// Development-only driver for the native UI-preview harness: loads a real track,
// sets Export Studio states for screenshots, and runs real exports through the
// studio's own controls (the only simulated step is the native save panel,
// replaced by a fixed path in the preview output directory).

const wait = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));
const click = (selector) => {
  const el = typeof selector === "string" ? document.querySelector(selector) : selector;
  if (!el) throw new Error(`Missing control ${selector}`);
  el.click();
  return el;
};
function setField(id, value) {
  const el = document.getElementById(id);
  el.focus();
  el.value = value;
  el.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
}
function log(kind, payload) {
  console.info(`[ExportRun] ${kind} ${JSON.stringify(payload)}`);
  // The UI-preview harness records stages in console.log; use them as the run log.
  window.CyanescentDiagnostics?.reportStage?.(`export-run:${kind}`, payload);
}

// Loading a track starts the visual warm-up and its splash screen (long on the first
// launch after a build). Wait for it to appear and close before using the studio.
async function waitForSplash() {
  const booting = () => document.body.classList.contains("engine-booting") || !window.__cyanescentFullAppReady
    || !document.getElementById("engineSplash")?.classList.contains("hidden");
  for (let i = 0; i < 32 && !booting(); i += 1) await wait(250);
  for (let i = 0; i < 720 && booting(); i += 1) await wait(250);
  await wait(700);
}

export async function loadFixtureTrack(ctx, { timeoutMs = 240000 } = {}) {
  // The fixture may start at "ui-ready", before the player and visuals finish booting.
  if (!window.__cyanescentFullAppReady) {
    log("waiting-for-app", {});
    await new Promise((resolve) => {
      window.addEventListener("cyanescent-app-ready", resolve, { once: true });
      const poll = () => (window.__cyanescentFullAppReady ? resolve() : window.setTimeout(poll, 250));
      poll();
    });
  }
  const name = ctx.params.get("fixtureAudio");
  // Read the fixture over the harness HTTP server. The native audio scheme can
  // stall without a playback gesture in an automated WKWebView session.
  const fixtureBlob = name ? URL.createObjectURL(await (await fetch(`/native-track/fixture-audio?t=${Date.now()}`)).blob()) : null;
  const track = name
    ? { id: "fixture-audio", name, url: fixtureBlob }
    : { id: "fixture-wav", name: "TestPsy.wav", url: new URL("assets/TestPsy.wav", window.location.href).href };
  log("track-loading", { name: track.name });
  await ctx.setPlayerQueue([track], 0, false);
  if (name) track.nativeId = "fixture-audio";
  log("track-queued", { name: track.name });
  const started = performance.now();
  let lastReport = 0;
  while (performance.now() - started < timeoutMs) {
    const { timeline, pending, duration } = ctx.analysis();
    if (timeline && !pending && duration > 0) break;
    if (performance.now() - lastReport > 10000) { lastReport = performance.now(); { const audio = ctx.audio?.(); log("waiting", { pending, duration, hasTimeline: Boolean(timeline), readyState: audio?.readyState, networkState: audio?.networkState, error: audio?.error?.code || 0, src: String(audio?.currentSrc || audio?.src || "").slice(0, 60), status: document.getElementById("audioDiagnostic")?.textContent?.slice(0, 120) }); } }
    await wait(400);
  }
  const { timeline, duration } = ctx.analysis();
  if (!timeline) throw new Error("The fixture track was not analysed in time.");
  log("track", { name: track.name, duration, frames: timeline.frames?.length || 0, drops: timeline.drops?.length || 0, seconds: Math.round((performance.now() - started) / 100) / 10 });
}

// Timers only: WebKit pauses animation frames while the harness window is covered.
async function settle(ms = 500) {
  await wait(ms);
}

export async function applyStudioState(ctx, previewId) {
  const { studio, journey } = ctx;
  await waitForSplash();
  await settle(800);
  // export-reel: start as a user with the visualiser showing; the studio must hide it.
  if (previewId === "export-reel") { ctx.showVisualiser?.(); await settle(2500); }
  ctx.openStudio();
  await settle(300);
  if (previewId === "export-auto" || previewId === "export-narrow") {
    studio.setMode("auto");
    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    if (ctx.range().mode === "selected") click('[data-range="full"]');
  }
  if (previewId === "export-reel") {
    studio.setMode("auto");
    click('[data-platform="instagram"]'); click('[data-format="ig-reel"]');
    click('[data-range="clip"]');
  }
  if (previewId === "export-advanced") {
    studio.setMode("auto");
    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    studio.openDrawer("output");
    await settle(100);
    click('#xsDrawer [data-set="resolution"][data-val="2160"]');
    click('#xsDrawer [data-set="codec"][data-val="h265"]');
  }
  if (previewId.startsWith("export-timeline")) {
    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    studio.setMode("custom");
    await settle(300);
    const markers = journey.state().markers.sort((a, b) => a.time - b.time);
    if (previewId === "export-timeline") ctx.seek((markers[1]?.time ?? 30) + 12);
    if (previewId === "export-timeline-add") {
      const drop = (ctx.analysis().timeline.drops || []).filter((d) => d.kind === "major")[1] || ctx.analysis().timeline.drops?.[0];
      ctx.seek(Math.max(1, (drop?.time ?? 60) - 1.6));
      journey.zoomAround?.(ctx.playhead(), 120);
      await settle(150);
      journey.openAddCard();
    }
    if (previewId === "export-timeline-edit") {
      const marker = markers[2] || markers[0];
      ctx.seek(marker.time + 20);
      journey.openSegCard(marker.id, { options: true });
    }
    if (previewId === "export-timeline-range") {
      const marker = markers[1] || markers[0];
      ctx.seek(marker.time + 4);
      click('#xsRangeScope [data-scope="section"]');
      await settle(100);
      setField("xsRangeStart", formatField(Math.max(0, marker.time - 10)));
      setField("xsRangeEnd", formatField(marker.time + 25));
      click("#xsRangeZoom");
    }
  }
  await settle(700);
  studio.capturePoster();
  await settle(600);
  // The first frame waits for the renderer to warm up (long on a first launch).
  const previewCanvas = document.querySelector('#exportWindow[data-mode="custom"]') ? "xsPreviewCanvasCustom" : "xsPreviewCanvasAuto";
  const splashSeen = !document.getElementById("engineSplash")?.classList.contains("hidden");
  for (let i = 0; i < 360 && !canvasStats(previewCanvas).hash; i += 1) await settle(500);
  log("preview", { ...previewStats(), splashDuringPreview: splashSeen || !document.getElementById("engineSplash")?.classList.contains("hidden") });
  log("layout", layoutStats());
  if (ctx.params.get("exportPlan") === "layout-modes") await checkLayoutModes(ctx);
  if (previewId === "export-reel") {
    await checkSinglePresetPreview(ctx);
    await checkPresetChangeWhilePlaying(ctx);
    await checkClipResizeWhilePlaying(ctx);
  }
  if (previewId === "export-timeline-big") await checkBigPreview(ctx, ctx.params.get("exportPlan") || "youtube");
  if (previewId === "export-timeline-audition") await checkAudition(ctx);
  if (previewId === "export-timeline-replay") await checkReplay(ctx);
  if (previewId === "export-timeline") {
    // The first preview frame waits for the visuals to finish compiling.
    for (let i = 0; i < 40 && !previewStats().hash; i += 1) await settle(500);
    log("preview-still", previewStats());
    const playLabel = () => document.querySelector("#xsTlPlay .lbl").textContent;
    const labelBefore = playLabel();
    click("#xsTlPlay");
    await settle(1500);
    log("play-button", { before: labelBefore, playing: playLabel(), audioPlaying: !ctx.audio()?.paused });
    const a = previewStats();
    await settle(1200);
    const b = previewStats();
    log("preview-playing", { a, b, moving: a.hash !== b.hash, state: document.getElementById("xsPreviewStateTl").textContent, visualiserNow: ctx.visualiserOpen?.() });
    click("#xsTlPlay");
    await settle(1200);
  }
}

// Reproduces: Single preset → another preset updates the preview; play shows moving
// frames in place (the visualiser window is never opened); pausing leaves the UI usable.
async function checkSinglePresetPreview(ctx) {
  const select = (id, value) => {
    const el = document.getElementById(id);
    el.value = String(value);
    el.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const visualiserBefore = ctx.visualiserOpen?.();
  click('[data-range="full"]');
  select("xsVisualBehaviour", "static");
  await settle(300);
  const options = [...document.getElementById("xsSinglePreset").options];
  const target = options.find((o) => /newton basin/i.test(o.textContent)) || options[1];
  const idle = async () => { for (let i = 0; i < 3; i += 1) { await settle(450); await ctx.studio.whenPreviewIdle(); } await settle(700); };
  // Start from a different preset so the change is visible in the still.
  const other = options.find((o) => o.value !== target.value && !/newton/i.test(o.textContent));
  select("xsSinglePreset", other.value);
  await idle();
  const before = previewStats();
  const changedAt = performance.now();
  select("xsSinglePreset", target.value);
  await idle();
  log("single-preset", {
    chosen: target.textContent, activePreset: ctx.activePreset(), expected: Number(target.value),
    summary: document.getElementById("xsSumLine2")?.textContent || "", label: document.querySelector("#xsPreviewAuto .pv-label")?.textContent || "",
    from: other.textContent, hashBefore: before.hash, hashAfter: previewStats().hash, meanBefore: before.mean, meanAfter: previewStats().mean,
    updatedWithinMs: Math.round(performance.now() - changedAt)
  });
  click("#xsPreviewPlay");
  await settle(1500);
  const a = previewStats();
  await settle(1200);
  const b = previewStats();
  log("preview-playing", { a, b, moving: a.hash !== b.hash, state: document.getElementById("xsPreviewState").textContent, visualiserBefore, visualiserNow: ctx.visualiserOpen?.() });
  click("#xsPreviewPlay");
  await settle(1200);
  const started = performance.now();
  await wait(0);
  const latency = performance.now() - started;
  ctx.studio.closeDialog();
  await settle(600);
  const visualiserAfterClose = ctx.visualiserOpen?.();
  ctx.openStudio();
  await settle(900);
  log("after-pause", { paused: ctx.audio()?.paused, state: document.getElementById("xsPreviewState").textContent, activePreset: ctx.activePreset(), timerLatencyMs: Math.round(latency), visualiserAfterClose, visualiserNow: ctx.visualiserOpen?.(), stats: previewStats() });
}

function previewStats() {
  const main = document.getElementById("visualizer");
  const target = document.querySelector('#exportWindow[data-mode="custom"]') ? document.getElementById("xsPreviewCanvasCustom") : document.getElementById("xsPreviewCanvasAuto");
  let mean = -1;
  let hash = 0;
  try {
    const c = target.getContext("2d");
    const d = c.getImageData(0, 0, target.width, target.height).data;
    let sum = 0;
    for (let i = 0; i < d.length; i += 4 * 97) sum += d[i] + d[i + 1] + d[i + 2];
    mean = Math.round(sum / (d.length / (4 * 97)) / 3);
    let h = 0;
    for (let i = 0; i < d.length; i += 4 * 31) h = (h * 31 + d[i] + d[i + 1] * 7 + d[i + 2] * 13) >>> 0;
    hash = h;
  } catch (error) { mean = String(error.message || error); }
  return { target: target ? `${target.width}x${target.height}` : "none", mean, hash };
}

// The preview keeps its size across range modes and transition styles; ends on
// Select range with video transitions (where the edition offers them).
async function checkLayoutModes(ctx) {
  if (ctx.studio.mode?.() === "custom" || document.getElementById("exportWindow").dataset.mode === "custom") {
    click('#xsRangeScope [data-scope="entire"]'); await settle(600); log("layout-entire", layoutStats());
    click('#xsRangeScope [data-scope="section"]'); await settle(600); log("layout-selected", layoutStats());
  }
  ctx.studio.openDrawer("visuals"); await settle(500);
  const video = document.querySelector('#xsDrawer [data-set="style"][data-val="video"]');
  log("layout-drawer", { ...layoutStats(), videoTransitionsOffered: Boolean(video) });
  if (video) { video.click(); await settle(800); log("layout-video-transitions", layoutStats()); }
  click("#xsDrawerClose"); await settle(800);
  ctx.studio.capturePoster(); await settle(800);
  log("layout-final", { ...layoutStats(), style: document.querySelector('#xsDrawer [data-set="style"][aria-checked="true"]')?.dataset.val || "rendered" });
}

// Preview size and whether the studio's controls fit the window.
function layoutStats() {
  const root = document.getElementById("exportWindow");
  const custom = root.dataset.mode === "custom";
  const size = (el) => { const r = el?.getBoundingClientRect(); return r && r.width ? `${Math.round(r.width)}x${Math.round(r.height)}` : "hidden"; };
  const studio = root.getBoundingClientRect();
  const exportBtn = document.getElementById("exportVideoBtn") || root.querySelector(".export-btn");
  const btn = exportBtn?.getBoundingClientRect();
  const clipped = [...root.querySelectorAll("button, input, select")].filter((el) => {
    const r = el.getBoundingClientRect();
    return r.width > 0 && (r.right > studio.right + 1 || r.left < studio.left - 1);
  }).map((el) => el.id || el.textContent.trim().slice(0, 24));
  return {
    studio: size(root), frame: size(root.querySelector(custom ? "#xsPreviewCustom .preview-frame" : "#xsPreviewAuto .preview-frame")),
    timeline: custom ? size(document.getElementById("xsTlMain")) : "n/a", range: custom ? (document.getElementById("xsRangeInline").hidden ? "entire" : "selected") : "auto",
    exportVisible: Boolean(btn && btn.bottom <= studio.bottom + 1 && btn.top >= studio.top), horizontalOverflow: root.scrollWidth > root.clientWidth + 1, clipped
  };
}

function formatLong(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = (seconds % 60).toFixed(1).padStart(4, "0");
  return `${h}:${String(m).padStart(2, "0")}:${s}`;
}

function formatField(seconds) {
  const m = Math.floor(seconds / 60);
  const s = (seconds % 60).toFixed(1).padStart(4, "0");
  return `${m}:${s}`;
}

async function runExport(ctx, name, { timeoutMs = 900000 } = {}) {
  log("export-request", {name});
  const dir = ctx.params.get("previewOutputDirectory");
  const path = `${dir}/${name}.mp4`;
  window.__exportLocationChosen({ path, fileName: `${name}.mp4` });
  await settle(150);
  const blocker = document.getElementById("xsExportBlocker");
  if (document.getElementById("startExportVideo").disabled) {
    log("result", { name, ok: false, reason: blocker.textContent || "Export button disabled" });
    return { name, ok: false };
  }
  const options = ctx.exportOptions();
  const plan = { range: ctx.range(), destinationId: options.destinationId, width: options.width, height: options.height, fps: options.fps, codec: options.codec, includeAudio: options.includeAudio, custom: ctx.studio.isCustom() };
  if (ctx.studio.isCustom()) plan.sequence = ctx.journey.previewPlan();
  const started = performance.now();
  click("#startExportVideo");
  log("export-clicked", {name, active:ctx.exportState.active});
  await wait(400);
  while (performance.now() - started < timeoutMs) {
    if (!ctx.exportState.active && (!document.getElementById("xsFootDone").hidden || !document.getElementById("xsFootReady").hidden)) break;
    await wait(500);
  }
  const ok = !document.getElementById("xsFootDone").hidden;
  const result = { name, ok, path: ctx.exportState.savedPath || path, seconds: Math.round((performance.now() - started) / 100) / 10, status: document.getElementById("exportStatus").textContent, blocker: blocker.hidden ? "" : blocker.textContent, plan };
  log("result", result);
  if (ok) click("#xsDoneBack");
  await settle(300);
  return result;
}

// Focused rendering matrix, through the real Studio controls and native encoder.
async function runMotionMatrix(ctx, names = "ABCDEFGH", transitionId = "aurora_storm", fps = 30) {
  const pick = (selector, value) => {
    const el = document.querySelector(selector);
    if (!el) throw new Error(`Missing diagnostic field ${selector}`);
    el.value = String(value); el.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const cases = {
    A: { from: 392 }, B: { from: 397 },
    C: { from: 154, to: 148 }, D: { from: 154, to: 148, video: true },
    E: { from: 154, to: 392, video: true }, F: { from: 148, to: 392 },
    J: { from: 397, offset: 60 }, K: { from: 392, offset: 64 },
    G: { from: 154, automatic: true }, H: { from: 154, to: 392, video: true, offset: 60 },
    // Chaotic Butterfly Tunnels: the breath, drop and unfurling (55.9 s on TestPsy), a zero start,
    // and a start inside the second unfurling's aftermath (167.7 s)
    L: { from: 94, offset: 50, len: 12 }, N: { from: 94 }, P: { from: 94, offset: 169, len: 6 }
  };
  click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
  ctx.studio.openDrawer("output"); await settle(100);
  click('#xsDrawer [data-set="resolution"][data-val="720"]');
  click(`#xsDrawer [data-set="fps"][data-val="${fps}"]`);
  ctx.studio.closeDrawer();
  ctx.studio.setMode("custom"); await settle(200);
  window.__offlineExportDiagnostics = (frame) => log("frame", frame);
  for (const name of names) {
    const item = cases[name];
    ctx.studio.setMode("custom");
    ctx.seek(0);
    for (const marker of ctx.journey.state().markers) {
      ctx.journey.openSegCard(marker.id);
      click('#xsCtxCard [data-act="remove"]');
    }
    click('[data-seq="single"]');
    if (!document.getElementById("xsConfirm").hidden) click("#xsConfirmOk");
    ctx.journey.openSegCard("open");
    pick('#xsCtxCard [data-field="segPreset"]', item.from);
    click('#xsCtxCard [data-act="close"]');
    if (item.to) {
      ctx.seek((item.offset || 0) + 7);
      ctx.journey.openAddCard();
      pick('#xsCtxCard [data-field="segPreset"]', item.to);
      pick('#xsCtxCard [data-field="trStyle"]', "quick");
      if (item.video) {
        // openAddCard already expands the options; clicking again would collapse them.
        if (document.querySelector('#xsCtxCard [data-act="more"]')?.getAttribute("aria-expanded") !== "true") click('#xsCtxCard [data-act="more"]');
        click('#xsCtxCard [data-act="trtype"][data-v="video"]');
        pick('#xsCtxCard [data-field="trvideo"]', transitionId);
      }
    }
    if (item.automatic) {
      ctx.studio.setMode("auto");
      pick("#xsVisualBehaviour", "static"); pick("#xsSinglePreset", item.from);
      click('[data-range="clip"]'); await settle(50);
      setField("xsClipStart", formatField(item.offset || 0)); setField("xsClipLength", "0:05.0");
    } else {
      click('#xsRangeScope [data-scope="section"]'); await settle(50);
      setField("xsRangeStart", formatField(item.offset || 0));
      setField("xsRangeEnd", formatField((item.offset || 0) + (item.len || (item.to ? 14 : 5))));
    }
    await ctx.studio.whenPreviewIdle();
    log("matrix-case", { name, ...item, plan: ctx.journey.previewPlan() });
    const result = await runExport(ctx, `motion-${name}${fps === 30 ? "" : `-${fps}fps`}`);
    if (!result.ok) throw new Error(`Motion case ${name} failed: ${result.status}`);
  }
  delete window.__offlineExportDiagnostics;
}

async function checkMotionPreviews(ctx) {
  const pick = (id, value) => { const el = document.getElementById(id); el.value = String(value); el.dispatchEvent(new Event("change", { bubbles: true })); };
  ctx.studio.setMode("auto");
  pick("xsVisualBehaviour", "static");
  click('[data-range="full"]');
  for (const id of [392, 397]) {
    pick("xsSinglePreset", id);
    const frames = [];
    for (const time of [0, 2, 4]) {
      ctx.seek(time); ctx.studio.capturePoster();
      // capturePoster debounces for 300ms before joining previewQueue.
      await settle(350);
      await ctx.studio.whenPreviewIdle();
      frames.push({ time, preset: ctx.activePreset(), ...previewStats() });
    }
    log("motion-preview", { id, frames });
    if (frames.some((frame) => !frame.hash) || new Set(frames.map((frame) => frame.hash)).size < 3) throw new Error(`Preset ${id} preview did not produce three distinct images`);
  }
}

// Pro Video My Transitions against a pre-filled test library
// (CYANESCENT_USER_TRANSITIONS_DIR): listing, Options panel, WebKit playback of
// each stored clip, a live transition in My Transitions mode, and real exports.
async function checkMyTransitions(ctx) {
  const library = await (await fetch(`user-transitions/library.json?t=${Date.now()}`)).json();
  const entries = library.entries || [];
  log("my-library", { revision: library.revision, entries: entries.map((e) => ({ id: e.id, name: e.name, status: e.status, codec: e.codec, processing: e.processing, enabled: e.enabled })) });
  if (!entries.some((e) => e.status === "ok")) throw new Error("The test library has no playable clips");
  ctx.studio.closeDialog();
  await settle(500);
  click("#optionsButton");
  await settle(1500);
  const items = [...document.querySelectorAll("#myTransitionsList .my-transition-item")];
  const thumbs = await Promise.all(items.map((item) => {
    const img = item.querySelector("img");
    return img ? img.decode().then(() => img.naturalWidth).catch(() => 0) : Promise.resolve(-1);
  }));
  log("my-panel", {
    visible: !document.getElementById("myTransitions").hidden,
    hint: document.querySelector("#myTransitions .transition-hint")?.textContent,
    modes: [...document.getElementById("videoTransitionMode").options].map((o) => o.value),
    items: items.map((item, i) => ({ name: item.querySelector("strong")?.textContent, details: item.querySelector(".my-transition-meta span")?.textContent, unavailable: item.classList.contains("is-unavailable"), thumbWidth: thumbs[i] }))
  });
  // Each stored clip through WebKit's own decoder via the app's local server.
  for (const entry of entries.filter((e) => e.status === "ok")) {
    const video = document.createElement("video");
    video.muted = true; video.playsInline = true; video.preload = "auto"; video.src = entry.file;
    const started = performance.now();
    await video.play().catch((error) => log("my-play-error", { id: entry.id, error: String(error) }));
    await wait(1500);
    log("my-webkit-playback", { name: entry.name, codec: entry.codec, readyState: video.readyState, currentTime: Math.round(video.currentTime * 100) / 100, size: `${video.videoWidth}x${video.videoHeight}`, error: video.error?.code || 0, ms: Math.round(performance.now() - started) });
    video.pause(); video.removeAttribute("src"); video.load();
  }
  const pick = (id, value) => { const el = document.getElementById(id); el.value = String(value); el.dispatchEvent(new Event("change", { bubbles: true })); };
  const use = document.getElementById("useVideoTransitions");
  if (!use.checked) { use.checked = true; use.dispatchEvent(new Event("change", { bubbles: true })); }
  pick("videoTransitionMode", "user");
  click("#closeOptions");
  await settle(400);
  // A live manual preset change must pick and play an imported clip in the
  // detached visual output, which keeps its own library copy in sync.
  ctx.showVisualiser?.();
  await settle(8000);
  const output = window.open("", "cyanescent-visual-output");
  const element = output?.document?.getElementById("transitionVideo") || document.getElementById("transitionVideo");
  log("my-live-target", { output: Boolean(output?.document?.getElementById("transitionVideo")), visualiser: ctx.visualiserOpen?.() });
  ctx.audio()?.play?.().catch(() => {});
  await settle(1500);
  const presetSelect = document.getElementById("presetSelect");
  const nextPreset = [...presetSelect.options].find((o) => Number(o.value) !== ctx.activePreset());
  pick("presetSelect", nextPreset.value);
  const samples = [];
  for (let i = 0; i < 24; i += 1) {
    await wait(500);
    samples.push({ t: (i + 1) * 0.5, src: String(element.currentSrc || element.src || "").replace(/^.*\/user-transitions\//, "user-transitions/").slice(0, 60), time: Math.round(element.currentTime * 100) / 100, opacity: Number(element.style.opacity || 0).toFixed(2), paused: element.paused });
  }
  ctx.audio()?.pause?.();
  log("my-live-transition", { samples });
  if (!samples.some((s) => s.src.startsWith("user-transitions/") && Number(s.opacity) > 0.99 && s.time > 3)) throw new Error("The live transition did not show an imported clip");
  // The export-run report expects the studio to be open at the end.
  ctx.openStudio();
  await settle(600);
}

// Real exports with imported clips (run without the visual output window).
async function exportMyTransitions(ctx) {
  const library = await (await fetch(`user-transitions/library.json?t=${Date.now()}`)).json();
  const entries = library.entries || [];
  const pick = (id, value) => { const el = document.getElementById(id); el.value = String(value); el.dispatchEvent(new Event("change", { bubbles: true })); };
  const use = document.getElementById("useVideoTransitions");
  if (!use.checked) { use.checked = true; use.dispatchEvent(new Event("change", { bubbles: true })); }
  pick("videoTransitionMode", "user");
  const chosen = entries.find((e) => e.status === "ok");
  await runMotionMatrix(ctx, "D", `user:${chosen.id}`);
  // Automatic mode with My Transitions over the whole track (720p30 from the matrix).
  ctx.studio.setMode("auto");
  pick("xsVisualBehaviour", "adaptive");
  ctx.studio.openDrawer("visuals"); await settle(200);
  click('#xsDrawer [data-set="style"][data-val="video"]');
  ctx.studio.closeDrawer();
  click('[data-range="full"]'); await settle(100);
  const overlays = new Map();
  window.__offlineExportDiagnostics = (frame) => {
    const path = frame.transitionOverlay?.path || "";
    if (path) overlays.set(path, (overlays.get(path) || 0) + 1);
  };
  const auto = await runExport(ctx, "my-transitions-automatic");
  delete window.__offlineExportDiagnostics;
  log("my-automatic-overlays", Object.fromEntries(overlays));
  if (!auto.ok) throw new Error(`Automatic export failed: ${auto.status}`);
}

const PLANS = {
  "my-transitions": checkMyTransitions,
  "my-transitions-export": exportMyTransitions,
  // Leaves Options open on the panel for the end-of-run screenshot.
  "my-transitions-panel": async (ctx) => {
    ctx.studio.closeDialog();
    await settle(400);
    click("#optionsButton");
    await settle(800);
    const mode = document.getElementById("videoTransitionMode");
    mode.value = "user"; mode.dispatchEvent(new Event("change", { bubbles: true }));
    document.getElementById("myTransitions").scrollIntoView({ block: "start" });
    await settle(1500);
  },
  "motion-preview": checkMotionPreviews,
  motion: (ctx) => runMotionMatrix(ctx),
  "motion-baseline": (ctx) => runMotionMatrix(ctx, "ABDE"),
  "motion-range": (ctx) => runMotionMatrix(ctx, "JK"),
  "motion-newton": (ctx) => runMotionMatrix(ctx, "A"),
  "motion-automatic": (ctx) => runMotionMatrix(ctx, "G"),
  "motion-hypercube": (ctx) => runMotionMatrix(ctx, "DEH", "hypercube_transforms_into_universe"),
  "motion-butterfly": async (ctx) => { await runMotionMatrix(ctx, "LNP"); await runMotionMatrix(ctx, "L", "aurora_storm", 60); },
  // Stage One checkpoint: Automatic mode, short regions.
  automatic: async (ctx) => {
    const { studio } = ctx;
    studio.setMode("auto");
    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    click('[data-range="clip"]'); await settle(100);
    setField("xsClipStart", "1:00.0"); setField("xsClipLength", "0:20.0");
    await runExport(ctx, "01-youtube-music-video-1080p60-clip20s");

    click('[data-platform="instagram"]'); click('[data-format="ig-reel"]');
    if (ctx.range().mode !== "selected") click('[data-range="clip"]');
    click('#xsDurPills [data-len="30"]');
    await runExport(ctx, "02-instagram-reel-30s");

    click('[data-platform="youtube"]'); click('[data-format="yt-shorts"]');
    click('#xsDurPills [data-len="15"]');
    await runExport(ctx, "03-youtube-shorts-15s");

    click('[data-platform="other"]'); click('[data-format="custom"]');
    await settle(100);
    const width = document.getElementById("xsCustomWidth");
    width.value = "1280"; width.dispatchEvent(new Event("input", { bubbles: true }));
    const height = document.getElementById("xsCustomHeight");
    height.value = "960"; height.dispatchEvent(new Event("input", { bubbles: true }));
    studio.closeDrawer();
    click('#xsDurPills [data-len="15"]');
    setField("xsClipLength", "0:10.0");
    await runExport(ctx, "04-custom-1280x960-10s");

    click('[data-platform="other"]'); click('[data-format="canvas"]');
    await runExport(ctx, "05-spotify-canvas-8s");

    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    studio.openDrawer("output"); await settle(100);
    click('#xsDrawer [data-set="resolution"][data-val="2160"]');
    click('#xsDrawer [data-set="codec"][data-val="h265"]');
    studio.closeDrawer();
    setField("xsClipLength", "0:06.0");
    await runExport(ctx, "06-youtube-4k60-h265-6s");
    studio.openDrawer("output"); await settle(100);
    click('#xsDrawer [data-set="resolution"][data-val="1080"]');
    click('#xsDrawer [data-set="codec"][data-val="h264"]');
    studio.closeDrawer();
  },
  // Stage Two/Three: Custom Timeline sequences and selected ranges.
  custom: async (ctx) => {
    const { studio, journey } = ctx;
    click('[data-platform="other"]'); click('[data-format="landscape"]');
    studio.setMode("custom");
    await settle(300);
    let markers = journey.state().markers.sort((a, b) => a.time - b.time);
    log("sequence", { startPreset: journey.state().startPreset, markers: markers.map((m) => [m.time, m.presetId, m.style, m.transitionKind]) });
    // A range that starts just before a transition, across it.
    const m1 = markers[0];
    click('#xsRangeScope [data-scope="section"]'); await settle(100);
    setField("xsRangeStart", formatField(Math.max(0, m1.time - 6)));
    setField("xsRangeEnd", formatField(m1.time + 10));
    await runExport(ctx, "10-timeline-generated-range");
    await runExport(ctx, "11-timeline-generated-range-repeat");
    // Edit: change a preset, add a change at the playhead, export a range near the end.
    const m2 = markers[1];
    journey.openSegCard(m2.id);
    await settle(100);
    const select = document.querySelector('#xsCtxCard [data-field="segPreset"]');
    const other = Array.from(select.options).find((o) => o.value !== select.value);
    select.value = other.value; select.dispatchEvent(new Event("change", { bubbles: true }));
    click('#xsCtxCard [data-act="close"]');
    const duration = ctx.analysis().duration;
    ctx.seek(duration - 12);
    click("#xsTlAdd"); await settle(100);
    markers = journey.state().markers.sort((a, b) => a.time - b.time);
    log("edited", { edits: journey.state().edits, markers: markers.map((m) => [m.time, m.presetId]) });
    setField("xsRangeStart", formatField(duration - 20));
    setField("xsRangeEnd", formatField(duration - 2));
    await runExport(ctx, "12-timeline-edited-range-near-end");
    // Video export after seeking: entire track would be long, so seek around and export a mid range.
    ctx.seek(duration * 0.7); await settle(200); ctx.seek(duration * 0.2); await settle(200);
    setField("xsRangeStart", formatField(m2.time - 4));
    setField("xsRangeEnd", formatField(m2.time + 8));
    await runExport(ctx, "13-timeline-after-seeking-edited-change");
  },
  // Long recordings: responsiveness, a short range near the end, whole-track view.
  long: async (ctx) => {
    const { studio, journey } = ctx;
    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    studio.setMode("custom");
    await settle(800);
    const duration = ctx.analysis().duration;
    document.getElementById("xsTlFit").click();
    await settle(200);
    let t0 = performance.now();
    for (let i = 0; i < 10; i += 1) journey.redraw();
    const fullDraw = (performance.now() - t0) / 10;
    journey.zoomAround(duration - 300, 300);
    t0 = performance.now();
    for (let i = 0; i < 10; i += 1) journey.redraw();
    const zoomDraw = (performance.now() - t0) / 10;
    const state = journey.state();
    log("long-track", { duration, markers: state.markers.length, startPreset: state.startPreset, fullDrawMs: Math.round(fullDraw * 10) / 10, fiveMinuteDrawMs: Math.round(zoomDraw * 10) / 10 });
    click('#xsRangeScope [data-scope="section"]'); await settle(100);
    setField("xsRangeStart", formatLong(duration - 45));
    setField("xsRangeEnd", formatLong(duration - 30));
    click("#xsRangeZoom");
    await runExport(ctx, "30-long-set-range-near-end");
    click('#xsRangeScope [data-scope="entire"]');
    document.getElementById("xsTlFit").click();
    await settle(300);
  },
  // Starts a real export and returns while it renders, so the capture shows the progress footer.
  progress: async (ctx) => {
    ctx.studio.setMode("auto");
    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    if (ctx.range().mode === "selected") click('[data-range="full"]');
    const dir = ctx.params.get("previewOutputDirectory");
    window.__exportLocationChosen({ path: `${dir}/progress-check.mp4`, fileName: "progress-check.mp4" });
    await settle(200);
    click("#startExportVideo");
    await settle(12000);
    log("progress", { status: document.getElementById("exportStatus").textContent, title: document.getElementById("exportStatus").title });
  },
  // A complete track (long render).
  full: async (ctx) => {
    ctx.studio.setMode("auto");
    click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
    if (ctx.range().mode === "selected") click('[data-range="full"]');
    await runExport(ctx, "20-youtube-music-video-full-track", { timeoutMs: 3 * 3600 * 1000 });
  }
};

// Deterministic automatic timing acceptance run, native Pro at 1080p/30.
async function runAutomaticTiming(ctx, {durations = [2.6,6,12], cancelFirst = false} = {}) {
  ctx.studio.setMode("auto");
  click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
  const behaviour=document.getElementById("xsVisualBehaviour");
  behaviour.value="adaptive"; behaviour.dispatchEvent(new Event("change",{bubbles:true}));
  ctx.studio.openDrawer("output");
  click('#xsDrawer [data-set="resolution"][data-val="1080"]');
  click('#xsDrawer [data-set="fps"][data-val="30"]');
  ctx.studio.closeDrawer();
  click('[data-range="clip"]'); await settle(100);
  for (const seconds of durations) {
    ctx.studio.openDrawer("visuals"); await settle(100);
    click('#xsDrawer [data-set="style"][data-val="rendered"]');
    click(`#xsDrawer [data-set="renderedTransitionDuration"][data-val="${seconds}"]`);
    click('#xsDrawer [data-set="autoClipBehaviour"][data-val="match-full"]');
    ctx.studio.closeDrawer();
    await ctx.studio.whenPreviewIdle();
    const plan=ctx.automaticPlan();
    const item=plan.timeline[0];
    if (!item) throw Error("Missing automatic transition");
    setField("xsClipStart",formatField(Math.max(0,item.startTime-1)));
    setField("xsClipLength",formatField(item.duration+2));
    await ctx.studio.whenPreviewIdle();
    log("timing-plan",{seconds,item,startPreset:plan.startPreset,options:ctx.exportOptions()});
    if (cancelFirst) {
      window.__offlineExportDiagnostics = frame => {
        log("frame",frame);
        if (frame.frameIndex >= 30) click("#cancelExportVideo");
      };
      const cancelled = await runExport(ctx, "automatic-rendered-cancelled");
      if (cancelled.ok || ctx.exportState.active || ctx.exportState.cancelRequested) throw Error("Cancellation did not restore idle state");
      log("timing-cancelled", {status:cancelled.status, options:ctx.exportOptions()});
    }
    window.__offlineExportDiagnostics = frame => log("frame",frame);
    const result=await runExport(ctx,`automatic-rendered-${seconds}s-1080p`);
    delete window.__offlineExportDiagnostics;
    if(!result.ok) throw Error(result.status);
  }
}

async function runCustomTimelineUx(ctx) {
  ctx.studio.setMode("custom");
  click('[data-platform="youtube"]'); click('[data-format="yt-video"]');
  ctx.studio.openDrawer("output");
  click('#xsDrawer [data-set="fps"][data-val="30"]');
  click('#xsDrawer [data-set="resolution"][data-val="1080"]');
  ctx.studio.closeDrawer();
  click('[data-seq="single"]');
  if (!document.getElementById("xsConfirm").hidden) click("#xsConfirmOk");
  const set = (field,value) => {
    const el=document.querySelector(`#xsCtxCard [data-field="${field}"]`);
    if(!el) throw Error(`Missing editor ${field}`);
    el.value=String(value); el.dispatchEvent(new Event("change",{bubbles:true}));
  };
  ctx.journey.openSegCard("open"); set("segPreset",154);
  ctx.seek(10); ctx.journey.openAddCard(); set("segPreset",148); set("trStyle","smooth");
  const edited=JSON.stringify(ctx.journey.state());
  click("#xsTlUndo"); click("#xsTlRedo");
  if(JSON.stringify(ctx.journey.state())!==edited) throw Error("Immediate edit Undo/Redo differs");
  ctx.journey.openSegCard("open"); ctx.journey.openSegCard(ctx.journey.state().markers[0].id);
  if(JSON.stringify(ctx.journey.state())!==edited) throw Error("Switching lost edits");
  click('#xsCtxCard [data-act="close"]');
  click('#xsRangeScope [data-scope="section"]'); await settle(50);
  setField("xsRangeStart","0:04.0"); setField("xsRangeEnd","0:16.0");
  await ctx.studio.whenPreviewIdle();
  const plan=ctx.journey.previewPlan();
  if(Math.abs(plan.transitions[0].durationSeconds-6)>.001 || plan.transitions[0].landingTime!==10) throw Error("Wrong committed transition");
  log("custom-ux",{immediateEdits:true,undoRedo:true,selectionRetained:true,plan});
  window.__offlineExportDiagnostics=frame=>log("frame",frame);
  const result=await runExport(ctx,"custom-timeline-smooth-1080p");
  delete window.__offlineExportDiagnostics;
  if(!result.ok) throw Error(result.status);
}

export async function runExportPlan(ctx, planName) {
  await waitForSplash();
  if (String(planName).startsWith("preset-soak:")) {
    const { runPresetExportSoak } = await import("./presetExportSoak.js");
    return runPresetExportSoak(ctx, JSON.parse(planName.slice("preset-soak:".length)));
  }
  ctx.openStudio();
  await settle(400);
  if (planName === "custom-timeline-ux") return runCustomTimelineUx(ctx);
  if (planName === "automatic-timing") return runAutomaticTiming(ctx);
  if (planName === "automatic-timing-retry") { await runAutomaticTiming(ctx, {durations:[2.6], cancelFirst:true}); return runMotionMatrix(ctx,"C"); }
  const failures = [];
  for (const name of String(planName || "automatic").split(",")) {
    const plan = PLANS[name.trim()];
    if (!plan) { failures.push(`Unknown export plan ${name}`); log("error", { message: failures.at(-1) }); continue; }
    log("plan-start", { plan: name });
    try { await plan(ctx); } catch (error) { failures.push(String(error?.stack || error)); log("error", { plan: name, message: failures.at(-1) }); }
    log("plan-end", { plan: name });
  }
  if (failures.length) throw new Error(failures.join("\n"));
}

// Changing the single preset while the preview plays must take effect at once and
// survive pause and resume.
async function checkPresetChangeWhilePlaying(ctx) {
  const pick = (id, value) => { const el = document.getElementById(id); el.value = String(value); el.dispatchEvent(new Event("change", { bubbles: true })); };
  const options = [...document.getElementById("xsSinglePreset").options];
  const next = options.find((o) => /fractal temple/i.test(o.textContent)) || options.find((o) => Number(o.value) !== ctx.activePreset());
  click("#xsPreviewPlay");
  await settle(2000);
  const before = previewStats();
  pick("xsSinglePreset", next.value);
  await settle(2500);
  const during = { activePreset: ctx.activePreset(), mean: previewStats().mean, meanBefore: before.mean, playing: !ctx.audio()?.paused, state: document.getElementById("xsPreviewState").textContent };
  click("#xsPreviewPlay");
  await settle(1500);
  const paused = { activePreset: ctx.activePreset(), select: Number(document.getElementById("xsSinglePreset").value) };
  click("#xsPreviewPlay");
  await settle(2000);
  const resumed = { activePreset: ctx.activePreset(), mean: previewStats().mean, state: document.getElementById("xsPreviewState").textContent };
  click("#xsPreviewPlay");
  await settle(1200);
  log("preset-while-playing", { expected: Number(next.value), name: next.textContent, during, paused, resumed, after: ctx.activePreset(), summary: document.getElementById("xsSumLine2").textContent });
}

// Lengthening the selected clip while it plays: playback must run past the old end,
// and seeking into the extended part must stay there.
async function checkClipResizeWhilePlaying(ctx) {
  click('[data-range="clip"]');
  await settle(200);
  click('#xsDurPills [data-len="30"]');
  await settle(300);
  const r0 = ctx.range();
  ctx.seek(r0.start);
  const label = () => document.getElementById("xsPreviewState").textContent;
  const labels = [];
  click("#xsClipPlay");
  await settle(1000);
  labels.push(`play:${label()}`);
  setField("xsClipEnd", formatField(r0.start + 45));
  await settle(400);
  labels.push(`resized:${label()}`);
  const r1 = ctx.range();
  ctx.seek(r0.start + 28);
  await settle(4500);
  const pastOldEnd = ctx.playhead() - r0.start;
  labels.push(`past30:${label()}`);
  ctx.seek(r0.start + 40);
  await settle(1500);
  const inExtension = ctx.playhead() - r0.start;
  ctx.seek(r1.end - 1.5);
  await settle(3000);
  const afterLoop = ctx.playhead() - r0.start;
  const playing = !ctx.audio()?.paused;
  labels.push(`end:${label()}`);
  click("#xsClipPlay");
  await settle(600);
  log("clip-resize-while-playing", { lengthBefore: +(r0.end - r0.start).toFixed(2), lengthAfter: +(r1.end - r1.start).toFixed(2), pastOldEnd: +pastOldEnd.toFixed(2), inExtension: +inExtension.toFixed(2), afterLoop: +afterLoop.toFixed(2), playing, labels: labels.join(" ") });
}

const studioRoot = () => document.getElementById("exportWindow");
const key = (k) => studioRoot().dispatchEvent(new KeyboardEvent("keydown", { key: k, bubbles: true }));
function canvasStats(id) {
  const c = document.getElementById(id);
  try {
    const d = c.getContext("2d").getImageData(0, 0, c.width, c.height).data;
    let sum = 0; let h = 0; let n = 0;
    for (let i = 0; i < d.length; i += 4 * 97) { sum += d[i] + d[i + 1] + d[i + 2]; n += 1; }
    for (let i = 0; i < d.length; i += 4 * 31) h = (h * 31 + d[i] + d[i + 1] * 7 + d[i + 2] * 13) >>> 0;
    const r = c.getBoundingClientRect();
    return { px: `${c.width}x${c.height}`, css: `${Math.round(r.width)}x${Math.round(r.height)}`, mean: Math.round(sum / Math.max(1, n) / 3), hash: h };
  } catch (error) { return { error: String(error) }; }
}
const sortedMarkers = (ctx) => ctx.journey.state().markers.sort((a, b) => a.time - b.time);
async function waitFrame(id, tries = 40) { for (let i = 0; i < tries && !canvasStats(id).hash; i += 1) await settle(500); }

// Large preview at an output aspect ratio: real frames, correct aspect, playback,
// seeking, Escape, and nothing in the timeline changes.
async function checkBigPreview(ctx, variant) {
  const formats = { youtube: ["youtube", "yt-video"], reel: ["instagram", "ig-reel"], feed: ["instagram", "ig-feed"] };
  const [platform, format] = formats[variant] || formats.youtube;
  ctx.studio.setMode("auto");
  await settle(200);
  click(`[data-platform="${platform}"]`); click(`[data-format="${format}"]`);
  ctx.studio.setMode("custom");
  await settle(400);
  const markers = sortedMarkers(ctx);
  const before = JSON.stringify(ctx.journey.state());
  const rangeBefore = JSON.stringify(ctx.range());
  const t0 = Math.max(1, (markers[1]?.time ?? 40) - 4);
  ctx.seek(t0);
  click("#xsTlPreviewBig");
  await settle(400);
  await waitFrame("xsBigCanvas");
  const frame = document.getElementById("xsBigFrame").getBoundingClientRect();
  const stage = document.getElementById("xsBigStage").getBoundingClientRect();
  const out = ctx.exportOptions();
  const still = canvasStats("xsBigCanvas");
  click("#xsBigPlay");
  await settle(2000);
  const a = canvasStats("xsBigCanvas");
  await settle(1500);
  const b = canvasStats("xsBigCanvas");
  const playing = { audio: !ctx.audio()?.paused, label: document.querySelector("#xsBigPlay .lbl").textContent, state: document.getElementById("xsBigState").textContent, preset: document.getElementById("xsBigPreset").textContent };
  click("#xsBigPlay");
  await settle(800);
  const paused = !!ctx.audio()?.paused;
  // Seek with the position bar while paused: the still follows.
  const seek = document.getElementById("xsBigSeek");
  seek.value = "600"; seek.dispatchEvent(new Event("input", { bubbles: true }));
  await settle(1800);
  const afterSeek = { playhead: +ctx.playhead().toFixed(2), expected: +(ctx.analysis().duration * 0.6).toFixed(2), frame: canvasStats("xsBigCanvas") };
  const playheadBeforeClose = ctx.playhead();
  key("Escape");
  await settle(500);
  const closed = document.getElementById("xsBig").hidden;
  log("big-preview", {
    variant, output: `${out.width}x${out.height}`,
    frameAspect: +(frame.width / frame.height).toFixed(3), outputAspect: +(out.width / out.height).toFixed(3),
    frameCss: `${Math.round(frame.width)}x${Math.round(frame.height)}`, stageCss: `${Math.round(stage.width)}x${Math.round(stage.height)}`,
    still, a, b, moving: a.hash !== b.hash, playing, paused, afterSeek, closed,
    playheadKept: Math.abs(ctx.playhead() - playheadBeforeClose) < 0.05,
    timelineUnchanged: JSON.stringify(ctx.journey.state()) === before, rangeUnchanged: JSON.stringify(ctx.range()) === rangeBefore,
    embedded: canvasStats("xsPreviewCanvasCustom")
  });
  // Leave it open and playing for the screenshot.
  ctx.seek(t0);
  click("#xsTlPreviewBig");
  await settle(300);
  click("#xsBigPlay");
  await settle(2500);
}

// Audition the current committed settings; edits remain after dismissal.
async function checkAudition(ctx) {
  const marker = sortedMarkers(ctx)[0];
  if (!marker) throw Error("No transition to audition");
  ctx.journey.openSegCard(marker.id, {options:true});
  const field = document.querySelector('#xsCtxCard [data-field="trStyle"]');
  field.value = "smooth"; field.dispatchEvent(new Event("change",{bubbles:true}));
  const before = JSON.stringify(ctx.journey.state());
  click('#xsCtxCard [data-act="audition"]'); await settle(1800);
  const first = canvasStats("xsPreviewCanvasCustom"); await settle(1200);
  const second = canvasStats("xsPreviewCanvasCustom");
  ctx.journey.stopAudition(); click('#xsCtxCard [data-act="close"]');
  if (JSON.stringify(ctx.journey.state()) !== before) throw Error("Audition altered committed edits");
  log("audition", {retained:true,moving:first.hash!==second.hash});
}

async function checkReplay(ctx) {
  const { journey } = ctx;
  const markers = sortedMarkers(ctx);
  const marker = markers[1] || markers[0];
  const plan = ctx.journey.previewPlan().transitions.find((t) => t.id === marker.id);
  ctx.seek(Math.min(ctx.analysis().duration - 1, marker.time + 30));
  journey.zoomAround?.(marker.time, 60);
  await settle(300);
  const canvas = document.getElementById("xsTlMain");
  const rect = canvas.getBoundingClientRect();
  const total = ctx.analysis().duration;
  const viewStart = Math.max(0, Math.min(total - 60, marker.time - 30));
  const x = rect.left + ((marker.time - viewStart) / 60) * rect.width;
  canvas.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, clientX: x, clientY: rect.top + rect.height * 0.6 }));
  await settle(1200);
  const replay = { playing: !ctx.audio()?.paused, playheadMinusTrigger: +(ctx.playhead() - plan.triggerTime).toFixed(2), state: document.getElementById("xsPreviewStateTl").textContent };
  await settle(3000);
  const replay2 = { preset: document.getElementById("xsPreviewPresetTl").textContent, frame: canvasStats("xsPreviewCanvasCustom") };
  click("#xsTlPlay");
  await settle(600);
  // Edit the existing change immediately, audition it, then dismiss the editor.
  const before = JSON.stringify(journey.state());
  journey.openSegCard(marker.id, { options: true });
  await settle(200);
  const card = document.getElementById("xsCtxCard");
  const style = card.querySelector('[data-field="trStyle"]');
  style.value = marker.style === "smooth" ? "quick" : "smooth";
  style.dispatchEvent(new Event("change", { bubbles: true }));
  await settle(200);
  const immediateEdit = { noApplyButton: ![...card.querySelectorAll('button')].some(b => b.textContent === 'Apply'), timelineChanged: JSON.stringify(journey.state()) !== before };
  click(card.querySelector('[data-act="audition"]'));
  await settle(1800);
  const auditioning = { auditioning: journey.auditioning(), playing: !ctx.audio()?.paused };
  click(card.querySelector('[data-act="audition"]'));
  await settle(500);
  click(card.querySelector('[data-act="close"]'));
  await settle(300);
  const cancelled = JSON.stringify(journey.state()) === before;
  log("replay", { marker: marker.id, replay, replay2, immediateEdit, auditioning, retained: !cancelled });
  // Screenshot state: auditioning the committed change.
  journey.openSegCard(marker.id, { options: true });
  await settle(200);
  const s2 = document.getElementById("xsCtxCard").querySelector('[data-field="trStyle"]');
  s2.value = marker.style === "smooth" ? "quick" : "smooth";
  s2.dispatchEvent(new Event("change", { bubbles: true }));
  await settle(150);
  click(document.getElementById("xsCtxCard").querySelector('[data-act="audition"]'));
  await settle(2600);
}
