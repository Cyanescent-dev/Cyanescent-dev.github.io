import { capabilityEnabled } from "../config/runtimeCapabilities.js";
import { USER_TRANSITION_MODES, USER_TRANSITIONS_CHANGED_EVENT } from "../engine/videoAssets.js";
import { requestMusicPlaylistAction } from "./musicPlaylistDialog.js";

// Pro Video only. Native owns the files (import, conversion, removal);
// this module drives the library through the app bridge and renders it.
export { USER_TRANSITIONS_CHANGED_EVENT };
const WINDOW_SECONDS = 10;
const LONG_SOURCE_SECONDS = WINDOW_SECONDS + 0.05;

function nativeBridge(target = window) {
  const handler = target?.webkit?.messageHandlers?.nativeApp;
  return typeof handler?.postMessage === "function" ? handler : null;
}

export function createUserTransitionBridge(target = window) {
  const pending = new Map();
  let nextRequest = 1;
  target.__userTransitionResponse = (response) => {
    const resolve = pending.get(response?.requestId);
    if (!resolve) return;
    pending.delete(response.requestId);
    resolve(response);
  };
  return {
    available: () => Boolean(nativeBridge(target)),
    request(action, details = {}) {
      const bridge = nativeBridge(target);
      if (!bridge) return Promise.resolve({ error: "My Transitions needs the Cyanescent Player Pro Video app." });
      const requestId = `user-transition-${Date.now()}-${nextRequest++}`;
      return new Promise((resolve) => {
        pending.set(requestId, resolve);
        bridge.postMessage({ command: "userTransitionRequest", requestId, action, ...details });
      });
    }
  };
}

export function formatTransitionSeconds(value) {
  const seconds = Math.floor((Number(value) || 0) * 10) / 10;
  return `${seconds < 10 ? seconds.toFixed(1) : Math.floor(seconds)} s`;
}

const CODEC_NAMES = { h264: "H.264", hevc: "HEVC", prores: "ProRes" };

export function describeUserTransition(entry) {
  const parts = [formatTransitionSeconds(entry.sourceDurationSeconds)];
  if (entry.sourceDurationSeconds > LONG_SOURCE_SECONDS) parts.push("first 10 s used");
  if (entry.processing === "converted") parts.push(`converted from ${CODEC_NAMES[entry.sourceCodec] || "source"} to H.264`);
  else if (entry.codec) parts.push(CODEC_NAMES[entry.codec] || entry.codec);
  if (entry.width && entry.height) parts.push(`${entry.width}×${entry.height}`);
  return parts.join(" · ");
}

function unavailableReason(entry) {
  if (entry.status === "missing") return "The stored copy of this video is missing. Remove it and import it again.";
  if (entry.status === "modified") return "The stored copy of this video was changed outside Cyanescent Player. Remove it and import it again.";
  return "";
}

export function initializeMyTransitions({
  ui = {},
  assetManager,
  getOptions,
  documentRef = document,
  target = window
} = {}) {
  const root = documentRef.getElementById("myTransitions");
  if (!root || !assetManager || !capabilityEnabled("videoTransitions")) return null;
  const $ = (id) => documentRef.getElementById(id);
  const elements = {
    importButton: $("myTransitionsImport"),
    status: $("myTransitionsStatus"),
    statusLines: $("myTransitionsStatusLines"),
    progress: $("myTransitionsProgress"),
    cancel: $("myTransitionsCancel"),
    dismiss: $("myTransitionsDismiss"),
    list: $("myTransitionsList"),
    empty: $("myTransitionsEmpty"),
    modeHint: $("myTransitionsModeHint")
  };
  const bridge = createUserTransitionBridge(target);
  let importing = false;
  let statusLines = [];
  root.hidden = false;

  function setStatus({ lines = statusLines, progress = null, busy = importing } = {}) {
    statusLines = lines.slice(-4);
    elements.status.classList.toggle("hidden", statusLines.length === 0 && !busy);
    elements.statusLines.replaceChildren(...statusLines.map(({ kind, text }) => {
      const line = documentRef.createElement("p");
      line.className = `my-transitions-line is-${kind}`;
      line.textContent = text;
      return line;
    }));
    elements.progress.classList.toggle("hidden", progress === null);
    if (progress !== null) elements.progress.value = Math.max(0, Math.min(1, progress));
    elements.cancel.classList.toggle("hidden", !busy);
    elements.dismiss.classList.toggle("hidden", busy || statusLines.length === 0);
    elements.importButton.disabled = busy;
    elements.list.querySelectorAll("button[data-act='remove'], input[data-act='use']").forEach((control) => { control.disabled = busy; });
  }

  function addLine(kind, text) {
    setStatus({ lines: [...statusLines, { kind, text }] });
  }

  function publishRevision() {
    const options = getOptions?.();
    // Session-only: carried to the detached output, never persisted.
    if (options) options.userTransitionsRevision = assetManager.userTransitionsRevision?.() || "";
    target.dispatchEvent?.(new CustomEvent(USER_TRANSITIONS_CHANGED_EVENT));
  }

  async function refresh() {
    await assetManager.refreshUserTransitions?.();
    publishRevision();
  }

  function render(entries = assetManager.userTransitions?.() || []) {
    elements.empty.classList.toggle("hidden", entries.length > 0);
    const mode = getOptions?.()?.videoTransitionMode || "auto";
    elements.modeHint.classList.toggle("hidden", !entries.length || USER_TRANSITION_MODES.includes(mode));
    elements.list.replaceChildren(...entries.map((entry) => {
      const item = documentRef.createElement("li");
      item.className = "my-transition-item";
      item.classList.toggle("is-unavailable", !entry.available);
      item.dataset.id = entry.libraryId;

      const preview = documentRef.createElement("button");
      preview.type = "button";
      preview.className = "my-transition-thumb";
      preview.dataset.act = "preview";
      preview.disabled = !entry.available;
      preview.setAttribute("aria-label", `Preview ${entry.label}`);
      preview.title = entry.available ? "Preview the first 10 seconds" : unavailableReason(entry);
      if (entry.thumbnail && entry.available) {
        const image = documentRef.createElement("img");
        image.alt = "";
        image.loading = "lazy";
        image.src = entry.thumbnail;
        preview.append(image);
      }
      const play = documentRef.createElement("span");
      play.className = "my-transition-play";
      play.setAttribute("aria-hidden", "true");
      play.textContent = entry.available ? "▶" : "!";
      preview.append(play);

      const meta = documentRef.createElement("div");
      meta.className = "my-transition-meta";
      const name = documentRef.createElement("strong");
      name.textContent = entry.label;
      name.title = entry.label;
      const details = documentRef.createElement("span");
      details.textContent = entry.available ? describeUserTransition(entry) : unavailableReason(entry);
      meta.append(name, details);

      const use = documentRef.createElement("label");
      use.className = "my-transition-use";
      use.title = "Include this clip when Video Transition Mode uses My Transitions";
      const checkbox = documentRef.createElement("input");
      checkbox.type = "checkbox";
      checkbox.dataset.act = "use";
      checkbox.checked = entry.enabled;
      checkbox.disabled = importing || !entry.available;
      use.append(checkbox, documentRef.createTextNode("Use"));

      const remove = documentRef.createElement("button");
      remove.type = "button";
      remove.className = "my-transition-remove";
      remove.dataset.act = "remove";
      remove.disabled = importing;
      remove.textContent = "Remove";
      remove.setAttribute("aria-label", `Remove ${entry.label}`);

      item.append(preview, meta, use, remove);
      return item;
    }));
  }

  function entryFor(element) {
    const id = element.closest(".my-transition-item")?.dataset.id;
    return (assetManager.userTransitions?.() || []).find((entry) => entry.libraryId === id) || null;
  }

  function openPreview(entry) {
    const dialog = documentRef.createElement("dialog");
    dialog.className = "music-playlist-dialog my-transition-preview";
    dialog.setAttribute("aria-label", `Preview ${entry.label}`);
    const heading = documentRef.createElement("h3");
    heading.textContent = entry.label;
    const frame = documentRef.createElement("div");
    frame.className = "my-transition-preview-frame";
    const video = documentRef.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";
    video.src = entry.resolvedPath;
    frame.append(video);
    const note = documentRef.createElement("p");
    note.className = "transition-hint";
    note.textContent = entry.sourceDurationSeconds > LONG_SOURCE_SECONDS
      ? `Plays muted. This video is ${formatTransitionSeconds(entry.sourceDurationSeconds)} long; only its first 10 seconds appear during transitions.`
      : "Plays muted, exactly as it appears during transitions (edges may be cropped to fill the screen).";
    const actions = documentRef.createElement("div");
    actions.className = "music-playlist-actions";
    const replay = documentRef.createElement("button");
    replay.type = "button";
    replay.textContent = "Replay";
    const close = documentRef.createElement("button");
    close.type = "button";
    close.className = "primary";
    close.textContent = "Close";
    actions.append(replay, close);
    dialog.append(heading, frame, note, actions);
    const restart = () => {
      try { video.currentTime = 0; } catch {}
      video.play().catch(() => {});
    };
    // The preview never shows more than the transition window.
    video.addEventListener("timeupdate", () => {
      if (video.currentTime >= WINDOW_SECONDS) video.pause();
    });
    video.addEventListener("error", () => {
      note.textContent = "This video could not be played. Remove it and import it again.";
    });
    replay.addEventListener("click", restart);
    close.addEventListener("click", () => dialog.close());
    dialog.addEventListener("close", () => {
      video.pause();
      video.removeAttribute("src");
      video.load?.();
      dialog.remove();
    }, { once: true });
    documentRef.body.append(dialog);
    dialog.showModal();
    restart();
  }

  async function removeEntry(entry) {
    const confirmed = await requestMusicPlaylistAction({
      title: `Remove “${entry.label}”?`,
      message: "It will be removed from My Transitions and its stored copy deleted. Your original video file is not affected.",
      confirmLabel: "Remove"
    });
    if (!confirmed) return;
    const response = await bridge.request("remove", { id: entry.libraryId });
    if (response.error) addLine("error", response.error);
    else setStatus({ lines: [{ kind: "success", text: `Removed “${entry.label}”.` }] });
    await refresh();
  }

  async function setEnabled(entry, enabled) {
    const response = await bridge.request("setEnabled", { id: entry.libraryId, enabled });
    if (response.error) addLine("error", response.error);
    await refresh();
  }

  async function startImport() {
    if (importing) return;
    const response = await bridge.request("import");
    if (response.cancelled) return;
    if (response.error) {
      setStatus({ lines: [{ kind: "error", text: response.error }] });
      return;
    }
    importing = true;
    setStatus({ lines: [], busy: true });
  }

  // Native import events: progress, imported, duplicate, failed, cancelled, finished, changed.
  target.__userTransitionEvent = (event = {}) => {
    const count = Number(event.count) || 1;
    const prefix = count > 1 ? `${(Number(event.index) || 0) + 1} of ${count}: ` : "";
    switch (event.type) {
      case "progress": {
        const done = statusLines.filter((line) => line.kind !== "busy");
        setStatus({ lines: [...done, { kind: "busy", text: prefix + event.message }], progress: Number.isFinite(event.fraction) ? event.fraction : null, busy: true });
        break;
      }
      case "imported":
      case "duplicate": {
        const done = statusLines.filter((line) => line.kind !== "busy");
        let text;
        if (event.type === "duplicate") text = `“${event.name}” is already in My Transitions.`;
        else if (Number(event.sourceDurationSeconds) > LONG_SOURCE_SECONDS) text = `Added “${event.name}”. It is ${formatTransitionSeconds(event.sourceDurationSeconds)} long, so only its first 10 seconds will appear during transitions.`;
        else text = `Added “${event.name}”.`;
        if (event.type === "imported" && event.processing === "converted") text += ` Converted from ${CODEC_NAMES[event.sourceCodec] || "its original format"} to H.264 for playback.`;
        setStatus({ lines: [...done, { kind: event.type === "duplicate" ? "info" : (Number(event.sourceDurationSeconds) > LONG_SOURCE_SECONDS ? "info" : "success"), text: prefix + text }], busy: true });
        void refresh();
        break;
      }
      case "failed":
      case "cancelled": {
        const done = statusLines.filter((line) => line.kind !== "busy");
        const name = event.fileName ? `${event.fileName}: ` : "";
        setStatus({ lines: [...done, { kind: event.type === "failed" ? "error" : "info", text: prefix + (event.type === "failed" ? name : "") + event.error }], busy: true });
        break;
      }
      case "finished":
        importing = false;
        setStatus({ lines: statusLines.filter((line) => line.kind !== "busy"), busy: false });
        void refresh();
        break;
      case "changed":
        void refresh();
        break;
      default:
        break;
    }
  };

  elements.importButton.addEventListener("click", () => { void startImport(); });
  elements.cancel.addEventListener("click", () => { void bridge.request("cancelImport"); });
  elements.dismiss.addEventListener("click", () => setStatus({ lines: [] }));
  elements.list.addEventListener("click", (event) => {
    const button = event.target.closest?.("button[data-act]");
    if (!button) return;
    const entry = entryFor(button);
    if (!entry) return;
    if (button.dataset.act === "preview" && entry.available) openPreview(entry);
    if (button.dataset.act === "remove") void removeEntry(entry);
  });
  elements.list.addEventListener("change", (event) => {
    const input = event.target;
    if (input?.dataset?.act !== "use") return;
    const entry = entryFor(input);
    if (entry) void setEnabled(entry, input.checked);
  });
  ui.videoTransitionMode?.addEventListener("change", () => render());
  // Opening Options re-reads the library so files changed on disk show up.
  ui.optionsButton?.addEventListener("click", () => { void refresh(); });
  assetManager.onUserTransitionsChanged?.((entries) => render(entries));
  render();
  void refresh();

  return { refresh, render, isImporting: () => importing };
}
