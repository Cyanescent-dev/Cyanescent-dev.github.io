import { seekOfflineVideoFrame, offlineVideoPlaybackAt } from "./offlineVideoFrame.js";
import { createPresetCalibration } from "../ui/presetCalibration.js";
import { forgePlaybackTarget } from "./forgeHybridRuntime.js";
import { NEWTON_BASIN_DESCENT } from "./newtonBasinAsset.js";
import { createNewtonAudioModel } from "./newtonBasinAudio.js";
import {
  PLANE_ORDER, cameraAt, classifyTimeStep, createFieldStore, interpolateAnchors, locateSample, loopFade, morphAt,
  morphWeights, motionAt, parseAnchors, sampleTimes
} from "./newtonBasinField.js";
import { GLINT, GLINT_END_NAMES } from "./newtonBasinRules.js";
import {
  WAVE_UNIFORM_SLOTS, newtonCompositeSource, newtonDownsampleSource, newtonGlintDummyFragment, newtonGlintFragmentSource,
  newtonGlintUpdateSource, newtonGlintVertexSource, newtonPrepSource, newtonResolveSource
} from "./newtonBasinShaders.js";
import { WAVE_SLOTS, createWavePool, waveFront } from "./newtonBasinWaves.js";

const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const CAPACITY = 2048;
const MAX_ANCHOR_UNIFORMS = 16;
const SMALL_WIDTH = 240, SMALL_HEIGHT = 135;
const LOG_PREFIX = "[NewtonBasin]";

if (WAVE_SLOTS !== WAVE_UNIFORM_SLOTS) throw new Error("Newton wave pool and shader disagree on the number of waves");

// The preset draws the beauty video itself (a WebGL texture of the playing <video>), so the
// music can grade, light and refract the Forge frame, and every reactive mark is composed in the
// same frame as the pixels it belongs to. The <video> element stays in the page underneath as the
// decoder; if the GPU path is unavailable it is simply what the viewer sees.
export function createNewtonBasinRuntime({ getGl, program, programFrom, setAttribs, asset = NEWTON_BASIN_DESCENT }) {
  const controls = {
    reactive: 1.5, waves: 0.34, craters: 0.8, seams: 0.8, glints: 0.8, grade: 0.72,
    bpmLock: true, testBPM: 0, debug: 0
  };
  const calibration = createPresetCalibration({
    presetId: 392, presetName: "Newton Basin Descent V1", controls, buildPanel: makePanel,
    clearPanel: () => { panel = null; }
  });
  const audioModel = createNewtonAudioModel();
  const wavePool = createWavePool();
  let active = false, token = 0, video = null, videoCallback = 0, playingPending = false;
  let presentedTime = NaN, lastPresented = NaN, presentedFrames = 0, callbackSkips = 0, uploadedFrame = -1;
  let lastAt = 0, lastMediaTime = NaN, loops = 0, seeks = 0, lastLabelAt = 0;
  let targetRate = 1, tempoBPM = 0, tempoAbsent = 0, started = false, waitingForBar = true;
  let pkg = null, packageError = "", packageState = "idle", fatal = "";
  let store = null, times = null, anchorBytes = null;
  const anchorCache = new Map();
  let programs = null, targets = null, glints = null, videoTexture = null, videoTextureReady = false;
  let panel = null;
  const slotsTex = [{ index: -1, a: null, b: null }, { index: -1, a: null, b: null }];
  let transientDirty = true, clockSeconds = 0;
  let packageLoad = null, offlineFrame = null;
  let presence = 0, reportAt = 0, frames = 0, reportFrames = 0, fps = 0;
  let seekFixture = "", seekFixtureDone = false, startCostMs = 0;
  const cam0 = {}, cam1 = {}, camN = {};
  const morph = { balance: 0.6, coexist: 0, lawPhase: 1 };
  const uniformLocations = new WeakMap();
  const anchorA = new Float32Array(MAX_ANCHOR_UNIFORMS * 4);
  const anchorB = new Float32Array(MAX_ANCHOR_UNIFORMS * 4);
  const waveA = new Float32Array(WAVE_SLOTS * 4);
  const waveB = new Float32Array(WAVE_SLOTS * 4);
  const waveC = new Float32Array(WAVE_SLOTS * 4);
  const timings = { video: 0, resolve: 0, prep: 0, glints: 0, composite: 0, upload: 0, frames: 0, total: 0 };
  let dropBurst = 0;
  const analysisTrace = [];
  let lastMusic = null;
  let liveGlints = null, endHistogram = null, kindHistogram = null, glintRates = null;
  const diagnosticStates = new Float32Array(CAPACITY * 12);
  let readback = null;   // trial-only asynchronous glint readback (staging buffer + fence)
  let anchorList = [];
  let currentIndices = { i0: 0, i1: 0, mix: 0 };
  let attachRisk = 0;
  const glErrors = {};
  const trialMode = () => document.body.classList.contains("preset-trial-role");
  // Trial-only GL error capture. getError is a synchronous round trip to WebKit's GPU process,
  // so it runs on one frame in 120, never every pass of every frame.
  function checkGl(gl, stage) {
    if (!trialMode() || frames % 120 !== 0) return;
    const code = gl.getError();
    if (code) glErrors[stage] = `0x${code.toString(16)}`;
  }

  // ------------------------------------------------------------- GL helpers
  function loc(gl, shader, name) {
    let map = uniformLocations.get(shader);
    if (!map) { map = new Map(); uniformLocations.set(shader, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(shader, name));
    return map.get(name);
  }
  const u1 = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1f(l, v); };
  const u1i = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1i(l, v); };
  const u2 = (gl, s, n, a, b) => { const l = loc(gl, s, n); if (l !== null) gl.uniform2f(l, a, b); };
  const u3v = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform3f(l, v[0], v[1], v[2]); };
  const u4 = (gl, s, n, a, b, c, d) => { const l = loc(gl, s, n); if (l !== null) gl.uniform4f(l, a, b, c, d); };
  const u4v = (gl, s, n, array) => { const l = loc(gl, s, n); if (l !== null) gl.uniform4fv(l, array); };
  function tex(gl, s, name, unit, texture) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    const l = loc(gl, s, name);
    if (l !== null) gl.uniform1i(l, unit);
  }
  function setCamera(gl, s, suffix, cam) {
    u3v(gl, s, `uPos${suffix}`, cam.position); u3v(gl, s, `uFwd${suffix}`, cam.forward);
    u3v(gl, s, `uRight${suffix}`, cam.right); u3v(gl, s, `uUp${suffix}`, cam.up);
    u1(gl, s, `uTan${suffix}`, cam.tanHalfFov);
  }
  function setCommon(gl, s) {
    u2(gl, s, "uSize", pkg ? pkg.fields.width : asset.fieldWidth, pkg ? pkg.fields.height : asset.fieldHeight);
    if (!pkg) return;
    u1(gl, s, "uMaxDist", pkg.encoding.boundary.maxTexels);
    u1(gl, s, "uAspect", pkg.camera.aspect);
    u1(gl, s, "uBudget", pkg.encoding.iteration.budget);
    u2(gl, s, "uRhoRange", pkg.encoding.domain.radius.min, pkg.encoding.domain.radius.max);
  }
  function makeTexture(gl, width, height, { internal = gl.RGBA8, format = gl.RGBA, type = gl.UNSIGNED_BYTE, filter = gl.NEAREST } = {}) {
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, width, height, 0, format, type, null);
    return texture;
  }
  function framebufferFor(gl, textures) {
    const fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    textures.forEach((texture, i) => gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0 + i, gl.TEXTURE_2D, texture, 0));
    gl.drawBuffers(textures.map((_, i) => gl.COLOR_ATTACHMENT0 + i));
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error("Newton framebuffer is incomplete");
    return fbo;
  }
  function compileShader(gl, type, source, label) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const log = gl.getShaderInfoLog(shader);
      gl.deleteShader(shader);
      throw new Error(`${label}: ${log}`);
    }
    return shader;
  }
  function makeFeedbackProgram(gl) {
    const vertex = compileShader(gl, gl.VERTEX_SHADER, newtonGlintUpdateSource, "Newton glint update");
    const fragment = compileShader(gl, gl.FRAGMENT_SHADER, newtonGlintDummyFragment, "Newton glint update fragment");
    const result = gl.createProgram();
    gl.attachShader(result, vertex); gl.attachShader(result, fragment);
    for (let i = 0; i < 3; i += 1) gl.bindAttribLocation(result, i, `aState${i}`);
    gl.transformFeedbackVaryings(result, ["vState0", "vState1", "vState2"], gl.INTERLEAVED_ATTRIBS);
    gl.linkProgram(result);
    gl.deleteShader(vertex); gl.deleteShader(fragment);
    if (!gl.getProgramParameter(result, gl.LINK_STATUS)) {
      const reason = gl.getProgramInfoLog(result);
      gl.deleteProgram(result);
      throw new Error(`Newton glint update link: ${reason}`);
    }
    return result;
  }
  function fullscreen(gl, prog) { gl.useProgram(prog); setAttribs(prog); gl.drawArrays(gl.TRIANGLES, 0, 3); }

  // ------------------------------------------------------------------ panel
  function makePanel() {
    panel = document.createElement("details");
    panel.className = "forge-hybrid-controls";
    panel.innerHTML = `<summary>Newton Basin controls</summary>
      <label>Reactive amount <input type="range" data-key="reactive" min="0" max="1.5" step="0.01"></label>
      <label>Ripple waves <input type="range" data-key="waves" min="0" max="1.5" step="0.01"></label>
      <label>Crater glow <input type="range" data-key="craters" min="0" max="1.5" step="0.01"></label>
      <label>Seam shimmer <input type="range" data-key="seams" min="0" max="1.5" step="0.01"></label>
      <label>Glints <input type="range" data-key="glints" min="0" max="1.5" step="0.01"></label>
      <label>Grade and bloom <input type="range" data-key="grade" min="0" max="1.5" step="0.01"></label>
      <label>BPM lock <input type="checkbox" data-key="bpmLock"></label>
      <label>Test BPM <select data-key="testBPM"><option value="0">Track</option><option value="140">140</option><option value="145">145</option><option value="150">150</option></select></label>
      <label>Field view <select data-key="debug"><option value="0">Beauty</option><option value="1">Basin ID</option><option value="2">Boundary distance</option><option value="3">Flow</option><option value="4">Iteration</option><option value="5">Depth</option><option value="6">Anchors</option><option value="7">Domain radius / angle</option><option value="8">Glints only</option><option value="9">Surface mask</option><option value="10">Glint attachment</option><option value="11">Reactive light only</option><option value="12">Waves</option></select></label>`;
    for (const input of panel.querySelectorAll("[data-key]")) {
      const key = input.dataset.key;
      if (input.type === "checkbox") input.checked = controls[key]; else input.value = String(controls[key]);
      input.addEventListener("input", () => { controls[key] = input.type === "checkbox" ? input.checked : Number(input.value); });
    }
    document.body.appendChild(panel);
    return panel;
  }

  // ---------------------------------------------------------------- package
  async function fetchJson(name) {
    const response = await fetch(`${asset.assetRoot}/${name}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`${name}: HTTP ${response.status}`);
    return response.json();
  }
  async function fetchBytes(url) {
    const response = await fetch(url, { cache: "no-store" });
    if (!response.ok) throw new Error(`${url}: HTTP ${response.status}`);
    return new Uint8Array(await response.arrayBuffer());
  }
  async function loadPackage(generation) {
    packageState = "loading";
    try {
      const manifest = await fetchJson(asset.manifest);
      if (manifest.schema !== asset.schema || manifest.version !== asset.packageVersion) {
        throw new Error(`unrecognised runtime package (${manifest.schema} v${manifest.version}; this build reads v${asset.packageVersion}, recompile with scripts/compile-newton-basin-runtime.mjs)`);
      }
      if (manifest.fields.width !== asset.fieldWidth || manifest.fields.height !== asset.fieldHeight
          || manifest.fields.sampleCount !== asset.sampleCount || manifest.fields.rateHz !== asset.fieldRateHz) {
        throw new Error("runtime.json disagrees with newtonBasinAsset.js (recompile the package or update the descriptor)");
      }
      if (manifest.fields.planes.join() !== PLANE_ORDER.join()) throw new Error("runtime.json plane layout differs from this build");
      const iteration = manifest.encoding.iteration;
      if (iteration.knee !== 48 || iteration.kneeByte !== 192) throw new Error("iteration encoding differs from the shader constants");
      if (typeof DecompressionStream !== "function" && manifest.fields.codec === "deflate") throw new Error("this WebKit has no DecompressionStream; recompile with --codec none");
      const [timeline, anchors] = await Promise.all([fetchJson(manifest.files.timeline), fetchBytes(`${asset.assetRoot}/${manifest.files.anchors}`)]);
      if (generation !== token) return;
      manifest.timelineData = timeline;
      pkg = manifest;
      times = sampleTimes(manifest);
      anchorBytes = anchors;
      store = createFieldStore({
        runtime: manifest, fetchBytes, urlFor: (name) => `${asset.assetRoot}/${name}`,
        now: () => performance.now(), behind: 3, ahead: 28
      });
      packageState = "ready";
    } catch (error) {
      if (generation !== token) return;
      packageError = String(error?.message || error);
      packageState = "failed";
      console.warn(`${LOG_PREFIX} runtime field package unavailable; showing the beauty video without reactive graphics.`, packageError);
    }
  }

  // ------------------------------------------------------------- lifecycle
  function start() {
    if (active) return;
    const startedAt = performance.now();
    active = true; token += 1;
    presentedTime = NaN; lastPresented = NaN; presentedFrames = callbackSkips = 0; uploadedFrame = -1; videoTextureReady = false;
    lastAt = null; lastMediaTime = NaN; loops = seeks = 0; started = false; waitingForBar = true;
    presence = 0; frames = 0; transientDirty = true; clockSeconds = 0; attachRisk = 0; dropBurst = 0;
    pkg = null; store = null; times = null; anchorBytes = null; anchorCache.clear();
    packageError = ""; packageState = "idle"; fatal = "";
    targetRate = 1; tempoBPM = 0; tempoAbsent = 0;
    audioModel.reset(); wavePool.clear();
    for (const key of Object.keys(timings)) timings[key] = 0;
    video = document.createElement("video");
    video.muted = true; video.playsInline = true; video.loop = true; video.preload = "auto";
    video.className = "forge-hybrid-video";
    document.body.appendChild(video);
    window.__newtonBasinVideo = video;
    video.src = encodeURI(`${asset.assetRoot}/${asset.video}`);
    video.load();
    if (video.requestVideoFrameCallback) {
      const generation = token;
      const callback = (_now, info) => {
        if (!active || generation !== token || !video) return;
        if (Number.isFinite(info.mediaTime)) {
          if (Number.isFinite(lastPresented) && info.mediaTime > lastPresented + 1.5 / asset.videoFps && info.mediaTime - lastPresented < 0.5) callbackSkips += 1;
          lastPresented = info.mediaTime;
          presentedTime = info.mediaTime;
          presentedFrames += 1;
        }
        videoCallback = video.requestVideoFrameCallback(callback);
      };
      videoCallback = video.requestVideoFrameCallback(callback);
    }
    const gl = getGl();
    const floatExtension = gl.getExtension("EXT_color_buffer_float") || gl.getExtension("EXT_color_buffer_half_float");
    if (!floatExtension) fatal = "float render targets are unavailable";
    else {
      try { buildGpuResources(gl); }
      catch (error) { fatal = String(error?.message || error); console.error(`${LOG_PREFIX} GPU setup failed:`, error); }
    }
    window.__newtonBasinControls = controls;
    calibration.start();
    const fixture = new URLSearchParams(window.location.search).get("fixture") || "";
    const debugFixtures = {
      "newton-align": 1, "newton-boundary": 2, "newton-flow": 3, "newton-iteration": 4, "newton-depth": 5, "newton-anchors": 6,
      "newton-domain": 7, "newton-particles": 8, "newton-hit": 9, "newton-attach": 10, "newton-emission": 11, "newton-waves": 12
    };
    if (debugFixtures[fixture]) controls.debug = debugFixtures[fixture];
    if (fixture === "newton-off") controls.reactive = 0;
    // Views of the basin network, flow and domain need the Newton phase, so they start there.
    const newtonPhaseViews = ["newton-boundary", "newton-flow", "newton-particles", "newton-depth", "newton-domain", "newton-attach", "newton-emission", "newton-waves"];
    seekFixture = fixture === "newton-loop" ? fixture : fixture === "newton-seek" || fixture === "newton-off" || newtonPhaseViews.includes(fixture) ? "newton-seek" : "";
    seekFixtureDone = false;
    packageLoad = loadPackage(token);
    startCostMs = performance.now() - startedAt;
  }

  function buildGpuResources(gl) {
    const width = asset.fieldWidth, height = asset.fieldHeight;
    programs = {
      down: program(newtonDownsampleSource),
      resolve: program(newtonResolveSource),
      prep: program(newtonPrepSource),
      composite: program(newtonCompositeSource),
      update: makeFeedbackProgram(gl),
      draw: programFrom(newtonGlintVertexSource, newtonGlintFragmentSource, [[0, "aState0"], [1, "aState1"], [2, "aState2"]])
    };
    for (const name of ["down", "resolve", "prep", "composite", "draw"]) if (!programs[name]) throw new Error(`Newton ${name} program did not compile`);
    videoTexture = makeTexture(gl, 2, 2, { filter: gl.LINEAR });
    const half = { internal: gl.RGBA16F, format: gl.RGBA, type: gl.HALF_FLOAT };
    for (const slot of slotsTex) {
      slot.index = -1;
      slot.a = makeTexture(gl, width, height);
      slot.b = makeTexture(gl, width, height);
    }
    const resolved = [0, 1, 2].map(() => makeTexture(gl, width, height, { ...half, filter: gl.LINEAR }));
    const prepS = makeTexture(gl, width, height, { ...half, filter: gl.LINEAR });
    const small = makeTexture(gl, SMALL_WIDTH, SMALL_HEIGHT, { filter: gl.LINEAR });
    targets = {
      resolved, resolveFbo: framebufferFor(gl, resolved),
      prepS, prepSFbo: framebufferFor(gl, [prepS]),
      small, smallFbo: framebufferFor(gl, [small])
    };
    for (const fbo of [targets.resolveFbo, targets.prepSFbo, targets.smallFbo]) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    // Glint state, 12 floats each: (world position, age) (life, seed, kind, amplitude) (fuv, visibility, end reason).
    const initial = blankGlints();
    glints = { buffers: [], vaos: [], feedback: gl.createTransformFeedback(), read: 0 };
    for (let i = 0; i < 2; i += 1) {
      const buffer = gl.createBuffer();
      glints.buffers.push(buffer);
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, i === 0 ? initial : initial.byteLength, gl.DYNAMIC_COPY);
      const vao = gl.createVertexArray();
      glints.vaos.push(vao);
      gl.bindVertexArray(vao);
      for (let attribute = 0; attribute < 3; attribute += 1) {
        gl.enableVertexAttribArray(attribute);
        gl.vertexAttribPointer(attribute, 4, gl.FLOAT, false, 48, attribute * 16);
      }
    }
    gl.bindVertexArray(null);
    gl.bindBuffer(gl.ARRAY_BUFFER, null);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  function blankGlints() {
    const blank = new Float32Array(CAPACITY * 12);
    for (let i = 0; i < CAPACITY; i += 1) blank[i * 12 + 3] = -1;   // age -1, life 0: dead
    return blank;
  }

  function clearTransient(gl) {
    wavePool.clear();
    if (glints) {
      gl.bindBuffer(gl.ARRAY_BUFFER, glints.buffers[glints.read]);
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, blankGlints());
      gl.bindBuffer(gl.ARRAY_BUFFER, null);
    }
    transientDirty = false;
  }

  function stop() {
    if (!active) return;
    active = false; token += 1; offlineFrame = null;
    if (video) {
      if (videoCallback && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(videoCallback);
      video.pause(); video.removeAttribute("src"); video.load(); video.remove(); video = null;
    }
    window.__newtonBasinVideo = null; window.__newtonBasinDiagnostics = null; window.__newtonBasinControls = null;
    store?.dispose();
    const gl = getGl();
    if (gl) {
      for (const slot of slotsTex) for (const key of ["a", "b"]) if (slot[key]) { gl.deleteTexture(slot[key]); slot[key] = null; }
      if (videoTexture) gl.deleteTexture(videoTexture);
      if (targets) {
        for (const texture of [...targets.resolved, targets.prepS, targets.small]) gl.deleteTexture(texture);
        for (const fbo of [targets.resolveFbo, targets.prepSFbo, targets.smallFbo]) gl.deleteFramebuffer(fbo);
      }
      if (glints) {
        glints.buffers.forEach((buffer) => gl.deleteBuffer(buffer));
        glints.vaos.forEach((vao) => gl.deleteVertexArray(vao));
        if (glints.feedback) gl.deleteTransformFeedback(glints.feedback);
      }
      if (programs) for (const shader of Object.values(programs)) if (shader) gl.deleteProgram(shader);
      if (readback) { if (readback.sync) gl.deleteSync(readback.sync); gl.deleteBuffer(readback.buffer); }
    }
    readback = null;
    programs = targets = glints = videoTexture = null;
    store = null; pkg = null; times = null; anchorBytes = null; anchorCache.clear();
    calibration.stop(); panel = null;
  }

  // ------------------------------------------------------------------ clock
  function updateTempo(tempo, dt) {
    const measured = controls.testBPM > 0 ? { bpm: controls.testBPM, confidence: 1 } : tempo || {};
    const bpm = Number(measured.bpm) || 0;
    const confidence = Number(measured.confidence ?? 1);
    if (!controls.bpmLock) { targetRate = 1; tempoBPM = 0; tempoAbsent = 0; }
    else if (bpm >= 70 && bpm <= 220 && confidence >= 0.35) {
      tempoAbsent = 0;
      if (!tempoBPM || Math.abs(bpm - tempoBPM) >= 0.8) {
        tempoBPM = bpm;
        targetRate = forgePlaybackTarget({ bpm, confidence }, pkg?.tempo.referenceBPM || asset.referenceBPM);
      }
    } else if ((tempoAbsent += dt) > 5) { targetRate = 1; tempoBPM = 0; }
    if (video) {
      const next = video.playbackRate + clamp(targetRate - video.playbackRate, -dt * 0.14, dt * 0.14);
      if (Math.abs(next - video.playbackRate) > 0.0002) video.playbackRate = next;
    }
  }

  // Beats per second of the music: the tracked tempo when it is trustworthy, otherwise the
  // Forge video's own 145 BPM at its current playback rate (which follows the music anyway).
  function beatsPerSecond(tempo) {
    const bpm = controls.testBPM > 0 ? controls.testBPM : Number(tempo?.bpm) || 0;
    const confidence = controls.testBPM > 0 ? 1 : Number(tempo?.confidence ?? 1);
    if (bpm >= 70 && bpm <= 220 && confidence >= 0.35) return bpm / 60;
    return (pkg?.tempo.referenceBPM || asset.referenceBPM) * (video?.playbackRate || 1) / 60;
  }

  // ---------------------------------------------------------------- samples
  function anchorsFor(index) {
    let list = anchorCache.get(index);
    if (!list) {
      list = anchorBytes ? parseAnchors(anchorBytes, index) : [];
      anchorCache.set(index, list);
      if (anchorCache.size > 96) anchorCache.delete(anchorCache.keys().next().value);
    }
    return list;
  }

  function uploadSample(gl, slot, index, entry) {
    const started = performance.now();
    const { width, height } = pkg.fields;
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, slot.a);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, entry.a);
    gl.bindTexture(gl.TEXTURE_2D, slot.b);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, entry.b);
    slot.index = index;
    timings.upload += performance.now() - started;
  }

  // Bind the two neighbouring samples to texture slots, uploading only new ones.
  function bindSamples(gl, i0, i1, e0, e1) {
    const need = [[i0, e0], [i1, e1]];
    const map = [null, null];
    for (let k = 0; k < 2; k += 1) {
      const [index] = need[k];
      const found = slotsTex.find((slot) => slot.index === index);
      if (found) map[k] = found;
    }
    for (let k = 0; k < 2; k += 1) {
      if (map[k]) continue;
      if (k === 1 && need[1][0] === need[0][0]) { map[1] = map[0]; continue; }
      const [index, entry] = need[k];
      const free = slotsTex.find((slot) => slot !== map[0] && slot !== map[1] && slot.index !== need[1 - k][0]) || slotsTex.find((slot) => slot !== map[1 - k]);
      uploadSample(gl, free, index, entry);
      map[k] = free;
    }
    return map;
  }

  // The playing frame -> a texture (the accelerated path: unsized RGBA, no flip; rows are top
  // first like the fields), and its small, box-filtered copy.
  function uploadVideo(gl, videoReady, exporting) {
    if (!videoReady || !programs) return;
    const fresh = exporting || !video.requestVideoFrameCallback || presentedFrames !== uploadedFrame || !videoTextureReady;
    if (!fresh) return;
    const stamp = performance.now();
    try {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, videoTexture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
      uploadedFrame = presentedFrames;
      videoTextureReady = true;
      if (offlineFrame) offlineFrame.textureUploaded = true;
    } catch (error) { if (frames < 400) console.warn(`${LOG_PREFIX} video texture:`, error); return; }
    gl.bindFramebuffer(gl.FRAMEBUFFER, targets.smallFbo);
    gl.viewport(0, 0, SMALL_WIDTH, SMALL_HEIGHT);
    gl.useProgram(programs.down);
    tex(gl, programs.down, "uVideo", 0, videoTexture);
    u2(gl, programs.down, "uSmallSize", SMALL_WIDTH, SMALL_HEIGHT);
    fullscreen(gl, programs.down);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    timings.video += performance.now() - stamp;
  }

  // ------------------------------------------------------------------ render
  function render({ target, width, height, now, tempo, playing = true, music, audio, smooth }) {
    if (!active) start();
    const gl = getGl();
    const dt = lastAt !== null ? clamp((now - lastAt) / 1000, 0, 0.05) : 1 / 60;
    lastAt = now;
    const videoReady = video.readyState >= 2 && video.videoWidth === asset.videoWidth && video.videoHeight === asset.videoHeight;
    const exporting = document.body.classList.contains("exporting-video");
    const glVideo = Boolean(programs && targets && !fatal);
    video.style.display = exporting ? "none" : "block";
    if (!offlineFrame) updateTempo(tempo, dt);
    if (offlineFrame && !video.paused) video.pause();
    if (!playing && !video.paused) video.pause();
    if (!offlineFrame && playing && videoReady && video.paused && !playingPending) {
      const beat = Number(music?.absoluteBeat);
      const canAlign = controls.bpmLock && tempo?.bpm > 0 && Number.isFinite(beat) && beat >= 0;
      const beatsPerBar = pkg?.tempo.beatsPerBar || 4;
      const phase = canAlign ? ((beat % beatsPerBar) + beatsPerBar) % beatsPerBar : 0;
      if (started || !canAlign || !waitingForBar || phase < 0.12 || phase > beatsPerBar - 0.10) {
        started = true; waitingForBar = false; playingPending = true;
        video.play().catch((error) => { if (frames < 400) console.warn(`${LOG_PREFIX} video playback:`, error); })
          .finally(() => { playingPending = false; });
      }
    }
    if (videoReady && seekFixture && !seekFixtureDone) {
      // Development fixtures: jump the real video near the end (loop) or into the middle (seek).
      video.currentTime = seekFixture === "newton-loop" ? Math.max(0, asset.durationSeconds - 3) : asset.durationSeconds * 0.45;
      seekFixtureDone = true;
    }
    const mediaTime = offlineFrame?.mediaTime ?? (Number.isFinite(presentedTime) ? presentedTime : (video.currentTime || 0));
    const step = classifyTimeStep(lastMediaTime, mediaTime, asset.durationSeconds, dt, video.playbackRate || 1);
    if (step === "loop") loops += 1;
    if (step === "loop" || step === "seek") { seeks += step === "seek" ? 1 : 0; transientDirty = true; }
    lastMediaTime = mediaTime;
    frames += 1;
    const started0 = performance.now();

    // The music model steps every frame regardless of field availability.
    const bps = beatsPerSecond(tempo);
    lastMusic = music;
    if (trialMode()) {
      analysisTrace.push([+(audio?.bassNow ?? -1).toFixed(3), +(audio?.bassFast ?? -1).toFixed(3), +(audio?.bassSlow ?? -1).toFixed(3), +(audio?.kickPulse ?? -1).toFixed(3), +(smooth?.bass ?? -1).toFixed(3), +(audio?.trebleNow ?? -1).toFixed(3), +(audio?.trebleRel ?? -1).toFixed(2), +(audio?.globalEnergy ?? -1).toFixed(3), +(Number(music?.absoluteBeat) || 0).toFixed(2)]);
      if (analysisTrace.length > 40) analysisTrace.shift();
    }
    const events = audioModel.step(playing ? dt : 0, { audio, smooth, music }, { reactive: controls.reactive, beatsPerSecond: bps });
    const audioState = audioModel.state;
    if (playing) {
      for (const wave of events.waves) wavePool.spawn(wave, { beatsPerSecond: bps, bassDrive: audioState.bassDrive });
      if (events.drop) dropBurst = 420;
    }
    wavePool.step(playing ? dt : 0);

    if (!glVideo) {
      // No GPU path: leave the canvas transparent and let the <video> element show through.
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, width, height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      report(gl, { now, mediaTime, videoReady, fieldReady: false, playing, glVideo });
      return;
    }
    uploadVideo(gl, videoReady, exporting);

    let fieldReady = false;
    let weights = null;
    if (packageState === "ready") {
      const located = locateSample(times, clamp(mediaTime, 0, pkg.beauty.durationSeconds));
      currentIndices = located;
      store.prefetch(located.i0, located.i0 === located.i1 ? [located.i0] : [located.i0, located.i1]);
      const e0 = store.get(located.i0), e1 = store.get(located.i1);
      fieldReady = Boolean(e0 && e1);
      if (transientDirty) clearTransient(gl);
      if (fieldReady) {
        const timeline = pkg.timelineData;
        cameraAt(timeline, located.i0, located.i0, 0, cam0);
        cameraAt(timeline, located.i1, located.i1, 0, cam1);
        cameraAt(timeline, located.i0, located.i1, located.mix, camN);
        morphAt(timeline, located.i0, located.i1, located.mix, morph);
        attachRisk = motionAt(timeline, located.i0, located.i1, located.mix);
        const flowCoverage = timeline.flowCoverage[located.i0] + (timeline.flowCoverage[located.i1] - timeline.flowCoverage[located.i0]) * located.mix;
        weights = morphWeights(morph, flowCoverage);
        if (controls.debug === 6) anchorList = interpolateAnchors(anchorsFor(located.i0), anchorsFor(located.i1), located.mix);
        const [slot0, slot1] = bindSamples(gl, located.i0, located.i1, e0, e1);
        drawFields(gl, located, slot0, slot1);
        drawGlints(gl, playing ? dt : 0, audioState, viewRect(width, height));
      }
    }
    presence += ((fieldReady ? 1 : 0) - presence) * (1 - Math.exp(-dt * (fieldReady ? 7 : 9)));
    drawComposite(gl, { target, width, height, mediaTime, audioState, fieldReady });
    timings.frames += 1;
    timings.total += performance.now() - started0;
    report(gl, { now, mediaTime, videoReady, fieldReady, playing, glVideo, weights });
  }

  function drawFields(gl, located, slot0, slot1) {
    const fw = pkg.fields.width, fh = pkg.fields.height;
    gl.disable(gl.BLEND);
    let stamp = performance.now();
    // 1. resolve: two neighbouring samples -> current-camera fields
    gl.bindFramebuffer(gl.FRAMEBUFFER, targets.resolveFbo);
    gl.viewport(0, 0, fw, fh);
    const resolve = programs.resolve;
    gl.useProgram(resolve);
    setCommon(gl, resolve);
    tex(gl, resolve, "uA0", 0, slot0.a); tex(gl, resolve, "uB0", 1, slot0.b);
    tex(gl, resolve, "uA1", 2, slot1.a); tex(gl, resolve, "uB1", 3, slot1.b);
    u1(gl, resolve, "uMix", located.mix);
    u1(gl, resolve, "uReproject", 1);
    setCamera(gl, resolve, "0", cam0); setCamera(gl, resolve, "1", cam1); setCamera(gl, resolve, "N", camN);
    fullscreen(gl, resolve);
    checkGl(gl, "resolve");
    timings.resolve += performance.now() - stamp;

    // 2. prep: smoothed count and masks
    stamp = performance.now();
    gl.bindFramebuffer(gl.FRAMEBUFFER, targets.prepSFbo);
    const prep = programs.prep;
    gl.useProgram(prep);
    setCommon(gl, prep);
    tex(gl, prep, "uFieldA", 0, targets.resolved[0]);
    tex(gl, prep, "uFieldB", 1, targets.resolved[1]);
    tex(gl, prep, "uFieldC", 2, targets.resolved[2]);
    fullscreen(gl, prep);
    // Leave the field framebuffers before anything samples their textures.
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    checkGl(gl, "prep");
    timings.prep += performance.now() - stamp;
  }

  function viewRect(width, height) {
    const aspect = asset.videoWidth / asset.videoHeight;
    return width / Math.max(1, height) > aspect ? [height * aspect, height] : [width, width / aspect];
  }

  function drawGlints(gl, dt, audioState, view) {
    if (!(dt > 0) || controls.glints <= 0) { dropBurst = 0; return; }
    const stamp = performance.now();
    wavePool.writeUniforms(waveA, waveB, waveC);
    // Expected births this frame. Surf follows the waves that are out on the terrain; the shader
    // only accepts candidates where a crest is actually breaking, so most tries are refused.
    let surfing = 0;
    for (const wave of wavePool.slots) if (wave.active && waveFront(wave) > 2.5) surfing += wave.strength;
    const calmMotion = 1 - 0.6 * attachRisk;
    const reactive = clamp(controls.reactive, 0, 1.5);
    const rates = [
      Math.min(90, surfing * 1400 * dt) * controls.glints * reactive * calmMotion,
      Math.min(60, audioState.glintRate * 4 * dt) * controls.glints * calmMotion,
      dropBurst * controls.glints * reactive
    ];
    dropBurst = 0;
    const update = programs.update;
    gl.useProgram(update);
    setCommon(gl, update);
    tex(gl, update, "uS", 0, targets.prepS);
    tex(gl, update, "uFieldB", 1, targets.resolved[1]);
    tex(gl, update, "uFieldC", 2, targets.resolved[2]);
    tex(gl, update, "uSmall", 3, targets.small);
    u1(gl, update, "uDelta", dt);
    u1(gl, update, "uClock", clockSeconds += dt);
    u1(gl, update, "uCapacity", CAPACITY);
    u4(gl, update, "uRates", rates[0], rates[1], rates[2], 0);
    u2(gl, update, "uViewPx", view[0], view[1]);
    u1(gl, update, "uDebugAttach", controls.debug === 10 ? 1 : 0);
    setCamera(gl, update, "N", camN);
    u4v(gl, update, "uWaveA[0]", waveA);
    u4v(gl, update, "uWaveB[0]", waveB);
    const output = 1 - glints.read;
    gl.bindVertexArray(glints.vaos[glints.read]);
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, glints.feedback);
    gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, glints.buffers[output]);
    gl.enable(gl.RASTERIZER_DISCARD);
    gl.beginTransformFeedback(gl.POINTS);
    gl.drawArrays(gl.POINTS, 0, CAPACITY);
    gl.endTransformFeedback();
    gl.disable(gl.RASTERIZER_DISCARD);
    gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, null);
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, null);
    gl.bindVertexArray(null);
    glints.read = output;
    glintRates = rates;
    checkGl(gl, "glintUpdate");
    timings.glints += performance.now() - stamp;
  }

  function drawComposite(gl, { target, width, height, mediaTime, audioState, fieldReady }) {
    const stamp = performance.now();
    const reactive = clamp(controls.reactive, 0, 1.5);
    const grade = clamp(controls.grade, 0, 1.5);
    const [viewW, viewH] = viewRect(width, height);
    const fade = pkg ? presence * loopFade(mediaTime, pkg.beauty.durationSeconds, pkg.loop.fadeSeconds, loops > 0) : 0;
    wavePool.writeUniforms(waveA, waveB, waveC);
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    gl.disable(gl.BLEND);
    const prog = programs.composite;
    gl.useProgram(prog);
    setCommon(gl, prog);
    tex(gl, prog, "uVideo", 0, videoTexture);
    tex(gl, prog, "uSmall", 1, targets.small);
    tex(gl, prog, "uS", 2, targets.prepS);
    tex(gl, prog, "uFieldA", 3, targets.resolved[0]);
    tex(gl, prog, "uFieldB", 4, targets.resolved[1]);
    tex(gl, prog, "uFieldC", 5, targets.resolved[2]);
    u1(gl, prog, "uCanvasAspect", width / Math.max(1, height));
    u1(gl, prog, "uVideoAspect", asset.videoWidth / asset.videoHeight);
    u2(gl, prog, "uViewPx", viewW, viewH);
    u1i(gl, prog, "uDebug", fieldReady ? controls.debug : 0);
    u1(gl, prog, "uFade", fieldReady ? fade : 0);
    const scaled = (value) => 1 + (value - 1) * grade;
    u4(gl, prog, "uGrade", scaled(audioState.exposure), scaled(audioState.saturation), scaled(audioState.contrast), audioState.haze * grade);
    u4(gl, prog, "uLight", audioState.bloom * grade, audioState.craterGlow, audioState.seamShimmer, audioState.shimmerPhase);
    u4(gl, prog, "uMix", controls.waves * reactive, controls.craters, controls.seams, controls.waves * reactive);
    u1(gl, prog, "uBreath", audioState.breathPhase % 1);
    u4v(gl, prog, "uWaveA[0]", waveA);
    u4v(gl, prog, "uWaveB[0]", waveB);
    u4v(gl, prog, "uWaveC[0]", waveC);
    if (controls.debug === 6) {
      let count = 0;
      for (const anchor of anchorList) {
        if (count >= MAX_ANCHOR_UNIFORMS) break;
        anchorA.set([anchor.u, anchor.v, anchor.radius, anchor.presence], count * 4);
        anchorB[count * 4] = anchor.code;
        count += 1;
      }
      u1i(gl, prog, "uAnchorCount", count);
      u4v(gl, prog, "uAnchorA[0]", anchorA);
      u4v(gl, prog, "uAnchorB[0]", anchorB);
    } else u1i(gl, prog, "uAnchorCount", 0);
    fullscreen(gl, prog);
    if (fieldReady && glints && controls.glints > 0 && [0, 8, 10, 11].includes(controls.debug)) {
      const draw = programs.draw;
      gl.useProgram(draw);
      gl.bindVertexArray(glints.vaos[glints.read]);
      setCommon(gl, draw);
      tex(gl, draw, "uSmall", 0, targets.small);
      u1(gl, draw, "uCanvasAspect", width / Math.max(1, height));
      u1(gl, draw, "uVideoAspect", asset.videoWidth / asset.videoHeight);
      u1(gl, draw, "uPxScale", Math.max(0.6, viewH / 720));
      u1(gl, draw, "uFade", fade);
      u1(gl, draw, "uAmount", controls.glints * clamp(controls.reactive, 0, 1.5));
      u1(gl, draw, "uDebugAttach", controls.debug === 10 ? 1 : 0);
      u3v(gl, draw, "uCamPos", camN.position || [0, 0, 0]);
      gl.enable(gl.BLEND);
      gl.blendFuncSeparate(gl.ONE, gl.ONE, gl.ZERO, gl.ONE);
      gl.drawArrays(gl.POINTS, 0, CAPACITY);
      gl.disable(gl.BLEND);
      gl.bindVertexArray(null);
    }
    checkGl(gl, "composite");
    timings.composite += performance.now() - stamp;
  }

  // ---------------------------------------------------------------- report
  // Trial diagnostics read the glint states back without stalling: copy them to a staging buffer
  // behind a fence, and read the copy on a later report once the GPU has finished with it.
  function readGlintsAsync(gl) {
    if (readback && gl.getSyncParameter(readback.sync, gl.SYNC_STATUS) === gl.SIGNALED) {
      gl.bindBuffer(gl.COPY_READ_BUFFER, readback.buffer);
      gl.getBufferSubData(gl.COPY_READ_BUFFER, 0, diagnosticStates);
      gl.bindBuffer(gl.COPY_READ_BUFFER, null);
      gl.deleteSync(readback.sync);
      readback.sync = null;
      liveGlints = 0;
      endHistogram = Object.fromEntries(GLINT_END_NAMES.map((name) => [name, 0]));
      kindHistogram = [0, 0, 0];
      for (let i = 0; i < CAPACITY; i += 1) {
        const age = diagnosticStates[i * 12 + 3], life = diagnosticStates[i * 12 + 4];
        if (age >= 0 && life > 0) {
          liveGlints += 1;
          kindHistogram[Math.min(2, Math.max(0, Math.round(diagnosticStates[i * 12 + 6])))] += 1;
        } else {
          // Dead slots keep the reason their last glint ended, an outline of what the rules reject.
          const reason = Math.round(diagnosticStates[i * 12 + 11]);
          if (reason > 0 && reason < GLINT_END_NAMES.length) endHistogram[GLINT_END_NAMES[reason]] += 1;
        }
      }
    }
    if (!readback) readback = { buffer: gl.createBuffer(), sync: null };
    if (!readback.sync) {
      gl.bindBuffer(gl.COPY_WRITE_BUFFER, readback.buffer);
      gl.bufferData(gl.COPY_WRITE_BUFFER, CAPACITY * 48, gl.STREAM_READ);
      gl.bindBuffer(gl.COPY_READ_BUFFER, glints.buffers[glints.read]);
      gl.copyBufferSubData(gl.COPY_READ_BUFFER, gl.COPY_WRITE_BUFFER, 0, 0, CAPACITY * 48);
      gl.bindBuffer(gl.COPY_READ_BUFFER, null);
      gl.bindBuffer(gl.COPY_WRITE_BUFFER, null);
      readback.sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    }
  }

  function report(gl, { now, mediaTime, videoReady, fieldReady, playing, glVideo, weights }) {
    if (panel && now - lastLabelAt > 500) {
      panel.querySelector("summary").textContent = packageState === "failed" || fatal
        ? "Newton Basin · video only"
        : `Newton Basin · ${video.playbackRate.toFixed(3)}× · sample ${currentIndices.i0}${fieldReady ? "" : " (loading)"}`;
      lastLabelAt = now;
    }
    const trial = trialMode();
    if (now - reportAt < (trial ? 2000 : 5000)) return;
    fps = reportAt ? (frames - reportFrames) * 1000 / (now - reportAt) : 0;
    reportAt = now; reportFrames = frames;
    const quality = video.getVideoPlaybackQuality?.();
    if (trial && glints && targets) readGlintsAsync(gl);
    const per = (value) => value / Math.max(1, timings.frames);
    const state = audioModel.state;
    window.__newtonBasinDiagnostics = {
      videoTime: mediaTime, fieldTime: mediaTime, sampleIndices: [currentIndices.i0, currentIndices.i1], mix: currentIndices.mix,
      fps, fieldReady, videoReady, glVideo, presence, playing, loops, seeks,
      playbackRate: video.playbackRate, targetRate, packageState, packageError, fatal,
      presentedFrames, callbackSkips, offlineFrame, uploadedFrame,
      droppedVideoFrames: quality?.droppedVideoFrames ?? 0, totalVideoFrames: quality?.totalVideoFrames ?? 0,
      store: store ? { ...store.stats, resident: store.size() } : null,
      music: {
        beat: state.beat, beatSource: state.beatSource, bps: state.beatsPerSecond, groove: state.groove, build: state.build, breakdown: state.breakdown,
        bassDrive: state.bassDrive, midDrive: state.midDrive, highDrive: state.highDrive, energyDrive: state.energyDrive, surge: state.surge,
        pump: state.pump, dropFlash: state.dropFlash, exposure: state.exposure, saturation: state.saturation, bloom: state.bloom,
        craterGlow: state.craterGlow, seamShimmer: state.seamShimmer, glintRate: state.glintRate,
        kickCount: state.kickCount, waveCount: state.waveCount, rollCount: state.rollCount, tideCount: state.tideCount, hatCount: state.hatCount, dropCount: state.dropCount
      },
      waves: wavePool.slots.filter((wave) => wave.active).map((wave) => ({ kind: wave.kind, front: Number(waveFront(wave).toFixed(2)), strength: Number(wave.strength.toFixed(2)), gains: wave.gains })),
      morph: weights, attachRisk, liveGlints, glintKinds: kindHistogram, glintEnds: endHistogram, glintRates, glintCapacity: CAPACITY, glintRules: GLINT,
      startCostMs, glErrors: { ...glErrors },
      analysisTrace: trial ? analysisTrace.slice() : undefined,
      musicAware: trial && lastMusic ? { role: lastMusic.role, buildUp: lastMusic.buildUp, breakdown: lastMusic.breakdown, drop: lastMusic.drop, calm: lastMusic.calm, highEnergy: lastMusic.highEnergy, sectionChange: lastMusic.sectionChange, adaptiveIntensity: lastMusic.adaptiveIntensity, phrasePulse: lastMusic.phrasePulse, energyTrend: lastMusic.energyTrend } : undefined,
      cpuMs: {
        video: per(timings.video), resolve: per(timings.resolve), prep: per(timings.prep), glints: per(timings.glints),
        composite: per(timings.composite), upload: per(timings.upload), total: per(timings.total)
      },
      decodedWindowMB: store ? store.size() * (pkg?.fields.rawSampleBytes || 0) / 1048576 : 0
    };
    if (trial) window.webkit?.messageHandlers?.nativeApp?.postMessage({
      command: "logConsole", type: "info", text: `${LOG_PREFIX} ${JSON.stringify(window.__newtonBasinDiagnostics)}`
    });
  }

  async function prepareOffline(time, tempo) {
    if (!active) start();
    if (!offlineFrame) {
      audioModel.reset(); wavePool.clear(); lastAt = null; lastMediaTime = NaN;
      clockSeconds = 0; presence = 0; transientDirty = true;
    }
    await packageLoad;
    if (fatal || packageError) throw new Error(fatal || packageError);
    const measured = controls.testBPM > 0 ? { bpm: controls.testBPM, confidence: 1 } : tempo || {};
    targetRate = forgePlaybackTarget(measured, pkg.tempo.referenceBPM || asset.referenceBPM, controls.bpmLock);
    const playback = offlineVideoPlaybackAt(time, targetRate);
    video.playbackRate = playback.rate;
    const mediaTime = playback.time % asset.durationSeconds;
    offlineFrame = { ...await seekOfflineVideoFrame(video, mediaTime, { fps: asset.videoFps }), textureUploaded: false };
    // Fields and camera metadata must be ready for this same beauty frame.
    const located = locateSample(times, offlineFrame.mediaTime);
    await store.ready([located.i0, located.i1]);
    offlineFrame.metadataSamples = [located.i0, located.i1];
    return offlineFrame;
  }
  return { render, stop, prepareOffline, endOffline() { offlineFrame = null; lastAt = 0; }, controls, isActive: () => active };
}
