import { capabilityEnabled, enforceTransitionCapabilities } from "../config/runtimeCapabilities.js";
import { createDiversityCycle } from "./diversityCycle.js";

function transitionKey(transition) {
  if (!transition?.active) return "";
  return [
    transition.from,
    transition.to,
    Math.round(Number(transition.start) || 0),
    Math.round(Number(transition.seed || 0) * 100000)
  ].join(":");
}

function clamp01(value) {
  return Math.max(0, Math.min(1, Number(value) || 0));
}

function transitionOpacityForPhase(phase, fadeRatio = 0.22) {
  const p = clamp01(phase);
  const fade = Math.max(0.05, Math.min(0.45, Number(fadeRatio) || 0.22));
  const fadeIn = smoothstep(0.00, fade, p);
  const fadeOut = 1 - smoothstep(1 - fade, 1.00, p);
  return clamp01(fadeIn * fadeOut);
}

function smoothstep(edge0, edge1, x) {
  const t = clamp01((x - edge0) / Math.max(0.0001, edge1 - edge0));
  return t * t * (3 - 2 * t);
}

// Budget for the element to reach readyState >= 2 (HAVE_CURRENT_DATA).
const READINESS_BUDGET_MS = 1200;
// Once the element is ready, play() still has to be called and take effect:
// waitForVideoReady resolves -> .then() -> playPreparedVideo -> tryPlaySource
// -> await video.play(). Those continuations need main-thread time *after*
// readiness, so the give-up deadline must sit strictly beyond the readiness
// budget. When both deadlines were 1200ms the play path could never win a
// close finish, and a fully loaded video was discarded milliseconds before it
// would have started.
const PLAY_GRACE_MS = 500;
// Once the element reports playing, currentTime still has to tick past zero
// before the video is worth revealing. One frame is ~33-42ms; this allows for
// a slow first decode without letting a wedged decoder hold the transition.
const FIRST_FRAME_GRACE_MS = 400;
// A gap between update() calls larger than this means the render loop itself
// stopped rather than merely running slowly, matching the frame-gap threshold
// in liveRenderLoop. The video keeps decoding on WebKit's media thread across
// such a gap, so the time is not evidence that the video failed.
const RENDER_STALL_GAP_MS = 250;

function waitForVideoReady(video, signal, timeoutMs = READINESS_BUDGET_MS) {
  return new Promise((resolve, reject) => {
    if (!video) {
      reject(new Error("Missing transition video element"));
      return;
    }
    if (signal.aborted) {
      resolve(false);
      return;
    }
    if (video.readyState >= 2) {
      resolve(true);
      return;
    }

    let done = false;
    const cleanup = () => {
      window.clearTimeout(timer);
      signal.removeEventListener("abort", onAbort);
      video.removeEventListener("loadeddata", onReady);
      video.removeEventListener("canplay", onReady);
      video.removeEventListener("error", onError);
    };
    const finish = (callback, value) => {
      if (done) return;
      done = true;
      cleanup();
      callback(value);
    };
    const onAbort = () => finish(resolve, false);
    const onReady = () => finish(resolve, true);
    const onError = () => {
      const mediaError = video.error;
      const message = mediaError
        ? `Video error ${mediaError.code}${mediaError.message ? `: ${mediaError.message}` : ""}`
        : "Video element error";
      finish(reject, new Error(message));
    };
    const timer = window.setTimeout(() => {
      // A timeout is not automatically fatal: WebKit sometimes has enough
      // metadata to start muted playback but delays canplay while decoding.
      finish(resolve, video.readyState >= 1);
    }, timeoutMs);

    signal.addEventListener("abort", onAbort, { once: true });
    video.addEventListener("loadeddata", onReady, { once: true });
    video.addEventListener("canplay", onReady, { once: true });
    video.addEventListener("error", onError, { once: true });
  });
}

// Only these settings cross into the visual-output document. Never copy or
// persist the controller's unrelated options from the output document.
export function snapshotVideoTransitionOptions(options = {}) {
  return {
    useVideoTransitions: Boolean(options.useVideoTransitions),
    videoTransitionMode: options.videoTransitionMode || "auto",
    selectedTransitionIds: [...(options.selectedTransitionIds || [])],
    videoTransitionDurationMs: Number(options.videoTransitionDurationMs) || 10000,
    videoTransitionFadeMs: Number(options.videoTransitionFadeMs) || 4300,
    userTransitionsRevision: String(options.userTransitionsRevision || "")
  };
}

export function createVideoTransitionManager({
  video,
  assetManager,
  classifyEnergy,
  getOptions,
  logger = console,
  recentLimit = 3
} = {}) {
  let activeKey = "";
  let activeOptions = {};
  let attempt = new AbortController();

  function invalidateAttempt() {
    attempt.abort();
    attempt = new AbortController();
  }
  let selectedVideo = null;
  let recentTransitionIds = [];
  const transitionDiversity = createDiversityCycle({ recentLimit });
  let playAttempted = false;
  let currentObjectUrl = "";
  let playbackStarted = false;
  let playbackStartedAt = 0;
  let preparationStartedAt = 0;
  let currentOpacity = 0;
  let fullCoverFrames = 0;
  let fullCoverStartedAt = 0;
  let fullCoverVideoTime = 0;
  let videoEventsAttached = false;
  let lastVideoEvent = "idle";
  let lastVideoEventAt = 0;
  let waitingEvents = 0;
  let stalledEvents = 0;
  let lastUpdateAt = 0;
  let starvedMs = 0;

  function roleLabel() {
    const classes = globalThis.document?.body?.classList;
    if (!classes) return "unknown";
    return classes.contains("visual-output-role") ? "output" : "controller";
  }

  function attachVideoDiagnostics() {
    if (!video || videoEventsAttached) return;
    videoEventsAttached = true;
    for (const eventName of ["loadstart", "loadeddata", "canplay", "playing", "waiting", "stalled", "seeking", "seeked", "error", "emptied"]) {
      video.addEventListener(eventName, () => {
        lastVideoEvent = eventName;
        lastVideoEventAt = performance.now();
        if (eventName === "waiting") waitingEvents += 1;
        if (eventName === "stalled") stalledEvents += 1;
      });
    }
  }

  function configureVideo() {
    if (!video) return;
    attachVideoDiagnostics();
    video.muted = true;
    video.playsInline = true;
    video.controls = false;
    video.loop = false;
    video.preload = "auto";
  }

  // Per-attempt playback state, cleared whenever a transition video starts
  // preparing -- not only when the element is torn down. begin() can run with
  // no intervening resetVideo() whenever one transition starts in the same
  // frame the previous one ended (app.js runs this manager's update() before
  // visualTransitions.updatePreset(), so the frame that completes a transition
  // still sees it active). A stale playAttempted then makes playPreparedVideo
  // return silently at its guard, so the new video loads to readyState 4 and
  // fires canplay but play() is never called at all -- the video sits paused
  // until the timeout and the transition falls back to a hard cut.
  function resetPlaybackAttempt() {
    playAttempted = false;
    playbackStarted = false;
    playbackStartedAt = 0;
    currentOpacity = 0;
    fullCoverFrames = 0;
    fullCoverStartedAt = 0;
    fullCoverVideoTime = 0;
    starvedMs = 0;
  }

  function resetVideo(transition = null) {
    invalidateAttempt();
    if (transition) {
      transition.suppressShaderTransition = false;
      transition.suppressVideoTransition = true;
    }
    if (!video) return;
    video.style.opacity = "0";
    try { video.pause(); } catch {}
    video.removeAttribute("src");
    video.load?.();
    video.__loadedTransitionPath = "";
    currentObjectUrl = "";
    resetPlaybackAttempt();
    preparationStartedAt = 0;
    selectedVideo = null;
  }

  async function loadVideoSource(source, signal) {
    if (signal.aborted || !video || !source) return false;
    configureVideo();
    currentObjectUrl = source;
    if (video.__loadedTransitionPath !== source) {
      video.src = source;
      video.__loadedTransitionPath = source;
      video.load();
    }
    const ready = await waitForVideoReady(video, signal);
    return ready && !signal.aborted;
  }

  async function prepareVideo(entry, signal) {
    if (!video || !entry?.resolvedPath) return false;
    // First try the local HTTP URL. If WebKit rejects playback for that URL,
    // playPreparedVideo retries through the asset manager's blob URL path.
    try {
      return await loadVideoSource(entry.resolvedPath, signal);
    } catch (error) {
      if (signal.aborted) return false;
      if (!assetManager?.objectUrlForVideo) throw error;
      logger.warn?.(`Video transition source load failed for ${entry.id}; retrying as blob URL:`, error);
      const blobUrl = await assetManager.objectUrlForVideo(entry.resolvedPath);
      if (signal.aborted) return false;
      if (!blobUrl) throw error;
      return loadVideoSource(blobUrl, signal);
    }
  }

  async function tryPlaySource(source, entry, signal) {
    if (signal.aborted) return false;
    if (video.__loadedTransitionPath !== source || video.readyState < 1) {
      if (!await loadVideoSource(source, signal)) return false;
    }
    if (signal.aborted || selectedVideo?.id !== entry?.id) return false;
    if ((Number(video.currentTime) || 0) > 0) {
      try { video.currentTime = 0; } catch {}
    }
    await video.play();
    if (signal.aborted || selectedVideo?.id !== entry?.id) return false;
    playbackStarted = true;
    playbackStartedAt = performance.now();
    return true;
  }

  async function playPreparedVideo(entry, transition, signal) {
    if (signal.aborted || !video || playAttempted) return;
    playAttempted = true;
    try {
      await tryPlaySource(currentObjectUrl || entry?.resolvedPath, entry, signal);
    } catch (error) {
      if (signal.aborted) return;
      if (entry?.resolvedPath && assetManager?.objectUrlForVideo && currentObjectUrl === entry.resolvedPath) {
        try {
          const blobUrl = await assetManager.objectUrlForVideo(entry.resolvedPath);
          if (blobUrl && !signal.aborted && selectedVideo?.id === entry.id) {
            await tryPlaySource(blobUrl, entry, signal);
            return;
          }
        } catch (fallbackError) {
          if (signal.aborted) return;
          logger.warn?.("Video transition blob fallback failed:", fallbackError);
        }
      }
      if (signal.aborted) return;
      logger.warn?.(
        `Video transition playback failed for ${entry?.id || "unknown"} (${entry?.resolvedPath || "no path"}); using shader transition only:`,
        error
      );
      resetVideo(transition);
    }
  }

  function rememberTransition(entry) {
    if (!entry?.id) return;
    const options = activeOptions;
    const eligibleIds = assetManager?.transitionsForMode?.(
      options.videoTransitionMode || "auto",
      options.selectedTransitionIds || []
    ).map((candidate) => candidate.id) || [];
    transitionDiversity.record(entry.id, eligibleIds);
    recentTransitionIds.unshift(entry.id);
    recentTransitionIds = recentTransitionIds.slice(0, recentLimit);
  }

  async function begin(transition, now) {
    enforceTransitionCapabilities(transition);
    if (!capabilityEnabled("videoTransitions")) { resetVideo(transition); return; }
    invalidateAttempt();
    if (selectedVideo) {
      // Adjacent transitions can reuse the element/source. Retire the old
      // attempt without unloading a decoder the next clip may still use.
      try { video.pause(); } catch {}
      video.style.opacity = "0";
      selectedVideo = null;
      resetPlaybackAttempt();
    }
    const signal = attempt.signal;
    // Keep the in-flight implementation and fades stable until completion.
    const options = activeOptions = snapshotVideoTransitionOptions(getOptions?.());
    options.useVideoTransitions = transition.useVideoTransitions ?? options.useVideoTransitions;
    const wantsVideo = options.useVideoTransitions || transition?.forceVideoTransition || transition?.videoTransitionId;
    if (transition?.suppressVideoTransition) {
      resetVideo(transition);
      return;
    }

    if (!wantsVideo || !video || !assetManager) {
      resetVideo(transition);
      return;
    }
    // Startup normally warms the manifests. A first-use transition can race
    // that warmup; await the same cached promise, never start a second loader.
    if (!assetManager.transitionsForMode?.(options.videoTransitionMode, options.selectedTransitionIds)?.length
        && assetManager.loadTransitionManifests) {
      try {
        await assetManager.loadTransitionManifests();
      } catch (error) {
        if (signal.aborted) return;
        logger.warn?.("Video transition manifests could not be prepared:", error);
        resetVideo(transition);
        return;
      }
      if (signal.aborted) return;
      now = performance.now();
    }
    // Only when My Transitions changed since this document last looked; the
    // common path stays synchronous so selection happens in this frame.
    if (assetManager.userTransitionsNeedSync?.(options.userTransitionsRevision)) {
      try { await assetManager.syncUserTransitions(options.userTransitionsRevision); } catch {}
      if (signal.aborted) return;
      now = performance.now();
    }

    // If nothing has rendered for a while, the first frame back can hand this
    // manager a transition that is already at or past its preset hand-off. A
    // video cannot cover a hand-off that has already happened, and loading one
    // would pull megabytes off disk to overlay a transition that is finishing,
    // so fall through to the shader path instead.
    const duration = Math.max(1, Number(transition?.duration) || 2600);
    const swapAt = Math.max(0.1, Math.min(0.95, Number(transition?.swapAt) || 0.5));
    const elapsedOnFirstSight = Number(now) - (Number(transition?.start) || Number(now));
    if (Number.isFinite(elapsedOnFirstSight) && elapsedOnFirstSight > duration * swapAt) {
      logger.warn?.(
        `Video transition skipped: transition was already ${elapsedOnFirstSight.toFixed(0)}ms into a ` +
        `${duration.toFixed(0)}ms hand-off when first seen (role=${roleLabel()}); using shader transition.`
      );
      resetVideo(transition);
      return;
    }
    const forcedId = transition?.videoTransitionId;

    const energyType = classifyEnergy?.(transition) || "high-high";
    const mode = options.videoTransitionMode || "auto";
    const selectedTransitionIds = options.selectedTransitionIds || [];
    const eligibleIds = assetManager.transitionsForMode?.(mode, selectedTransitionIds).map((candidate) => candidate.id) || [];
    const entry = forcedId
      ? assetManager.transitionById?.(forcedId)
      : assetManager.selectTransitionVideo({
        mode,
        energyType,
        selectedTransitionIds,
        candidateIds: transitionDiversity.candidates(eligibleIds),
        recentTransitionIds
      });
    if (!entry) {
      resetVideo(transition);
      return;
    }

    selectedVideo = entry;
    resetPlaybackAttempt();
    preparationStartedAt = performance.now();
    waitingEvents = 0;
    stalledEvents = 0;
    lastVideoEvent = "selected";
    lastVideoEventAt = performance.now();
    rememberTransition(entry);
    prepareVideo(entry, signal)
      .then((ready) => {
        if (ready && !signal.aborted) playPreparedVideo(entry, transition, signal);
      })
      .catch((error) => {
        if (signal.aborted) return;
        logger.warn?.("Video transition could not be prepared:", error);
        resetVideo(transition);
      });
  }

  function update(transition, now) {
    // Accumulate render-loop starvation before begin() may reset it, so time
    // the loop spent not running is never billed against the video's budget.
    const updateAt = performance.now();
    if (lastUpdateAt) {
      const sinceLastUpdate = updateAt - lastUpdateAt;
      if (sinceLastUpdate > RENDER_STALL_GAP_MS) starvedMs += sinceLastUpdate - RENDER_STALL_GAP_MS;
    }
    lastUpdateAt = updateAt;

    if (!transition?.active) {
      if (activeKey) {
        activeKey = "";
        resetVideo(transition);
      }
      return;
    }

    enforceTransitionCapabilities(transition);
    if (!capabilityEnabled("videoTransitions")) {
      if (activeKey || selectedVideo || video?.__loadedTransitionPath) resetVideo(transition);
      activeKey = "";
      return;
    }
    const key = transitionKey(transition);
    if (key && key !== activeKey) {
      activeKey = key;
      begin(transition, now);
    }

    const options = activeOptions;
    if (transition?.suppressVideoTransition) {
      if (video) video.style.opacity = "0";
      return;
    }
    const wantsVideo = options.useVideoTransitions || transition?.forceVideoTransition || transition?.videoTransitionId;
    if (!wantsVideo || !video || !selectedVideo) {
      if (!wantsVideo) transition.suppressShaderTransition = false;
      if (video) video.style.opacity = "0";
      return;
    }

    const elapsedSinceStart = Number(now) - (Number(transition.start) || Number(now));
    // The element itself is the authority on whether it is playing. playbackStarted
    // is only set by a promise continuation after await video.play() resolves, so
    // under main-thread congestion -- exactly when transitions are most fragile --
    // it can still read false while WebKit's media thread plays the video normally.
    // Requiring it here discarded videos that were visibly running.
    const elementIsPlaying = Boolean(video && !video.paused && video.readyState >= 2);
    const isActivelyPlaying = elementIsPlaying && (Number(video.currentTime) || 0) > 0;

    // Timeout safeguard, measured from the moment this manager actually started
    // preparing the video and discounted for render-loop stalls.
    //
    // This deliberately does not use the transition's own clock. transition.start
    // is wall-clock time that keeps running while nothing renders, so whenever
    // requestAnimationFrame is throttled -- an occluded controller window is the
    // common case -- the first frame back would see a transition tens of seconds
    // old and kill a video that had not been given a single millisecond to load.
    //
    // Readiness and playback get separate budgets. A video that has reached
    // readyState >= 2 has done everything asked of it and is only waiting on
    // play() to take effect, so it earns PLAY_GRACE_MS beyond the readiness
    // budget rather than being cut at the same instant the load completes.
    // An element that reports playing but has not advanced past frame 0 earns
    // FIRST_FRAME_GRACE_MS on top -- bounded, not unconditional, so a decoder
    // wedged at zero still falls back instead of stalling the transition.
    const sincePreparation = preparationStartedAt ? performance.now() - preparationStartedAt : 0;
    const effectiveElapsed = Math.max(0, sincePreparation - starvedMs);
    let budgetMs = READINESS_BUDGET_MS;
    if (video && video.readyState >= 2) budgetMs += PLAY_GRACE_MS;
    if (elementIsPlaying) budgetMs += FIRST_FRAME_GRACE_MS;
    if (!isActivelyPlaying && preparationStartedAt && effectiveElapsed > budgetMs) {
      logger.warn?.(
        `Video transition playback timed out for ${selectedVideo.id} after ${sincePreparation.toFixed(0)}ms ` +
        `(role=${roleLabel()} ready=${video.readyState} paused=${video.paused} event=${lastVideoEvent} ` +
        `effective=${effectiveElapsed.toFixed(0)}ms budget=${budgetMs}ms starved=${starvedMs.toFixed(0)}ms ` +
        `waits=${waitingEvents} stalls=${stalledEvents}); falling back to shader transition.`
      );
      resetVideo(transition);
      // The shader crossfade that takes over now reads this same transition's
      // wall-clock start/duration (transitions.js:presetTransitionProgress).
      // A timeout this late usually means requestAnimationFrame itself was
      // starved -- the same reason sincePreparation can overshoot 1200ms by
      // several seconds -- so that clock is often already past `duration`,
      // which reports phase=1 (complete) on the very next check. The shader
      // fallback would then render zero blended frames: a hard, instant cut
      // to the incoming preset instead of a fade. Rebase the clock so the
      // fallback still gets one short fade of its own; leave it alone when
      // there is still genuine transition time left to fade through.
      if (transition && Number(now) - Number(transition.start || now) >= Number(transition.duration || 2600)) {
        transition.start = Number(now);
        transition.duration = Math.max(300, Math.min(900, Number(options.videoTransitionFadeMs) || 600));
      }
      return;
    }

    const duration = Math.max(1, Number(transition.duration) || 2600);
    const phase = clamp01(elapsedSinceStart / duration);
    const fadeMs = Math.max(250, Number(options.videoTransitionFadeMs) || 4300);
    const fadeRatio = Math.min(0.45, fadeMs / duration);
    
    // Only reveal video element when video is actively playing frames. A video
    // that has not appeared at all by late phase can no longer cover the
    // hand-off it exists for, and fading one in now would only ghost briefly
    // before the phase > 0.96 cutoff below pulls it straight back out. This
    // suppresses the reveal only -- it never discards the video on wall-clock
    // grounds, which is what the deliberately clock-independent timeout above
    // is protecting against.
    const tooLateToReveal = currentOpacity <= 0 && phase > 0.75;
    if (!isActivelyPlaying || tooLateToReveal) {
      currentOpacity = 0;
      video.style.opacity = "0";
    } else {
      currentOpacity = transitionOpacityForPhase(phase, fadeRatio);
      video.style.opacity = String(currentOpacity);
    }

    if (currentOpacity >= 0.995 && isActivelyPlaying) {
      if (fullCoverFrames === 0) {
        fullCoverStartedAt = performance.now();
        fullCoverVideoTime = Number(video.currentTime) || 0;
      }
      fullCoverFrames += 1;
    } else {
      fullCoverFrames = 0;
      fullCoverStartedAt = 0;
      fullCoverVideoTime = 0;
    }
    if (phase > 0.96 && video.style.opacity !== "0") {
      video.style.opacity = "0";
      currentOpacity = 0;
    }
  }

  function canCoverPresetPreparation() {
    // Deliberately does not consult playbackStarted: the opacity, frame-count
    // and currentTime-advance checks below are direct evidence that the video
    // is really covering the canvas, whereas that flag can lag behind under
    // the main-thread congestion this cover exists to hide.
    if (!video || !selectedVideo || video.paused || video.readyState < 2) return false;
    // Do not compile in the same browser frame that raises the video opacity.
    // WebKit needs several committed, advancing frames before synchronous
    // preset preparation can safely block the main thread behind it.
    const coverAge = performance.now() - fullCoverStartedAt;
    const videoAdvance = (Number(video.currentTime) || 0) - fullCoverVideoTime;
    return currentOpacity >= 0.995
      && fullCoverFrames >= 3
      && coverAge >= 80
      && videoAdvance >= 0.05;
  }

  // Rendering an incoming flagship preset beneath an opaque transition video
  // competes with WebKit's video compositor. The renderer can defer that work
  // until the outgoing video has begun to reveal the visual again.
  function isCoveringOutput(minimumOpacity = 0.92) {
    return Boolean(
      video
      && selectedVideo
      && !video.paused
      && video.readyState >= 2
      && currentOpacity >= Math.max(0, Math.min(1, Number(minimumOpacity) || 0))
    );
  }

  function stop() {
    activeKey = "";
    resetVideo();
    transitionDiversity.reset();
    recentTransitionIds = [];
  }

  function diagnosticState() {
    if (!video) return { available: false };
    let playbackQuality = null;
    try {
      const quality = video.getVideoPlaybackQuality?.();
      if (quality) playbackQuality = {
        totalFrames: Number(quality.totalVideoFrames) || 0,
        droppedFrames: Number(quality.droppedVideoFrames) || 0
      };
    } catch {}
    return {
      available: true,
      selectedId: selectedVideo?.id || "",
      readyState: Number(video.readyState) || 0,
      networkState: Number(video.networkState) || 0,
      currentTime: Number(video.currentTime) || 0,
      paused: Boolean(video.paused),
      playbackStarted,
      opacity: currentOpacity,
      lastEvent: lastVideoEvent,
      lastEventAgeMs: lastVideoEventAt ? performance.now() - lastVideoEventAt : null,
      waitingEvents,
      stalledEvents,
      playbackQuality
    };
  }

  return {
    update,
    stop,
    canCoverPresetPreparation,
    isCoveringOutput,
    currentTransitionVideo: () => selectedVideo,
    diagnosticState,
    recentTransitionIds: () => recentTransitionIds.slice(),
    resetDiversity: () => transitionDiversity.reset()
  };
}
