// On-demand observations only: no binds, clears, reads of pixels, or getError()
// (which would consume evidence belonging to another observer).
export function captureRenderState(gl, presetProgram, state) {
  const snapshot = { ...state };
  if (!gl || gl.isContextLost()) return { ...snapshot, contextLost: Boolean(gl) };
  const value = (name) => {
    const result = gl.getParameter(gl[name]);
    return ArrayBuffer.isView(result) ? Array.from(result) : result;
  };
  snapshot.gpu = {
    contextLost: false,
    drawingBuffer: [gl.drawingBufferWidth, gl.drawingBufferHeight],
    viewport: value('VIEWPORT'),
    scissor: value('SCISSOR_BOX'),
    colorMask: value('COLOR_WRITEMASK'),
    depthMask: value('DEPTH_WRITEMASK'),
    defaultDrawFramebuffer: gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING) === null,
    defaultReadFramebuffer: gl.getParameter(gl.READ_FRAMEBUFFER_BINDING) === null,
    framebufferStatus: gl.checkFramebufferStatus(gl.FRAMEBUFFER),
    enabled: Object.fromEntries(['BLEND', 'DEPTH_TEST', 'SCISSOR_TEST', 'CULL_FACE', 'RASTERIZER_DISCARD']
      .map(name => [name, gl.isEnabled(gl[name])])),
    blend: ['BLEND_SRC_RGB', 'BLEND_DST_RGB', 'BLEND_SRC_ALPHA', 'BLEND_DST_ALPHA',
      'BLEND_EQUATION_RGB', 'BLEND_EQUATION_ALPHA'].map(value)
  };
  // This is the last preset program supplied by the shared renderer, which
  // may differ from the currently bound final blit/composite program.
  snapshot.uniforms = {};
  if (presetProgram && gl.isProgram(presetProgram)) {
    for (const name of ['preset', 'presetTime', 'resolution', 'quality', 'transitionPhase',
      'kick', 'bass', 'mids', 'highs', 'level', 'u_slowLevel', 'u_slowBass',
      'kickPulse', 'globalEnergy', 'highEnergyState', 'mainRiffState']) {
      const location = gl.getUniformLocation(presetProgram, name);
      if (location === null) continue;
      const uniform = gl.getUniform(presetProgram, location);
      snapshot.uniforms[name] = ArrayBuffer.isView(uniform) ? Array.from(uniform) : uniform;
    }
  }
  return snapshot;
}
