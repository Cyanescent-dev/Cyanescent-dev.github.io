import { capabilityEnabled } from "../config/runtimeCapabilities.js";
export const DEFAULT_CYANESCENT_TRANSITION_MANIFEST = "assets/bg/cyanescent_transitions/manifest.json";
export const DEFAULT_CUSTOM_TRANSITION_MANIFEST = "assets/bg/transitions/manifest.json";
// Pro Video's imported clips. Served by the native app from Application Support,
// outside the signed bundle; absent (404) in Free, Pro and browser previews.
export const DEFAULT_USER_TRANSITION_LIBRARY = "user-transitions/library.json";
export const USER_TRANSITION_ID_PREFIX = "user:";
// Dispatched on window after My Transitions changes in this document.
export const USER_TRANSITIONS_CHANGED_EVENT = "cyanescent-user-transitions-changed";
// Modes that draw on My Transitions. Older builds treat them as "auto".
export const USER_TRANSITION_MODES = Object.freeze(["user", "mixed"]);
// Imported clips carry no energy tags, so they suit every musical change.
const ALL_ENERGY_TYPES = Object.freeze(["low-low", "high-high", "rising", "falling"]);

function resolveAssetPath(basePath, file) {
  if (!file) return "";
  if (/^(blob:|data:|https?:|file:)/i.test(file)) return file;
  return `${basePath.replace(/\/+$/, "")}/${file}`;
}

function normalizeTransitionEntry(entry, basePath) {
  if (!entry?.id || !entry?.file) return null;
  return {
    ...entry,
    resolvedPath: resolveAssetPath(basePath, entry.file)
  };
}

// Only the native app serves the library. Browser previews and test servers
// would answer 404, which WebKit reports as a console error.
export function userTransitionLibraryServed(target = globalThis) {
  return typeof target?.webkit?.messageHandlers?.nativeApp?.postMessage === "function";
}

export function isUserTransitionId(id) {
  return String(id || "").startsWith(USER_TRANSITION_ID_PREFIX);
}

export function normalizeUserTransition(entry) {
  if (!/^[0-9a-f]{32}$/.test(String(entry?.id || "")) || typeof entry.file !== "string" || !entry.file) return null;
  return {
    id: `${USER_TRANSITION_ID_PREFIX}${entry.id}`,
    libraryId: entry.id,
    file: entry.file,
    resolvedPath: entry.file,
    label: String(entry.name || "Imported transition"),
    thumbnail: typeof entry.thumbnail === "string" ? entry.thumbnail : "",
    durationSeconds: Number(entry.durationSeconds) || 0,
    sourceDurationSeconds: Number(entry.sourceDurationSeconds) || Number(entry.durationSeconds) || 0,
    width: Number(entry.width) || 0,
    height: Number(entry.height) || 0,
    codec: String(entry.codec || ""),
    sourceCodec: String(entry.sourceCodec || ""),
    processing: String(entry.processing || ""),
    status: String(entry.status || "ok"),
    available: (entry.status || "ok") === "ok",
    enabled: entry.enabled !== false,
    source: "user",
    energy: ALL_ENERGY_TYPES,
    intensity: 0.7
  };
}

async function fetchJson(url) {
  const response = await fetch(url, { cache: "no-cache" });
  if (!response.ok) throw new Error(`${url} returned ${response.status}`);
  return response.json();
}

export function createVideoAssetManager({
  cyanescentManifest = DEFAULT_CYANESCENT_TRANSITION_MANIFEST,
  customManifest = DEFAULT_CUSTOM_TRANSITION_MANIFEST,
  cyanescentBasePath = "assets/bg/cyanescent_transitions",
  customBasePath = "assets/bg/transitions",
  userLibrary = DEFAULT_USER_TRANSITION_LIBRARY,
  logger = console
} = {}) {
  let cyanescentTransitions = [];
  let customTransitions = [];
  let userTransitions = [];
  let userTransitionsRevision = "";
  let userLoadPromise = null;
  let manifestLoadPromise = null;
  const videoObjectUrls = new Map();
  const userListeners = new Set();

  async function loadManifest(url, basePath) {
    const data = await fetchJson(url);
    if (!Array.isArray(data)) return [];
    return data
      .map((entry) => normalizeTransitionEntry(entry, basePath))
      .filter(Boolean);
  }

  // A failed refresh keeps the last good listing; a missing library is simply empty.
  function refreshUserTransitions() {
    if (!capabilityEnabled("videoTransitions") || !userTransitionLibraryServed()) {
      userTransitions = [];
      return Promise.resolve(userTransitions);
    }
    userLoadPromise = fetchJson(userLibrary)
      .then((data) => {
        userTransitions = (Array.isArray(data?.entries) ? data.entries : [])
          .map(normalizeUserTransition)
          .filter(Boolean);
        userTransitionsRevision = String(data?.revision || "");
      })
      .catch(() => {})
      .then(() => {
        for (const listener of userListeners) {
          try { listener(userTransitions); } catch (error) { logger.warn?.("My Transitions listener failed:", error); }
        }
        return userTransitions;
      });
    return userLoadPromise;
  }

  // The detached output document learns of library changes through the
  // revision carried in the shared video-transition options.
  function userTransitionsNeedSync(revision) {
    return Boolean(revision) && String(revision) !== userTransitionsRevision;
  }

  function syncUserTransitions(revision) {
    return userTransitionsNeedSync(revision) ? refreshUserTransitions() : Promise.resolve(userTransitions);
  }

  function onUserTransitionsChanged(listener) {
    userListeners.add(listener);
    return () => userListeners.delete(listener);
  }

  function playableUserTransitions() {
    return userTransitions.filter((entry) => entry.available && entry.enabled);
  }

  async function loadTransitionManifests() {
    if (!capabilityEnabled("videoTransitions")) return { cyanescentTransitions: [], customTransitions: [] };
    if (manifestLoadPromise) return manifestLoadPromise;
    manifestLoadPromise = Promise.allSettled([
      loadManifest(cyanescentManifest, cyanescentBasePath),
      loadManifest(customManifest, customBasePath),
      userLoadPromise || refreshUserTransitions()
    ]).then(([cyanescent, custom]) => {
      if (cyanescent.status === "fulfilled") {
        cyanescentTransitions = cyanescent.value;
      } else {
        logger.warn?.("Could not load Cyanescent transition manifest:", cyanescent.reason);
      }
      if (custom.status === "fulfilled") {
        customTransitions = custom.value;
      } else {
        logger.warn?.("Could not load custom transition manifest:", custom.reason);
      }
      return {
        cyanescentTransitions,
        customTransitions
      };
    });
    return manifestLoadPromise;
  }

  function transitionsForMode(mode = "auto", selectedIds = []) {
    if (!capabilityEnabled("videoTransitions")) return [];
    if (mode === "manual") {
      const enabled = new Set(Array.isArray(selectedIds) ? selectedIds : []);
      const manual = customTransitions.filter((entry) => enabled.has(entry.id));
      if (manual.length) return manual;
    }
    if (mode === "custom") {
      return customTransitions.length ? customTransitions : cyanescentTransitions;
    }
    const builtIn = cyanescentTransitions.length ? cyanescentTransitions : customTransitions;
    // With nothing playable in My Transitions, behave like Auto rather than
    // leaving the transition without a video.
    if (mode === "user") {
      const mine = playableUserTransitions();
      return mine.length ? mine : builtIn;
    }
    if (mode === "mixed") return [...builtIn, ...playableUserTransitions()];
    return builtIn;
  }

  function selectTransitionVideo({
    mode = "auto",
    energyType = "high-high",
    selectedTransitionIds = [],
    candidateIds = [],
    recentTransitionIds = [],
    random = Math.random
  } = {}) {
    const all = transitionsForMode(mode, selectedTransitionIds);
    if (!all.length) return null;

    const candidateSet = new Set(Array.isArray(candidateIds) ? candidateIds.map(String) : []);
    let candidates = candidateSet.size
      ? all.filter((entry) => candidateSet.has(String(entry.id)))
      : all;
    const energyMatches = candidates.filter((entry) => Array.isArray(entry.energy) && entry.energy.includes(energyType));
    if (energyMatches.length) candidates = energyMatches;

    // Older callers still get the previous short-history behaviour. The live
    // and offline transition paths pass candidateIds from the full cycle.
    if (!candidateSet.size) {
      const recent = new Set(Array.isArray(recentTransitionIds) ? recentTransitionIds : []);
      const lessRecent = candidates.filter((entry) => !recent.has(entry.id));
      if (lessRecent.length) candidates = lessRecent;
    }

    const totalWeight = candidates.reduce((sum, entry) => sum + Math.max(0.01, Number(entry.weight) || Number(entry.intensity) || 1), 0);
    let pick = random() * totalWeight;
    for (const entry of candidates) {
      pick -= Math.max(0.01, Number(entry.weight) || Number(entry.intensity) || 1);
      if (pick <= 0) return entry;
    }
    return candidates[candidates.length - 1] || null;
  }

  function transitionById(id) {
    if (!capabilityEnabled("videoTransitions")) return null;
    const key = String(id || "");
    if (!key) return null;
    // A clip chosen explicitly plays even when it is out of rotation, but a
    // missing or modified file is never handed to the player or exporter.
    if (isUserTransitionId(key)) return userTransitions.find((entry) => entry.id === key && entry.available) || null;
    return [...cyanescentTransitions, ...customTransitions].find((entry) => entry.id === key) || null;
  }

  async function objectUrlForVideo(path) {
    if (!path) return "";
    if (videoObjectUrls.has(path)) return videoObjectUrls.get(path);
    const response = await fetch(path);
    if (!response.ok) throw new Error(`${path} returned ${response.status}`);
    const url = URL.createObjectURL(await response.blob());
    videoObjectUrls.set(path, url);
    return url;
  }

  function releaseObjectUrls() {
    for (const url of videoObjectUrls.values()) URL.revokeObjectURL(url);
    videoObjectUrls.clear();
  }

  return {
    loadTransitionManifests,
    cyanescentTransitions: () => cyanescentTransitions,
    customTransitions: () => customTransitions,
    userTransitions: () => userTransitions,
    userTransitionsRevision: () => userTransitionsRevision,
    refreshUserTransitions,
    userTransitionsNeedSync,
    syncUserTransitions,
    onUserTransitionsChanged,
    transitionsForMode,
    selectTransitionVideo,
    transitionById,
    objectUrlForVideo,
    releaseObjectUrls
  };
}
