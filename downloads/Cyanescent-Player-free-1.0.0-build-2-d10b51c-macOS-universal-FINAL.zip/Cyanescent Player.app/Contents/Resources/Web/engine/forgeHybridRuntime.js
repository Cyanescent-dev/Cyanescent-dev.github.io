import { createPresetCalibration } from "../ui/presetCalibration.js";
import { createRenderTarget, deleteRenderTarget } from "./renderTargets.js";
import { createForgeBraids } from "./forgeHybridBraids.js";
import { createForgeCues } from "./forgeHybridCues.js";
import { createForgeCalligraphy } from "./forgeHybridCalligraphy.js";
import { forgeCalligraphyVertexSource, forgeCalligraphyFragmentSource } from "./forgeHybridCalligraphyShaders.js";
import {
  forgeCompositeSource, forgeExcitationSource,
  forgeParticleVertexSource, forgeParticleFragmentSource,
  forgeBraidVertexSource, forgeBraidFragmentSource
} from "./forgeHybridShaders.js";

const clamp = (value, low, high) => Math.min(high, Math.max(low, value));
const MAX_PACKETS = 900;
const EXCITATION_WIDTH = 160;
const EXCITATION_HEIGHT = 90;

export function forgeFramePair(timeSeconds, fps, frameCount, seamlessLoop = false) {
  const timeline = Math.max(0, timeSeconds * fps);
  const position = seamlessLoop ? timeline % frameCount : clamp(timeline, 0, frameCount - 1);
  const first = Math.floor(position);
  return { first, second: seamlessLoop ? (first + 1) % frameCount : Math.min(first + 1, frameCount - 1), mix: position - first };
}

export function forgePresentedFramePair(currentTime, presentedTime, fps, frameCount, seamlessLoop = false) {
  if (Number.isFinite(presentedTime) && presentedTime >= 0 &&
      Math.abs(currentTime - presentedTime) <= 2.5 / fps) {
    const frame = Math.round(presentedTime * fps);
    const first = seamlessLoop ? frame % frameCount : clamp(frame, 0, frameCount - 1);
    // The decoder holds this beauty frame until the next presentation. Mixing
    // toward a not-yet-visible camera frame can detach a signal by many pixels.
    return { first, second: first, mix: 0 };
  }
  return forgeFramePair(currentTime, fps, frameCount, seamlessLoop);
}

export function forgePlaybackTarget({ bpm, confidence = 1 }, authoredBPM, enabled = true) {
  if (!enabled || !Number.isFinite(bpm) || bpm < 70 || bpm > 220 || confidence < 0.35) return 1;
  return clamp(bpm / authoredBPM, 0.65, 1.5);
}

export function createForgeHybridRuntime({ getGl, program, programFrom, setAttribs, asset }) {
  const controls = {
    intensity: 1.5, packetAmount: 1.26, transportSpeed: 0.7,
    persistence: 0.45, propagation: 0.61, augmentationOpacity: 0.54,
    bpmLock: true, debug: 0, testBPM: 0, braidAmount: 0.66,
    braidsEnabled: true, packetsEnabled: true, calligraphyEnabled: true, calligraphyAmount: 1
  };
  const calibration = createPresetCalibration({
    presetId: 390, presetName: "Apollonian Physarum Genesis", controls, buildPanel: makePanel,
    clearPanel: () => { controlPanel = null; }
  });
  let active = false;
  let generation = 0;
  let video = null;
  let videoFrameCallbackId = 0;
  let callbackEpoch = 0;
  let lastCallbackAt = 0;
  let lastCallbackRearmAt = 0;
  let callbackRearms = 0;
  let presentationLag = 0;
  let memoryResets = 0;
  let lastUploadedVideoTime = -1;
  let videoTexture = null;
  let pendingVideoTexture = null;
  let pendingVideoFrame = -1;
  let pendingVideoVerified = false;
  let presentedVideoFrame = -1;
  let presentedFields = null;
  let frameCoherent = false;
  let videoUploads = 0;
  let videoUploadMaxMs = 0;
  let captureTarget = null;
  let captureCanvas = null;
  let outputWidth = 1;
  let outputHeight = 1;
  let compositeProgram = null;
  let excitationProgram = null;
  let particleProgram = null;
  let particleBuffer = null;
  let braidProgram = null;
  let braidBuffer = null;
  const braids = createForgeBraids(asset.fieldWidth, asset.fieldHeight);
  const cueMemory = createForgeCues();
  const calligraphy = createForgeCalligraphy(asset.fieldWidth, asset.fieldHeight);
  const additionalLayers = [
    { name: "calligraphy", enabled: "calligraphyEnabled", amount: "calligraphyAmount", debug: 9, module: calligraphy,
      vertex: forgeCalligraphyVertexSource, fragment: forgeCalligraphyFragmentSource, attributes: [4, 4, 2],
      uniforms: ["phase", "highs", "mids", "anticipation", "release", "releaseAge", "phrase"], program: null, buffer: null }
  ];
  const elementSwitches = { braidsEnabled: true, packetsEnabled: true, calligraphyEnabled: true };
  let elementFixture = "";
  let excitationTargets = null;
  let excitationRead = 0;
  let fieldSlots = null;
  let fieldCache = new Map();
  let fieldCanvas = null;
  let fieldContext = null;
  let controlPanel = null;
  let lastRenderAt = 0;
  let lastVideoTime = 0;
  let completedLoops = 0;
  let lastTempoBPM = 0;
  let tempoLowSeconds = 0;
  let targetRate = 1;
  let started = false;
  let waitingForBar = true;
  let playPending = false;
  let lastKick = 0;
  let lastKickAt = -Infinity;
  let lastSectionAt = -Infinity;
  let lastReleaseSerial = 0;
  let lastPhraseStep = -1;
  let lastJunctionScanFrame = -1;
  let junctions = [];
  let scheduled = [];
  let recentSignals = [];
  let packets = [];
  const packetVertices = new Float32Array(MAX_PACKETS * 6);
  const flowScratch = new Float32Array(3);
  const deposits = new Float32Array(8 * 4);
  const excitationPixels = new Uint8Array(EXCITATION_WIDTH * EXCITATION_HEIGHT * 4);
  const uniformLocations = new WeakMap();
  const timings = { videoUploadMs: 0, fieldMs: 0, excitationMs: 0, particlesMs: 0, braidsMs: 0, calligraphyMs: 0, frames: 0 };
  let lastReportedAt = 0;
  let lastLabelAt = 0;
  let loadErrors = 0;
  let maxKickObserved = 0;
  let signalsTriggered = 0;
  let depositsApplied = 0;
  let videoOnlyTrial = false;
  let fieldStarves = 0;
  let fieldPauses = 0;
  let fieldUploadMaxMs = 0;
  let fieldUploadSlowFrames = 0;
  let videoCallbacks = 0;
  let videoCallbackSkips = 0;
  let lastCallbackMediaTime = -1;
  const frameAlignment = { videoTime: 0, fieldFrames: [0, 1], fieldMix: 0 };

  function effectSnapshot() {
    return {
      braids: { ...braids.diagnostics, ...braids.state },
      effects: {
        calligraphy: { enabled: controls.calligraphyEnabled, ...calligraphy.diagnostics, ...calligraphy.state },
      },
      cues: { ...cueMemory.state }, controls: { ...controls }
    };
  }
  function source(kind, frame) {
    const pattern = kind === "density" ? asset.densityPattern : asset.flowPattern;
    return `${asset.assetRoot}/${pattern}${String(frame).padStart(6, "0")}.png`;
  }
  function texture(width = 1, height = 1, data = new Uint8Array([0, 0, 0, 255])) {
    const gl = getGl();
    const result = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, result);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
    return result;
  }
  function location(gl, shader, name) {
    let cache = uniformLocations.get(shader);
    if (!cache) { cache = new Map(); uniformLocations.set(shader, cache); }
    if (!cache.has(name)) cache.set(name, gl.getUniformLocation(shader, name));
    return cache.get(name);
  }
  function sampler(gl, shader, name, unit, value) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, value);
    gl.uniform1i(location(gl, shader, name), unit);
  }
  function makePanel() {
    const panel = document.createElement("details");
    panel.className = "forge-hybrid-controls";
    panel.innerHTML = `<summary>Forge controls</summary>
      <fieldset><legend>Network elements</legend>
      <label>Cytoplasmic Braids <input type="checkbox" data-control="braidsEnabled"></label>
      <label>Transport Packets <input type="checkbox" data-control="packetsEnabled"></label>
      <label>Spore Calligraphy <input type="checkbox" data-control="calligraphyEnabled"></label>
      </fieldset>
      <label>Augmentation <input type="range" data-control="intensity" min="0" max="1.5" step="0.01"></label>
      <label>Packets <input type="range" data-control="packetAmount" min="0" max="1.5" step="0.01"></label>
      <label>Cytoplasmic braids <input type="range" data-control="braidAmount" min="0" max="1.5" step="0.01"></label>
      <label>Transport speed <input type="range" data-control="transportSpeed" min="0" max="1.5" step="0.01"></label>
      <label>Persistence <input type="range" data-control="persistence" min="0" max="1" step="0.01"></label>
      <label>Propagation <input type="range" data-control="propagation" min="0" max="1" step="0.01"></label>
      <label>Layer opacity <input type="range" data-control="augmentationOpacity" min="0" max="1" step="0.01"></label>
      <label>BPM lock <input type="checkbox" data-control="bpmLock"></label>
      <label>Test BPM <select data-control="testBPM"><option value="0">Track</option><option value="140">140</option><option value="145">145</option><option value="150">150</option></select></label>
      <label>View <select data-control="debug"><option value="0">Beauty</option><option value="1">Density</option><option value="2">Flow</option><option value="3">Excitation</option><option value="4">Compare</option><option value="5">Packets</option><option value="6">Density alignment</option><option value="7">Braids only</option><option value="9">Spore calligraphy only</option></select></label>`;
    for (const input of panel.querySelectorAll("[data-control]")) {
      const name = input.dataset.control;
      if (input.type === "checkbox") input.checked = controls[name];
      else input.value = String(controls[name]);
      input.addEventListener("input", () => {
        controls[name] = input.type === "checkbox" ? input.checked : Number(input.value);
      });
    }
    document.body.appendChild(panel);
    controlPanel = panel;
    return panel;
  }
  function start() {
    if (active) return;
    active = true;
    const fixture = new URLSearchParams(window.location.search).get("fixture") || "";
    elementFixture = fixture.replace(/-t\d+(?:\.\d+)?$/, "");
    videoOnlyTrial = fixture === "forge-video-only";
    if (fixture === "forge-excitation") controls.debug = 3;
    if (fixture === "forge-compare") controls.debug = 4;
    if (fixture === "forge-packets") controls.debug = 5;
    if (fixture === "forge-align") controls.debug = 6;
    if (fixture === "forge-braids-only") controls.debug = 7;
    if (fixture === "forge-braids-compare") controls.debug = 4;
    if (fixture === "forge-off") controls.intensity = 0;
    const debugFixtures = { "forge-calligraphy": 9 };
    if (debugFixtures[elementFixture]) controls.debug = debugFixtures[elementFixture];
    if (elementFixture === "forge-elements-off") {
      for (const name of Object.keys(elementSwitches)) controls[name] = false;
    }
    generation += 1;
    started = false;
    waitingForBar = true;
    lastRenderAt = 0;
    lastVideoTime = 0;
    completedLoops = 0;
    lastTempoBPM = 0;
    tempoLowSeconds = 0;
    targetRate = 1;
    lastReleaseSerial = 0; lastPhraseStep = -1;
    maxKickObserved = signalsTriggered = depositsApplied = 0;
    fieldStarves = fieldPauses = fieldUploadSlowFrames = videoCallbacks = videoCallbackSkips = 0;
    fieldUploadMaxMs = 0;
    lastCallbackMediaTime = -1;
    lastCallbackAt = lastCallbackRearmAt = callbackRearms = memoryResets = presentationLag = 0;
    pendingVideoFrame = presentedVideoFrame = -1;
    pendingVideoVerified = frameCoherent = false;
    presentedFields = null;
    videoUploads = videoUploadMaxMs = 0;
    packets = [];
    braids.reset();
    calligraphy.reset(); cueMemory.reset();
    for (const name of Object.keys(elementSwitches)) elementSwitches[name] = controls[name];
    for (const key of Object.keys(timings)) timings[key] = 0;
    window.__forgeHybridFrameAlignment = frameAlignment;
    window.__forgeHybridEffectSnapshot = effectSnapshot;
    window.__forgeHybridCaptureSource = capturePresentedSource;
    scheduled = [];
    recentSignals = [];
    fieldCache = new Map();
    fieldCanvas = document.createElement("canvas");
    fieldCanvas.width = asset.fieldWidth;
    fieldCanvas.height = asset.fieldHeight;
    fieldContext = fieldCanvas.getContext("2d", { willReadFrequently: true });
    video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";
    video.loop = true;
    video.className = "forge-hybrid-video";
    const fixtureSeek = fixture.match(/-t(\d+(?:\.\d+)?)$/);
    if (fixtureSeek && /^forge-(?:calligraphy|elements|loop|callback-stall)/.test(elementFixture)) {
      const requested = clamp(Number(fixtureSeek[1]), 0, (asset.frameCount - 1) / asset.fps);
      video.onloadedmetadata = () => { if (active && video) video.currentTime = requested; };
    }
    document.body.appendChild(video);
    window.__forgeHybridVideo = video;
    video.src = encodeURI(`${asset.assetRoot}/${asset.video}`);
    video.load();
    video.onseeking = () => { if (active) { clearMemory(); resetVideoCallback(); } };
    video.onseeked = () => { if (active) resetVideoCallback(); };
    lastUploadedVideoTime = -1;
    resetVideoCallback();
    const gl = getGl();
    compositeProgram = program(forgeCompositeSource);
    excitationProgram = program(forgeExcitationSource);
    particleProgram = programFrom(forgeParticleVertexSource, forgeParticleFragmentSource, [[0, "aPacket"], [1, "aDirection"]]);
    braidProgram = programFrom(forgeBraidVertexSource, forgeBraidFragmentSource, [[0, "aPath"], [1, "aSignal"], [2, "aTube"]]);
    braidBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, braidBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, braids.vertices.byteLength, gl.DYNAMIC_DRAW);
    for (const layer of additionalLayers) {
      layer.program = programFrom(layer.vertex, layer.fragment);
      layer.buffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, layer.buffer);
      gl.bufferData(gl.ARRAY_BUFFER, layer.module.vertices.byteLength, gl.DYNAMIC_DRAW);
    }
    // The displayed beauty cannot be an independently advancing AVPlayerLayer.
    // Freeze decoder output and present it with the matching fields in WebGL.
    videoTexture = texture(asset.videoWidth, asset.videoHeight, null);
    pendingVideoTexture = texture(asset.videoWidth, asset.videoHeight, null);
    fieldSlots = [{ frame: -1, density: texture(asset.fieldWidth, asset.fieldHeight, null), flow: texture(asset.fieldWidth, asset.fieldHeight, null) },
      { frame: -1, density: texture(asset.fieldWidth, asset.fieldHeight, null), flow: texture(asset.fieldWidth, asset.fieldHeight, null) }];
    excitationTargets = [createRenderTarget(gl, EXCITATION_WIDTH, EXCITATION_HEIGHT),
      createRenderTarget(gl, EXCITATION_WIDTH, EXCITATION_HEIGHT)];
    for (const target of excitationTargets || []) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, EXCITATION_WIDTH, EXCITATION_HEIGHT);
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    excitationRead = 0;
    particleBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, particleBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, packetVertices.byteLength, gl.DYNAMIC_DRAW);
    window.__forgeHybridControls = controls;
    calibration.start();
    if (!videoOnlyTrial) {
      requestFrame(0);
      requestFrame(1);
      requestFrame(2);
    }
  }
  function stop() {
    if (!active) return;
    active = false;
    generation += 1;
    if (video) {
      if (videoFrameCallbackId && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(videoFrameCallbackId);
      videoFrameCallbackId = 0;
      video.pause();
      video.onloadedmetadata = null;
      video.onseeking = video.onseeked = null;
      callbackEpoch += 1;
      video.removeAttribute("src");
      video.load();
      video.remove();
      video = null;
    }
    window.__forgeHybridVideo = null;
    window.__forgeHybridEffectSnapshot = null;
    window.__forgeHybridCaptureSource = null;
    const gl = getGl();
    if (videoTexture) gl.deleteTexture(videoTexture);
    if (pendingVideoTexture) gl.deleteTexture(pendingVideoTexture);
    if (captureTarget) deleteRenderTarget(gl, captureTarget);
    captureTarget = captureCanvas = null;
    for (const slot of fieldSlots || []) {
      gl.deleteTexture(slot.density);
      gl.deleteTexture(slot.flow);
    }
    for (const target of excitationTargets || []) deleteRenderTarget(gl, target);
    if (particleBuffer) gl.deleteBuffer(particleBuffer);
    if (braidBuffer) gl.deleteBuffer(braidBuffer);
    for (const shader of [compositeProgram, excitationProgram, particleProgram, braidProgram]) if (shader) gl.deleteProgram(shader);
    braidProgram = braidBuffer = null;
    braids.reset();
    for (const layer of additionalLayers) {
      if (layer.program) gl.deleteProgram(layer.program);
      if (layer.buffer) gl.deleteBuffer(layer.buffer);
      layer.program = layer.buffer = null;
      layer.module.reset();
    }
    cueMemory.reset();
    videoTexture = compositeProgram = excitationProgram = particleProgram = particleBuffer = null;
    pendingVideoTexture = null;
    pendingVideoFrame = presentedVideoFrame = -1;
    presentedFields = null;
    frameCoherent = false;
    excitationTargets = fieldSlots = null;
    for (const entry of fieldCache.values()) {
      releaseFieldImages(entry);
    }
    fieldCache.clear();
    fieldContext = fieldCanvas = null;
    calibration.stop();
    controlPanel = null;
    window.__forgeHybridControls = null;
    window.__forgeHybridDiagnostics = null;
    window.__forgeHybridFrameAlignment = null;
  }
  function resetVideoCallback() {
    callbackEpoch += 1;
    if (!video) return;
    if (videoFrameCallbackId && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(videoFrameCallbackId);
    videoFrameCallbackId = 0;
    lastCallbackMediaTime = -1;
    lastCallbackAt = 0;
    lastCallbackRearmAt = performance.now();
    callbackRearms += 1;
    if (!video.requestVideoFrameCallback) return;
    const token = generation, epoch = callbackEpoch, owner = video;
    const onFrame = (_now, metadata) => {
      if (!active || generation !== token || epoch !== callbackEpoch || video !== owner) return;
      // Development fixture simulates WebKit abandoning callbacks while its
      // hardware-composited video continues. Normal playback never injects it.
      if (elementFixture === "forge-callback-stall" && cueMemory.state.seconds >= 3) return;
      videoCallbacks += 1;
      if (Number.isFinite(metadata?.mediaTime)) {
        if (lastCallbackMediaTime >= 0 && metadata.mediaTime - lastCallbackMediaTime > 1.5 / asset.fps) videoCallbackSkips += 1;
        lastCallbackMediaTime = metadata.mediaTime;
        lastCallbackAt = performance.now();
        captureVideoFrame(Math.round(metadata.mediaTime * asset.fps), true);
      }
      videoFrameCallbackId = owner.requestVideoFrameCallback(onFrame);
    };
    videoFrameCallbackId = owner.requestVideoFrameCallback(onFrame);
  }
  function captureVideoFrame(frame, verified) {
    if (!pendingVideoTexture || video.readyState < 2 || video.seeking) return;
    frame = asset.seamlessLoop ? ((frame % asset.frameCount) + asset.frameCount) % asset.frameCount
      : clamp(frame, 0, asset.frameCount - 1);
    if (frame === pendingVideoFrame || frame === presentedVideoFrame) return;
    const gl = getGl(), began = performance.now();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, pendingVideoTexture);
    // Keep the native decoder surface orientation during the GPU copy; the
    // beauty samplers flip UVs instead of forcing an upload-time pixel flip.
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    try {
      // Capture in the frame callback, before field uploads or the next render
      // tick. Two fixed textures keep the shown image immutable until promotion.
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
      pendingVideoFrame = frame;
      pendingVideoVerified = verified;
      lastUploadedVideoTime = video.currentTime;
      videoUploads++;
    } catch (error) {
      if (loadErrors++ < 3) console.error("Forge video texture upload failed:", error);
    }
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    const elapsed = performance.now() - began;
    timings.videoUploadMs += elapsed;
    videoUploadMaxMs = Math.max(videoUploadMaxMs, elapsed);
  }
  function capturePresentedSource() {
    if (!active || presentedVideoFrame < 0) return null;
    const gl = getGl();
    if (!captureTarget || captureTarget.width !== outputWidth || captureTarget.height !== outputHeight) {
      if (captureTarget) deleteRenderTarget(gl, captureTarget);
      captureTarget = createRenderTarget(gl, outputWidth, outputHeight);
      captureCanvas = document.createElement("canvas");
      captureCanvas.width = outputWidth; captureCanvas.height = outputHeight;
    }
    // Diagnostic readback of the very texture being shown, not drawImage(video)
    // of a separately advancing decoder/compositor. Ordinary playback never
    // creates this target or reads pixels back from the GPU.
    gl.bindFramebuffer(gl.FRAMEBUFFER, captureTarget.fb);
    gl.viewport(0, 0, outputWidth, outputHeight);
    setAttribs(compositeProgram);
    sampler(gl, compositeProgram, "uVideo", 0, videoTexture);
    bindFields(gl, compositeProgram, presentedFields, 0);
    sampler(gl, compositeProgram, "uExcitation", 5, excitationTargets[excitationRead].tex);
    gl.uniform1f(location(gl, compositeProgram, "uCanvasAspect"), outputWidth / outputHeight);
    gl.uniform1f(location(gl, compositeProgram, "uVideoAspect"), asset.videoWidth / asset.videoHeight);
    gl.uniform1f(location(gl, compositeProgram, "uMaster"), 0);
    gl.uniform1f(location(gl, compositeProgram, "uAugmentationOpacity"), 0);
    gl.uniform1f(location(gl, compositeProgram, "uVideoReady"), 1);
    gl.uniform1f(location(gl, compositeProgram, "uLoopFade"), 1);
    gl.uniform1i(location(gl, compositeProgram, "uDomVideo"), 0);
    gl.uniform1i(location(gl, compositeProgram, "uDebug"), 0);
    gl.disable(gl.BLEND);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    const pixels = new Uint8Array(outputWidth * outputHeight * 4);
    gl.readPixels(0, 0, outputWidth, outputHeight, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    const context = captureCanvas.getContext("2d"), image = context.createImageData(outputWidth, outputHeight);
    const rowBytes = outputWidth * 4;
    for (let row = 0; row < outputHeight; row++) {
      image.data.set(pixels.subarray(row * rowBytes, (row + 1) * rowBytes), (outputHeight - row - 1) * rowBytes);
    }
    context.putImageData(image, 0, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return captureCanvas;
  }
  function releaseFieldImages(entry) {
    for (const image of entry.images || []) {
      image.onload = image.onerror = null;
      image.src = "";
    }
  }
  function requestFrame(frame) {
    if (frame < 0 || frame >= asset.frameCount) return;
    const previous = fieldCache.get(frame);
    if (previous) {
      if (!previous.failedAt || previous.retries >= 4 ||
          performance.now() - previous.failedAt < Math.min(2000, 250 * 2 ** previous.retries)) return;
      releaseFieldImages(previous);
      fieldCache.delete(frame);
    }
    const entry = { frame, density: null, flow: null, images: [], ready: false, retries: previous ? previous.retries + 1 : 0, failedAt: 0 };
    fieldCache.set(frame, entry);
    const token = generation;
    for (const kind of ["density", "flow"]) {
      const image = new Image();
      entry.images.push(image);
      image.onload = () => {
        if (!active || token !== generation) return;
        if (image.naturalWidth !== asset.fieldWidth || image.naturalHeight !== asset.fieldHeight) {
          loadErrors += 1;
          console.error(`Forge ${kind} frame ${frame} has unexpected dimensions`);
          return;
        }
        entry[kind] = image;
        entry.ready = Boolean(entry.density && entry.flow);
      };
      image.onerror = () => {
        if (!active || token !== generation) return;
        loadErrors += 1;
        entry.failedAt = performance.now();
        if (entry.retries >= 4) console.error(`Could not load Forge ${kind} frame ${frame} after retries: ${image.src}`);
        else if (loadErrors < 4) console.warn(`Retrying Forge ${kind} frame ${frame}: ${image.src}`);
      };
      image.src = source(kind, frame);
    }
  }
  function prefetch(frame) {
    if (asset.seamlessLoop) {
      for (let offset = 0; offset <= 6; offset += 1) requestFrame((frame + offset) % asset.frameCount);
    } else {
      for (let index = frame; index <= Math.min(asset.frameCount - 1, frame + 6); index += 1) requestFrame(index);
    }
    for (const [index, entry] of fieldCache) {
      const ahead = (index - frame + asset.frameCount) % asset.frameCount;
      const behind = (frame - index + asset.frameCount) % asset.frameCount;
      const keep = asset.seamlessLoop ? ahead <= 8 || behind <= 2 : index >= frame - 2 && index <= frame + 8;
      if (!keep) {
        releaseFieldImages(entry);
        fieldCache.delete(index);
      }
    }
  }
  function uploadField(slot, entry) {
    const startedAt = performance.now();
    const gl = getGl();
    for (const kind of ["density", "flow"]) {
      fieldContext.clearRect(0, 0, asset.fieldWidth, asset.fieldHeight);
      fieldContext.drawImage(entry[kind], 0, 0);
      entry[`${kind}Pixels`] = fieldContext.getImageData(0, 0, asset.fieldWidth, asset.fieldHeight).data;
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, slot[kind]);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, fieldCanvas);
    }
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    slot.frame = entry.frame;
    const elapsed = performance.now() - startedAt;
    fieldUploadMaxMs = Math.max(fieldUploadMaxMs, elapsed);
    if (elapsed > 8) fieldUploadSlowFrames += 1;
  }
  function ensureFieldPair(first, second) {
    const a = fieldCache.get(first);
    const b = fieldCache.get(second);
    if (!a?.ready || !b?.ready) return null;
    const desired = first === second ? [first] : [first, second];
    for (const frame of desired) {
      if (fieldSlots.some((slot) => slot.frame === frame)) continue;
      const slot = fieldSlots.find((candidate) => !desired.includes(candidate.frame));
      if (!slot) return null;
      uploadField(slot, fieldCache.get(frame));
    }
    return {
      first: fieldSlots.find((slot) => slot.frame === first),
      second: fieldSlots.find((slot) => slot.frame === second), a, b
    };
  }
  function bindFields(gl, shader, pair, mix) {
    sampler(gl, shader, "uDensity0", 1, pair?.first.density || fieldSlots[0].density);
    sampler(gl, shader, "uDensity1", 2, pair?.second.density || fieldSlots[0].density);
    sampler(gl, shader, "uFlow0", 3, pair?.first.flow || fieldSlots[0].flow);
    sampler(gl, shader, "uFlow1", 4, pair?.second.flow || fieldSlots[0].flow);
    gl.uniform1f(location(gl, shader, "uFieldMix"), pair ? mix : 0);
  }
  function fieldChannel(pair, mix, kind, channel, x, y) {
    const px = clamp(x * asset.fieldWidth - 0.5, 0, asset.fieldWidth - 1);
    const py = clamp(y * asset.fieldHeight - 0.5, 0, asset.fieldHeight - 1);
    const ix = Math.floor(px), iy = Math.floor(py), fx = px - ix, fy = py - iy;
    const jx = Math.min(ix + 1, asset.fieldWidth - 1), jy = Math.min(iy + 1, asset.fieldHeight - 1);
    const i00 = (iy * asset.fieldWidth + ix) * 4 + channel;
    const i10 = (iy * asset.fieldWidth + jx) * 4 + channel;
    const i01 = (jy * asset.fieldWidth + ix) * 4 + channel;
    const i11 = (jy * asset.fieldWidth + jx) * 4 + channel;
    const first = kind === "density" ? pair.a.densityPixels : pair.a.flowPixels;
    const second = kind === "density" ? pair.b.densityPixels : pair.b.flowPixels;
    const a = first[i00] * (1 - fx) * (1 - fy) + first[i10] * fx * (1 - fy) + first[i01] * (1 - fx) * fy + first[i11] * fx * fy;
    if (mix <= 0 || first === second) return a;
    const b = second[i00] * (1 - fx) * (1 - fy) + second[i10] * fx * (1 - fy) + second[i01] * (1 - fx) * fy + second[i11] * fx * fy;
    return a + (b - a) * mix;
  }
  function sampleDensity(pair, mix, x, y) {
    return pair ? fieldChannel(pair, mix, "density", 0, x, y) / 255 : 0;
  }
  function sampleFlow(pair, mix, x, y) {
    flowScratch[0] = (fieldChannel(pair, mix, "flow", 0, x, y) - 128) / 127;
    flowScratch[1] = (fieldChannel(pair, mix, "flow", 1, x, y) - 128) / 127;
    flowScratch[2] = fieldChannel(pair, mix, "flow", 2, x, y) / 255;
    return flowScratch;
  }
  function attachPacket(packet, pair, mix) {
    const d = sampleDensity(pair, mix, packet.x, packet.y);
    const flow = sampleFlow(pair, mix, packet.x, packet.y);
    if (d >= 0.14 && flow[2] >= 0.28) return true;
    const tx = packet.headingX, ty = packet.headingY, norm = Math.hypot(tx, ty);
    if (norm < 0.2) return false;
    // A small perpendicular correction only. Camera motion is not encoded in
    // cytoplasmic flow: detach when the visible strand has moved away.
    for (let step = 1; step <= 3; step++) for (let sign = -1; sign <= 1; sign += 2) {
      const x = packet.x - ty / norm * sign * step * 0.5 / asset.fieldWidth;
      const y = packet.y + tx / norm * sign * step * 0.5 / asset.fieldHeight;
      if (sampleDensity(pair, mix, x, y) >= 0.16 && sampleFlow(pair, mix, x, y)[2] >= 0.30) {
        packet.x = x; packet.y = y; return true;
      }
    }
    return false;
  }
  function scanJunctions(pair, frame) {
    if (!pair?.a.densityPixels || (lastJunctionScanFrame >= 0 && Math.abs(frame - lastJunctionScanFrame) < 10)) return;
    lastJunctionScanFrame = frame;
    const pixels = pair.a.densityPixels;
    const candidates = [];
    const width = asset.fieldWidth;
    const height = asset.fieldHeight;
    // Coarse, bounded local analysis at 3 Hz. High support in several directions
    // is enough to evoke junctions without attempting graph reconstruction.
    for (let y = 8; y < height - 8; y += 5) {
      for (let x = 8; x < width - 8; x += 5) {
        const center = pixels[(y * width + x) * 4] / 255;
        if (center < 0.26) continue;
        let arms = 0;
        for (const [dx, dy] of [[-5, 0], [5, 0], [0, -5], [0, 5]]) {
          arms += pixels[((y + dy) * width + x + dx) * 4] > 35 ? 1 : 0;
        }
        if (arms < 3) continue;
        candidates.push({ x: x / width, y: y / height, score: center * arms + Math.random() * 0.28 });
      }
    }
    candidates.sort((left, right) => right.score - left.score);
    junctions = candidates.slice(0, 96);
  }
  function chooseJunction(nearPoint = null) {
    if (!junctions.length) return null;
    if (nearPoint) {
      const nearby = junctions.filter((j) => {
        const dx = (j.x - nearPoint.x) * 1.7778;
        const dy = j.y - nearPoint.y;
        return dx * dx + dy * dy < 0.055 && dx * dx + dy * dy > 0.0005;
      });
      if (nearby.length) return nearby[Math.floor(Math.random() * nearby.length)];
    }
    return junctions[Math.floor(Math.random() * Math.min(junctions.length, 40))];
  }
  function signal(point, strength, now, cascade = true) {
    if (!point) return;
    signalsTriggered += 1;
    recentSignals.push({ x: point.x, y: point.y, strength, until: now + 1400 });
    scheduled.push({ point, strength, due: now, cascade: false });
    if (cascade && Math.random() < 0.72 * controls.propagation) {
      const next = chooseJunction(point);
      if (next) scheduled.push({ point: next, strength: strength * 0.57, due: now + 180 + Math.random() * 520, cascade: false });
    }
  }
  function events(now, audio, music, cues, pair, frame) {
    scanJunctions(pair, frame);
    const kick = clamp(Number(audio?.kickPulse) || 0, 0, 1);
    maxKickObserved = Math.max(maxKickObserved, kick);
    if (kick > 0.54 && lastKick <= 0.54 && now - lastKickAt > 220) {
      lastKickAt = now;
      signal(chooseJunction(), 0.36 + kick * 0.62, now);
      // Existing transport receives an impulse, creating a contraction wave.
      for (const packet of packets) packet.impulse = Math.max(packet.impulse, kick * (packet.band === 0 ? 0.75 : 0.24));
    }
    lastKick = kick;
    if ((music?.sectionChange || 0) > 0.64 && now - lastSectionAt > 2400) {
      lastSectionAt = now;
      signal(chooseJunction(), 0.68, now);
    }
    if (cues.releaseSerial !== lastReleaseSerial) {
      lastReleaseSerial = cues.releaseSerial;
      const point = chooseJunction();
      signal(point, 0.80, now);
      if (point) {
        const next = chooseJunction(point);
        if (next) scheduled.push({ point: next, strength: 0.62, due: now + 340 });
      }
    }
    const phraseStep = Math.floor(cues.beat / 8);
    if (phraseStep !== lastPhraseStep) {
      if (lastPhraseStep >= 0 && cues.energy > 0.25) {
        // Larger musical boundaries launch longer local conversations. Each
        // response is delayed and still must sit on current visible support.
        const strength = phraseStep % 4 === 0 ? 0.58 : phraseStep % 2 === 0 ? 0.40 : 0.24;
        signal(chooseJunction(), strength * (0.45 + cues.energy * 0.55), now);
      }
      lastPhraseStep = phraseStep;
    }
    deposits.fill(0);
    let count = 0;
    for (let index = 0; index < scheduled.length;) {
      const event = scheduled[index];
      if (event.due > now || count >= 8) { index += 1; continue; }
      if (sampleDensity(pair, 0, event.point.x, event.point.y) < 0.14 || sampleFlow(pair, 0, event.point.x, event.point.y)[2] < 0.28) { scheduled.splice(index, 1); continue; }
      const base = count * 4;
      deposits[base] = event.point.x;
      deposits[base + 1] = 1 - event.point.y;
      deposits[base + 2] = event.strength;
      deposits[base + 3] = 0.018 + event.strength * 0.014;
      scheduled.splice(index, 1);
      depositsApplied += 1;
      count += 1;
    }
    if (scheduled.length > 40) scheduled = scheduled.slice(-40);
    recentSignals = recentSignals.filter((event) => event.until > now);
  }
  function newPacket(pair, mix, energy) {
    let x = Math.random(), y = Math.random();
    if (recentSignals.length && Math.random() < 0.44) {
      const source = recentSignals[Math.floor(Math.random() * recentSignals.length)];
      x = clamp(source.x + (Math.random() - 0.5) * 0.095, 0, 1);
      y = clamp(source.y + (Math.random() - 0.5) * 0.095, 0, 1);
    }
    for (let attempt = 0; attempt < 12; attempt += 1) {
      const d = sampleDensity(pair, mix, x, y);
      if (Math.random() < d * d * 1.8 && d > 0.16 && sampleFlow(pair, mix, x, y)[2] > 0.30) break;
      x = Math.random(); y = Math.random();
    }
    if (sampleDensity(pair, mix, x, y) < 0.16 || sampleFlow(pair, mix, x, y)[2] < 0.30) return null;
    return { x, y, life: 1, age: 0, duration: 1.8 + Math.random() * 3.6,
      speed: 0.010 + Math.random() * 0.017, impulse: 0,
      headingX: 0, headingY: 0, band: Math.floor(Math.random() * 3), reverse: Math.random(),
      power: (0.42 + Math.random() * 0.58 + energy * 0.18) * (0.55 + energy * 0.45) };
  }
  function advancePackets(pair, mix, dt, audio, smooth, music, cues) {
    const energy = clamp(cues.energy || 0, 0, 1);
    const bass = cues.bass, mids = cues.mids, highs = cues.highs;
    const release = cues.release;
    const quiet = cues.breakdown * (1 - release), gathering = cues.anticipation * (1 - release);
    const targetCount = Math.min(MAX_PACKETS, Math.floor((16 + Math.pow(energy, 1.3) * 650) *
      (1 - quiet * 0.84) * (1 + gathering * 0.3 + release * 0.55) * controls.packetAmount));
    const spawnBudget = Math.min(16, Math.max(0, targetCount - packets.length));
    for (let i = 0; i < spawnBudget; i++) {
      const packet = newPacket(pair, mix, energy);
      if (packet && packets.length < MAX_PACKETS) packets.push(packet);
    }
    let count = 0;
    for (let index = 0; index < packets.length;) {
      const p = packets[index];
      if (!attachPacket(p, pair, mix)) { packets[index] = packets[packets.length - 1]; packets.pop(); continue; }
      const flow = sampleFlow(pair, mix, p.x, p.y), confidence = flow[2];
      const norm = Math.hypot(flow[0], flow[1]);
      if (norm < 0.2) { packets[index] = packets[packets.length - 1]; packets.pop(); continue; }
      const inward = quiet > 0.45 && p.reverse < 0.42 ? -1 : 1;
      const fx = flow[0] / norm * inward, fy = flow[1] / norm * inward;
      p.headingX += (fx - p.headingX) * (1 - Math.exp(-dt * 14));
      p.headingY += (fy - p.headingY) * (1 - Math.exp(-dt * 14));
      const bandDrive = p.band === 0 ? bass : p.band === 1 ? mids : highs;
      const speed = p.speed * 2.4 * controls.transportSpeed * (0.45 + bandDrive * 1.5 + p.impulse) *
        (1 - gathering * 0.68) * (1 - quiet * 0.72) * (1 + release * 1.45) * confidence;
      const oldX = p.x, oldY = p.y;
      p.x += p.headingX * speed * dt;
      p.y += p.headingY * speed * dt * asset.fieldWidth / asset.fieldHeight;
      if (!attachPacket(p, pair, mix)) { p.x = oldX; p.y = oldY; p.life -= dt * 4; }
      p.impulse *= Math.exp(-dt * 3.5);
      p.age += dt;
      if (p.age > p.duration || index >= targetCount + 32) p.life -= dt * 0.85;
      if (p.x < 0 || p.x > 1 || p.y < 0 || p.y > 1 || p.life <= 0) {
        packets[index] = packets[packets.length - 1]; packets.pop(); continue;
      }
      const fadeIn = Math.min(1, p.age * 3.2), offset = count * 6;
      packetVertices[offset] = p.x; packetVertices[offset + 1] = p.y;
      packetVertices[offset + 2] = p.life * fadeIn;
      packetVertices[offset + 3] = p.power * (0.45 + bandDrive * 0.85 + release * 0.45);
      packetVertices[offset + 4] = p.headingX; packetVertices[offset + 5] = p.headingY;
      count++; index++;
    }
    return count;
  }
  function play() {
    if (!video || !video.paused || playPending) return;
    playPending = true;
    video.play().catch((error) => {
      if (active && loadErrors < 4) console.warn("Forge video playback could not start:", error);
    }).finally(() => { playPending = false; });
  }
  function clearMemory() {
    memoryResets += 1;
    const gl = getGl();
    for (const target of excitationTargets || []) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, EXCITATION_WIDTH, EXCITATION_HEIGHT);
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    packets.length = 0;
    braids.reset();
    calligraphy.reset();
    recentSignals.length = 0;
    scheduled.length = 0;
    junctions.length = 0; lastJunctionScanFrame = -1; lastKick = 0;
    pendingVideoFrame = presentedVideoFrame = -1;
    presentedFields = null;
    frameCoherent = false;
  }
  function updateTempo(tempo, dt) {
    const measured = controls.testBPM > 0 ? { bpm: controls.testBPM, confidence: 1 } : tempo;
    const bpm = Number(measured?.bpm) || 0;
    const confidence = Number(measured?.confidence ?? 1);
    if (!controls.bpmLock) {
      targetRate = 1;
      lastTempoBPM = 0;
      tempoLowSeconds = 0;
    } else if (!bpm || confidence < 0.35) {
      tempoLowSeconds += dt;
      if (tempoLowSeconds > 5) { targetRate = 1; lastTempoBPM = 0; }
    } else if (!lastTempoBPM || Math.abs(bpm - lastTempoBPM) >= 0.8) {
      tempoLowSeconds = 0;
      lastTempoBPM = bpm;
      targetRate = forgePlaybackTarget({ bpm, confidence }, asset.authoredBPM);
    } else {
      tempoLowSeconds = 0;
    }
    const rate = video.playbackRate;
    const next = rate + clamp(targetRate - rate, -dt * 0.14, dt * 0.14);
    if (Math.abs(next - rate) > 0.0002) video.playbackRate = next;
  }
  function simulate(gl, pair, mix, dt) {
    const next = 1 - excitationRead;
    gl.bindFramebuffer(gl.FRAMEBUFFER, excitationTargets[next].fb);
    gl.viewport(0, 0, EXCITATION_WIDTH, EXCITATION_HEIGHT);
    setAttribs(excitationProgram);
    sampler(gl, excitationProgram, "uPrevious", 0, excitationTargets[excitationRead].tex);
    bindFields(gl, excitationProgram, pair, mix);
    gl.uniform2f(location(gl, excitationProgram, "uTexel"), 1 / EXCITATION_WIDTH, 1 / EXCITATION_HEIGHT);
    gl.uniform1f(location(gl, excitationProgram, "uDelta"), dt);
    gl.uniform1f(location(gl, excitationProgram, "uDecay"), 0.18 + (1 - controls.persistence) * 0.72);
    gl.uniform1f(location(gl, excitationProgram, "uPropagation"), controls.propagation);
    gl.uniform1f(location(gl, excitationProgram, "uTransport"), controls.transportSpeed);
    gl.uniform4fv(location(gl, excitationProgram, "uDeposits[0]"), deposits);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    excitationRead = next;
  }
  function updateElementSwitches(cues) {
    if (elementFixture === "forge-elements-switch") {
      const phase = Math.floor(cues.seconds / 3) % 8;
      const names = Object.keys(elementSwitches);
      for (let i = 0; i < names.length; i++) controls[names[i]] = phase === i + 1 || phase === 5 || phase === 7;
    }
    for (const name of Object.keys(elementSwitches)) {
      if (elementSwitches[name] === controls[name]) continue;
      elementSwitches[name] = controls[name];
      if (!controls[name]) {
        if (name === "braidsEnabled") braids.reset();
        if (name === "packetsEnabled") packets.length = 0;
        if (name === "calligraphyEnabled") calligraphy.reset();
      }
      const input = controlPanel?.querySelector(`[data-control="${name}"]`);
      if (input) input.checked = controls[name];
    }
  }
  function drawAdditionalLayer(layer, { gl, width, height, pair, mix, currentTime, dt, audio, smooth, music, cues, domVideo }) {
    const began = performance.now();
    const count = layer.module.update({ fields: pair, fieldMix: mix, videoTime: currentTime,
      dt, audio, bands: smooth, music, cues, amount: controls[layer.amount] });
    if (count > 0) {
      const shader = layer.program;
      gl.useProgram(shader);
      gl.bindBuffer(gl.ARRAY_BUFFER, layer.buffer);
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, layer.module.vertices, 0, count * layer.module.stride);
      let offset = 0;
      for (let i = 0; i < layer.attributes.length; i++) {
        gl.enableVertexAttribArray(i);
        gl.vertexAttribPointer(i, layer.attributes[i], gl.FLOAT, false, layer.module.stride * 4, offset);
        offset += layer.attributes[i] * 4;
      }
      sampler(gl, shader, "uVideo", 0, videoTexture);
      bindFields(gl, shader, pair, mix);
      gl.uniform2f(location(gl, shader, "uFieldSize"), asset.fieldWidth, asset.fieldHeight);
      gl.uniform1f(location(gl, shader, "uCanvasAspect"), width / Math.max(1, height));
      gl.uniform1f(location(gl, shader, "uVideoAspect"), asset.videoWidth / asset.videoHeight);
      for (const key of layer.uniforms) {
        gl.uniform1f(location(gl, shader, `u${key[0].toUpperCase()}${key.slice(1)}`), layer.module.state[key]);
      }
      gl.uniform1f(location(gl, shader, "uMaster"), controls.intensity);
      gl.uniform1f(location(gl, shader, "uOpacity"), controls.augmentationOpacity);
      gl.uniform1f(location(gl, shader, "uOutputWidth"), width);
      gl.uniform1i(location(gl, shader, "uCompare"), controls.debug === 4 ? 1 : 0);
      gl.enable(gl.BLEND);
      if (domVideo) gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE, gl.ONE, gl.ONE);
      else gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      gl.drawArrays(gl.TRIANGLES, 0, count);
      gl.disable(gl.BLEND);
      for (let i = 1; i < layer.attributes.length; i++) gl.disableVertexAttribArray(i);
    }
    timings[`${layer.name}Ms`] += performance.now() - began;
  }
  function render({ target, width, height, tempo, playing = true, music, audio, smooth, lookahead, now }) {
    if (!active) start();
    const gl = getGl();
    const dt = playing ? (lastRenderAt ? clamp((now - lastRenderAt) / 1000, 0, 0.05) : 1 / 60) : 0;
    lastRenderAt = now;
    updateTempo(tempo, dt);
    const ready = video.readyState >= 2 && video.videoWidth === asset.videoWidth && video.videoHeight === asset.videoHeight;
    const domVideo = false;
    // Leave the decoder element renderable beneath the opaque canvas so WebKit
    // continues delivering frame callbacks. Only its captured GPU image is seen.
    video.style.display = "block";
    outputWidth = width; outputHeight = height;
    const currentTime = ready ? Number(video.currentTime) || 0 : 0;
    if (ready && currentTime < lastVideoTime - 2) {
      completedLoops += 1;
      clearMemory();
      resetVideoCallback();
    }
    lastVideoTime = currentTime;
    const callbackFresh = lastCallbackMediaTime >= 0 && !video.seeking &&
      Math.abs(currentTime - lastCallbackMediaTime) <= 2.5 / asset.fps;
    if (callbackFresh && !video.paused) {
      presentationLag += (clamp(currentTime - lastCallbackMediaTime, 0, 2 / asset.fps) - presentationLag) * 0.12;
    }
    if (video.requestVideoFrameCallback && !callbackFresh && playing && started &&
        now - Math.max(lastCallbackAt, lastCallbackRearmAt) > 250) resetVideoCallback();
    const fallbackTime = Math.max(0, currentTime - presentationLag);
    if (ready && !callbackFresh && (presentedVideoFrame < 0 ||
        Math.abs(currentTime - lastUploadedVideoTime) >= 0.8 / asset.fps)) {
      // A stalled callback must not freeze the video. The clock cannot certify
      // this decoded sample's identity, so show beauty alone until it recovers.
      captureVideoFrame(Math.floor(fallbackTime * asset.fps), false);
    }
    const requestedFrame = pendingVideoFrame >= 0 ? pendingVideoFrame
      : presentedVideoFrame >= 0 ? presentedVideoFrame : Math.floor(fallbackTime * asset.fps);
    if (!videoOnlyTrial) prefetch(requestedFrame);
    const fieldStarted = performance.now();
    const nextPair = videoOnlyTrial ? null : ensureFieldPair(requestedFrame, requestedFrame);
    const waitingForFields = !videoOnlyTrial && !nextPair;
    if (pendingVideoFrame >= 0 && (nextPair || videoOnlyTrial)) {
      const previousTexture = videoTexture;
      videoTexture = pendingVideoTexture;
      pendingVideoTexture = previousTexture;
      presentedVideoFrame = pendingVideoFrame;
      pendingVideoFrame = -1;
      presentedFields = nextPair;
      frameCoherent = pendingVideoVerified;
    }
    const pairInfo = { first: Math.max(0, presentedVideoFrame), second: Math.max(0, presentedVideoFrame), mix: 0 };
    const fieldTime = pairInfo.first / asset.fps;
    const pair = frameCoherent ? presentedFields : null;
    frameAlignment.videoTime = fieldTime;
    frameAlignment.mediaClockTime = currentTime;
    frameAlignment.fieldFrames[0] = pairInfo.first;
    frameAlignment.fieldFrames[1] = pairInfo.second;
    frameAlignment.fieldMix = 0;
    frameAlignment.presentedVideoFrame = presentedVideoFrame;
    frameAlignment.sourceVideoFrame = presentedVideoFrame;
    frameAlignment.videoPresentation = "gpu";
    frameAlignment.frameCoherent = frameCoherent;
    if (ready && started && !pair) fieldStarves += 1;
    timings.fieldMs += performance.now() - fieldStarted;
    if (!playing && video && !video.paused) video.pause();
    if (ready && !waitingForFields && playing) {
      if (!started) {
        const beat = Number(music?.absoluteBeat);
        const canAlign = controls.bpmLock && tempo?.bpm > 0 && Number.isFinite(beat) && beat >= 0;
        const phase = canAlign ? ((beat % asset.beatsPerBar) + asset.beatsPerBar) % asset.beatsPerBar : 0;
        if (!canAlign || !waitingForBar || phase < 0.12 || phase > asset.beatsPerBar - 0.10) {
          started = true;
          waitingForBar = false;
          play();
        }
      } else play();
    } else if (started && !video.paused) {
      // A missing field pair cannot drift away from its displayed video state.
      fieldPauses += 1;
      video.pause();
    }
    const cues = cueMemory.update({ dt: started && pair ? dt : 0, music, audio, bands: smooth, lookahead, tempo, authoredBPM: asset.authoredBPM });
    updateElementSwitches(cues);
    if (pair && dt > 0) {
      events(now, audio, music, cues, pair, pairInfo.first);
      const simulationStarted = performance.now();
      simulate(gl, pair, pairInfo.mix, dt);
      timings.excitationMs += performance.now() - simulationStarted;
    } else deposits.fill(0);
    const loopDuration = asset.durationBeats * 60 / asset.authoredBPM;
    const endFade = clamp((loopDuration - currentTime) / 0.42, 0, 1);
    const startFade = completedLoops ? clamp(currentTime / 0.42, 0, 1) : 1;
    const loopFade = asset.seamlessLoop ? 1 : endFade * startFade;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    setAttribs(compositeProgram);
    sampler(gl, compositeProgram, "uVideo", 0, videoTexture);
    bindFields(gl, compositeProgram, pair, pairInfo.mix);
    sampler(gl, compositeProgram, "uExcitation", 5, excitationTargets[excitationRead].tex);
    gl.uniform1f(location(gl, compositeProgram, "uCanvasAspect"), width / Math.max(1, height));
    gl.uniform1f(location(gl, compositeProgram, "uVideoAspect"), asset.videoWidth / asset.videoHeight);
    gl.uniform1f(location(gl, compositeProgram, "uMaster"), pair ? controls.intensity : 0);
    gl.uniform1f(location(gl, compositeProgram, "uAugmentationOpacity"), controls.augmentationOpacity);
    gl.uniform1f(location(gl, compositeProgram, "uVideoReady"), presentedVideoFrame >= 0 ? 1 : 0);
    gl.uniform1f(location(gl, compositeProgram, "uLoopFade"), loopFade);
    gl.uniform1i(location(gl, compositeProgram, "uDomVideo"), domVideo ? 1 : 0);
    gl.uniform1i(location(gl, compositeProgram, "uDebug"), pair ? controls.debug : 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    if (pair && ready && started && controls.packetsEnabled && (controls.debug === 0 || controls.debug === 4 || controls.debug === 5) && playing) {
      const particleStarted = performance.now();
      const count = advancePackets(pair, pairInfo.mix, dt, audio, smooth, music, cues);
      gl.useProgram(particleProgram);
      gl.bindBuffer(gl.ARRAY_BUFFER, particleBuffer);
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, packetVertices, 0, count * 6);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 24, 0);
      gl.enableVertexAttribArray(1);
      gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 24, 16);
      sampler(gl, particleProgram, "uVideo", 0, videoTexture);
      bindFields(gl, particleProgram, pair, pairInfo.mix);
      sampler(gl, particleProgram, "uExcitation", 5, excitationTargets[excitationRead].tex);
      gl.uniform1f(location(gl, particleProgram, "uCanvasAspect"), width / Math.max(1, height));
      gl.uniform1f(location(gl, particleProgram, "uVideoAspect"), asset.videoWidth / asset.videoHeight);
      gl.uniform1f(location(gl, particleProgram, "uPixelScale"), Math.max(0.75, height / 720));
      gl.uniform1f(location(gl, particleProgram, "uMaster"), controls.intensity);
      gl.uniform1f(location(gl, particleProgram, "uOpacity"), controls.augmentationOpacity);
      gl.uniform1f(location(gl, particleProgram, "uOutputWidth"), width);
      gl.uniform2f(location(gl, particleProgram, "uOutputSize"), width, height);
      gl.uniform1i(location(gl, particleProgram, "uCompare"), controls.debug === 4 ? 1 : 0);
      gl.enable(gl.BLEND);
      if (domVideo) gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE, gl.ONE, gl.ONE);
      else gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      gl.drawArrays(gl.POINTS, 0, count);
      gl.disable(gl.BLEND);
      gl.disableVertexAttribArray(1);
      timings.particlesMs += performance.now() - particleStarted;
    }
    if (pair && ready && started && playing && controls.braidsEnabled && controls.braidAmount > 0 &&
        (controls.debug === 0 || controls.debug === 4 || controls.debug === 7)) {
      const braidStarted = performance.now();
      const count = braids.update({ fields: pair, fieldMix: pairInfo.mix, videoTime: fieldTime,
        dt, audio, bands: smooth, music, cues, amount: controls.braidAmount, speed: controls.transportSpeed });
      gl.useProgram(braidProgram);
      gl.bindBuffer(gl.ARRAY_BUFFER, braidBuffer);
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, braids.vertices, 0, count * braids.stride);
      for (let attribute = 0; attribute < 3; attribute++) gl.enableVertexAttribArray(attribute);
      gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 40, 0);
      gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 40, 16);
      gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 40, 32);
      sampler(gl, braidProgram, "uVideo", 0, videoTexture);
      bindFields(gl, braidProgram, pair, pairInfo.mix);
      gl.uniform2f(location(gl, braidProgram, "uFieldSize"), asset.fieldWidth, asset.fieldHeight);
      gl.uniform1f(location(gl, braidProgram, "uCanvasAspect"), width / Math.max(1, height));
      gl.uniform1f(location(gl, braidProgram, "uVideoAspect"), asset.videoWidth / asset.videoHeight);
      for (const key of ["phase", "weave", "bass", "mids", "highs", "energy", "anticipation", "release", "releaseAge", "phrase", "breakdown", "kick", "phrase8", "phrase16", "phrase32"]) {
        gl.uniform1f(location(gl, braidProgram, `u${key[0].toUpperCase()}${key.slice(1)}`), braids.state[key]);
      }
      gl.uniform1f(location(gl, braidProgram, "uMaster"), controls.intensity);
      gl.uniform1f(location(gl, braidProgram, "uOpacity"), controls.augmentationOpacity);
      gl.uniform1f(location(gl, braidProgram, "uOutputWidth"), width);
      gl.uniform1i(location(gl, braidProgram, "uCompare"), controls.debug === 4 ? 1 : 0);
      gl.enable(gl.BLEND);
      if (domVideo) gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE, gl.ONE, gl.ONE);
      else gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      gl.drawArrays(gl.TRIANGLES, 0, count);
      gl.disable(gl.BLEND);
      gl.disableVertexAttribArray(1);
      gl.disableVertexAttribArray(2);
      timings.braidsMs += performance.now() - braidStarted;
    }
    if (pair && ready && started && playing) {
      for (const layer of additionalLayers) {
        if (controls[layer.enabled] && controls[layer.amount] > 0 &&
            (controls.debug === 0 || controls.debug === 4 || controls.debug === layer.debug)) {
          drawAdditionalLayer(layer, { gl, width, height, pair, mix: pairInfo.mix, currentTime: fieldTime, dt, audio, smooth, music, cues, domVideo });
        }
      }
    }
    timings.frames += 1;
    if (controlPanel && now - lastLabelAt > 400) {
      controlPanel.querySelector("summary").textContent =
        `Forge · ${video.playbackRate.toFixed(3)}× · field ${pair ? pairInfo.first : "loading"} · ${packets.length} packets`;
      lastLabelAt = now;
    }
    if (now - lastReportedAt > (document.body.classList.contains("preset-trial-role") ? 2000 : 5000)) {
      const quality = video.getVideoPlaybackQuality?.();
      let excitationMax = null;
      let excitationActive = null;
      if (controlPanel?.open || document.body.classList.contains("preset-trial-role")) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, excitationTargets[excitationRead].fb);
        gl.readPixels(0, 0, EXCITATION_WIDTH, EXCITATION_HEIGHT, gl.RGBA, gl.UNSIGNED_BYTE, excitationPixels);
        excitationMax = 0;
        excitationActive = 0;
        for (let index = 0; index < excitationPixels.length; index += 4) {
          excitationMax = Math.max(excitationMax, excitationPixels[index]);
          if (excitationPixels[index] > 2) excitationActive += 1;
        }
      }
      window.__forgeHybridDiagnostics = {
        videoTime: currentTime, displayedVideoTime: fieldTime, fieldFrames: [pairInfo.first, pairInfo.second],
        fieldMix: pairInfo.mix, fieldReady: Boolean(pair),
        playbackRate: video.playbackRate, targetRate, playing, paused: video.paused,
        started, completedLoops, memoryResets, callbackRearms, callbackFresh, presentationLag, packets: packets.length, domVideo,
        videoPresentation: "gpu", presentedVideoFrame, frameCoherent, videoUploads, videoUploadMaxMs,
        braids: { ...braids.diagnostics, ...braids.state },
        effects: {
            calligraphy: { enabled: controls.calligraphyEnabled, ...calligraphy.diagnostics, ...calligraphy.state },
          },
        controls: { ...controls }, cues: { ...cues },
        debug: controls.debug,
        appliedDebug: gl.getUniform(compositeProgram, location(gl, compositeProgram, "uDebug")),
        maxKickObserved, junctions: junctions.length, signalsTriggered, depositsApplied,
        excitationMax, excitationActive,
        droppedVideoFrames: quality?.droppedVideoFrames ?? 0,
        totalVideoFrames: quality?.totalVideoFrames ?? 0,
        loadErrors, fieldStarves, fieldPauses, fieldUploadMaxMs, fieldUploadSlowFrames,
        videoCallbacks, videoCallbackSkips,
        averageCpuMs: Object.fromEntries(["videoUploadMs", "fieldMs", "excitationMs", "particlesMs", "braidsMs", "calligraphyMs"]
          .map((key) => [key, timings[key] / Math.max(1, timings.frames)]))
      };
      if (document.body.classList.contains("preset-trial-role")) {
        window.webkit?.messageHandlers?.nativeApp?.postMessage({
          command: "logConsole", type: "info",
          text: `[ForgeHybrid] ${JSON.stringify(window.__forgeHybridDiagnostics)}`
        });
      }
      lastReportedAt = now;
    }
  }
  return { render, stop, isActive: () => active, controls };
}
