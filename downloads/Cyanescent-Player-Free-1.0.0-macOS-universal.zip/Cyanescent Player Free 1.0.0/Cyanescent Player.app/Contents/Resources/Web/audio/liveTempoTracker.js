// Online BPM + phase tracker for live audio input (external line-in/mic, or
// the Scion synth monitor). File playback gets its beat grid for free from
// the offline AudioAnalysisTimeline (see features.js AudioAnalysisTimeline.
// detectTempo / getBeatInfo) which can see the whole track. This module is
// the live analogue of that pair: it has no lookahead and no whole-track
// statistics, so it works off a short rolling history of the kick-onset
// envelope instead, re-scoring itself every second or so and only "locking"
// once several windows agree.
//
// The output shape of getLiveBeatInfo() deliberately mirrors
// AudioAnalysisTimeline.getBeatInfo() so callers (musicAware.js) can treat
// either source the same way.

import { clamp01, smoothstepJs, mixJs } from "../utils/math.js";

// Kick-onset ring buffer. 25Hz keeps the autocorrelation search cheap while
// still resolving phase to a few percent of a beat at trance/psy tempos.
const SAMPLE_RATE_HZ = 25;
const SAMPLE_INTERVAL_SECONDS = 1 / SAMPLE_RATE_HZ;
const BUFFER_SECONDS = 10;
const BUFFER_CAPACITY = Math.round(BUFFER_SECONDS * SAMPLE_RATE_HZ);
const MIN_WARMUP_SECONDS = 6;

// Same BPM range the offline detectTempo() searches - this app's presets are
// tuned for that range, and narrowing the search keeps the live version fast
// and less prone to half/double-tempo confusion.
const MIN_BPM = 112;
const MAX_BPM = 172;
const COARSE_STEP_BPM = 1.0;
const REFINE_RANGE_BPM = 3;
const REFINE_STEP_BPM = 0.25;
const PHASE_STEP_SAMPLES = 0.25;

const ANALYSIS_INTERVAL_MS = 1200;
const MIN_SCORE_TO_CONSIDER = 0.05;
const MIN_CONFIDENCE_TO_LOCK = 0.22;
const LOCK_STREAK_REQUIRED = 3;
const LOCK_BPM_TOLERANCE = 1.5;
const RELOCK_BPM_TOLERANCE = 2.5;
const RELOCK_MISMATCH_STREAK = 3;

// Per-frame PLL-style phase correction, applied on top of the coarse
// re-analysis above so the beat grid stays snapped to individual kicks
// between search ticks instead of only correcting once a second.
const PHASE_NUDGE_GAIN = 0.06;
const PHASE_NUDGE_MAX_ERROR_FRACTION = 0.14;
const KICK_ONSET_THRESHOLD = 0.35;
const KICK_NUDGE_MIN_INTERVAL_MS = 60;

export function createLiveTempoTrackerState() {
  return {
    buffer: new Float32Array(BUFFER_CAPACITY),
    timestamps: new Float64Array(BUFFER_CAPACITY),
    writeIndex: 0,
    filled: 0,
    sampleAccumulatorSeconds: 0,
    lastUpdateAt: null,
    lastAnalysisAt: 0,
    lastKickNudgeAt: 0,
    candidateBpm: 0,
    candidateStreak: 0,
    mismatchStreak: 0,
    locked: false,
    bpm: 0,
    beatDuration: 0,
    phaseAnchorMs: 0,
    confidence: 0,
    // True while this lock came from engageSyntheticClock() (Scion mode)
    // rather than real kick-onset analysis - see updateLiveTempoTracker.
    syntheticClock: false
  };
}

export function resetLiveTempoTracker(state) {
  if (!state) return createLiveTempoTrackerState();
  state.buffer.fill(0);
  state.timestamps.fill(0);
  state.writeIndex = 0;
  state.filled = 0;
  state.sampleAccumulatorSeconds = 0;
  state.lastUpdateAt = null;
  state.lastAnalysisAt = 0;
  state.lastKickNudgeAt = 0;
  state.candidateBpm = 0;
  state.candidateStreak = 0;
  state.mismatchStreak = 0;
  state.locked = false;
  state.bpm = 0;
  state.beatDuration = 0;
  state.phaseAnchorMs = 0;
  state.confidence = 0;
  state.syntheticClock = false;
  return state;
}

function pushSample(state, value, timestampMs) {
  state.buffer[state.writeIndex] = value;
  state.timestamps[state.writeIndex] = timestampMs;
  state.writeIndex = (state.writeIndex + 1) % state.buffer.length;
  state.filled = Math.min(state.buffer.length, state.filled + 1);
}

function linearBufferWithTimestamps(state) {
  const n = state.filled;
  const capacity = state.buffer.length;
  const start = (state.writeIndex - n + capacity) % capacity;
  const values = new Float32Array(n);
  const timestamps = new Float64Array(n);
  for (let i = 0; i < n; i += 1) {
    const index = (start + i) % capacity;
    values[i] = state.buffer[index];
    timestamps[i] = state.timestamps[index];
  }
  return { values, timestamps };
}

function sampleAt(values, position) {
  if (!values.length) return 0;
  const clamped = Math.max(0, Math.min(values.length - 1, position));
  const low = Math.floor(clamped);
  const high = Math.min(values.length - 1, low + 1);
  return mixJs(values[low], values[high], clamped - low);
}

// Comb-filter style scoring, adapted from AudioAnalysisTimeline.detectTempo's
// scoreCandidate: for a candidate bpm, slide a phase across one beat interval
// and measure how consistently the onset envelope peaks on-beat versus at
// the half-beat offbeat position. Operates on a short in-memory snapshot of
// the ring buffer rather than the whole track.
function scoreCandidate(values, sampleRateHz, bpm) {
  const interval = (60 / bpm) * sampleRateHz;
  if (interval < 2 || values.length < interval * 3) return { bpm, score: -Infinity, phase: 0 };
  let bestPhase = 0;
  let bestScore = -Infinity;
  for (let phase = 0; phase < interval; phase += PHASE_STEP_SAMPLES) {
    let onbeat = 0;
    let offbeat = 0;
    let count = 0;
    for (let position = phase + interval; position < values.length; position += interval) {
      const current = sampleAt(values, position);
      const previous = sampleAt(values, position - interval);
      const half = sampleAt(values, position - interval * 0.5);
      onbeat += current * 0.70 + Math.min(current, previous) * 0.30;
      offbeat += half;
      count += 1;
    }
    if (count < 2) continue;
    const onAvg = onbeat / count;
    const offAvg = offbeat / count;
    const score = onAvg - offAvg * 0.35;
    if (score > bestScore) {
      bestScore = score;
      bestPhase = phase;
    }
  }
  return { bpm, score: bestScore, phase: bestPhase };
}

function searchTempo(values, sampleRateHz) {
  let best = { bpm: 0, score: -Infinity, phase: 0 };
  let second = { bpm: 0, score: -Infinity, phase: 0 };
  for (let bpm = MIN_BPM; bpm <= MAX_BPM; bpm += COARSE_STEP_BPM) {
    const candidate = scoreCandidate(values, sampleRateHz, bpm);
    if (candidate.score > best.score) {
      second = best;
      best = candidate;
    } else if (candidate.score > second.score) {
      second = candidate;
    }
  }
  const refineMin = Math.max(MIN_BPM, best.bpm - REFINE_RANGE_BPM);
  const refineMax = Math.min(MAX_BPM, best.bpm + REFINE_RANGE_BPM);
  for (let bpm = refineMin; bpm <= refineMax; bpm += REFINE_STEP_BPM) {
    const candidate = scoreCandidate(values, sampleRateHz, bpm);
    if (candidate.score > best.score) best = candidate;
  }
  const separation = Math.max(0, best.score - (second.score || 0));
  const confidence = clamp01(Math.max(0, best.score) * 1.6 + separation * 2.2);
  return { ...best, confidence };
}

// Shifts `candidate` by whole beat-duration multiples so it lands as close as
// possible to `reference`. Anchors that are "the same" beat alignment but
// several beats apart numerically must be reconciled this way before they
// can be blended - otherwise mixing them directly would produce garbage.
function alignAnchor(reference, candidate, beatDurationMs) {
  if (!beatDurationMs) return candidate;
  const diff = candidate - reference;
  const cycles = Math.round(diff / beatDurationMs);
  return candidate - cycles * beatDurationMs;
}

function unlock(state) {
  state.locked = false;
  state.mismatchStreak = 0;
  state.candidateStreak = 0;
}

function runAnalysis(state) {
  const { values, timestamps } = linearBufferWithTimestamps(state);
  if (values.length < MIN_WARMUP_SECONDS * SAMPLE_RATE_HZ) return;
  const result = searchTempo(values, SAMPLE_RATE_HZ);
  if (!Number.isFinite(result.score) || result.score < MIN_SCORE_TO_CONSIDER) {
    state.confidence *= 0.7;
    if (state.locked && state.confidence < 0.12) unlock(state);
    return;
  }

  const avgIntervalMs = (timestamps[timestamps.length - 1] - timestamps[0]) / Math.max(1, timestamps.length - 1);
  const anchorMs = timestamps[0] + result.phase * avgIntervalMs;

  if (!state.locked) {
    if (state.candidateStreak > 0 && Math.abs(result.bpm - state.candidateBpm) <= LOCK_BPM_TOLERANCE) {
      state.candidateStreak += 1;
      state.candidateBpm = mixJs(state.candidateBpm, result.bpm, 0.4);
    } else {
      state.candidateBpm = result.bpm;
      state.candidateStreak = 1;
    }
    state.confidence = result.confidence;
    if (state.candidateStreak >= LOCK_STREAK_REQUIRED && result.confidence >= MIN_CONFIDENCE_TO_LOCK) {
      state.locked = true;
      state.bpm = state.candidateBpm;
      state.beatDuration = 60 / state.bpm;
      state.phaseAnchorMs = anchorMs;
      state.mismatchStreak = 0;
    }
    return;
  }

  const deviation = Math.abs(result.bpm - state.bpm);
  state.confidence = mixJs(state.confidence, result.confidence, 0.35);
  if (deviation <= LOCK_BPM_TOLERANCE) {
    state.mismatchStreak = 0;
    const beatDurationMsBeforeUpdate = state.beatDuration * 1000;
    const alignedAnchor = alignAnchor(state.phaseAnchorMs, anchorMs, beatDurationMsBeforeUpdate);
    state.phaseAnchorMs = mixJs(state.phaseAnchorMs, alignedAnchor, 0.25);
    state.bpm = mixJs(state.bpm, result.bpm, 0.25);
    state.beatDuration = 60 / state.bpm;
  } else if (deviation <= RELOCK_BPM_TOLERANCE) {
    // Ambiguous but not wildly off - hold the current lock and let the
    // per-frame phase nudge below absorb small timing error instead of
    // churning the lock on a single noisy window.
    state.mismatchStreak = 0;
  } else {
    state.mismatchStreak += 1;
    if (state.mismatchStreak >= RELOCK_MISMATCH_STREAK) {
      unlock(state);
      state.candidateBpm = result.bpm;
      state.candidateStreak = 1;
    }
  }
}

// Fine-grained proportional phase correction: when a strong kick lands close
// to a predicted beat boundary, nudge the anchor a little toward it. Hits
// that land far from any predicted boundary (hi-hats, snares, room noise)
// are ignored rather than allowed to drag the phase toward the offbeat.
function nudgePhase(state, now, strength) {
  const beatDurationMs = state.beatDuration * 1000;
  if (!beatDurationMs) return;
  const beatFloat = (now - state.phaseAnchorMs) / beatDurationMs;
  const phase = beatFloat - Math.floor(beatFloat);
  const error = phase <= 0.5 ? phase : phase - 1;
  if (Math.abs(error) > PHASE_NUDGE_MAX_ERROR_FRACTION) return;
  state.phaseAnchorMs += error * beatDurationMs * PHASE_NUDGE_GAIN * clamp01(strength);
}

// Scion mode has no reliable rhythmic kick to lock onto (see
// scionBiofeedback.js), so instead of running the analysis below at all,
// force-lock this tracker to a stable synthetic BPM. getLiveBeatInfo() then
// produces beatPhase/beatIndex/phrasePulse exactly as it would for a real
// detected tempo - existing callers and presets need no changes at all.
// The anchor is set once (the moment the clock engages) and left alone, so
// phase keeps advancing smoothly from wall-clock time between calls, the
// same way a real lock's phaseAnchorMs is stable between re-analyses.
function engageSyntheticClock(state, bpm, now) {
  if (state.locked && state.syntheticClock && state.bpm === bpm) return;
  state.locked = true;
  state.bpm = bpm;
  state.beatDuration = 60 / bpm;
  state.phaseAnchorMs = now;
  state.confidence = 1;
  state.syntheticClock = true;
  state.candidateBpm = bpm;
  state.candidateStreak = LOCK_STREAK_REQUIRED;
  state.mismatchStreak = 0;
}

export function updateLiveTempoTracker({ state, bands, now = performance.now(), active = true, syntheticBpm = 0 } = {}) {
  if (!state) return state;
  const previousAt = state.lastUpdateAt ?? now;
  const elapsedSeconds = Math.max(0, Math.min(0.25, (now - previousAt) / 1000));
  state.lastUpdateAt = now;
  if (!active) return state;

  if (syntheticBpm > 0) {
    engageSyntheticClock(state, syntheticBpm, now);
    return state;
  }
  if (state.syntheticClock) {
    // Leaving Scion mode: drop the synthetic lock cleanly and let real
    // analysis start over from scratch, rather than treating 145 as a
    // legitimately-detected tempo to refine.
    resetLiveTempoTracker(state);
    state.lastUpdateAt = now;
  }

  const onsetValue = Math.max(0, Math.min(1, Number(bands?.kick) || 0));
  state.sampleAccumulatorSeconds += elapsedSeconds;
  // Subtract (not reset) the interval so leftover time carries into the next
  // frame - resetting to zero would throw away that remainder every tick and
  // quietly settle onto whatever cadence the caller's frame rate happens to
  // divide into, instead of the intended SAMPLE_RATE_HZ. The while loop
  // catches up (with correctly backdated timestamps) if a frame stalls for
  // longer than one sample interval, e.g. a backgrounded tab.
  while (state.sampleAccumulatorSeconds >= SAMPLE_INTERVAL_SECONDS) {
    state.sampleAccumulatorSeconds -= SAMPLE_INTERVAL_SECONDS;
    pushSample(state, onsetValue, now - state.sampleAccumulatorSeconds * 1000);
  }

  if (
    state.locked
    && onsetValue > KICK_ONSET_THRESHOLD
    && now - state.lastKickNudgeAt > KICK_NUDGE_MIN_INTERVAL_MS
  ) {
    nudgePhase(state, now, onsetValue);
    state.lastKickNudgeAt = now;
  }

  const bufferSeconds = state.filled / SAMPLE_RATE_HZ;
  if (bufferSeconds >= MIN_WARMUP_SECONDS && now - state.lastAnalysisAt >= ANALYSIS_INTERVAL_MS) {
    state.lastAnalysisAt = now;
    runAnalysis(state);
  }

  return state;
}

function nextLoopBoundary(anchorMs, now, beatDuration) {
  const loopBeats = [8, 16, 32];
  let best = null;
  for (const beats of loopBeats) {
    const loopDurationMs = beatDuration * beats * 1000;
    if (!loopDurationMs) continue;
    const sinceAnchor = now - anchorMs;
    const index = Math.floor(sinceAnchor / loopDurationMs) + 1;
    const timeMs = anchorMs + index * loopDurationMs;
    if (!best || timeMs < best.timeMs - 0.5 || (Math.abs(timeMs - best.timeMs) <= 0.5 && beats > best.beats)) {
      best = { timeMs, beats };
    }
  }
  return best;
}

// Mirrors AudioAnalysisTimeline.getBeatInfo()'s shape so callers don't need
// to know whether the beat grid came from offline analysis or from here.
//
// phraseOffsetBeats shifts only the 8/16/32-beat phrase grid, not the raw
// beat/bpm fields. The beat anchor this tracker locks onto is arbitrary -
// it's just wherever the first confidently-detected kick happened to be, not
// necessarily beat 0 of an actual musical phrase. beatPhase itself doesn't
// care (any beat is as good as any other for mod-1 phase), but the phrase
// grid does: liveStructureTracker.js resolves phraseOffsetBeats separately
// by watching for real structural events, and callers pass it in here once
// resolved so the loop-boundary math lines up with the track's actual
// phrases instead of wherever this listening session happened to start.
export function getLiveBeatInfo(state, now = performance.now(), phraseOffsetBeats = 0) {
  if (!state?.locked || !state.bpm) return null;
  const beatDuration = state.beatDuration || 60 / state.bpm;
  const beatFloat = Math.max(0, (now - state.phaseAnchorMs) / 1000 / beatDuration);
  const beatPhase = beatFloat - Math.floor(beatFloat);
  const phraseAnchorMs = state.phaseAnchorMs + phraseOffsetBeats * beatDuration * 1000;
  const phraseBeatFloat = Math.max(0, (now - phraseAnchorMs) / 1000 / beatDuration);
  const loopProgress = (beats) => {
    const value = phraseBeatFloat / beats;
    return value - Math.floor(value);
  };
  const boundaryPulse = (beats) => {
    const progress = loopProgress(beats);
    const distance = Math.min(progress, 1 - progress);
    return smoothstepJs(0.17, 0.0, distance);
  };
  const next = nextLoopBoundary(phraseAnchorMs, now, beatDuration);
  return {
    bpm: state.bpm,
    beatDuration,
    beatPhase,
    beatIndex: Math.floor(beatFloat),
    phrase8Progress: loopProgress(8),
    phrase16Progress: loopProgress(16),
    phrase32Progress: loopProgress(32),
    phrasePulse: Math.max(boundaryPulse(8) * 0.55, boundaryPulse(16) * 0.78, boundaryPulse(32)),
    nextLoopTime: next?.timeMs ?? null,
    nextLoopBeats: next?.beats ?? null,
    nextLoopSeconds: next ? Math.max(0, (next.timeMs - now) / 1000) : 0,
    confidence: state.confidence,
    locked: true
  };
}
