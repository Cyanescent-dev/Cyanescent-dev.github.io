import { validateMusicPlaylistState } from './musicPlaylistState.js';

export function createMusicPlaylistRPC(nativeApp, target = window) {
  const pending = new Map();
  target.__musicPlaylistResponse = response => {
    const request = pending.get(response.requestId);
    if (!request) return;
    pending.delete(response.requestId); clearTimeout(request.timer);
    if (response.error && !response.conflict) request.reject(new Error(response.error));
    else request.resolve(response);
  };
  return (action, args = {}) => new Promise((resolve, reject) => {
    const requestId = crypto.randomUUID();
    const timer = setTimeout(() => { pending.delete(requestId); reject(new Error('Native music playlist storage did not respond. Your session remains available.')); }, 30000);
    pending.set(requestId, {resolve,reject,timer});
    nativeApp.postMessage({command:'musicPlaylistRequest',requestId,action,...args});
  });
}

export function createMusicPlaylistPersistence({store, queue, player, request, notify, getDefaultPlaylistId = () => null, target = window}) {
  let revision = 'none', dirty = false, initializing = true, blocked = false, epoch = 0, inFlight = null;
  let restoringSelection = false;
  let firstRun = false, lastSaved = '', lastRecovery = '', saveError = null, warning = '';
  const recoveryId = crypto.randomUUID();
  const pendingImport = () => {
    const native = target.__pendingNativeTracks;
    return Boolean((Array.isArray(native) ? native.length : native?.tracks?.length) || target.__pendingPlayerFiles?.length);
  };
  const report = (message, reload = false) => notify?.(message, reload);
  async function pump() {
    if (initializing || !dirty) return;
    if (inFlight) { await inFlight; return pump(); }
    const state = store.snapshot(), serialized = JSON.stringify(state);
    dirty = false;
    if (serialized === (blocked ? lastRecovery : lastSaved)) { saveError = null; return; }
    const preserving = blocked;
    inFlight = request(preserving ? 'preserve' : 'save', {state,expectedRevision:revision,recoveryId}).then(result => {
      saveError = null;
      if (result.conflict) {
        blocked = true; lastRecovery = serialized; report(result.error,true);
      } else if (preserving) {
        lastRecovery = serialized;
        report(`Shared saving is paused. Your latest edits are safe in ${result.recoveryPath}. Reload saved playlists to resume shared saving.`,true);
      } else {
        revision = result.revision; lastSaved = serialized;
        const temporary = state.playlists.some(list => list.entries.some(entry => !entry.reference));
        report(temporary ? 'Some tracks have no durable file reference. They will need Locate File after restart.' : warning);
      }
    }).catch(error => {
      dirty = true; blocked = true; saveError = error;
      report(`Music playlists could not be saved: ${error.message}`,true);
    });
    await inFlight;
    inFlight = null;
    // A primary-save failure gets one recovery-copy attempt; a recovery failure stops.
    if (dirty && (!saveError || !preserving)) await pump();
  }
  store.subscribe((_snapshot, operation) => {
    if (!(restoringSelection && ['activate','relink'].includes(operation))) epoch++;
    dirty = true;
    if (!initializing) warning = '';
    if (!initializing) void pump();
  });
  async function initialize(reload = false) {
    initializing = true;
    const startedAt = epoch;
    let overlappingRace = false;
    try {
      const loaded = await request('load');
      revision = loaded.revision;
      lastSaved = loaded.state ? JSON.stringify(loaded.state) : '';
      warning = loaded.warning || '';
      firstRun = !loaded.state;
      if (loaded.state) {
        validateMusicPlaylistState(loaded.state);
        const entries = loaded.state.playlists.flatMap(list => list.entries);
        const resolved = await request('resolve',{entries:entries.map(({id,reference})=>({id,reference}))});
        const userChanged = epoch !== startedAt;
        overlappingRace = userChanged && loaded.state.playlists.some(list => store.state.playlists.some(local => local.id === list.id));
        // A deliberate import/edit while native restoration was pending must survive it.
        if (!userChanged) player.stopForPlaylistRestore?.();
        const restored = JSON.parse(JSON.stringify(loaded.state));
        const defaultId = !reload && !userChanged ? getDefaultPlaylistId() : null;
        if (restored.playlists.some(list => list.id === defaultId)) restored.selectedPlaylistId = defaultId;
        store.hydrate(restored,resolved.tracks,userChanged);
        queue.renderQueue(); queue.updateRepeatButton();
        queue.syncShuffleButton?.();
        if (!userChanged) {
          const selected = store.playlist();
          const index = selected.entries.findIndex(entry => entry.id === selected.selectedTrackEntryId);
          const track = store.tracks()[index];
          if (track?.url && !track.unavailable && !pendingImport()) {
            restoringSelection = true;
            try { await player.loadTrackAt(index,false,selected.id,{prepareOnly:true,shouldContinue:()=>epoch === startedAt && !pendingImport()}); }
            catch (error) { warning = `Playlists restored; the selected file could not load. Use Locate File. ${error.message}`; }
            finally { restoringSelection = false; }
          }
        }
        dirty = userChanged || JSON.stringify(store.snapshot()) !== JSON.stringify(loaded.state);
      }
      blocked = overlappingRace;
      if (overlappingRace) warning = 'Playlists changed while reloading. Local edits will be preserved separately; reload again to resume shared saving.';
      report(warning,overlappingRace);
    } catch (error) {
      blocked = true; firstRun = false;
      report(`Music playlists could not be restored: ${error.message}`,true);
    } finally {
      initializing = false;
      if (dirty) await pump();
    }
    return {firstRun,allowDefaultFolder:firstRun && epoch === startedAt && !store.state.playlists.some(list=>list.entries.length)};
  }
  let ready = initialize();
  target.__flushMusicPlaylists = async () => { await ready; await pump(); if (inFlight) await inFlight; if (saveError) throw saveError; };
  return {ready, shouldLoadDefaultFolder: () => firstRun && !blocked && epoch === 0, flush:target.__flushMusicPlaylists,
    async reload() { await target.__flushMusicPlaylists(); ready = initialize(true); return ready; },
    async resolveEntry(entryId) {
      const entry = store.state.playlists.flatMap(list => list.entries).find(item => item.id === entryId);
      if (!entry) throw new Error('Track was removed from the playlist.');
      const result = await request('resolve',{entries:[{id:entryId,reference:entry.reference}]});
      const track = result.tracks?.find(item => item.entryId === entryId);
      if (!track?.url || track.unavailable) {
        const message = track?.error || 'Music file is unavailable. Use Locate File.';
        store.markUnavailable(entryId,message); queue.renderQueue();
        throw new Error(message);
      }
      store.relink(entryId,track); queue.renderQueue();
    },
    async locate(entryId) {
      try {
        const result = await request('locate');
        if (result.track) { store.relink(entryId,result.track); queue.renderQueue(); }
      } catch(error) { report(`Could not locate music file: ${error.message}`); }
    }
  };
}
