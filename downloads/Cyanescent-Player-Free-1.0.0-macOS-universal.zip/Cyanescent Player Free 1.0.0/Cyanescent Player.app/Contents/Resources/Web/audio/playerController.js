import { prepareSeekableSource } from "./seekableSource.js";
import {
  createBrowserAudioTracks,
  loadAudioElementSource,
  registerNativePlayerQueueCallbacks,
  waitForAudioCanPlay
} from "./playerSources.js";

export function createPlayerController({
  ui,
  playerQueueController,
  isAudioFileName,
  ensurePlayer,
  ensureAudioContext,
  setupPlayerAnalyser,
  playPlayerAudioWithFade,
  applyPlayerVolume,
  currentPlayerVolume,
  analyzeLoadedTrack,
  resetLookaheadState,
  visualTransitions,
  waveformController,
  onTrackSourceReset,
  updateWaveformProgress,
  updateTrackTimeDisplay,
  nativeAppBridge,
  stopInputStream,
  setMonitoringInput,
  setPlayerMode,
  clearAnalyserBuffers,
  incrementAnalysisGeneration,
  setAnalysisTimeline,
  setAnalysisPending,
  currentAnalysisGeneration,
  setStatus,
  setDiagnostic,
  reportFeedback,
  registerNativeCallbacks = true,
  acceptNativeTracks = () => true,
  resolveTrack,
  isReady = () => window.__cyanescentFullAppReady
} = {}) {
  let preparedSource = null;
  let trackLoadRequest = 0;
  let restoringRequest = null;
  let playbackIntent = false;
  let handledMediaErrorRequest = null;
  let pendingNativeAutoplay = false;
  let nativeAutoplayInProgress = false;

  function reportAudioImportDiagnostic(stage, details = {}) {
    const nativeApp = nativeAppBridge?.();
    if (!nativeApp) return;
    let serialized = "{}";
    try { serialized = JSON.stringify(details); } catch (error) {}
    nativeApp.postMessage({
      command: "audioImportDiagnostic",
      text: `stage=${stage} details=${serialized}`
    });
  }

  function reportAutoplayBlocked(error) {
    setStatus?.("player blocked");
    setDiagnostic?.(`Autoplay blocked: ${error.name || "Error"} ${error.message || ""}`.trim());
    reportFeedback?.('Playback could not start. Press Play to try again.');
    console.error(error);
  }

  function releaseObjectUrls() {
    playerQueueController.releaseObjectUrls();
  }

  async function autoplayLoadedTrackFromFinder() {
    const audio = ensurePlayer?.();
    if (!pendingNativeAutoplay || nativeAutoplayInProgress || !audio || !audio.paused) return;
    const request = trackLoadRequest;
    const stillCurrent = () => request === trackLoadRequest && audio.__cyanescentLoadRequest === request;
    nativeAutoplayInProgress = true;
    try {
      setStatus?.("player starting");
      setDiagnostic?.("Starting Finder-opened track...");
      await waitForAudioCanPlay(audio);
      if (!stillCurrent()) return;
      for (let attempt = 0; attempt < 4 && audio.paused && stillCurrent(); attempt += 1) {
        try {
          await playPlayerAudioWithFade?.({ setupAnalyserFirst: false });
        } catch (error) {
          if (!stillCurrent()) return;
          if (audio.error || error.name === 'NotSupportedError') throw error;
          if (attempt >= 3) throw error;
          await new Promise((resolve) => window.setTimeout(resolve, 180 + attempt * 320));
        }
      }
      if (!stillCurrent()) return;
      if (!audio.paused) {
        pendingNativeAutoplay = false;
        audio.autoplay = false;
      }
      setupPlayerAnalyser?.({ bestEffort: true, timeoutMs: 700 }).then((connected) => {
        if (connected) applyPlayerVolume?.();
      }).catch((error) => {
        console.warn("Deferred player analyser setup failed", error);
      });
    } finally {
      if (request === trackLoadRequest) nativeAutoplayInProgress = false;
    }
  }

  async function loadPlayerSource(src, name, options = {}) {
    const audio = ensurePlayer?.();
    pendingNativeAutoplay = false;
    audio.pause();
    nativeAutoplayInProgress = false;
    // Keep autoplay under our explicit startup path. Letting WebKit autoplay
    // the media element can briefly bypass the prepared player volume/analyser
    // path before our controlled playback starts.
    audio.autoplay = false;
    setMonitoringInput?.(false);
    nativeAppBridge?.()?.postMessage("stopNativeAudio");
    if (ui.deviceSelect.value !== "player") ui.deviceSelect.value = "player";
    waveformController.resetForSource();
    onTrackSourceReset?.();
    updateWaveformProgress?.(true);
    const generation = incrementAnalysisGeneration?.() ?? currentAnalysisGeneration?.();
    setAnalysisTimeline?.(null);
    setAnalysisPending?.(false);
    resetLookaheadState?.();
    visualTransitions?.resetAdaptive?.();
    const targetVolume = currentPlayerVolume?.();
    setStatus?.("player loading");
    setDiagnostic?.("Preparing accurate audio seeking...");
    // Stop retaining the previous PCM blob before preparing the next track.
    audio.__cyanescentEntryId = null;
    audio.removeAttribute("src");
    audio.load();
    preparedSource?.release();
    preparedSource = null;
    let prepared;
    try {
      prepared = await prepareSeekableSource(src, name, ensureAudioContext?.());
    } catch (error) {
      // A superseded load must not report its failure over the current track.
      if (generation !== currentAnalysisGeneration?.() || options.shouldContinue?.() === false) return false;
      throw error;
    }
    if (generation !== currentAnalysisGeneration?.() || options.shouldContinue?.() === false) {
      prepared.release();
      return false;
    }
    preparedSource = prepared;
    pendingNativeAutoplay = Boolean(options.autoplay);
    audio.__cyanescentEntryId = options.entryId;
    audio.__cyanescentLoadRequest = options.loadRequest;
    loadAudioElementSource(audio, prepared.url, { volume: targetVolume });
    let sourceScheme = "unknown";
    try { sourceScheme = new URL(String(src || ""), window.location.href).protocol.replace(":", ""); } catch (error) {}
    reportAudioImportDiagnostic("media-source", {
      requestedSource: String(src || ""),
      mediaSource: audio.src || "",
      scheme: sourceScheme
    });
    ui.playPause.textContent = "Play";
    ui.trackName.textContent = name || "Loaded track";
    updateTrackTimeDisplay?.();
    setStatus?.("player ready");
    setDiagnostic?.("Local track loaded");
    if (options.setupAnalyser !== false) {
      await setupPlayerAnalyser?.();
      applyPlayerVolume?.();
    }
    if (generation !== currentAnalysisGeneration?.() || options.shouldContinue?.() === false) return false;
    analyzeLoadedTrack?.(src, generation, prepared.buffer);
    prepared.buffer = null; // Analysis owns the temporary decoded buffer until it completes.
    return true;
  }

  async function loadPlayerFile(file) {
    if (!file) return;
    await loadPlayerFiles([file], true);
  }

  async function loadPlayerFiles(files, autoplay = false) {
    const tracks = createBrowserAudioTracks(files, isAudioFileName);
    if (!tracks.length) {
      if (files?.length) reportFeedback?.('No supported music files found.');
      return;
    }
    await appendPlayerTracks(tracks, autoplay);
  }

  async function appendPlayerTracks(tracks, autoplay = false) {
    // Appends never reset a loaded or currently preparing source/analysis.
    const hadCurrent = restoringRequest === null && Boolean(playerQueueController.currentTrack?.() || ensurePlayer?.()?.src);
    const firstAdded = playerQueueController.appendTracks(tracks);
    if (!hadCurrent && firstAdded >= 0) await loadTrackAt(firstAdded, autoplay);
    else if (firstAdded >= 0) {
      const audio = ensurePlayer?.();
      if (audio?.src) setStatus?.(audio.paused ? "player ready" : "player audio");
      setDiagnostic?.(`Added ${tracks.length} track${tracks.length === 1 ? "" : "s"} to music playlist`);
    }
  }

  async function setPlayerQueue(tracks, startIndex = 0, autoplay = false) {
    const currentIndex = playerQueueController.setQueue(tracks, startIndex);
    if (currentIndex >= 0) {
      await loadTrackAt(currentIndex, autoplay);
    } else {
      playerQueueController.renderEmptyQueue();
    }
  }

  async function loadTrackAt(index, autoplay = false, playlistId, options = {}) {
    const intent = ++trackLoadRequest;
    const shouldContinue = () => intent === trackLoadRequest && options.shouldContinue?.() !== false;
    restoringRequest = options.prepareOnly ? intent : null;
    playbackIntent = autoplay;
    let candidate;
    try {
      const owner = playlistId || playerQueueController.store?.state.selectedPlaylistId;
      candidate = playerQueueController.store?.tracks(owner)[index];
      if (resolveTrack && candidate?.entryId && candidate.reference) {
        try { await resolveTrack(candidate.entryId); }
        catch (error) { if (intent === trackLoadRequest) throw error; return; }
        if (intent !== trackLoadRequest) return;
        index = playerQueueController.store.tracks(owner).findIndex(item => item.entryId === candidate.entryId);
      }
      if (!shouldContinue()) return;
      if (!playerQueueController.setCurrentIndex(index, owner)) return;
      const track = playerQueueController.currentTrack();
      playerQueueController.setPlaybackState?.("loading");
      playerQueueController.renderQueue();
      let loaded;
      try { loaded = await loadPlayerSource(track.url, track.name, { setupAnalyser: !autoplay && !options.prepareOnly, autoplay, shouldContinue, entryId: track.entryId, loadRequest: intent }); }
      catch (error) {
        if (intent === trackLoadRequest && playerQueueController.currentTrack()?.entryId === track.entryId) {
          playerQueueController.store?.markUnavailable(track.entryId, error.message);
          playerQueueController.renderQueue();
        }
        throw error;
      }
      if (!loaded) {
        if (options.prepareOnly && intent === trackLoadRequest && options.shouldContinue?.() === false) {
          playerQueueController.store?.abandonPlayback();
          playerQueueController.setPlaybackState?.('paused');
          setStatus?.('player ready');
          setDiagnostic?.('Playlists restored. Select a track to play.');
          playerQueueController.renderQueue();
        }
        return;
      }
      if (!shouldContinue()) return;
      playerQueueController.setPlaybackState?.("paused");
      playerQueueController.renderQueue();
      if (autoplay) {
        if (!shouldContinue()) return;
        try {
          await autoplayLoadedTrackFromFinder();
        } catch (error) {
          if (!shouldContinue()) return;
          if (ensurePlayer?.()?.error || error.name === 'NotSupportedError') throw error;
          reportAutoplayBlocked(error);
        }
      }
      if (shouldContinue() && (!autoplay || !ensurePlayer?.()?.paused)) playerQueueController.confirmTrackLoad?.(track.entryId);
    } catch (error) {
      if (intent !== trackLoadRequest) return;
      playerQueueController.rejectTrackLoad?.(candidate?.entryId);
      if (candidate?.entryId) playerQueueController.store?.markUnavailable(candidate.entryId, error.message);
      if (playerQueueController.currentTrack()?.entryId === candidate?.entryId) playerQueueController.setPlaybackState?.('paused');
      playerQueueController.renderQueue();
      reportFeedback?.(`Could not play “${candidate?.name || 'track'}”. Use Locate File or Remove. ${error.message || ''}`);
      throw error;
    } finally { if (restoringRequest === intent) restoringRequest = null; }
  }

  async function handleTrackEnded() {
    const owner = playerQueueController.playbackPlaylistId?.();
    const limit = playerQueueController.store?.tracks(owner).length || 1;
    for (let attempt = 0; attempt < limit; attempt++) {
      const next = playerQueueController.nextTrackIndex(false);
      if (next < 0) break;
      const request = trackLoadRequest + 1;
      try { await loadTrackAt(next, true, owner); return; }
      catch (error) { setDiagnostic?.(`Skipping unavailable file: ${error.message}`); }
      // A manual selection supersedes this entire advancement sequence.
      if (trackLoadRequest !== request) return;
    }
    playbackIntent = false;
    playerQueueController.setPlaybackState?.('paused');
    setStatus?.('player ready');
  }

  async function togglePlayer() {
    const audio = ensurePlayer?.();
    if (!audio.src || audio.error) {
      if (playerQueueController.length?.()) {
        const selected = playerQueueController.store?.playlist();
        const index = Math.max(0, selected?.entries.findIndex(entry => entry.id === selected.selectedTrackEntryId) ?? 0);
        await loadTrackAt(index, true);
        return;
      }
      const nativeApp = nativeAppBridge?.();
      if (nativeApp) nativeApp.postMessage("openAudioFile");
      else ui.audioFile.click();
      return;
    }
    playbackIntent = audio.paused;
    if (audio.paused) await playPlayerAudioWithFade?.();
    else audio.pause();
  }

  async function handleMediaError(audio) {
    const track = playerQueueController.currentTrack();
    if (ui.deviceSelect?.value !== 'player' || !audio?.error || !track?.entryId || audio.__cyanescentEntryId !== track.entryId
        || audio.__cyanescentLoadRequest !== trackLoadRequest || handledMediaErrorRequest === trackLoadRequest) return;
    handledMediaErrorRequest = trackLoadRequest;
    const advance = playbackIntent;
    pendingNativeAutoplay = false;
    playerQueueController.store?.markUnavailable(track.entryId, audio.error.message || 'Music file became unavailable. Use Locate File.');
    reportFeedback?.(`“${track.name}” is unavailable. Connect its disk or use Locate File.`);
    audio.pause();
    playerQueueController.setPlaybackState?.('paused');
    playerQueueController.renderQueue();
    setStatus?.('player error');
    if (advance) await handleTrackEnded();
  }

  function stopForPlaylistRestore() {
    trackLoadRequest++;
    restoringRequest = null;
    playbackIntent = false;
    pendingNativeAutoplay = false;
    nativeAutoplayInProgress = false;
    incrementAnalysisGeneration?.();
    const audio = ensurePlayer?.();
    audio.pause(); audio.autoplay = false; audio.removeAttribute('src'); audio.load();
    preparedSource?.release(); preparedSource = null;
    waveformController.resetForSource();
    onTrackSourceReset?.(); setAnalysisTimeline?.(null); setAnalysisPending?.(false);
    ui.trackName.textContent = 'No track loaded'; ui.playPause.textContent = 'Play';
    playerQueueController.setPlaybackState?.('paused');
    updateTrackTimeDisplay?.();
  }

  async function selectPlayerAudioSource() {
    setMonitoringInput?.(false);
    nativeAppBridge?.()?.postMessage("stopNativeAudio");
    stopInputStream?.();
    const audio = ensurePlayer?.();
    if (audio?.src) {
      await setupPlayerAnalyser?.();
      setStatus?.(audio.paused ? "player ready" : "player audio");
      setDiagnostic?.(audio.paused ? "Player audio selected" : "Analyzing player audio");
    } else {
      setPlayerMode?.(true);
      clearAnalyserBuffers?.();
      setStatus?.("player ready");
      setDiagnostic?.("Load a track or import a folder to begin");
    }
  }

  if (registerNativeCallbacks) {
    registerNativePlayerQueueCallbacks({
      ui,
      isReady,
      acceptNativeTracks,
      releaseObjectUrls,
      setPlayerQueue,
      appendTracks: playerQueueController.appendTracks ? appendPlayerTracks : undefined,
      shouldRetryAutoplay: () => pendingNativeAutoplay,
      retryAutoplay: autoplayLoadedTrackFromFinder
    });
  }

  return {
    stopForPlaylistRestore,
    handleMediaError,
    releaseObjectUrls,
    loadPlayerFile,
    loadPlayerFiles,
    appendPlayerTracks,
    setPlayerQueue,
    loadTrackAt,
    handleTrackEnded,
    togglePlayer,
    selectPlayerAudioSource,
    autoplayLoadedTrackFromFinder,
    pendingAutoplay: () => pendingNativeAutoplay
  };
}
