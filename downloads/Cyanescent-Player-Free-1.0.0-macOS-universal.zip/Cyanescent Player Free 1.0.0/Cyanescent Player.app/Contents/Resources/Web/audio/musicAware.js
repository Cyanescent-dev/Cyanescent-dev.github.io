import { clamp01, smoothstepJs } from "../utils/math.js";
import { MusicRole } from "../engine/transitions.js";
import { DROP_STATE_DEFAULTS, dropMapEnabled, dropStateFields } from "./dropMap.js";

export function createMusicAwareState() {
  return {
    futureEnergy: 0,
    futureBrightness: 0,
    futureDensity: 0,
    sectionChange: 0,
    energyTrend: 0,
    breakdown: 0,
    mainRiff: 0,
    drop: 0,
    buildUp: 0,
    calm: 0,
    highEnergy: 0,
    adaptiveIntensity: 0,
    upcomingDrop: 0,
    upcomingBreakdown: 0,
    upcomingBuild: 0,
    phrasePulse: 0,
    phraseProgress: 0,
    beatPhase: 0,
    absoluteBeat: 0,
    nextPhraseSeconds: 0,
    role: MusicRole.CALM,
    roleConfidence: 0,
    // the track's drop map (see dropMap.js dropStateFields): exact, ahead of time and seek-proof
    ...DROP_STATE_DEFAULTS
  };
}

// Fields that are timing, not levels: copied as they are, never smoothed.
const UNSMOOTHED = new Set(["beatPhase", "phraseProgress", "nextPhraseSeconds", "role", "absoluteBeat",
  "dropKnown", "dropIn", "dropBeatsIn", "dropLeadIn", "dropNextStrength", "dropAge", "dropLastStrength"]);

function energyLevelFromLabel(label) {
  return Math.max(0, Math.min(5, Number((String(label || "").match(/Energy\s+([1-5])/) || [])[1]) || 0));
}

// Shared by both the offline (whole-track lookahead) and live (rolling
// baseline) branches below - once buildUp/drop/breakdown/highEnergy/calm
// are computed, picking a role from them is the same threshold cascade
// either way.
function resolveMusicRole({ drop, buildUp, breakdown, highEnergy, calm }) {
  if (drop > 0.48) return { role: MusicRole.DROP, roleConfidence: drop };
  if (buildUp > 0.48) return { role: MusicRole.BUILD, roleConfidence: buildUp };
  if (breakdown > 0.48) return { role: MusicRole.BREAKDOWN, roleConfidence: breakdown };
  if (highEnergy > 0.46) return { role: MusicRole.HIGH, roleConfidence: highEnergy };
  if (calm > 0.44) return { role: MusicRole.CALM, roleConfidence: calm };
  return { role: MusicRole.SHIFT, roleConfidence: 0.34 };
}

export function computeMusicAwareState({
  previousState,
  lookaheadState,
  analysisTimeline,
  audioFeatures,
  liveBeatInfo,
  liveStructureState,
  currentTime = 0
} = {}) {
  const state = previousState || createMusicAwareState();
  let target = createMusicAwareState();
  if (lookaheadState?.ready && lookaheadState.current) {
    const current = lookaheadState.current;
    const short = lookaheadState.short || current;
    const medium = lookaheadState.medium || short;
    const long = lookaheadState.long || medium;
    const section = analysisTimeline?.getSectionAt(currentTime)?.label || "";
    const upcomingSection = analysisTimeline?.sections?.find((item) => item.start > currentTime + 0.75 && item.start - currentTime <= 24) || null;
    const upcomingWeight = upcomingSection ? smoothstepJs(24, 3, upcomingSection.start - currentTime) : 0;
    const energyLevel = energyLevelFromLabel(section);
    const upcomingEnergyLevel = energyLevelFromLabel(upcomingSection?.label);
    const beatInfo = analysisTimeline?.getBeatInfo(currentTime);
    const energyRise = clamp01((long.energyDelta || 0) * 2.0 + (medium.maxEnergy - current.energy) * 1.0);
    const energyFall = clamp01((current.energy - medium.energy) * 1.6 + (current.energy - long.energy) * 0.8);
    const buildUp = clamp01((energyLevel >= 2 && energyLevel <= 4 && upcomingEnergyLevel > energyLevel ? 0.42 + upcomingWeight * 0.24 : 0) + energyRise * 0.58 + (medium.brightnessDelta || 0) * 0.9);
    const drop = clamp01((audioFeatures?.dropDetected || 0) * 0.88 + (energyLevel >= 5 && upcomingEnergyLevel < energyLevel ? 0.10 : 0));
    const breakdown = clamp01((energyLevel <= 1 ? 0.84 : energyLevel === 2 ? 0.36 : 0) + (upcomingEnergyLevel <= 1 ? upcomingWeight * 0.28 : 0) + energyFall * 0.24);
    const calm = clamp01((energyLevel <= 2 ? 0.62 : 0) + breakdown * 0.45 + (current.energy < 0.24 && medium.energy < 0.30 ? 0.26 : 0));
    const mainRiff = clamp01(energyLevel >= 5 ? 0.86 : energyLevel === 4 ? 0.34 : 0);
    const highEnergy = clamp01(mainRiff * 0.76 + drop * 0.52 + (audioFeatures?.globalEnergy || 0) * 0.44 + (energyLevel >= 4 ? 0.32 : 0));
    target = {
      futureEnergy: clamp01(long.energy * 0.48 + medium.maxEnergy * 0.34 + short.energy * 0.18),
      futureBrightness: clamp01(medium.brightness * 0.70 + long.brightness * 0.30),
      futureDensity: clamp01(medium.density * 0.52 + long.density * 0.30 + short.beatStrength * 0.18),
      sectionChange: clamp01(Math.max(medium.maxSectionProbability || 0, long.maxSectionProbability || 0)),
      energyTrend: clamp01((long.energyDelta || 0) * 1.7 + 0.5),
      breakdown,
      mainRiff,
      drop,
      buildUp,
      calm,
      highEnergy,
      adaptiveIntensity: clamp01(current.energy * 0.42 + medium.density * 0.22 + highEnergy * 0.26 + buildUp * 0.16 + drop * 0.22),
      upcomingDrop: upcomingSection?.label === "Drop" ? upcomingWeight : energyRise * 0.32,
      upcomingBreakdown: upcomingSection?.label === "Breakdown" ? upcomingWeight : energyFall * 0.22,
      upcomingBuild: upcomingSection?.label === "Buildup" ? upcomingWeight : buildUp * 0.42,
      phrasePulse: beatInfo?.phrasePulse || 0,
      phraseProgress: beatInfo?.phrase32Progress || 0,
      beatPhase: beatInfo?.beatPhase || 0,
      absoluteBeat: beatInfo ? (beatInfo.beatIndex + beatInfo.beatPhase) : (currentTime * 2.4),
      nextPhraseSeconds: beatInfo?.nextLoopSeconds || 0
    };
    // The drop map replaces the guesses above for drop and upcomingDrop: the analysis' sections
    // are labelled by energy level (never "Drop"), so upcomingDrop only ever saw the energy rise,
    // and drop came from the live drop detector alone.
    const dropFields = dropMapEnabled() ? dropStateFields(analysisTimeline?.getDropInfo?.(currentTime)) : null;
    if (dropFields) {
      Object.assign(target, dropFields);
      target.drop = dropFields.dropPulse;
    }
  } else {
    // No pre-analyzed timeline (live input / Scion monitor): the timing
    // fields come from the online tempo tracker's beat grid, and the
    // structure classifiers from the rolling-baseline novelty tracker - see
    // liveTempoTracker.js and liveStructureTracker.js. Genuine lookahead
    // fields (futureEnergy/futureBrightness/futureDensity/energyTrend) have
    // no honest live analogue and are left at their decayed default.
    if (liveBeatInfo) {
      target.phrasePulse = liveBeatInfo.phrasePulse || 0;
      target.phraseProgress = liveBeatInfo.phrase32Progress || 0;
      target.beatPhase = liveBeatInfo.beatPhase || 0;
      target.absoluteBeat = liveBeatInfo.beatIndex + liveBeatInfo.beatPhase;
      target.nextPhraseSeconds = liveBeatInfo.nextLoopSeconds || 0;
    }
    if (liveStructureState) {
      target.sectionChange = liveStructureState.sectionChange || 0;
      target.breakdown = liveStructureState.breakdown || 0;
      target.calm = liveStructureState.calm || 0;
      target.mainRiff = liveStructureState.mainRiff || 0;
      target.drop = liveStructureState.drop || 0;
      target.buildUp = liveStructureState.buildUp || 0;
      target.highEnergy = liveStructureState.highEnergy || 0;
      target.adaptiveIntensity = liveStructureState.adaptiveIntensity || 0;
      target.upcomingDrop = liveStructureState.upcomingDrop || 0;
      target.upcomingBreakdown = liveStructureState.upcomingBreakdown || 0;
      target.upcomingBuild = liveStructureState.upcomingBuild || 0;
    }
  }
  // target already defaults to role: CALM, roleConfidence: 0 (from
  // createMusicAwareState()) when neither branch above populated anything -
  // e.g. nothing loaded/playing at all - so only resolve a role once there's
  // an actual offline or live signal to resolve one from.
  if ((lookaheadState?.ready && lookaheadState.current) || liveBeatInfo || liveStructureState) {
    const resolvedRole = resolveMusicRole(target);
    target.role = resolvedRole.role;
    target.roleConfidence = resolvedRole.roleConfidence;
  }
  for (const key of Object.keys(state)) {
    if (UNSMOOTHED.has(key)) {
      state[key] = target[key] ?? 0;
      continue;
    }
    const amount = target[key] > state[key] ? 0.16 : 0.045;
    state[key] += (target[key] - state[key]) * amount;
  }
  return state;
}
