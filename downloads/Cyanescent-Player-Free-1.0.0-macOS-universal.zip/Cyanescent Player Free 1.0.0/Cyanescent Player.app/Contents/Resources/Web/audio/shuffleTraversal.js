// Session-only traversal. Authored playlist order and the persistence schema stay unchanged.
export function createShuffleTraversal({ random = Math.random } = {}) {
  let history = [], cursor = -1, remaining = [], seen = new Set(), current = null, pending = -1;
  const shuffled = ids => {
    const result = [...ids];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  };
  function reset(id, ids) {
    current = id;
    history = id ? [id] : [];
    cursor = history.length - 1;
    pending = -1;
    seen = new Set(history);
    remaining = shuffled(ids.filter(value => !seen.has(value)));
  }
  function sync(ids) {
    const available = new Set(ids);
    remaining = remaining.filter(id => available.has(id));
    const queued = new Set(remaining);
    remaining.push(...shuffled(ids.filter(id => !seen.has(id) && !queued.has(id))));
  }
  function cancelPending(ids) {
    if (pending < 0) return;
    const [id] = history.splice(pending, 1);
    if (cursor >= pending) cursor--;
    pending = -1;
    current = history[cursor] || null;
    // Rapid navigation can supersede a load before it ever plays. Keep that
    // entry eligible, but do not invent a played-history item for it.
    seen.delete(id);
    if (ids.includes(id) && !remaining.includes(id)) remaining.push(id);
  }
  return {
    activate(id, ids) {
      // Navigation reserves its destination before asynchronous loading. A direct
      // row selection starts a fresh traversal anchored at that selected entry.
      if (history[cursor] !== id) { reset(id, ids); pending = cursor; }
      current = id;
    },
    loaded(id) { if (history[pending] === id) pending = -1; },
    failed(id) {
      if (pending >= 0 && history[pending] === id) {
        history.splice(pending, 1);
        if (cursor >= pending) cursor--;
        pending = -1;
      }
    },
    next(ids, repeatMode, manual = false) {
      cancelPending(ids);
      sync(ids);
      if (!manual && repeatMode === 'one' && ids.includes(current)) return current;
      while (cursor + 1 < history.length) {
        const id = history[++cursor];
        if (ids.includes(id)) return id;
      }
      if (!remaining.length && repeatMode === 'all' && ids.length) {
        seen = new Set();
        remaining = shuffled(ids);
        if (remaining.length > 1 && remaining[0] === current) remaining.push(remaining.shift());
      }
      const id = remaining.shift();
      if (!id) return null;
      seen.add(id);
      history.push(id);
      cursor = history.length - 1;
      pending = cursor;
      return id;
    },
    previous(ids, time = 0) {
      cancelPending(ids);
      if (time > 3 && ids.includes(current)) return current;
      for (let index = cursor - 1; index >= 0; index--) {
        if (ids.includes(history[index])) { cursor = index; return history[index]; }
      }
      return ids.includes(current) ? current : null;
    },
    reset
  };
}
