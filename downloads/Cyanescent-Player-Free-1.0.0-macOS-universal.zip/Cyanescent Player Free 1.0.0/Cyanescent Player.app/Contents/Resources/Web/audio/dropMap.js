// Drop map: where the drops are in an analysed track, computed once with the track's analysis so
// every preset can know them ahead of time and after any seek.
//
// A drop is the groove coming back in full: measured per beat on the beat grid, in dB (the 0-1
// analysis features saturate on loud masters), from four cues:
//   return   the low end (below ~180 Hz) coming back after a dip or a thin stretch (dB)
//   context  the new section being fuller in the low end than the stretch before it (dB): this is
//            what separates a drop from a fill (a one- or two-bar dip inside a full section)
//   kick     the kick returning after bars without it (the beat grid's kick score); a drop whose
//            build keeps a full low end (a riser over the bass) shows only here
//   riser    the highs building over the bars before it (dB)
//   break    how deep and long the dip before it was (dB x bars over the last 8 bars): a break of
//            several bars inside a full section is a drop, a one- or two-bar fill is not
// Candidates must show a real return (low end or kick); a section that is merely louder than one
// long ago is an echo of an earlier drop, not a new one. The strongest candidate within 16 bars
// wins; its time is the beat where the low end or kick comes back, snapped to that beat.
//
// computeDropMap returns [{ time, beat, kind: "major" | "minor", strength 0-1, leadIn, cues }],
// sorted by time. Markers (the listener's own) are merged by mergeDropMarkers.

const DROP_MAJOR = 11;
const DROP_MINOR = 5.5;
const clamp01 = (x) => Math.min(1, Math.max(0, Number.isFinite(x) ? x : 0));

function percentile(values, p) {
  const sorted = values.filter(Number.isFinite).slice().sort((a, b) => a - b);
  if (!sorted.length) return 0;
  return sorted[Math.min(sorted.length - 1, Math.max(0, Math.round(p * (sorted.length - 1))))];
}

// Per-beat levels: mean power of the frames inside each beat, back to dB.
function beatLevels(frames, frameDuration, beatGrid, duration, key, fallback) {
  const out = new Array(beatGrid.length);
  for (let j = 0; j < beatGrid.length; j++) {
    const t0 = beatGrid[j].time;
    const t1 = j + 1 < beatGrid.length ? beatGrid[j + 1].time : Math.min(duration, t0 + (beatGrid[j].time - (beatGrid[j - 1]?.time ?? t0 - 0.4)));
    const a = Math.max(0, Math.floor(t0 / frameDuration));
    const b = Math.min(frames.length, Math.max(a + 1, Math.floor(t1 / frameDuration)));
    let power = 0;
    for (let i = a; i < b; i++) {
      const f = frames[i];
      const db = Number.isFinite(f[key]) ? f[key] : fallback(f);
      power += Math.pow(10, db / 10);
    }
    out[j] = 10 * Math.log10(power / Math.max(1, b - a) + 1e-10);
  }
  return out;
}

export function computeDropMap({ frames = [], frameDuration = 0.05, beatGrid = [], duration = 0 } = {}) {
  const n = beatGrid.length;
  if (n < 64 || !frames.length) return [];
  // without the dB fields (an older analysis) fall back to the scaled features
  const low = beatLevels(frames, frameDuration, beatGrid, duration, "lowDb", (f) => 20 * Math.log10(Math.max(1e-4, f.bass / 4.2)));
  const high = beatLevels(frames, frameDuration, beatGrid, duration, "highDb", (f) => 20 * Math.log10(Math.max(1e-4, f.treble / 7)));
  const kickRaw = beatGrid.map((b) => (Number.isFinite(b.score) ? b.score : 0));
  const kickRef = Math.max(0.05, percentile(kickRaw, 0.9));
  const kick = kickRaw.map((k) => Math.min(1.2, k / kickRef));
  const fullLow = percentile(low, 0.9);

  // bar means (4 beats from j)
  const bar = (arr, j) => {
    let s = 0, c = 0;
    for (let k = Math.max(0, j); k < Math.min(n, j + 4); k++) { s += arr[k]; c++; }
    return c ? s / c : arr[Math.max(0, Math.min(n - 1, j))];
  };
  const bars = (arr, j, from, to) => {   // mean of bar means at offsets from..to (in bars)
    let s = 0, c = 0;
    for (let b = from; b <= to; b++) { s += bar(arr, j + 4 * b); c++; }
    return s / Math.max(1, c);
  };

  const candidates = [];
  for (let i = 32; i < n - 16; i++) {
    const after = bars(low, i, 0, 3);
    const dip = Math.min(bar(low, i - 4), bar(low, i - 8));
    const before = bars(low, i, -20, -5);
    const ret = after - dip;
    const ctx = after - before;
    const kickBefore = bars(kick, i, -6, -1);
    const kickAfter = bars(kick, i, 0, 3);
    const kickReturn = kickBefore < 0.45 ? kickAfter - kickBefore : 0;
    const riser = bar(high, i - 4) - bar(high, i - 24);
    let breakDepth = 0;
    for (let b = 1; b <= 8; b++) breakDepth += Math.max(0, after - bar(low, i - 4 * b) - 3);
    // a real return, into a full section
    if (!(ret >= 3 || kickReturn >= 0.3)) continue;
    if (after < fullLow - 5) continue;
    const score = Math.max(0, ctx) + 0.35 * Math.max(0, ret - 5) + 14 * Math.max(0, kickReturn) + 0.15 * Math.max(0, riser) +
      0.1 * Math.max(0, breakDepth - 25);
    if (score < DROP_MINOR) continue;
    candidates.push({ i, score, ret, ctx, kickReturn, riser, after, breakDepth });
  }
  candidates.sort((a, b) => b.score - a.score);
  const picked = [];
  for (const c of candidates) if (picked.every((p) => Math.abs(p.i - c.i) >= 64)) picked.push(c);

  const drops = picked.sort((a, b) => a.i - b.i).map((c) => {
    // the beat where it comes back: the largest one-beat rise of the low end or the kick nearby
    let best = c.i, bestRise = -Infinity;
    for (let j = Math.max(1, c.i - 4); j <= Math.min(n - 1, c.i + 4); j++) {
      const rise = Math.max(low[j] - low[j - 1], 12 * (kick[j] - kick[j - 1]));
      if (rise > bestRise) { bestRise = rise; best = j; }
    }
    // the lead-in (the build or break): back over the bars whose low end is clearly thinner than
    // the drop's or that have no kick (bar means: single beats are often low off the beat), up to
    // 32 bars
    let lead = best;
    for (let b = 1; b <= 32; b++) {
      const j = best - 4 * b;
      if (j < 0) break;
      if (bar(low, j) < c.after - 4 || bar(kick, j) < 0.35) lead = j; else break;
    }
    return {
      time: beatGrid[best].time,
      beat: best,
      kind: c.score >= DROP_MAJOR ? "major" : "minor",
      strength: clamp01(c.score / 25),
      leadIn: beatGrid[lead].time,
      source: "auto",
      cues: { return: +c.ret.toFixed(1), context: +c.ctx.toFixed(1), kick: +c.kickReturn.toFixed(2), riser: +c.riser.toFixed(1), break: +c.breakDepth.toFixed(0), score: +c.score.toFixed(1) }
    };
  });
  // a lead-in never reaches back past the previous drop
  for (let k = 1; k < drops.length; k++) drops[k].leadIn = Math.max(drops[k].leadIn, drops[k - 1].time + 1);
  return drops;
}

// Markers: [{ time, kind: "major" | "minor" | "none" }] from the listener. A marker replaces any
// automatic drop within 4 s of it; kind "none" removes the automatic drop there.
export const DROP_MARKER_REPLACEMENT_WINDOW = 4;
export function mergeDropMarkers(auto = [], markers = []) {
  const out = auto.filter((d) => !markers.some((m) => Math.abs(m.time - d.time) < DROP_MARKER_REPLACEMENT_WINDOW));
  for (const m of markers) {
    if (m.kind === "none") continue;
    // keep the lead-in the analysis found for a drop the marker replaces; otherwise ~16 s
    const replaced = auto.find((d) => Math.abs(m.time - d.time) < DROP_MARKER_REPLACEMENT_WINDOW);
    out.push({ time: m.time, beat: null, kind: m.kind === "minor" ? "minor" : "major", strength: m.kind === "minor" ? 0.5 : 1,
      leadIn: replaced ? Math.min(replaced.leadIn, m.time - 2) : Math.max(0, m.time - 16), source: "marker", cues: null });
  }
  out.sort((a, b) => a.time - b.time);
  for (let k = 1; k < out.length; k++) out[k].leadIn = Math.max(out[k].leadIn, out[k - 1].time + 1);
  return out;
}

// Whether presets should use the drop map (localStorage "cyanescent.dropMap" = "0" turns it off,
// restoring the older behaviour of the shared drop / upcomingDrop values for comparison).
export function dropMapEnabled() {
  // (outside a page, e.g. in tests under Node, there is no setting to read)
  if (typeof document === "undefined") return true;
  try { return globalThis.localStorage?.getItem("cyanescent.dropMap") !== "0"; } catch { return true; }
}

const DROP_HORIZON = 64;   // seconds: "no drop known within this" reads as this

// The shared music-state fields for a drop info (AudioAnalysisTimeline.getDropInfo). They are
// functions of the track time alone, so they are right after any seek:
//   dropKnown         1 when the track has a drop map
//   dropIn            seconds to the next drop (DROP_HORIZON when none)
//   dropBeatsIn       beats to the next drop
//   dropLeadIn        0 before the next drop's approach (its lead-in, the build or break, at most
//                     its last 24 s), rising to 1 at the drop
//   dropNextStrength  1 major, 0.5 minor, 0 none
//   dropAge           seconds since the last drop (DROP_HORIZON when none)
//   dropLastStrength  the last drop's strength
//   dropPulse         the last drop's strength, fading over ~2 s after it
//   upcomingDrop      the next drop approaching: its strength, rising through its lead-in (not
//                     before it: a drive running up to a drop is not yet its build)
export function dropStateFields(info) {
  if (!info) return null;
  const strengthOf = (drop) => (drop ? (drop.kind === "major" ? 1 : 0.5) : 0);
  const nextStrength = strengthOf(info.next);
  const lastStrength = strengthOf(info.last);
  const age = Math.min(DROP_HORIZON, info.secondsSinceLast);
  // the approach: through the lead-in, but over its last 24 s at most (a long breakdown before a
  // drop is its lead-in, not all of it its build)
  let lead = info.leadInProgress;
  if (info.next && Number.isFinite(info.secondsToNext)) {
    const span = Math.min(24, Math.max(0.5, info.next.time - info.next.leadIn));
    lead = Math.min(1, Math.max(0, 1 - info.secondsToNext / span));
  }
  return {
    dropKnown: 1,
    dropIn: Math.min(DROP_HORIZON, info.secondsToNext),
    dropBeatsIn: Math.min(DROP_HORIZON * 4, info.beatsToNext),
    dropLeadIn: lead,
    dropNextStrength: nextStrength,
    dropAge: age,
    dropLastStrength: lastStrength,
    dropPulse: age < 6 ? lastStrength * Math.exp(-age / 2) : 0,
    upcomingDrop: nextStrength * lead * lead * (3 - 2 * lead)
  };
}

export const DROP_STATE_DEFAULTS = Object.freeze({
  dropKnown: 0, dropIn: DROP_HORIZON, dropBeatsIn: DROP_HORIZON * 4, dropLeadIn: 0, dropNextStrength: 0,
  dropAge: DROP_HORIZON, dropLastStrength: 0, dropPulse: 0
});
