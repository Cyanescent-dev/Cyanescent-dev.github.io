import { normalizePlayerTracks, nextTrackIndexForQueue, previousTrackIndexForQueue } from './playerSources.js';
import { createShuffleTraversal } from './shuffleTraversal.js';
import { createMusicPlaylistStore } from './musicPlaylistStore.js';
import { renderQueueList, renderEmptyQueueState, registerMusicPanelScrolling, updateRepeatButton as updateRepeatButtonView } from '../ui/playlist.js';
import { requestMusicPlaylistAction } from '../ui/musicPlaylistDialog.js';

export function createPlayerQueueController({ ui, updateTrackTimeDisplay, hasPlayerSource, loadTrackAt,
  store = createMusicPlaylistStore(), requestAction = requestMusicPlaylistAction, locateTrack, reportFeedback, random }) {
  registerMusicPanelScrolling(ui.queueList?.closest('.playlist-panel'), ui.queueList);
  let playbackState = 'paused';
  const traversals = new Map();
  let collection = store.state.playlists;
  const availableIds = id => store.tracks(id).filter(track => !track.unavailable && track.url).map(track => track.entryId);
  function traversal(id = playbackPlaylistId()) {
    if (collection !== store.state.playlists) { traversals.clear(); collection = store.state.playlists; }
    if (!traversals.has(id)) {
      const value = createShuffleTraversal({random});
      value.reset(store.state.currentPlaylistId === id ? store.state.currentTrackEntryId : null, availableIds(id));
      traversals.set(id, value);
    }
    return traversals.get(id);
  }
  store.subscribe((_state, operation) => {
    if (operation === 'setShuffle') traversals.clear();
    if (operation === 'activate' && store.state.shuffleEnabled) {
      traversal().activate(store.state.currentTrackEntryId, availableIds(playbackPlaylistId()));
    }
  });
  const playbackPlaylistId = () => store.state.currentPlaylistId || store.state.selectedPlaylistId;
  function renderQueue() {
    if (ui.musicPlaylistSelect) {
      ui.musicPlaylistSelect.replaceChildren();
      for (const playlist of store.state.playlists) {
        const option = document.createElement('option');
        option.value = playlist.id;
        option.textContent = playlist.name;
        ui.musicPlaylistSelect.append(option);
      }
      ui.musicPlaylistSelect.value = store.state.selectedPlaylistId;
    }
    if (ui.clearMusicPlaylist) ui.clearMusicPlaylist.disabled = !store.playlist().entries.length;
    renderQueueList({
      queueList: ui.queueList, queueSummary: ui.queueSummary,
      prevButton: ui.prevTrack, nextButton: ui.nextTrack, playButton: ui.playPause,
      queue: store.tracks(), currentEntryId: store.state.currentTrackEntryId,
      selectedEntryId: store.playlist().selectedTrackEntryId, playbackState,
      transportCount: store.tracks(playbackPlaylistId()).length,
      hasPlayerSource: hasPlayerSource?.(),
      playingElsewhere: store.currentTrack() && (playbackPlaylistId() !== store.state.selectedPlaylistId
        || store.playbackIndex() < 0) ? store.currentTrack().name : '',
      onSelect: id => {
        store.selectEntry(id);
        // Keep the clicked node alive for native double-click and keyboard focus.
        for (const button of ui.queueList?.querySelectorAll('[data-action="select"]') || []) {
          const selected = button.dataset.entryId === id;
          button.setAttribute('aria-pressed', String(selected));
          button.parentElement.classList.toggle('selected', selected);
        }
      },
      onLocate: id => locateTrack?.(id),
      onRemove: id => { store.removeEntry(id); renderQueue(); },
      onMove: (id, destination) => { store.move(id, destination); renderQueue(); },
      onTrackClick: index => {
        loadTrackAt?.(index, true, store.state.selectedPlaylistId).catch(error => {
          reportFeedback?.(`Could not play track: ${error.message || 'File unavailable. Use Locate File.'}`);
          ui.audioStatus.textContent = 'player error';
          ui.audioDiagnostic.textContent = `Could not play track: ${error.message || 'unknown error'}`;
          console.error(error);
        });
      }
    });
  }
  function renderEmptyQueue() {
    if (!store.currentTrack()) renderEmptyQueueState({ trackName: ui.trackName, queueSummary: ui.queueSummary,
      updateTrackTime: updateTrackTimeDisplay });
    renderQueue();
  }
  function updateRepeatButton() {
    updateRepeatButtonView(ui.repeatMode, store.state.repeatMode);
  }
  function setQueue(tracks, startIndex = 0) {
    store.clear(); // Explicit replacement API for diagnostic callers; imports use appendTracks.
    store.append(normalizePlayerTracks(tracks));
    renderQueue();
    const count = store.tracks().length;
    return count ? Math.max(0, Math.min(count - 1, startIndex)) : -1;
  }
  function appendTracks(tracks) {
    const start = store.tracks().length;
    const added = store.append(normalizePlayerTracks(tracks));
    renderQueue();
    return added.length ? start : -1;
  }
  function setCurrentIndex(index, playlistId) {
    if (store.state.shuffleEnabled) traversal(playlistId || store.state.selectedPlaylistId); // Capture the prior audible identity before activation.
    return store.activate(index, playlistId);
  }
  function unfilteredNextTrackIndex(manual = false) {
    const count = store.tracks(playbackPlaylistId()).length;
    if (store.currentTrack() && store.playbackIndex() < 0) {
      // A removed entry may finish, but Repeat One must not resurrect it.
      const next = store.detachedNextIndex();
      if (next >= 0) return next;
      return count && (manual || store.state.repeatMode === 'all') ? 0 : -1;
    }
    return nextTrackIndexForQueue({ count, currentIndex: store.playbackIndex(),
      repeatMode: store.state.repeatMode, shuffleEnabled: false, manual });
  }
  function unfilteredPreviousTrackIndex(currentTime = 0) {
    return previousTrackIndexForQueue({ count: store.tracks(playbackPlaylistId()).length,
      currentIndex: Math.max(0, store.playbackIndex()), repeatMode: store.state.repeatMode, currentTime });
  }
  function nextTrackIndex(manual = false) {
    const tracks = store.tracks(playbackPlaylistId());
    if (store.state.shuffleEnabled) {
      const id = traversal().next(availableIds(playbackPlaylistId()), store.state.repeatMode, manual);
      return id ? tracks.findIndex(track => track.entryId === id) : -1;
    }
    const first = unfilteredNextTrackIndex(manual);
    if (first < 0 || !tracks[first]?.unavailable) return first;
    // Walk once at most, respecting sequential boundaries.
    for (let offset = 1; offset <= tracks.length; offset++) {
      let index = first + offset;
      if (index >= tracks.length) {
        if (!manual && store.state.repeatMode !== 'all') return -1;
        index %= tracks.length;
      }
      if (!tracks[index].unavailable && tracks[index].url) return index;
    }
    return -1;
  }
  function previousTrackIndex(currentTime = 0) {
    const tracks = store.tracks(playbackPlaylistId());
    if (store.state.shuffleEnabled) {
      const id = traversal().previous(availableIds(playbackPlaylistId()), currentTime);
      return id ? tracks.findIndex(track => track.entryId === id) : -1;
    }
    const first = unfilteredPreviousTrackIndex(currentTime);
    if (first < 0 || !tracks[first]?.unavailable) return first;
    for (let index = first - 1; index >= 0; index--) if (!tracks[index].unavailable && tracks[index].url) return index;
    if (store.state.repeatMode === 'all') for (let index = tracks.length - 1; index > first; index--) if (!tracks[index].unavailable && tracks[index].url) return index;
    return -1;
  }
  function syncShuffleButton() {
    ui.playerShuffle?.classList.toggle('active', store.state.shuffleEnabled);
    ui.playerShuffle?.setAttribute('aria-pressed', String(store.state.shuffleEnabled));
  }
  function toggleShuffle() {
    store.setShuffle(!store.state.shuffleEnabled);
    syncShuffleButton();
  }
  function setRepeatMode(value) {
    store.setRepeat(value);
    updateRepeatButton();
  }
  function cycleRepeatMode() {
    setRepeatMode(store.state.repeatMode === 'off' ? 'all' : store.state.repeatMode === 'all' ? 'one' : 'off');
  }
  ui.musicPlaylistSelect?.addEventListener('change', () => { store.select(ui.musicPlaylistSelect.value); renderQueue(); });
  ui.newMusicPlaylist?.addEventListener('click', async () => {
    const name = await requestAction({ title: 'New music playlist', name: 'New Playlist', confirmLabel: 'Create' });
    if (name) { store.create(name); renderQueue(); }
  });
  ui.renameMusicPlaylist?.addEventListener('click', async () => {
    const playlist = store.playlist();
    const name = await requestAction({ title: 'Rename music playlist', name: playlist.name, confirmLabel: 'Rename' });
    if (name) { store.rename(playlist.id, name); renderQueue(); }
  });
  for (const [button, operation, verb] of [[ui.deleteMusicPlaylist, 'remove', 'Delete'], [ui.clearMusicPlaylist, 'clear', 'Clear']]) {
    button?.addEventListener('click', async () => {
      const playlist = store.playlist();
      if (await requestAction({ title: `${verb} music playlist`, confirmLabel: verb,
        message: `${verb} “${playlist.name}”? Music files will remain on your Mac. The current track can finish playing.` })) {
        store[operation](playlist.id);
        renderQueue();
      }
    });
  }
  return {
    confirmTrackLoad(id) { if (store.state.shuffleEnabled) traversal().loaded(id); },
    rejectTrackLoad(id) { if (store.state.shuffleEnabled) traversal().failed(id); },
    store, playbackPlaylistId, appendTracks, syncShuffleButton,
    releaseObjectUrls: store.releaseObjectUrls,
    currentTrack: store.currentTrack,
    hasQueue: () => store.tracks().length > 0,
    length: () => store.tracks().length,
    renderQueue, renderEmptyQueue, updateRepeatButton, setQueue, setCurrentIndex,
    nextTrackIndex, previousTrackIndex, toggleShuffle, cycleRepeatMode, setRepeatMode,
    setPlaybackState(value) { playbackState = value; renderQueue(); }
  };
}
