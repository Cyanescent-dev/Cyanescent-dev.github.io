export function nativeTrackIdFromUrl(url) {
  const text = String(url || "");
  const match = text.match(/(?:cyanescent-audio:\/\/track|\/native-track)\/([^/?#]+)/);
  return match ? decodeURIComponent(match[1]) : "";
}

export function normalizePlayerTrack(track) {
  if (!track?.url) return null;
  const nativeId = track.nativeId || nativeTrackIdFromUrl(track.url);
  if (nativeId) {
    return {
      ...track,
      id: track.id || nativeId,
      nativeId,
      url: `cyanescent-audio://track/${encodeURIComponent(nativeId)}?t=${Date.now()}`
    };
  }
  return track;
}

export function normalizePlayerTracks(tracks) {
  return Array.isArray(tracks)
    ? tracks.map((track) => normalizePlayerTrack(track)).filter((track) => track?.url)
    : [];
}

export function queueStartIndexFor(count, requestedIndex = 0) {
  return count ? Math.max(0, Math.min(count - 1, requestedIndex)) : -1;
}

export function createBrowserAudioTracks(files, isAudioFileName) {
  const audioFiles = Array.from(files || []).filter((file) => {
    return isAudioFileName?.(file.name) || /^audio\//i.test(file.type || "");
  });
  return audioFiles.map((file, index) => {
    const objectUrl = URL.createObjectURL(file);
    return {
      id: `web-${Date.now()}-${index}`,
      name: file.name,
      url: objectUrl,
      objectUrl
    };
  });
}

export function revokeTrackObjectUrls(tracks, extraObjectUrl = "") {
  for (const track of tracks || []) {
    if (track.objectUrl) URL.revokeObjectURL(track.objectUrl);
  }
  if (extraObjectUrl) URL.revokeObjectURL(extraObjectUrl);
}

export function createPlayerAudioElement({
  onEnded,
  onPause,
  onPlay,
  onMetadata,
  onCanPlay,
  onError,
  onDurationChange,
  onTimeUpdate,
  onSeeked
} = {}) {
  const audio = new Audio();
  audio.preload = "metadata";
  audio.autoplay = false;
  audio.volume = 0;
  audio.muted = false;
  audio.addEventListener("ended", () => onEnded?.());
  audio.addEventListener("pause", () => onPause?.());
  audio.addEventListener("play", () => onPlay?.());
  audio.addEventListener("loadedmetadata", () => onMetadata?.());
  audio.addEventListener("loadeddata", () => onCanPlay?.());
  audio.addEventListener("canplay", () => onCanPlay?.());
  audio.addEventListener("canplaythrough", () => onCanPlay?.());
  audio.addEventListener("error", () => onError?.(audio.error, audio));
  audio.addEventListener("durationchange", () => onDurationChange?.());
  audio.addEventListener("timeupdate", () => onTimeUpdate?.());
  audio.addEventListener("seeked", () => onSeeked?.(audio.currentTime || 0));
  return audio;
}

export function loadAudioElementSource(audio, src, options = {}) {
  if (!audio) return;
  audio.pause();
  audio.__cyanescentTargetVolume = Number.isFinite(options.volume)
    ? Math.max(0, Math.min(1, options.volume))
    : audio.__cyanescentTargetVolume;
  audio.volume = 0;
  audio.muted = true;
  audio.src = src;
  audio.load();
}

export function playerVolumeFromControl(control) {
  return Math.max(0, Math.min(1, Number(control?.value) || 0));
}

export function applyAudioOutputVolume({ audio, gain, context, volume }) {
  const safeVolume = Math.max(0, Math.min(1, Number(volume) || 0));
  if (audio) audio.volume = gain ? 1 : safeVolume;
  if (gain) {
    const now = context?.currentTime || 0;
    gain.gain.cancelScheduledValues(now);
    gain.gain.setTargetAtTime(safeVolume, now, 0.012);
  }
}

function rampMediaElementVolume(audio, targetVolume, durationMs = 45) {
  if (!audio) return Promise.resolve();
  const target = Math.max(0, Math.min(1, Number(targetVolume) || 0));
  const steps = 6;
  let step = 0;
  audio.volume = 0;
  return new Promise((resolve) => {
    const tick = () => {
      step += 1;
      audio.volume = target * Math.min(1, step / steps);
      if (step >= steps) resolve();
      else window.setTimeout(tick, durationMs / steps);
    };
    window.setTimeout(tick, durationMs / steps);
  });
}

export async function playAudioElementWithFade({ audio, context, gain, targetVolume }) {
  const safeTarget = Math.max(0, Math.min(1, Number(targetVolume) || 0));
  if (gain) {
    const now = context.currentTime;
    gain.gain.cancelScheduledValues(now);
    gain.gain.setValueAtTime(0, now);
    if (audio) {
      audio.volume = 1;
      audio.muted = false;
    }
    await audio.play();
    if (audio) audio.muted = false;
    const rampStart = context.currentTime;
    gain.gain.cancelScheduledValues(rampStart);
    gain.gain.setValueAtTime(0, rampStart);
    gain.gain.linearRampToValueAtTime(safeTarget, rampStart + 0.055);
  } else if (audio) {
    audio.volume = 0;
    audio.muted = false;
    await audio.play();
    audio.muted = false;
    await rampMediaElementVolume(audio, safeTarget, 55);
  }
}

export function waitForAudioCanPlay(audio, timeoutMs = 4000) {
  if (!audio) return Promise.reject(new Error("No audio element is available"));
  if (audio.error) return Promise.reject(new Error(audio.error.message || 'Music file cannot be played.'));
  if (audio.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) return Promise.resolve();
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => {
      audio.removeEventListener("canplay", done);
      audio.removeEventListener("loadeddata", done);
      audio.removeEventListener("loadedmetadata", done);
      audio.removeEventListener("error", failed);
      window.clearTimeout(timer);
    };
    const done = () => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve();
    };
    const failed = () => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new Error(audio.error?.message || 'Music file cannot be played.'));
    };
    const timer = window.setTimeout(done, timeoutMs);
    audio.addEventListener("canplay", done, { once: true });
    audio.addEventListener("loadeddata", done, { once: true });
    audio.addEventListener("loadedmetadata", done, { once: true });
    audio.addEventListener("error", failed, { once: true });
  });
}

export function createPlayerAudioGraphController({
  getAudio,
  getContext,
  createAnalyser,
  getVolume
} = {}) {
  let source = null;
  let gain = null;

  function currentGain() {
    return gain;
  }

  function applyVolume(volume = getVolume?.()) {
    applyAudioOutputVolume({
      audio: getAudio?.(),
      gain,
      context: getContext?.(),
      volume
    });
  }

  function connectAnalyser() {
    const context = getContext?.();
    const audio = getAudio?.();
    if (!context || !audio) return false;
    if (!source) {
      source = context.createMediaElementSource(audio);
    }
    try { source.disconnect(); } catch (error) {}
    if (gain) {
      try { gain.disconnect(); } catch (error) {}
    }
    const analyser = createAnalyser?.();
    gain = context.createGain();
    gain.gain.value = Math.max(0, Math.min(1, Number(getVolume?.()) || 0));
    source.connect(analyser);
    analyser.connect(gain);
    gain.connect(context.destination);
    return true;
  }

  return {
    currentGain,
    applyVolume,
    connectAnalyser
  };
}

export function queuePendingMusicImport(target, tracks, options) {
  if (target.__queueNativeMusicImport) return target.__queueNativeMusicImport(tracks, options);
  const pending = target.__pendingNativeTracks;
  const batches = pending?.batches || (Array.isArray(pending) && pending.length
      ? [{tracks: pending, options: {}}] : pending?.tracks?.length
        ? [{tracks: pending.tracks, options: pending.options || {}}] : []);
  batches.push({tracks, options});
  target.__pendingNativeTracks = {tracks: batches.flatMap(batch => batch.tracks), batches};
}

export function registerNativeTrackLoadCallbacks({
  target = window,
  isReady = () => true,
  loadTracks,
  retryAutoplay
} = {}) {
  target.__loadNativeTrack = (track, options = {}) => {
    if (!track?.url) return;
    if (!isReady()) {
      queuePendingMusicImport(target, [track], options);
      return;
    }
    loadTracks?.([track], "track", options);
  };

  target.__loadNativeTracks = (tracks, options = {}) => {
    if (!Array.isArray(tracks) || !tracks.length) return;
    if (!isReady()) {
      queuePendingMusicImport(target, tracks, options);
      return;
    }
    loadTracks?.(tracks, "folder", options);
  };

  target.__retryNativeAutoplay = () => {
    retryAutoplay?.();
  };
}

export function registerNativePlayerQueueCallbacks({
  target = window,
  ui,
  isReady,
  releaseObjectUrls,
  setPlayerQueue,
  appendTracks,
  acceptNativeTracks = () => true,
  shouldRetryAutoplay = () => false,
  retryAutoplay
} = {}) {
  registerNativeTrackLoadCallbacks({
    target,
    isReady,
    loadTracks: (tracks, sourceKind, options = {}) => {
      if (!acceptNativeTracks(options)) return;
      if (!appendTracks) releaseObjectUrls?.();
      const loading = appendTracks ? appendTracks(tracks, Boolean(options.autoplay))
        : setPlayerQueue?.(tracks, 0, Boolean(options.autoplay));
      loading.catch((error) => {
        if (ui?.audioStatus) ui.audioStatus.textContent = "player error";
        if (ui?.audioDiagnostic) {
          ui.audioDiagnostic.textContent = `Could not load ${sourceKind}: ${error.message || "unknown error"}`;
        }
        console.error(error);
      });
    },
    retryAutoplay: () => {
      if (!shouldRetryAutoplay?.()) return;
      retryAutoplay?.().catch((error) => {
        if (ui?.audioStatus) ui.audioStatus.textContent = "player blocked";
        if (ui?.audioDiagnostic) {
          ui.audioDiagnostic.textContent = `Autoplay blocked: ${error.name || "Error"} ${error.message || ""}`.trim();
        }
        console.error(error);
      });
    }
  });
}

export function nextTrackIndexForQueue({
  count,
  currentIndex,
  repeatMode = "off",
  shuffleEnabled = false,
  manual = false,
  random = Math.random
}) {
  if (!count) return -1;
  if (!manual && repeatMode === "one") return currentIndex;
  if (shuffleEnabled && count > 1) {
    let next = currentIndex;
    for (let i = 0; i < 8 && next === currentIndex; i += 1) {
      next = Math.floor(random() * count);
    }
    return next === currentIndex ? (currentIndex + 1) % count : next;
  }
  if (currentIndex < count - 1) return currentIndex + 1;
  return repeatMode === "all" || manual ? 0 : -1;
}

export function previousTrackIndexForQueue({
  count,
  currentIndex,
  repeatMode = "off",
  currentTime = 0
}) {
  if (!count) return -1;
  if (currentTime > 3) return currentIndex;
  if (currentIndex > 0) return currentIndex - 1;
  return repeatMode === "all" ? count - 1 : 0;
}
