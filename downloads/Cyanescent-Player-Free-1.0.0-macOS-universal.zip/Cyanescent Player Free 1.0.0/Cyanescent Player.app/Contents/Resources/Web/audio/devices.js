import { SYSTEM_AUDIO_VALUE } from "./systemAudio.js";

export const ENABLE_EXTERNAL_AUDIO_VALUE = "__enable_external_audio__";
export const DEFAULT_EXTERNAL_AUDIO_VALUE = "__default_external_audio__";
export const CHOOSE_EXTERNAL_AUDIO_VALUE = "__choose_external_audio__";

const SAVED_DEVICE_KEY = "cyanescent.audio-input.device-id.v1";
const SAVED_MODE_KEY = "cyanescent.audio-input.mode.v1";
const PLAYER_VALUE = "player";
const SCION_VALUE = "scion";

export function usableAudioInputDeviceId(value) {
  const deviceId = String(value || "").trim();
  return Boolean(deviceId)
    && deviceId !== SYSTEM_AUDIO_VALUE
    && deviceId !== "default"
    && deviceId !== "-1"
    && deviceId !== ENABLE_EXTERNAL_AUDIO_VALUE
    && deviceId !== DEFAULT_EXTERNAL_AUDIO_VALUE
    && deviceId !== CHOOSE_EXTERNAL_AUDIO_VALUE
    && !deviceId.startsWith("__anonymous_external_audio__:");
}

function anonymousAudioInputValue(index) {
  return `__anonymous_external_audio__:${index}`;
}

function isExternalAudioValue(value) {
  return value !== SYSTEM_AUDIO_VALUE
    && value !== PLAYER_VALUE
    && value !== SCION_VALUE
    && value !== ENABLE_EXTERNAL_AUDIO_VALUE
    && value !== CHOOSE_EXTERNAL_AUDIO_VALUE;
}

function opaqueIdSuffix(value) {
  const deviceId = String(value || "");
  return deviceId ? `…${deviceId.slice(-6)}` : "none";
}

function streamDeviceId(stream) {
  return stream?.getAudioTracks?.()[0]?.getSettings?.()?.deviceId || "";
}

function streamTrackLabel(stream) {
  return String(stream?.getAudioTracks?.()[0]?.label || "");
}

function deviceOptionValue(device, index) {
  if (usableAudioInputDeviceId(device?.deviceId)) return device.deviceId;
  if (device?.deviceId === "default") return DEFAULT_EXTERNAL_AUDIO_VALUE;
  return anonymousAudioInputValue(index);
}

function selectedOptionLabel(select) {
  return select?.options?.[select.selectedIndex]?.textContent || "external input";
}

export function audioInputErrorMessage(error) {
  switch (error?.name) {
    case "NotAllowedError":
    case "SecurityError":
      return {
        status: "permission denied",
        diagnostic: "External audio permission was denied. Player Audio and Scion Mode remain available."
      };
    case "NotFoundError":
      return {
        status: "no audio input",
        diagnostic: "No external audio input is currently available."
      };
    case "OverconstrainedError":
      return {
        status: "input changed",
        diagnostic: "The selected audio input is no longer available. The device list was refreshed."
      };
    case "NotReadableError":
      return {
        status: "input unavailable",
        diagnostic: "The selected audio input is busy or could not be opened."
      };
    case "AbortError":
      return {
        status: "input interrupted",
        diagnostic: "External audio startup was interrupted. Please try again."
      };
    default:
      return {
        status: "audio blocked",
        diagnostic: `External audio could not start${error?.message ? `: ${error.message}` : "."}`
      };
  }
}

export function stopMediaStream(stream, reportDiagnostic, reason = "switch") {
  const tracks = stream?.getTracks?.() || [];
  for (const track of tracks) track.stop();
  if (tracks.length) {
    reportDiagnostic?.("stream-cleanup", {
      reason,
      trackCount: tracks.length,
      trackKinds: tracks.map((track) => track.kind || "unknown")
    });
  }
}

export function primeExternalAudioContext({ ensureAudioContext, reportDiagnostic } = {}) {
  const context = ensureAudioContext?.();
  const initialState = context?.state || "unavailable";
  let activationPromise = Promise.resolve(initialState);
  if (context && context.state !== "running" && context.state !== "closed") {
    try {
      // Invoke resume synchronously from the dropdown change event. WKWebView can
      // lose transient user activation while permission and enumeration await.
      activationPromise = Promise.resolve(context.resume()).then(() => context.state).catch((error) => {
        reportDiagnostic?.("audio-context-prime-failed", {
          name: error?.name || "Error",
          message: error?.message || "",
          state: context.state || "unknown"
        });
        return context.state || "unknown";
      });
    } catch (error) {
      reportDiagnostic?.("audio-context-prime-failed", {
        name: error?.name || "Error",
        message: error?.message || "",
        state: context.state || "unknown"
      });
      activationPromise = Promise.resolve(context.state || "unknown");
    }
  }
  reportDiagnostic?.("audio-context-prime-started", { initialState });
  return { context, activationPromise };
}

export function createAudioInputDeviceController({
  select,
  setStatus,
  setDiagnostic,
  getStream,
  setStream,
  getInputSource,
  setInputSource,
  onSelectedDeviceRemoved,
  mediaDevices = navigator.mediaDevices,
  permissions = navigator.permissions,
  storage = window.localStorage,
  timerTarget = window,
  reportDiagnostic,
  systemAudioAvailable = () => false
} = {}) {
  let permissionState = "unknown";
  let permissionRevealed = false;
  let inputs = [];
  let refreshPromise = null;
  let refreshTimer = 0;
  let deviceChangeTimer = 0;
  let lastStableSelection = PLAYER_VALUE;
  let activeDeviceId = "";
  let pendingExternalSelection = false;
  let pendingReturnSelection = PLAYER_VALUE;
  const genericLabels = new Map();

  const builtInSelection = value => value === PLAYER_VALUE || value === SCION_VALUE
    || (value === SYSTEM_AUDIO_VALUE && systemAudioAvailable());

  function savedDeviceId() {
    try {
      const value = storage?.getItem?.(SAVED_DEVICE_KEY) || "";
      return usableAudioInputDeviceId(value) ? value : "";
    } catch (error) {
      return "";
    }
  }

  function clearSavedDevice() {
    try { storage?.removeItem?.(SAVED_DEVICE_KEY); } catch (error) {}
  }

  function savedMode() {
    try { return storage?.getItem?.(SAVED_MODE_KEY) || ""; } catch (error) { return ""; }
  }

  function persistMode(value) {
    const mode = builtInSelection(value) ? value : "external";
    try { storage?.setItem?.(SAVED_MODE_KEY, mode); } catch (error) {}
  }

  function persistDevice(device) {
    if (!permissionRevealed || !device?.label || !usableAudioInputDeviceId(device.deviceId)) return;
    try { storage?.setItem?.(SAVED_DEVICE_KEY, device.deviceId); } catch (error) {}
  }

  async function readPermissionState() {
    try {
      const result = await permissions?.query?.({ name: "microphone" });
      permissionState = result?.state || "unknown";
    } catch (error) {
      permissionState = "unknown";
    }
    reportDiagnostic?.("permission-state", { state: permissionState });
    return permissionState;
  }

  function genericLabel(device, index) {
    const key = usableAudioInputDeviceId(device?.deviceId)
      ? `id:${device.deviceId}`
      : device?.groupId ? `group:${device.groupId}` : `ordinal:${index}`;
    if (!genericLabels.has(key)) genericLabels.set(key, `External Audio Input ${genericLabels.size + 1}`);
    return genericLabels.get(key);
  }

  function createOption(value, label, { disabled = false } = {}) {
    const documentTarget = select?.ownerDocument || document;
    const option = documentTarget.createElement("option");
    option.value = value;
    option.textContent = label;
    option.disabled = disabled;
    select?.appendChild(option);
  }

  function reportDropdownSelection(reason) {
    const value = select?.value || "";
    reportDiagnostic?.("dropdown-rebuild", {
      reason,
      pendingExternalSelection,
      selectedMode: builtInSelection(value)
        ? value
        : value === ENABLE_EXTERNAL_AUDIO_VALUE ? "enable-external"
          : value === CHOOSE_EXTERNAL_AUDIO_VALUE ? "choose-external" : "external",
      idSuffix: usableAudioInputDeviceId(value) ? opaqueIdSuffix(value) : "none"
    });
  }

  function renderDevices(
    preferredValue = select?.value || lastStableSelection,
    { reason = "render" } = {}
  ) {
    if (!select) return;
    select.innerHTML = "";
    createOption(PLAYER_VALUE, "Player Audio");
    createOption(SCION_VALUE, "Scion Mode");
    if (systemAudioAvailable()) createOption(SYSTEM_AUDIO_VALUE, "System Audio");

    if (!permissionRevealed) {
      createOption(ENABLE_EXTERNAL_AUDIO_VALUE, "Enable External Audio Inputs…");
      select.value = pendingExternalSelection
        ? ENABLE_EXTERNAL_AUDIO_VALUE
        : builtInSelection(preferredValue)
        ? preferredValue
        : lastStableSelection;
      reportDropdownSelection(reason);
      return;
    }

    const pendingNeedsChoice = pendingExternalSelection
      && !usableAudioInputDeviceId(preferredValue)
      && preferredValue !== DEFAULT_EXTERNAL_AUDIO_VALUE
      && !String(preferredValue || "").startsWith("__anonymous_external_audio__:");
    if (pendingNeedsChoice) {
      createOption(CHOOSE_EXTERNAL_AUDIO_VALUE, "Choose External Input…", { disabled: true });
    }
    inputs.forEach((device, index) => {
      const value = deviceOptionValue(device, index);
      const label = device.label || genericLabel(device, index);
      createOption(value, label);
    });

    const availableValues = new Set(inputs.map(deviceOptionValue));
    const saved = savedDeviceId();
    const desired = pendingNeedsChoice
      ? CHOOSE_EXTERNAL_AUDIO_VALUE
      : builtInSelection(preferredValue) || availableValues.has(preferredValue)
      ? preferredValue
      : availableValues.has(saved) ? saved : lastStableSelection;
    select.value = desired === CHOOSE_EXTERNAL_AUDIO_VALUE
      || builtInSelection(desired)
      || availableValues.has(desired)
      ? desired
      : PLAYER_VALUE;
    reportDropdownSelection(reason);
  }

  async function enumerate({ reason = "manual", preferredValue } = {}) {
    if (!mediaDevices?.enumerateDevices) {
      inputs = [];
      renderDevices(preferredValue, { reason });
      return inputs;
    }
    const devices = await mediaDevices.enumerateDevices();
    inputs = devices.filter((device) => device.kind === "audioinput");
    if (permissionState === "granted" || inputs.some((device) => Boolean(device.label))) {
      permissionRevealed = true;
    }
    reportDiagnostic?.("enumerate", {
      reason,
      permissionState,
      devices: devices.map((device) => ({
        kind: device.kind,
        labelAvailable: Boolean(device.label),
        idSuffix: opaqueIdSuffix(device.deviceId)
      }))
    });
    renderDevices(preferredValue, { reason });
    return inputs;
  }

  async function refreshDevices(options = {}) {
    if (refreshPromise) return refreshPromise;
    const preferredValue = options.preferredValue || select?.value || lastStableSelection;
    refreshPromise = (async () => {
      await readPermissionState();
      return enumerate({ ...options, preferredValue });
    })();
    try {
      return await refreshPromise;
    } finally {
      refreshPromise = null;
    }
  }

  function refreshDevicesOnDemand() {
    timerTarget.clearTimeout?.(refreshTimer);
    refreshTimer = timerTarget.setTimeout?.(() => {
      refreshDevices({ reason: "dropdown-open" }).catch((error) => presentError(error));
    }, 0);
  }

  function stopInputStream(reason = "mode-switch") {
    const source = getInputSource?.();
    if (source) {
      try { source.disconnect(); } catch (error) {}
      setInputSource?.(null);
      reportDiagnostic?.("source-cleanup", { reason });
    }
    stopMediaStream(getStream?.(), reportDiagnostic, reason);
    setStream?.(null);
    activeDeviceId = "";
  }

  function rememberSelection(value) {
    if (builtInSelection(value) || isExternalAudioValue(value)) {
      lastStableSelection = value;
      persistMode(value);
    }
    if (builtInSelection(value)) {
      if (pendingExternalSelection) {
        reportDiagnostic?.("external-intent-cancelled", { reason: `user-selected-${value}` });
      }
      pendingExternalSelection = false;
      pendingReturnSelection = value;
    }
    reportDiagnostic?.("selected-mode", {
      mode: builtInSelection(value) ? value : "external",
      idSuffix: usableAudioInputDeviceId(value) ? opaqueIdSuffix(value) : "none"
    });
  }

  function presentError(error) {
    const message = audioInputErrorMessage(error);
    setStatus?.(message.status);
    setDiagnostic?.(message.diagnostic);
    reportDiagnostic?.("failure", {
      name: error?.name || "Error",
      message: error?.message || "",
      constraint: error?.constraint || ""
    });
    return message;
  }

  function externalSelectionDecision(defaultDeviceId = "") {
    const realInputs = inputs.filter((device) => usableAudioInputDeviceId(device.deviceId));
    if (realInputs.length === 1) {
      return { device: realInputs[0], reason: "single-device" };
    }

    const saved = savedDeviceId();
    const savedDevice = realInputs.find((device) => device.deviceId === saved);
    if (savedDevice) return { device: savedDevice, reason: "saved-device" };

    const permissionDefault = realInputs.find((device) => device.deviceId === defaultDeviceId);
    if (permissionDefault) return { device: permissionDefault, reason: "permission-default" };

    const defaultEntry = inputs.find((device) => device.deviceId === "default");
    const defaultLabel = String(defaultEntry?.label || "").replace(/^default\s*[-:]\s*/i, "").trim();
    const labelledDefault = defaultLabel
      ? realInputs.find((device) => device.label === defaultLabel || defaultEntry.label.includes(device.label))
      : null;
    if (labelledDefault) return { device: labelledDefault, reason: "labelled-default" };
    if (defaultEntry) return { device: defaultEntry, reason: "system-default" };

    if (!realInputs.length && inputs.length === 1) {
      return { device: inputs[0], reason: "single-unconstrained-device" };
    }
    return { device: null, reason: inputs.length ? "multiple-devices" : "no-devices" };
  }

  function fallBackFromExternalIntent(reason, error = null) {
    const fallbackValue = builtInSelection(pendingReturnSelection)
      ? pendingReturnSelection
      : PLAYER_VALUE;
    pendingExternalSelection = false;
    lastStableSelection = fallbackValue;
    renderDevices(fallbackValue, { reason: `external-fallback-${reason}` });
    reportDiagnostic?.("external-intent-fallback", { reason, fallbackMode: fallbackValue });
    if (error) presentError(error);
    return fallbackValue;
  }

  async function resolveExternalIntent() {
    pendingReturnSelection = builtInSelection(lastStableSelection)
      ? lastStableSelection
      : PLAYER_VALUE;
    pendingExternalSelection = true;
    reportDiagnostic?.("external-intent-selected", { returnMode: pendingReturnSelection });
    reportDiagnostic?.("pending-selection-preserved", { pendingMode: "external" });
    let permissionStream = null;
    let defaultDeviceId = "";
    try {
      await readPermissionState();
      await enumerate({ reason: "external-intent", preferredValue: ENABLE_EXTERNAL_AUDIO_VALUE });

      if (!permissionRevealed) {
        reportDiagnostic?.("permission-request-started", { constraints: { audio: true } });
        permissionStream = await mediaDevices.getUserMedia({ audio: true });
        permissionRevealed = true;
        permissionState = "granted";
        defaultDeviceId = streamDeviceId(permissionStream);
        reportDiagnostic?.("permission-request-completed", {
          granted: true,
          idSuffix: opaqueIdSuffix(defaultDeviceId),
          trackCount: permissionStream.getTracks?.().length || 0
        });
        stopMediaStream(permissionStream, reportDiagnostic, "permission-probe");
        permissionStream = null;
        await enumerate({ reason: "permission-completed", preferredValue: CHOOSE_EXTERNAL_AUDIO_VALUE });
      } else {
        reportDiagnostic?.("permission-request-not-needed", { state: permissionState });
      }

      reportDiagnostic?.("devices-after-permission", {
        count: inputs.length,
        usableCount: inputs.filter((device) => usableAudioInputDeviceId(device.deviceId)).length
      });
      const decision = externalSelectionDecision(defaultDeviceId);
      if (!decision.device) {
        if (!inputs.length) {
          setStatus?.("no audio input");
          setDiagnostic?.("No external audio input is currently available.");
          fallBackFromExternalIntent("no-devices");
          return { selection: "", reason: "no-devices", inputs };
        }
        renderDevices(CHOOSE_EXTERNAL_AUDIO_VALUE, { reason: "external-choice-required" });
        setStatus?.("choose external input");
        setDiagnostic?.("Choose an external audio input from the newly refreshed device list.");
        reportDiagnostic?.("pending-selection-preserved", {
          pendingMode: "external",
          reason: "multiple-devices"
        });
        return { selection: "", reason: "multiple-devices", inputs };
      }

      const selectedIndex = inputs.indexOf(decision.device);
      const selection = deviceOptionValue(decision.device, selectedIndex);
      renderDevices(selection, { reason: "external-device-resolved" });
      if (select) select.value = selection;
      reportDiagnostic?.("automatic-device-chosen", {
        reason: decision.reason,
        idSuffix: usableAudioInputDeviceId(selection) ? opaqueIdSuffix(selection) : "none"
      });
      return { selection, reason: decision.reason, inputs };
    } catch (error) {
      stopMediaStream(permissionStream, reportDiagnostic, "permission-error");
      await readPermissionState();
      if (error?.name === "NotAllowedError" || error?.name === "SecurityError") {
        reportDiagnostic?.("permission-request-completed", { granted: false, name: error.name });
      }
      fallBackFromExternalIntent(
        error?.name === "NotAllowedError" || error?.name === "SecurityError"
          ? "permission-denied"
          : "discovery-error",
        error
      );
      return { selection: "", reason: error?.name || "Error", error, inputs };
    }
  }

  function deviceForSelection(value, currentInputs = inputs) {
    return currentInputs.find((device, index) => deviceOptionValue(device, index) === value) || null;
  }

  function exactConstraints(deviceId) {
    return {
      audio: {
        deviceId: { exact: deviceId },
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false
      },
      video: false
    };
  }

  async function acquireSelectedStream(selectedDeviceId) {
    const requestedValue = String(selectedDeviceId || "");
    const latestInputs = await refreshDevices({
      reason: "selection-validation",
      preferredValue: requestedValue
    });
    const selectedDevice = deviceForSelection(requestedValue, latestInputs);
    const canUseExact = usableAudioInputDeviceId(requestedValue) && Boolean(selectedDevice);
    reportDiagnostic?.("selection-existence-check", {
      exists: Boolean(selectedDevice),
      exactEligible: canUseExact,
      idSuffix: usableAudioInputDeviceId(requestedValue) ? opaqueIdSuffix(requestedValue) : "none"
    });

    async function acquireFallback(reason) {
      clearSavedDevice();
      await refreshDevices({ reason: "stale-selection", preferredValue: PLAYER_VALUE });
      reportDiagnostic?.("fallback", { reason, constraints: { audio: true }, attempt: 1 });
      const fallbackStream = await mediaDevices.getUserMedia({ audio: true });
      activeDeviceId = streamDeviceId(fallbackStream);
      setStream?.(fallbackStream);
      const refreshedInputs = await enumerate({
        reason: "fallback-acquired",
        preferredValue: activeDeviceId || DEFAULT_EXTERNAL_AUDIO_VALUE
      });
      const actualDevice = refreshedInputs.find((device) => device.deviceId === activeDeviceId)
        || refreshedInputs.find((device) => device.label === streamTrackLabel(fallbackStream))
        || null;
      const fallbackValue = actualDevice
        ? deviceOptionValue(actualDevice, refreshedInputs.indexOf(actualDevice))
        : DEFAULT_EXTERNAL_AUDIO_VALUE;
      if (select && !Array.from(select.options || []).some((option) => option.value === fallbackValue)) {
        createOption(fallbackValue, streamTrackLabel(fallbackStream) || "External Audio Input");
      }
      if (select) select.value = fallbackValue;
      persistDevice(actualDevice);
      rememberSelection(actualDevice?.deviceId || DEFAULT_EXTERNAL_AUDIO_VALUE);
      pendingExternalSelection = false;
      reportDiagnostic?.("stream-acquired", {
        fallback: true,
        idSuffix: opaqueIdSuffix(activeDeviceId),
        trackCount: fallbackStream.getTracks?.().length || 0
      });
      reportDiagnostic?.("final-stream-start", {
        fallback: true,
        idSuffix: opaqueIdSuffix(activeDeviceId)
      });
      setStatus?.("input changed");
      setDiagnostic?.(`The saved input was unavailable; using ${selectedOptionLabel(select)} instead.`);
      return { stream: fallbackStream, device: actualDevice, fallback: true };
    }

    if (usableAudioInputDeviceId(requestedValue) && !selectedDevice) {
      stopInputStream("stale-external-selection");
      return acquireFallback("missing-device-id");
    }

    const constraints = canUseExact ? exactConstraints(requestedValue) : { audio: true };
    reportDiagnostic?.("get-user-media", {
      constraints: canUseExact ? {
        audio: {
          deviceId: { exact: `<opaque:${opaqueIdSuffix(requestedValue)}>` },
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        },
        video: false
      } : { audio: true }
    });

    stopInputStream("external-device-switch");
    try {
      const acquired = await mediaDevices.getUserMedia(constraints);
      activeDeviceId = streamDeviceId(acquired) || (canUseExact ? requestedValue : "");
      setStream?.(acquired);
      const actualDevice = latestInputs.find((device) => device.deviceId === activeDeviceId)
        || selectedDevice;
      const actualSelection = actualDevice
        ? deviceOptionValue(actualDevice, latestInputs.indexOf(actualDevice))
        : requestedValue;
      if (select && Array.from(select.options || []).some((option) => option.value === actualSelection)) {
        select.value = actualSelection;
      }
      persistDevice(actualDevice);
      rememberSelection(actualSelection);
      pendingExternalSelection = false;
      reportDiagnostic?.("stream-acquired", {
        fallback: false,
        idSuffix: opaqueIdSuffix(activeDeviceId),
        trackCount: acquired.getTracks?.().length || 0
      });
      reportDiagnostic?.("final-stream-start", {
        fallback: false,
        idSuffix: opaqueIdSuffix(activeDeviceId)
      });
      return { stream: acquired, device: actualDevice, fallback: false };
    } catch (error) {
      reportDiagnostic?.("stream-acquire-failed", {
        name: error?.name || "Error",
        message: error?.message || "",
        retryEligible: error?.name === "OverconstrainedError" || error?.name === "NotFoundError"
      });
      if (error?.name !== "OverconstrainedError" && error?.name !== "NotFoundError") throw error;
      return acquireFallback(error.name);
    }
  }

  async function handleDeviceChange() {
    reportDiagnostic?.("devicechange", { activeIdSuffix: opaqueIdSuffix(activeDeviceId) });
    const preferred = select?.value || lastStableSelection;
    const latestInputs = await refreshDevices({ reason: "devicechange", preferredValue: preferred });
    if (!activeDeviceId || latestInputs.some((device) => device.deviceId === activeDeviceId)) return;
    clearSavedDevice();
    stopInputStream("selected-device-removed");
    lastStableSelection = PLAYER_VALUE;
    persistMode(PLAYER_VALUE);
    renderDevices(PLAYER_VALUE);
    setStatus?.("input disconnected");
    setDiagnostic?.("The selected external input was removed. Player Audio is now selected.");
    reportDiagnostic?.("selected-device-removed", { fallbackMode: PLAYER_VALUE });
    onSelectedDeviceRemoved?.();
  }

  function scheduleDeviceChange() {
    timerTarget.clearTimeout?.(deviceChangeTimer);
    deviceChangeTimer = timerTarget.setTimeout?.(() => {
      handleDeviceChange().catch((error) => presentError(error));
    }, 250);
  }

  async function initialize() {
    renderDevices(PLAYER_VALUE);
    mediaDevices?.addEventListener?.("devicechange", scheduleDeviceChange);
    const latestInputs = await refreshDevices({ reason: "startup", preferredValue: PLAYER_VALUE });
    const saved = savedDeviceId();
    const savedDevice = saved
      ? latestInputs.find((device) => device.deviceId === saved && device.label)
      : null;
    const restoreDevice = savedMode() === "external" ? savedDevice : null;
    if (saved && !savedDevice && permissionRevealed) clearSavedDevice();
    return { restoreDeviceId: restoreDevice?.deviceId || "", permissionState, inputs: latestInputs };
  }

  return {
    initialize,
    refreshDevices,
    refreshDevicesOnDemand,
    resolveExternalIntent,
    enableExternalInputs: resolveExternalIntent,
    acquireSelectedStream,
    stopInputStream,
    rememberSelection,
    presentError,
    fallBackFromExternalIntent,
    permissionState: () => permissionState,
    permissionRevealed: () => permissionRevealed,
    inputs: () => inputs.slice(),
    pendingExternalSelection: () => pendingExternalSelection
  };
}

export async function startExternalAudioMonitoring({
  ui,
  nativeAppBridge,
  getPlayerAudio,
  setPlayerMode,
  setMonitoringInput,
  incrementAnalysisGeneration,
  setAnalysisPending,
  setAnalysisTimeline,
  resetLookaheadState,
  stopInputStream,
  acquireInputStream,
  ensureAudioContext,
  makeAnalyser,
  setInputSource,
  reportDiagnostic
} = {}) {
  getPlayerAudio?.()?.pause();
  incrementAnalysisGeneration?.();
  setAnalysisPending?.(false);
  setAnalysisTimeline?.(null);
  resetLookaheadState?.();
  stopInputStream?.("external-start");
  nativeAppBridge?.()?.postMessage("stopNativeAudio");

  const requestedDeviceId = ui?.deviceSelect?.value || "";
  const result = await acquireInputStream?.(requestedDeviceId);
  const stream = result?.stream;
  if (!stream) throw new Error("No external audio stream was returned.");

  try {
    setMonitoringInput?.(true);
    setPlayerMode?.(false);
    const context = ensureAudioContext?.();
    if (!context) throw new Error("The Web Audio context is unavailable.");
    const analyser = makeAnalyser?.();
    if (!analyser) throw new Error("The external-input analyser is unavailable.");
    const source = context.createMediaStreamSource(stream);
    source.connect(analyser);
    setInputSource?.(source);
    reportDiagnostic?.("external-graph-connected", {
      contextState: context.state || "unknown",
      liveAudioTracks: stream.getAudioTracks?.().filter((track) => track.readyState !== "ended").length || 0
    });
    if (context.state !== "running" && context.state !== "closed") {
      await context.resume();
    }
    reportDiagnostic?.("external-graph-active", { contextState: context.state || "unknown" });
    // Start the native fallback only after the Web Audio source/analyser graph is
    // attached, avoiding a first-permission capture-initialisation race.
    nativeAppBridge?.()?.postMessage("startNativeAudio");
    const selected = selectedOptionLabel(ui?.deviceSelect);
    if (ui?.audioStatus) ui.audioStatus.textContent = selected.length > 18 ? "audio active" : selected;
    if (ui?.audioDiagnostic) ui.audioDiagnostic.textContent = `Web audio using ${selected}`;
    reportDiagnostic?.("monitoring-active", { fallback: Boolean(result.fallback) });
    return result;
  } catch (error) {
    stopInputStream?.("monitoring-start-failed");
    nativeAppBridge?.()?.postMessage("stopNativeAudio");
    setMonitoringInput?.(false);
    throw error;
  }
}
