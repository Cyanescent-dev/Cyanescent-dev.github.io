import {
  createAnalyserBuffers,
  createConfiguredAnalyser,
  ensureAudioContextInstance,
  resumeAudioContextBestEffort
} from "./audioContext.js";
import {
  createPlayerAudioElement,
  createPlayerAudioGraphController,
  playerVolumeFromControl,
  playAudioElementWithFade
} from "./playerSources.js";
import {
  mediaDuration,
  timelineDuration
} from "../ui/playlist.js";

export function createPlayerElementEventHandlers({
  ui,
  handleTrackEnded,
  updateTrackTimeDisplay,
  updateWaveformProgress,
  pendingAutoplay,
  autoplayLoadedTrack,
  handleSeek,
  onVisualPlaybackStarted,
  onDurationAvailable,
  onPlaybackStateChanged,
  handlePlayerError
} = {}) {
  function reportAutoplayBlocked(error) {
    if (ui?.audioStatus) ui.audioStatus.textContent = "player blocked";
    if (ui?.audioDiagnostic) {
      ui.audioDiagnostic.textContent = `Autoplay blocked: ${error.name || "Error"} ${error.message || ""}`.trim();
    }
    console.error(error);
  }

  function tryAutoplayLoadedTrack() {
    if (!pendingAutoplay?.()) return;
    autoplayLoadedTrack?.().catch(reportAutoplayBlocked);
  }

  return {
    onEnded: () => {
      onPlaybackStateChanged?.("paused");
      if (ui?.playPause) ui.playPause.textContent = "Play";
      if (ui?.audioStatus) ui.audioStatus.textContent = "player ready";
      handleTrackEnded?.().catch((error) => {
        if (ui?.audioStatus) ui.audioStatus.textContent = "player error";
        if (ui?.audioDiagnostic) {
          ui.audioDiagnostic.textContent = `Could not advance queue: ${error.message || "unknown error"}`;
        }
        console.error(error);
      });
    },
    onPause: () => {
      onPlaybackStateChanged?.("paused");
      if (ui?.playPause) ui.playPause.textContent = "Play";
      updateTrackTimeDisplay?.();
    },
    onPlay: () => {
      onPlaybackStateChanged?.("playing");
      if (ui?.playPause) ui.playPause.textContent = "Pause";
      if (ui?.audioStatus) ui.audioStatus.textContent = "player audio";
      updateTrackTimeDisplay?.();
      onVisualPlaybackStarted?.();
    },
    onMetadata: () => {
      updateTrackTimeDisplay?.();
      updateWaveformProgress?.(true);
      onDurationAvailable?.();
      tryAutoplayLoadedTrack();
    },
    onCanPlay: tryAutoplayLoadedTrack,
    onError: (mediaError, audio) => {
      const code = mediaError?.code ?? 0;
      const message = mediaError?.message || "HTML media source failed to load";
      console.error("Audio media-element load failed", {
        name: "MediaError",
        message,
        code,
        source: audio?.currentSrc || audio?.src || ""
      });
      handlePlayerError?.(audio)?.catch(reportAutoplayBlocked);
    },
    onDurationChange: () => {
      updateTrackTimeDisplay?.();
      updateWaveformProgress?.(true);
      onDurationAvailable?.();
    },
    onTimeUpdate: () => {
      updateTrackTimeDisplay?.();
    },
    onSeeked: (time) => handleSeek?.(time)
  };
}

export function createPlayerRuntime({
  volumeControl,
  getPlayerAudio,
  setPlayerAudio,
  getAnalysisTimeline,
  stopInputStream,
  setPlayerMode,
  activateVisuals,
  playerElementEvents
} = {}) {
  let audioContext = null;
  let analyser = null;
  let freq = null;
  let timeData = null;
  let playerAudioGraph = null;

  function ensureAudioContext() {
    audioContext = ensureAudioContextInstance(audioContext);
    return audioContext;
  }

  async function resumeAudioContext(timeoutMs = 450) {
    return resumeAudioContextBestEffort(ensureAudioContext(), timeoutMs);
  }

  function makeAnalyser() {
    if (analyser) {
      try { analyser.disconnect(); } catch (error) {}
    }
    analyser = createConfiguredAnalyser(ensureAudioContext());
    const buffers = createAnalyserBuffers(analyser);
    freq = buffers.frequency;
    timeData = buffers.time;
    return analyser;
  }

  function currentPlayerVolume() {
    return playerVolumeFromControl(volumeControl);
  }

  function playerAudioGraphController() {
    if (!playerAudioGraph) {
      playerAudioGraph = createPlayerAudioGraphController({
        getAudio: getPlayerAudio,
        getContext: ensureAudioContext,
        createAnalyser: makeAnalyser,
        getVolume: currentPlayerVolume
      });
    }
    return playerAudioGraph;
  }

  function applyPlayerVolume() {
    playerAudioGraphController().applyVolume(currentPlayerVolume());
  }

  async function setupPlayerAnalyser(options = {}) {
    stopInputStream?.();
    setPlayerMode?.(true);
    const context = ensureAudioContext();
    if (context.state === "suspended") {
      const resumed = options.bestEffort
        ? await resumeAudioContext(options.timeoutMs || 450)
        : (await context.resume(), true);
      if (!resumed) return false;
    }
    return playerAudioGraphController().connectAnalyser();
  }

  async function playPlayerAudioWithFade(options = {}) {
    const setupAnalyserFirst = options.setupAnalyserFirst !== false;
    const context = setupAnalyserFirst ? ensureAudioContext() : null;
    const audio = ensurePlayer();
    if (setupAnalyserFirst) {
      await setupPlayerAnalyser?.();
    }
    await playAudioElementWithFade({
      audio,
      context,
      gain: setupAnalyserFirst ? playerAudioGraphController().currentGain() : null,
      targetVolume: currentPlayerVolume()
    });
    activateVisuals?.(1400);
  }

  function playerDuration() {
    return mediaDuration(getPlayerAudio?.());
  }

  function waveformDuration() {
    return timelineDuration(getAnalysisTimeline?.(), getPlayerAudio?.());
  }

  function ensurePlayer() {
    let audio = getPlayerAudio?.();
    if (audio) return audio;
    audio = createPlayerAudioElement(playerElementEvents);
    setPlayerAudio?.(audio);
    return audio;
  }

  function clearAnalyserBuffers() {
    analyser = null;
    freq = null;
    timeData = null;
  }

  function analyserState() {
    return { audioContext, analyser, freq, timeData };
  }

  return {
    ensureAudioContext,
    resumeAudioContext,
    makeAnalyser,
    currentPlayerVolume,
    playerAudioGraphController,
    applyPlayerVolume,
    setupPlayerAnalyser,
    playPlayerAudioWithFade,
    playerDuration,
    waveformDuration,
    ensurePlayer,
    clearAnalyserBuffers,
    analyserState,
    get audioContext() { return audioContext; },
    get analyser() { return analyser; },
    get freq() { return freq; },
    get timeData() { return timeData; }
  };
}
