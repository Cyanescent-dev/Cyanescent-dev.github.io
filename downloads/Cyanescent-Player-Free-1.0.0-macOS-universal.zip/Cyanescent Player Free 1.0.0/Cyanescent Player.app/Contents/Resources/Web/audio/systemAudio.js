export const SYSTEM_AUDIO_VALUE = "systemAudio";

export function systemAudioSupported(target = globalThis.window) {
  return target?.__cyanescentNativeAudioCapabilities?.systemAudio === true
    && typeof target?.webkit?.messageHandlers?.nativeApp?.postMessage === "function";
}

// A request token prevents a late permission/start reply from reactivating an
// input after the user has chosen Player Audio, Scion, or an external device.
export function createSystemAudioInputController({
  target = window,
  bridge,
  supported = () => systemAudioSupported(target),
  isSelected = () => true,
  onStatus = () => {},
  timeoutMs = 120000
} = {}) {
  let serial = 0;
  let activeRequest = null;
  let pending = null;

  function finish(value) {
    if (!pending) return;
    target.clearTimeout(pending.timer);
    const resolve = pending.resolve;
    pending = null;
    resolve(value);
  }

  function stop() {
    if (activeRequest == null) return;
    activeRequest = null;
    finish(false);
    try { bridge()?.postMessage("stopNativeAudio"); } catch { /* The window may be closing. */ }
  }

  function receive({ detail } = {}) {
    if (!detail || detail.requestID !== activeRequest) return;
    if (!isSelected()) { stop(); return; }
    if (detail.status === "started") {
      onStatus("system audio", "Listening to system audio. If the meter stays silent while music plays, check Screen & System Audio Recording access in System Settings.");
      finish(true);
    } else if (detail.status === "error") {
      onStatus("system audio unavailable", detail.error || "Choose BlackHole or another external input, or check system audio recording permission.");
      stop();
    }
  }
  target.addEventListener("cyanescent-system-audio-status", receive);

  function start() {
    stop();
    if (!supported()) {
      onStatus("system audio unavailable", "System Audio requires macOS 14.2 or later. Choose BlackHole or another external input.");
      return Promise.resolve(false);
    }
    const requestID = `system-audio-${++serial}`;
    activeRequest = requestID;
    onStatus("system audio starting", "Allow system audio recording if macOS asks. Your normal audio output stays unchanged.");
    return new Promise(resolve => {
      pending = { resolve, timer: target.setTimeout(() => {
        if (activeRequest !== requestID) return;
        onStatus("system audio unavailable", "System audio capture did not start. Check recording permission in System Settings, then retry or choose an external input.");
        stop();
      }, timeoutMs) };
      try {
        bridge().postMessage({ command: "startSystemAudio", requestID });
      } catch (error) {
        onStatus("system audio unavailable", error.message || "The native audio bridge is unavailable.");
        stop();
      }
    });
  }

  return { start, stop, dispose() {
    stop();
    target.removeEventListener("cyanescent-system-audio-status", receive);
  } };
}
