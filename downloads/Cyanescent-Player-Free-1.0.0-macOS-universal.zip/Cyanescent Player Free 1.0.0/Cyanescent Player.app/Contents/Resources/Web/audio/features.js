import { clamp01, mixJs, smoothstepJs } from "../utils/math.js";
import { computeDropMap, mergeDropMarkers } from "./dropMap.js";

function yieldToInterface() {
  return new Promise((resolve) => window.setTimeout(resolve, 0));
}

function errorDetail(error) {
  return {
    name: error?.name || "Error",
    message: error?.message || String(error || "Unknown error"),
    stack: error?.stack || ""
  };
}

export class AudioAnalysisTimeline {
  constructor(frames, frameDuration, duration, waveformPeaks = [], sections = [], tempo = null, beatGrid = []) {
    this.frames = frames;
    this.frameDuration = frameDuration;
    this.duration = duration;
    this.waveformPeaks = waveformPeaks;
    this.sections = sections;
    this.tempo = tempo;
    this.beatGrid = beatGrid;
    // the drops found in the audio (see dropMap.js); markers from the listener refine them
    this.autoDrops = computeDropMap({ frames, frameDuration, beatGrid, duration });
    this.fingerprint = AudioAnalysisTimeline.fingerprintOf(frames, duration);
    this.dropMarkers = [];
    this.drops = this.autoDrops;
  }

  // A stable identity for the track's audio (Player has no stable track id: native tracks get a
  // new one per load and browser files have none): its duration and the loudness contour,
  // quantised to half a dB, hashed (FNV-1a). Same file, same fingerprint, whatever its name.
  static fingerprintOf(frames, duration) {
    let hash = 0x811c9dc5;
    const mix = (value) => { hash ^= value & 0xff; hash = Math.imul(hash, 0x01000193) >>> 0; hash ^= (value >>> 8) & 0xff; hash = Math.imul(hash, 0x01000193) >>> 0; };
    mix(Math.round((Number(duration) || 0) * 10));
    const step = Math.max(1, Math.floor(frames.length / 4096));
    for (let i = 0; i < frames.length; i += step) {
      const f = frames[i];
      mix(Math.round((Number.isFinite(f.fullDb) ? f.fullDb : 20 * Math.log10(Math.max(1e-5, f.energy / 3.2))) * 2) + 512);
    }
    return `a${hash.toString(16).padStart(8, "0")}-${Math.round((Number(duration) || 0) * 10)}`;
  }

  // Markers: [{ time, kind: "major" | "minor" | "none" }] (see mergeDropMarkers).
  setDropMarkers(markers = []) {
    this.dropMarkers = Array.isArray(markers) ? markers.filter((m) => Number.isFinite(m?.time)) : [];
    this.drops = mergeDropMarkers(this.autoDrops, this.dropMarkers);
    return this.drops;
  }

  // The drop state at a track time: the next drop, the last one, and where we are between them.
  getDropInfo(time) {
    const drops = this.drops || [];
    let next = null, last = null;
    for (const drop of drops) {
      if (drop.time > time) { next = drop; break; }
      last = drop;
    }
    const beatDuration = this.tempo?.beatDuration || (this.tempo?.bpm ? 60 / this.tempo.bpm : 0.41);
    return {
      next,
      last,
      secondsToNext: next ? next.time - time : Infinity,
      beatsToNext: next ? (next.time - time) / beatDuration : Infinity,
      // 0 before the lead-in, rising to 1 at the drop
      leadInProgress: next ? clamp01((time - next.leadIn) / Math.max(0.5, next.time - next.leadIn)) : 0,
      secondsSinceLast: last ? time - last.time : Infinity
    };
  }

  static async fromSource(src, context, { onWaveformProgress, onLoadStage } = {}) {
    let parsedSource = null;
    try { parsedSource = new URL(String(src || ""), window.location.href); } catch (error) {}
    onLoadStage?.("fetch-start", {
      source: String(src || ""),
      scheme: parsedSource?.protocol?.replace(":", "") || "unknown"
    });
    let response;
    try {
      response = await fetch(src, { cache: "no-store" });
    } catch (error) {
      onLoadStage?.("fetch-failed", { error: errorDetail(error) });
      throw error;
    }
    onLoadStage?.("fetch-response", {
      ok: response.ok,
      status: response.status,
      type: response.type,
      responseURL: response.url || "",
      contentLength: response.headers.get("content-length") || "unknown"
    });
    if (!response.ok) throw new Error(`Audio fetch failed: ${response.status}`);
    let data;
    try {
      data = await response.arrayBuffer();
      onLoadStage?.("array-buffer-ready", { bytes: data.byteLength });
    } catch (error) {
      onLoadStage?.("array-buffer-failed", { error: errorDetail(error) });
      throw error;
    }
    let buffer;
    try {
      buffer = await decodeAudioBuffer(context, data);
      onLoadStage?.("decode-ready", {
        duration: buffer.duration,
        sampleRate: buffer.sampleRate,
        channels: buffer.numberOfChannels
      });
    } catch (error) {
      onLoadStage?.("decode-failed", { error: errorDetail(error) });
      throw error;
    }
    return AudioAnalysisTimeline.fromAudioBuffer(buffer, { onWaveformProgress });
  }

  static async fromAudioBuffer(buffer, { onWaveformProgress } = {}) {
    const sampleRate = buffer.sampleRate;
    const channels = [];
    for (let channel = 0; channel < buffer.numberOfChannels; channel += 1) {
      channels.push(buffer.getChannelData(channel));
    }
    const frameDuration = 0.05;
    const frameSize = Math.max(1024, Math.floor(sampleRate * frameDuration));
    const frameCount = Math.max(1, Math.ceil(buffer.length / frameSize));
    const lowAlpha = 1 - Math.exp(-2 * Math.PI * 180 / sampleRate);
    const midAlpha = 1 - Math.exp(-2 * Math.PI * 2400 / sampleRate);
    let low = 0;
    let midLow = 0;
    let previousEnergy = 0;
    let previousBrightness = 0;
    let trendEnergy = 0;
    let trendBrightness = 0;
    const frames = [];
    let sliceStartedAt = performance.now();
    // Begin peak extraction immediately and let both long-running passes yield
    // to the UI. The waveform can then appear progressively before the more
    // expensive musical analysis completes.
    const waveformPeaksPromise = AudioAnalysisTimeline.makeWaveformPeaks(
      channels,
      buffer.length,
      960,
      onWaveformProgress
    );

    for (let frame = 0; frame < frameCount; frame += 1) {
      const start = frame * frameSize;
      const end = Math.min(buffer.length, start + frameSize);
      let sum = 0;
      let peak = 0;
      let bassSum = 0;
      let midSum = 0;
      let trebleSum = 0;

      for (let i = start; i < end; i += 1) {
        let sample = 0;
        for (const channel of channels) sample += channel[i] || 0;
        sample /= Math.max(1, channels.length);
        low += lowAlpha * (sample - low);
        midLow += midAlpha * (sample - midLow);
        const bassSample = low;
        const midSample = midLow - low;
        const trebleSample = sample - midLow;
        const abs = Math.abs(sample);
        peak = Math.max(peak, abs);
        sum += sample * sample;
        bassSum += bassSample * bassSample;
        midSum += midSample * midSample;
        trebleSum += trebleSample * trebleSample;
      }

      const count = Math.max(1, end - start);
      const energy = clamp01(Math.sqrt(sum / count) * 3.2);
      const bass = clamp01(Math.sqrt(bassSum / count) * 4.2);
      const mid = clamp01(Math.sqrt(midSum / count) * 4.8);
      const treble = clamp01(Math.sqrt(trebleSum / count) * 7.0);
      const brightness = clamp01((treble * 0.75 + mid * 0.25) / Math.max(0.08, bass + mid + treble));
      const flux = clamp01(Math.max(0, energy - previousEnergy) * 5.0 + Math.max(0, brightness - previousBrightness) * 1.5);
      trendEnergy = mixJs(trendEnergy, energy, 0.045);
      trendBrightness = mixJs(trendBrightness, brightness, 0.045);
      const beatStrength = clamp01(Math.max(0, energy - previousEnergy * 0.86) * 6.0 + bass * 0.20 + flux * 0.16);
      const sectionProbability = clamp01(Math.abs(energy - trendEnergy) * 1.35 + Math.abs(brightness - trendBrightness) * 0.75 + flux * 0.20);
      const crest = peak / Math.max(0.0001, Math.sqrt(sum / count));
      // Unscaled levels in dB: the 0-1 features above saturate on loud masters (energy and bass
      // sit near 1 through whole sections), so drop detection measures in dB instead.
      const levelDb = (meanSquare) => Math.round(10 * Math.log10(meanSquare + 1e-10) * 100) / 100;

      frames.push({
        time: start / sampleRate,
        energy,
        peak: clamp01(peak),
        crest: Math.min(12, crest),
        bass,
        mid,
        treble,
        brightness,
        flux,
        beatStrength,
        sectionProbability,
        energyTrend: clamp01(energy - trendEnergy + 0.5),
        density: clamp01((energy * 0.48 + flux * 0.34 + beatStrength * 0.18)),
        fullDb: levelDb(sum / count),
        lowDb: levelDb(bassSum / count),
        highDb: levelDb(trebleSum / count)
      });

      previousEnergy = energy;
      previousBrightness = brightness;
      if (performance.now() - sliceStartedAt > 8) {
        await yieldToInterface();
        sliceStartedAt = performance.now();
      }
    }

    const waveformPeaks = await waveformPeaksPromise;
    await yieldToInterface();
    const kickScores = AudioAnalysisTimeline.makeKickScores(frames);
    const offlineKickScores = AudioAnalysisTimeline.makeOfflineKickScores(frames);
    for (let index = 0; index < frames.length; index += 1) {
      // Preserve the transient-aligned kick detector output for deterministic
      // offline rendering. Tempo/beat-grid estimation may use these scores,
      // but it must not become the only source of exported shader kicks.
      frames[index].kickScore = kickScores[index] || 0;
      frames[index].offlineKickScore = offlineKickScores[index] || 0;
    }
    await yieldToInterface();
    const hatScores = AudioAnalysisTimeline.makeHatScores(frames);
    await yieldToInterface();
    const tempo = await AudioAnalysisTimeline.detectTempo(frames, frameDuration, buffer.duration, kickScores);
    await yieldToInterface();
    const beatGrid = AudioAnalysisTimeline.makeBeatGrid(frames, frameDuration, buffer.duration, tempo, kickScores, hatScores);
    await yieldToInterface();
    const sections = AudioAnalysisTimeline.makeEnergySections(frames, frameDuration, buffer.duration, tempo, beatGrid, kickScores, hatScores);
    return new AudioAnalysisTimeline(frames, frameDuration, buffer.duration, waveformPeaks, sections, tempo, beatGrid);
  }

  static async makeWaveformPeaks(channels, length, bucketCount, onProgress = null) {
    const buckets = Math.max(1, bucketCount);
    const peaks = new Array(buckets).fill(0);
    let sliceStartedAt = performance.now();
    for (let bucket = 0; bucket < buckets; bucket += 1) {
      const start = Math.floor((bucket / buckets) * length);
      const end = Math.max(start + 1, Math.floor(((bucket + 1) / buckets) * length));
      let peak = 0;
      const stride = Math.max(1, Math.floor((end - start) / 80));
      for (let i = start; i < end; i += stride) {
        let sample = 0;
        for (const channel of channels) sample += Math.abs(channel[i] || 0);
        sample /= Math.max(1, channels.length);
        peak = Math.max(peak, sample);
      }
      peaks[bucket] = clamp01(peak);
      if ((bucket + 1) % 12 === 0 || bucket === buckets - 1) {
        onProgress?.({
          peaks: peaks.slice(),
          progress: (bucket + 1) / buckets,
          complete: bucket === buckets - 1
        });
        // A callback alone does not give WebKit a paint opportunity. Always
        // yield after a visible batch so long tracks advance on screen rather
        // than jumping from an empty canvas to 100%.
        await yieldToInterface();
        sliceStartedAt = performance.now();
        continue;
      }
      if (performance.now() - sliceStartedAt > 8) {
        await yieldToInterface();
        sliceStartedAt = performance.now();
      }
    }
    return peaks;
  }

  static makeOfflineKickScores(frames) {
    // Visual band values saturate on loud masters. Detecting differences after
    // that clamp erases real kicks (bass and energy can both stay exactly 1).
    // Recover the original scaled RMS from the stored dB measurements only for
    // export onsets; leave tempo, sections, Drop Map and visual bands unchanged.
    return AudioAnalysisTimeline.makeKickScores(frames.map((frame) => ({
      ...frame,
      bass: Number.isFinite(frame.lowDb) ? Math.pow(10, frame.lowDb / 20) * 4.2 : frame.bass,
      energy: Number.isFinite(frame.fullDb) ? Math.pow(10, frame.fullDb / 20) * 3.2 : frame.energy
    })));
  }

  static makeKickScores(frames) {
    if (!frames.length) return [];
    const basses = frames.map((frame) => frame.bass || 0);
    const energies = frames.map((frame) => frame.energy || 0);
    const localAverage = (values, start, end) => {
      let total = 0;
      let count = 0;
      for (let i = Math.max(0, start); i <= Math.min(values.length - 1, end); i += 1) {
        total += values[i] || 0;
        count += 1;
      }
      return total / Math.max(1, count);
    };
    const raw = frames.map((frame, index) => {
      const bass = basses[index] || 0;
      const energy = energies[index] || 0;
      const previousBass = basses[Math.max(0, index - 1)] || 0;
      const previousEnergy = energies[Math.max(0, index - 1)] || 0;
      const preBassFloor = localAverage(basses, index - 8, index - 2);
      const postBassFloor = localAverage(basses, index + 2, index + 6);
      const preEnergyFloor = localAverage(energies, index - 8, index - 2);
      const bassRise = Math.max(0, bass - previousBass * 0.93);
      const bassContrast = Math.max(0, bass - preBassFloor * 1.08);
      const localPeakContrast = Math.max(0, bass - Math.max(preBassFloor * 0.96, postBassFloor * 0.90));
      const energyRise = Math.max(0, energy - previousEnergy * 0.97);
      const energyContrast = Math.max(0, energy - preEnergyFloor * 1.04);
      const sustainedBass = preBassFloor > 0.001 ? clamp01(preBassFloor / Math.max(0.001, bass)) : 0;
      const transientGate = clamp01((bassContrast * 7.0 + localPeakContrast * 5.5 + bassRise * 4.0 + energyRise * 1.4) - sustainedBass * 0.28);
      const bassDominance = clamp01(bass / Math.max(0.04, (frame.mid || 0) * 0.72 + (frame.treble || 0) * 0.42 + bass));
      return (
        bassRise * 4.3 +
        bassContrast * 6.8 +
        localPeakContrast * 5.2 +
        energyRise * 0.82 +
        energyContrast * 0.40 +
        (frame.flux || 0) * 0.12
      ) * (0.50 + transientGate * 0.50) * (0.70 + bassDominance * 0.30);
    });
    const sorted = [...raw].sort((a, b) => a - b);
    const p92 = sorted[Math.max(0, Math.min(sorted.length - 1, Math.floor(sorted.length * 0.92)))] || 1;
    const p98 = sorted[Math.max(0, Math.min(sorted.length - 1, Math.floor(sorted.length * 0.98)))] || p92;
    const scale = Math.max(0.08, p92 * 0.72 + p98 * 0.28);
    return raw.map((value) => clamp01(value / scale));
  }

  static makeHatScores(frames) {
    if (!frames.length) return [];
    let previousTreble = frames[0].treble || 0;
    let previousBrightness = frames[0].brightness || 0;
    const raw = frames.map((frame) => {
      const trebleRise = Math.max(0, frame.treble - previousTreble * 0.78);
      const brightnessRise = Math.max(0, frame.brightness - previousBrightness * 0.78);
      previousTreble = frame.treble;
      previousBrightness = frame.brightness;
      const bassPenalty = Math.max(0, frame.bass - frame.treble * 0.62) * 0.24;
      return Math.max(0, trebleRise * 3.80 + brightnessRise * 1.15 + frame.treble * 0.48 + frame.flux * 0.18 - bassPenalty);
    });
    const sorted = [...raw].sort((a, b) => a - b);
    const p90 = sorted[Math.max(0, Math.min(sorted.length - 1, Math.floor(sorted.length * 0.90)))] || 1;
    const scale = Math.max(0.08, p90);
    return raw.map((value) => clamp01(value / scale));
  }

  static sampleArray(values, position) {
    if (!values.length) return 0;
    const clamped = Math.max(0, Math.min(values.length - 1, position));
    const low = Math.floor(clamped);
    const high = Math.max(0, Math.min(values.length - 1, low + 1));
    return mixJs(values[low], values[high], clamped - low);
  }

  static async detectTempo(frames, frameDuration, duration, kickScores = null) {
    const scores = kickScores || AudioAnalysisTimeline.makeKickScores(frames);
    if (scores.length < 80 || duration < 20) return null;
    const sortedScores = [...scores].sort((a, b) => a - b);
    const hitThreshold = Math.max(0.18, sortedScores[Math.floor(sortedScores.length * 0.72)] || 0.18);
    const scoreCandidate = (bpm) => {
      const interval = 60 / bpm / frameDuration;
      let bestPhase = 0;
      let bestScore = -Infinity;
      let bestOnbeat = 0;
      let bestOffbeat = 0;
      let bestRegularity = 0;
      for (let phase = 0; phase < interval; phase += 0.20) {
        let onbeat = 0;
        let offbeat = 0;
        let regularHits = 0;
        let count = 0;
        for (let position = phase + interval * 2; position < scores.length - interval; position += interval) {
          const current = AudioAnalysisTimeline.sampleArray(scores, position);
          const previous = AudioAnalysisTimeline.sampleArray(scores, position - interval);
          const next = AudioAnalysisTimeline.sampleArray(scores, position + interval);
          const half = AudioAnalysisTimeline.sampleArray(scores, position + interval * 0.5);
          const quarter = AudioAnalysisTimeline.sampleArray(scores, position + interval * 0.25);
          onbeat += current * 0.62 + Math.min(current, previous) * 0.20 + Math.min(current, next) * 0.18;
          offbeat += half * 0.76 + quarter * 0.24;
          regularHits += current >= hitThreshold ? 1 : 0;
          count += 1;
        }
        const onAvg = onbeat / Math.max(1, count);
        const offAvg = offbeat / Math.max(1, count);
        const regularity = regularHits / Math.max(1, count);
        const psytranceBias = 1 + 0.09 * Math.exp(-Math.pow((bpm - 145) / 20, 2));
        const fastPenalty = bpm > 150 ? 1 - Math.min(0.08, (bpm - 150) * 0.006) : 1;
        const score = (onAvg * 0.72 + regularity * 0.32 - offAvg * 0.20) * psytranceBias * fastPenalty;
        if (score > bestScore) {
          bestScore = score;
          bestPhase = phase;
          bestOnbeat = onAvg;
          bestOffbeat = offAvg;
          bestRegularity = regularity;
        }
      }
      return {
        bpm,
        score: bestScore,
        phase: bestPhase * frameDuration,
        onbeat: bestOnbeat,
        offbeat: bestOffbeat,
        regularity: bestRegularity
      };
    };

    let best = { bpm: 0, score: -Infinity, phase: 0 };
    let second = { bpm: 0, score: -Infinity, phase: 0 };
    let sliceStartedAt = performance.now();
    for (let bpm = 112; bpm <= 172; bpm += 0.5) {
      const candidate = scoreCandidate(bpm);
      if (candidate.score > best.score) {
        second = best;
        best = candidate;
      } else if (candidate.score > second.score) {
        second = candidate;
      }
      if (performance.now() - sliceStartedAt > 8) {
        await yieldToInterface();
        sliceStartedAt = performance.now();
      }
    }
    for (let bpm = Math.max(112, best.bpm - 4); bpm <= Math.min(172, best.bpm + 4); bpm += 0.1) {
      const candidate = scoreCandidate(bpm);
      if (candidate.score > best.score) {
        best = candidate;
      }
      if (performance.now() - sliceStartedAt > 8) {
        await yieldToInterface();
        sliceStartedAt = performance.now();
      }
    }
    if (!Number.isFinite(best.score) || best.score < 0.035) return null;

    const separation = best.score - (second.score || 0);
    return {
      bpm: Math.round(best.bpm * 10) / 10,
      confidence: clamp01(best.score * 1.55 + separation * 3.0),
      beatDuration: 60 / best.bpm,
      phase: best.phase
    };
  }

  static makeBeatGrid(frames, frameDuration, duration, tempo, kickScores = null, hatScores = null) {
    if (!tempo?.bpm) return [];
    const scores = kickScores || AudioAnalysisTimeline.makeKickScores(frames);
    const hats = hatScores || AudioAnalysisTimeline.makeHatScores(frames);
    const beatDuration = tempo.beatDuration || 60 / tempo.bpm;
    const windowFrames = Math.max(1, Math.round((beatDuration / frameDuration) * 0.28));
    const hatWindowFrames = Math.max(1, Math.round((beatDuration / frameDuration) * 0.18));
    const intervalFrames = beatDuration / frameDuration;
    const grid = [];
    let time = tempo.phase || 0;
    while (time - beatDuration >= 0) time -= beatDuration;
    while (time < 0) time += beatDuration;
    for (; time <= duration + beatDuration * 0.5; time += beatDuration) {
      const center = time / frameDuration;
      let score = 0;
      for (let offset = -windowFrames; offset <= windowFrames; offset += 1) {
        score = Math.max(score, AudioAnalysisTimeline.sampleArray(scores, center + offset));
      }
      const preKick = AudioAnalysisTimeline.sampleArray(scores, center - intervalFrames * 0.38);
      const halfKick = AudioAnalysisTimeline.sampleArray(scores, center + intervalFrames * 0.50);
      const lateKick = AudioAnalysisTimeline.sampleArray(scores, center + intervalFrames * 0.38);
      const surroundingKick = Math.max(preKick, halfKick, lateKick);
      const onbeatContrast = Math.max(0, score - surroundingKick * 0.72);
      const kickEvidence = clamp01(score * 0.62 + onbeatContrast * 0.72);
      let hat = 0;
      const offbeatCenter = center + intervalFrames * 0.5;
      for (let offset = -hatWindowFrames; offset <= hatWindowFrames; offset += 1) {
        hat = Math.max(hat, AudioAnalysisTimeline.sampleArray(hats, offbeatCenter + offset));
      }
      grid.push({ time, score: kickEvidence, rawScore: score, surroundingKick, hat });
    }
    return grid;
  }

  static beatWindowStats(beatGrid, centerBeat, fromOffset, toOffset, threshold, hatThreshold = 0.35) {
    let total = 0;
    let hatTotal = 0;
    let hits = 0;
    let hatHits = 0;
    let count = 0;
    for (let offset = fromOffset; offset <= toOffset; offset += 1) {
      const beat = beatGrid[centerBeat + offset];
      if (!beat) continue;
      total += beat.score;
      hatTotal += beat.hat || 0;
      hits += beat.score >= threshold ? 1 : 0;
      hatHits += (beat.hat || 0) >= hatThreshold ? 1 : 0;
      count += 1;
    }
    return {
      average: total / Math.max(1, count),
      regularity: hits / Math.max(1, count),
      hatAverage: hatTotal / Math.max(1, count),
      hatRegularity: hatHits / Math.max(1, count)
    };
  }

  static snapSectionsToLoops(sections, tempo, duration) {
    if (!tempo?.bpm || sections.length < 2) return sections;
    const beatDuration = tempo.beatDuration || 60 / tempo.bpm;
    const phase = tempo.phrasePhase ?? tempo.phase ?? 0;
    const snapTime = (time) => {
      let bestTime = time;
      let bestDistance = Infinity;
      for (const beats of [8, 16, 32]) {
        const loop = beatDuration * beats;
        const index = Math.round((time - phase) / loop);
        const candidate = phase + index * loop;
        const distance = Math.abs(candidate - time);
        const tolerance = beatDuration * 2.4;
        if (distance < tolerance && distance < bestDistance) {
          bestTime = candidate;
          bestDistance = distance;
        }
      }
      return Math.max(0, Math.min(duration, bestTime));
    };
    const snapped = sections.map((section) => ({ ...section }));
    for (let i = 1; i < snapped.length; i += 1) {
      const boundary = snapTime(snapped[i].start);
      if (boundary > snapped[i - 1].start + 1.0 && boundary < snapped[i].end - 1.0) {
        snapped[i - 1].end = boundary;
        snapped[i].start = boundary;
      }
    }
    return snapped;
  }

  static estimatePhrasePhaseFromSections(sections, tempo, duration) {
    if (!tempo?.bpm || !sections.length) return;
    const beatDuration = tempo.beatDuration || 60 / tempo.bpm;
    const beatPhase = tempo.phase || 0;
    const boundaries = sections
      .slice(1)
      .filter((section) => section.start > 4 && section.start < duration - 4)
      .map((section) => ({
        time: section.start,
        weight: 1 + Math.min(2, Math.abs((section.level || 3) - (sections[sections.indexOf(section) - 1]?.level || 3)) * 0.45)
      }));
    if (!boundaries.length) return;
    let bestPhase = beatPhase;
    let bestScore = Infinity;
    for (let offset = 0; offset < 8; offset += 1) {
      const candidatePhase = beatPhase + offset * beatDuration;
      let score = 0;
      let weightTotal = 0;
      for (const boundary of boundaries) {
        const loop = beatDuration * 8;
        const index = Math.round((boundary.time - candidatePhase) / loop);
        const snapped = candidatePhase + index * loop;
        const distance = Math.abs(boundary.time - snapped) / Math.max(0.001, beatDuration);
        score += Math.min(distance, 4.0) * boundary.weight;
        weightTotal += boundary.weight;
      }
      score /= Math.max(0.001, weightTotal);
      if (score < bestScore) {
        bestScore = score;
        bestPhase = candidatePhase;
      }
    }
    tempo.phrasePhase = bestPhase;
  }

  static shapeEnergyTransitions(sections, duration) {
    if (!sections.length) return sections;
    const shaped = sections.map((section) => ({ ...section }));
    for (let i = 1; i < shaped.length; i += 1) {
      const previous = shaped[i - 1];
      const current = shaped[i];
      const jump = current.level - previous.level;
      const previousDuration = previous.end - previous.start;
      if (jump >= 2 && previousDuration > 10) {
        const rampDuration = Math.min(12, Math.max(5, previousDuration * 0.22));
        const rampStart = Math.max(previous.start + 2, current.start - rampDuration);
        if (current.start - rampStart > 2.5 && rampStart > previous.start + 2) {
          previous.end = rampStart;
          shaped.splice(i, 0, {
            start: rampStart,
            end: current.start,
            label: `Energy ${Math.max(previous.level + 1, Math.min(current.level - 1, 4))}`,
            level: Math.max(previous.level + 1, Math.min(current.level - 1, 4)),
            confidence: 0.62,
            drive: 0.52
          });
          i += 1;
        }
      } else if (jump <= -2 && previousDuration > 10) {
        const fallDuration = Math.min(10, Math.max(4, previousDuration * 0.18));
        const fallStart = Math.max(previous.start + 2, current.start - fallDuration);
        if (current.start - fallStart > 2.0 && fallStart > previous.start + 2) {
          previous.end = fallStart;
          shaped.splice(i, 0, {
            start: fallStart,
            end: current.start,
            label: `Energy ${Math.max(current.level + 1, Math.min(previous.level - 1, 4))}`,
            level: Math.max(current.level + 1, Math.min(previous.level - 1, 4)),
            confidence: 0.58,
            drive: 0.45
          });
          i += 1;
        }
      }
    }
    for (let i = shaped.length - 1; i >= 1; i -= 1) {
      if (shaped[i].end - shaped[i].start <= 0.5) shaped.splice(i, 1);
    }
    if (shaped.length) {
      shaped[0].start = 0;
      shaped[shaped.length - 1].end = duration;
    }
    return shaped;
  }

  static makeEnergySections(frames, frameDuration, duration, tempo = null, beatGrid = [], kickScores = null, hatScores = null) {
    if (!frames.length || !duration || duration < 4) return [];
    const kicks = kickScores || AudioAnalysisTimeline.makeKickScores(frames);
    const hats = hatScores || AudioAnalysisTimeline.makeHatScores(frames);
    const quantile = (values, q) => {
      if (!values.length) return 0;
      const sorted = [...values].sort((a, b) => a - b);
      return sorted[Math.max(0, Math.min(sorted.length - 1, Math.floor(q * (sorted.length - 1))))] || 0;
    };
    const activeScores = frames.map((frame) => clamp01(frame.energy * 0.48 + frame.bass * 0.30 + frame.mid * 0.10 + frame.density * 0.18 + frame.beatStrength * 0.10));
    const bassValues = frames.map((frame) => frame.bass || 0);
    const p12Active = quantile(activeScores, 0.12);
    const p50Active = quantile(activeScores, 0.50);
    const p70Active = quantile(activeScores, 0.70);
    const p86Active = quantile(activeScores, 0.86);
    const p45Bass = quantile(bassValues, 0.45);
    const p62Bass = quantile(bassValues, 0.62);
    const activeRange = Math.max(0.06, p86Active - p12Active);
    const kickThreshold = Math.max(0.22, quantile(kicks, 0.66) * 0.74);
    const hatThreshold = Math.max(0.18, quantile(hats, 0.66) * 0.72);
    const beatDuration = tempo?.beatDuration || 0;
    const phase = tempo?.phase || 0;
    const bassWindowFrames = Math.max(2, Math.round(((beatDuration || 0.55) * 0.55) / frameDuration));
    const localAverage = (values, center, radius) => {
      let total = 0;
      let count = 0;
      for (let offset = -radius; offset <= radius; offset += 1) {
        const value = values[Math.max(0, Math.min(values.length - 1, center + offset))] || 0;
        total += value;
        count += 1;
      }
      return total / Math.max(1, count);
    };
    const localBeatStats = (frame) => {
      if (!beatDuration || !beatGrid.length) {
        return {
          average: kicks[Math.max(0, Math.min(kicks.length - 1, Math.round(frame.time / frameDuration)))] || 0,
          regularity: 0,
          hatAverage: hats[Math.max(0, Math.min(hats.length - 1, Math.round(frame.time / frameDuration)))] || 0,
          hatRegularity: 0
        };
      }
      const beatIndex = Math.max(0, Math.min(beatGrid.length - 1, Math.round((frame.time - phase) / beatDuration)));
      return AudioAnalysisTimeline.beatWindowStats(beatGrid, beatIndex, -8, 8, kickThreshold, hatThreshold);
    };
    const rawScores = frames.map((frame, index) => {
      const stats = localBeatStats(frame);
      const active = activeScores[index];
      const absolute = clamp01(active * 0.78 + frame.bass * 0.18 + frame.treble * 0.04);
      const relative = clamp01((active - p12Active) / activeRange);
      const kickDrive = clamp01(stats.regularity * 0.72 + stats.average * 0.28);
      const hatDrive = clamp01(stats.hatRegularity * 0.70 + stats.hatAverage * 0.22 + frame.treble * 0.08);
      const fullOnDrive = clamp01(kickDrive * 0.70 + hatDrive * 0.24 + frame.bass * 0.10);
      const localBass = localAverage(bassValues, index, bassWindowFrames);
      const bassKickEvidence = localBass >= Math.max(0.055, p45Bass * 0.82) && frame.bass >= Math.max(0.038, p45Bass * 0.58);
      const strongBassKickEvidence = localBass >= Math.max(0.070, p62Bass * 0.82) && frame.bass >= Math.max(0.048, p62Bass * 0.58);
      const reliableKickPattern = stats.regularity >= 0.38 && stats.average >= kickThreshold * 0.92 && bassKickEvidence;
      const strongKickPattern = stats.regularity >= 0.50 && stats.average >= kickThreshold * 1.05 && strongBassKickEvidence;
      let score = clamp01(absolute * 0.30 + relative * 0.32 + kickDrive * 0.26 + hatDrive * 0.12);
      if (fullOnDrive > 0.62 && relative > 0.52 && absolute > 0.22) score = Math.max(score, 0.58 + fullOnDrive * 0.18 + relative * 0.08);
      if (fullOnDrive > 0.80 && relative > 0.70 && hatDrive > 0.46 && absolute > 0.30) score = Math.max(score, 0.78 + hatDrive * 0.08);

      const progress = frame.time / Math.max(duration, 0.001);
      const noSteadyKick = stats.regularity < 0.22 && stats.average < kickThreshold * 0.95;
      const weakKick = stats.regularity < 0.36 && stats.average < kickThreshold * 1.18;
      let cap = 5;
      if (noSteadyKick) cap = absolute > 0.55 ? 3 : absolute > 0.30 ? 2 : 1;
      else if (weakKick) cap = absolute > 0.56 ? 3 : 2;
      if (!reliableKickPattern) cap = Math.min(cap, 4);
      if (!bassKickEvidence && progress < 0.14) cap = Math.min(cap, 3);
      if (relative < 0.36 && active < p50Active) cap = Math.min(cap, kickDrive > 0.55 ? 3 : 2);
      if (relative < 0.52 && kickDrive < 0.58) cap = Math.min(cap, 3);
      if (relative < 0.66 && active < p70Active && hatDrive < 0.38 && kickDrive < 0.68) cap = Math.min(cap, 4);
      if (progress < 0.12 && !strongKickPattern) cap = Math.min(cap, absolute > 0.66 ? 3 : 2);
      if (progress > 0.92 && kickDrive < 0.52 && absolute < 0.66) cap = Math.min(cap, 2);
      return {
        score,
        cap,
        kickDrive,
        hatDrive,
        fullOnDrive,
        absolute,
        relative,
        active,
        reliableKickPattern,
        strongKickPattern,
        bassKickEvidence,
        strongBassKickEvidence,
        localBass
      };
    });

    const radius = Math.max(2, Math.round(1.15 / frameDuration));
    const smoothScores = rawScores.map((_, index) => {
      let weighted = 0;
      let weightTotal = 0;
      for (let offset = -radius; offset <= radius; offset += 1) {
        const frameIndex = Math.max(0, Math.min(rawScores.length - 1, index + offset));
        const weight = 1 - Math.abs(offset) / (radius + 1);
        weighted += rawScores[frameIndex].score * weight;
        weightTotal += weight;
      }
      return clamp01(weighted / Math.max(0.001, weightTotal));
    });
    const levels = smoothScores.map((score, index) => {
      const raw = rawScores[index];
      let level = 1;
      if (score >= 0.20) level = 2;
      if (score >= 0.42) level = 3;
      if (score >= 0.64) level = 4;
      if (score >= 0.74 && raw.relative > 0.58 && raw.kickDrive > 0.50) level = 5;
      level = Math.min(level, raw.cap);
      if (raw.fullOnDrive > 0.72 && raw.relative > 0.54 && raw.absolute > 0.26) level = Math.max(level, 4);
      if (raw.strongKickPattern && raw.kickDrive > 0.80 && raw.hatDrive > 0.34 && raw.relative > 0.76 && raw.absolute > 0.40 && score > 0.72) level = 5;
      if (raw.strongKickPattern && raw.fullOnDrive > 0.88 && raw.hatDrive > 0.58 && raw.relative > 0.76 && raw.absolute > 0.34) level = 5;
      level = Math.min(level, raw.cap);
      return Math.max(1, Math.min(5, level));
    });
    const segments = [];
    for (let i = 0; i < levels.length; i += 1) {
      const levelValue = levels[i];
      const last = segments[segments.length - 1];
      if (last && last.level === levelValue) {
        last.endFrame = i;
      } else {
        segments.push({ level: levelValue, startFrame: i, endFrame: i });
      }
    }
    const minDuration = Math.max(2.5, Math.min(8, duration * 0.018));
    const merged = [];
    for (let index = 0; index < segments.length; index += 1) {
      const segment = segments[index];
      const segmentDuration = (segment.endFrame - segment.startFrame + 1) * frameDuration;
      const previous = merged[merged.length - 1];
      const next = segments[index + 1] || null;
      const bridgesEnergyChange = previous && next && (
        (previous.level < segment.level && segment.level < next.level) ||
        (previous.level > segment.level && segment.level > next.level) ||
        Math.abs(previous.level - next.level) >= 2
      );
      if (previous && segmentDuration < minDuration && !bridgesEnergyChange) {
        previous.endFrame = segment.endFrame;
      } else if (previous && previous.level === segment.level) {
        previous.endFrame = segment.endFrame;
      } else {
        merged.push({ ...segment });
      }
    }
    const sections = merged.map((segment) => {
      const start = frames[segment.startFrame]?.time || 0;
      const endFrame = Math.min(frames.length - 1, segment.endFrame + 1);
      const end = endFrame === frames.length - 1 ? duration : Math.min(duration, frames[endFrame]?.time || duration);
      let average = 0;
      let count = 0;
      for (let i = segment.startFrame; i <= segment.endFrame; i += 1) {
        average += smoothScores[i] || 0;
        count += 1;
      }
      const energy = average / Math.max(1, count);
      let reliableKickFrames = 0;
      for (let i = segment.startFrame; i <= segment.endFrame; i += 1) {
        if (rawScores[i]?.strongKickPattern) reliableKickFrames += 1;
      }
      const reliableKickShare = reliableKickFrames / Math.max(1, segment.endFrame - segment.startFrame + 1);
      let sectionBeatHits = 0;
      let sectionBeatCount = 0;
      let sectionBeatAverage = 0;
      if (beatGrid.length) {
        for (const beat of beatGrid) {
          if (beat.time < start || beat.time >= end) continue;
          const score = beat.score || 0;
          sectionBeatHits += score >= kickThreshold ? 1 : 0;
          sectionBeatAverage += score;
          sectionBeatCount += 1;
        }
      }
      const sectionKickShare = sectionBeatHits / Math.max(1, sectionBeatCount);
      sectionBeatAverage /= Math.max(1, sectionBeatCount);
      let promotedLevel = segment.level === 4 && energy > 0.735 && end - start > 14 && reliableKickShare > 0.42 && sectionKickShare > 0.42 ? 5 : segment.level;
      if (promotedLevel >= 5 && sectionKickShare < 0.42) promotedLevel = energy > 0.70 && sectionBeatAverage > kickThreshold * 0.74 ? 4 : 3;
      if (promotedLevel >= 4 && sectionKickShare < 0.24 && end - start > 8) promotedLevel = 3;
      return {
        start,
        end,
        label: `Energy ${promotedLevel}`,
        level: promotedLevel,
        confidence: clamp01(0.48 + Math.abs(energy - 0.5) * 0.55),
        drive: clamp01(energy)
      };
    }).filter((section) => section.end - section.start > 0.5);
    if (sections.length) {
      sections[0].start = 0;
      sections[sections.length - 1].end = duration;
    }
    const shapedSections = AudioAnalysisTimeline.shapeEnergyTransitions(sections, duration);
    AudioAnalysisTimeline.estimatePhrasePhaseFromSections(shapedSections, tempo, duration);
    return AudioAnalysisTimeline.snapSectionsToLoops(shapedSections, tempo, duration);
  }

  static makeSections(frames, frameDuration, duration, tempo = null, beatGrid = [], kickScores = null, hatScores = null) {
    if (!frames.length || !duration || duration < 12) return [];
    const kicks = kickScores || AudioAnalysisTimeline.makeKickScores(frames);
    const hats = hatScores || AudioAnalysisTimeline.makeHatScores(frames);
    const energies = frames.map((frame) => frame.energy);
    const densities = frames.map((frame) => frame.density);
    const beats = frames.map((frame) => frame.beatStrength);
    const basses = frames.map((frame) => frame.bass);
    const fluxes = frames.map((frame) => frame.flux);
    const activeScores = frames.map((frame) => clamp01(frame.energy * 0.46 + frame.bass * 0.24 + frame.density * 0.22 + frame.beatStrength * 0.08));
    const sortedEnergy = [...energies].sort((a, b) => a - b);
    const sortedDensity = [...densities].sort((a, b) => a - b);
    const sortedBeat = [...beats].sort((a, b) => a - b);
    const sortedBass = [...basses].sort((a, b) => a - b);
    const sortedFlux = [...fluxes].sort((a, b) => a - b);
    const sortedActive = [...activeScores].sort((a, b) => a - b);
    const sortedKickScores = [...kicks].sort((a, b) => a - b);
    const sortedHatScores = [...hats].sort((a, b) => a - b);
    const quantile = (sorted, q) => sorted[Math.max(0, Math.min(sorted.length - 1, Math.floor(q * (sorted.length - 1))))] || 0;
    const avgDensity = densities.reduce((sum, value) => sum + value, 0) / frames.length;
    const avgBass = basses.reduce((sum, value) => sum + value, 0) / frames.length;
    const avgActive = activeScores.reduce((sum, value) => sum + value, 0) / frames.length;
    const p10Active = quantile(sortedActive, 0.10);
    const p28Active = quantile(sortedActive, 0.28);
    const p62Active = quantile(sortedActive, 0.62);
    const p78Active = quantile(sortedActive, 0.78);
    const p88Active = quantile(sortedActive, 0.88);
    const p35Bass = quantile(sortedBass, 0.35);
    const p35Density = quantile(sortedDensity, 0.35);
    const p72Density = quantile(sortedDensity, 0.72);
    const p70Beat = quantile(sortedBeat, 0.70);
    const p66Flux = quantile(sortedFlux, 0.66);
    const beatHitThreshold = Math.max(0.18, quantile(sortedKickScores, 0.62) * 0.70);
    const hatHitThreshold = Math.max(0.18, quantile(sortedHatScores, 0.62) * 0.70);
    const activeRange = Math.max(0.045, p88Active - p10Active);
    const highThreshold = Math.max(p62Active, avgActive + activeRange * 0.04);
    const dropThreshold = Math.max(p78Active, avgActive + activeRange * 0.18);
    const lowThreshold = Math.min(p28Active, avgActive - activeRange * 0.11);
    const shortWindowFrames = Math.max(3, Math.round(2.2 / frameDuration));
    const windowFrames = Math.max(4, Math.round(4.5 / frameDuration));
    const longWindowFrames = Math.max(8, Math.round(14.0 / frameDuration));
    const averageValue = (values, start, end) => {
      const from = Math.max(0, start);
      const to = Math.min(frames.length - 1, end);
      let total = 0;
      let count = 0;
      for (let i = from; i <= to; i += 1) {
        total += values[i] || 0;
        count += 1;
      }
      return total / Math.max(1, count);
    };
    const maxValue = (values, start, end) => {
      const from = Math.max(0, start);
      const to = Math.min(frames.length - 1, end);
      let peak = 0;
      for (let i = from; i <= to; i += 1) peak = Math.max(peak, values[i] || 0);
      return peak;
    };
    const raw = frames.map((frame, index) => {
      const progress = frame.time / Math.max(duration, 0.001);
      const active = activeScores[index];
      const beatDuration = tempo?.beatDuration || 0;
      const beatIndex = beatDuration > 0 && beatGrid.length ? Math.max(0, Math.min(beatGrid.length - 1, Math.round((frame.time - (tempo.phase || 0)) / beatDuration))) : 0;
      const pastKick = beatGrid.length ? AudioAnalysisTimeline.beatWindowStats(beatGrid, beatIndex, -32, -9, beatHitThreshold, hatHitThreshold) : { average: 1, regularity: 1, hatAverage: 1, hatRegularity: 1 };
      const localKick = beatGrid.length ? AudioAnalysisTimeline.beatWindowStats(beatGrid, beatIndex, -8, 8, beatHitThreshold, hatHitThreshold) : { average: 1, regularity: 1, hatAverage: 1, hatRegularity: 1 };
      const futureKick = beatGrid.length ? AudioAnalysisTimeline.beatWindowStats(beatGrid, beatIndex, 9, 32, beatHitThreshold, hatHitThreshold) : { average: 1, regularity: 1, hatAverage: 1, hatRegularity: 1 };
      const before = averageValue(activeScores, index - windowFrames, index - 1);
      const after = averageValue(activeScores, index + 1, index + windowFrames);
      const immediatePast = averageValue(activeScores, index - shortWindowFrames, index - 1);
      const longPastPeak = maxValue(activeScores, index - longWindowFrames, index - 1);
      const longFuturePeak = maxValue(activeScores, index + 1, index + longWindowFrames);
      const surroundingPeak = Math.max(longPastPeak, longFuturePeak);
      const trend = after - before;
      const highDensity = frame.density > Math.max(avgDensity * 0.92, p72Density * 0.82);
      const lowDensity = frame.density < Math.max(p35Density, avgDensity * 0.82);
      const lowBass = frame.bass < Math.max(p35Bass, avgBass * 0.78);
      const drivingBeat = frame.beatStrength > p70Beat * 0.80 || frame.flux > p66Flux * 0.88;
      const middle = progress > 0.10 && progress < 0.91;
      const highContext = longPastPeak > highThreshold * 0.95 && longFuturePeak > highThreshold * 0.82;
      const hasRegularKicks = localKick.regularity > 0.43 || (localKick.average > beatHitThreshold * 1.10 && localKick.regularity > 0.32);
      const hasOffbeatHats = localKick.hatRegularity > 0.34 || localKick.hatAverage > hatHitThreshold * 1.08;
      const fullOnDrive = hasRegularKicks && hasOffbeatHats && active > highThreshold * 0.74;
      const kickDropout = highContext && !hasRegularKicks && pastKick.regularity > 0.42 && localKick.regularity < 0.24 && futureKick.regularity > 0.30;
      const kickThinning = highContext && !hasRegularKicks && localKick.average < Math.max(pastKick.average, futureKick.average) * 0.46 && localKick.regularity < 0.34;
      const relativeDip = highContext && !hasRegularKicks && active < surroundingPeak - activeRange * 0.18 && active < highThreshold * 0.92;
      const sparseDip = highContext && !hasRegularKicks && (lowDensity || lowBass) && active < Math.max(highThreshold * 0.88, avgActive + activeRange * 0.02);
      const futureSurge = longFuturePeak > dropThreshold && after > active + activeRange * 0.06;
      const rising = trend > activeRange * 0.065 || after > before + activeRange * 0.08;
      const kickReturn = localKick.regularity > 0.42 && pastKick.regularity < 0.32 && active > highThreshold * 0.92;
      const highOnset = active > highThreshold && (immediatePast < active - activeRange * 0.11 || kickReturn) && immediatePast < dropThreshold * 1.02;
      if (progress < 0.075 && active < dropThreshold) return "Intro";
      if (progress > 0.92 && active < highThreshold) return "Wind down";
      if (active > dropThreshold && highOnset && (drivingBeat || highDensity || kickReturn || fullOnDrive)) return "Drop";
      if (fullOnDrive) return "Main riff";
      if (middle && hasRegularKicks) {
        if (futureSurge && rising && active < dropThreshold * 1.02) return "Buildup";
        return active > highThreshold * 0.70 || highDensity ? "Main riff" : "Buildup";
      }
      if (middle && (kickDropout || kickThinning || relativeDip || sparseDip)) return "Breakdown";
      if (middle && futureSurge && rising && active < dropThreshold * 1.08) return "Buildup";
      if (active > highThreshold || highDensity) return "Main riff";
      if (middle && rising && longFuturePeak > highThreshold) return "Buildup";
      if (middle && !hasRegularKicks && (active < lowThreshold || lowDensity || lowBass)) return "Breakdown";
      return progress > 0.80 && active < avgActive ? "Wind down" : "Breakdown";
    });

    const segments = [];
    for (let i = 0; i < raw.length; i += 1) {
      const label = raw[i];
      const last = segments[segments.length - 1];
      if (last && last.label === label) {
        last.endFrame = i;
      } else {
        segments.push({ label, startFrame: i, endFrame: i });
      }
    }

    const minDurations = {
      Intro: 4.0,
      Buildup: 2.4,
      Drop: 1.4,
      "Main riff": 5.0,
      Breakdown: 2.4,
      "Wind down": 4.0
    };
    const merged = [];
    for (const section of segments) {
      const seconds = (section.endFrame - section.startFrame + 1) * frameDuration;
      const tooShort = seconds < (minDurations[section.label] || 4.0);
      const previous = merged[merged.length - 1];
      const keepShort = section.label === "Drop" || section.label === "Buildup" || section.label === "Breakdown";
      if (tooShort && previous && !keepShort) {
        previous.endFrame = section.endFrame;
      } else if (previous && previous.label === section.label) {
        previous.endFrame = section.endFrame;
      } else {
        merged.push({ ...section });
      }
    }

    const finalSections = [];
    for (const section of merged) {
      const start = frames[section.startFrame]?.time || 0;
      const endFrame = Math.min(frames.length - 1, section.endFrame + 1);
      const end = endFrame === frames.length - 1 ? duration : Math.min(duration, frames[endFrame]?.time || duration);
      if (end - start < 1.2) continue;
      if (section.label === "Drop" && end - start > Math.max(12, duration * 0.07)) {
        const split = Math.min(end - 1.2, start + Math.max(4.5, Math.min(9.0, (end - start) * 0.32)));
        finalSections.push({ start, end: split, label: "Drop" });
        finalSections.push({ start: split, end, label: "Main riff" });
      } else {
        finalSections.push({ start, end, label: section.label });
      }
    }

    const describeSection = (section) => {
      const startFrame = Math.max(0, Math.min(frames.length - 1, Math.floor(section.start / frameDuration)));
      const endFrame = Math.max(startFrame, Math.min(frames.length - 1, Math.ceil(section.end / frameDuration)));
      let activeTotal = 0;
      let densityTotal = 0;
      let bassTotal = 0;
      const labelCounts = {};
      let count = 0;
      for (let i = startFrame; i <= endFrame; i += 1) {
        activeTotal += activeScores[i] || 0;
        densityTotal += densities[i] || 0;
        bassTotal += basses[i] || 0;
        labelCounts[raw[i]] = (labelCounts[raw[i]] || 0) + 1;
        count += 1;
      }
      const midpoint = (section.start + section.end) * 0.5;
      const beatDuration = tempo?.beatDuration || 0;
      const beatIndex = beatDuration > 0 && beatGrid.length ? Math.max(0, Math.min(beatGrid.length - 1, Math.round((midpoint - (tempo.phase || 0)) / beatDuration))) : 0;
      const kickStats = beatGrid.length ? AudioAnalysisTimeline.beatWindowStats(beatGrid, beatIndex, -16, 16, beatHitThreshold, hatHitThreshold) : { regularity: 0.5, hatRegularity: 0.5, average: 0.5, hatAverage: 0.5 };
      const beforeActive = averageValue(activeScores, startFrame - longWindowFrames, startFrame - 1);
      const afterActive = averageValue(activeScores, endFrame + 1, endFrame + longWindowFrames);
      const futurePeak = maxValue(activeScores, endFrame + 1, endFrame + longWindowFrames);
      const dominantCount = Math.max(...Object.values(labelCounts), 0);
      const labelSupport = (labelCounts[section.label] || dominantCount) / Math.max(1, count);
      return {
        avgActive: activeTotal / Math.max(1, count),
        avgDensity: densityTotal / Math.max(1, count),
        avgBass: bassTotal / Math.max(1, count),
        kickRegularity: kickStats.regularity,
        hatRegularity: kickStats.hatRegularity,
        beforeActive,
        afterActive,
        futurePeak,
        labelSupport,
        duration: section.end - section.start,
        progress: midpoint / Math.max(duration, 0.001)
      };
    };

    const refineSectionLabel = (section, stats) => {
      if (section.label === "Drop" || stats.progress < 0.08 || stats.progress > 0.92) return section.label;
      const sustainedKicks = stats.kickRegularity > 0.45 || (stats.kickRegularity > 0.36 && stats.avgActive > highThreshold * 0.78);
      const openHatDrive = stats.hatRegularity > 0.32 || (stats.hatRegularity > 0.24 && stats.avgDensity > p72Density * 0.78);
      const fullOnDrive = sustainedKicks && openHatDrive && stats.avgActive > highThreshold * 0.68;
      const sparse = stats.kickRegularity < 0.30 && stats.avgActive < highThreshold * 0.94 && (stats.avgDensity < p72Density * 0.82 || stats.avgBass < p35Bass * 1.12);
      const rising = stats.afterActive > stats.beforeActive + activeRange * 0.08 || stats.futurePeak > stats.avgActive + activeRange * 0.16;
      if (fullOnDrive || (sustainedKicks && stats.avgActive > highThreshold * 0.82)) return "Main riff";
      if (sparse && rising && stats.futurePeak > highThreshold * 0.94) return "Buildup";
      if (sparse) return "Breakdown";
      if (rising && stats.futurePeak > dropThreshold * 0.92 && stats.avgActive < dropThreshold * 1.03) return "Buildup";
      return section.label;
    };

    const decorateSection = (section) => {
      const stats = describeSection(section);
      const label = refineSectionLabel(section, stats);
      let confidence = 0.34 + stats.labelSupport * 0.34;
      if (label === "Main riff") confidence += stats.kickRegularity * 0.20 + stats.hatRegularity * 0.14;
      if (label === "Breakdown") confidence += (1 - stats.kickRegularity) * 0.22 + (stats.avgActive < highThreshold ? 0.10 : 0);
      if (label === "Buildup") confidence += clamp01((stats.afterActive - stats.beforeActive) / activeRange) * 0.18 + (stats.futurePeak > highThreshold ? 0.12 : 0);
      if (label === "Drop") confidence += stats.avgActive > dropThreshold ? 0.18 : 0.08;
      if (label === "Intro" || label === "Wind down") confidence += stats.avgActive < highThreshold ? 0.12 : 0;
      return {
        ...section,
        label,
        confidence: clamp01(confidence),
        drive: clamp01(stats.avgActive * 0.55 + stats.kickRegularity * 0.32 + stats.hatRegularity * 0.20),
        kickRegularity: stats.kickRegularity,
        hatRegularity: stats.hatRegularity
      };
    };

    const intelligentSections = [];
    for (const section of finalSections.map(decorateSection)) {
      const previous = intelligentSections[intelligentSections.length - 1];
      if (previous && previous.label === section.label && section.start <= previous.end + 1.25) {
        const previousDuration = Math.max(0.001, previous.end - previous.start);
        const sectionDuration = Math.max(0.001, section.end - section.start);
        const totalDuration = previousDuration + sectionDuration;
        previous.end = section.end;
        previous.confidence = clamp01((previous.confidence * previousDuration + section.confidence * sectionDuration) / totalDuration);
        previous.drive = Math.max(previous.drive || 0, section.drive || 0);
        previous.kickRegularity = Math.max(previous.kickRegularity || 0, section.kickRegularity || 0);
        previous.hatRegularity = Math.max(previous.hatRegularity || 0, section.hatRegularity || 0);
      } else {
        intelligentSections.push(section);
      }
    }

    if (intelligentSections.length) {
      intelligentSections[0].start = 0;
      intelligentSections[intelligentSections.length - 1].end = duration;
      if (intelligentSections[0].label === "Breakdown") intelligentSections[0].label = "Intro";
      if (intelligentSections[intelligentSections.length - 1].label === "Breakdown") intelligentSections[intelligentSections.length - 1].label = "Wind down";
    }
    return AudioAnalysisTimeline.snapSectionsToLoops(intelligentSections, tempo, duration);
  }

  getFeatures(time) {
    if (!this.frames.length) return null;
    const position = clamp01(time / Math.max(this.duration, 0.001)) * (this.frames.length - 1);
    const index = Math.floor(position);
    const nextIndex = Math.min(this.frames.length - 1, index + 1);
    const amount = position - index;
    return this.interpolate(this.frames[index], this.frames[nextIndex], amount);
  }

  getKickScoreAt(time) {
    if (!this.frames.length) return null;
    const frameDuration = Math.max(0.001, Number(this.frameDuration) || 0.05);
    // kickScore describes the analysis window beginning at this index. Use a
    // discrete, window-centred lookup so interpolation cannot ramp towards a
    // future kick and quantisation has no systematic early/late bias.
    const centredTime = Math.max(0, time - frameDuration * 0.5);
    const index = Math.max(0, Math.min(this.frames.length - 1, Math.floor(centredTime / frameDuration)));
    const score = this.frames[index]?.offlineKickScore ?? this.frames[index]?.kickScore;
    return Number.isFinite(score) ? clamp01(score) : null;
  }

  getLookaheadFeatures(time, seconds) {
    if (!this.frames.length) return null;
    const start = Math.max(0, Math.floor(time / this.frameDuration));
    const end = Math.min(this.frames.length - 1, Math.ceil((time + seconds) / this.frameDuration));
    const output = {
      energy: 0,
      bass: 0,
      mid: 0,
      treble: 0,
      brightness: 0,
      density: 0,
      beatStrength: 0,
      sectionProbability: 0,
      maxEnergy: 0,
      maxSectionProbability: 0
    };
    let count = 0;
    for (let i = start; i <= end; i += 1) {
      const frame = this.frames[i];
      output.energy += frame.energy;
      output.bass += frame.bass;
      output.mid += frame.mid;
      output.treble += frame.treble;
      output.brightness += frame.brightness;
      output.density += frame.density;
      output.beatStrength += frame.beatStrength;
      output.sectionProbability += frame.sectionProbability;
      output.maxEnergy = Math.max(output.maxEnergy, frame.energy);
      output.maxSectionProbability = Math.max(output.maxSectionProbability, frame.sectionProbability);
      count += 1;
    }
    for (const key of ["energy", "bass", "mid", "treble", "brightness", "density", "beatStrength", "sectionProbability"]) {
      output[key] /= Math.max(1, count);
    }
    const current = this.getFeatures(time) || output;
    output.energyDelta = output.energy - current.energy;
    output.brightnessDelta = output.brightness - current.brightness;
    return output;
  }

  getSectionAt(time) {
    if (!this.sections?.length) return null;
    return this.sections.find((section) => time >= section.start && time < section.end) || this.sections[this.sections.length - 1] || null;
  }

  getLoopBoundariesBetween(startTime, endTime, loopBeats = [8, 16, 32]) {
    if (!this.tempo?.bpm || endTime <= startTime) return [];
    const beatDuration = this.tempo.beatDuration || 60 / this.tempo.bpm;
    const phase = this.tempo.phrasePhase ?? this.tempo.phase ?? 0;
    const candidates = [];
    for (const beats of loopBeats) {
      const loopDuration = beatDuration * beats;
      const firstIndex = Math.ceil((startTime - phase) / loopDuration);
      const lastIndex = Math.floor((endTime - phase) / loopDuration);
      for (let index = firstIndex; index <= lastIndex; index += 1) {
        const time = phase + index * loopDuration;
        if (time >= startTime && time <= endTime && time <= this.duration) {
          candidates.push({ time, beats });
        }
      }
    }
    candidates.sort((a, b) => a.time - b.time || b.beats - a.beats);
    return candidates;
  }

  getBeatInfo(time) {
    if (!this.tempo?.bpm) return null;
    const beatDuration = this.tempo.beatDuration || 60 / this.tempo.bpm;
    const phase = this.tempo.phase || 0;
    const beatFloat = Math.max(0, (time - phase) / beatDuration);
    const beatPhase = beatFloat - Math.floor(beatFloat);
    const loopProgress = (beats) => {
      const value = beatFloat / beats;
      return value - Math.floor(value);
    };
    const boundaryPulse = (beats) => {
      const progress = loopProgress(beats);
      const distance = Math.min(progress, 1 - progress);
      return smoothstepJs(0.17, 0.0, distance);
    };
    const boundaries = this.getLoopBoundariesBetween(time + 0.001, Math.min(this.duration, time + beatDuration * 32 + 0.5));
    const next = boundaries[0] || null;
    return {
      bpm: this.tempo.bpm,
      beatDuration,
      beatPhase,
      beatIndex: Math.floor(beatFloat),
      phrase8Progress: loopProgress(8),
      phrase16Progress: loopProgress(16),
      phrase32Progress: loopProgress(32),
      phrasePulse: Math.max(boundaryPulse(8) * 0.55, boundaryPulse(16) * 0.78, boundaryPulse(32)),
      nextLoopTime: next?.time ?? null,
      nextLoopBeats: next?.beats ?? null,
      nextLoopSeconds: next ? Math.max(0, next.time - time) : 0
    };
  }

  interpolate(a, b, amount) {
    const out = {};
    for (const key of Object.keys(a)) {
      out[key] = typeof a[key] === "number" ? mixJs(a[key], b[key], amount) : a[key];
    }
    return out;
  }
}

function decodeAudioBuffer(context, data) {
  return new Promise((resolve, reject) => {
    const maybePromise = context.decodeAudioData(data.slice(0), resolve, reject);
    if (maybePromise && typeof maybePromise.then === "function") maybePromise.then(resolve, reject);
  });
}
