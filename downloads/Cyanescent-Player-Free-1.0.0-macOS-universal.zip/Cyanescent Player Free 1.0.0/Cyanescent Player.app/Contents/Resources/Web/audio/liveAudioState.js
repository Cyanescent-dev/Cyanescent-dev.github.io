export function createAudioBands(values = {}) {
  return {
    kick: Number(values.kick) || 0,
    bass: Number(values.bass) || 0,
    mids: Number(values.mids) || 0,
    highs: Number(values.highs) || 0,
    brightness: Number(values.brightness) || 0,
    level: Number(values.level) || 0
  };
}

export function createAudioFeatureState(now = performance.now()) {
  return {
    bassNow: 0,
    midNow: 0,
    trebleNow: 0,
    bassFast: 0,
    midFast: 0,
    trebleFast: 0,
    bassSlow: 0.08,
    midSlow: 0.08,
    trebleSlow: 0.08,
    bassRel: 1,
    midRel: 1,
    trebleRel: 1,
    kickPulse: 0,
    kickCooldownUntil: 0,
    kickArmed: true,
    globalEnergy: 0,
    globalEnergyFast: 0,
    globalEnergySlow: 0,
    dropDetected: 0,
    dropCooldownUntil: 0,
    lastUpdateAt: now
  };
}

export function relativeBandEnergy(current, longAverage) {
  const baseline = Math.max(0.025, Number(longAverage) || 0);
  return Math.max(0, Math.min(2.8, (Number(current) || 0) / baseline));
}

function followEnvelope(current, target, elapsedSeconds, attackSeconds, releaseSeconds) {
  const timeConstant = target > current ? attackSeconds : releaseSeconds;
  const amount = 1 - Math.exp(-elapsedSeconds / Math.max(0.001, timeConstant));
  return current + (target - current) * amount;
}

export function updateAudioFeatureState({
  state,
  bands,
  now = performance.now(),
  // Scion biofeedback snapshot (see scionBiofeedback.js), or null/undefined
  // for normal music/mic input. When present: (1) the generated Scion audio
  // has no drum to detect a kick from, so the bands.kick-based detector below
  // is skipped entirely in favour of the synthetic beat clock driving
  // kickPulse directly (see scionBiofeedback.applyScionBeatPulse, called
  // separately once beatPhase is known); (2) Scion's sustained/transient
  // activity substantially boosts globalEnergy, since a mushroom's generated
  // audio is otherwise far flatter/quieter than the music this metric was
  // tuned against. Normal (non-Scion) behaviour is completely unchanged.
  scion = null
} = {}) {
  const features = state || createAudioFeatureState(now);
  const currentBands = createAudioBands(bands);
  const previousBassFast = features.bassFast || 0;
  const previousEnergyFast = features.globalEnergyFast || 0;
  const elapsedMs = Math.max(4, Math.min(250, Number(now) - (Number(features.lastUpdateAt) || Number(now) - 16.67)));
  const elapsedSeconds = elapsedMs * 0.001;

  features.bassNow = currentBands.bass;
  features.midNow = currentBands.mids;
  features.trebleNow = currentBands.highs;
  features.bassFast = followEnvelope(features.bassFast || 0, features.bassNow, elapsedSeconds, 0.035, 0.16);
  features.midFast = followEnvelope(features.midFast || 0, features.midNow, elapsedSeconds, 0.045, 0.18);
  features.trebleFast = followEnvelope(features.trebleFast || 0, features.trebleNow, elapsedSeconds, 0.030, 0.14);
  features.bassSlow = followEnvelope(features.bassSlow || 0.08, features.bassNow, elapsedSeconds, 1.8, 2.8);
  features.midSlow = followEnvelope(features.midSlow || 0.08, features.midNow, elapsedSeconds, 1.6, 2.5);
  features.trebleSlow = followEnvelope(features.trebleSlow || 0.08, features.trebleNow, elapsedSeconds, 1.4, 2.2);
  features.bassRel = relativeBandEnergy(features.bassFast, features.bassSlow);
  features.midRel = relativeBandEnergy(features.midFast, features.midSlow);
  features.trebleRel = relativeBandEnergy(features.trebleFast, features.trebleSlow);

  const bandEnergyNow = Math.max(0, Math.min(1,
    currentBands.level * 0.48
    + currentBands.bass * 0.24
    + currentBands.mids * 0.17
    + currentBands.highs * 0.11
  ));
  // Scion's generated audio is otherwise far flatter than the music this
  // formula was tuned against, so its own sustained/transient activity is
  // blended in (never subtracted) rather than replacing the band-energy
  // reading outright - a genuinely loud/busy synth patch still counts too.
  const energyNow = scion
    ? Math.max(bandEnergyNow, Math.max(0, Math.min(1, scion.slow * 0.60 + scion.activity * 0.55)))
    : bandEnergyNow;
  features.globalEnergyFast = followEnvelope(features.globalEnergyFast || 0, energyNow, elapsedSeconds, 0.055, 0.28);
  features.globalEnergySlow = followEnvelope(features.globalEnergySlow || 0, energyNow, elapsedSeconds, 2.4, 4.2);
  const energySurge = Math.max(0, features.globalEnergyFast - features.globalEnergySlow);
  features.globalEnergy = Math.max(0, Math.min(1,
    features.globalEnergyFast * 0.72 + features.globalEnergySlow * 0.28 + energySurge * 0.52
  ));

  features.kickPulse *= Math.exp(-elapsedSeconds / 0.15);
  if (scion) {
    // The synthetic beat clock drives kickPulse instead (see app.js's call
    // to scionBiofeedback.applyScionBeatPulse, made once beatPhase for this
    // frame is known) - bands.kick here is a crude energy proxy on generated
    // audio with no real onset to detect, and would just add uncontrolled
    // noise on top of the clock's deliberately steady rhythm.
  } else {
    const bassRise = Math.max(0, features.bassFast - previousBassFast);
    const kickEvidence = Math.max(0, Math.min(1,
      Math.max(
        currentBands.kick,
        bassRise * 4.6,
        Math.max(0, features.bassRel - 1.08) * 0.62
      )
    ));
    if (kickEvidence < 0.16 && features.bassRel < 1.18) features.kickArmed = true;
    if (features.kickArmed && Number(now) >= (features.kickCooldownUntil || 0) && kickEvidence > 0.28) {
      features.kickPulse = Math.max(features.kickPulse, kickEvidence);
      features.kickCooldownUntil = Number(now) + 105;
      features.kickArmed = false;
    } else {
      features.kickPulse = Math.max(features.kickPulse, currentBands.kick * 0.72);
    }
  }

  features.dropDetected *= Math.exp(-elapsedSeconds / 0.32);
  const fastEnergyRise = Math.max(0, features.globalEnergyFast - previousEnergyFast);
  const dropEvidence = Math.max(0, Math.min(1,
    energySurge * 3.8
    + fastEnergyRise * 4.4
    + Math.max(0, features.bassRel - 1.20) * 0.24
    + features.kickPulse * 0.20
  ));
  if (
    Number(now) >= (features.dropCooldownUntil || 0)
    && features.globalEnergyFast > 0.28
    && dropEvidence > 0.58
  ) {
    features.dropDetected = Math.max(features.dropDetected, dropEvidence);
    features.dropCooldownUntil = Number(now) + 2600;
  }

  features.lastUpdateAt = Number(now);
  return features;
}

export function bandsFromNativeAudio(nativeAudio = {}) {
  return createAudioBands({
    kick: nativeAudio.kick,
    bass: nativeAudio.bass,
    mids: nativeAudio.mids,
    highs: nativeAudio.highs,
    brightness: nativeAudio.brightness,
    level: nativeAudio.level
  });
}

export function mergeNativeAudioBands(bands, nativeAudio = {}) {
  return createAudioBands({
    kick: Math.max(bands.kick, nativeAudio.kick || 0),
    bass: Math.max(bands.bass, nativeAudio.bass || 0),
    mids: Math.max(bands.mids, nativeAudio.mids || 0),
    highs: Math.max(bands.highs, nativeAudio.highs || 0),
    brightness: Math.max(bands.brightness, nativeAudio.brightness || 0),
    level: Math.max(bands.level, nativeAudio.level || 0)
  });
}

export function frequencyBandAverage(freq, sampleRate, startHz, endHz) {
  if (!freq || !sampleRate) return 0;
  const nyquist = sampleRate / 2;
  const start = Math.max(0, Math.floor((startHz / nyquist) * freq.length));
  const end = Math.min(freq.length - 1, Math.ceil((endHz / nyquist) * freq.length));
  let total = 0;
  for (let i = start; i <= end; i += 1) total += freq[i];
  return total / Math.max(1, end - start + 1) / 255;
}

export function timeDomainRms(timeData) {
  if (!timeData?.length) return 0;
  let rms = 0;
  for (let i = 0; i < timeData.length; i += 1) {
    const centered = (timeData[i] - 128) / 128;
    rms += centered * centered;
  }
  return Math.sqrt(rms / timeData.length);
}

export function bandsFromAnalyserData({ freq, timeData, sampleRate, previousKick = 0 }) {
  const rms = timeDomainRms(timeData);
  const lowKick = frequencyBandAverage(freq, sampleRate, 35, 92);
  const bass = frequencyBandAverage(freq, sampleRate, 92, 230);
  const mids = frequencyBandAverage(freq, sampleRate, 260, 2400);
  const highs = frequencyBandAverage(freq, sampleRate, 4200, 13200);
  const bright = frequencyBandAverage(freq, sampleRate, 1800, 9000);
  const transient = Math.max(0, lowKick - previousKick * 0.42);
  return createAudioBands({
    kick: Math.min(1, transient * 5.5 + lowKick * 0.25),
    bass,
    mids,
    highs,
    brightness: bright,
    level: Math.min(1, rms * 3.5)
  });
}

export function readLiveAudioBands({
  analyser,
  freq,
  timeData,
  sampleRate,
  previousKick = 0,
  nativeAudio = {},
  monitoringInput = false,
  playerMode = false,
  nativeOnlySource = null
} = {}) {
  const nativeFresh = nativeAudio.timestamp && Date.now() / 1000 - nativeAudio.timestamp < 1.2;
  const useNativeInput = monitoringInput && nativeFresh;
  if (nativeOnlySource && !playerMode) {
    // A paused player's analyser can retain its last FFT/waveform. A native
    // source must never merge those stale values into system capture.
    freq?.fill(0);
    timeData?.fill(128);
    const waveform = useNativeInput && nativeAudio.source === nativeOnlySource ? nativeAudio.waveform : null;
    if (timeData && Array.isArray(waveform) && waveform.length) {
      for (let index = 0; index < timeData.length; index++) {
        const value = Number(waveform[Math.floor(index * waveform.length / timeData.length)]);
        timeData[index] = Number.isFinite(value) ? Math.max(0, Math.min(255, value)) : 128;
      }
    }
    return {
      bands: useNativeInput && nativeAudio.source === nativeOnlySource
        ? bandsFromNativeAudio(nativeAudio) : createAudioBands(),
      noAnalyser: true
    };
  }
  if (!analyser || !freq) {
    return {
      bands: useNativeInput ? bandsFromNativeAudio(nativeAudio) : createAudioBands(),
      noAnalyser: true
    };
  }
  analyser.getByteFrequencyData(freq);
  analyser.getByteTimeDomainData(timeData);
  let bands = bandsFromAnalyserData({
    freq,
    timeData,
    sampleRate,
    previousKick
  });
  if (useNativeInput && !playerMode) {
    bands = mergeNativeAudioBands(bands, nativeAudio);
  }
  return {
    bands,
    noAnalyser: false
  };
}

export function smoothAudioBands({ smooth, bands, noAnalyser = false }) {
  const next = { ...smooth };
  for (const key of Object.keys(next)) {
    const attack = key === "kick" ? 1.0 : key === "level" ? (noAnalyser ? 0.86 : 0.82) : (noAnalyser ? 0.62 : 0.52);
    const release = key === "kick" ? 0.28 : (noAnalyser ? 0.16 : 0.14);
    const amount = bands[key] > next[key] ? attack : release;
    next[key] += (bands[key] - next[key]) * amount;
  }
  return next;
}

export function updateSlowAudioBands({ slowLevel, slowBass, bands }) {
  return {
    slowLevel: slowLevel + (bands.level - slowLevel) * 0.025,
    slowBass: slowBass + (bands.bass - slowBass) * 0.025
  };
}
