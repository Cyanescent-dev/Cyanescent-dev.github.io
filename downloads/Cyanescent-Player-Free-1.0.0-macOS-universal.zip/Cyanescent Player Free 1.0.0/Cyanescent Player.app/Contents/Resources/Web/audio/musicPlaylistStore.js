import { validateMusicPlaylistState } from "./musicPlaylistState.js";
// Serializable authored state lives here; session media URLs live only in runtimeTracks.
export function createMusicPlaylistStore({ idFactory = () => crypto.randomUUID() } = {}) {
  const newId = (kind) => `${kind}-${idFactory()}`;
  const makePlaylist = (name) => ({ id: newId('music'), name, entries: [], selectedTrackEntryId: null });
  const state = { version: 1, playlists: [makePlaylist('My Music')], selectedPlaylistId: null,
    currentPlaylistId: null, currentTrackEntryId: null, shuffleEnabled: false, repeatMode: 'off' };
  state.selectedPlaylistId = state.playlists[0].id;
  const runtimeTracks = new Map();
  let playingTrack = null;
  let detachedSuccessors = [];
  const playlist = (id = state.selectedPlaylistId) => state.playlists.find(item => item.id === id);
  const tracks = (id) => (playlist(id)?.entries || []).map(entry => runtimeTracks.get(entry.id));
  function create(name = 'New Playlist') {
    const item = makePlaylist(String(name).trim().slice(0, 80) || 'New Playlist');
    state.playlists.push(item);
    select(item.id);
    return item.id;
  }
  function select(id) {
    if (!playlist(id)) return false;
    state.selectedPlaylistId = id;
    return true;
  }
  function rename(id, name) {
    const item = playlist(id), clean = String(name || '').trim().slice(0, 80);
    if (!item || !clean) return false;
    item.name = clean;
    return true;
  }
  function releaseEntry(id) {
    const track = runtimeTracks.get(id);
    runtimeTracks.delete(id);
    if (track?.objectUrl && ![...runtimeTracks.values()].some(other => other.objectUrl === track.objectUrl)) URL.revokeObjectURL(track.objectUrl);
  }
  function removeEntry(id, playlistId = state.selectedPlaylistId) {
    const item = playlist(playlistId);
    const index = item?.entries.findIndex(entry => entry.id === id) ?? -1;
    if (index < 0) return false;
    if (id === state.currentTrackEntryId && playlistId === state.currentPlaylistId) {
      // Keep the audible source alive; remember the remaining order by identity.
      detachedSuccessors = item.entries.slice(index + 1).map(entry => entry.id);
    }
    item.entries.splice(index, 1);
    if (id !== state.currentTrackEntryId) releaseEntry(id);
    if (item.selectedTrackEntryId === id) item.selectedTrackEntryId = item.entries[Math.min(index, item.entries.length - 1)]?.id || null;
    return true;
  }
  function clear(id = state.selectedPlaylistId) {
    const item = playlist(id);
    if (!item) return false;
    for (const entry of [...item.entries]) removeEntry(entry.id, id);
    return true;
  }
  function remove(id) {
    const index = state.playlists.findIndex(item => item.id === id);
    if (index < 0) return false;
    clear(id);
    state.playlists.splice(index, 1);
    if (!state.playlists.length) state.playlists.push(makePlaylist('My Music'));
    if (state.selectedPlaylistId === id) select(state.playlists[Math.min(index, state.playlists.length - 1)].id);
    return true;
  }
  function append(input, id = state.selectedPlaylistId) {
    const item = playlist(id);
    if (!item) return [];
    const added = input.map(track => {
      const entry = { id: newId('entry'), name: track.name || 'Untitled track', reference: track.reference ? JSON.parse(JSON.stringify(track.reference)) : null };
      // Job B supplies durable references. Session nativeId/url/objectUrl never enter the snapshot.
      runtimeTracks.set(entry.id, { ...track, entryId: entry.id });
      item.entries.push(entry);
      return entry.id;
    });
    item.selectedTrackEntryId ||= added[0] || null;
    return added;
  }
  function move(id, destination, playlistId = state.selectedPlaylistId) {
    const item = playlist(playlistId);
    const index = item?.entries.findIndex(entry => entry.id === id) ?? -1;
    if (index < 0 || destination < 0 || destination >= item.entries.length) return false;
    const [entry] = item.entries.splice(index, 1);
    item.entries.splice(destination, 0, entry);
    return true;
  }
  function selectEntry(id) {
    const item = playlist();
    if (!item.entries.some(entry => entry.id === id)) return false;
    item.selectedTrackEntryId = id;
    return true;
  }
  function activate(index, playlistId = state.selectedPlaylistId) {
    const item = playlist(playlistId), entry = item?.entries[index];
    if (!entry || runtimeTracks.get(entry.id)?.unavailable || !runtimeTracks.get(entry.id)?.url) return false;
    const previousId = state.currentTrackEntryId;
    if (previousId && !state.playlists.some(list => list.entries.some(item => item.id === previousId))) releaseEntry(previousId);
    state.currentPlaylistId = playlistId;
    state.currentTrackEntryId = entry.id;
    item.selectedTrackEntryId = entry.id;
    playingTrack = runtimeTracks.get(entry.id);
    detachedSuccessors = [];
    return true;
  }
  function hydrate(saved, bindings = [], preserveSession = false) {
    validateMusicPlaylistState(saved);
    const incoming = JSON.parse(JSON.stringify(saved));
    if (preserveSession) {
      const local = api.snapshot();
      incoming.playlists = [...incoming.playlists.filter(list => !local.playlists.some(item => item.id === list.id)), ...local.playlists];
      incoming.selectedPlaylistId = local.selectedPlaylistId;
      incoming.currentPlaylistId = local.currentPlaylistId;
      incoming.currentTrackEntryId = local.currentTrackEntryId;
      incoming.shuffleEnabled = local.shuffleEnabled;
      incoming.repeatMode = local.repeatMode;
    } else {
      api.releaseObjectUrls(); runtimeTracks.clear(); playingTrack = null; detachedSuccessors = [];
    }
    Object.assign(state, incoming);
    const resolved = new Map(bindings.map(track => [track.entryId, track]));
    for (const list of state.playlists) for (const entry of list.entries) {
      if (preserveSession && runtimeTracks.has(entry.id)) continue;
      const track = resolved.get(entry.id);
      if (track?.reference) entry.reference = JSON.parse(JSON.stringify(track.reference));
      if (track?.name) entry.name = track.name;
      runtimeTracks.set(entry.id, { name: entry.name, reference: entry.reference, entryId: entry.id,
        unavailable: true, error: 'File unavailable. Connect its disk or use Locate File.', ...track });
      // Successful native bindings have a URL, rather than an availability flag.
      if (track?.url) runtimeTracks.get(entry.id).unavailable = false;
    }
  }
  function relink(id, track) {
    const entry = state.playlists.flatMap(list => list.entries).find(item => item.id === id);
    if (!entry || !track?.reference || !track?.url) return false;
    entry.reference = JSON.parse(JSON.stringify(track.reference));
    entry.name = track.name || entry.name;
    runtimeTracks.set(id, { ...track, entryId: id, unavailable: false });
    return true;
  }
  function markUnavailable(id, error) {
    const track = runtimeTracks.get(id);
    if (track) { track.unavailable = true; track.error = error || 'File unavailable. Use Locate File.'; }
  }
  function playbackIndex() {
    return playlist(state.currentPlaylistId)?.entries.findIndex(entry => entry.id === state.currentTrackEntryId) ?? -1;
  }
  function detachedNextIndex() {
    const entries = playlist(state.currentPlaylistId)?.entries || [];
    for (const id of detachedSuccessors) {
      const index = entries.findIndex(entry => entry.id === id);
      if (index >= 0) return index;
    }
    return -1;
  }
  const api = { hydrate, relink, markUnavailable,
    abandonPlayback() { playingTrack = null; state.currentTrackEntryId = null; state.currentPlaylistId = null; }, state, playlist, tracks, create, select, rename, remove, clear, append, move, removeEntry, selectEntry, activate,
    setShuffle(value) { state.shuffleEnabled = Boolean(value); },
    setRepeat(value) { state.repeatMode = ["off", "all", "one"].includes(value) ? value : "off"; },
    playbackIndex, detachedNextIndex, currentTrack: () => playingTrack,
    snapshot: () => {
      const snapshot = JSON.parse(JSON.stringify(state));
      if (playbackIndex() < 0) { snapshot.currentPlaylistId = null; snapshot.currentTrackEntryId = null; }
      return snapshot;
    },
    releaseObjectUrls() {
      for (const track of runtimeTracks.values()) if (track.objectUrl) URL.revokeObjectURL(track.objectUrl);
    }
  };
  const listeners = new Set();
  api.subscribe = listener => { listeners.add(listener); return () => listeners.delete(listener); };
  for (const name of ['create', 'select', 'rename', 'remove', 'clear', 'append', 'move', 'removeEntry', 'selectEntry', 'activate', 'setShuffle', 'setRepeat', 'relink']) {
    const operation = api[name];
    api[name] = (...args) => {
      const result = operation(...args);
      for (const listener of listeners) listener(api.snapshot(), name);
      return result;
    };
  }
  return api;
}
