import { DROP_MARKER_REPLACEMENT_WINDOW } from "./dropMap.js";

// The listener's drop markers, saved per track (by the analysis fingerprint) in localStorage:
// { [fingerprint]: { name, markers: [{ time, kind: "major" | "minor" | "none" }], updated } }.
const STORAGE_KEY = "cyanescent.dropMarkers.v1";

function readAll() {
  try {
    const parsed = JSON.parse(globalThis.localStorage?.getItem(STORAGE_KEY) || "{}");
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch { return {}; }
}

export function loadDropMarkers(fingerprint) {
  if (!fingerprint) return [];
  const entry = readAll()[fingerprint];
  return Array.isArray(entry?.markers)
    ? entry.markers.filter((m) => Number.isFinite(m?.time) && ["major", "minor", "none"].includes(m.kind))
    : [];
}

export function saveDropMarkers(fingerprint, markers, name = "") {
  if (!fingerprint) return false;
  const all = readAll();
  if (markers.length) all[fingerprint] = { name: String(name || all[fingerprint]?.name || ""), markers, updated: Date.now() };
  else delete all[fingerprint];
  try { globalThis.localStorage?.setItem(STORAGE_KEY, JSON.stringify(all)); return true; } catch { return false; }
}

// Only the same timestamp toggles; the 2 s neighbourhood is for correcting a drop,
// never a removal hit-box or beat snap. Preserve the player's seconds unchanged.
// The microsecond tolerance absorbs floating-point noise, below one audio sample.
export function toggleDropMarker({ drops = [], markers = [], autoDrops = drops.filter(d => d.source !== "marker"), time, minor = false }) {
  const fmt = (t) => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, "0")}`;
  const out = markers.slice();
  if (!Number.isFinite(time) || time < 0) return { markers: out, message: "Invalid drop time" };
  const sameTime = (a, b) => Math.abs(a - b) <= 1e-6;
  const existing = drops.filter(d => Math.abs(d.time - time) < 2)
    .sort((a, b) => Math.abs(a.time - time) - Math.abs(b.time - time))[0];
  const own = existing ? out.findIndex(m => m.kind !== "none" && sameTime(m.time, existing.time)) : -1;
  const suppressAutomatic = (at) => {
    for (const drop of autoDrops) {
      if (Math.abs(drop.time - at) < DROP_MARKER_REPLACEMENT_WINDOW
          && !out.some(m => m.kind === "none" && sameTime(m.time, drop.time))) {
        out.push({ time: drop.time, kind: "none" });
      }
    }
  };
  if (existing && sameTime(existing.time, time)) {
    if (minor && existing.kind === "major") {
      if (own >= 0) out[own] = { time: existing.time, kind: "minor" }; else out.push({ time: existing.time, kind: "minor" });
      return { markers: out, message: `Drop at ${fmt(existing.time)} marked minor` };
    }
    if (own >= 0) out.splice(own, 1);
    suppressAutomatic(existing.time);
    return { markers: out, message: `Drop at ${fmt(existing.time)} removed` };
  }
  const hidden = out.findIndex(m => m.kind === "none" && sameTime(m.time, time));
  if (!existing && hidden >= 0 && autoDrops.some(d => sameTime(d.time, time))) {
    out.splice(hidden, 1);
    return { markers: out, message: `Drop at ${fmt(time)} restored` };
  }
  // Moving a nearby manual marker replaces it, rather than leaving a duplicate.
  if (own >= 0) out.splice(own, 1);
  if (existing) suppressAutomatic(existing.time);
  suppressAutomatic(time);
  out.push({ time, kind: minor ? "minor" : "major" });
  return { markers: out, message: `${minor ? "Minor drop" : "Drop"} marked at ${fmt(time)}` };
}
