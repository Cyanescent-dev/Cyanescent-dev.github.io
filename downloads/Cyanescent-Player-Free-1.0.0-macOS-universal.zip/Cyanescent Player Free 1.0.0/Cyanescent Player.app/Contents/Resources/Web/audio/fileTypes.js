const AUDIO_FILE_RE = /\.(mp3|wav|aif|aiff|aac|m4a|flac|ogg)$/i;

export function isAudioFileName(name) {
  return AUDIO_FILE_RE.test(name || "");
}
