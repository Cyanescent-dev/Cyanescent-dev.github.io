// WebKit's compressed-media seek can report the requested currentTime while
// emitting samples from a different position (including VBR MP3 and FLAC).
// Decode once and give the existing media element sample-addressable PCM.
// Analysis uses that same buffer; native export keeps the original track URL.
export function pcmWaveBlob(buffer) {
  const channels = buffer.numberOfChannels;
  const blockAlign = channels * 4;
  const dataBytes = buffer.length * blockAlign;
  if (dataBytes > 0xffffffff - 36) throw new Error("Track is too large for PCM WAV playback");
  const header = new ArrayBuffer(44);
  const view = new DataView(header);
  const tag = (at, text) => { for (let i = 0; i < text.length; i++) view.setUint8(at + i, text.charCodeAt(i)); };
  tag(0, "RIFF"); view.setUint32(4, 36 + dataBytes, true); tag(8, "WAVE");
  tag(12, "fmt "); view.setUint32(16, 16, true);
  view.setUint16(20, 3, true); // IEEE float: preserve decoded samples without quantisation.
  view.setUint16(22, channels, true); view.setUint32(24, buffer.sampleRate, true);
  view.setUint32(28, buffer.sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true); view.setUint16(34, 32, true);
  tag(36, "data"); view.setUint32(40, dataBytes, true);
  const parts = [header];
  const pcm = Array.from({ length: channels }, (_, c) => buffer.getChannelData(c));
  for (let start = 0; start < buffer.length; start += 16384) {
    const frames = Math.min(16384, buffer.length - start);
    const chunk = new ArrayBuffer(frames * blockAlign);
    const output = new DataView(chunk);
    for (let i = 0; i < frames; i++) {
      for (let c = 0; c < channels; c++) output.setFloat32((i * channels + c) * 4, pcm[c][start + i], true);
    }
    parts.push(chunk);
  }
  return new Blob(parts, { type: "audio/wav" });
}

export async function prepareSeekableSource(src, name, context) {
  // Limit the workaround to the formats with measured seek errors. PCM and
  // other containers retain their existing streaming and analysis paths.
  if (!/\.(?:flac|mp3)(?:[?#]|$)/i.test(name || src)) return { url: src, buffer: null, release() {} };
  const response = await fetch(src, { cache: "no-store" });
  if (!response.ok) throw new Error(`Audio fetch failed: ${response.status}`);
  const buffer = await context.decodeAudioData(await response.arrayBuffer());
  const url = URL.createObjectURL(pcmWaveBlob(buffer));
  return { url, buffer, release: () => URL.revokeObjectURL(url) };
}
