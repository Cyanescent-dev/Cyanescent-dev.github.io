// Pocket SCÍON biofeedback state.
//
// Scion arrives through the same native band payload as any other audio source,
// so by the time a shader sees `bass`/`mids`/`highs` it cannot tell a living
// organism's signal apart from a music track. This module keeps the small
// amount of extra state a preset needs in order to treat Scion as a separate
// biological input rather than more music:
//
//   presence     — 0..1 ramp, 1 while the Scion source is live and publishing.
//   signal       — medium-smoothed activity level (sub-second character).
//   slow         — very slow envelope, the organism's drifting internal state.
//   variance     — short-term volatility of the raw activity (how erratic it
//                  currently is), independent of its absolute level.
//   transient    — peak-held "is something unusual happening right now"
//                  pulse: how far the instantaneous signal sits above its own
//                  recent rolling baseline, plus a contribution from variance.
//   activity     — the single normalized 0..1 "how active is the mushroom
//                  right now" value the visual clock and energy system read.
//                  Combines signal + variance + transient rather than a raw
//                  instantaneous sample, so one noisy sample can't produce an
//                  absurd spike on its own.
//   beatStrength — how strong the *next* synthetic beat should land, derived
//                  from activity/transient. Never collapses to exactly 0 at
//                  rest (a quiet organism should still produce a gentle
//                  pulse), and comfortably exceeds the normal band on a
//                  genuine transient so an accent reads as clearly stronger.
//   lastAccentAt/accentStrength — a refractory-gated "this was a big enough
//                  transient to deserve an extra beat between the regular
//                  ones" event. Consumers detect a *new* accent by watching
//                  lastAccentAt change, the same edge-triggered pattern used
//                  for kick cooldowns elsewhere in the audio pipeline.
//
// Every envelope is exponentially smoothed against real elapsed time so live
// playback and offline export behave the same way, and every derived value
// collapses smoothly to a safe, low resting state when Scion is not the
// active source (never a hard snap to 0, never NaN/Infinity) - see the
// fail-safe branch in updateScionBiofeedback below.

import { clamp01 } from "../utils/math.js";

// The visual library was developed and tested around ~143-145 BPM psytrance,
// so this is the fixed tempo the synthetic beat clock targets in Scion mode -
// see liveTempoTracker.js's `syntheticBpm` parameter. It is a rhythmic
// backbone only: it never becomes an audible kick, and it never changes the
// actual Scion synth audio.
export const SCION_VISUAL_BPM = 145;

const PRESENCE_TAU = 0.75;
const SIGNAL_TAU = 0.45;
const SLOW_TAU = 24.0;
const MAX_DT = 0.25;

// Short rolling "recent normal" for transient/deviation detection - distinct
// from the much slower `slow` envelope above, which represents the organism's
// drifting overall state rather than "the last several seconds."
const BASELINE_TAU = 6.0;
// Short-term volatility: an envelope of the sample-to-sample rate of change,
// so a busy/erratic signal reads as active even at a modest absolute level.
const VARIANCE_TAU = 0.5;
// Peak-hold then exponential release, so a transient is clearly visible for a
// beat or two rather than a single frame.
const TRANSIENT_DECAY_SECONDS = 0.5;
const TRANSIENT_DEVIATION_GAIN = 3.2;
const TRANSIENT_VARIANCE_GAIN = 1.6;

const ACTIVITY_SIGNAL_WEIGHT = 0.55;
const ACTIVITY_VARIANCE_WEIGHT = 0.65;
const ACTIVITY_TRANSIENT_WEIGHT = 0.45;

// A quiet organism still produces a gentle beat rather than silence; a strong
// transient can push well past the "normal" band before clamping.
const BEAT_STRENGTH_FLOOR = 0.22;
const BEAT_STRENGTH_ACTIVITY_GAIN = 0.62;
const BEAT_STRENGTH_TRANSIENT_GAIN = 0.38;

// How large a transient has to be (on the same 0..1 scale as `transient`) to
// count as a genuine bioelectric event worth an extra accent beat, and the
// minimum time between accepted accents - noisy sensor input must not be
// able to fire faster than this regardless of how erratic it gets.
const ACCENT_TRIGGER_THRESHOLD = 0.55;
const ACCENT_REFRACTORY_MS = 260;

export function createScionBiofeedbackState() {
  return {
    presence: 0,
    signal: 0,
    slow: 0,
    baseline: 0,
    baselineSeeded: false,
    variance: 0,
    transient: 0,
    activity: 0,
    beatStrength: 0,
    rawPrevious: 0,
    lastAccentAt: -Infinity,
    accentStrength: 0,
    // Edge-detection bookkeeping for applyScionBeatPulse - kept here (rather
    // than left to spring into existence on first use) so a reset genuinely
    // clears them instead of leaving a stale beat/accent index behind.
    lastBeatIndexApplied: -1,
    lastAccentAppliedAt: -Infinity,
    lastAt: 0
  };
}

export function scionActivityFromBands(bands = {}) {
  const level = Number(bands.level) || 0;
  const spectral = ((Number(bands.bass) || 0) + (Number(bands.mids) || 0) + (Number(bands.highs) || 0)) / 3;
  return clamp01(Math.max(level, spectral));
}

function approach(current, target, dt, tau) {
  return current + (target - current) * (1 - Math.exp(-dt / tau));
}

export function updateScionBiofeedback(state, { live = false, bands = null, now = 0 } = {}) {
  if (!state) return createScionBiofeedbackState();
  const previousAt = state.lastAt;
  state.lastAt = now;
  const dt = previousAt ? Math.max(0, Math.min(MAX_DT, (now - previousAt) / 1000)) : 0;
  if (dt <= 0) return state;

  const rawActivity = live ? scionActivityFromBands(bands || {}) : 0;
  state.presence = approach(state.presence, live ? 1 : 0, dt, PRESENCE_TAU);
  state.signal = approach(state.signal, rawActivity, dt, SIGNAL_TAU);
  state.slow = approach(state.slow, rawActivity, dt, SLOW_TAU);

  if (live) {
    // Rectified derivative: how much the signal moved since the last sample,
    // smoothed into a short volatility envelope rather than read raw (a
    // single noisy sample must not, on its own, register as a spike).
    const delta = Math.abs(rawActivity - (Number(state.rawPrevious) || 0));
    state.variance = approach(state.variance, delta, dt, VARIANCE_TAU);
    if (!state.baselineSeeded) {
      // Snap instead of slewing up from 0 on the very first live sample (or
      // the first sample after a disconnect re-seeds it below) - otherwise
      // "recent normal" spends its first several seconds climbing from
      // nothing, which reads as one long false transient regardless of
      // whether the organism is actually doing anything unusual.
      state.baseline = rawActivity;
      state.baselineSeeded = true;
    } else {
      state.baseline = approach(state.baseline, rawActivity, dt, BASELINE_TAU);
    }
    const deviation = Math.max(0, rawActivity - state.baseline);
    const transientRaw = clamp01(deviation * TRANSIENT_DEVIATION_GAIN + state.variance * TRANSIENT_VARIANCE_GAIN);
    // Peak-hold (jump straight up on a spike) then exponential release, so a
    // transient stays visible for a moment instead of a single frame.
    state.transient = Math.max(transientRaw, state.transient - dt / TRANSIENT_DECAY_SECONDS);

    state.activity = clamp01(
      state.signal * ACTIVITY_SIGNAL_WEIGHT
      + state.variance * ACTIVITY_VARIANCE_WEIGHT
      + state.transient * ACTIVITY_TRANSIENT_WEIGHT
    );
    state.beatStrength = clamp01(
      BEAT_STRENGTH_FLOOR
      + state.activity * BEAT_STRENGTH_ACTIVITY_GAIN
      + state.transient * BEAT_STRENGTH_TRANSIENT_GAIN
    );

    if (transientRaw >= ACCENT_TRIGGER_THRESHOLD && now - state.lastAccentAt >= ACCENT_REFRACTORY_MS) {
      state.lastAccentAt = now;
      state.accentStrength = clamp01(0.6 + transientRaw * 0.5);
    }
    state.rawPrevious = rawActivity;
  } else {
    // Fail-safe: decay every derived channel smoothly toward a safe, quiet
    // resting state rather than snapping to 0 or leaving a stale spike/high
    // reading latched in from before the source dropped out.
    state.variance = approach(state.variance, 0, dt, VARIANCE_TAU);
    state.baseline = approach(state.baseline, 0, dt, BASELINE_TAU);
    state.baselineSeeded = false;
    state.transient = Math.max(0, state.transient - dt / TRANSIENT_DECAY_SECONDS);
    state.activity = approach(state.activity, 0, dt, SIGNAL_TAU);
    state.beatStrength = approach(state.beatStrength, 0, dt, SIGNAL_TAU);
    state.rawPrevious = 0;
  }
  return state;
}

// Edge-detects a new accent since the caller's own bookkeeping timestamp -
// the same pattern as the kick cooldown in liveAudioState.js, so one accent
// event is consumed exactly once regardless of frame rate.
export function scionAccentIsNew(state, previouslySeenAt) {
  return Boolean(state) && state.lastAccentAt > (Number(previouslySeenAt) || -Infinity);
}

// Applies the synthetic beat clock's regular pulse and any pending accent to
// audioFeatures.kickPulse, the same field every preset already reads for
// beat-driven motion. `absoluteBeat` should come from musicAwareState (i.e.
// the same clock beatPhase/beatIndex uniforms already use), so a regular beat
// and the visuals it drives are always in lockstep by construction.
export function applyScionBeatPulse({ audioFeatures, state, absoluteBeat }) {
  if (!audioFeatures || !state) return;
  const beatIndex = Math.floor(Number(absoluteBeat) || 0);
  if (beatIndex !== state.lastBeatIndexApplied) {
    state.lastBeatIndexApplied = beatIndex;
    audioFeatures.kickPulse = Math.max(audioFeatures.kickPulse || 0, state.beatStrength);
  }
  if (scionAccentIsNew(state, state.lastAccentAppliedAt)) {
    state.lastAccentAppliedAt = state.lastAccentAt;
    audioFeatures.kickPulse = Math.max(audioFeatures.kickPulse || 0, state.accentStrength);
  }
}

export function resetScionBiofeedbackState(state) {
  if (!state) return createScionBiofeedbackState();
  Object.assign(state, createScionBiofeedbackState());
  return state;
}

export function applyScionBiofeedbackSnapshot(state, snapshot = {}) {
  if (!state) return createScionBiofeedbackState();
  state.presence = clamp01(Number(snapshot.presence) || 0);
  state.signal = clamp01(Number(snapshot.signal) || 0);
  state.slow = clamp01(Number(snapshot.slow) || 0);
  state.variance = clamp01(Number(snapshot.variance) || 0);
  state.transient = clamp01(Number(snapshot.transient) || 0);
  state.activity = clamp01(Number(snapshot.activity) || 0);
  state.beatStrength = clamp01(Number(snapshot.beatStrength) || 0);
  return state;
}

export function scionBiofeedbackSnapshot(state = {}) {
  return {
    presence: clamp01(Number(state.presence) || 0),
    signal: clamp01(Number(state.signal) || 0),
    slow: clamp01(Number(state.slow) || 0),
    variance: clamp01(Number(state.variance) || 0),
    transient: clamp01(Number(state.transient) || 0),
    activity: clamp01(Number(state.activity) || 0),
    beatStrength: clamp01(Number(state.beatStrength) || 0)
  };
}
