export function validateMusicPlaylistState(state) {
  const fail = () => { throw new Error('Invalid or unsupported music playlist document; saved data was preserved.'); };
  if (!state || state.version !== 1 || !Array.isArray(state.playlists) || !state.playlists.length
      || typeof state.shuffleEnabled !== 'boolean' || !['off','all','one'].includes(state.repeatMode)) fail();
  const playlistIds = new Set(), entryIds = new Set();
  for (const list of state.playlists) {
    if (!list || typeof list.id !== 'string' || !list.id || playlistIds.has(list.id)
        || typeof list.name !== 'string' || !list.name.trim() || !Array.isArray(list.entries)) fail();
    playlistIds.add(list.id);
    for (const entry of list.entries) {
      if (!entry || typeof entry.id !== 'string' || !entry.id || entryIds.has(entry.id) || typeof entry.name !== 'string') fail();
      entryIds.add(entry.id);
      if (entry.reference !== null) {
        const ref = entry.reference;
        if (!ref || ref.kind !== 'mac-file' || typeof ref.bookmark !== 'string' || !ref.bookmark
            || typeof ref.securityScoped !== 'boolean' || typeof ref.fileURL !== 'string' || !ref.fileURL.startsWith('file:///')) fail();
      }
    }
    if (list.selectedTrackEntryId !== null && !list.entries.some(entry => entry.id === list.selectedTrackEntryId)) fail();
  }
  if (!playlistIds.has(state.selectedPlaylistId)) fail();
  if (state.currentTrackEntryId !== null) {
    if (!state.playlists.find(list => list.id === state.currentPlaylistId)?.entries.some(entry => entry.id === state.currentTrackEntryId)) fail();
  } else if (state.currentPlaylistId !== null) fail();
  return state;
}
