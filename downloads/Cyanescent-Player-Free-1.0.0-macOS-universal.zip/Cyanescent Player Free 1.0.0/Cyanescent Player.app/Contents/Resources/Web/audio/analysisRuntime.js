import { analyzeTrackTimeline } from "./trackAnalysis.js";
import {
  blendLookaheadIntoBands,
  computeLookaheadState,
  createEmptyLookaheadState
} from "./lookahead.js";
import {
  computeMusicAwareState,
  createMusicAwareState
} from "./musicAware.js";
import {
  updateLiveTempoTracker,
  getLiveBeatInfo,
  resetLiveTempoTracker
} from "./liveTempoTracker.js";
import {
  updateLiveStructureTracker,
  getLiveStructureState,
  resetLiveStructureTracker
} from "./liveStructureTracker.js";

export { createEmptyLookaheadState, createMusicAwareState };

export function createAudioAnalysisRuntime({
  getPlayerMode,
  getPlayerAudio,
  getAnalysisTimeline,
  setAnalysisTimeline,
  getAnalysisGeneration,
  setAnalysisPending,
  getLookaheadState,
  setLookaheadState,
  getMusicAwareState,
  setMusicAwareState,
  getAudioFeatures,
  getBands,
  getLiveTempoTracker,
  getLiveStructureTracker,
  getMonitoringInput,
  getScionVisualBpm,
  waveformController,
  updateWaveformProgress,
  ensureAudioContext,
  setDiagnostic
} = {}) {
  function resetLookaheadState() {
    setLookaheadState?.(createEmptyLookaheadState());
    const trackerState = getLiveTempoTracker?.();
    if (trackerState) resetLiveTempoTracker(trackerState);
    const structureState = getLiveStructureTracker?.();
    if (structureState) resetLiveStructureTracker(structureState);
  }

  async function analyzeLoadedTrack(src, generation, decodedBuffer) {
    await analyzeTrackTimeline({
      src,
      decodedBuffer,
      generation,
      currentGeneration: getAnalysisGeneration,
      audioContext: ensureAudioContext?.(),
      waveformController,
      updateWaveformProgress,
      setAnalysisTimeline,
      setAnalysisPending,
      resetLookaheadState,
      setDiagnostic
    });
  }

  function updateLookaheadState() {
    const lookaheadState = computeLookaheadState({
      playerMode: getPlayerMode?.(),
      audio: getPlayerAudio?.(),
      analysisTimeline: getAnalysisTimeline?.()
    });
    setLookaheadState?.(lookaheadState);
    return lookaheadState;
  }

  function blendTimelineIntoBands() {
    return blendLookaheadIntoBands(getBands?.(), getLookaheadState?.());
  }

  function updateLiveTempo() {
    const trackerState = getLiveTempoTracker?.();
    const active = Boolean(getMonitoringInput?.());
    const now = performance.now();
    const syntheticBpm = Number(getScionVisualBpm?.()) || 0;
    if (trackerState) {
      updateLiveTempoTracker({ state: trackerState, bands: getBands?.(), now, active, syntheticBpm });
    }
    const structureState = getLiveStructureTracker?.();
    if (structureState) {
      updateLiveStructureTracker({
        state: structureState,
        bands: getBands?.(),
        audioFeatures: getAudioFeatures?.(),
        tempoTrackerState: trackerState,
        now,
        active
      });
    }
  }

  function updateMusicAwareState() {
    const audio = getPlayerAudio?.();
    const now = performance.now();
    const trackerState = getLiveTempoTracker?.();
    const structureState = getLiveStructureTracker?.();
    const liveStructureState = structureState ? getLiveStructureState(structureState) : null;
    const phraseOffsetBeats = liveStructureState?.phraseLocked ? liveStructureState.phraseOffsetBeats : 0;
    const liveBeatInfo = trackerState ? getLiveBeatInfo(trackerState, now, phraseOffsetBeats) : null;
    const state = computeMusicAwareState({
      previousState: getMusicAwareState?.(),
      lookaheadState: getLookaheadState?.(),
      analysisTimeline: getAnalysisTimeline?.(),
      audioFeatures: getAudioFeatures?.(),
      liveBeatInfo,
      liveStructureState,
      currentTime: audio?.currentTime || 0
    });
    setMusicAwareState?.(state);
    return state;
  }

  return {
    resetLookaheadState,
    analyzeLoadedTrack,
    updateLookaheadState,
    blendTimelineIntoBands,
    updateLiveTempo,
    updateMusicAwareState
  };
}
