// Online structure classifier for live audio input: structural novelty
// (section-change events), the drop/buildUp/breakdown/calm/highEnergy
// classifiers, and - the harder problem - resolving which beat is actually
// "beat 0 of a phrase" without ever having seen the start of the track.
//
// liveTempoTracker.js's beat-phase lock is anchor-free (any detected kick
// is as good as any other for mod-1-beat phase), but the 8/16/32-beat
// phrase grid is not: it needs to know which beat, mod 8, a real musical
// phrase starts on, and nothing about tempo/phase alone tells you that if
// you started listening mid-track. This mirrors what the offline analyzer
// does for the same reason - see AudioAnalysisTimeline.
// estimatePhrasePhaseFromSections in features.js, which resolves an
// equivalent unknown by searching which of 8 candidate offsets makes real
// detected section boundaries land closest to 8-beat grid lines. This is
// the incremental, online version of that: instead of a one-shot search
// over a finished section list, it accumulates votes into 8 bins as
// structural events happen live, and commits once one bin's evidence
// clearly and durably wins.
//
// One extra genre-aware shortcut: trance/psytrance (this app's core genre)
// very commonly opens with a soft, sparse intro that then drops into the
// main kick-and-bass groove. That entrance is, by strong production
// convention, a phrase start - so a sustained low-energy stretch followed
// by a sustained energy jump is treated as high-confidence evidence on its
// own, instead of waiting for the slower statistical vote to accumulate.

import { clamp01, smoothstepJs } from "../utils/math.js";
import { getLiveBeatInfo } from "./liveTempoTracker.js";

// "Now" vs "baseline" envelopes for structural novelty. Baseline uses a
// slow ~18s constant (roughly a phrase or more at these tempos) so it
// represents "the recent normal", not "the last kick".
const ENERGY_NOW_ATTACK = 0.5;
const ENERGY_NOW_RELEASE = 0.9;
const BASELINE_ATTACK = 18;
const BASELINE_RELEASE = 18;
const BRIGHTNESS_NOW_ATTACK = 0.6;
const BRIGHTNESS_NOW_RELEASE = 1.0;
const FLUX_ATTACK = 0.25;
const FLUX_RELEASE = 0.4;

// Structural novelty scoring - mirrors AudioAnalysisTimeline's offline
// sectionProbability formula (energy/brightness deviation from trend, plus
// flux), re-weighted for the coarser, noisier live band signal.
const NOVELTY_ENERGY_WEIGHT = 1.3;
const NOVELTY_BRIGHTNESS_WEIGHT = 0.7;
const NOVELTY_FLUX_WEIGHT = 1.1;
const NOVELTY_ARM_THRESHOLD = 0.20;
const NOVELTY_FIRE_THRESHOLD = 0.38;
const NOVELTY_CONFIRM_MS = 250;
const NOVELTY_EVENT_MIN_INTERVAL_MS = 2600;

// Soft-intro -> drop pattern.
const LOW_ENERGY_THRESHOLD = 0.22;
const LOW_ENERGY_MIN_STREAK_MS = 8000;
const INTRO_DROP_SUSTAIN_CHECK_MS = 1800;
const INTRO_DROP_ABANDON_MS = 30000;
const INTRO_DROP_BONUS_WEIGHT = 5.0;

// Phrase-offset voting (8 bins covering beat-offset mod 8; 16/32 nest on
// top of whichever 8-beat anchor wins, same as the offline version only
// ever resolving mod 8 - see snapSectionsToLoops in features.js).
const PHRASE_MIN_EVIDENCE_WEIGHT = 6.0;
const PHRASE_LOCK_MARGIN = 0.18;
const PHRASE_MISMATCH_STREAK_REQUIRED = 3;

function followEnvelope(current, target, elapsedSeconds, attackSeconds, releaseSeconds) {
  const timeConstant = target > current ? attackSeconds : releaseSeconds;
  const amount = 1 - Math.exp(-elapsedSeconds / Math.max(0.001, timeConstant));
  return current + (target - current) * amount;
}

export function createLiveStructureTrackerState() {
  return {
    lastUpdateAt: null,

    energyNow: 0,
    energyBaseline: 0,
    brightnessNow: 0,
    brightnessBaseline: 0,
    fluxNow: 0,
    density: 0,
    previousBass: 0,
    previousMid: 0,
    previousTreble: 0,

    noveltyNow: 0,
    noveltyArmed: true,
    noveltyConfirmUntilMs: 0,
    noveltyConfirmPeak: 0,
    noveltyConfirmOnsetMs: 0,
    lastNoveltyEventAt: 0,

    lowEnergyStreakMs: 0,
    dropSignalArmed: true,
    pendingIntroDropOnsetMs: 0,

    sectionChange: 0,
    buildUp: 0,
    drop: 0,
    breakdown: 0,
    calm: 0,
    highEnergy: 0,
    mainRiff: 0,

    phraseBinSum: new Array(8).fill(0),
    phraseBinWeight: new Array(8).fill(0),
    phraseLocked: false,
    phraseOffsetBeats: 0,
    phraseConfidence: 0,
    phraseMismatchStreak: 0,
    lockedBpmSeen: 0
  };
}

export function resetLiveStructureTracker(state) {
  if (!state) return createLiveStructureTrackerState();
  Object.assign(state, createLiveStructureTrackerState());
  return state;
}

function distanceToNearestMultipleOf8(beatFloat) {
  const wrapped = ((beatFloat % 8) + 8) % 8;
  return Math.min(wrapped, 8 - wrapped);
}

function castPhraseVote(state, tempoTrackerState, atMs, weight) {
  if (!(weight > 0)) return false;
  const info = getLiveBeatInfo(tempoTrackerState, atMs);
  if (!info) return false;
  const beatFloat = info.beatIndex + info.beatPhase;
  for (let offset = 0; offset < 8; offset += 1) {
    const distance = distanceToNearestMultipleOf8(beatFloat - offset);
    const closeness = Math.max(0, 1 - distance / 4);
    state.phraseBinSum[offset] += weight * closeness;
    state.phraseBinWeight[offset] += weight;
  }
  return true;
}

function resolvePhraseOffset(state) {
  let bestOffset = 0;
  let bestAvg = -Infinity;
  let secondAvg = -Infinity;
  let totalWeight = 0;
  for (let offset = 0; offset < 8; offset += 1) {
    totalWeight += state.phraseBinWeight[offset];
    const avg = state.phraseBinWeight[offset] > 0 ? state.phraseBinSum[offset] / state.phraseBinWeight[offset] : 0;
    if (avg > bestAvg) {
      secondAvg = bestAvg;
      bestAvg = avg;
      bestOffset = offset;
    } else if (avg > secondAvg) {
      secondAvg = avg;
    }
  }
  if (totalWeight < PHRASE_MIN_EVIDENCE_WEIGHT) return;
  const margin = bestAvg - Math.max(0, secondAvg);

  if (!state.phraseLocked) {
    if (margin >= PHRASE_LOCK_MARGIN) {
      state.phraseOffsetBeats = bestOffset;
      state.phraseLocked = true;
      state.phraseConfidence = clamp01(margin * 2.2);
      state.phraseMismatchStreak = 0;
    }
    return;
  }

  state.phraseConfidence = clamp01(Math.max(state.phraseConfidence * 0.9, margin * 2.2));
  // phraseOffsetBeats may hold a full (unreduced) beat count when it came
  // from commitPhraseAnchor below rather than this mod-8-only vote - compare
  // mod 8 rather than raw equality, or a fast-path anchor that's already
  // musically correct mod 8 would look like a permanent disagreement here
  // and eventually get "corrected" down to a plain 0-7 value, throwing away
  // the extra 16/32-beat precision it was carrying for no reason.
  const currentOffsetMod8 = ((state.phraseOffsetBeats % 8) + 8) % 8;
  if (bestOffset === currentOffsetMod8) {
    state.phraseMismatchStreak = 0;
    return;
  }
  // Don't flap the committed offset on a single noisy window - require a
  // sustained, clear preference for a different offset before switching.
  if (margin >= PHRASE_LOCK_MARGIN) {
    state.phraseMismatchStreak += 1;
    if (state.phraseMismatchStreak >= PHRASE_MISMATCH_STREAK_REQUIRED) {
      // The statistics disagree with the committed anchor - fall back to
      // the plain mod-8 value the vote actually supports (any 16/32-beat
      // precision the previous anchor had is no longer trustworthy either).
      state.phraseOffsetBeats = bestOffset;
      state.phraseMismatchStreak = 0;
    }
  } else {
    state.phraseMismatchStreak = 0;
  }
}

// Immediately, and with high confidence, commit a phrase-zero anchor - used
// for the soft-intro -> drop shortcut, where genre convention already makes
// this a near-certainty rather than something to wait and vote on. Unlike
// the statistical vote above (which only ever resolves mod 8), this keeps
// the full beat count of the captured onset, so it anchors the 16- and
// 32-beat grids correctly too, not just the 8-beat one - producers
// overwhelmingly design this entrance to start a full section, not just an
// 8-beat sub-phrase.
function commitPhraseAnchor(state, beatFloat) {
  state.phraseOffsetBeats = Math.round(beatFloat);
  state.phraseLocked = true;
  state.phraseConfidence = Math.max(state.phraseConfidence, 0.7);
  state.phraseMismatchStreak = 0;
}

function updateClassifiers(state, { tempoTrackerState, now, elapsedSeconds, audioFeatures }) {
  const energyRise = clamp01(Math.max(0, state.energyNow - state.energyBaseline) * 2.6);
  const energyFall = clamp01(Math.max(0, state.energyBaseline - state.energyNow) * 2.6);

  let boundaryPassed = 0;
  let boundaryApproaching = 0;
  if (state.phraseLocked) {
    const corrected = getLiveBeatInfo(tempoTrackerState, now, state.phraseOffsetBeats);
    if (corrected) {
      boundaryPassed = smoothstepJs(0.14, 0.0, corrected.phrase8Progress);
      boundaryApproaching = smoothstepJs(0.72, 1.0, corrected.phrase8Progress);
    }
  }

  const dropTarget = clamp01((Number(audioFeatures?.dropDetected) || 0) * (0.7 + boundaryPassed * 0.6));
  const buildTarget = clamp01(energyRise * (0.6 + boundaryApproaching * 0.7));
  const breakdownTarget = clamp01(energyFall * 0.8 + (state.energyNow < 0.16 ? 0.3 : 0));
  const calmTarget = clamp01(breakdownTarget * 0.7 + (state.energyNow < 0.14 ? 0.3 : 0));
  const highEnergyTarget = clamp01(state.energyNow * 0.85 + dropTarget * 0.4);
  const mainRiffTarget = state.energyNow > 0.55 ? clamp01(state.energyNow) : 0;

  state.drop = followEnvelope(state.drop, dropTarget, elapsedSeconds, 0.10, 0.55);
  state.buildUp = followEnvelope(state.buildUp, buildTarget, elapsedSeconds, 0.6, 1.2);
  state.breakdown = followEnvelope(state.breakdown, breakdownTarget, elapsedSeconds, 1.5, 2.2);
  state.calm = followEnvelope(state.calm, calmTarget, elapsedSeconds, 1.8, 2.4);
  state.highEnergy = followEnvelope(state.highEnergy, highEnergyTarget, elapsedSeconds, 0.5, 1.0);
  state.mainRiff = followEnvelope(state.mainRiff, mainRiffTarget, elapsedSeconds, 0.6, 1.2);
  // sectionChange is set to a peak value when a novelty event fires (see
  // below); decay it back down here so it reads as a pulse, not a latch.
  state.sectionChange *= Math.exp(-elapsedSeconds / 0.9);
}

export function updateLiveStructureTracker({
  state,
  bands,
  audioFeatures,
  tempoTrackerState,
  now = performance.now(),
  active = true
} = {}) {
  if (!state) return state;
  const previousAt = state.lastUpdateAt ?? now;
  const elapsedSeconds = Math.max(0, Math.min(0.25, (now - previousAt) / 1000));
  state.lastUpdateAt = now;
  if (!active) return state;

  const beatInfo = getLiveBeatInfo(tempoTrackerState, now);
  // A different tempo lock than the one our phrase histogram was built
  // against (new track, or a fresh re-lock) makes the accumulated votes
  // meaningless - start the phrase search over.
  if (beatInfo) {
    if (state.lockedBpmSeen && Math.abs(beatInfo.bpm - state.lockedBpmSeen) > 1.5) {
      state.phraseBinSum.fill(0);
      state.phraseBinWeight.fill(0);
      state.phraseLocked = false;
      state.phraseOffsetBeats = 0;
      state.phraseConfidence = 0;
      state.phraseMismatchStreak = 0;
      state.pendingIntroDropOnsetMs = 0;
    }
    state.lockedBpmSeen = beatInfo.bpm;
  }

  const bass = clamp01(Number(bands?.bass) || 0);
  const mid = clamp01(Number(bands?.mids) || 0);
  const treble = clamp01(Number(bands?.highs) || 0);
  const level = clamp01(Number(bands?.level) || 0);
  const brightness = clamp01(Number(bands?.brightness) || 0);
  const fluxSample = clamp01(
    Math.abs(bass - state.previousBass) + Math.abs(mid - state.previousMid) + Math.abs(treble - state.previousTreble)
  );
  state.previousBass = bass;
  state.previousMid = mid;
  state.previousTreble = treble;

  const energySample = clamp01(level * 0.48 + bass * 0.24 + mid * 0.17 + treble * 0.11);
  state.energyNow = followEnvelope(state.energyNow, energySample, elapsedSeconds, ENERGY_NOW_ATTACK, ENERGY_NOW_RELEASE);
  state.energyBaseline = followEnvelope(state.energyBaseline, energySample, elapsedSeconds, BASELINE_ATTACK, BASELINE_RELEASE);
  state.brightnessNow = followEnvelope(state.brightnessNow, brightness, elapsedSeconds, BRIGHTNESS_NOW_ATTACK, BRIGHTNESS_NOW_RELEASE);
  state.brightnessBaseline = followEnvelope(state.brightnessBaseline, brightness, elapsedSeconds, BASELINE_ATTACK, BASELINE_RELEASE);
  state.fluxNow = followEnvelope(state.fluxNow, fluxSample, elapsedSeconds, FLUX_ATTACK, FLUX_RELEASE);
  state.density = clamp01(state.energyNow * 0.48 + state.fluxNow * 0.34 + (Number(audioFeatures?.kickPulse) || 0) * 0.18);

  state.noveltyNow = clamp01(
    Math.abs(state.energyNow - state.energyBaseline) * NOVELTY_ENERGY_WEIGHT
    + Math.abs(state.brightnessNow - state.brightnessBaseline) * NOVELTY_BRIGHTNESS_WEIGHT
    + state.fluxNow * NOVELTY_FLUX_WEIGHT
  );

  if (state.energyBaseline < LOW_ENERGY_THRESHOLD) {
    state.lowEnergyStreakMs += elapsedSeconds * 1000;
  } else {
    state.lowEnergyStreakMs = 0;
  }

  // Novelty event detection: confirm-then-fire (like a slower kickPulse) so
  // a single noisy frame can't trigger an event on its own.
  if (
    !state.noveltyConfirmUntilMs
    && state.noveltyArmed
    && state.noveltyNow >= NOVELTY_FIRE_THRESHOLD
    && now - state.lastNoveltyEventAt >= NOVELTY_EVENT_MIN_INTERVAL_MS
  ) {
    state.noveltyConfirmUntilMs = now + NOVELTY_CONFIRM_MS;
    state.noveltyConfirmPeak = state.noveltyNow;
    state.noveltyConfirmOnsetMs = now;
  }
  if (state.noveltyConfirmUntilMs) {
    state.noveltyConfirmPeak = Math.max(state.noveltyConfirmPeak, state.noveltyNow);
    if (now >= state.noveltyConfirmUntilMs) {
      const eventWeight = state.noveltyConfirmPeak;
      const eventOnsetMs = state.noveltyConfirmOnsetMs;
      state.sectionChange = Math.max(state.sectionChange, eventWeight);
      state.noveltyArmed = false;
      state.lastNoveltyEventAt = now;
      state.noveltyConfirmUntilMs = 0;

      if (castPhraseVote(state, tempoTrackerState, eventOnsetMs, eventWeight)) {
        resolvePhraseOffset(state);
      }
    }
  }
  if (!state.noveltyArmed && state.noveltyNow < NOVELTY_ARM_THRESHOLD) state.noveltyArmed = true;

  // Classic trance/psytrance opener: a long quiet stretch followed by a
  // strong, sustained energy jump. This needs a precise onset timestamp to
  // anchor the phrase grid to, so it rides audioFeatures.dropDetected
  // directly (already tuned for fast surge detection, ~0.1s latency)
  // instead of the novelty pipeline above, whose ~0.5s energy envelope and
  // confirm window would otherwise anchor the phrase grid the better part
  // of a beat late.
  // Only ever fires once: audioFeatures.dropDetected re-triggers on its own
  // ~2.6s cooldown timer regardless of the beat grid, so later triggers
  // during an already-established groove land at essentially arbitrary
  // (non-beat-quantized) offsets from the real entrance - letting this keep
  // firing after a lock is already established would just as often
  // clobber a correct phrase anchor with a wrong one as reinforce it.
  const dropSignal = clamp01(Number(audioFeatures?.dropDetected) || 0);
  if (!state.dropSignalArmed && dropSignal < 0.15) state.dropSignalArmed = true;
  if (
    state.dropSignalArmed
    && dropSignal > 0.5
    && !state.pendingIntroDropOnsetMs
    && !state.phraseLocked
    && state.lowEnergyStreakMs >= LOW_ENERGY_MIN_STREAK_MS
  ) {
    state.pendingIntroDropOnsetMs = now;
    state.dropSignalArmed = false;
  }

  // Resolve a pending intro/breakdown -> drop candidate. This keeps
  // retrying every frame (not just once) because the tempo tracker itself
  // typically can't lock until a few seconds after a beatless intro's kick
  // actually arrives - the vote has to wait for that lock either way, so
  // this makes sure it fires the moment the lock appears rather than
  // missing a single check window.
  if (state.pendingIntroDropOnsetMs) {
    const sincePendingMs = now - state.pendingIntroDropOnsetMs;
    // Wait for the sustain window before judging "did it stick" at all -
    // energyNow's own envelope (slower than the fast dropDetected signal
    // that captured this timestamp) hasn't had time to rise yet on the
    // frames right after the onset, so checking it too early would read as
    // "fell back down" before it ever got a chance to climb.
    if (sincePendingMs >= INTRO_DROP_SUSTAIN_CHECK_MS) {
      if (state.energyNow < LOW_ENERGY_THRESHOLD + 0.05) {
        // Genuinely back down by now - a loud transient in the intro, not a
        // real, sustained groove entrance.
        state.pendingIntroDropOnsetMs = 0;
      } else {
        const info = getLiveBeatInfo(tempoTrackerState, state.pendingIntroDropOnsetMs);
        if (info) {
          castPhraseVote(state, tempoTrackerState, state.pendingIntroDropOnsetMs, INTRO_DROP_BONUS_WEIGHT);
          // A lock could have landed from the statistical vote while this
          // was pending - don't let a stale fast-path candidate clobber it.
          if (!state.phraseLocked) commitPhraseAnchor(state, info.beatIndex + info.beatPhase);
          state.pendingIntroDropOnsetMs = 0;
        } else if (sincePendingMs > INTRO_DROP_ABANDON_MS) {
          // Tempo never locked - give up; ordinary voting is still available
          // once/if it eventually does.
          state.pendingIntroDropOnsetMs = 0;
        }
        // else: sustained, tempo just isn't locked yet - keep waiting and
        // re-check next frame.
      }
    }
  }

  updateClassifiers(state, { tempoTrackerState, now, elapsedSeconds, audioFeatures });

  return state;
}

export function getLiveStructureState(state) {
  if (!state) return null;
  return {
    sectionChange: clamp01(state.sectionChange),
    breakdown: clamp01(state.breakdown),
    calm: clamp01(state.calm),
    buildUp: clamp01(state.buildUp),
    drop: clamp01(state.drop),
    highEnergy: clamp01(state.highEnergy),
    mainRiff: clamp01(state.mainRiff),
    adaptiveIntensity: clamp01(
      state.energyNow * 0.42 + state.density * 0.22 + state.highEnergy * 0.26 + state.buildUp * 0.16 + state.drop * 0.22
    ),
    // These mirror the offline branch's own non-lookahead fallback formulas
    // (they only use real lookahead when a specific upcoming section was
    // found; otherwise they already reduce to this same energy-trend-based
    // shape) - genuine lookahead fields (futureEnergy/futureBrightness/
    // futureDensity/energyTrend) have no honest live analogue and are left
    // at their decayed default instead of being faked from current values.
    upcomingBuild: clamp01(state.buildUp * 0.42),
    upcomingDrop: clamp01(Math.max(0, state.energyNow - state.energyBaseline) * 2.6 * 0.32),
    upcomingBreakdown: clamp01(Math.max(0, state.energyBaseline - state.energyNow) * 2.6 * 0.22),
    phraseLocked: state.phraseLocked,
    phraseOffsetBeats: state.phraseOffsetBeats,
    phraseConfidence: state.phraseConfidence
  };
}
