import { AudioAnalysisTimeline } from "./features.js";
import { nativeAppBridge } from "../utils/nativeBridge.js";
import { loadDropMarkers } from "./dropMarkerStore.js";

function nativeTrackIdFromSource(src) {
  const match = String(src || "").match(/(?:cyanescent-audio:\/\/track|\/native-track)\/([^/?#]+)/);
  return match ? decodeURIComponent(match[1]) : "";
}

function reportAudioImportDiagnostic(stage, details = {}) {
  const bridge = nativeAppBridge?.();
  if (!bridge) return;
  let serialized = "{}";
  try { serialized = JSON.stringify(details); } catch (error) {}
  bridge.postMessage({
    command: "audioImportDiagnostic",
    text: `stage=${stage} details=${serialized}`
  });
}

function fullErrorDetails(error) {
  return {
    name: error?.name || "Error",
    message: error?.message || String(error || "Unknown error"),
    stack: error?.stack || ""
  };
}

export async function analyzeTrackTimeline({
  src,
  decodedBuffer,
  generation,
  currentGeneration,
  audioContext,
  waveformController,
  updateWaveformProgress,
  setAnalysisTimeline,
  setAnalysisPending,
  resetLookaheadState,
  setDiagnostic
} = {}) {
  setAnalysisPending?.(true);
  setAnalysisTimeline?.(null);
  resetLookaheadState?.();
  setDiagnostic?.("Analyzing track timeline...");
  const nativeTrackId = nativeTrackIdFromSource(src);
  reportAudioImportDiagnostic("analysis-source", {
    source: String(src || ""),
    nativeTrackId: nativeTrackId || "none"
  });
  if (nativeTrackId && nativeAppBridge?.()) {
    window.__nativeWaveformPreview = (state = {}) => {
      if (Number(state.generation) !== Number(generation)) return;
      if (Array.isArray(state.peaks)) {
        waveformController?.setProgressiveWaveform?.(state.peaks, state.progress, Boolean(state.complete));
      }
    };
    nativeAppBridge().postMessage({
      command: "startNativeWaveformPreview",
      audioTrackId: nativeTrackId,
      generation
    });
  }
  try {
    const options = {
      // Native-picked tracks have an AVFoundation scanner already streaming
      // the visible waveform. Avoid racing it with a second browser-side scan.
      onWaveformProgress: nativeTrackId ? null : (state) => {
        if (generation !== currentGeneration?.()) return;
        waveformController?.setProgressiveWaveform?.(state.peaks, state.progress, state.complete);
      },
      onLoadStage: reportAudioImportDiagnostic
    };
    const timeline = decodedBuffer
      ? await AudioAnalysisTimeline.fromAudioBuffer(decodedBuffer, options)
      : await AudioAnalysisTimeline.fromSource(src, audioContext, options);
    if (generation !== currentGeneration?.()) return null;
    // the listener's drop markers for this track, if any were saved
    timeline.setDropMarkers?.(loadDropMarkers(timeline.fingerprint));
    setAnalysisTimeline?.(timeline);
    waveformController?.setAnalysisTimeline(timeline);
    updateWaveformProgress?.(true);
    setAnalysisPending?.(false);
    const bpmText = timeline.tempo?.bpm ? `, ${timeline.tempo.bpm.toFixed(1)} BPM` : "";
    setDiagnostic?.(`Lookahead analysis ready: ${timeline.frames.length} frames${bpmText}`);
    return timeline;
  } catch (error) {
    if (generation !== currentGeneration?.()) return null;
    setAnalysisPending?.(false);
    waveformController?.clearAnalysis();
    updateWaveformProgress?.(true);
    const details = fullErrorDetails(error);
    reportAudioImportDiagnostic("analysis-failed", details);
    setDiagnostic?.(`Playback ready; analysis unavailable: ${details.message}`);
    console.error("Audio analysis load failed", details);
    return null;
  }
}
