import { clamp01 } from "../utils/math.js";

export function createEmptyLookaheadState() {
  return {
    ready: false,
    current: null,
    short: null,
    medium: null,
    long: null
  };
}

export function computeLookaheadState({
  playerMode,
  audio,
  analysisTimeline
} = {}) {
  if (!playerMode || !audio || !analysisTimeline) {
    return createEmptyLookaheadState();
  }
  const currentTime = audio.currentTime || 0;
  return {
    ready: true,
    current: analysisTimeline.getFeatures(currentTime),
    short: analysisTimeline.getLookaheadFeatures(currentTime, 0.5),
    medium: analysisTimeline.getLookaheadFeatures(currentTime, 5),
    long: analysisTimeline.getLookaheadFeatures(currentTime, 20)
  };
}

export function blendLookaheadIntoBands(bands, lookaheadState) {
  if (!lookaheadState?.ready || !lookaheadState.current) return bands;
  const current = lookaheadState.current;
  const short = lookaheadState.short || current;
  const long = lookaheadState.long || current;
  const anticipation = clamp01((short.energyDelta || 0) * 1.8 + (long.energyDelta || 0) * 0.6);
  bands.level = Math.max(bands.level, current.energy * 0.42 + anticipation * 0.16);
  bands.bass = Math.max(bands.bass, current.bass * 0.35);
  bands.mids = Math.max(bands.mids, current.mid * 0.32);
  bands.highs = Math.max(bands.highs, current.treble * 0.28);
  bands.brightness = Math.max(bands.brightness, current.brightness * 0.22 + (short.brightness || 0) * 0.10);
  return bands;
}
