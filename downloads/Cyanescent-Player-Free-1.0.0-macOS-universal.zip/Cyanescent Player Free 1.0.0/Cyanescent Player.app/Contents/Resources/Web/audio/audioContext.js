export function ensureAudioContextInstance(currentContext, AudioContextClass = window.AudioContext) {
  return currentContext || new AudioContextClass();
}

export async function resumeAudioContextBestEffort(context, timeoutMs = 450) {
  if (!context || context.state !== "suspended") return true;
  try {
    await Promise.race([
      context.resume(),
      new Promise((resolve) => window.setTimeout(() => resolve(false), timeoutMs))
    ]);
  } catch (error) {
    console.warn("AudioContext resume was deferred", error);
  }
  return context.state !== "suspended";
}

export function createConfiguredAnalyser(context) {
  const analyser = context.createAnalyser();
  analyser.fftSize = 512;
  analyser.smoothingTimeConstant = 0.05;
  return analyser;
}

export function createAnalyserBuffers(analyser) {
  return {
    frequency: new Uint8Array(analyser.frequencyBinCount),
    time: new Uint8Array(analyser.fftSize)
  };
}
