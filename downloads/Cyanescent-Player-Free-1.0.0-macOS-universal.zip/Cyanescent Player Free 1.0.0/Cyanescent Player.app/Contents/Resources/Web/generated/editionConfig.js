export const editionConfig = Object.freeze({
  "id": "free",
  "displayName": "Cyanescent Player",
  "bundleIdentifier": "local.cyanescent-player.free",
  "packageName": "Cyanescent Player.app",
  "executableName": "CyanescentPlayer",
  "completePresetLibrary": false,
  "allowJsonPresetImports": true,
  "allowedPresetIds": [
    163,
    167,
    146,
    147,
    148,
    94,
    143,
    172,
    174,
    176,
    180,
    165,
    142,
    141,
    1,
    5,
    97,
    98
  ],
  "videoExport": {
    "allow4K": false,
    "maxLandscapeWidth": 1920,
    "maxLandscapeHeight": 1080,
    "maxPortraitWidth": 1080,
    "maxPortraitHeight": 1920,
    "maxPixels": 2073600
  },
  "capabilities": {
    "adaptiveEngine": "musical",
    "renderedTransitions": true,
    "realTimePresets": "curated",
    "videoPresets": false,
    "videoTransitions": false,
    "alienVisits": false,
    "optionalHDWorlds": false,
    "maxExportResolution": "1080p"
  },
  "assetGroups": [
    "shared"
  ],
  "optionalPresetIds": [],
  "assetPolicy": {
    "presetDependencies": true,
    "bundleOptionalWorlds": false,
    "selection": "declared-dependencies"
  },
  "distribution": {
    "access": "free-download",
    "licenceActivation": false,
    "priceUSD": 0
  },
  "productVersion": "1.0.0",
  "buildNumber": "2",
  "assetPaths": [
    "assets/cyanescent-fractal-icon.png",
    "assets/cymatic_mandala_modes.png",
    "assets/om-symbol.png",
    "assets/scion-midi/bach.mid",
    "assets/scion-midi/brahms.mid",
    "assets/scion-midi/mozart.mid",
    "assets/splash-fractal-bg.jpg"
  ],
  "videoPresetIds": [
    78,
    79
  ],
  "registeredPresetIds": [
    163,
    167,
    146,
    147,
    148,
    94,
    143,
    172,
    174,
    176,
    180,
    165,
    142,
    141,
    1,
    5,
    97,
    98
  ],
  "corePresetIds": [
    163,
    167,
    146,
    147,
    148,
    94,
    143,
    172,
    174,
    176,
    180,
    165,
    142,
    141,
    1,
    5,
    97,
    98
  ],
  "optionalPresets": []
});
export function editionAllowsPreset(presetId) { return !(editionConfig.excludedPresetIds || []).includes(Number(presetId)) && (editionConfig.completePresetLibrary || editionConfig.allowedPresetIds.includes(Number(presetId))); }
export function editionIncludesAsset(path) { return editionConfig.assetPaths === null || editionConfig.assetPaths.includes(String(path)); }
