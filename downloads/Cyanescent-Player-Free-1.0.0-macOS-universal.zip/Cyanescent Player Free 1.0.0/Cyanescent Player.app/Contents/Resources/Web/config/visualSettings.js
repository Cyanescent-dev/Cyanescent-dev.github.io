// Presets rely on this uniform remaining available even though it is no longer
// user-configurable. Keep one shared value for rendering and status display.
export const VISUAL_AUDIO_SENSITIVITY = 1.35;
