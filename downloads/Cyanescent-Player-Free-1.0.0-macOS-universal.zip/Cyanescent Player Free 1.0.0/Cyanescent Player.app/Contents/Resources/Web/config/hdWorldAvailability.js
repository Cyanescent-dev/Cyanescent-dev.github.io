import { editionConfig } from '../generated/editionConfig.js';

// Native validation is the authority. Never infer installation from registered shaders,
// localStorage, an asset HTTP 200, or a pack's own inventory.
let worlds = new Map();
if (editionConfig.capabilities?.optionalHDWorlds && typeof window !== 'undefined'
    && /^https?:$/.test(window.location?.protocol || '')) {
  try {
    const splash = document.getElementById?.('engineSplashStatus');
    if (splash) splash.textContent = 'Checking HD Worlds…';
    let completed = false;
    for (let attempt = 0; attempt < 600; attempt++) {
      const response = await fetch('/hd-world-status.json', { cache: 'no-store' });
      if (!response.ok) throw new Error('HD World validation status unavailable');
      const status = await response.json();
      if (!status.checking) {
        worlds = new Map((status.worlds || []).filter(w => editionConfig.optionalPresetIds.includes(Number(w.id)))
          .map(w => [Number(w.id), { state: w.state, message: String(w.message || 'HD World validation failed') }]));
        completed = true;
        break;
      }
      await new Promise(resolve => setTimeout(resolve, 250));
    }
    if (!completed) throw new Error('HD World validation timed out — restart Player to retry');
  } catch (error) {
    worlds = new Map((editionConfig.optionalPresetIds || []).map(id => [Number(id),
      { state: 'invalid', message: `HD World validation unavailable: ${error.message}` }]));
    console.warn('HD Worlds remain unavailable:', error.message);
  }
}

export function hdWorldStatus(id) {
  return worlds.get(Number(id)) || { state: 'missing', message: 'HD World — Not Installed' };
}
export function hdWorldIsInstalled(id) { return hdWorldStatus(id).state === 'valid'; }
