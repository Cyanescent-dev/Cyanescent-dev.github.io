import { hdWorldIsInstalled, hdWorldStatus } from './hdWorldAvailability.js';
import { editionConfig } from '../generated/editionConfig.js';

export function capabilityEnabled(name, config = editionConfig) {
  return config.capabilities?.[name] === true;
}

// Optional built-ins need native-validated installation. Registration alone grants no access.
// Imported shaders use the existing reserved user-ID range and separate catalog validation.
export function runtimeAllowsPreset(value, config = editionConfig) {
  const id = Number(value);
  if (!Number.isInteger(id)) return false;
  if (id >= 10000) return config.allowJsonPresetImports === true;
  const optional = (config.optionalPresetIds || []).includes(id);
  return (optional ? capabilityEnabled('optionalHDWorlds', config) && hdWorldIsInstalled(id) : (config.corePresetIds || []).includes(id))
    && (!(config.videoPresetIds || []).includes(id) || capabilityEnabled('videoPresets', config));
}

export function requireRuntimePreset(value, config = editionConfig) {
  if (!runtimeAllowsPreset(value, config)) throw new Error((config.optionalPresetIds || []).includes(Number(value))
    ? `HD World ${value} is unavailable: ${hdWorldStatus(value).message}. Quit Player, install the matching expansion pack, then restart.`
    : `Preset ${value} is unavailable in this edition or requires optional installed content.`);
  return Number(value);
}

export function enforceRuntimeOptions(options, config = editionConfig) {
  if (!capabilityEnabled('videoTransitions', config)) options.useVideoTransitions = false;
  if (!capabilityEnabled('alienVisits', config)) options.alienVisits = false;
  return options;
}

// Mutate execution state only, never the stored authored markers or playlists.
export function enforceTransitionCapabilities(transition, config = editionConfig) {
  if (transition && !capabilityEnabled('videoTransitions', config)) {
    transition.useVideoTransitions = false;
    transition.forceVideoTransition = false;
    transition.videoTransitionId = '';
    transition.videoTransition = null;
    transition.suppressVideoTransition = true;
    transition.suppressShaderTransition = false;
  }
  return transition;
}
