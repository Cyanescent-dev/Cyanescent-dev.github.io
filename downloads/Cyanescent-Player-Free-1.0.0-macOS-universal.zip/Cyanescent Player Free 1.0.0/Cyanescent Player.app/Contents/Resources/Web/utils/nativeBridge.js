export function nativeAppBridge() {
  return window.webkit?.messageHandlers?.nativeApp || null;
}
