export function installNativeConsoleLogging() {
  if (window.__cyanescentLoggingReady) return;
  const bridge = window.webkit?.messageHandlers?.nativeApp;
  if (!bridge) return;

  function sendLog(type, text) {
    bridge.postMessage({ command: "logConsole", type, text });
  }

  function formatArgs(args) {
    return Array.from(args).map((arg) => {
      if (arg === null) return "null";
      if (arg === undefined) return "undefined";
      if (arg && arg.stack) return String(arg.stack);
      if (arg instanceof Error || (arg && arg.name && arg.message)) {
        return `${arg.name || "Error"}: ${arg.message}`;
      }
      if (arg && typeof arg === "object") {
        if (arg.message) return `${arg.name || "DOMException"}: ${arg.message}`;
        try {
          const obj = {};
          const props = Object.getOwnPropertyNames(arg);
          for (const prop of props) {
            const val = arg[prop];
            if (typeof val === "function") continue;
            obj[prop] = val;
          }
          const str = JSON.stringify(obj);
          return str === "{}" ? String(arg) : str;
        } catch (e) {
          return String(arg);
        }
      }
      return String(arg);
    }).join(" ");
  }

  window.addEventListener("error", (event) => {
    sendLog("error", `Uncaught Error: ${event.message} at ${event.filename}:${event.lineno}:${event.colno}`);
  });
  window.addEventListener("unhandledrejection", (event) => {
    sendLog("error", `Unhandled Rejection: ${event.reason?.stack || event.reason}`);
  });

  const originalError = console.error;
  console.error = function() {
    originalError.apply(console, arguments);
    sendLog("error", formatArgs(arguments));
  };

  const originalWarn = console.warn;
  console.warn = function() {
    originalWarn.apply(console, arguments);
    sendLog("warn", formatArgs(arguments));
  };

  window.__cyanescentLoggingReady = true;
}
