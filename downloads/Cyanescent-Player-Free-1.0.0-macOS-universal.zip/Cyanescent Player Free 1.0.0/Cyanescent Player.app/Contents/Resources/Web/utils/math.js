export function clamp01(value) {
  return Math.max(0, Math.min(1, value));
}

export function smoothstepJs(edge0, edge1, value) {
  const t = clamp01((value - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

export function mixJs(a, b, amount) {
  return a + (b - a) * amount;
}

export function fractJs(value) {
  return value - Math.floor(value);
}
