(() => {
  // This is app chrome, not a browser page. WebKit's default Reload menu
  // destroys the in-memory timeline; retain native menus only for text editing.
  document.addEventListener("contextmenu", (event) => {
    const target = event.target;
    if (target?.closest?.("input, textarea") || target?.isContentEditable) return;
    event.preventDefault();
  }, true);

  // Secondary/Control-clicks must not reach waveform seek/drag handlers either.
  // Install at boot so this also covers loading screens and both app windows.
  for (const name of ["pointerdown", "click"]) {
    document.addEventListener(name, (event) => {
      if ((event.button !== 0 || event.ctrlKey) && event.target?.closest?.("canvas, #xsTlSegments")) {
        event.preventDefault();
        event.stopPropagation();
      }
    }, true);
  }

  const params = new URLSearchParams(window.location.search);
  const isVisualOutput = params.get("visualOutput") === "1";
  window.__cyanescentUiPreviewActive = Boolean(params.get("uiPreview"));
  const previewNativeApp = window.webkit?.messageHandlers?.nativeApp;
  const reportPreviewStage = (stage, details = {}) => {
    if (!window.__cyanescentUiPreviewActive) return;
    previewNativeApp?.postMessage({ command: "uiPreviewStage", stage, details });
  };
  window.__cyanescentUiPreviewStage = reportPreviewStage;
  reportPreviewStage("diagnostic-boot-loaded");
  document.body.classList.add(isVisualOutput ? "visual-output-role" : "controller-role");

  // Bridge logging setup
  (function() {
    if (window.__cyanescentLoggingReady) return;
    const bridge = window.webkit?.messageHandlers?.nativeApp;
    if (!bridge) return;
    
    function sendLog(type, text) {
      bridge.postMessage({ command: "logConsole", type: type, text: text });
    }
    
    function formatArgs(args) {
      return Array.from(args).map(arg => {
        if (arg === null) return "null";
        if (arg === undefined) return "undefined";
        if (arg && arg.stack) return String(arg.stack);
        if (arg instanceof Error || (arg && arg.name && arg.message)) {
          return `${arg.name || 'Error'}: ${arg.message}`;
        }
        if (arg && typeof arg === 'object') {
          if (arg.message) return `${arg.name || 'DOMException'}: ${arg.message}`;
          try {
            const obj = {};
            const props = Object.getOwnPropertyNames(arg);
            for (const prop of props) {
              const val = arg[prop];
              if (typeof val === 'function') continue;
              obj[prop] = val;
            }
            const str = JSON.stringify(obj);
            return str === '{}' ? String(arg) : str;
          } catch (e) {
            return String(arg);
          }
        }
        return String(arg);
      }).join(' ');
    }

    window.addEventListener('error', (event) => {
      sendLog("error", `Uncaught Error: ${event.message} at ${event.filename}:${event.lineno}:${event.colno}`);
    });
    window.addEventListener('unhandledrejection', (event) => {
      sendLog("error", `Unhandled Rejection: ${event.reason?.stack || event.reason}`);
    });

    const originalError = console.error;
    console.error = function() {
      originalError.apply(console, arguments);
      sendLog("error", formatArgs(arguments));
    };

    const originalWarn = console.warn;
    console.warn = function() {
      originalWarn.apply(console, arguments);
      sendLog("warn", formatArgs(arguments));
    };

    window.__cyanescentLoggingReady = true;
  })();

  const chooseTrack = document.getElementById("chooseTrack");
  const importFolder = document.getElementById("importFolder");
  const audioFile = document.getElementById("audioFile");

  const fullscreen = document.getElementById("fullscreen");
  const audioStatus = document.getElementById("audioStatus");
  const audioDiagnostic = document.getElementById("audioDiagnostic");
  const splashStatus = document.getElementById("engineSplashStatus");
  const splashBar = document.getElementById("engineSplashBar");
  const splashPercent = document.getElementById("engineSplashPercent");

  window.__cyanescentFullAppReady = false;
  window.__pendingNativeTracks = [];
  window.__pendingPlayerFiles = [];
  window.__pendingFullscreenLaunch = false;
  window.__cyanescentPerfTest = new URLSearchParams(window.location.search).get("perfTest") === "1";

  let fullAppLoading = false;
  let fullAppLoaded = false;
  let fullAppTimer = 0;
  let holdFullAppUntil = 0;
  let nativeDialogOpen = false;

  function setSplashProgress(progress, status) {
    const percent = Math.round(Math.max(0, Math.min(1, progress)) * 100);
    if (splashStatus && status) splashStatus.textContent = status;
    if (splashBar) splashBar.style.width = `${percent}%`;
    if (splashPercent) splashPercent.textContent = `${percent}%`;
  }

  function nativeAppBridge() {
    return window.webkit?.messageHandlers?.nativeApp || null;
  }

  function requestFullApp(delay = 1500, urgent = false) {
    if (fullAppLoading || fullAppLoaded || window.__cyanescentFullAppReady) return;
    const targetDelay = Math.max(0, delay);
    window.clearTimeout(fullAppTimer);
    fullAppTimer = window.setTimeout(() => {
      const wait = urgent ? 0 : holdFullAppUntil - Date.now();
      if (nativeDialogOpen && !urgent) {
        requestFullApp(2000, false);
        return;
      }
      if (wait > 0) {
        requestFullApp(wait, false);
        return;
      }
      fullAppLoading = true;
      setSplashProgress(0.04, "Loading visual engine code");
      const script = document.createElement("script");
      script.type = "module";
      script.src = "app.js";
      script.async = true;
      reportPreviewStage("app-script-load-started", { src: script.src });
      script.onload = () => {
        fullAppLoaded = true;
        reportPreviewStage("app-script-loaded");
      };
      script.onerror = () => {
        fullAppLoading = false;
        fullAppLoaded = false;
        setSplashProgress(1, "Could not load the visual engine");
        if (audioStatus) audioStatus.textContent = "load error";
        if (audioDiagnostic) audioDiagnostic.textContent = "Could not load the visual engine";
        reportPreviewStage("app-script-load-failed", { src: script.src });
      };
      document.body.appendChild(script);
    }, targetDelay);
  }

  function openTrackDialog() {
    if (window.__cyanescentFullAppReady) return;
    nativeDialogOpen = true;
    holdFullAppUntil = Date.now() + 6000;
    const nativeApp = nativeAppBridge();
    if (nativeApp) {
      nativeApp.postMessage("openAudioFile");
    } else {
      nativeDialogOpen = false;
      audioFile?.click();
    }
    requestFullApp(5000);
  }

  function openFolderDialog() {
    if (window.__cyanescentFullAppReady) return;
    nativeDialogOpen = true;
    holdFullAppUntil = Date.now() + 6000;
    const nativeApp = nativeAppBridge();
    if (nativeApp) {
      nativeApp.postMessage("openAudioFolder");
    } else {
      nativeDialogOpen = false;
      audioFile?.click();
    }
    requestFullApp(5000);
  }

  function launchFullscreenEarly() {
    if (window.__cyanescentFullAppReady) return;
    window.__pendingFullscreenLaunch = true;
    if (audioStatus) audioStatus.textContent = "starting visuals";
    if (audioDiagnostic) audioDiagnostic.textContent = "Opening the visualiser window";
    requestFullApp(80, true);
  }

  function hasPendingNativeTracks() {
    const pending = window.__pendingNativeTracks;
    if (Array.isArray(pending)) return pending.length > 0;
    return Array.isArray(pending?.tracks) && pending.tracks.length > 0;
  }

  window.__nativeDialogClosed = () => {
    nativeDialogOpen = false;
    if (hasPendingNativeTracks() || window.__pendingPlayerFiles.length) {
      requestFullApp(80, true);
      return;
    }
    holdFullAppUntil = Date.now() + 500;
    requestFullApp(900);
  };

  window.__queueNativeMusicImport = (tracks, options) => {
    const pending = window.__pendingNativeTracks;
    const batches = pending?.batches || (Array.isArray(pending) && pending.length
      ? [{tracks: pending, options: {}}] : pending?.tracks?.length
        ? [{tracks: pending.tracks, options: pending.options || {}}] : []);
    batches.push({tracks, options});
    window.__pendingNativeTracks = {tracks: batches.flatMap(batch => batch.tracks), batches};
  };

  window.__loadNativeTrack = (track, options = {}) => {
    if (window.__cyanescentFullAppReady || !track?.url) return;
    nativeDialogOpen = false;
    window.__queueNativeMusicImport([track], options);
    if (audioStatus) audioStatus.textContent = "loading track";
    if (audioDiagnostic) audioDiagnostic.textContent = track.name || "Track selected";
    requestFullApp(80, true);
  };

  window.__loadNativeTracks = (tracks, options = {}) => {
    if (window.__cyanescentFullAppReady || !Array.isArray(tracks) || !tracks.length) return;
    nativeDialogOpen = false;
    window.__queueNativeMusicImport(tracks, options);
    if (audioStatus) audioStatus.textContent = "loading folder";
    if (audioDiagnostic) audioDiagnostic.textContent = `${tracks.length} tracks selected`;
    requestFullApp(80, true);
  };

  if (!isVisualOutput) {
    chooseTrack?.addEventListener("click", openTrackDialog);
    importFolder?.addEventListener("click", openFolderDialog);
    fullscreen?.addEventListener("click", launchFullscreenEarly);
    audioFile?.addEventListener("change", () => {
      if (window.__cyanescentFullAppReady) return;
      nativeDialogOpen = false;
      window.__pendingPlayerFiles = Array.from(audioFile.files || []);
      requestFullApp(80, true);
    });
  }

  setSplashProgress(0.02, "Starting visual engine");
  requestFullApp(80, true);
})();
