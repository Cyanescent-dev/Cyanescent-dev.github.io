import { mat4LookAt, mat4Multiply, mat4Perspective } from "../engine/geometry.js";
import { bindFullscreenTriangleBuffer } from "../engine/geometryBuffers.js";
import {
  fluidBackgroundSource,
  fluidVertexSource,
  fluidFragmentSource
} from "./quantumFluidShaders.js";

// Quantum Fluid Dynamics.
//
// Particles are integrated on the CPU with real state, so the field genuinely
// transports them and the large-scale structures (vortices, shear, jets,
// convergence) are produced by the motion rather than drawn on top of it. Each
// particle's recent path lives in a GPU ring buffer, which makes a trail actual
// history and costs one small buffer write per frame instead of a full-frame
// accumulation pass.

const TRAIL_LENGTH = { standard: 14, high: 24 };
const PARTICLES = { standard: 1800, high: 3800 };
const MAX_WAVES = 3;
// Two integration substeps per frame. One ring slot per rendered frame leaves a
// gap of speed * dt * pixelsPerUnit between trail points, which forces the
// points to be fat enough to bridge it and turns filaments into soft worms.
// Substepping halves the gap instead, so the points can stay small and crisp.
const SUBSTEPS = 2;

function clamp(v, lo, hi) {
  return v < lo ? lo : (v > hi ? hi : v);
}

export function createQuantumFluidGeometry(particleCount = 2600) {
  // Kept exported for compatibility: a golden-angle disc is still how the
  // simulation seeds and respawns particles.
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i += 1) {
    const t = (i + 0.5) / particleCount;
    const theta = i * 2.3999632;
    const r = 3.6 * Math.sqrt(t);
    positions[i * 3] = Math.cos(theta) * r;
    positions[i * 3 + 1] = Math.sin(theta) * r;
    positions[i * 3 + 2] = -6.0 * t;
  }
  return positions;
}

export function createQuantumFluidRenderer({
  getGl,
  getCanvas,
  getQuad,
  program,
  programFrom,
  getSmooth,
  getMusicAwareState,
  getAudioFeatures,
  getActivePresetStartedAt,
  getQuality,
  getAnalysisTimeline,
  textureAssets
} = {}) {
  let backgroundProgram = null;
  let mainProgram = null;
  let trailBuffer = null;

  let particleCount = 0;
  let trailLength = 0;
  let builtForQuality = -1;

  // Simulation state
  let posX = null;
  let posY = null;
  let posZ = null;
  let speed = null;
  let life = null;
  let lifeSpan = null;
  let slotData = null;      // one ring slot, uploaded per frame
  let currentSlot = 0;

  // Smoothed audio
  let smoothBass = 0;
  let smoothMids = 0;
  let smoothHighs = 0;
  let smoothEnergy = 0;
  let smoothKick = 0;
  let lastKickActive = false;
  let lastTime = null;

  // Emergent order: rises rarely, folds the flow into N-fold symmetry, decays.
  let orderParam = 0;
  let orderTarget = 0;
  let orderHoldUntil = 0;
  let orderCooldownUntil = 12;
  let symmetry = 6;
  let orderPhase = 0;

  // Pressure waves left by kicks
  const waveX = new Float32Array(MAX_WAVES);
  const waveY = new Float32Array(MAX_WAVES);
  const waveBorn = new Float32Array(MAX_WAVES).fill(-999);
  let nextWave = 0;

  let rngState = 0x2f6e2b1;
  function rnd() {
    rngState = (rngState * 1664525 + 1013904223) & 0xffffffff;
    return (rngState >>> 8) / 16777216;
  }

  function gl() { return getGl?.(); }
  function canvas() { return getCanvas?.(); }

  function seedParticle(i, spreadOnly) {
    const a = rnd() * Math.PI * 2;
    const r = 4.4 * Math.sqrt(rnd());
    posX[i] = Math.cos(a) * r;
    posY[i] = Math.sin(a) * r;
    if (!spreadOnly) posZ[i] = -6.0 * rnd();
    speed[i] = 0;
    lifeSpan[i] = 4.0 + rnd() * 7.0;
    life[i] = spreadOnly ? rnd() * lifeSpan[i] : 0;
  }

  function ensureResources() {
    const context = gl();
    const quality = Number(getQuality?.() || 0);
    const wantHigh = quality > 0.5;
    const wantCount = wantHigh ? PARTICLES.high : PARTICLES.standard;
    const wantTrail = wantHigh ? TRAIL_LENGTH.high : TRAIL_LENGTH.standard;

    if (!backgroundProgram) backgroundProgram = program(fluidBackgroundSource);
    if (!mainProgram) {
      mainProgram = programFrom(fluidVertexSource, fluidFragmentSource, [[0, "trail"]]);
    }

    const rebuild = !trailBuffer || particleCount !== wantCount || trailLength !== wantTrail;
    if (!rebuild) return;

    particleCount = wantCount;
    trailLength = wantTrail;
    builtForQuality = quality;

    posX = new Float32Array(particleCount);
    posY = new Float32Array(particleCount);
    posZ = new Float32Array(particleCount);
    speed = new Float32Array(particleCount);
    life = new Float32Array(particleCount);
    lifeSpan = new Float32Array(particleCount);
    slotData = new Float32Array(particleCount * 4);
    for (let i = 0; i < particleCount; i += 1) seedParticle(i, true);

    // Fill every slot with the starting state so the first frames show a
    // settled field instead of trails converging out of the origin.
    const initial = new Float32Array(particleCount * trailLength * 4);
    for (let s = 0; s < trailLength; s += 1) {
      for (let i = 0; i < particleCount; i += 1) {
        const o = (s * particleCount + i) * 4;
        initial[o] = posX[i];
        initial[o + 1] = posY[i];
        initial[o + 2] = posZ[i];
        initial[o + 3] = 0;
      }
    }
    if (trailBuffer) context.deleteBuffer(trailBuffer);
    trailBuffer = context.createBuffer();
    context.bindBuffer(context.ARRAY_BUFFER, trailBuffer);
    context.bufferData(context.ARRAY_BUFFER, initial, context.DYNAMIC_DRAW);
    currentSlot = 0;
  }

  // ---------------------------------------------------------------------------
  // The flow field.
  //
  // The turbulent part is the exact curl of an analytic stream function, so it
  // is divergence-free by construction and the fluid folds and shears instead of
  // pumping particles in and out of nothing. Derivatives are closed-form rather
  // than finite differences: cheaper and exact.
  // ---------------------------------------------------------------------------
  const flow = { vx: 0, vy: 0 };

  function evaluateFlow(x, y, t, P) {
    // Symmetry is added as a smooth angular FORCING term rather than by folding
    // coordinates into a sector. Sector folding is discontinuous at the seam:
    // the rotation jumps, particles pile into a hard radial line, and easing
    // that jump away destroys the fold it was meant to soften. sin(N*a) is
    // continuous for integer N, so this organises the fluid into N lobes with
    // no seam anywhere.
    const sx = x;
    const sy = y;

    // Curl of psi = sin(0.9x + .13t)cos(0.75y - .09t)
    //             + 0.45 sin(1.9x - 1.3y + .21t)
    //             + 0.35 cos(0.5x + 2.1y - .17t)
    const a1 = 0.90 * sx + t * 0.13;
    const b1 = 0.75 * sy - t * 0.09;
    const a2 = 1.90 * sx - 1.30 * sy + t * 0.21;
    const a3 = 0.50 * sx + 2.10 * sy - t * 0.17;

    let vx = -0.75 * Math.sin(a1) * Math.sin(b1)
             - 0.45 * 1.30 * Math.cos(a2)
             - 0.35 * 2.10 * Math.sin(a3);
    let vy = -0.90 * Math.cos(a1) * Math.cos(b1)
             + 0.45 * 1.90 * Math.cos(a2)
             + 0.35 * 0.50 * Math.sin(a3);

    // Turbulence yields while the fluid organises; otherwise the coherent
    // forcing below is simply drowned out and no structure appears.
    const turb = P.turbulence * (1.0 - P.order * 0.72);
    vx *= turb;
    vy *= turb;

    // Fine-scale detail from the top end: a second, higher-frequency curl adds
    // filament structure without disturbing the large flow.
    if (P.fine > 0.001) {
      const c1 = 3.7 * sx - 1.1 * t;
      const c2 = 4.3 * sy + 0.9 * t;
      vx += -4.3 * Math.sin(c1) * Math.sin(c2) * P.fine * 0.10;
      vy += -3.7 * Math.cos(c1) * Math.cos(c2) * P.fine * 0.10;
    }

    // Vortices, plus convergence/divergence: the large-scale structures the
    // particles reveal. Each is a real term in the velocity field.
    for (let i = 0; i < P.vortexCount; i += 1) {
      const dx = sx - P.vcx[i];
      const dy = sy - P.vcy[i];
      const r2 = dx * dx + dy * dy + 0.42;
      const s = P.vs[i] * (1.0 - P.order * 0.55);
      vx += (-dy * s) / r2;
      vy += (dx * s) / r2;
      const cvg = P.vc[i];
      vx += (dx * cvg) / r2;
      vy += (dy * cvg) / r2;
    }

    // Shear band: adjacent strips sliding past one another, which is what
    // breaks smooth flow up into eddies along the boundary.
    const shear = P.shear * (1.0 - P.order * 0.65);
    vx += Math.sin(sy * P.shearFreq + t * 0.19) * shear;
    vy += Math.cos(sx * P.shearFreq * 0.8 - t * 0.14) * shear * 0.6;

    // Jet: a stream THROUGH the fluid, finite along its axis as well as across
    // it. Unbounded along the axis it becomes a conveyor belt that carries the
    // whole population to one edge.
    if (P.jet > 0.001) {
      const along = sx * P.jetNx + sy * P.jetNy;
      const across = -sx * P.jetNy + sy * P.jetNx - P.jetOffset;
      const overrun = Math.max(0, Math.abs(along) - 1.8);
      const profile = Math.exp(-across * across * 1.6) * Math.exp(-overrun * overrun * 0.55);
      vx += P.jetNx * profile * P.jet;
      vy += P.jetNy * profile * P.jet;
    }

    // N-fold organisation: particles gather into lobes and counter-rotate
    // between them, producing a rosette that dissolves as `order` decays.
    if (P.order > 0.001) {
      const rr0 = Math.sqrt(x * x + y * y) + 1e-5;
      const ang = Math.atan2(y, x);
      const phase = P.symmetry * ang + P.orderPhase;
      const reach = Math.exp(-rr0 * rr0 * 0.030);
      const gather = Math.sin(phase) * P.order * 5.4 * reach;
      const spin = Math.cos(phase) * P.order * 3.6 * reach;
      vx += (x / rr0) * gather - (y / rr0) * spin;
      vy += (y / rr0) * gather + (x / rr0) * spin;
    }

    // Weak restoring pull. The jet and convergence terms do not cancel over
    // time, so without this the population slowly migrates off one edge.
    const rr = Math.sqrt(x * x + y * y) + 1e-5;
    if (rr > 3.1) {
      const pull = (rr - 3.1) * 0.34;
      vx -= (x / rr) * pull;
      vy -= (y / rr) * pull;
    }

    // Pressure waves. Each kick leaves an expanding ring that pushes the fluid
    // radially as it passes. Because it propagates from a point inside the
    // fluid, particles react as the front reaches them rather than the whole
    // frame pulsing at once.
    for (let w = 0; w < MAX_WAVES; w += 1) {
      const age = t - waveBorn[w];
      if (age < 0 || age > 2.2) continue;
      const dx = x - waveX[w];
      const dy = y - waveY[w];
      const rw = Math.hypot(dx, dy) + 1e-4;
      const band = rw - age * 3.4;
      const amp = Math.exp(-band * band * 3.0) * Math.exp(-age * 1.6) * P.waveStrength;
      vx += (dx / rw) * amp;
      vy += (dy / rw) * amp;
    }

    flow.vx = vx;
    flow.vy = vy;
    return flow;
  }

  function fluidMvpMatrix(now, aspect, P) {
    const seconds = now * 0.001;
    const projection = mat4Perspective((48 * Math.PI) / 180, aspect, 0.1, 100);
    // A slow drift keeps the volume feeling inhabited without ever repeating.
    const driftX = Math.sin(seconds * 0.077) * 0.30 + Math.sin(seconds * 0.031) * 0.18;
    const driftY = Math.cos(seconds * 0.063) * 0.24;
    const eye = [driftX, driftY, 7.2 - P.pushIn];
    const target = [driftX * 0.25, driftY * 0.25, -2.5];
    const view = mat4LookAt(eye, target, [0, 1, 0]);
    return mat4Multiply(projection, view);
  }

  function renderQuantumFluid3D(now, targetFbo = null, width = canvas().width, height = canvas().height, presetId = 83) {
    const context = gl();
    ensureResources();

    const seconds = now * 0.001;
    const smooth = getSmooth?.() || {};
    const audioFeatures = getAudioFeatures?.() || {};
    const music = getMusicAwareState?.() || {};
    const quality = Number(getQuality?.() || 0);

    const timelineReset = lastTime === null || now < lastTime;
    const dt = timelineReset ? 1 / 60 : Math.min(0.1, Math.max(0.001, (now - lastTime) * 0.001));
    lastTime = now;

    let bassVal = smooth.bass;
    let midsVal = smooth.mids;
    let highsVal = smooth.highs;
    let levelVal = smooth.level;
    let kickVal = smooth.kick;

    // Keep the fluid alive when nothing is playing.
    const hasAudio = bassVal > 0.001 || midsVal > 0.001 || highsVal > 0.001;
    if (!hasAudio) {
      bassVal = 0.22 + 0.14 * Math.sin(seconds * 0.9);
      midsVal = 0.18 + 0.10 * Math.cos(seconds * 0.7);
      highsVal = 0.12 + 0.08 * Math.sin(seconds * 1.3);
      levelVal = 0.20 + 0.10 * Math.sin(seconds * 0.5);
      kickVal = Math.sin(seconds * 3.1) > 0.9 ? 1.0 : 0.0;
    }

    if (timelineReset) {
      smoothBass = bassVal; smoothMids = midsVal; smoothHighs = highsVal;
      smoothEnergy = levelVal; smoothKick = kickVal;
      lastKickActive = kickVal > 0.45;
    }

    const lerp = 1.0 - Math.pow(1.0 - 0.12, dt * 60.0);
    smoothBass += (bassVal - smoothBass) * lerp;
    smoothMids += (midsVal - smoothMids) * lerp;
    smoothHighs += (highsVal - smoothHighs) * lerp;
    smoothEnergy += (levelVal - smoothEnergy) * lerp;

    // A kick strikes the fluid: it leaves a pressure wave at a point inside the
    // field rather than flashing the whole frame.
    const isKick = kickVal > 0.45;
    if (isKick && !lastKickActive) {
      const a = rnd() * Math.PI * 2;
      const r = 0.6 + rnd() * 2.4;
      waveX[nextWave] = Math.cos(a) * r;
      waveY[nextWave] = Math.sin(a) * r;
      waveBorn[nextWave] = seconds;
      nextWave = (nextWave + 1) % MAX_WAVES;
      smoothKick = 1.0;
    } else {
      const decay = 1.0 - Math.pow(1.0 - 0.14, dt * 60.0);
      smoothKick += (kickVal - smoothKick) * decay;
    }
    lastKickActive = isKick;

    // ---- Energy state -------------------------------------------------------
    // One continuous parameter rather than discrete modes, so the fluid settles
    // and builds smoothly instead of switching between looks.
    const highEnergy = Number(music.highEnergy) || 0;
    const calm = Number(music.calm) || 0;
    const breakdown = Number(music.breakdown) || 0;
    const globalEnergy = Number(audioFeatures.globalEnergy) || smoothEnergy;
    let state = clamp(globalEnergy * 0.55 + smoothEnergy * 0.30 + highEnergy * 0.35 - calm * 0.25 - breakdown * 0.20, 0, 1);

    // ---- Emergent symmetry --------------------------------------------------
    // Order rises, the flow organises into an N-fold arrangement, then decays
    // back into turbulence. This has to stay RARE to land as "did that just form
    // a pattern?" -- without the cooldown below, a per-frame roll of even 0.011
    // retriggers about every 1.5s and the fluid ends up ordered most of the
    // time, which reads as a deliberate effect rather than an emergent one.
    if (seconds > orderHoldUntil) {
      if (orderTarget > 0) {
        // Episode just ended: settle back and stay turbulent for a good while.
        orderTarget = 0;
        orderCooldownUntil = seconds + 22.0 + rnd() * 26.0;
      } else if (seconds > orderCooldownUntil) {
        const phrase = Number(music.phrasePulse) || 0;
        const chance = 0.004 + phrase * 0.012 + state * 0.006;
        if (rnd() < chance) {
          orderTarget = 0.38 + rnd() * 0.28;
          symmetry = [4, 6, 6, 8][Math.floor(rnd() * 4)];
          orderHoldUntil = seconds + 3.0 + rnd() * 3.0;
        }
      }
    }
    const orderRate = 1.0 - Math.pow(1.0 - (orderTarget > orderParam ? 0.020 : 0.010), dt * 60.0);
    orderParam += (orderTarget - orderParam) * orderRate;

    // ---- Flow parameters ----------------------------------------------------
    orderPhase += dt * 0.22;

    const P = {
      order: orderParam,
      symmetry,
      orderPhase,
      turbulence: 0.55 + smoothMids * 1.35 + state * 0.55,
      fine: smoothHighs * 1.5,
      shear: 0.16 + smoothMids * 0.85 + state * 0.30,
      shearFreq: 0.75 + smoothMids * 0.85,
      waveStrength: 2.6 + smoothBass * 3.0,
      pushIn: state * 1.5,
      vortexCount: 3,
      vcx: [0, 0, 0], vcy: [0, 0, 0], vs: [0, 0, 0], vc: [0, 0, 0],
      jet: 0, jetNx: 1, jetNy: 0, jetOffset: 0
    };

    // Vortices drift on their own slow clocks and never line up the same way.
    for (let i = 0; i < P.vortexCount; i += 1) {
      const fi = i;
      P.vcx[i] = Math.sin(seconds * (0.083 + fi * 0.021) + fi * 2.1) * (1.7 + fi * 0.55);
      P.vcy[i] = Math.cos(seconds * (0.071 + fi * 0.017) + fi * 1.7) * (1.4 + fi * 0.45);
      const swirl = (i % 2 === 0 ? 1 : -1);
      P.vs[i] = swirl * (0.85 + smoothBass * 2.6 + state * 1.1) * (0.7 + 0.3 * Math.sin(seconds * 0.13 + fi));
      // Convergence breathes in and out, so the fluid gathers then disperses.
      P.vc[i] = Math.sin(seconds * 0.11 + fi * 2.3) * (0.35 + smoothBass * 0.9);
    }

    // A jet fades in and out over a long cycle.
    const jetCycle = 0.5 + 0.5 * Math.sin(seconds * 0.047);
    P.jet = Math.max(0, jetCycle - 0.45) * (1.1 + state * 1.4);
    const jetAngle = seconds * 0.031;
    P.jetNx = Math.cos(jetAngle);
    P.jetNy = Math.sin(jetAngle);
    P.jetOffset = Math.sin(seconds * 0.053) * 1.6;

    // ---- Integrate ----------------------------------------------------------
    const speedScale = 0.55 + smoothBass * 0.85 + state * 0.75;
    const clampSpeed = 6.0;
    const subDt = dt / SUBSTEPS;

    for (let step = 0; step < SUBSTEPS; step += 1) {
      const subTime = seconds - dt + subDt * (step + 1);
      for (let i = 0; i < particleCount; i += 1) {
        // Depth parallax: further layers move more slowly.
        const depthN = clamp((posZ[i] + 6.0) / 6.0, 0, 1);
        const layer = 0.45 + depthN * 0.75;

        const v = evaluateFlow(posX[i], posY[i], subTime, P);
        let vx = v.vx * speedScale * layer;
        let vy = v.vy * speedScale * layer;

        const sp = Math.hypot(vx, vy);
        if (sp > clampSpeed) {
          const k = clampSpeed / sp;
          vx *= k; vy *= k;
        }

        posX[i] += vx * subDt;
        posY[i] += vy * subDt;
        posZ[i] += (0.12 + smoothHighs * 0.35) * subDt * (depthN > 0.5 ? -1 : 1) * 0.4;
        speed[i] = Math.min(sp, clampSpeed);

        life[i] += subDt;
        const far = posX[i] * posX[i] + posY[i] * posY[i] > 34.0;
        if (life[i] > lifeSpan[i] || far) seedParticle(i, false);
        if (posZ[i] > 0.0) posZ[i] = -6.0;
        if (posZ[i] < -6.0) posZ[i] = 0.0;
      }

      // ---- Write this substep into the ring ---------------------------------
      currentSlot = (currentSlot + 1) % trailLength;
      for (let i = 0; i < particleCount; i += 1) {
        const o = i * 4;
        slotData[o] = posX[i];
        slotData[o + 1] = posY[i];
        slotData[o + 2] = posZ[i];
        slotData[o + 3] = speed[i];
      }
      context.bindBuffer(context.ARRAY_BUFFER, trailBuffer);
      context.bufferSubData(context.ARRAY_BUFFER, currentSlot * particleCount * 16, slotData);
    }

    // ---- Draw ---------------------------------------------------------------
    context.bindFramebuffer(context.FRAMEBUFFER, targetFbo);
    context.viewport(0, 0, width, height);
    context.colorMask(true, true, true, true);
    context.clearColor(0, 0, 0, 1);
    context.clear(context.COLOR_BUFFER_BIT);

    context.disable(context.DEPTH_TEST);
    context.depthMask(false);
    context.disable(context.BLEND);

    // 1. The fluid's own field, rendered faintly as the environment.
    context.useProgram(backgroundProgram);
    bindFullscreenTriangleBuffer(context, getQuad?.());
    context.uniform2f(context.getUniformLocation(backgroundProgram, "resolution"), width, height);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "time"), seconds);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "level"), smoothEnergy);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "bass"), smoothBass);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "mids"), smoothMids);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "highs"), smoothHighs);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "u_order"), orderParam);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "u_symmetry"), symmetry);
    context.uniform4f(context.getUniformLocation(backgroundProgram, "u_vortexA"), P.vcx[0], P.vcy[0], P.vs[0], P.vc[0]);
    context.uniform4f(context.getUniformLocation(backgroundProgram, "u_vortexB"), P.vcx[1], P.vcy[1], P.vs[1], P.vc[1]);
    context.uniform4f(context.getUniformLocation(backgroundProgram, "u_vortexC"), P.vcx[2], P.vcy[2], P.vs[2], P.vc[2]);
    context.drawArrays(context.TRIANGLES, 0, 3);

    // 2. The fluid itself. Additive, so overlapping trail points accumulate into
    //    filaments instead of each point needing to be bright on its own.
    context.enable(context.BLEND);
    context.blendFunc(context.SRC_ALPHA, context.ONE);

    context.useProgram(mainProgram);
    context.bindBuffer(context.ARRAY_BUFFER, trailBuffer);
    context.enableVertexAttribArray(0);
    context.vertexAttribPointer(0, 4, context.FLOAT, false, 16, 0);
    context.disableVertexAttribArray(1);

    const aspect = Math.max(0.1, width / Math.max(1, height));
    context.uniformMatrix4fv(context.getUniformLocation(mainProgram, "u_mvp"), false, fluidMvpMatrix(now, aspect, P));
    context.uniform1f(context.getUniformLocation(mainProgram, "u_time"), seconds);
    context.uniform1i(context.getUniformLocation(mainProgram, "u_particleCount"), particleCount);
    context.uniform1i(context.getUniformLocation(mainProgram, "u_trailLength"), trailLength);
    context.uniform1i(context.getUniformLocation(mainProgram, "u_currentSlot"), currentSlot);
    // Longer filaments when the music is driving, short marks when it is calm.
    context.uniform1f(context.getUniformLocation(mainProgram, "u_trailFade"), 0.35 + state * 0.60);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_energy"), state);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_highs"), smoothHighs);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_quality"), quality);

    context.drawArrays(context.POINTS, 0, particleCount * trailLength);

    context.disable(context.BLEND);
  }

  return {
    ensureResources,
    renderQuantumFluid3D,
    // Test hook only: symmetry episodes are rare by design, so waiting for one
    // is not a practical way to verify it works.
    __forceOrder(amount, folds) {
      orderTarget = amount;
      orderParam = amount;
      symmetry = folds;
      orderHoldUntil = 1e9;
    }
  };
}
