// Quantum Fluid Dynamics.
//
// The fluid simulation is the whole visual language here. Particles are
// integrated on the CPU with real state and their recent path is kept in a GPU
// ring buffer, so a trail is genuine history rather than a frame smear. The
// background is the same flow field rendered faintly, not a separate backdrop.

export const fluidBackgroundSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform vec2 resolution;
uniform float time;
uniform float level;
uniform float bass;
uniform float mids;
uniform float highs;
uniform float u_order;        // emergent-symmetry order parameter
uniform float u_symmetry;     // fold count while ordered
uniform vec4  u_vortexA;      // xy centre, z strength, w convergence
uniform vec4  u_vortexB;
uniform vec4  u_vortexC;

// Analytic stream function. Its curl is the flow the particles ride, so the
// haze below is genuinely this fluid's own structure rather than decoration
// sitting behind it.
float streamPotential(vec2 p, float t) {
    return sin(p.x * 0.90 + t * 0.13) * cos(p.y * 0.75 - t * 0.09)
         + sin(p.x * 1.90 - p.y * 1.30 + t * 0.21) * 0.45
         + cos(p.x * 0.50 + p.y * 2.10 - t * 0.17) * 0.35;
}

void main() {
    vec2 p = (vUv * 2.0 - 1.0) * vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    p *= 3.2;

    // Fold toward N-fold symmetry exactly as the simulation does, so when the
    // fluid organises the surrounding haze organises with it.
    if (u_order > 0.001) {
        float r = length(p);
        float a = atan(p.y, p.x);
        float sector = 6.2831853 / u_symmetry;
        float af = abs(mod(a, sector) - sector * 0.5);
        p = mix(p, vec2(cos(af), sin(af)) * r, u_order);
    }

    float sp = streamPotential(p, time);

    // Vortex cores read as faint pressure wells.
    float wells = 0.0;
    vec4 vx[3];
    vx[0] = u_vortexA; vx[1] = u_vortexB; vx[2] = u_vortexC;
    for (int i = 0; i < 3; i++) {
        vec2 d = p - vx[i].xy;
        wells += abs(vx[i].z) / (dot(d, d) + 0.55);
    }

    // Near-black navy through indigo. Deliberately dim: the luminous fluid has
    // to be the only bright thing in frame.
    vec3 col = vec3(0.0035, 0.0055, 0.0130);
    col += vec3(0.0060, 0.0105, 0.0260) * smoothstep(-0.8, 1.2, sp) * (0.55 + level * 0.45);
    col += vec3(0.0130, 0.0060, 0.0290) * smoothstep(0.15, 1.30, wells) * (0.35 + bass * 0.55);
    col += vec3(0.0040, 0.0090, 0.0230) * smoothstep(0.55, 1.0, abs(sp)) * mids * 0.6;

    // Gentle vignette so the volume feels enclosed.
    float r2 = length(vUv * 2.0 - 1.0);
    col *= 1.0 - r2 * 0.30;

    outColor = vec4(max(col, 0.0), 1.0);
}
`;

export const fluidVertexSource = `#version 300 es
precision highp float;

// One vertex per (particle, trail slot). The buffer is slot-major, so
// gl_VertexID resolves directly to both indices and the trail's age comes from
// the distance back to the slot currently being written.
layout(location = 0) in vec4 trail;   // xy position, z depth, w speed

uniform mat4 u_mvp;
uniform float u_time;
uniform int u_particleCount;
uniform int u_trailLength;
uniform int u_currentSlot;
uniform float u_trailFade;    // how far back the trail stays visible
uniform float u_energy;
uniform float u_highs;
uniform float u_quality;

out vec3 vColor;
out float vAlpha;

void main() {
    int slot = gl_VertexID / u_particleCount;
    int back = u_currentSlot - slot;
    if (back < 0) back += u_trailLength;
    float ageN = float(back) / float(u_trailLength);   // 0 = head

    vec3 p = trail.xyz;
    float speed = trail.w;

    gl_Position = u_mvp * vec4(p, 1.0);

    // Trails fade back along their own history. Length is driven by energy, so
    // calm passages leave short marks and loud ones draw long filaments.
    float life = clamp(1.0 - ageN / max(u_trailFade, 0.05), 0.0, 1.0);
    life *= life;

    // Velocity is the main visual variable: fast fluid is brighter, whiter and
    // slightly larger, which is what makes the motion itself legible.
    // Typical flow speeds sit around 1-3 against a clamp of 6, so a plain
    // linear scale parks almost the whole population on the first leg of the
    // ramp and the violet/magenta/white end never gets used. The gamma expands
    // that crowded low end so ordinary fluid reads as cyan-violet and only
    // genuinely fast filaments reach the top.
    float v = pow(clamp(speed * 0.26, 0.0, 1.0), 0.75);

    vec3 deepBlue = vec3(0.12, 0.38, 0.95);
    vec3 cyan     = vec3(0.10, 0.85, 1.00);
    vec3 violet   = vec3(0.55, 0.25, 1.00);
    vec3 magenta  = vec3(1.00, 0.30, 0.85);

    vec3 col = mix(deepBlue, cyan, smoothstep(0.0, 0.22, v));
    col = mix(col, violet, smoothstep(0.26, 0.58, v) * 0.80);
    col = mix(col, magenta, smoothstep(0.55, 0.85, v) * 0.60);
    // Only the extreme tail reaches white.
    col = mix(col, vec3(1.0), smoothstep(0.88, 1.0, v) * 0.55);

    // Depth: far particles are dimmer, cooler and smaller.
    float depthN = clamp((p.z + 6.0) / 6.0, 0.0, 1.0);   // 0 far, 1 near
    col = mix(col * vec3(0.55, 0.70, 1.0), col, depthN);

    vColor = col;
    // The depth term compresses rather than reaching for zero: far particles
    // are already dimmed by the colour tint above, so scaling their alpha down
    // to 0.40 as well charged the back half of the volume for depth twice.
    vAlpha = life * (0.20 + v * 0.34) * (0.58 + depthN * 0.42);

    // Sized so consecutive slots overlap: a particle covers roughly
    // speed * dt * pixelsPerUnit between writes, and anything smaller than that
    // renders the trail as a string of beads rather than a continuous filament.
    float distScale = 1.0 / max(0.35, gl_Position.w);
    float head = 1.0 + (1.0 - ageN) * 0.8;
    // gl_PointSize is the full sprite diameter, and the halo below lights well
    // short of its edge, so the mark actually drawn is smaller than the sprite.
    // Sized for the VISIBLE mark to bridge the gap between consecutive ring
    // slots, otherwise the filament beads. Pushing this much past these values
    // is what turns the fast outer particles from dashes into fat teardrops --
    // brightness is the exposure's job, not this term's. The floor is what slow
    // particles get, and it is why calm passages used to read as empty.
    float size = (u_quality > 0.5 ? 48.0 : 40.0) * distScale * head
               * (0.68 + v * 1.2 + u_highs * 0.4);
    gl_PointSize = clamp(size, 2.0, 36.0);
}
`;

export const fluidFragmentSource = `#version 300 es
precision highp float;
in vec3 vColor;
in float vAlpha;
out vec4 outColor;

void main() {
    vec2 pc = gl_PointCoord * 2.0 - 1.0;
    float d2 = dot(pc, pc);
    if (d2 > 1.0) discard;

    // Soft gaussian core. Additive blending does the accumulation, so many
    // overlapping trail points build the luminous filaments rather than each
    // point having to be bright on its own.
    // A tight core inside a wider halo. The core keeps the filament's centre
    // defined -- without it a broad gaussian across a large point reads as a
    // soft worm -- while the halo is what spreads light into the frame between
    // filaments: there is no bloom pass anywhere in this pipeline, so this
    // per-point glow is the only thing doing that job.
    float halo = exp(-d2 * 3.0);
    float core = exp(-d2 * 20.0);

    vec3 rgb = vColor * halo * 0.58 + vColor * core * 1.55;
    // Additive output sat far below clipping, so this exposure spends headroom
    // that already existed: whole-frame mean luminance goes from roughly 3/255
    // to 13/255 on ordinary material, with under 1% of pixels blown to flat
    // white on the loudest. It is the single knob to pull back on if dense
    // vortex cores clip more than that.
    outColor = vec4(rgb * vAlpha * 1.35, 1.0);
}
`;
