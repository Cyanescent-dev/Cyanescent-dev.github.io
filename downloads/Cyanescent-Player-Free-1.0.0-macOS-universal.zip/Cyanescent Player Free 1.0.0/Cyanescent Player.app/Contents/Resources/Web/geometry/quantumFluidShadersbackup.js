export const fluidBackgroundSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;

uniform vec2 resolution;
uniform float time;
uniform float level;
uniform float bass;
uniform float mids;
uniform float highs;

uniform sampler2D presetBackground;
uniform float presetBackgroundReady;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
        mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
        u.y
    );
}

void main() {
    vec2 p = (vUv * 2.0 - 1.0) * vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    float r = length(p);
    
    // Constant slow liquid baseline swirling in the background
    float timeScale = time * 0.3;
    float n1 = noise(p * 1.2 + vec2(timeScale, -timeScale * 0.6));
    float n2 = noise(p * 1.8 - vec2(timeScale * 0.5, timeScale * 0.8));
    
    vec3 col1 = vec3(0.003, 0.006, 0.018); // Deep indigo
    vec3 col2 = vec3(0.012, 0.024, 0.048); // Cyber blue
    vec3 baseBg = mix(col1, col2, n1 * (0.6 + level * 0.4));

    // Harmonic Nebula Clouds (Driven by mids & highs)
    float nebulaNoise = noise(p * 2.5 - vec2(time * 0.1, time * 0.2)) * 0.5 + noise(p * 4.8 + vec2(time * 0.15, -time * 0.05)) * 0.25;
    vec3 nebulaCol1 = vec3(0.4, 0.0, 0.8); // Deep purple
    vec3 nebulaCol2 = vec3(0.9, 0.1, 0.5); // Electric magenta
    vec3 activeNebula = mix(nebulaCol1, nebulaCol2, mids);
    baseBg += activeNebula * smoothstep(0.3, 0.7, nebulaNoise) * (0.2 + highs * 1.5 + mids * 1.0);
    
    // Dynamic color accents
    vec3 glowColor = mix(vec3(0.0, 0.55, 0.85), vec3(0.48, 0.12, 0.72), 0.5 + 0.5 * sin(time * 0.18 + mids));
    baseBg += glowColor * n2 * 0.12 * (1.0 + bass) * smoothstep(1.8, 0.15, r);
    
    baseBg *= (1.0 - r * 0.35);

    // Composite background image if ready
    if (presetBackgroundReady > 0.5) {
        vec2 cover = vUv;
        float canvasAspect = resolution.x / max(1.0, resolution.y);
        float imageAspect = 16.0 / 9.0;
        if (canvasAspect > imageAspect) {
            cover.y = (cover.y - 0.5) * (imageAspect / canvasAspect) + 0.5;
        } else {
            cover.x = (cover.x - 0.5) * (canvasAspect / imageAspect) + 0.5;
        }
        vec3 imgBg = texture(presetBackground, clamp(cover, vec2(0.0), vec2(1.0))).rgb;
        // Vignette on the background image
        float vignette = smoothstep(1.38, 0.10, length((vUv * 2.0 - 1.0) * vec2(canvasAspect, 1.0)));
        imgBg *= (0.72 + 0.28 * vignette);

        // Blend the swirly liquid fluid colors on top of the background image
        baseBg = mix(imgBg, imgBg + baseBg * 1.5, 0.70);
    }
    
    outColor = vec4(clamp(baseBg, 0.0, 1.0), 1.0);
}
`;

export const fluidVertexSource = `#version 300 es
precision highp float;
layout(location = 0) in vec3 position; // static particle base coordinates
layout(location = 1) in vec3 offset;   // CPU dynamic offsets (used in standard mode)

uniform mat4 u_mvp;
uniform float u_time;
uniform float u_smoothBass;
uniform float u_smoothMids;
uniform float u_smoothHighs;
uniform float u_smoothKick;
uniform float u_energy;
uniform float u_quality;

out vec3 vColor;
out float vDepth;
out float vSize;

float hash3(vec3 p) {
    p = fract(p * vec3(443.897, 441.423, 437.195));
    p += dot(p, p.yzx + 19.19);
    return fract((p.x + p.y) * p.z);
}

float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(mix(hash3(i),               hash3(i + vec3(1,0,0)), u.x),
            mix(hash3(i + vec3(0,1,0)), hash3(i + vec3(1,1,0)), u.x), u.y),
        mix(mix(hash3(i + vec3(0,0,1)), hash3(i + vec3(1,0,1)), u.x),
            mix(hash3(i + vec3(0,1,1)), hash3(i + vec3(1,1,1)), u.x), u.y), u.z
    );
}

float fBm(vec3 p) {
    float v = 0.0;
    float a = 0.5;
    vec3 shift = vec3(100.0);
    for (int i = 0; i < 3; i++) {
        v += a * noise3(p);
        p = p * 2.0 + shift;
        a *= 0.5;
    }
    return v;
}

vec3 curlNoise(vec3 p) {
    const float e = 0.05;
    float dx = fBm(p + vec3(e, 0.0, 0.0)) - fBm(p - vec3(e, 0.0, 0.0));
    float dy = fBm(p + vec3(0.0, e, 0.0)) - fBm(p - vec3(0.0, e, 0.0));
    float dz = fBm(p + vec3(0.0, 0.0, e)) - fBm(p - vec3(0.0, 0.0, e));
    return normalize(vec3(dy - dz, dz - dx, dx - dy));
}

void main() {
    vec3 p = position;

    // --- BASELINE ROTATION (Elite swirling even when music is paused) ---
    float baseSpin = u_time * 0.45 + u_smoothBass * 0.65;
    float rc = cos(baseSpin);
    float rs = sin(baseSpin);
    p.xy = mat2(rc, -rs, rs, rc) * p.xy;

    if (u_quality > 0.5) {
        // --- HIGH QUALITY MODE: 3D Curl Noise Fluid ---
        float timeScale = u_time * 0.15;
        
        // Fluid vortex bending
        vec3 flowCoord = p * 0.55 + vec3(0.0, 0.0, timeScale);
        vec3 flow = curlNoise(flowCoord) * (1.5 + u_energy * 2.5);
        
        // Dynamic Kick drum expansion velocity
        flow *= (1.0 + u_smoothKick * 0.8);
        p += flow;
    } else {
        // --- STANDARD QUALITY MODE: Lite CPU offset ---
        p += offset;
    }

    // Apply Perspective projection
    gl_Position = u_mvp * vec4(p, 1.0);
    vDepth = p.z;

    // --- HIGH-CONTRAST GLOWING EMISSION PALETTE (Cyan, Violet, Gold) ---
    vec3 cyan = vec3(0.0, 0.90, 1.0);
    vec3 violet = vec3(0.75, 0.05, 1.0);
    vec3 gold = vec3(1.0, 0.80, 0.0);

    // Dynamic color morphing that cycles over time and reacts to mids/highs
    vec3 mixedColor = mix(cyan, violet, 0.4 + 0.6 * sin(u_time * 0.3 + u_smoothMids));
    mixedColor = mix(mixedColor, gold, 0.25 * (0.5 + 0.5 * sin(u_time * 1.1)) + u_smoothHighs * 0.65);
    
    // Core sparks pop on kick beats
    vColor = mix(mixedColor, vec3(1.0), min(1.0, u_smoothKick * 0.15));

    // Particle sizes scaling with highs, kicks, and camera depth
    float baseSize = u_quality > 0.5 ? 48.0 : 30.0;
    float distScale = 1.0 / max(0.05, gl_Position.w);
    vSize = baseSize * distScale * (0.75 + u_smoothHighs * 3.5 + u_smoothKick * 0.3);
    gl_PointSize = clamp(vSize, 2.0, 150.0);
}
`;

export const fluidFragmentSource = `#version 300 es
precision highp float;
in vec3 vColor;
in float vDepth;
in float vSize;
out vec4 outColor;

uniform float u_smoothKick;
uniform float u_quality;
uniform float u_time;

void main() {
    vec2 pc = gl_PointCoord * 2.0 - 1.0;
    float dist = length(pc);
    if (dist > 1.0) discard;

    // Soft glowing halo falloff
    float core = 1.0 - smoothstep(0.0, 0.12, dist);
    float halo = exp(-dist * dist * 4.0);
    
    // Alpha blending with strict minimum visibility
    float baseAlpha = halo * (0.55 + u_smoothKick * 0.65);
    float alpha = max(0.4, baseAlpha); // FORCE baseline visibility when quiet
    
    vec3 finalRGB = vColor;
    if (u_quality > 0.5) {
        // High quality bright core highlight
        finalRGB += vec3(0.9, 0.95, 1.0) * core * 0.8;
        // Moderate depth fade so background particles aren't completely choked
        alpha = mix(alpha, alpha * 0.45, smoothstep(-50.0, -10.0, vDepth));
    }

    // Force premium glow with explicit * 4.5 brightness multiplier
    outColor = vec4(finalRGB * alpha * 4.5, alpha);
}
`;

export const fluidHeroOverlaySource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;

uniform vec2 resolution;
uniform float time;
uniform float bass;
uniform float mids;
uniform float highs;
uniform float level;

// Blooming Lotus Mandala
void main() {
    vec2 p = (vUv * 2.0 - 1.0);
    p.x *= resolution.x / max(resolution.y, 1.0);

    float r = length(p);
    float a = atan(p.y, p.x);

    // Slowly rotating
    a += time * 0.1;

    // The lotus "breathes" with the bass
    float breath = 1.0 + 0.1 * sin(time * 2.0) + bass * 0.3;
    r /= breath;

    // Number of petals influenced by mids
    // Base 6 petals, add more based on mids
    float petals = 6.0 + floor(mids * 4.0) * 2.0;

    // Multiple layers of petals
    float lotusAlpha = 0.0;
    vec3 lotusColor = vec3(0.0);

    for (int i = 0; i < 4; i++) {
        float fi = float(i);
        float radiusOffset = 0.2 + fi * 0.25;
        float currentF = cos((a + fi * 0.5) * petals) * 0.5 + 0.5;
        
        // Petal sharpness driven by highs
        currentF = pow(currentF, 0.8 + highs * 1.5);

        // Soft, flowing geometric shapes (blooming lotus)
        float edge = smoothstep(radiusOffset + 0.05, radiusOffset - 0.05, r - currentF * 0.4);
        float innerEdge = smoothstep(radiusOffset - 0.08, radiusOffset + 0.02, r - currentF * 0.4);
        float ring = edge * innerEdge;

        lotusAlpha += ring;

        // Colors shifting per layer
        vec3 col = mix(vec3(0.1, 0.8, 1.0), vec3(1.0, 0.2, 0.8), fract(fi * 0.25 + time * 0.05 + mids * 0.5));
        lotusColor += col * ring * (1.0 - fi * 0.15);
    }

    // Audio-reactive bright waves pushing outwards
    float wave = fract(r * 2.5 - time * 1.5 - bass * 2.0);
    wave = smoothstep(0.8, 1.0, wave) * bass * 2.5;

    lotusColor += vec3(1.0, 0.8, 0.4) * wave * lotusAlpha;

    // Fade out towards edges
    lotusAlpha *= smoothstep(1.5, 0.3, r);

    // Keep it semi-transparent so particles show through, boosting opacity on mids/highs
    outColor = vec4(lotusColor, clamp(lotusAlpha * (0.35 + mids * 0.6 + highs * 0.4), 0.0, 1.0));
}
`;
