import { createProgramFromSources } from "../engine/shaders.js";
const vertexSource = `#version 300 es
in vec2 position;
out vec2 vUv;
void main() {
  vUv = position * 0.5 + 0.5;
  gl_Position = vec4(position, 0.0, 1.0);
}
`;
const fragmentSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_bass;
uniform float u_mids;
uniform float u_highs;
uniform float u_kick;
uniform float u_energy;
uniform float uTopLayerAlpha;
uniform float u_slowBass;
uniform float u_slowMids;
uniform float u_slowHighs;
uniform float u_quality;
uniform float u_breath;
uniform vec2 u_archScale;
uniform float u_roofOpen;
uniform float u_unfold;
uniform float u_build;
uniform float u_breakdown;
uniform float u_dropAge;
uniform float u_dropStrength;
const float TAU = 6.28318530718;
// Underlying geometric background pattern
vec3 renderBackgroundPattern(vec3 p) {
    float grid = smoothstep(0.92, 1.0, max(abs(sin(p.x * 2.5)), max(abs(sin(p.y * 2.5)), abs(sin(p.z * 2.5)))));
    vec3 col1 = vec3(0.02, 0.08, 0.18);
    vec3 col2 = vec3(0.05, 0.22, 0.35);
    vec3 basePattern = mix(col1, col2, sin(p.x + p.y + p.z + u_time) * 0.5 + 0.5);
    return mix(basePattern, vec3(0.0, 0.85, 0.75), grid * 0.25 * (1.0 + u_bass));
}
// Coral pink shell material
vec3 renderPinkShell(vec3 p, float trap, float trap2) {
    vec3 coralPink = vec3(0.95, 0.32, 0.48);
    vec3 neonViolet = vec3(0.58, 0.12, 0.88);
    vec3 gold = vec3(0.98, 0.72, 0.15);
    
    vec3 col = mix(coralPink, neonViolet, sin(trap * 2.5) * 0.5 + 0.5);
    col = mix(col, gold, cos(trap2 * 0.8) * 0.5 + 0.5);
    return col;
}
// Smooth, mirror-symmetric inverse deformation of the original architecture.
// Never move the camera, alter repetition count, or switch fractal topology.
vec3 cathedralSpace(vec3 p) {
    p.xy = (p.xy - vec2(0.0, 0.3)) * u_archScale + vec2(0.0, 0.3);
    // The vault opens above the camera, while the lower coral/floor keep
    // their grounding. This inverse warp is monotone and non-expansive:
    // dy'/dy = sy * (1 - open * (roof + (y-.3)*roof')), in [0.25, 1].
    // Together with sx <= 1 and unchanged Z, its Jacobian norm is <= 1;
    // the existing DE/step safety remains conservative under this warp.
    float roof = smoothstep(0.30, 1.45, p.y);
    p.y -= (p.y - 0.3) * roof * u_roofOpen;
    return p;
}
// Kleinian fractal distance estimator
float map(vec3 p, out vec4 oColor) {
    p = cathedralSpace(p);
    float zRepeat = 6.0;
    p.z = mod(p.z, zRepeat) - zRepeat * 0.5;
    
    p.x = abs(p.x);
    
    // Columns
    float dCol = length(p.xy - vec2(2.5, -0.5)) - 0.5;
    
    // Arched ceiling
    vec2 pArch = p.xy - vec2(0.0, 2.5);
    pArch.x = abs(pArch.x) + 0.8;
    float dArch = length(pArch) - 2.8;
    
    float dCathedral = min(dCol, dArch);
    
    // Floor
    float dFloor = p.y + 2.0;
    dCathedral = min(dCathedral, dFloor);
    
    vec3 q = p;
    float scale = 1.0;
    float orbit = 100.0;
    
    // Keep the five original folds. Slow envelopes only make small internal
    // changes: a transient must never rescale every recursive generation.
    vec3 offset = vec3(1.34 + u_slowBass * 0.030, 1.10 + u_slowMids * 0.045, 0.8);
    float minRadius = 0.30 + u_slowHighs * 0.008;
    float fixedRadius = 1.0;
    
    for (int i = 0; i < 5; i++) {
        q = abs(q) - 1.0;
        float r2 = dot(q, q);
        if (r2 < minRadius) {
            q /= minRadius;
            scale /= minRadius;
        } else if (r2 < fixedRadius) {
            q /= r2;
            scale /= r2;
        }
        q = q * 1.70 - offset;
        scale *= 1.70;
        orbit = min(orbit, length(q.xy));
    }
    
    float dFractal = (length(q) - 0.12) / abs(scale);
    
    // Small, bounded ripple gradient; Z is periodic over the exact 6-unit cell.
    // The previous 0.04 x 32 displacement could invalidate the DE step bound
    // and jumped at mod seams. Fast treble now affects light, not this field.
    float bumps = sin(p.x * 24.0 + u_time * 0.65) * sin(p.y * 24.0)
        * sin(p.z * TAU * 4.0 / 6.0) * (0.005 + u_slowMids * 0.0025);
    // Opening reveals the original relief. Reuse this field instead of
    // paying for another fold tree.
    float roof = smoothstep(0.45, 0.85, p.y);
    dFractal += bumps * (1.0 + roof * u_unfold * 0.38);

    // Mathematically carve out a clear central corridor along the Z-axis (camera path)
    // to expunge any central bouncing balls/spheres from ever appearing in the nave.
    float dTunnel = length(p.xy - vec2(0.0, 0.3)) - 1.25;
    float dFractalCarved = max(dFractal, -dTunnel);

    float dFinal = mix(dCathedral, dFractalCarved, 0.70);
    oColor = vec4(orbit, length(q.yz), scale, dFinal);
    return dFinal;
}
vec3 getNormal(vec3 p, float travel) {
    // A bounded footprint keeps remote fine folds from producing sparkly normals.
    vec2 e = vec2(max(0.0008, travel * 0.45 / max(u_resolution.y, 1.0)), 0.0);
    vec4 dummy;
    vec3 gradient = vec3(
        map(p + e.xyy, dummy) - map(p - e.xyy, dummy),
        map(p + e.yxy, dummy) - map(p - e.yxy, dummy),
        map(p + e.yyx, dummy) - map(p - e.yyx, dummy)
    );
    return gradient / max(length(gradient), 0.000001);
}
void main() {
    vec2 uv = (vUv * 2.0 - 1.0) * vec2(u_resolution.x / max(u_resolution.y, 1.0), 1.0);
    
    // Start inside fractal immediately (no intro/foggy sphere state)
    vec3 ro = vec3(0.0, 0.3 + sin(u_time * 0.3) * 0.15, u_time * 0.6);
    vec3 lookTarget = ro + vec3(sin(u_time * 0.15) * 0.25, cos(u_time * 0.1) * 0.15, 3.0);
    
    vec3 forward = normalize(lookTarget - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    float t = 0.0;
    float maxD = 35.0;
    vec4 oColor = vec4(0.0);
    float glow = 0.0;
    float coralScatter = 0.0;
    // Player quality=1 means High (Stage B had this branch reversed).
    int steps = u_quality > 0.5 ? 72 : 64;
    bool hit = false;
    
    // Reserve a convergence tail for grazing/distant rays. Most nearby
    // surfaces exit in the original budget; exhausted rays remain misses.
    for (int i = 0; i < steps + 64; i++) {
        vec3 p = ro + rd * t;
        float d = map(p, oColor);
        if (t > maxD) break;
        // Integrate over distance, not iteration count: near-misses at the
        // vanishing point must not become a bright 80-step additive hotspot.
        float proximity = exp(-max(d, 0.0) * 6.5);
        float segment = min(max(d, 0.0) * 0.78, 0.25);
        glow += proximity * segment * 0.16;
        // Coloured light immediately around nearby coral, integrated over
        // distance rather than step count. Long nave rays cannot accumulate
        // the old central whiteout. Reuse the same exponential as the haze.
        float coralZone = 1.0 - smoothstep(0.10, 0.75, p.y);
        float nearWeight = 1.0 / (1.0 + t * 0.12 + t * t * 0.018);
        coralScatter += proximity * proximity * segment * coralZone * nearWeight * 1.65;
        // Resolve the ray cone at pixel scale, rather than demanding subpixel
        // convergence from distant coral and discarding exhausted rays.
        float footprint = max(0.0012, t * 0.65 / max(u_resolution.y, 1.0));
        if (d < footprint) {
            hit = true;
            break;
        }
        t += d * 0.78;
    }
    
    vec3 col = vec3(0.0);
    if (hit) {
        vec3 p = ro + rd * t;
        vec3 n = getNormal(p, t);
        
        float trap = oColor.x;
        float trap2 = oColor.y;
        
        // Material follows the warped coordinates as the mathematical roof inhales.
        vec3 surface = cathedralSpace(p);
        vec3 geomCol = renderBackgroundPattern(surface);
        vec3 pinkCol = renderPinkShell(surface, trap, trap2);
        
        // Blend according to uTopLayerAlpha
        float ceilingMaterial = smoothstep(0.45, 0.85, surface.y);
        vec3 matCol = mix(geomCol, pinkCol, uTopLayerAlpha * (1.0 - ceilingMaterial * 0.10));
        vec3 livingTint = mix(vec3(0.92, 0.18, 0.42), vec3(0.0, 0.92, 0.85),
            0.5 + 0.5 * sin(u_time * 0.28 + u_slowMids));
        vec3 pearlTint = mix(vec3(0.68, 0.45, 1.0), vec3(0.25, 0.92, 1.0),
            0.5 + 0.5 * sin(trap * 1.6 + trap2 * 0.09 + u_time * 0.13));
        float distanceAlong = max(0.0, p.z - ro.z);
        // Waves advance into the nave. Build and breakdown are existing
        // shared musical levels; drop age is the analysed/live event envelope.
        float travel = pow(0.5 + 0.5 * cos(distanceAlong * 0.72 - u_time * 1.1), 6.0);
        float age = max(0.0, u_dropAge);
        float waveFront = exp(-pow((distanceAlong - age * 3.0) / 2.2, 2.0));
        float dropWave = u_dropStrength * (1.0 - exp(-age * 5.0)) * exp(-age * 0.22) * waveFront;

        
        vec3 lightPos = vec3(0.0, 1.2, p.z + 1.8);
        vec3 l = normalize(lightPos - p);
        float diff = max(0.0, dot(n, l));
        float spec = pow(max(0.0, dot(reflect(-l, n), -rd)), 16.0);
        
        // Local occlusion separates the roof's folded layers; one short DE
        // sample only at a surface hit; no extra march or full-screen pass.
        vec4 aoTrap;
        float ao = clamp(map(p + n * 0.055, aoTrap) / 0.055, 0.0, 1.0);
        float fill = max(0.0, dot(n, normalize(vec3(-0.6, -0.8, -0.4))));
        float roofKey = max(0.0, dot(n, normalize(vec3(-p.x * 0.22, -0.8, -0.45))));
        col = matCol * (diff * 0.72 + 0.30 + ceilingMaterial * (0.22 + roofKey * 0.36))
            * (0.80 + ao * 0.20);
        col += matCol * pearlTint * ceilingMaterial * (0.12 + fill * 0.24);
        col += mix(vec3(1.0), pearlTint, 0.28) * spec * (0.58 + u_highs * 0.24);
        // The wave exposes the original orbit-trap folds, not just lamp dots.
        float reveal = u_build * travel * 0.55 + dropWave * 1.10;
        float foldSheen = pow(0.5 + 0.5 * sin(trap * 5.0 + trap2 * 0.12), 6.0);
        col += matCol * ceilingMaterial * mix(livingTint, pearlTint, 0.60)
            * (reveal * 0.50 + foldSheen * u_unfold * (0.10 + u_highs * 0.10));
        // Wrapped coloured light and a broad iridescent rim make the shells
        // read as radiant pearl rather than opaque beads against a dark void.
        float rim = pow(clamp(1.0 - abs(dot(n, -rd)), 0.0, 1.0), 1.7);
        float coral = 1.0 - ceilingMaterial * 0.65;
        col += mix(pearlTint, livingTint, 0.62) * rim * coral
            * (0.48 + u_bass * 0.22 + u_kick * 0.42);
        col += livingTint * coral * pow(0.5 + 0.5 * dot(n, l), 2.0)
            * (0.08 + u_slowBass * 0.08);
        // One drop-launched bioluminescent wave. Its origin is reconstructed
        // at the event time on the ORIGINAL world-space camera path; neither
        // the repeated DE cell nor the current camera position anchors it.
        // The front starts 25 units ahead and travels towards the viewer.
        // Existing analysed/live drop age is absolute seconds, never frames.
        if (u_dropStrength > 0.0 && u_dropAge >= 0.0 && u_dropAge < 13.0) {
            float eventZ = (u_time - u_dropAge) * 0.6;
            float frontZ = eventZ + 25.0 - u_dropAge * 2.2;
            float along = p.z - frontZ;
            float front = smoothstep(-0.8, 0.25, along);
            float tail = exp(-max(along, 0.0) / 3.4);
            float envelope = smoothstep(0.0, 0.8, u_dropAge)
                * (1.0 - smoothstep(10.5, 13.0, u_dropAge));
            float bioWave = front * tail * envelope * u_dropStrength;
            // Reuse the orbit traps and resolved normal: folds and curved
            // pearl boundaries catch the signal, rather than a flat Z stripe.
            float ridge = pow(0.5 + 0.5 * sin(trap * 5.0 + trap2 * 0.12), 3.0);
            float facing = max(0.0, dot(n, normalize(vec3(0.25, -0.6, -0.7))));
            float structure = 0.10 + ridge * 0.75 + facing * 0.45 + rim * 0.35;
            vec3 materialHue = matCol / max(max(matCol.r, max(matCol.g, matCol.b)), 0.001);
            vec3 bioColor = mix(materialHue, livingTint, 0.62);
            vec3 bioContribution = bioColor * bioWave * structure * (0.65 + ao * 0.35) * 1.65;
            col += bioContribution;
        }
        col = mix(col, vec3(0.005, 0.008, 0.015), smoothstep(12.0, maxD, t));
        
        // Exact copy of background lighting/color at the same point
        vec3 colCathedral = geomCol * (diff * 0.75 + 0.25) + vec3(1.0) * spec * 0.4;
        colCathedral += vec3(0.35, 0.65, 0.8) * spec * u_highs * 0.16;
        colCathedral = mix(colCathedral, vec3(0.005, 0.008, 0.015), smoothstep(12.0, maxD, t));
        
        // Opacity cylinder: Blend background copy on top at 40% inside camera path corridor
        float dTunnel = length(p.xy - vec2(0.0, 0.3)) - 1.25;
        float insideTunnel = 1.0 - smoothstep(-0.3, 0.0, dTunnel);
        col = mix(col, colCathedral, 0.18 * insideTunnel);
        glow *= (1.0 - 0.40 * insideTunnel);
        glow *= uTopLayerAlpha;


    } else {
        col = vec3(0.002, 0.005, 0.012);
    }
    
    vec3 glowColor = mix(vec3(0.92, 0.18, 0.42), vec3(0.0, 0.92, 0.85), 0.5 + 0.5 * sin(u_time * 0.28 + u_slowMids));
    col += glowColor * (min(glow, 0.24) + min(coralScatter, 0.70));
    col *= (0.90 + u_energy * 0.18);
    
    vec2 centerDist = (vUv - 0.5) * 2.0;
    col *= (1.0 - dot(centerDist, centerDist) * 0.35);
    
    // A single soft shoulder preserves saturated highlights at maximum input.
    col = pow(1.0 - exp(-max(col, vec3(0.0)) * 1.55), vec3(0.85));
    
    outColor = vec4(col, 1.0);
}
`;
const KleinianCoralCathedral = {
  id: "kleinianCoralCathedral",
  displayName: "Kleinian Coral Cathedral",
  category: "Fractal",
  energyTags: ["steady", "psychedelic"],
  
  init(gl) {
    this.program = createProgramFromSources(gl, vertexSource, fragmentSource, [
      [0, "position"]
    ]);
    
    this.buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    
    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    gl.bindBuffer(gl.ARRAY_BUFFER, null);
    this.uniforms = {
      resolution: gl.getUniformLocation(this.program, "u_resolution"),
      time: gl.getUniformLocation(this.program, "u_time"),
      bass: gl.getUniformLocation(this.program, "u_bass"),
      mids: gl.getUniformLocation(this.program, "u_mids"),
      highs: gl.getUniformLocation(this.program, "u_highs"),
      kick: gl.getUniformLocation(this.program, "u_kick"),
      energy: gl.getUniformLocation(this.program, "u_energy"),
      slowBass: gl.getUniformLocation(this.program, "u_slowBass"),
      slowMids: gl.getUniformLocation(this.program, "u_slowMids"),
      slowHighs: gl.getUniformLocation(this.program, "u_slowHighs"),
      quality: gl.getUniformLocation(this.program, "u_quality"),
      breath: gl.getUniformLocation(this.program, "u_breath"),
      archScale: gl.getUniformLocation(this.program, "u_archScale"),
      roofOpen: gl.getUniformLocation(this.program, "u_roofOpen"),
      unfold: gl.getUniformLocation(this.program, "u_unfold"),
      build: gl.getUniformLocation(this.program, "u_build"),
      breakdown: gl.getUniformLocation(this.program, "u_breakdown"),
      dropAge: gl.getUniformLocation(this.program, "u_dropAge"),
      dropStrength: gl.getUniformLocation(this.program, "u_dropStrength"),
      uTopLayerAlpha: gl.getUniformLocation(this.program, "uTopLayerAlpha")
    };
    
    this.time = 0;
  },
  
  render(gl, visualTimeSeconds, audio, width = gl.drawingBufferWidth, height = gl.drawingBufferHeight, music = {}, quality = 0) {
    if (!this.program) return;

    // Absolute visual time keeps live playback, transitions, seeking, and
    // offline export deterministic regardless of the frame rate.
    const timestamp = Number(visualTimeSeconds);
    this.time = Number.isFinite(timestamp) ? Math.max(0, timestamp) : 0;
    gl.viewport(0, 0, width, height);
    
    gl.useProgram(this.program);
    gl.bindVertexArray(this.vao);
    
    const unit = (value) => Math.max(0, Math.min(1, Number(value) || 0));
    const bass = unit(audio?.bass ?? audio?.smoothBass ?? audio?.low);
    const mids = unit(audio?.mids ?? audio?.smoothMids ?? audio?.mid);
    const highs = unit(audio?.highs ?? audio?.smoothHighs ?? audio?.high);
    const kick = unit(audio?.kickPulse ?? audio?.kick ?? audio?.smoothKick);
    const energy = unit(audio?.globalEnergySlow ?? audio?.level ?? audio?.energy);
    // These are the existing shared 1.4–4.2 s envelopes, replayed by the
    // export audio timeline. No per-render history or private beat clock.
    const slowBass = unit(audio?.bassSlow);
    const slowMids = unit(audio?.midSlow);
    const slowHighs = unit(audio?.trebleSlow);
    const uTopLayerAlpha = 0.70 + energy * 0.03;
    const ease = (value) => { const x = unit(value); return x * x * (3 - 2 * x); };
    // One continuous breath per shared musical phrase. Quiet passages still
    // breathe; held energy earns a deeper inhale. No beat-driven scale changes.
    const phrase = unit(music?.phraseProgress);
    const breath = (0.5 - 0.5 * Math.cos(phrase * Math.PI * 2)) * (0.30 + energy * 0.45 + slowBass * 0.25)
      + (0.5 + 0.5 * Math.sin(this.time * 0.23)) * 0.08;
    const dropAge = Number(music?.dropAge);
    const hasDrop = Number.isFinite(dropAge) && dropAge >= 0 && dropAge < 24;
    const dropStrength = hasDrop ? unit(music?.dropLastStrength ?? music?.drop) : 0;
    const mapped = unit(music?.dropKnown) > 0.5;
    const nextIn = Number(music?.dropIn);
    const approach = mapped ? ease(music?.dropLeadIn) * unit(music?.dropNextStrength) : 0;
    // Carry the approach continuously across the exact mapped onset. The
    // larger opening follows over 3.5 s, holds, then recovers over 11 s.
    // Fade before a closely spaced next drop so an event-age reset cannot jerk.
    const nextGate = mapped && Number.isFinite(nextIn) ? ease(nextIn / 4) : 1;
    const opening = hasDrop ? ease(dropAge / 3.5) * (1 - ease((dropAge - 9) / 11))
      * dropStrength * nextGate : 0;
    const heldApproach = mapped ? Math.max(approach, hasDrop ? (1 - ease(dropAge / 4)) * dropStrength : 0) : 0;
    const unfold = unit(energy * 0.55 + slowMids * 0.15 + opening * 0.30);
    const roofOpen = Math.min(0.30, breath * 0.12 + unfold * 0.065 + opening * 0.095 + heldApproach * 0.018);

    gl.uniform2f(this.uniforms.resolution, width, height);
    gl.uniform1f(this.uniforms.time, this.time);
    gl.uniform1f(this.uniforms.bass, bass);
    gl.uniform1f(this.uniforms.mids, mids);
    gl.uniform1f(this.uniforms.highs, highs);
    gl.uniform1f(this.uniforms.kick, kick);
    gl.uniform1f(this.uniforms.energy, energy);
    gl.uniform1f(this.uniforms.slowBass, slowBass);
    gl.uniform1f(this.uniforms.slowMids, slowMids);
    gl.uniform1f(this.uniforms.slowHighs, slowHighs);
    gl.uniform1f(this.uniforms.quality, unit(quality));
    gl.uniform1f(this.uniforms.breath, breath);
    gl.uniform2f(this.uniforms.archScale, 1 - breath * 0.055 - unfold * 0.030 - opening * 0.025,
      1 - breath * 0.025 - unfold * 0.012);
    gl.uniform1f(this.uniforms.roofOpen, roofOpen);
    gl.uniform1f(this.uniforms.unfold, unfold);
    gl.uniform1f(this.uniforms.build, Math.max(unit(music?.buildUp), approach * 0.85));
    gl.uniform1f(this.uniforms.breakdown, unit(music?.breakdown));
    gl.uniform1f(this.uniforms.dropAge, hasDrop ? dropAge : 1000);
    gl.uniform1f(this.uniforms.dropStrength, dropStrength);
    gl.uniform1f(this.uniforms.uTopLayerAlpha, uTopLayerAlpha);
    
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    
    gl.bindVertexArray(null);
    gl.useProgram(null);
  },
  
  dispose(gl) {
    if (this.program) {
      gl.deleteProgram(this.program);
      this.program = null;
    }
    if (this.buffer) {
      gl.deleteBuffer(this.buffer);
      this.buffer = null;
    }
    if (this.vao) {
      gl.deleteVertexArray(this.vao);
      this.vao = null;
    }
  }
};
export default KleinianCoralCathedral;
