import { mat4LookAt, mat4Multiply, mat4Perspective } from "../engine/geometry.js";
import { bindFullscreenTriangleBuffer } from "../engine/geometryBuffers.js";
import {
  fluidBackgroundSource,
  fluidVertexSource,
  fluidFragmentSource,
  fluidHeroOverlaySource
} from "./quantumFluidShaders.js";

export function createQuantumFluidGeometry(particleCount = 1500) {
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i += 1) {
    const t = i / particleCount;
    const theta = i * 2.3999632;
    const r = 1.2 + 2.8 * Math.sqrt(t);
    const z = mixJs(-50.0, 0.5, t);
    
    positions[i * 3]     = Math.cos(theta) * r;
    positions[i * 3 + 1] = Math.sin(theta) * r;
    positions[i * 3 + 2] = z;
  }
  return positions;
}

function mixJs(a, b, f) {
  return a + f * (b - a);
}

export function createQuantumFluidRenderer({
  getGl,
  getCanvas,
  getQuad,
  program,
  programFrom,
  getSmooth,
  getMusicAwareState,
  getAudioFeatures,
  getActivePresetStartedAt,
  getQuality,
  getAnalysisTimeline,
  textureAssets
} = {}) {
  let backgroundProgram = null;
  let mainProgram = null;
  let heroOverlayProgram = null;
  let staticBuffer = null;
  let offsetBuffer = null;
  
  const particleCount = 1500;
  let staticData = null;
  let offsetData = null;

  // Smoothed audio metrics
  let smoothBass = 0;
  let smoothMids = 0;
  let smoothHighs = 0;
  let smoothKick = 0;
  let smoothEnergy = 0;

  // Kick onset detection
  let lastKickActive = false;
  let lastTime = null;

  function gl() {
    return getGl?.();
  }

  function canvas() {
    return getCanvas?.();
  }

  function ensureResources() {
    const context = gl();
    if (!backgroundProgram) backgroundProgram = program(fluidBackgroundSource);
    if (!heroOverlayProgram) heroOverlayProgram = program(fluidHeroOverlaySource);
    if (!mainProgram) {
      mainProgram = programFrom(fluidVertexSource, fluidFragmentSource, [
        [0, "position"],
        [1, "offset"]
      ]);
    }
    if (!staticBuffer) {
      staticData = createQuantumFluidGeometry(particleCount);
      staticBuffer = context.createBuffer();
      context.bindBuffer(context.ARRAY_BUFFER, staticBuffer);
      context.bufferData(context.ARRAY_BUFFER, staticData, context.STATIC_DRAW);
    }
    if (!offsetBuffer) {
      offsetData = new Float32Array(particleCount * 3);
      offsetBuffer = context.createBuffer();
      context.bindBuffer(context.ARRAY_BUFFER, offsetBuffer);
      context.bufferData(context.ARRAY_BUFFER, offsetData, context.DYNAMIC_DRAW);
    }
  }

  function fluidMvpMatrix(now, aspect) {
    const seconds = now * 0.001;
    const projection = mat4Perspective(45 * Math.PI / 180, aspect, 0.1, 100);
    
    // Slow organic camera drift looking down the vortex
    const driftX = Math.sin(seconds * 0.3) * 0.22;
    const driftY = Math.cos(seconds * 0.25) * 0.18;
    const eye = [driftX, driftY, 2.0];
    const target = [driftX * 0.3, driftY * 0.3, -100.0];
    
    const view = mat4LookAt(eye, target, [0, 1, 0]);
    return mat4Multiply(projection, view);
  }

  function renderQuantumFluid3D(now, targetFbo = null, width = canvas().width, height = canvas().height, presetId = 83) {
    const context = gl();
    ensureResources();

    const seconds = now * 0.001;
    const smooth = getSmooth?.() || {};
    const audioFeatures = getAudioFeatures?.() || {};
    const quality = getQuality?.() || 0;

    // Time-normalized smoothing keeps motion consistent at live and export FPS.
    const timelineReset = lastTime === null || now < lastTime;
    const dt = timelineReset
      ? 1 / 60
      : Math.min(0.1, Math.max(0.001, (now - lastTime) * 0.001));
    lastTime = now;

    // --- EXPLICIT DATA VERIFICATION & MOCK FALLBACKS ---
    let bassVal = smooth.bass;
    let midsVal = smooth.mids;
    let highsVal = smooth.highs;
    let levelVal = smooth.level;
    let kickVal = smooth.kick;

    // Verify if inputs are present and non-zero. If quiet or paused, run mock sine cycles
    const hasAudio = (bassVal > 0.001 || midsVal > 0.001 || highsVal > 0.001);
    if (!hasAudio) {
      bassVal = 0.25 + 0.15 * Math.sin(seconds * 2.2);
      midsVal = 0.20 + 0.12 * Math.cos(seconds * 1.8);
      highsVal = 0.15 + 0.10 * Math.sin(seconds * 3.1);
      levelVal = 0.22 + 0.12 * Math.sin(seconds * 0.85);
      kickVal = (Math.sin(seconds * 4.5) > 0.82) ? 1.0 : 0.0;
    }

    if (timelineReset) {
      smoothBass = bassVal;
      smoothMids = midsVal;
      smoothHighs = highsVal;
      smoothEnergy = levelVal;
      smoothKick = kickVal;
      lastKickActive = kickVal > 0.45;
    }

    // Match the original 0.12-at-60fps response without tying it to frame count.
    const lerpFactor = 1.0 - Math.pow(1.0 - 0.12, dt * 60.0);
    smoothBass  += (bassVal - smoothBass)   * lerpFactor;
    smoothMids  += (midsVal - smoothMids)   * lerpFactor;
    smoothHighs += (highsVal - smoothHighs) * lerpFactor;
    smoothEnergy += (levelVal - smoothEnergy) * lerpFactor;

    // --- INSTANT KICK TRANSIENT SURGE (+5.0 boost on onset) ---
    const isKick = (kickVal > 0.45);
    if (isKick && !lastKickActive) {
      smoothKick = 5.0; // Instantly spike to a high velocity/turbulence factor
    } else {
      // Exponential decay back to the baseline kick value
      const kickDecay = 1.0 - Math.pow(1.0 - 0.15, dt * 60.0);
      smoothKick += (kickVal - smoothKick) * kickDecay;
    }
    lastKickActive = isKick;

    // Standard mode CPU displacement
    if (quality < 0.5) {
      for (let i = 0; i < particleCount; i += 1) {
        const theta = (i / particleCount) * Math.PI * 2 * 12;
        const timeScale = seconds * 0.8;
        
        // Simulates 2D Simplex/Perlin noise flow field on the CPU
        const dx = Math.sin(theta + timeScale + smoothBass * 1.5) * 0.28;
        const dy = Math.cos(theta * 0.85 - timeScale + smoothMids * 1.2) * 0.28;
        const dz = Math.sin(theta * 1.45 + timeScale * 0.5) * 0.22 * (1.0 + smoothHighs);
        
        offsetData[i * 3]     = dx;
        offsetData[i * 3 + 1] = dy;
        offsetData[i * 3 + 2] = dz;
      }
      context.bindBuffer(context.ARRAY_BUFFER, offsetBuffer);
      context.bufferSubData(context.ARRAY_BUFFER, 0, offsetData);
    }

    // Bind destination framebuffer
    context.bindFramebuffer(context.FRAMEBUFFER, targetFbo);
    context.viewport(0, 0, width, height);
    context.colorMask(true, true, true, true);
    
    // In High Mode, blend frames to create trail feedback
    if (quality > 0.5 && targetFbo === null) {
      context.enable(context.BLEND);
      context.blendFunc(context.SRC_ALPHA, context.ONE_MINUS_SRC_ALPHA);
    } else {
      context.clearColor(0, 0, 0, 1);
      context.clear(context.COLOR_BUFFER_BIT);
    }

    // ── 1. RENDER BACKGROUND SHADER ──────────────────────────────────────────
    context.disable(context.DEPTH_TEST);
    context.depthMask(false);
    context.useProgram(backgroundProgram);
    bindFullscreenTriangleBuffer(context, getQuad?.());

    context.uniform2f(context.getUniformLocation(backgroundProgram, "resolution"), width, height);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "time"), seconds);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "level"), smoothEnergy);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "bass"), smoothBass);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "mids"), smoothMids);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "highs"), smoothHighs);
    context.uniform1f(context.getUniformLocation(backgroundProgram, "kickPulse"), audioFeatures.kickPulse || 0.0);

    const assets = textureAssets?.();
    const backgroundTexture = assets?.ensurePresetBackgroundTexture?.(presetId);
    const backgroundReady = assets?.presetBackgroundReady?.(presetId) || 0;
    if (backgroundTexture && backgroundReady > 0) {
      context.activeTexture(context.TEXTURE2);
      context.bindTexture(context.TEXTURE_2D, backgroundTexture);
      context.uniform1i(context.getUniformLocation(backgroundProgram, "presetBackground"), 2);
      context.uniform1f(context.getUniformLocation(backgroundProgram, "presetBackgroundReady"), backgroundReady);
    } else {
      context.uniform1f(context.getUniformLocation(backgroundProgram, "presetBackgroundReady"), 0.0);
    }

    if (quality > 0.5) {
      context.enable(context.BLEND);
      context.blendFunc(context.SRC_ALPHA, context.ONE_MINUS_SRC_ALPHA);
    }
    context.drawArrays(context.TRIANGLES, 0, 3);

    // ── 2. RENDER FLOWING VOLUMETRIC PARTICLES ──────────────────────────────
    if (quality > 0.5) {
      context.enable(context.BLEND);
      context.blendFunc(context.SRC_ALPHA, context.ONE); // Additive blending for glows
    } else {
      context.enable(context.BLEND);
      context.blendFunc(context.SRC_ALPHA, context.ONE_MINUS_SRC_ALPHA);
    }

    context.useProgram(mainProgram);

    // Bind static particle geometry
    context.bindBuffer(context.ARRAY_BUFFER, staticBuffer);
    context.enableVertexAttribArray(0);
    context.vertexAttribPointer(0, 3, context.FLOAT, false, 12, 0);

    // Bind dynamic offsets
    context.bindBuffer(context.ARRAY_BUFFER, offsetBuffer);
    context.enableVertexAttribArray(1);
    context.vertexAttribPointer(1, 3, context.FLOAT, false, 12, 0);

    const aspect = Math.max(0.1, width / Math.max(1, height));
    const mvpMatrix = fluidMvpMatrix(now, aspect);

    context.uniformMatrix4fv(context.getUniformLocation(mainProgram, "u_mvp"), false, mvpMatrix);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_time"), seconds);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_smoothBass"), smoothBass);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_smoothMids"), smoothMids);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_smoothHighs"), smoothHighs);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_smoothKick"), smoothKick);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_energy"), smoothEnergy);
    context.uniform1f(context.getUniformLocation(mainProgram, "u_quality"), Number(quality));

    context.drawArrays(context.POINTS, 0, particleCount);

    // ── 3. RENDER HERO OVERLAY (BLOOMING LOTUS) ─────────────────────────────
    context.enable(context.BLEND);
    context.blendFunc(context.SRC_ALPHA, context.ONE_MINUS_SRC_ALPHA);
    context.useProgram(heroOverlayProgram);
    bindFullscreenTriangleBuffer(context, getQuad?.());
    context.uniform2f(context.getUniformLocation(heroOverlayProgram, "resolution"), width, height);
    context.uniform1f(context.getUniformLocation(heroOverlayProgram, "time"), seconds);
    context.uniform1f(context.getUniformLocation(heroOverlayProgram, "level"), smoothEnergy);
    context.uniform1f(context.getUniformLocation(heroOverlayProgram, "bass"), smoothBass);
    context.uniform1f(context.getUniformLocation(heroOverlayProgram, "mids"), smoothMids);
    context.uniform1f(context.getUniformLocation(heroOverlayProgram, "highs"), smoothHighs);
    context.drawArrays(context.TRIANGLES, 0, 3);

    context.disable(context.BLEND);
  }

  return {
    ensureResources,
    renderQuantumFluid3D
  };
}
