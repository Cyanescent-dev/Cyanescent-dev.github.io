import { bindFullscreenTriangleBuffer } from "../engine/geometryBuffers.js";
import KleinianCoralCathedral from "./kleinianCoralCathedral.js";

export function createSpecialGeometryRenderer({
  getGl,
  getCanvas,
  getQuad,
  program,
  programFrom,
  getSmooth,
  getAudioFeatures,
  getMusicAwareState,
  getQuality,
} = {}) {
  let kleinianCoralCathedralInitialized = false;
  let previousFrameWasPine3D = false;

  function gl() {
    return getGl?.();
  }

  function canvas() {
    return getCanvas?.();
  }

  function ensurePineResources() {
  }

  function ensureFernGeometryResources() {
  }

  function ensureKleinianCoralCathedralResources() {
    if (kleinianCoralCathedralInitialized) return;
    KleinianCoralCathedral.init(gl());
    kleinianCoralCathedralInitialized = true;
  }

  function ensureBloodCellNebulaResources() {
  }

  function setAttribs(programToUse) {
    const context = gl();
    context.useProgram(programToUse);
    bindFullscreenTriangleBuffer(context, getQuad?.());
  }

  function renderFiddleheadGeometry(now, targetFbo = null, width = canvas().width, height = canvas().height) {
  }

  function renderPinecone3D(now, targetFbo = null, width = canvas().width, height = canvas().height, presetId = 0) {
  }

  function renderKleinianCoralCathedral(
    now,
    targetFbo = null,
    width = canvas().width,
    height = canvas().height
  ) {
    const context = gl();
    ensureKleinianCoralCathedralResources();
    const previousFramebuffer = context.getParameter(context.FRAMEBUFFER_BINDING);
    context.bindFramebuffer(context.FRAMEBUFFER, targetFbo);
    context.viewport(0, 0, width, height);
    context.disable(context.DEPTH_TEST);
    context.depthMask(false);
    context.colorMask(true, true, true, true);
    KleinianCoralCathedral.render(context, now * 0.001,
      { ...getSmooth?.(), ...getAudioFeatures?.() }, width, height,
      getMusicAwareState?.() || {}, getQuality?.() || 0);
    context.bindFramebuffer(context.FRAMEBUFFER, previousFramebuffer);
    previousFrameWasPine3D = (targetFbo === null);
  }

  function renderBloodCellNebula(
    now,
    targetFbo = null,
    width = canvas().width,
    height = canvas().height
  ) {
  }

  return {
    ensurePineResources,
    ensureFernGeometryResources,
    ensureKleinianCoralCathedralResources,
    ensureBloodCellNebulaResources,
    renderFiddleheadGeometry,
    renderPinecone3D,
    renderKleinianCoralCathedral,
    renderBloodCellNebula,
    getPreviousFrameWasPine3D: () => previousFrameWasPine3D,
    setPreviousFrameWasPine3D: (value) => { previousFrameWasPine3D = value; }
  };
}
