import { adaptiveTransitionTimingRange, adaptiveTransitionProtectionShift } from './adaptiveTransitionManager.js';
import { chooseAdaptivePreset, transitionStyleForMusicalEvent } from './adaptiveTransitions.js';
import { createDiversityCycle } from './diversityCycle.js';
import { MusicalEventType as Event, VisualTransitionMode } from './transitions.js';

const number = value => Number.isFinite(Number(value)) ? Number(value) : 0;

// These are observations of the present, never fabricated lookahead features.
export function liveAdaptiveEvent(input = {}) {
  const music = input.music || {}, structure = input.structure || {}, features = input.features || {};
  const strength = key => Math.max(number(music[key]), number(structure[key]));
  const drop = Math.max(strength('drop'), number(features.dropDetected));
  const hasBaseline = Number.isFinite(structure.energyNow) && Number.isFinite(structure.energyBaseline);
  // The fast drop detector can retrigger on ordinary kicks. Require an
  // observed energy rise or confirmed structural novelty before calling it a
  // section-level drop; retain those kicks in the existing visual features.
  const dropCorroborated = !hasBaseline || structure.energyNow - structure.energyBaseline > 0.12
    || number(structure.sectionChange) > 0.35;
  if (drop >= 0.58 && dropCorroborated) return { type: Event.DROP, confidence: drop };
  const roles = [
    [Event.BREAKDOWN, strength('breakdown')], [Event.BUILD_UP, strength('buildUp')],
    [Event.HIGH_ENERGY, strength('highEnergy')],
    [Event.CALM_SECTION, Math.max(strength('calm'), hasBaseline && structure.energyNow < 0.16 ? 0.65 : 0)]
  ].sort((a, b) => b[1] - a[1]);
  if (roles[0][1] >= 0.55) return { type: roles[0][0], confidence: roles[0][1] };
  return { type: Event.SECTION_CHANGE, confidence: strength('sectionChange') };
}

// Align the *landing* to a trusted live phrase, or just a beat when only tempo
// is known. A locked beat grid alone does not establish a musical bar/phrase.
export function liveAdaptiveLanding({ now, earliest, latest, tempo = {}, structure = {} }) {
  if (!tempo.locked || number(tempo.confidence) < 0.45 || !(tempo.bpm > 0)) return null;
  const duration = 60 / tempo.bpm;
  const phrase = structure.phraseLocked && number(structure.phraseConfidence) >= 0.3;
  const anchor = number(tempo.phaseAnchorMs) / 1000
    + (phrase ? number(structure.phraseOffsetBeats) * duration : 0);
  const candidates = [];
  for (const beats of phrase ? [8, 16, 32] : [1]) {
    const period = duration * beats;
    const boundary = anchor + Math.ceil((now / 1000 + earliest - anchor - 1e-8) / period) * period;
    const delay = boundary - now / 1000;
    if (delay >= earliest - 1e-6 && delay <= latest + 1e-6) {
      candidates.push({ delay, beats, score: delay - (beats === 32 ? 2 : beats === 16 ? 0.75 : 0) });
    }
  }
  candidates.sort((a, b) => a.score - b.score);
  return candidates[0] || null;
}

/** Live-input sibling of the timeline manager. It owns an audible-session
 * clock; the paused HTML player's clock is deliberately never consulted. */
export class LiveAdaptiveTransitionManager {
  constructor(deps = {}) {
    this.deps = deps;
    this.diversity = createDiversityCycle();
    this.reset();
  }

  reset() {
    this.lastNow = null;
    this.source = null;
    this.clock = 0;
    this.presetStart = 0;
    this.activation = null;
    this.pending = null;
    this.audibleUntil = -Infinity;
    this.wasAudible = false;
    this.resumeAt = 0;
    this.role = null;
    this.roleSince = 0;
    this.lastDecisionType = null;
    this.status = { enabled: false, phase: 'inactive' };
  }

  invalidate() { this.pending = null; }

  record(preset) {
    this.diversity.record(preset, this.deps.eligiblePresetIds?.() || []);
    this.pending = null;
    this.presetStart = this.clock;
  }

  plan(now, input, event, forced, exactRemaining = null) {
    const ids = (this.deps.eligiblePresetIds?.() || []).map(Number);
    const active = this.deps.activePreset?.();
    if (!ids.some(id => id !== active)) return;
    const eligible = new Set(ids);
    const metadata = (this.deps.presetMetadata?.() || []).filter(item => eligible.has(item.id));
    const target = chooseAdaptivePreset({ event, activePreset: active, presetMetadata: metadata,
      presetMetadataById: this.deps.presetMetadataById?.() || new Map(),
      candidatePresetIds: this.diversity.candidates(ids, { activeId: active }),
      recentPresets: this.diversity.recentIds().map(Number), currentTime: this.clock });
    if (target == null || target === active) return;
    const style = transitionStyleForMusicalEvent(event.type);
    const timing = this.deps.transitionTiming?.({ from: active, to: target, source: 'adaptive', style }) || {};
    const lead = Math.max(0.1, number(timing.duration ?? 2600) * number(timing.swapAt ?? 0.48) / 1000);
    const minimum = Math.max(0, number(this.deps.minimumPlaySeconds?.(active)));
    const age = Math.max(0, number(this.deps.activePresetAgeSeconds?.()));
    const range = adaptiveTransitionTimingRange(this.deps.timingPreset?.());
    const shift = adaptiveTransitionProtectionShift(minimum);
    const elapsed = this.clock - this.presetStart;
    const earliest = Math.max(lead + 0.35, range.min + shift - elapsed, minimum - age + lead);
    const latest = Math.max(earliest, range.max + shift - elapsed);
    let delay, beats = null;
    if (exactRemaining != null) {
      delay = Math.max(lead + 0.35, exactRemaining, minimum - age + lead);
    } else {
      const aligned = liveAdaptiveLanding({ now, earliest, latest,
        tempo: input.tempo, structure: input.structure });
      // A steady role without a trusted phrase/beat is allowed one response;
      // afterwards the deadline, rather than repeating a classifier, drives it.
      if (!forced && !aligned && event.type === this.lastDecisionType) return;
      delay = aligned?.delay ?? (forced ? latest : earliest);
      beats = aligned?.beats ?? null;
    }
    this.pending = { target, style, timing, event, beats, startAt: this.clock + delay - lead,
      landingAt: this.clock + delay };
    this.deps.onPendingPreset?.(target, this.pending);
  }

  update(now, input = {}, blocked = false) {
    if (!input.active || this.deps.transitionMode?.() !== VisualTransitionMode.ADAPTIVE) {
      this.reset();
      return;
    }
    if (this.source !== input.source || (this.lastNow != null && now < this.lastNow)) {
      this.reset();
      this.source = input.source;
    }
    const delta = this.lastNow == null ? 0 : Math.max(0, Math.min(1, (now - this.lastNow) / 1000));
    this.lastNow = now;
    const activation = `${this.deps.activePreset?.()}:${this.deps.activePresetStartedAt?.()}`;
    if (activation !== this.activation) {
      this.activation = activation;
      this.record(this.deps.activePreset?.());
      this.lastDecisionType = null;
    }
    // Tail bridges ordinary gaps between beats; sustained silence pauses the
    // session clock and cancels queued changes. A click alone cannot resume one.
    if (number(input.bands?.level) > 0.008) this.audibleUntil = now + 1500;
    const audible = now < this.audibleUntil;
    if (audible) this.clock += delta;
    if (audible && !this.wasAudible) this.resumeAt = this.clock + 1.5;
    this.wasAudible = audible;
    this.status = { enabled: true, audible, phase: audible ? 'listening' : 'silence',
      bpm: input.tempo?.locked ? input.tempo.bpm : 0, phraseLocked: Boolean(input.structure?.phraseLocked) };
    if (!audible || blocked || this.clock < this.resumeAt) {
      this.pending = null;
      return;
    }
    const event = liveAdaptiveEvent(input);
    if (event.type !== this.role || event.confidence < 0.55) { this.role = event.type; this.roleSince = this.clock; }
    const stable = event.confidence >= 0.55 && (event.type === Event.DROP || (event.type === Event.SECTION_CHANGE && event.confidence >= 0.58) || this.clock - this.roleSince >= 0.8);
    const active = this.deps.activePreset?.();
    const minimum = Math.max(0, number(this.deps.minimumPlaySeconds?.(active)));
    const exact = Math.max(0, number(this.deps.exactPlaySeconds?.(active)));
    const range = adaptiveTransitionTimingRange(this.deps.timingPreset?.());
    const elapsed = this.clock - this.presetStart;
    const age = Math.max(0, number(this.deps.activePresetAgeSeconds?.()));
    const shift = adaptiveTransitionProtectionShift(minimum);
    const fallback = elapsed >= range.max + shift - 12;
    // Do not queue events detected during the protected part of a preset.
    if (!this.pending && age >= minimum && (exact > 0 || fallback || (stable && elapsed >= range.min + shift - 12))) {
      this.plan(now, input, event, fallback, exact > 0 ? Math.max(0, exact - age) : null);
    }
    if (!this.pending) return;
    // A real structural change can replace a queued target; never replace on
    // each beat or let a fading event move an already chosen deadline.
    if (stable && event.type !== this.pending.event.type && event.type !== Event.SECTION_CHANGE) {
      this.pending = null;
      this.plan(now, input, event, fallback, exact > 0 ? Math.max(0, exact - age) : null);
    }
    if (!this.pending) return;
    const p = this.pending;
    this.status = { ...this.status, phase: 'scheduled', event: p.event.type,
      beats: p.beats, secondsUntilTransition: Math.max(0, p.startAt - this.clock) };
    if (this.clock + 1e-6 < p.startAt || age < minimum) return;
    // A playlist edit can invalidate a prefetched target.
    if (!(this.deps.eligiblePresetIds?.() || []).map(Number).includes(p.target)) { this.pending = null; return; }
    this.pending = null;
    if (this.deps.begin?.(p.target, p.style, p.timing)) {
      this.lastDecisionType = p.event.type;
      this.presetStart = this.clock;
      this.status = { ...this.status, phase: 'transitioning' };
    }
  }
}
