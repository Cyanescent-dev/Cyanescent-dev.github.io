import { createPresetShaderModuleController } from "../presets/shaderRegistry.js";
import { nativeAppBridge } from "../utils/nativeBridge.js";

export function createPresetShaderRuntime({
  registry,
  compileProgram,
  warmupDrawCall,
  isPlaybackActive,
  isLiveRenderLoopRunning,
  renderMode,
  offlineRenderMode,
  getLastUserInteractionAt,
  shellProgram,
  fullProgram,
  fullShaderReady,
  setShellActive,
  setErrorText,
  setStatus,
  setDiagnostic,
  getDiagnosticText,
  logError = console.error
}) {
  let controller = null;
  const reportedModuleStates = new Set();

  function logNativeModuleError(text) {
    try {
      nativeAppBridge()?.postMessage({ command: "logConsole", type: "error", text });
    } catch (error) {
      console.error(error);
    }
  }

  function manager() {
    if (!controller) {
      controller = createPresetShaderModuleController({
        registry,
        compileModule: (module) => {
          const compiled = compileProgram(module.source);
          const presentationSource = module.presentationSources?.[module.qualityVariant === "high" ? "high" : "standard"];
          if (presentationSource) compiled.presentationProgram = compileProgram(presentationSource);
          const variant = module.qualityVariant === "high" ? "high" : "standard";
          const densitySource = module.presentationDensitySources?.[variant];
          if (densitySource && compiled.presentationProgram) {
            compiled.presentationProgram.densityProgram = compileProgram(densitySource);
            compiled.presentationProgram.densityIntervalMs = module.presentationDensityIntervalMs?.[variant] || 0;
          }
          if (!isPlaybackActive?.() && !isLiveRenderLoopRunning?.()) {
            warmupDrawCall(compiled);
          }
          return compiled;
        },
        shouldDeferCompile: () => renderMode?.() !== offlineRenderMode && (
          isPlaybackActive?.() ||
          isLiveRenderLoopRunning?.() ||
          performance.now() - getLastUserInteractionAt() < 900
        ),
        isActive: isPlaybackActive,
        shellProgram,
        fullProgram,
        fullShaderReady,
        onShellActive: setShellActive,
        onModuleReady: (_moduleId, module) => {
          reportedModuleStates.delete(`${module.name}:not-ready`);
          reportedModuleStates.delete(`${module.name}:error`);
          const diagnostic = getDiagnosticText?.() || "";
          if (diagnostic.includes("fallback") || diagnostic.includes("shader")) {
            setDiagnostic?.(`${module.name} visual module ready`);
          }
        },
        onModuleError: (_moduleId, module, message) => {
          const errorText = `${module.name}: ${message}`;
          setErrorText?.(errorText);
          logError(errorText);
          logNativeModuleError(`[PresetModuleError] ${errorText}`);
          setStatus?.("visual fallback");
          setDiagnostic?.(`Preset module failed: ${errorText}`);
        },
        onModuleUnavailable: (_moduleId, module, reason, message) => {
          const moduleName = module?.name || `Preset ${_moduleId}`;
          const key = `${moduleName}:${reason}`;
          if (reportedModuleStates.has(key)) return;
          reportedModuleStates.add(key);
          if (reason === "error") {
            const errorText = `${moduleName}: ${message || "preset module compile failed"}`;
            setErrorText?.(errorText);
            logNativeModuleError(`[PresetModuleUnavailable] ${errorText}`);
            setDiagnostic?.(`Preset module unavailable: ${errorText}`);
            return;
          }
          const waitingText = `${moduleName}: visual module not ready; using fallback while queued`;
          logNativeModuleError(`[PresetModuleDeferred] ${waitingText}`);
          setDiagnostic?.(waitingText);
        }
      });
    }
    return controller;
  }

  return {
    manager,
    moduleIdForPreset: (presetValue) => manager().moduleIdForPreset(presetValue),
    queuePrime: (presetValue, delay = 1200, qualityValue = 0) => manager().queuePrime(presetValue, delay, qualityValue),
    ensure: (presetValue, options = {}, qualityValue = 0) => manager().ensure(presetValue, options, qualityValue),
    renderProgramForPreset: (presetValue, qualityValue = 0) => manager().renderProgramForPreset(presetValue, qualityValue),
    diagnosticState: (presetValue, qualityValue = 0) => manager().diagnosticState(presetValue, qualityValue),
    prime: (presetValue, delay = 0, qualityValue = 0) => manager().prime(presetValue, delay, qualityValue),
    warm: async (options = {}, onProgress = null) => await manager().warm(options, onProgress)
  };
}
