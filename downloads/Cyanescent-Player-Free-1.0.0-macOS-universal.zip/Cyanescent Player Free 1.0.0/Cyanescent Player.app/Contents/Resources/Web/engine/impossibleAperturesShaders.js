// Shadow Geometry: Impossible Apertures — GLSL (preset 397).
//
// One fullscreen pass renders the station the camera is in and the next one along the journey.
// Every station is a sculpture inside a translucent pearl membrane (a sphere with an entry and an
// exit aperture on the journey axis). The membrane's inner wall receives the sculpture's shadows;
// seen from outside, the same light glows through it.
//
// Shadows are evaluated analytically wherever the geometry allows:
//   orrery   the shells are spheres, so a shadow ray crosses each shell at points found in closed
//            form; transmission is the aperture mask there, with a penumbra from the light's size
//   lattice  the sculpture is the intersection of two cones (apex V and apex L*); from L* a ray is
//            blocked exactly when it lies in pattern B's cone, so the shadow is pattern B itself
//   weave    a short bounded march of the ribbon field (soft shadows)
// Light shafts in the haze use the same visibility functions.

import { IRIS_STRUT_START } from "./impossibleAperturesJourney.js";

export const STATION_PARAMS = 8;   // vec4 parameters per station slot
export const STATION_LIGHTS = 4;   // lights per station slot
export const PATTERN_EXTENT = 1.15; // pattern textures span [-extent, extent] (rim radius 1)
export const PATTERN_SEGMENTS = 160;

export const iaPatternSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform vec4 uSeg[${PATTERN_SEGMENTS}];   // segment endpoints in pattern units (rim radius 1)
uniform int uCount;
uniform vec4 uRings;        // circle radii (0 = unused)
uniform float uNode;        // node disc radius (0 = none)
uniform float uExtent;      // the texture spans [-uExtent, uExtent]
float seg(vec2 p, vec2 a, vec2 b) {
  vec2 pa = p - a, ba = b - a;
  float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-8), 0.0, 1.0);
  return length(pa - ba * h);
}
void main() {
  vec2 p = (vUv * 2.0 - 1.0) * uExtent;
  float d = 1e9;
  for (int i = 0; i < ${PATTERN_SEGMENTS}; i++) {
    if (i >= uCount) break;
    d = min(d, seg(p, uSeg[i].xy, uSeg[i].zw));
    // Nodes: discs at the vertices read as joints where rods meet.
    if (uNode > 0.0) d = min(d, min(length(p - uSeg[i].xy), length(p - uSeg[i].zw)) - uNode);
  }
  float r = length(p);
  for (int i = 0; i < 4; i++) if (uRings[i] > 0.0) d = min(d, abs(r - uRings[i]));
  outColor = vec4(d, 0.0, 0.0, 1.0);
}`;

export const iaSceneSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;

uniform vec2 uRes;
uniform float uTime;
uniform int uQuality;
uniform vec3 uCamPos;
uniform vec3 uCamFwd;
uniform vec3 uCamRight;
uniform vec3 uCamUp;
uniform float uFocal;

uniform vec4 uSt[2];        // xyz centre, w type (0 orrery, 1 weave, 2 lattice, -1 none)
uniform vec4 uStB[2];       // x presence, y membrane radius, z cos(aperture half-angle), w membrane gain
uniform mat3 uStRot[2];     // world -> sculpture frame
uniform vec4 uStP[16];      // 8 parameters per station
uniform vec4 uStCol[8];     // 4 material colours per station: surface, sheen, edge, membrane
uniform vec4 uLight[8];     // 4 per station: xyz position, w radius
uniform vec4 uLightC[8];    // rgb colour * intensity, w unused

uniform vec4 uMusic;        // x kick pulse, y bass, z highs, w energy
uniform vec4 uGrade;        // x exposure, y haze density, z flash, w saturation
uniform vec4 uGrade2;       // x vignette, y membrane detail, z glints, w edge glow

uniform sampler2D uPatA;
uniform sampler2D uPatB;
uniform vec3 uLatC;         // lattice centre
uniform vec4 uLatV;         // apex V, w distance V..centre
uniform vec4 uLatL;         // apex L*, w distance L*..centre
uniform mat3 uLatMA;        // world -> cone A frame (z towards the centre)
uniform mat3 uLatMB;
uniform vec4 uLatP;         // x pattern radius at the centre, y stroke A, z stroke B, w bound radius
uniform vec4 uLatK;         // x kick ring radius (pattern units), y kick strength, z alignment glow, w texture extent

const float PI = 3.14159265;
const float TAU = 6.28318531;
const float IRIS_STRUT_START = ${IRIS_STRUT_START.toFixed(3)};

float sdBox2(vec2 p, vec2 b) { vec2 d = abs(p) - b; return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0); }
mat2 rot2(float a) { float c = cos(a), s = sin(a); return mat2(c, s, -s, c); }
float atanh1(float x) { return 0.5 * log((1.0 + x) / (1.0 - x)); }
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }

// ------------------------------------------------------------------------------------------------
// Orrery: two nested perforated spherical shells. Apertures are a lattice in Mercator coordinates
// w = (atanh z, atan(y, x)) = log of the stereographic coordinate, so they follow loxodromes from
// pole to pole and shrink by sech(u) towards the poles: a Doyle-like spiral on the sphere.
// Parameters (base b = slot * 8):
//   P0 R_out, th_out, R_in, th_in      P1/P2 lattice K, row step, row twist, hole fraction
//   P3 flow u / spin v (outer, inner)  P4 polar fade |u|, iris half-angle, core radius, kick u
//   P5 kick strength, -, -, -
// ------------------------------------------------------------------------------------------------
float orEmpty(vec3 d, float r, vec4 L, vec2 flow, vec2 poles) {
  float z = clamp(d.z, -0.99995, 0.99995);
  float u = atanh1(z);
  float v = atan(d.y, d.x);
  float sp = TAU / L.x;
  float fade = smoothstep(poles.x, poles.x - 0.9, abs(u));
  float hole = sp * (0.5 * L.w * fade - 0.08 * (1.0 - fade));
  vec2 w = vec2(u - flow.x, v - flow.y);
  float i0 = floor(w.x / L.y + 0.5);
  float best = 1e9;
  for (int k = -1; k <= 1; k++) {
    float i = i0 + float(k);
    float du = w.x - i * L.y;
    float vv = w.y - i * L.z;
    float dv = vv - sp * floor(vv / sp + 0.5);
    best = min(best, du * du + dv * dv);
  }
  float dw = (sqrt(best) - hole) * r / cosh(u);
  // Polar irises. When open, nine radial struts survive beyond IRIS_STRUT_START from the pole (the
  // camera flies through well inside it), so the polar beam projects a starburst, not a blank disc.
  float ang = acos(abs(z));
  float iris = (ang - poles.y) * r;
  float strut = abs(fract((v - flow.y) * 9.0 / TAU + 0.5) - 0.5) * (TAU / 9.0) * sin(ang) * r - 0.07 - 0.09 * r * (ang - IRIS_STRUT_START);
  iris = max(iris, -max(strut, (IRIS_STRUT_START - ang) * r));
  return min(dw, iris);
}

// x distance, y material (1 outer shell, 2 inner shell, 3 core)
vec2 orMap(vec3 q, int b) {
  vec4 P0 = uStP[b], P3 = uStP[b + 3], P4 = uStP[b + 4];
  float r = length(q);
  vec3 d = q / max(r, 1e-4);
  vec2 res = vec2(r - P4.z, 3.0);
  float b1 = abs(r - P0.x) - P0.y;
  if (b1 < res.x) {
    float s1 = max(b1, -orEmpty(d, r, uStP[b + 1], P3.xy, P4.xy));
    if (s1 < res.x) res = vec2(s1, 1.0);
  }
  float b2 = abs(r - P0.z) - P0.w;
  if (b2 < res.x) {
    float s2 = max(b2, -orEmpty(d, r, uStP[b + 2], P3.zw, P4.xy));
    if (s2 < res.x) res = vec2(s2, 2.0);
  }
  return res;
}

float orEmptyShell(vec3 x, int b, int shell) {
  vec4 P3 = uStP[b + 3], P4 = uStP[b + 4];
  vec3 d = normalize(x);
  if (shell == 0) return orEmpty(d, uStP[b].x, uStP[b + 1], P3.xy, P4.xy);
  return orEmpty(d, uStP[b].z, uStP[b + 2], P3.zw, P4.xy);
}

// Segment a -> l (local frame) through both shells. Seen from the receiver a, the light's disc
// (radius lightR at distance len) spans lightR * t / len at the crossing t: the penumbra half-width.
// Each colour channel's edge sits at a slightly different place inside the penumbra, so projected
// apertures carry thin spectral fringes (one mask evaluation per crossing).
vec3 orTrans(vec3 a, vec3 l, int b, float lightR, float minSoft) {
  vec3 dir = l - a;
  float len = length(dir);
  dir /= len;
  vec3 T = vec3(1.0);
  const vec3 disperse = vec3(-0.45, 0.0, 0.45);
  for (int shell = 0; shell < 2; shell++) {
    float R = shell == 0 ? uStP[b].x : uStP[b].z;
    float B = dot(a, dir), C = dot(a, a) - R * R, H = B * B - C;
    if (H <= 0.0) continue;
    H = sqrt(H);
    float t0 = -B - H, t1 = -B + H;
    if (t0 > 0.0 && t0 < len) {
      float soft = minSoft + lightR * t0 / len;
      T *= 1.0 - smoothstep(-soft, soft, orEmptyShell(a + dir * t0, b, shell) + disperse * soft);
    }
    if (t1 > 0.0 && t1 < len) {
      float soft = minSoft + lightR * t1 / len;
      T *= 1.0 - smoothstep(-soft, soft, orEmptyShell(a + dir * t1, b, shell) + disperse * soft);
    }
    if (max(T.r, max(T.g, T.b)) < 0.002) break;
  }
  return T;
}

// ------------------------------------------------------------------------------------------------
// Weave: two coaxial tori (common core radius R, tube radii r1 < r2), each woven from N ribbons
// that follow the (1, k) curves theta = k phi + c. The tori wind in opposite senses, so every
// ribbon links every ribbon of the other torus. Ribbons are flat bands lying in the torus that can
// turn about their centre line like louvres.
//   P0 R, r1, r2, thickness   P1/P2 N, k, phase, width fraction   P3 louvre 1, louvre 2, kick phi, kick strength
// ------------------------------------------------------------------------------------------------
float wvTorus(vec3 q, float R, float r, vec4 F, float louver, float thick) {
  float rho = length(q.xy);
  float phi = atan(q.y, q.x);
  vec2 ab = vec2(rho - R, q.z);
  float rr = length(ab);
  float th = atan(ab.y, ab.x);
  float sp = TAU / F.x;
  float s = th - F.y * phi - F.z;
  float sl = s - sp * floor(s / sp + 0.5);
  float g = sqrt(1.0 / (rr * rr + 1e-3) + F.y * F.y / (rho * rho + 1e-3));
  float halfGap = 0.5 * sp / g;
  vec2 c = rot2(louver) * vec2(sl / g, rr - r);
  return sdBox2(c, vec2(F.w * halfGap, thick)) - 0.02;
}

// Position across the nearest ribbon, 0 on its centre line and 1 at its edge (for edge light).
float wvAcross(vec3 q, float R, float r, vec4 F) {
  float rho = length(q.xy);
  float phi = atan(q.y, q.x);
  vec2 ab = vec2(rho - R, q.z);
  float rr = length(ab);
  float s = atan(ab.y, ab.x) - F.y * phi - F.z;
  float sp = TAU / F.x;
  float sl = s - sp * floor(s / sp + 0.5);
  return abs(sl) / (0.5 * sp * F.w);
}

vec2 wvMap(vec3 q, int b) {
  vec4 P0 = uStP[b], P3 = uStP[b + 3];
  // Every ribbon lies within 0.75 of its torus surface (half-width <= 0.62 of a half-gap <= 0.26 r,
  // turned by the louvre, plus thickness), and the distance to the core circle is 1-Lipschitz, so
  // away from the two shells this is an exact lower bound: empty space (the hole, the gap
  // between and around the tori) is crossed without evaluating the ribbon pattern.
  float rr = length(vec2(length(q.xy) - P0.x, q.z));
  float shell = min(abs(rr - P0.y), abs(rr - P0.z)) - 0.75;
  if (shell > 0.15) return vec2(shell, abs(rr - P0.y) < abs(rr - P0.z) ? 1.0 : 2.0);
  float d1 = wvTorus(q, P0.x, P0.y, uStP[b + 1], P3.x, P0.w);
  float d2 = wvTorus(q, P0.x, P0.z, uStP[b + 2], P3.y, P0.w);
  return d1 < d2 ? vec2(d1 * 0.72, 1.0) : vec2(d2 * 0.72, 2.0);
}

// Transmission of one torus's ribbons where a light ray crosses that torus surface at p. A band
// turned by the louvre angle presents about w |cos| + thickness across the surface; the penumbra
// (world units) is converted into the band's normalised across-coordinate.
float wvBand(vec3 p, float R, float r, vec4 F, float louver, float thick, float soft) {
  float rho = length(p.xy);
  vec2 ab = vec2(rho - R, p.z);
  float rr = max(length(ab), 1e-3);
  float s = atan(ab.y, ab.x) - F.y * atan(p.y, p.x) - F.z;
  float sp = TAU / F.x;
  float sl = abs(s - sp * floor(s / sp + 0.5));
  float g = sqrt(1.0 / (rr * rr) + F.y * F.y / max(rho * rho, 1e-3));
  float halfGap = 0.5 * sp / g;
  float edge = (F.w * halfGap * abs(cos(louver)) + thick) * g;   // band half-width in s units
  float pen = soft * g;
  return smoothstep(edge - pen, edge + pen, sl);
}

// Shadows of the weave, evaluated at the ray's crossings of the two torus surfaces (the ribbons
// are thin bands lying in them), as the orrery does with its shells: the distance to the core
// circle is sampled along the bounded segment, each sign change of (rr - r) is refined linearly,
// and the band pattern is evaluated once there with a penumbra from the light's size.
float wvShadow(vec3 a, vec3 l, int b, float lightR) {
  vec3 dir = l - a;
  float len = length(dir);
  dir /= len;
  vec4 P0 = uStP[b], P3 = uStP[b + 3];
  float Rb = P0.x + P0.z + 0.6;
  float B = dot(a, dir), C = dot(a, a) - Rb * Rb, H = B * B - C;
  if (H <= 0.0) return 1.0;
  H = sqrt(H);
  float t0 = max(-B - H, 0.03), t1 = min(-B + H, len - 0.2);
  if (t0 >= t1) return 1.0;
  int n = uQuality > 0 ? 40 : 28;
  float dt = (t1 - t0) / float(n);
  vec3 p = a + dir * t0;
  float rr = length(vec2(length(p.xy) - P0.x, p.z));
  float f1 = rr - P0.y, f2 = rr - P0.z;
  float T = 1.0;
  for (int i = 1; i <= 40; i++) {
    if (i > n) break;
    float t = t0 + float(i) * dt;
    p = a + dir * t;
    rr = length(vec2(length(p.xy) - P0.x, p.z));
    float g1 = rr - P0.y, g2 = rr - P0.z;
    if (g1 * f1 < 0.0) {
      float tc = t - dt * g1 / (g1 - f1);
      T *= wvBand(a + dir * tc, P0.x, P0.y, uStP[b + 1], P3.x, P0.w, 0.015 + lightR * tc / len);
    }
    if (g2 * f2 < 0.0) {
      float tc = t - dt * g2 / (g2 - f2);
      T *= wvBand(a + dir * tc, P0.x, P0.z, uStP[b + 2], P3.y, P0.w, 0.015 + lightR * tc / len);
    }
    f1 = g1; f2 = g2;
    if (T < 0.01) break;
  }
  return T;
}

// ------------------------------------------------------------------------------------------------
// Lattice: the sculpture is {x : A(proj_V x) and B(proj_L x)}, the intersection of pattern A's cone
// from V with pattern B's cone from L*. From V it is exactly pattern A; under a point light at L*
// its shadow is exactly pattern B (each epipolar plane meets both patterns' rims, so every ray of
// either cone meets the other cone inside the bound). From anywhere else it is a tangle of
// disconnected curved rods.
// ------------------------------------------------------------------------------------------------
float patLookup(sampler2D tex, vec2 uv) {
  float r = length(uv);
  float ext = uLatK.w;
  if (r < ext * 0.97) return texture(tex, uv / ext * 0.5 + 0.5).r;
  return r - 1.0;
}
vec2 coneUv(vec3 p, vec3 apex, mat3 M, float D, out float z) {
  vec3 q = M * (p - apex);
  z = q.z;
  return q.xy / max(q.z, 0.2) * (D / uLatP.x);
}
// Distance to the cone of the stroke pattern (world units, conservative).
float coneDist(vec3 p, vec3 apex, mat3 M, float D, sampler2D tex, float stroke, out vec2 uv) {
  float z;
  uv = coneUv(p, apex, M, D, z);
  if (z < 0.2) return length(p - apex);
  float dp = patLookup(tex, uv) - stroke;
  return dp * uLatP.x * (z / D) * 0.82;
}
float latMap(vec3 p, out vec2 uvA) {
  vec2 uvB;
  float bnd = length(p - uLatC) - uLatP.w;
  float a = coneDist(p, uLatV.xyz, uLatMA, uLatV.w, uPatA, uLatP.y, uvA);
  float b = coneDist(p, uLatL.xyz, uLatMB, uLatL.w, uPatB, uLatP.z, uvB);
  return max(max(a, b), bnd);
}
// Lights other than L*: a bounded soft-shadow march through the rods.
float latShadow(vec3 a, vec3 l, float lightR) {
  vec3 dir = l - a;
  float len = length(dir);
  dir /= len;
  vec3 oc = a - uLatC;
  float Rb = uLatP.w;
  float B = dot(oc, dir), C = dot(oc, oc) - Rb * Rb, H = B * B - C;
  if (H <= 0.0) return 1.0;
  H = sqrt(H);
  float t = max(-B - H, 0.03), tEnd = min(-B + H, len - 0.2);
  if (t >= tEnd) return 1.0;
  float res = 1.0;
  vec2 uv;
  int steps = uQuality > 0 ? 48 : 30;
  for (int i = 0; i < 48; i++) {
    if (i >= steps || t >= tEnd) break;
    float d = latMap(a + dir * t, uv);
    float pen = 0.01 + lightR * t / len;
    res = min(res, clamp(0.5 + 0.5 * d / pen, 0.0, 1.0));
    if (res < 0.01) break;
    t += max(d, 0.03);
  }
  return res * res * (3.0 - 2.0 * res);
}
// L* itself: blocked exactly where the receiver lies in pattern B's cone beyond the sculpture.
float latStarTrans(vec3 p, float lightR) {
  float z;
  vec2 uv = coneUv(p, uLatL.xyz, uLatMB, uLatL.w, z);
  float behind = smoothstep(uLatL.w + uLatP.w * 0.2, uLatL.w + uLatP.w * 0.7, z);
  if (behind <= 0.0) return 1.0;
  // Penumbra in pattern units: light radius scaled by (receiver - sculpture) / (sculpture - light).
  float soft = 0.004 + lightR / uLatP.x * max(z - uLatL.w, 0.0) / uLatL.w * 0.5;
  float inB = 1.0 - smoothstep(-soft, soft, patLookup(uPatB, uv) - uLatP.z);
  return 1.0 - inB * behind;
}

// ------------------------------------------------------------------------------------------------
// Dispatch
// ------------------------------------------------------------------------------------------------
vec2 sMap(int s, vec3 q) {
  float type = uSt[s].w;
  int b = s * 8;
  if (type < 0.5) return orMap(q, b);
  if (type < 1.5) return wvMap(q, b);
  vec2 uv;
  return vec2(latMap(q + uSt[s].xyz, uv), 1.0);
}

float boundRadius(int s) {
  float type = uSt[s].w;
  int b = s * 8;
  if (type < 0.5) return uStP[b].x + uStP[b].y + 0.05;
  if (type < 1.5) return uStP[b].x + uStP[b].z + 0.6;
  return uLatP.w;
}

float traceSculpture(int s, vec3 lo, vec3 ld, float tA, float tB, out float id) {
  id = 0.0;
  float Rb = boundRadius(s);
  float B = dot(lo, ld), C = dot(lo, lo) - Rb * Rb, H = B * B - C;
  if (H <= 0.0) return -1.0;
  H = sqrt(H);
  float t = max(tA, -B - H), tEnd = min(tB, -B + H);
  if (t >= tEnd) return -1.0;
  float type = uSt[s].w;
  float stepScale = type < 0.5 ? 0.8 : 1.0;
  int steps = uQuality > 0 ? 180 : 120;
  for (int i = 0; i < 180; i++) {
    if (i >= steps) break;
    vec2 h = sMap(s, lo + ld * t);
    if (h.x < 0.0012 * t + 0.0015) { id = h.y; return t; }
    t += h.x * stepScale;
    if (t > tEnd) break;
  }
  return -1.0;
}

vec3 sNormal(int s, vec3 q, float t) {
  float e = 0.0015 + 0.0006 * t;
  vec2 k = vec2(1.0, -1.0);
  return normalize(k.xyy * sMap(s, q + k.xyy * e).x + k.yyx * sMap(s, q + k.yyx * e).x +
                   k.yxy * sMap(s, q + k.yxy * e).x + k.xxx * sMap(s, q + k.xxx * e).x);
}

// Spotlights (w = cos of the cone half-angle, 0 = omnidirectional) are aimed at their sculpture,
// so the membrane receives a lit disc containing the sculpture's shadow and stays dark elsewhere.
float spotCone(int s, int li, vec3 toLight) {
  float c = uLightC[li].w;
  if (c <= 0.0) return 1.0;
  vec3 axis = normalize(uSt[s].xyz - uLight[li].xyz);
  return smoothstep(c, c + 0.025, dot(-toLight, axis));
}

// Transmission from a point (sculpture frame) to light i of station s.
vec3 lightTrans(int s, vec3 q, vec3 lq, float lightR, int i, float minSoft) {
  float type = uSt[s].w;
  if (type < 0.5) return orTrans(q, lq, s * 8, lightR, minSoft);
  if (type < 1.5) return vec3(wvShadow(q, lq, s * 8, lightR));
  vec3 p = q + uSt[s].xyz;
  if (i == 0) return vec3(latStarTrans(p, lightR));
  return vec3(latShadow(p, lq + uSt[s].xyz, lightR));
}

// Light arriving on the membrane at world point p with inward normal n.
vec3 membraneIrradiance(int s, vec3 p, vec3 n) {
  vec3 C = uSt[s].xyz;
  mat3 M = uStRot[s];
  vec3 q = M * (p - C);
  vec3 sum = vec3(0.0);
  for (int i = 0; i < 4; i++) {
    int li = s * 4 + i;
    vec3 col = uLightC[li].rgb;
    if (dot(col, vec3(1.0)) < 1e-4) continue;
    vec3 lp = uLight[li].xyz;
    vec3 l = lp - p;
    float dist = length(l);
    float ndl = max(dot(n, l / dist), 0.0);
    if (ndl <= 0.0) continue;
    float spot = spotCone(s, li, l / dist);
    if (spot <= 0.0) continue;
    vec3 T = lightTrans(s, q, M * (lp - C), uLight[li].w, i, 0.004);
    sum += col * T * ndl * spot * (700.0 / (dist * dist + 60.0));
  }
  return sum;
}

// Haze visibility of the station's main light at world point x.
float hazeVis(int s, vec3 x) {
  float type = uSt[s].w;
  if (type > 1.5) return latStarTrans(x, uLight[s * 4].w);
  if (type > 0.5) return 0.3;
  int b = s * 8;
  vec3 q = uStRot[s] * (x - uSt[s].xyz);
  float r = length(q);
  float T = 1.0;
  float soft = 0.015 + 0.004 * r;
  if (r > uStP[b].z) T *= 1.0 - smoothstep(-soft, soft, orEmptyShell(q, b, 1));
  if (r > uStP[b].x && T > 0.002) T *= 1.0 - smoothstep(-soft, soft, orEmptyShell(q, b, 0));
  return T;
}

vec3 haze(int s, vec3 ro, vec3 rd, float ta, float tb, float jitter) {
  float density = uGrade.y * uStB[s].x;
  if (density < 1e-4 || tb <= ta) return vec3(0.0);
  vec3 lp = uLight[s * 4].xyz;
  vec3 lc = uLightC[s * 4].rgb;
  // Equiangular sampling: samples uniform in the angle seen from the light, so their density
  // follows the inverse-square falloff and the angular frequency of the aperture masks; a dozen
  // samples resolve the shafts (pdf(t) = h / ((thB - thA) * d^2), d the distance to the light).
  float tc = dot(lp - ro, rd);
  float h = max(length(ro + rd * tc - lp), 0.05);
  float thA = atan((ta - tc) / h), thB = atan((tb - tc) / h);
  int n = uQuality > 0 ? 14 : 9;
  vec3 acc = vec3(0.0);
  for (int i = 0; i < 14; i++) {
    if (i >= n) break;
    float th = mix(thA, thB, (float(i) + jitter) / float(n));
    float t = tc + h * tan(th);
    float d2 = h * h + (t - tc) * (t - tc);
    acc += lc * hazeVis(s, ro + rd * t) * d2 / (1.0 + d2 * 0.06);
  }
  acc *= (thB - thA) / (h * float(n)) * 0.0035;
  // Every other light adds a soft unshadowed glow so coloured lights read in the air.
  for (int i = 1; i < 4; i++) {
    int li = s * 4 + i;
    vec3 col = uLightC[li].rgb;
    if (dot(col, vec3(1.0)) < 1e-4) continue;
    vec3 lp2 = uLight[li].xyz;
    float tc = clamp(dot(lp2 - ro, rd), ta, tb);
    float dd = length(ro + rd * tc - lp2);
    acc += col * 0.004 / (1.0 + dd * dd * 0.15);
  }
  return acc * density;
}

vec3 lightGlows(int s, vec3 ro, vec3 rd, float tEnd) {
  vec3 acc = vec3(0.0);
  for (int i = 0; i < 4; i++) {
    int li = s * 4 + i;
    vec3 col = uLightC[li].rgb;
    if (dot(col, vec3(1.0)) < 1e-4) continue;
    vec3 lp = uLight[li].xyz;
    float t = dot(lp - ro, rd);
    if (t <= 0.0 || t > tEnd) continue;
    float d = length(ro + rd * t - lp);
    float r = max(uLight[li].w, 0.02) * (1.0 + 0.002 * t);
    acc += col * (exp(-d * d / (r * r)) * 0.9 + r * r * 0.015 / (d * d + r * r * 0.5));
  }
  return acc;
}

// ------------------------------------------------------------------------------------------------
// Materials
// ------------------------------------------------------------------------------------------------
vec3 thinFilm(float c, vec3 shift) { return 0.55 + 0.45 * cos(TAU * (c * 1.4 + shift)); }

vec3 shadeSculpture(int s, vec3 q, vec3 ldir, float id, float t, vec2 frag) {
  float type = uSt[s].w;
  int b = s * 8;
  vec3 C = uSt[s].xyz;
  mat3 M = uStRot[s];
  vec3 n = sNormal(s, q, t);
  vec3 v = -ldir;
  float ndv = max(dot(n, v), 0.0);
  float fres = pow(1.0 - ndv, 5.0);
  vec3 surf = uStCol[s * 4].rgb, sheen = uStCol[s * 4 + 1].rgb, edgeCol = uStCol[s * 4 + 2].rgb;

  float rough = 0.25;
  vec3 albedo = surf;
  float metal = 0.0;
  vec3 emit = vec3(0.0);
  float edge = 0.0;

  if (type < 0.5) {
    // Obsidian shells with a violet sheen; the core is emissive.
    if (id > 2.5) return uLightC[s * 4].rgb * 0.06 + vec3(1.0, 0.92, 0.75) * 2.0;
    int shell = id > 1.5 ? 1 : 0;
    float e = orEmptyShell(q, b, shell);
    float R = shell == 0 ? uStP[b].x : uStP[b].z, th = shell == 0 ? uStP[b].y : uStP[b].w;
    // Only the outer lip of each aperture: a fine luminous line, not the whole wall.
    float lip = exp(-abs(length(q) - R - th) / 0.035);
    edge = exp(-abs(e) / (0.02 + 0.001 * t)) * lip;
    rough = 0.12;
    // Obsidian: almost no diffuse, so even the inner faces near the core read through reflections
    // and the dappled light of the other shell rather than as flat lit plaster.
    albedo = surf * (shell == 0 ? 0.45 : 0.35);
    // Kick: a band of light running along the rims from pole to pole.
    float u = atanh1(clamp(normalize(q).z, -0.9999, 0.9999));
    float band = exp(-pow((u - uStP[b + 4].w) * 2.2, 2.0)) * uStP[b + 5].x;
    emit += edgeCol * edge * (0.08 * uGrade2.w + 1.6 * band);
  } else if (type < 1.5) {
    // Pearl ribbons: thin-film tint shifting with the view angle.
    // Dark pearl ribbons with a thin-film sheen; their edges carry a fine line of light that
    // explains the weave, and kick pulses travel round the torus along those edges.
    albedo = surf * mix(vec3(1.0), thinFilm(ndv, vec3(0.0, 0.33, 0.67) + id * 0.21), 0.55) * 0.16;
    metal = 0.35;
    rough = 0.28;
    vec4 P0 = uStP[b];
    float across = id < 1.5 ? wvAcross(q, P0.x, P0.y, uStP[b + 1]) : wvAcross(q, P0.x, P0.z, uStP[b + 2]);
    float rim = smoothstep(0.78, 0.98, across);
    float phi = atan(q.y, q.x);
    float dphi = abs(mod(phi - uStP[b + 3].z + PI, TAU) - PI);
    float pulse = exp(-dphi * dphi * 6.0) * uStP[b + 3].w;
    emit += edgeCol * rim * (0.05 * uGrade2.w + 1.8 * pulse) + edgeCol * pulse * 0.15;
  } else {
    // Brushed white gold rods. The A coordinate carries the kick ring and the alignment glow.
    vec2 uvA;
    float zA;
    uvA = coneUv(q + C, uLatV.xyz, uLatMA, uLatV.w, zA);
    float ra = length(uvA);
    float ring = exp(-pow((ra - uLatK.x) * 55.0, 2.0)) * uLatK.y;
    emit += edgeCol * (ring * 1.4 + uLatK.z * 0.3);
    metal = 0.85;
    rough = 0.22;
  }

  vec3 col = vec3(0.0);
  for (int i = 0; i < 4; i++) {
    int li = s * 4 + i;
    vec3 lc = uLightC[li].rgb;
    if (dot(lc, vec3(1.0)) < 1e-4) continue;
    vec3 lq = M * (uLight[li].xyz - C);
    vec3 l = lq - q;
    float dist = length(l);
    l /= dist;
    float ndl = dot(n, l);
    if (ndl <= 0.0) continue;
    vec3 T = vec3(1.0);
    if (type < 0.5) T = orTrans(q + n * 0.01, lq, b, uLight[li].w, 0.004);
    else if (type < 1.5 && i < (uQuality > 0 ? 2 : 1)) T = vec3(wvShadow(q + n * 0.04, lq, b, uLight[li].w));
    if (max(T.r, max(T.g, T.b)) < 0.002) continue;
    vec3 h = normalize(l + v);
    float sp = pow(max(dot(n, h), 0.0), 2.0 / (rough * rough * rough + 0.002));
    float fall = 220.0 / (dist * dist + 12.0);
    vec3 spec = mix(vec3(0.04), albedo * 2.0, metal) * min(sp, 40.0) * (1.0 + (type > 1.5 ? 0.4 : 1.5) * uGrade2.z);
    col += lc * T * fall * (albedo * (1.0 - metal) * ndl + spec * ndl);
  }

  // Environment: the membrane around the sculpture, lit by its own projection.
  vec3 rf = reflect(-v, n);
  vec3 env = sheen * (0.04 + 0.05 * rf.z);
  if (type < 0.5) {
    float RM = uStB[s].y;
    float Bq = dot(q, rf), Cq = dot(q, q) - RM * RM;
    vec3 pd = q + rf * (-Bq + sqrt(max(Bq * Bq - Cq, 0.0)));
    vec3 T = orTrans(pd * 0.999, vec3(0.0), b, uLight[b / 2].w, 0.02);
    env += uLightC[s * 4].rgb * T * 0.05 * uStCol[s * 4 + 3].rgb;
  }
  vec3 F = mix(vec3(0.04), albedo, metal);
  col += env * (F + (1.0 - F) * fres) * (type < 0.5 ? 3.0 : 1.5);
  col += sheen * fres * 0.08 * (0.4 + uMusic.w);
  // High-frequency glints on edges and ridges.
  // (Not on the lattice: its rods are a few pixels wide and glints there read as sparkle noise.)
  float glint = pow(max(dot(reflect(-v, n), normalize(vec3(0.3, 0.8, -0.5))), 0.0), 60.0);
  col += edgeCol * glint * uGrade2.z * (type > 1.5 ? 0.0 : 0.25);
  return col + emit;
}

// Membrane: pearl inside, glowing through outside, luminous aperture rims.
vec3 shadeMembrane(int s, vec3 p, vec3 d, vec3 rd, bool outside) {
  vec3 n = -d;
  vec3 irr = membraneIrradiance(s, p, n);
  vec3 pearl = uStCol[s * 4 + 3].rgb;
  float gain = uStB[s].w;
  // Faint loxodromic engraving keeps the curvature legible where no light falls.
  float z = clamp(d.z, -0.999, 0.999);
  vec2 w = vec2(atanh1(z), atan(d.y, d.x)) * vec2(5.0, 24.0 / TAU);
  vec2 g = abs(fract(w + vec2(w.y * 0.25, 0.0)) - 0.5);
  float lines = smoothstep(0.03, 0.0, min(g.x, g.y) * (1.0 + abs(w.x) * 0.2));
  float detail = uGrade2.y * (0.006 + 0.007 * lines);
  float ndv = abs(dot(rd, d));
  vec3 tint = pearl * thinFilm(ndv, vec3(0.6, 0.75, 0.9));
  vec3 col;
  if (outside) col = irr * pearl * 0.55 * gain + tint * (detail + pow(1.0 - ndv, 3.0) * 0.05);
  else col = irr * pearl * gain + tint * detail;
  // Aperture rims
  float c = abs(d.z);
  float rim = exp(-pow((c - uStB[s].z) * 60.0, 2.0));
  col += uStCol[s * 4 + 2].rgb * rim * (0.35 + 0.6 * uMusic.x) * uStB[s].x;
  return col * uStB[s].x;
}

vec3 background(vec3 rd) {
  vec3 col = mix(vec3(0.004, 0.005, 0.012), vec3(0.016, 0.010, 0.030), 0.5 + 0.5 * rd.y);
  vec2 sph = vec2(atan(rd.x, rd.z), asin(clamp(rd.y, -1.0, 1.0))) * 90.0;
  vec2 cell = floor(sph);
  float h = hash12(cell);
  vec2 f = fract(sph) - 0.5 - (vec2(hash12(cell + 7.1), hash12(cell + 3.3)) - 0.5) * 0.6;
  float star = smoothstep(0.996, 1.0, h) * exp(-dot(f, f) * 40.0);
  col += vec3(0.7, 0.8, 1.0) * star * 0.5;
  return col;
}

void station(int s, vec3 ro, vec3 rd, float jitter, vec2 frag, inout vec3 col, inout float T) {
  if (uSt[s].w < -0.5 || uStB[s].x < 0.001) return;
  vec3 C = uSt[s].xyz;
  float RM = uStB[s].y;
  vec3 oc = ro - C;
  float B = dot(oc, rd), Cc = dot(oc, oc) - RM * RM, H = B * B - Cc;
  if (H <= 0.0) return;
  H = sqrt(H);
  float t0 = -B - H, t1 = -B + H;
  if (t1 <= 0.0) return;
  float apCos = uStB[s].z;
  float tStart = max(t0, 0.0);
  if (Cc > 0.0) {
    // Outside: the membrane, unless the ray enters through an aperture.
    vec3 d = (ro + rd * t0 - C) / RM;
    float open = smoothstep(apCos - 0.002, apCos + 0.002, abs(d.z));
    if (open < 1.0) col += T * (1.0 - open) * shadeMembrane(s, ro + rd * t0, d, rd, true);
    T *= open;
    if (T < 0.002) return;
  }
  mat3 M = uStRot[s];
  float id;
  float th = traceSculpture(s, M * (ro - C), M * rd, tStart, t1, id);
  float tEnd = th > 0.0 ? th : t1;
  col += T * haze(s, ro, rd, tStart, tEnd, jitter);
  col += T * lightGlows(s, ro, rd, tEnd);
  if (th > 0.0) {
    col += T * shadeSculpture(s, M * (ro + rd * th - C), M * rd, id, th, frag);
    T = 0.0;
    return;
  }
  vec3 d = (ro + rd * t1 - C) / RM;
  float open = smoothstep(apCos - 0.002, apCos + 0.002, abs(d.z));
  if (open < 1.0) col += T * (1.0 - open) * shadeMembrane(s, ro + rd * t1, d, rd, false);
  T *= open;
}

void main() {
  vec2 frag = gl_FragCoord.xy;
  vec2 p = (frag * 2.0 - uRes) / uRes.y;
  vec3 rd = normalize(p.x * uCamRight + p.y * uCamUp + uFocal * uCamFwd);
  vec3 ro = uCamPos;
  float jitter = ign(frag);
  vec3 col = vec3(0.0);
  float T = 1.0;
  station(0, ro, rd, jitter, frag, col, T);
  if (T > 0.002) station(1, ro, rd, jitter, frag, col, T);
  if (T > 0.002) col += T * background(rd);

  col *= uGrade.x;
  col += vec3(1.0, 0.86, 0.62) * uGrade.z * 0.25;
  float lum = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = max(mix(vec3(lum), col, uGrade.w), 0.0);
  // ACES fit, then display gamma.
  col = clamp((col * (2.51 * col + 0.03)) / (col * (2.43 * col + 0.59) + 0.14), 0.0, 1.0);
  col = pow(col, vec3(1.0 / 2.2));
  vec2 uv = frag / uRes;
  col *= 1.0 - uGrade2.x * pow(length((uv - 0.5) * vec2(uRes.x / uRes.y, 1.0)) * 0.9, 2.2);
  col += (hash12(frag) - 0.5) / 255.0;
  outColor = vec4(col, 1.0);
}`;
