// Hypergeometry Engine: Dimensional Emergence (preset 398) — music -> the state of the
// four-dimensional system (pure JS, testable).
//
// Rotation is a pair of unit quaternions (qL, qR), v -> qL v qR. Equal left and right generators
// along u rotate the plane (w, u) only: a rotation through the fourth dimension. Opposite
// generators rotate the 3D plane orthogonal to u: an ordinary rotation. So:
//
//   bass        rotations in the planes containing w (the projected cells pass through each other,
//               insides turn outwards), the slicing hyperplane's travel, cell breathing
//   kicks       light pulses launched from a vertex that travel the polytope's real edge graph,
//               layer by graph distance
//   mids        ordinary 3D-plane rotation, colour drift, which cells stand out
//   highs/hats  vertex accents, facet rims
//   energy      how much of the structure is revealed: facet opacity, separated cells, echoes of the
//               polytope in the surrounding space, rotation rates
//   breakdown   dimensional reduction: the projection fades to a ghost, the exact 3D cross-section
//               becomes the subject and sweeps slowly through the fourth dimension
//   build       instability: W-plane rotations accelerate through new orientations, the section
//               sweeps faster, pulses launch from antipodal vertices timed to converge on one vertex
//               at the predicted boundary; in the last ~1.5 s the system settles into a symmetric
//               "critical" orientation and the light contracts
//   drop        emergence: the next polytope sweeps in through the fourth dimension (a hyperplane
//               passes through, new structure on one side, old on the other, both cross-sections
//               glowing at the interface), its cells separate, energy races out from every vertex
import { createNewtonAudioModel, follow } from "./newtonBasinAudio.js";
import { buildPolytope, graphDistances, quat, v4 } from "./hypergeometryMath.js";
import { AETHER_WORLD_SLICE } from "./hypergeometryAether.js";

const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const TAU = Math.PI * 2;

// The journey through the polytopes; the 120-cell and 600-cell are the climaxes.
export const WORLDS = Object.freeze([
  // density scales facet opacity and edge light so 600-face structures stay readable
  { polytope: "tesseract", hue: 0.0, name: "Hypercrystal", density: 1.0, scale: 1.55 },
  { polytope: "24-cell", hue: 0.62, name: "Octahedral Lattice", density: 0.7, scale: 1.55 },
  { polytope: "16-cell", hue: 0.33, name: "Orthoplex", density: 1.0, scale: 1.9 },
  { polytope: "120-cell", hue: 0.82, name: "Dodecahedral Universe", density: 0.3, scale: 1.35 },
  { polytope: "600-cell", hue: 0.55, name: "Tetrahedral Storm", density: 0.16, scale: 1.35 }
]);

// Camera shots (spherical around the origin): distance, yaw rate, pitch, fov.
export const SHOTS = Object.freeze({
  orbit: { dist: 4.2, pitch: 0.32, fov: 0.85, rate: 0.06 },
  close: { dist: 3.1, pitch: 0.12, fov: 0.95, rate: 0.045 },
  interior: { dist: 0.85, pitch: 0.18, fov: 1.35, rate: 0.035 },
  wide: { dist: 5.0, pitch: 0.45, fov: 0.72, rate: 0.05 }
});
const SHOT_ORDER = ["orbit", "close", "interior", "orbit", "wide", "close"];

export function createHypergeometryDirector() {
  const audioModel = createNewtonAudioModel();
  const polytopes = new Map();
  const s = {};
  const pulses = [];
  const polytope = (name) => {
    if (!polytopes.has(name)) { const p = buildPolytope(name); polytopes.set(name, { poly: p, dist: graphDistances(p), diameter: diameterOf(p) }); }
    return polytopes.get(name);
  };

  function reset() {
    audioModel.reset();
    pulses.length = 0;
    Object.assign(s, {
      time: 0, world: 0, nextWorld: 1, sweep: null, worldSince: 0,
      qL: quat.norm([0.18, 0.31, -0.12, 0.92]), qR: quat.norm([-0.1, 0.22, 0.35, 0.9]), target: null,
      energy: 0.35, bass: 0.2, mids: 0.25, highs: 0.2, groove: 0, breakdown: 0, build: 0,
      tension: 0, future: 0, preDrop: 0, surge: 0, flash: 0, kickPulse: 0, kicks: 0, hats: 0, drops: 0,
      previousKick: 0, breakAt: null, lastDropAt: -100, collapseSince: null, lastRelaxAt: -100, levelPeak: 0.3,
      shrink: 0.96, faceOpacity: 0.16, edgeIntensity: 1, sectionMix: 0, sectionH: 0.9, sectionDir: -1,
      projD: 2.6, persp: 1, echo: 0, hue: 0, hatGlint: 0,
      shot: "orbit", shotIndex: 0, shotSince: 0, cam: { dist: 4.6, pitch: 0.32, fov: 0.85, yaw: 0.6 },
      exposure: 1, saturation: 1.05, phase: "intro", event: "", convergeTarget: 0,
      forcedDrop: false, shrinkKick: 0, frontVertex: 0,
      // Dimensional Aether (the environment): its own SO(4) orientation, slice height and envelopes
      qeL: quat.norm([0.1, -0.2, 0.15, 0.96]), qeR: quat.norm([0.12, 0.25, -0.05, 0.95]),
      envSlice: AETHER_WORLD_SLICE[0], envEnergy: 0.35, envReveal: 0.35, envBass: 0.2, envKick: 0, envKickAge: 10, envMaster: 1
    });
  }
  reset();

  function spawnPulse(kind, source, strength, speed, delay = 0) {
    if (pulses.length >= 8) {
      let oldest = 0;
      for (let i = 1; i < pulses.length; i += 1) if (pulses[i].age > pulses[oldest].age) oldest = i;
      pulses.splice(oldest, 1);
    }
    pulses.push({ kind, source, strength, speed, age: -delay, life: 0 });
  }

  function step(dt, input = {}, controls = {}) {
    dt = clamp(dt, 0, 0.1);
    s.time += dt;
    const { audio = {}, smooth: smoothBands = {}, music = {}, lookahead = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth: smoothBands, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    const reactive = clamp(controls.reactive ?? 1, 0, 1.5);
    s.event = "";

    // ---- envelopes (relative to the track's own level: loud masters saturate absolute values) ----
    const fast = clamp(audio.globalEnergyFast ?? a.energyFast), slow = clamp(audio.globalEnergySlow ?? a.energySlow);
    const energyNow = clamp(fast * 0.5 + slow * 0.2 + clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.3);
    s.levelPeak = Math.max(energyNow, s.levelPeak - dt * s.levelPeak / 90);
    const rel = clamp((energyNow / Math.max(s.levelPeak, 0.05) - 0.55) / 0.45);
    s.mids = follow(s.mids, a.midDrive, dt, 0.1, 0.5);
    s.highs = follow(s.highs, a.highDrive, dt, 0.03, 0.2);
    s.bass = follow(s.bass, Math.max(a.subDrive, clamp(((audio.bassRel ?? 1) - 0.8) * 1.6)), dt, 0.08, 0.6);
    s.groove = a.groove; s.breakdown = a.breakdown; s.build = a.build;
    const energyGoal = clamp(0.12 + 0.38 * s.groove * (1 - 0.6 * s.breakdown) + 0.15 * rel + 0.38 * s.surge + 0.08 * s.highs * s.groove);
    s.energy = follow(s.energy, energyGoal * reactive + 0.3 * (1 - reactive), dt, 0.4, 1.4);
    const E = s.energy;
    const B = clamp(s.breakdown * (1 - s.groove));

    // ---- lookahead and drops (as in the other music-aware runtimes) ---------------------------------
    const current = lookahead.current || {}, med = lookahead.medium || {}, long = lookahead.long || {};
    const rise = clamp(((med.maxEnergy || med.energy || 0) - (current.energy || 0) - 0.08) * 3.2);
    const bassReturn = clamp(((med.bass || 0) - (current.bass || 0) - 0.035) * 3);
    const farRise = clamp(((long.energy || 0) - (current.energy || 0) - 0.12) * 2);
    s.future = lookahead.ready
      ? clamp(Math.max(clamp(music.upcomingDrop) * 1.4, rise * (0.5 + 0.5 * bassReturn), clamp(music.upcomingBuild) * 0.5, farRise * 0.4))
      : 0;
    const phraseSeconds = Number(music.nextPhraseSeconds);
    const phraseValid = Number.isFinite(phraseSeconds) && phraseSeconds > 0;
    const quiet = s.groove < 0.35 || s.breakdown > 0.6;
    const pulseNow = clamp(audio.kickPulse), lowNow = clamp(audio.bassNow ?? smoothBands.bass);
    const onset = pulseNow > 0.48 && s.previousKick <= 0.48 && lowNow > 0.3;
    s.previousKick = pulseNow;
    let grooveReturn = 0;
    if (quiet) { if (s.breakAt === null) s.breakAt = s.time; }
    if (s.breakAt !== null && (onset || events.drop || (!quiet && s.groove > 0.6))) {
      const gap = s.time - s.breakAt;
      if (s.tension > 0.3 && gap > 1.5) { grooveReturn = Math.max(gap, 3); s.breakAt = null; }
      else if (gap > 0.8 && (!quiet || gap >= 3)) { grooveReturn = gap; s.breakAt = null; }
      else if (!quiet) s.breakAt = null;
    }
    const evidence = bassReturn > 0.15 || rise > 0.45 || clamp(music.upcomingDrop) > 0.5;
    const confident = clamp(music.upcomingDrop) > 0.8;
    const loosening = quiet || s.groove < 0.8 || a.build > 0.5;
    const predicted = loosening && s.future > 0.6 && evidence && phraseValid && phraseSeconds < 9 && s.time > 6
      && s.time - s.lastDropAt > 12 && (s.time - s.lastRelaxAt > 16 || confident);
    let goal = 0;
    if (predicted) goal = clamp(s.future * 1.25) * clamp((9 - phraseSeconds) / 7);
    else if (a.build > 0.6 && quiet) goal = 0.6 * a.build;
    goal *= clamp(controls.anticipation ?? 1);
    if (goal > 0.2 && s.collapseSince === null) s.collapseSince = s.time;
    if (s.collapseSince !== null && (s.time - s.collapseSince > 14 || goal < 0.05)) { s.collapseSince = null; s.lastRelaxAt = s.time; goal = 0; }
    s.tension = follow(s.tension, goal, dt, 0.6, 1.6);
    s.preDrop = follow(s.preDrop, predicted && phraseSeconds < 1.6 ? 1 : 0, dt, 0.25, 0.15);
    const T = s.tension;

    const forced = Number.isFinite(controls.dropAt) && s.time >= controls.dropAt && !s.forcedDrop;
    if (forced) s.forcedDrop = true;
    const dropEvent = (grooveReturn >= 3 || forced) && s.time > 4 && s.time - s.lastDropAt > 6 && (controls.drops ?? 1) > 0;
    const world = WORLDS[s.world], P = polytope(world.polytope);

    // ---- drop: emergence of the next polytope through the fourth dimension -------------------------
    if (dropEvent && !s.sweep) {
      s.lastDropAt = s.time; s.drops += 1; s.tension = 0; s.collapseSince = null;
      s.flash = 1; s.surge = 1; s.preDrop = 0;   // the critical configuration releases at once
      // Peaks go to the richest structures; otherwise the journey continues in order.
      const next = controls.world >= 0 ? controls.world : (s.drops % 2 === 1 ? (s.world + 1) % WORLDS.length : nextRich(s.world));
      startSweep(next, 1.8);
      s.event = `drop:${WORLDS[next].polytope}`;
      s.target = null;
      s.shrinkKick = 1;
    }
    // Long stretches without drops still travel: a slower sweep to the next world every ~48 s.
    // Only in a steady groove (never while a drop is building or in a breakdown, so the big change
    // stays with the music's own events).
    if (!s.sweep && s.time - s.worldSince > (controls.worldSeconds ?? 80) && T < 0.05 && s.future < 0.25 && s.groove > 0.8 && B < 0.2
      && s.time - s.lastDropAt > 20 && (controls.drops ?? 1) >= 0) startSweep((s.world + 1) % WORLDS.length, 4.5);
    if (Number.isFinite(controls.world) && s.world !== controls.world && !s.sweep && s.time < 0.1) { s.world = controls.world; s.worldSince = 0; }

    // ---- kicks: light travels the real edge graph ---------------------------------------------------
    for (const wave of events.waves) {
      if (wave.kind !== "kick") continue;
      s.kicks += 1;
      s.kickPulse = 1;
      const n = P.poly.vertices.length;
      // Downbeats start from the vertex nearest the viewer in the fourth dimension; other beats
      // walk round the polytope so successive pulses cross each other.
      const source = wave.beatInBar === 0 ? s.frontVertex ?? 0 : (s.kicks * 7919) % n;
      const beat = 1 / bps;
      spawnPulse("kick", source, (0.6 + 0.6 * E) * reactive, P.diameter / (beat * (1.3 - 0.4 * E)));
    }
    if (events.hats && s.highs > 0.15) { s.hats += 1; s.hatGlint = Math.min(1, s.hatGlint + 0.5); }
    // Build: antipodal pulses timed to converge on one vertex at the predicted boundary.
    if (T > 0.35 && phraseValid && phraseSeconds > 0.8 && phraseSeconds < 6 && !pulses.some((p) => p.kind === "converge")) {
      const n = P.poly.vertices.length, target = s.convergeTarget % n;
      const anti = antipode(P.poly, target);
      spawnPulse("converge", anti, 1.0, P.diameter / phraseSeconds);
    }
    if (dropEvent) {
      // Emergence: energy races out from several vertices at once.
      const n = polytope(WORLDS[s.sweep ? s.sweep.to : s.world].polytope).poly.vertices.length;
      for (let i = 0; i < 4; i += 1) spawnPulse("drop", (i * 37 + s.drops * 11) % n, 1.4, polytope(WORLDS[s.sweep ? s.sweep.to : s.world].polytope).diameter / 0.9, i * 0.08);
    }
    for (const p of pulses) p.age += dt;
    for (let i = pulses.length - 1; i >= 0; i -= 1) {
      const P2 = polytope(WORLDS[s.world].polytope);
      if (pulses[i].age * pulses[i].speed > P2.diameter + 3) pulses.splice(i, 1);
    }
    s.kickPulse *= Math.exp(-dt / 0.15);
    s.hatGlint *= Math.exp(-dt / 0.12);
    s.flash *= Math.exp(-dt / 0.6);
    s.surge *= Math.exp(-dt / 7);
    s.shrinkKick = (s.shrinkKick || 0) * Math.exp(-dt / 2.2);

    // ---- the sweep between polytopes -----------------------------------------------------------------
    if (s.sweep) {
      s.sweep.h -= dt * 2.3 / s.sweep.duration;
      if (s.sweep.h < -1.15) { s.world = s.sweep.to; s.worldSince = s.time; s.sweep = null; }
    }

    // ---- rotation through SO(4) -----------------------------------------------------------------------
    // Rates in radians per second; W-plane rotation rides on the bass, 3D rotation on the mids.
    // Just before a predicted drop the free rotation is damped while the system settles into its
    // critical orientation (below).
    const settle = 1 - 0.9 * s.preDrop;
    const wRate = (0.05 + 0.22 * s.bass + 0.25 * E + 0.6 * T + 0.5 * s.surge) * reactive * (1 - 0.6 * B) * settle;
    const r3 = (0.03 + 0.10 * s.mids + 0.05 * E) * reactive * settle;
    const t = s.time;
    // The W-plane axis drifts slowly so successive minutes explore different 4D orientations.
    const uW = [Math.cos(t * 0.031), Math.sin(t * 0.031) * Math.cos(t * 0.019), Math.sin(t * 0.031) * Math.sin(t * 0.019)];
    const u3 = [Math.sin(t * 0.023 + 1), Math.cos(t * 0.017), Math.sin(t * 0.029 + 2)];
    const gL = uW.map((x, i) => x * wRate + u3[i] * r3), gR = uW.map((x, i) => x * wRate - u3[i] * r3);
    s.qL = quat.norm(quat.mul(quat.exp(gL, dt * 0.5), s.qL));
    s.qR = quat.norm(quat.mul(s.qR, quat.exp(gR, dt * 0.5)));
    // Pre-drop: settle into a symmetric critical orientation (a vertex or a cell facing the
    // fourth-dimensional viewpoint), the last moment of order before the emergence.
    if (s.preDrop > 0.05 || controls.critical) {
      if (!s.target) s.target = criticalOrientation(P.poly, s.drops);
      const k = 1 - Math.exp(-dt * (5 * Math.max(s.preDrop, controls.critical ? 1 : 0)));
      s.qL = quat.slerp(s.qL, s.target.qL, k);
      s.qR = quat.slerp(s.qR, s.target.qR, k);
    } else if (s.target && s.preDrop < 0.02) s.target = null;
    // The environment turns through the same planes, driven by the same generators, at a small
    // fraction of the rate: far away and immense. During a drop's sweep it also turns a further
    // ~70 degrees through the W plane: the field reorganises with the emerging polytope.
    const envRate = 0.13 * (controls.freeze ? 0 : 1);
    const spin = s.sweep ? 1.2 / s.sweep.duration : 0;
    const eL = gL.map((x, i) => x * envRate + uW[i] * spin), eR = gR.map((x, i) => x * envRate + uW[i] * spin);
    s.qeL = quat.norm(quat.mul(quat.exp(eL, dt * 0.5), s.qeL));
    s.qeR = quat.norm(quat.mul(s.qeR, quat.exp(eR, dt * 0.5)));

    // ---- how much of the structure is revealed --------------------------------------------------------
    const sectionGoal = Math.max(clamp((B - 0.35) / 0.4), controls.section ?? 0);
    s.sectionMix = follow(s.sectionMix, sectionGoal, dt, 1.5, 1.2);
    // The hyperplane sweeps back and forth through the fourth dimension; builds speed it up.
    const sweepRate = (0.12 + 0.25 * s.bass + 0.6 * T) * (controls.freeze ? 0 : 1);
    s.sectionH += s.sectionDir * sweepRate * dt;
    if (s.sectionH < -0.98) { s.sectionH = -0.98; s.sectionDir = 1; }
    if (s.sectionH > 0.98) { s.sectionH = 0.98; s.sectionDir = -1; }
    if (Number.isFinite(controls.h)) s.sectionH = controls.h;
    // Cells are either joined (1: the exact projection) or clearly separated (<= 0.82): slightly
    // separated per-cell copies of an edge would read as a rendering fault. The separated state
    // belongs to peaks and drops (internal volumes separate), entered and left quickly.
    const separate = Math.max(smooth(0.78, 0.9, E), s.shrinkKick > 0.25 ? 1 : 0) * (1 - s.sectionMix);
    const shrinkGoal = separate > 0.5 ? 0.8 - 0.12 * s.shrinkKick : 1;
    s.shrink = follow(s.shrink, Number.isFinite(controls.shrink) ? controls.shrink : shrinkGoal, dt, 0.45, 0.45);
    s.faceOpacity = follow(s.faceOpacity, (0.10 + 0.16 * E + 0.08 * s.surge) * (1 - 0.75 * s.sectionMix) * (1 - 0.5 * s.preDrop), dt, 0.4, 0.8);
    s.edgeIntensity = follow(s.edgeIntensity, (0.55 + 0.6 * E) * (1 - 0.55 * s.sectionMix) * (1 - 0.4 * s.preDrop), dt, 0.3, 0.6);
    s.echo = follow(s.echo, smooth(0.45, 0.9, E) * (1 - s.sectionMix), dt, 1.0, 2.0);
    s.projD = follow(s.projD, 2.6 - 0.35 * T + 0.25 * B, dt, 1.2, 1.2);
    s.hue = (s.hue + dt * (0.004 + 0.012 * s.mids)) % 1;
    // Environment: the slice height belongs to the world (a new arrangement after each drop),
    // follows the foreground's slicing hyperplane in breakdowns and drifts ahead during builds.
    const envWorld = s.sweep ? AETHER_WORLD_SLICE[s.sweep.to] : AETHER_WORLD_SLICE[s.world];
    const envSliceGoal = envWorld + 0.45 * s.sectionMix * s.sectionH + 0.3 * T * Math.sin(s.time * 0.4) + 0.08 * Math.sin(s.time * 0.021);
    s.envSlice = follow(s.envSlice, envSliceGoal, dt, s.sweep ? 0.9 : 3.5, s.sweep ? 0.9 : 3.5);
    s.envEnergy = follow(s.envEnergy, E, dt, 1.2, 2.5);
    s.envBass = follow(s.envBass, s.bass, dt, 1.0, 2.0);
    // How much of the architecture is revealed: a few structures at rest, all of them at peaks,
    // restrained and spacious in breakdowns.
    s.envReveal = follow(s.envReveal, clamp((0.15 + 0.85 * E + 0.25 * T + 0.3 * s.surge) * (1 - 0.35 * B)), dt, 1.5, 3.0);
    s.envMaster = (controls.aether ?? 1) * (1 - 0.35 * s.preDrop);
    if (events.waves.some((w) => w.kind === "kick")) { s.envKick = (0.5 + 0.5 * E) * reactive; s.envKickAge = 0; }
    if (dropEvent) { s.envKick = 1.3; s.envKickAge = 0; }
    s.envKickAge += dt;

    // ---- camera ---------------------------------------------------------------------------------------
    const forcedShot = SHOTS[controls.shot] ? controls.shot : null;
    if (forcedShot) { s.shot = forcedShot; }
    else if (dropEvent) { s.shot = "wide"; s.shotSince = s.time; }
    else if (B > 0.5 && s.shot !== "close" && s.time - s.shotSince > 6) { s.shot = "close"; s.shotSince = s.time; }
    else if (s.time - s.shotSince > (s.shot === "wide" ? 5 : 16 + 8 * (1 - E))) {
      s.shotIndex = (s.shotIndex + 1) % SHOT_ORDER.length;
      s.shot = SHOT_ORDER[s.shotIndex];
      if (s.shot === "interior" && (s.sectionMix > 0.3 || s.sweep)) s.shot = "close";
      s.shotSince = s.time;
    }
    const shot = SHOTS[s.shot];
    const tau = s.shot === "wide" && s.time - s.shotSince < 3 ? 1.2 : 3.2;
    for (const key of ["dist", "pitch", "fov"]) s.cam[key] = follow(s.cam[key], shot[key], dt, tau, tau);
    s.cam.yaw += dt * shot.rate * (1 + 1.5 * E) * (controls.freeze ? 0 : 1);

    // ---- grade ------------------------------------------------------------------------------------------
    s.exposure = (0.7 + 0.25 * E + 0.1 * s.flash - 0.25 * s.preDrop) * (controls.brightness ?? 1);
    s.saturation = 1.05 + 0.15 * E - 0.1 * B;
    s.phase = dropEvent ? "drop" : T > 0.3 ? "build" : B > 0.5 ? "breakdown" : E > 0.8 ? "peak" : "drive";
    return events;
  }

  function startSweep(to, duration) {
    if (to === s.world) to = (to + 1) % WORLDS.length;
    s.sweep = { from: s.world, to, h: 1.15, duration };
    s.nextWorld = to;
    s.convergeTarget += 5;
  }
  function nextRich(i) { return i === 3 ? 4 : 3; }

  return { state: s, pulses, step, reset, polytope, worlds: WORLDS, audioState: audioModel.state };
}

function diameterOf(poly) {
  const n = poly.vertices.length, d = graphDistances(poly);
  let m = 0;
  for (let i = 0; i < n; i += 1) m = Math.max(m, d[i]);
  return m;
}
export function antipode(poly, i) {
  const v = poly.vertices[i];
  let best = 0, bestD = Infinity;
  poly.vertices.forEach((u, j) => { const d = v4.len(v4.add(u, v)); if (d < bestD) { bestD = d; best = j; } });
  return best;
}
// Symmetric orientations: a vertex, an edge, a face or a cell centre facing the 4D viewpoint (+w).
export function criticalOrientation(poly, k) {
  const kinds = ["cell", "vertex", "face", "edge"];
  const kind = kinds[k % kinds.length];
  let u;
  if (kind === "vertex") u = poly.vertices[0];
  else if (kind === "edge") { const [i, j] = poly.edges[0]; u = v4.add(poly.vertices[i], poly.vertices[j]); }
  else if (kind === "face") u = poly.faces[0].vertices.reduce((acc, i) => v4.add(acc, poly.vertices[i]), [0, 0, 0, 0]);
  else u = poly.cells[0].centre;
  const qL = quat.conj(quat.norm(u));
  return { qL, qR: quat.identity(), kind };
}
