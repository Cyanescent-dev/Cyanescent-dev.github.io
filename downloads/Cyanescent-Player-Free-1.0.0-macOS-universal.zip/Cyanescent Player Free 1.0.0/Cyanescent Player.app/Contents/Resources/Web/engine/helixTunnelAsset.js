export const HELIX_TUNNEL_ID = 395;
export const HELIX_TUNNEL = Object.freeze({
  id: HELIX_TUNNEL_ID, name: "Helix Tunnel", assetRoot: "assets/forge/helix-tunnel",
  video: "helix-tunnel-1080p.mp4", durationSeconds: 3178 / 60, fps: 60, frames: 3178,
  width: 1920, height: 1080, fieldWidth: 240, fieldHeight: 135
});
