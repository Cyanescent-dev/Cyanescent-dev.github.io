function identifierFor(value) {
  return String(value ?? "");
}

function uniqueEntries(values) {
  const entries = [];
  const seen = new Set();
  for (const value of Array.isArray(values) ? values : []) {
    const key = identifierFor(value);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    entries.push({ key, value });
  }
  return entries;
}

// Keeps automatic choices fresh without deciding *which* eligible candidate is
// artistically best. Callers rank the returned candidates with their own music
// or energy-aware logic, then record the item only once it is actually used.
export function createDiversityCycle({ recentLimit = 3 } = {}) {
  let scopeKey = "";
  let used = new Set();
  let recent = [];

  function sync(values) {
    const entries = uniqueEntries(values);
    const nextScopeKey = entries.map((entry) => entry.key).sort().join("\u001f");
    const available = new Set(entries.map((entry) => entry.key));
    if (nextScopeKey !== scopeKey) {
      scopeKey = nextScopeKey;
      used = new Set();
      recent = [];
    } else {
      used = new Set([...used].filter((key) => available.has(key)));
      recent = recent.filter((key) => available.has(key));
    }
    return entries;
  }

  function candidates(values, { activeId = null } = {}) {
    const entries = sync(values);
    if (entries.length <= 1) return [];
    const activeKey = identifierFor(activeId);
    const activeIsEligible = entries.some((entry) => entry.key === activeKey);
    if (activeIsEligible) used.add(activeKey);

    let available = entries.filter((entry) => entry.key !== activeKey && !used.has(entry.key));
    if (available.length) return available.map((entry) => entry.value);

    // The cycle has been exhausted. Start a new one, but never immediately
    // revisit the current item or any of the three most recently shown items.
    used.clear();
    if (activeIsEligible) used.add(activeKey);
    const excluded = new Set([activeKey, ...recent]);
    available = entries.filter((entry) => !excluded.has(entry.key));
    if (!available.length) {
      available = entries.filter((entry) => entry.key !== activeKey);
    }
    return available.map((entry) => entry.value);
  }

  function record(value, values) {
    const entries = sync(values);
    const key = identifierFor(value);
    if (!entries.some((entry) => entry.key === key)) return;
    used.add(key);
    recent = [key, ...recent.filter((recentKey) => recentKey !== key)].slice(0, Math.max(0, recentLimit));
  }

  function reset() {
    scopeKey = "";
    used.clear();
    recent = [];
  }

  return {
    candidates,
    record,
    reset,
    recentIds: () => recent.slice(),
    usedIds: () => [...used]
  };
}
