export function createImageTexture(gl, url, options = {}) {
  if (!gl) return null;
  const {
    flipY = true,
    minFilter = gl.LINEAR_MIPMAP_LINEAR,
    magFilter = gl.LINEAR,
    wrapS = gl.REPEAT,
    wrapT = gl.REPEAT,
    onLoad = null
  } = options;

  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 0]));

  const image = new Image();
  image.onload = () => {
    if (!gl) return;
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, Boolean(flipY));
    
    // WebKit WebGL cannot upload SVG Image elements directly. We must rasterize them first.
    let source = image;
    if (url.endsWith(".svg")) {
      const canvas = document.createElement("canvas");
      canvas.width = image.width || 2000;
      canvas.height = image.height || 2000;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
      source = canvas;
    }
    
    try {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, magFilter);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrapS);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrapT);
    } catch (err) {
      console.error("Texture upload error", err);
    }
    onLoad?.(image, texture);
  };
  
  if (url.endsWith(".svg") && !url.startsWith("data:")) {
    fetch(url)
      .then(res => res.text())
      .then(text => {
        image.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(text);
      })
      .catch(err => {
        console.error("Failed to fetch SVG", err);
        image.src = url; // Fallback
      });
  } else {
    image.src = url;
  }
  
  return texture;
}
