let transitionSequence = 0;

export function nextTransitionDiagnosticId() {
  transitionSequence += 1;
  return `transition-${transitionSequence}`;
}

export function transitionDiagnosticId(transition) {
  if (!transition?.active) return "none";
  return transition.diagnosticId || `${transition.from ?? "?"}-${transition.to ?? "?"}-${Math.round(Number(transition.start) || 0)}`;
}

export function createGpuTimerCollector(gl, { enabled = () => false, maxPending = 96 } = {}) {
  let extension = null;
  let extensionChecked = false;
  let active = null;
  const pending = [];
  let disabledReason = "";

  function getExtension() {
    if (extensionChecked) return extension;
    extensionChecked = true;
    try {
      extension = gl?.getExtension?.("EXT_disjoint_timer_query_webgl2") || null;
      if (!extension) disabledReason = "EXT_disjoint_timer_query_webgl2 unavailable";
    } catch (error) {
      disabledReason = error?.message || "GPU timer extension lookup failed";
      extension = null;
    }
    return extension;
  }

  function begin(stage, diagnosticId, frameNumber) {
    if (!enabled?.() || active || !getExtension()) return null;
    try {
      const query = gl.createQuery();
      gl.beginQuery(extension.TIME_ELAPSED_EXT, query);
      active = { query, stage, diagnosticId, frameNumber };
      return active;
    } catch (error) {
      disabledReason = error?.message || "GPU timer query begin failed";
      active = null;
      return null;
    }
  }

  function end(token) {
    if (!token || token !== active) return;
    try {
      gl.endQuery(extension.TIME_ELAPSED_EXT);
      pending.push(token);
      while (pending.length > maxPending) {
        const stale = pending.shift();
        gl.deleteQuery?.(stale.query);
      }
    } catch (error) {
      disabledReason = error?.message || "GPU timer query end failed";
      gl.deleteQuery?.(token.query);
    } finally {
      active = null;
    }
  }

  function poll() {
    if (!extension || !pending.length) return [];
    const completed = [];
    let disjoint = false;
    try {
      disjoint = Boolean(gl.getParameter(extension.GPU_DISJOINT_EXT));
    } catch {}
    for (let index = pending.length - 1; index >= 0; index -= 1) {
      const item = pending[index];
      let available = false;
      try {
        available = Boolean(gl.getQueryParameter(item.query, gl.QUERY_RESULT_AVAILABLE));
      } catch {}
      if (!available) continue;
      pending.splice(index, 1);
      try {
        const elapsedNanoseconds = Number(gl.getQueryParameter(item.query, gl.QUERY_RESULT)) || 0;
        if (!disjoint) completed.push({
          stage: item.stage,
          diagnosticId: item.diagnosticId,
          frameNumber: item.frameNumber,
          gpuMs: elapsedNanoseconds / 1_000_000
        });
      } finally {
        gl.deleteQuery?.(item.query);
      }
    }
    return completed.reverse();
  }

  return {
    begin,
    end,
    poll,
    supported: () => Boolean(getExtension()),
    disabledReason: () => disabledReason
  };
}

export function formatDiagnosticFields(fields = {}) {
  return Object.entries(fields)
    .filter(([, value]) => value !== undefined && value !== null && value !== "")
    .map(([key, value]) => `${key}=${typeof value === "number" ? value.toFixed(1) : String(value).replaceAll(" ", "_")}`)
    .join(" ");
}
