const WORLDSHELL_PRESET_ID = 193;

function numberParam(params, name, fallback, minimum, maximum) {
  const rawValue = params.get(name);
  if (rawValue === null || rawValue === "") return fallback;
  const value = Number(rawValue);
  if (!Number.isFinite(value)) return fallback;
  return Math.max(minimum, Math.min(maximum, value));
}

function aggregateStage(target, stages = {}) {
  for (const [name, value] of Object.entries(stages)) {
    const elapsed = Number(value) || 0;
    const stage = target[name] || { count: 0, totalMs: 0, maxMs: 0 };
    stage.count += 1;
    stage.totalMs += elapsed;
    stage.maxMs = Math.max(stage.maxMs, elapsed);
    target[name] = stage;
  }
}

function summaryStages(stages) {
  return Object.fromEntries(Object.entries(stages).map(([name, stage]) => [name, {
    samples: stage.count,
    averageMs: stage.count ? Number((stage.totalMs / stage.count).toFixed(3)) : 0,
    maxMs: Number(stage.maxMs.toFixed(3))
  }]));
}

export function worldshellBenchmarkConfig(search = window.location.search) {
  const params = new URLSearchParams(search);
  const enabled = params.get("worldshellBenchmark") === "1";
  const requestedTarget = params.get("worldshellBenchmarkTarget");
  return {
    enabled,
    target: requestedTarget === "primary" ? "primary" : "secondary",
    durationMs: numberParam(params, "worldshellBenchmarkDuration", 30000, 5000, 120000),
    warmupMs: numberParam(params, "worldshellBenchmarkWarmup", 3000, 0, 30000)
  };
}

export function createWorldshellBenchmark({ config = worldshellBenchmarkConfig(), onComplete } = {}) {
  let state = null;

  function start(context = {}) {
    if (!config.enabled || state?.running) return false;
    state = {
      running: true,
      finishingFrames: 0,
      startedAt: 0,
      firstSampleAt: 0,
      lastSampleAt: 0,
      frames: 0,
      frameGapTotalMs: 0,
      frameGapMinMs: Infinity,
      frameGapMaxMs: 0,
      totalMs: 0,
      renderMs: 0,
      cpuStages: {},
      gpuStages: {},
      invalidFrames: 0,
      timer: "unreported",
      context: { ...context }
    };
    return true;
  }

  function onFrame({ now, frameGapMs, totalMs, renderMs, activePreset, transition, renderDiagnostics, context = {} } = {}) {
    if (!state?.running) return null;
    const elapsed = Number(now) - state.startedAt;
    if (!state.startedAt) {
      state.startedAt = Number(now);
      return null;
    }
    if (elapsed < config.warmupMs) return null;
    if (!state.firstSampleAt) state.firstSampleAt = Number(now);
    state.lastSampleAt = Number(now);
    state.context = { ...state.context, ...context };
    state.timer = renderDiagnostics?.gpuTimerSupported
      ? "supported"
      : (renderDiagnostics?.gpuTimerReason || state.timer);
    if (Number(activePreset) !== WORLDSHELL_PRESET_ID || transition?.active) state.invalidFrames += 1;
    const gap = Math.max(0, Number(frameGapMs) || 0);
    if (gap > 0) {
      state.frames += 1;
      state.frameGapTotalMs += gap;
      state.frameGapMinMs = Math.min(state.frameGapMinMs, gap);
      state.frameGapMaxMs = Math.max(state.frameGapMaxMs, gap);
      state.totalMs += Number(totalMs) || 0;
      state.renderMs += Number(renderMs) || 0;
      aggregateStage(state.cpuStages, renderDiagnostics?.cpuStages);
    }
    for (const result of renderDiagnostics?.gpuResults || []) {
      if (!result?.stage) continue;
      aggregateStage(state.gpuStages, { [result.stage]: result.gpuMs });
    }

    if (elapsed < config.durationMs) return null;
    state.finishingFrames += 1;
    if (state.finishingFrames < 45) return null;
    state.running = false;
    const sampleDurationMs = Math.max(1, state.lastSampleAt - state.firstSampleAt);
    const result = {
      event: "worldshell_benchmark",
      target: config.target,
      preset: WORLDSHELL_PRESET_ID,
      warmupMs: config.warmupMs,
      sampleDurationMs,
      frames: state.frames,
      averageFps: Number((state.frames * 1000 / sampleDurationMs).toFixed(2)),
      averageFrameMs: Number((state.frameGapTotalMs / Math.max(1, state.frames)).toFixed(3)),
      minFps: Number((1000 / Math.max(1, state.frameGapMaxMs)).toFixed(2)),
      maxFps: Number((1000 / Math.max(1, state.frameGapMinMs)).toFixed(2)),
      averageCpuTotalMs: Number((state.totalMs / Math.max(1, state.frames)).toFixed(3)),
      averageCpuRenderMs: Number((state.renderMs / Math.max(1, state.frames)).toFixed(3)),
      invalidFrames: state.invalidFrames,
      gpuTimer: state.timer,
      cpuStages: summaryStages(state.cpuStages),
      gpuStages: summaryStages(state.gpuStages),
      ...state.context
    };
    onComplete?.(result);
    return result;
  }

  return {
    config,
    start,
    onFrame,
    isRunning: () => Boolean(state?.running)
  };
}

export function worldshellBenchmarkLogLine(result = {}) {
  return `worldshell_benchmark\t${JSON.stringify(result)}`;
}
