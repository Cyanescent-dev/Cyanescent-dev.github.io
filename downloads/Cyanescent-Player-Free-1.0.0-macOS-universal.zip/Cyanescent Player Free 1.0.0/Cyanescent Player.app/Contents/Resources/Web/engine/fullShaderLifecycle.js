import {
  FullShaderCompiler,
  fullShaderBusyDelay,
  fullShaderIsBusy,
  fullShaderScheduleIsBusy
} from "./fullShaderCompiler.js";

export function createFullShaderLifecycle({
  ui,
  ensureWebGl,
  vertexSource,
  fragmentSource,
  compileFullscreenProgram,
  warmupDrawCall,
  renderMode,
  offlineRenderMode,
  isPlaying,
  getLastUserInteractionAt,
  idleGraceMs = 15000,
  getReady,
  getProgram,
  setProgram,
  setRenderProgram,
  setShellActive,
  setReady,
  setErrorText,
  clearFeedbackBuffers,
  hasFeedbackBuffers,
  visualsReady,
  visualFallbackActive
}) {
  let compiler = null;

  function isBusy() {
    return fullShaderIsBusy({
      renderMode: renderMode(),
      offlineRenderMode,
      isPlaying
    });
  }

  function isScheduleBusy() {
    return fullShaderScheduleIsBusy({
      renderMode: renderMode(),
      offlineRenderMode,
      isPlaying,
      lastUserInteractionAt: getLastUserInteractionAt(),
      idleGraceMs
    });
  }

  function busyDelay() {
    return fullShaderBusyDelay(isPlaying);
  }

  function createCompiler() {
    const gl = ensureWebGl();
    return new FullShaderCompiler({
      gl,
      vertexSource,
      fragmentSource,
      bindings: [[0, "position"]],
      isBusy,
      isScheduleBusy,
      busyDelay,
      onUnsupported: () => {
        ui.audioDiagnostic.textContent = "Fast visual shell active; full shader async compile is unavailable on this WebView.";
      },
      onCompiling: () => {
        ui.audioDiagnostic.textContent = "Fast visual shell active; preparing full visual engine in the background...";
      },
      onReady: (compiledProgram) => {
        setProgram(compiledProgram);
        warmupDrawCall(compiledProgram);
        setRenderProgram(compiledProgram);
        setShellActive(false);
        setReady(true);
        if (hasFeedbackBuffers?.()) clearFeedbackBuffers?.();
        if (visualsReady?.() && !visualFallbackActive?.()) {
          ui.audioStatus.textContent = isPlaying?.() ? "player audio" : "player ready";
          ui.audioDiagnostic.textContent = "Full visual engine ready";
        }
      },
      onFailed: (message) => {
        setErrorText(message);
        ui.audioStatus.textContent = "visual shell";
        ui.audioDiagnostic.textContent = `Full shader unavailable: ${message}`;
        console.error(message);
      }
    });
  }

  function getCompiler() {
    if (!compiler) compiler = createCompiler();
    return compiler;
  }

  function start() {
    if (getReady?.()) return;
    getCompiler().start();
  }

  function schedule(delay = 1200) {
    if (getReady?.()) return;
    getCompiler().schedule(delay);
  }

  function markSynchronousReady() {
    const compiled = compileFullscreenProgram(fragmentSource);
    getCompiler().markSynchronousReady(compiled);
  }

  function waitUntilReady(timeoutMs = 90000, errorText = "") {
    if (getReady?.() && getProgram?.()) return Promise.resolve();
    return getCompiler().waitUntilReady(timeoutMs, errorText);
  }

  function status() {
    return getCompiler().status();
  }

  return {
    getCompiler,
    start,
    schedule,
    markSynchronousReady,
    waitUntilReady,
    status
  };
}
