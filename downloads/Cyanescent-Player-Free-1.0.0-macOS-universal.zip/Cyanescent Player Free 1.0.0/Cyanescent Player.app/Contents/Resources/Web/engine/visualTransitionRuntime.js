import { enforceTransitionCapabilities, runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
import { createVisualTransitionController } from "./visualTransitionController.js";
import {
  createInactivePresetTransition,
  VisualTransitionMode
} from "./transitions.js";

export function createVisualTransitionRuntime({
  presetSelection,
  initialPreset,
  initialMode = VisualTransitionMode.STATIC,
  initialShuffleSeconds = 45,
  getActivePreset,
  setActivePreset,
  getActivePresetStartedAt,
  setActivePresetStartedAt,
  getPlayerMode,
  getPlayerAudio,
  getAnalysisTimeline,
  getMusicAwareState,
  getLookaheadState,
  getLiveInputState,
  getAdaptiveTimingPreset,
  getAdaptivePresetExactPlaySeconds,
  getAdaptivePresetMinimumPlaySeconds,
  presetMetadata,
  presetMetadataById,
  onPresetCandidate,
  onActivePresetChanged,
  getTransitionTiming,
  shouldDeferAutoTransition,
  now = () => performance.now()
}) {
  let visualTransitionMode = initialMode || VisualTransitionMode.STATIC;
  let transition = createInactivePresetTransition(initialPreset);
  let nextShuffleAt = now() + Number(initialShuffleSeconds || 45) * 1000;

  const controller = createVisualTransitionController({
    presetSelection,
    getTransition: () => transition,
    setTransition: (value) => {
      transition = enforceTransitionCapabilities({ ...value });
      if (transition.active && (!runtimeAllowsPreset(transition.from) || !runtimeAllowsPreset(transition.to))) {
        transition = createInactivePresetTransition(presetSelection.normalizePresetId(getActivePreset()));
      }
    },
    getActivePreset,
    setActivePreset,
    getActivePresetStartedAt,
    setActivePresetStartedAt,
    getVisualTransitionMode: () => visualTransitionMode,
    getNextShuffleAt: () => nextShuffleAt,
    setNextShuffleAt: (value) => {
      nextShuffleAt = value;
    },
    getPlayerMode,
    getPlayerAudio,
    getAnalysisTimeline,
    getMusicAwareState,
    getLookaheadState,
    getLiveInputState,
    getAdaptiveTimingPreset,
    getAdaptivePresetExactPlaySeconds,
    getAdaptivePresetMinimumPlaySeconds,
    presetMetadata,
    presetMetadataById,
    shouldDeferAutoTransition,
    onPresetCandidate,
    onActivePresetChanged,
    getTransitionTiming,
    now
  });

  function resetShuffleTimer() {
    nextShuffleAt = now() + controller.shuffleIntervalMs();
  }

  function setTransitionMode(value) {
    visualTransitionMode = value || VisualTransitionMode.STATIC;
    resetShuffleTimer();
    controller.resetAdaptive();
  }

  function setStaticTransitionMode() {
    setTransitionMode(VisualTransitionMode.STATIC);
  }

  function setPresetImmediate(presetId) {
    transition.active = false;
    if (!runtimeAllowsPreset(presetId)) return false;
    const preset = presetSelection.normalizePresetId(presetId);
    setActivePreset(preset);
    setActivePresetStartedAt(now());
    controller.notePresetActivated(preset);
    onActivePresetChanged?.(preset);
    if (visualTransitionMode === VisualTransitionMode.ADAPTIVE) {
      controller.markAdaptivePresetStarted(getPlayerAudio?.()?.currentTime || 0);
    }
  }

  return {
    getTransition: () => transition,
    setTransition: (value) => {
      transition = enforceTransitionCapabilities({ ...value });
      if (transition.active && (!runtimeAllowsPreset(transition.from) || !runtimeAllowsPreset(transition.to))) {
        transition = createInactivePresetTransition(presetSelection.normalizePresetId(getActivePreset()));
      }
    },
    getTransitionMode: () => visualTransitionMode,
    setTransitionMode,
    resetShuffleTimer,
    setStaticTransitionMode,
    setPresetImmediate,
    normalizePresetId: controller.normalizePresetId,
    presetIds: controller.presetIds,
    presetCount: controller.presetCount,
    adaptiveEligiblePresetIds: controller.adaptiveEligiblePresetIds,
    shuffleIntervalMs: controller.shuffleIntervalMs,
    chooseNextPreset: controller.chooseNextPreset,
    begin: controller.begin,
    updatePreset: controller.updatePreset,
    updateVisual: controller.updateVisual,
    // How far off the next automatic shuffle is, so callers can tell whether
    // the visualiser is mid-preset or about to change.
    nextShuffleAt: () => nextShuffleAt,
    resetAdaptive: controller.resetAdaptive,
    markAdaptivePresetStarted: controller.markAdaptivePresetStarted,
    notePresetActivated: controller.notePresetActivated,
    setAdaptiveTimingPreset: controller.setAdaptiveTimingPreset,
    getLiveAdaptiveStatus: controller.getLiveAdaptiveStatus,
    handleSeek: controller.handleSeek
  };
}
