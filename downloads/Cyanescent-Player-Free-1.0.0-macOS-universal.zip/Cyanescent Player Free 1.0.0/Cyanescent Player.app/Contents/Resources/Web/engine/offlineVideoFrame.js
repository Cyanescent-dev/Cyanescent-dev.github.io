// A paused media element must finish its seek before its pixels may be captured.
// currentTime alone changes before decoding does. No playback or fixed sleep is
// used; timeout/error rejects the export instead of silently repeating a frame.
function waitForMedia(video, events, ready, timeoutMs, start = null) {
  if (video.error) return Promise.reject(new Error(`Offline video decode failed (${video.error.code})`));
  if (!start && ready()) return Promise.resolve();
  return new Promise((resolve, reject) => {
    let timer, started = false;
    const cleanup = () => { clearTimeout(timer); for (const event of [...events, "error"]) video.removeEventListener(event, check); };
    const check = () => {
      if (video.error) { cleanup(); reject(new Error(`Offline video decode failed (${video.error.code})`)); }
      else if (started && ready()) { cleanup(); resolve(); }
    };
    for (const event of [...events, "error"]) video.addEventListener(event, check);
    timer = setTimeout(() => { cleanup(); reject(new Error("Offline video frame readiness timed out")); }, timeoutMs);
    try { start?.(); started = true; check(); }
    catch (error) { cleanup(); reject(error); }
  });
}

export async function seekOfflineVideoFrame(video, time, { fps = 30, timeoutMs = 15000 } = {}) {
  video.pause();
  await waitForMedia(video, ["loadedmetadata", "loadeddata", "canplay"], () => video.readyState >= 2, timeoutMs);
  const frame = Math.max(0, Math.floor(Math.max(0, Number(time) || 0) * fps + 1e-6));
  const last = Number.isFinite(video.duration) ? Math.max(0, Math.ceil(video.duration * fps) - 1) : frame;
  const target = Math.min(frame, last) / fps;
  if (Math.abs(video.currentTime - target) > 1e-6 || video.seeking) {
    // Install the listener before assigning currentTime; seeked guarantees a
    // decoded frame for the new playback position, including backwards seeks.
    await waitForMedia(video, ["seeked", "loadeddata"],
      () => !video.seeking && video.readyState >= 2 && Math.abs(video.currentTime - target) < 1e-5,
      timeoutMs, () => { video.currentTime = target; });
  }
  return { requestedTime: target, mediaTime: video.currentTime, frame: Math.min(frame, last) };
}

// Integrate the live Forge player's rate slew from 1x to a stable track tempo.
// This maps preset time to media time without asking real-time playback to run.
export function offlineVideoPlaybackAt(time, targetRate, slew = .14) {
  const elapsed = Math.max(0, Number(time) || 0);
  const change = targetRate - 1;
  const rampDuration = Math.abs(change) / slew;
  const ramp = Math.min(elapsed, rampDuration);
  return { time: elapsed + Math.sign(change) * slew * ramp * ramp / 2 + change * Math.max(0, elapsed - rampDuration),
    rate: 1 + Math.sign(change) * slew * ramp };
}
