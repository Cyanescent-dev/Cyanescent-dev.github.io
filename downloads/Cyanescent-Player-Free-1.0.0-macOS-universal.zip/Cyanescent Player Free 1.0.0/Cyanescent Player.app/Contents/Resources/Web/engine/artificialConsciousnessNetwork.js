// Artificial Consciousness: the Forge world's network, rebuilt in JS. Pure functions, no DOM and
// no WebGL, so the compiler, tools/test-artificial-consciousness.mjs and the runtime share them.
//
// The export (`ArtificialConsciousness_Field_Export`) ships topology.bin once (every node and every
// connection) and, per frame, the Forge's GPU header (stage, entity frame, clocks, lobes ...) plus
// the camera. Every node position then follows from `acPlace`; this file is a line-for-line port of
// ForgeArtificialConsciousness.h (acPlace, acEdgeGeometry, acProject) and of ACHash. The runtime
// evaluates the same maths in GLSL (artificialConsciousnessShaders.js); this JS version is the
// reference that tests compare the export's own key-node and pathway records against.

export const AC = Object.freeze({
  RIN: 5.0, ROUT: 44.0, DOME: 9.0, GAP_PLANE: 1.6, TILE: 13.0,
  SUBSTRATE_FADE0: 165.0, SUBSTRATE_FADE1: 228.0
});

// Edge kinds (ACEdge* in ForgeShaderTypes.h).
export const EDGE = Object.freeze({
  RING: 0, FAN: 1, BRIDGE: 2, HUB_STAR: 3, HUB_LINK: 4, REGION: 5, LONG: 6, SPOKE: 7, SUB_RING: 8, SUB_FAN: 9,
  SUB_BUS: 10, TETHER: 11, META: 12, REACH: 13, SATELLITE: 14, CORE: 15, ATTENTION: 16
});
export const EDGE_KIND_COUNT = 17;
export const EDGE_OPTIONAL_BIT = 1 << 16;

export const TOPOLOGY_MAGIC = 0x31544341; // 'ACT1'
export const NODE_FLOATS = 12;

const TAU = Math.PI * 2;
export const sat = (x) => Math.min(Math.max(x, 0), 1);
export const smoother = (x) => { const t = sat(x); return t * t * t * (t * (t * 6 - 15) + 10); };
export const smoothstep = (a, b, x) => { const t = sat((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const wrapAngle = (d) => d - TAU * Math.floor((d + Math.PI) / TAU);

// ------------------------------------------------------------------ hashing (forgeHashU32 / Combine)
export function hashU32(value) {
  let v = value >>> 0;
  v ^= v >>> 17; v = Math.imul(v, 0xed5ad4bb) >>> 0;
  v ^= v >>> 11; v = Math.imul(v, 0xac4c1b51) >>> 0;
  v ^= v >>> 15; v = Math.imul(v, 0x31848bab) >>> 0;
  v ^= v >>> 14;
  return v >>> 0;
}
export function hashCombine(a, b) {
  a >>>= 0; b >>>= 0;
  return hashU32((a ^ (((b + 0x9e3779b9) >>> 0) + ((a << 6) >>> 0) + (a >>> 2))) >>> 0);
}
export const hashUnit = (v) => (hashU32(v) & 0x00ffffff) / 16777216;
export const hashUnit2 = (a, b) => hashUnit(hashCombine(a, b));

// ------------------------------------------------------------------ topology.bin
export function parseTopology(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const header = [];
  for (let i = 0; i < 16; i += 1) header.push(view.getUint32(i * 4, true));
  if (header[0] !== TOPOLOGY_MAGIC || header[1] !== 1) throw new Error("topology.bin: unrecognised header");
  const [, , nodeCount, edgeCount, keyCount, pathCount, seed, complexityBits, entityCount, substrateCount, bloomCount, nodeBytes, edgeBytes] = header;
  if (nodeBytes !== NODE_FLOATS * 4 || edgeBytes !== 16) throw new Error("topology.bin: unexpected record sizes");
  let at = 64;
  const aligned = new Uint8Array(nodeCount * nodeBytes);
  aligned.set(bytes.subarray(at, at + aligned.length));
  const nodes = new Float32Array(aligned.buffer);
  at += aligned.length;
  const edgeRaw = new Uint8Array(edgeCount * edgeBytes);
  edgeRaw.set(bytes.subarray(at, at + edgeRaw.length));
  const edges = new Uint32Array(edgeRaw.buffer);
  const edgeRank = new Float32Array(edgeRaw.buffer);
  at += edgeRaw.length;
  const readList = (count) => {
    const raw = new Uint8Array(count * 4);
    raw.set(bytes.subarray(at, at + raw.length));
    at += raw.length;
    return new Uint32Array(raw.buffer);
  };
  const keyNodes = readList(keyCount);
  const pathEdges = readList(pathCount);
  const complexity = new DataView(new ArrayBuffer(4));
  complexity.setUint32(0, complexityBits, true);
  return {
    nodeCount, edgeCount, seed, complexity: complexity.getFloat32(0, true), entityCount, substrateCount, bloomCount,
    nodes, edges, edgeRank, keyNodes, pathEdges
  };
}

// Node field accessors (ACNode: plane = x z r theta, attr = shell kind region phase, extra = module ring importance birth).
export const nodeShell = (t, i) => t.nodes[i * NODE_FLOATS + 4];
export const nodeKind = (t, i) => t.nodes[i * NODE_FLOATS + 5];
export const edgeA = (t, e) => t.edges[e * 4];
export const edgeB = (t, e) => t.edges[e * 4 + 1];
export const edgeKind = (t, e) => t.edges[e * 4 + 2] & 0xff;
export const edgeFlags = (t, e) => t.edges[e * 4 + 2];
export const edgeRegion = (t, e) => ((t.edges[e * 4 + 2] >>> 8) & 0xff) - 1;

// ------------------------------------------------------------------ frame state (the Forge's ACHeader)
const v4 = (a, fallback = 0) => [a?.[0] ?? fallback, a?.[1] ?? fallback, a?.[2] ?? fallback, a?.[3] ?? fallback];

// One frame's header + camera from a metadata.jsonl line (the export's own JSON), as plain numbers.
export function frameStateFromMetadata(meta) {
  const h = meta.world.header, c = meta.camera;
  return {
    seed: h.seed >>> 0,
    stage: v4(h.stage), awake: v4(h.awake), trans: v4(h.trans), torus: v4(h.torus), disc: v4(h.disc),
    centre: v4(h.centre), axisX: v4(h.axisX), axisY: v4(h.axisY), axisZ: v4(h.axisZ), attention: v4(h.attention),
    clocks: v4(h.clocks), look: v4(h.look), look2: v4(h.look2), warp: v4(h.warp), flow: v4(h.flow), aperture: v4(h.aperture),
    lobeAngle: [...v4(h.lobeAngle0), ...v4(h.lobeAngle1)], lobeAmp: [...v4(h.lobeAmp0), ...v4(h.lobeAmp1)],
    lobeWidth: [...v4(h.lobeWidth0), ...v4(h.lobeWidth1, 1)],
    regionCount: 6,
    camera: {
      position: c.position, forward: c.forward, right: c.right, up: c.up,
      tanHalfFov: c.tanHalfVerticalFOV, aspect: c.aspect, width: meta.resolution.beauty[0], height: meta.resolution.beauty[1]
    }
  };
}

// ------------------------------------------------------------------ small vector helpers
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const len3 = (a) => Math.hypot(a[0], a[1], a[2]);
const norm3 = (a) => { const l = len3(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const dist3 = (a, b) => len3(sub(a, b));
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const rotateAxis = (v, axis, angle) => {
  const c = Math.cos(angle), s = Math.sin(angle), k = cross(axis, v), d = dot(axis, v);
  return [v[0] * c + k[0] * s + axis[0] * d * (1 - c), v[1] * c + k[1] * s + axis[1] * d * (1 - c), v[2] * c + k[2] * s + axis[2] * d * (1 - c)];
};

function lobe(h, theta) {
  let sum = 0;
  for (let q = 0; q < Math.min(h.regionCount, 8); q += 1) {
    const d = wrapAngle(theta - h.lobeAngle[q]) / Math.max(h.lobeWidth[q], 1e-3);
    sum += h.lobeAmp[q] * Math.exp(-d * d);
  }
  return sum - 0.55;
}
const toWorld = (h, l) => [
  h.centre[0] + (h.axisX[0] * l[0] + h.axisY[0] * l[1] + h.axisZ[0] * l[2]) * h.centre[3],
  h.centre[1] + (h.axisX[1] * l[0] + h.axisY[1] * l[1] + h.axisZ[1] * l[2]) * h.centre[3],
  h.centre[2] + (h.axisX[2] * l[0] + h.axisY[2] * l[1] + h.axisZ[2] * l[2]) * h.centre[3]
];
const toLocal = (h, p) => {
  const s = Math.max(h.centre[3], 1e-4);
  const d = [(p[0] - h.centre[0]) / s, (p[1] - h.centre[1]) / s, (p[2] - h.centre[2]) / s];
  return [dot(d, h.axisX), dot(d, h.axisY), dot(d, h.axisZ)];
};
const attentionLocal = (h) => [dot(h.attention, h.axisX), dot(h.attention, h.axisY), dot(h.attention, h.axisZ)];
function flare(h, l) {
  const beta = h.axisX[3];
  if (beta <= 0) return l;
  const u = dot(l, attentionLocal(h)) / Math.max(h.axisY[3], 1);
  const d = Math.max(1 - beta * u, 0.35);
  return [l[0] / d, l[1] / d, l[2] / d];
}

function hexCentre(px, pz, size) {
  const q = (0.57735026919 * px - 0.33333333333 * pz) / size;
  const r = (0.66666666667 * pz) / size;
  const x = q, z = r, y = -x - z;
  let rx = Math.round(x), ry = Math.round(y), rz = Math.round(z);
  const dx = Math.abs(rx - x), dy = Math.abs(ry - y), dz = Math.abs(rz - z);
  if (dx > dy && dx > dz) rx = -ry - rz; else if (dy > dz) ry = -rx - rz; else rz = -rx - ry;
  return [size * 1.73205080757 * (rx + rz * 0.5), size * 1.5 * rz];
}
// Substrate and scaffold: in the plane until the transcendence's peel front reaches their tile.
function peel(h, px, pz) {
  const front = h.trans[2];
  const flat = [px, 0, pz];
  if (front <= 0) return { position: flat, presence: 1 };
  const [cx, cz] = hexCentre(px, pz, AC.TILE);
  const tr = Math.hypot(cx, cz);
  const hx = (Math.floor(cx * 8) | 0) >>> 0, hz = (Math.floor(cz * 8) | 0) >>> 0;
  const jit = hashUnit(hashCombine((h.seed ^ 0x5eed) >>> 0, ((Math.imul(hx, 73856093)) ^ (Math.imul(hz, 19349663))) >>> 0));
  const u = sat((front - tr - jit * 16) / 36);
  if (u <= 0) return { position: flat, presence: 1 };
  const radial = tr > 1e-3 ? [cx / tr, cz / tr] : [1, 0];
  const axis = norm3([-radial[1], 0, radial[0]]);
  const angle = u * u * (1.1 + jit * 1.6) * (jit > 0.5 ? 1 : -1);
  const rel = rotateAxis([px - cx, 0, pz - cz], axis, angle);
  const centre = [cx + radial[0] * u * u * 18, -u * u * 75, cz + radial[1] * u * u * 18];
  return { position: [centre[0] + rel[0], centre[1] + rel[1], centre[2] + rel[2]], presence: 1 - 0.72 * smoothstep(0.35, 1, u) };
}

function placeBloom(h, n, o) {
  const structure = Math.round(n[8]);
  const u = n[2], phi = n[3];
  const g = sat((h.trans[0] - n[11]) / 0.35);
  const rhoT = h.torus[1], rT = h.torus[0], expand = h.trans[1], spin = h.look2[2];
  let local, presence;
  if (structure === 0) {
    const rMeta = (2.3 + 0.16 * u) * rhoT * (1 + 0.6 * expand);
    const thetaM = h.lobeAngle[0] + spin * 0.5;
    const radial = rT + rMeta * Math.cos(phi);
    local = [radial * Math.cos(thetaM), rMeta * Math.sin(phi), radial * Math.sin(thetaM)];
    presence = sat((g * Math.PI * 1.02 - Math.abs(wrapAngle(phi - Math.PI))) / 0.25);
  } else {
    const j = hashCombine(h.seed, structure);
    const a1 = TAU * (structure / 5 + 0.15 * hashUnit2(j, 0xb1));
    const a2 = 0.35 + 0.9 * hashUnit2(j, 0xb2);
    const nrm = [Math.sin(a2) * Math.cos(a1), Math.cos(a2), Math.sin(a2) * Math.sin(a1)];
    const radius = (rT + rhoT) * (1.3 + 0.13 * structure) * (1 + 0.3 * expand);
    let e1 = [-nrm[0] * nrm[1], 1 - nrm[1] * nrm[1], -nrm[2] * nrm[1]];
    e1 = len3(e1) > 1e-6 ? norm3(e1) : [1, 0, 0];
    const e2 = cross(nrm, e1);
    local = [0, 1, 2].map((k) => (e1[k] * Math.cos(phi) + e2[k] * Math.sin(phi)) * radius + nrm[k] * (u - 0.5) * 1.6);
    presence = sat((g * Math.PI * 1.02 - Math.abs(wrapAngle(phi))) / 0.25);
  }
  o.position = toWorld(h, flare(h, local)); o.presence = presence; o.entity = 1; o.fold = 0; o.normal = [0, 0, 0];
  return o;
}

// acPlace: { position, presence, entity, fold, normal } of node `i`.
export function placeNode(h, topology, i, out = {}) {
  const n = topology.nodes.subarray(i * NODE_FLOATS, i * NODE_FLOATS + NODE_FLOATS);
  const shell = n[4], px = n[0], pz = n[1], r = n[2], theta = n[3];
  out.normal = [0, 0, 0]; out.fold = 0;
  if (shell < 0.5) {
    const p = peel(h, px, pz);
    out.position = p.position; out.presence = p.presence; out.entity = 0;
    return out;
  }
  if (shell > 4.5) return placeBloom(h, n, out);
  const F = h.stage[1];
  const rhoN = r / AC.ROUT;
  const eLocal = smoother(h.stage[0] * 1.6 - rhoN * 0.6);
  const spin = h.look2[2];
  const thetaS = theta + F * spin;
  const aperture = h.axisZ[3];
  let local, normalLocal = [0, 1, 0];
  if (shell > 3.5) {
    const hole = h.torus[0] - h.torus[1] - h.torus[2];
    const target = (0.34 + 0.56 * r / 4.2) * hole;
    const radius = r + (target - r) * aperture * F;
    const twist = F * spin + aperture * F * (0.9 - 0.5 * r / 4.2) + aperture * F * TAU * h.clocks[3] * 0.25;
    const ang = Math.atan2(pz, px) + twist;
    const q = r > 1e-6 ? [Math.cos(ang) * radius, Math.sin(ang) * radius] : [0, 0];
    let y = AC.DOME * eLocal * (1 - F) + F * h.torus[1] * 0.55 * aperture;
    if (r < 1e-6) y = AC.DOME * smoother(h.stage[0] * 1.6) * (1 - F) + F * h.torus[1] * 0.55 * aperture;
    local = [q[0], y, q[1]];
  } else {
    const shellOffset = shell - 2;
    const rMid = 0.5 * (AC.RIN + AC.ROUT), L = AC.ROUT - AC.RIN;
    const sN = (r - rMid) / L;
    const rhoT = h.torus[1], closure = h.torus[3];
    const A = F * TAU * closure;
    const lenF = L + (TAU * closure * rhoT - L) * F;
    const lb = lobe(h, theta);
    const a = sN * A + h.warp[1] * F * F * Math.sin(theta + h.warp[3]);
    let m, nm, rc = 0;
    if (A < 1e-3) { m = [sN * lenF, 0]; nm = [0, 1]; }
    else {
      rc = lenF / A;
      const sh = Math.sin(0.5 * a);
      m = [rc * Math.sin(a), rc * 2 * sh * sh];
      nm = [-Math.sin(a), Math.cos(a)];
    }
    const hShell = shellOffset * (AC.GAP_PLANE * eLocal + (h.torus[2] - AC.GAP_PLANE * eLocal) * F);
    m = [m[0] + nm[0] * hShell, m[1] + nm[1] * hShell];
    if (A >= 1e-3) {
      const k = 1 + F * F * lb;
      m = [m[0] * k, rc + (m[1] - rc) * k];
    }
    const rMaj = rMid + (h.torus[0] * (1 + F * h.warp[2] * Math.cos(2 * theta + h.warp[3]) + F * 0.18 * lb) - rMid) * F;
    const rhoXZ = rMaj + m[0];
    const dome = AC.DOME * (1 - rhoN * rhoN) * (1 - rhoN * rhoN) * eLocal * (1 - F);
    const ripple = 0.5 * Math.sin(rhoN * 9 - TAU * h.clocks[2] * 2) * eLocal * (1 - F) * h.stage[2];
    const y = -rhoT * F + m[1] + dome + ripple + F * h.warp[0] * Math.sin(2 * theta + h.warp[3] * 1.7);
    local = [rhoXZ * Math.cos(thetaS), y, rhoXZ * Math.sin(thetaS)];
    local[0] += (px - r * Math.cos(theta)) * (1 - F);
    local[2] += (pz - r * Math.sin(theta)) * (1 - F);
    const grow = 1 + h.trans[1] * (shell < 1.5 ? 0.12 : (shell < 2.5 ? 0.5 : 1.9));
    local = [local[0] * grow, local[1] * grow, local[2] * grow];
    const aS = A < 1e-3 ? 0 : a;
    normalLocal = [Math.sin(aS) * Math.cos(thetaS), -Math.cos(aS), Math.sin(aS) * Math.sin(thetaS)];
  }
  out.position = toWorld(h, flare(h, local));
  out.normal = [
    h.axisX[0] * normalLocal[0] + h.axisY[0] * normalLocal[1] + h.axisZ[0] * normalLocal[2],
    h.axisX[1] * normalLocal[0] + h.axisY[1] * normalLocal[1] + h.axisZ[1] * normalLocal[2],
    h.axisX[2] * normalLocal[0] + h.axisY[2] * normalLocal[1] + h.axisZ[2] * normalLocal[2]
  ];
  out.presence = shell > 3.5 ? (r < 1e-6 ? 1 - 0.85 * aperture : 1 - 0.7 * aperture) : 1;
  out.entity = sat(Math.max(eLocal, F) * 50);
  out.fold = shell > 3.5 ? 0 : F;
  return out;
}

// ------------------------------------------------------------------ edges
// Width / intensity per kind (acEdgeStyle).
export const EDGE_STYLE = [
  [0.050, 0.90], [0.045, 0.70], [0.035, 0.55], [0.035, 0.35], [0.050, 0.80], [0.070, 1.00], [0.085, 1.20], [0.100, 1.50],
  [0.040, 0.55], [0.035, 0.45], [0.075, 0.90], [0.030, 0.50], [0.080, 1.30], [0.085, 1.30], [0.070, 1.40], [0.060, 1.40], [0.060, 0.90]
];

// acEdgeGeometry: the curve (A, K, B quadratic Bezier), visibility and growth of edge `e`, given the
// placed nodes `states` (array of placeNode results).
export function edgeGeometry(h, topology, e, states) {
  const a = edgeA(topology, e), b = edgeB(topology, e), kind = edgeKind(topology, e), flags = edgeFlags(topology, e);
  const rank = topology.edgeRank[e * 4 + 3];
  const sa = states[a], sb = states[b];
  const [width, baseIntensity] = EDGE_STYLE[kind] || [0.05, 1];
  let intensity = baseIntensity;
  let A = sa.position, B = sb.position;
  let vis = Math.min(sa.presence, sb.presence);
  let growth = 1;
  const coh = h.stage[2], F = h.stage[1], tau = h.trans[0];
  const eh = hashCombine((h.seed ^ 0xed9e) >>> 0, e);
  if (flags & EDGE_OPTIONAL_BIT) vis *= sat((h.look[1] - hashUnit(eh)) / 0.04);
  switch (kind) {
    case EDGE.LONG: case EDGE.SPOKE: case EDGE.REGION: growth = sat((coh - rank) / 0.12); break;
    case EDGE.TETHER: vis *= 1 - smoothstep(0.55, 0.92, F); break;
    case EDGE.REACH: growth = sat((tau - rank) / 0.25); break;
    case EDGE.ATTENTION: growth = sat((coh - rank) / 0.15); break;
    default: break;
  }
  const awakeColour = h.awake[3], aperture = h.axisZ[3];
  if (kind === EDGE.RING || kind === EDGE.FAN || kind === EDGE.BRIDGE || kind === EDGE.HUB_STAR) intensity *= (1 + (0.5 - 1) * F) * (1 - 0.3 * awakeColour);
  else if (kind === EDGE.REGION || kind === EDGE.LONG) intensity *= 1 + (1.5 - 1) * F;
  if (kind === EDGE.CORE && F > 0) intensity *= 1 + (0.35 + (1 - 0.35) * aperture - 1) * F;
  if (kind === EDGE.HUB_LINK || kind === EDGE.HUB_STAR) {
    intensity *= 0.45 + (1 - 0.45) * smoothstep(0.1, 0.6, coh);
    if (topology.nodes[a * NODE_FLOATS + 4] < -0.5) intensity *= 0.55;
  }
  const mid = [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2, (A[2] + B[2]) / 2];
  const length = dist3(A, B);
  let outward = sub(mid, h.centre);
  outward = len3(outward) > 1e-4 ? norm3(outward) : [0, 1, 0];
  const arcLift = h.disc[3];
  const lm = toLocal(h, mid);
  const lxz = Math.hypot(lm[0], lm[2]);
  const ringDir = lxz > 1e-4 ? [lm[0] / lxz, lm[2] / lxz] : [1, 0];
  let tubeOut = [lm[0] - ringDir[0] * h.torus[0], lm[1], lm[2] - ringDir[1] * h.torus[0]];
  tubeOut = len3(tubeOut) > 1e-4 ? norm3(tubeOut) : [0, 1, 0];
  const tubeOutWorld = [0, 1, 2].map((k) => h.axisX[k] * tubeOut[0] + h.axisY[k] * tubeOut[1] + h.axisZ[k] * tubeOut[2]);
  const entityEdge = sa.entity > 0.5 && sb.entity > 0.5 && topology.nodes[a * NODE_FLOATS + 4] < 3.5;
  const foldBow = entityEdge ? tubeOutWorld : outward;
  let K = mid.slice();
  if (kind === EDGE.HUB_LINK || kind === EDGE.REGION) {
    K = [mid[0] + foldBow[0] * length * 0.32 * F, mid[1] + length * 0.08 * arcLift * (1 - F) + foldBow[1] * length * 0.32 * F, mid[2] + foldBow[2] * length * 0.32 * F];
  } else if (kind === EDGE.LONG || kind === EDGE.SPOKE || kind === EDGE.SUB_BUS) {
    const lift = kind === EDGE.SUB_BUS ? 0.5 : 1;
    K = [mid[0] + foldBow[0] * length * 0.6 * F, mid[1] + length * (0.06 + 0.3 * arcLift) * lift * (1 - F) + foldBow[1] * length * 0.6 * F, mid[2] + foldBow[2] * length * 0.6 * F];
  } else if (kind === EDGE.REACH) {
    const s = (length * 0.4 + 8 * h.centre[3]) * (0.6 + 0.4 * growth);
    K = [mid[0] + outward[0] * s, mid[1] + outward[1] * s, mid[2] + outward[2] * s];
  } else if (kind === EDGE.ATTENTION) {
    K = [mid[0] + foldBow[0] * length * 0.45, mid[1] + foldBow[1] * length * 0.45, mid[2] + foldBow[2] * length * 0.45];
    const conv = smoother((h.stage[3] - (0.17 + 0.2 * hashUnit(eh ^ 0x0c0d)) ) / 0.3);
    if (conv > 0) {
      const la = toLocal(h, A);
      const phi = Math.atan2(la[2], la[0]) + 0.7 + 0.3 * (hashUnit(eh ^ 0x4a11) - 0.5);
      const rim = [0, 1, 2].map((k) => h.aperture[k] + (h.axisX[k] * Math.cos(phi) + h.axisZ[k] * Math.sin(phi)) * h.aperture[3]);
      const dr = dist3(A, rim);
      const kc = [0, 1, 2].map((k) => rim[k] - h.axisY[k] * 0.55 * dr);
      B = [0, 1, 2].map((k) => B[k] + (rim[k] - B[k]) * conv);
      K = [0, 1, 2].map((k) => K[k] + (kc[k] - K[k]) * conv);
      growth = Math.max(growth, conv);
    }
    intensity *= 0.12 + 2.3 * conv;
  }
  return { A, K, B, vis, growth, kind, width, intensity };
}

export const bezier = (a, k, b, t) => {
  const u = 1 - t;
  return [0, 1, 2].map((i) => a[i] * u * u + k[i] * 2 * u * t + b[i] * t * t);
};

// acProject: pixel position (top-left origin) and view depth.
export function project(camera, p) {
  const c = sub(p, camera.position);
  const z = dot(c, camera.forward), x = dot(c, camera.right), y = dot(c, camera.up);
  const zs = Math.max(z, 1e-4);
  const ndcx = x / (zs * camera.aspect * camera.tanHalfFov), ndcy = y / (zs * camera.tanHalfFov);
  return { x: (ndcx + 1) * 0.5 * camera.width, y: (1 - ndcy) * 0.5 * camera.height, z };
}
export const toUv = (camera, p) => { const s = project(camera, p); return { u: s.x / camera.width, v: s.y / camera.height, depth: s.z }; };

// Place every node for one frame.
export function placeAll(h, topology) {
  const states = new Array(topology.nodeCount);
  for (let i = 0; i < topology.nodeCount; i += 1) states[i] = placeNode(h, topology, i, {});
  return states;
}
