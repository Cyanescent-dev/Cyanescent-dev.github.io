// Hypergeometry Engine: Dimensional Emergence (preset 398) — four-dimensional geometry (pure JS,
// no GL, testable).
//
// Regular convex 4-polytopes are generated from their vertex sets. The cells (3-faces) are found
// from the dual polytope: every dual vertex is the outward normal of one cell, and the cell's
// vertices are the polytope vertices furthest along it. Two cells sharing at least three vertices
// meet in a 2-face (a ridge); edges join nearest neighbours. Everything is normalised to
// circumradius 1.
//
// Rotations of R^4 are pairs of unit quaternions (qL, qR): v -> qL v qR, with the point
// (x, y, z, w) read as the quaternion w + x i + y j + z k. Left and right multiplication by
// exp(t u) are isoclinic rotations; together they reach every rotation in SO(4), all six planes,
// and two orientations can be interpolated smoothly by slerping each quaternion.

export const PHI = (1 + Math.sqrt(5)) / 2;
const EPS = 1e-6;

// ---- small vector helpers (4D) ----------------------------------------------------------------
export const v4 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2], a[3] - b[3]],
  scale: (a, k) => [a[0] * k, a[1] * k, a[2] * k, a[3] * k],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3],
  len: (a) => Math.hypot(a[0], a[1], a[2], a[3]),
  norm: (a) => { const l = Math.hypot(a[0], a[1], a[2], a[3]) || 1; return [a[0] / l, a[1] / l, a[2] / l, a[3] / l]; }
};

function signedCombos(base) {
  // every sign combination of the non-zero entries
  const out = [];
  const nz = base.map((x, i) => (Math.abs(x) > EPS ? i : -1)).filter((i) => i >= 0);
  for (let m = 0; m < 1 << nz.length; m += 1) {
    const v = base.slice();
    nz.forEach((idx, k) => { if ((m >> k) & 1) v[idx] = -v[idx]; });
    out.push(v);
  }
  return out;
}
function permutations(arr) {
  if (arr.length <= 1) return [arr.slice()];
  const out = [];
  arr.forEach((x, i) => { for (const rest of permutations(arr.slice(0, i).concat(arr.slice(i + 1)))) out.push([x, ...rest]); });
  return out;
}
const isEven = (perm) => {
  let inv = 0;
  for (let i = 0; i < perm.length; i += 1) for (let j = i + 1; j < perm.length; j += 1) if (perm[i] > perm[j]) inv += 1;
  return inv % 2 === 0;
};
function evenPermutations(arr) {
  const out = [];
  for (const p of permutations([0, 1, 2, 3])) if (isEven(p)) out.push(p.map((i) => arr[i]));
  return out;
}
function unique(points) {
  const seen = new Map();
  for (const p of points) {
    const key = p.map((x) => (Math.abs(x) < 1e-9 ? 0 : x).toFixed(6)).join(",");
    if (!seen.has(key)) seen.set(key, p);
  }
  return [...seen.values()];
}
const allSignedPerms = (base) => unique(permutations(base).flatMap(signedCombos));
const evenSignedPerms = (base) => unique(evenPermutations(base).flatMap(signedCombos));

// ---- vertex sets ----------------------------------------------------------------------------------
export function vertexSet(name) {
  const r5 = Math.sqrt(5), ip = 1 / PHI;
  switch (name) {
    case "tesseract": return signedCombos([1, 1, 1, 1]);
    case "16-cell": return allSignedPerms([1, 0, 0, 0]);
    case "24-cell": return allSignedPerms([1, 1, 0, 0]);
    case "24-cell-dual": return unique([...allSignedPerms([1, 0, 0, 0]), ...signedCombos([0.5, 0.5, 0.5, 0.5])]);
    case "600-cell": return unique([
      ...signedCombos([0.5, 0.5, 0.5, 0.5]), ...allSignedPerms([1, 0, 0, 0]), ...evenSignedPerms([PHI / 2, 0.5, ip / 2, 0])
    ]);
    // The 120-cell is built from the 600-cell (its vertices are the 600-cell's cell centres), so
    // the two are exactly dual in the same orientation.
    case "120-cell": return tetrahedronCentres(vertexSet("600-cell"));
    default: throw new Error(`unknown vertex set ${name}`);
  }
}
// Centres of the 600 tetrahedral cells of the 600-cell: its 4-cliques of nearest neighbours.
let cachedCentres = null;
function tetrahedronCentres(verts) {
  if (cachedCentres) return cachedCentres.map((v) => v.slice());
  const n = verts.length;
  let minD = Infinity;
  for (let i = 1; i < n; i += 1) minD = Math.min(minD, v4.len(v4.sub(verts[0], verts[i])));
  const adj = Array.from({ length: n }, () => new Set());
  for (let i = 0; i < n; i += 1) for (let j = i + 1; j < n; j += 1) {
    if (Math.abs(v4.len(v4.sub(verts[i], verts[j])) - minD) < 1e-5) { adj[i].add(j); adj[j].add(i); }
  }
  const centres = [];
  for (let a = 0; a < n; a += 1) for (const b of adj[a]) if (b > a) for (const c of adj[a]) if (c > b && adj[b].has(c)) {
    for (const d of adj[a]) if (d > c && adj[b].has(d) && adj[c].has(d)) {
      centres.push(v4.scale([a, b, c, d].reduce((acc, i) => v4.add(acc, verts[i]), [0, 0, 0, 0]), 0.25));
    }
  }
  cachedCentres = centres;
  return centres.map((v) => v.slice());
}

const DUAL = { "tesseract": "16-cell", "16-cell": "tesseract", "24-cell": "24-cell-dual", "600-cell": "120-cell", "120-cell": "600-cell" };
const dualNormals = (name) => (name === "600-cell" ? tetrahedronCentres(vertexSet("600-cell")) : vertexSet(DUAL[name]));
export const POLYTOPES = Object.freeze(["tesseract", "16-cell", "24-cell", "120-cell", "600-cell"]);

// Order the vertices of a planar convex polygon in 4D around its centroid.
function orderPolygon(points, indices) {
  const c = v4.scale(indices.reduce((acc, i) => v4.add(acc, points[i]), [0, 0, 0, 0]), 1 / indices.length);
  const u = v4.norm(v4.sub(points[indices[0]], c));
  let w = null;
  for (const i of indices.slice(1)) {
    const d = v4.sub(points[i], c);
    const perp = v4.sub(d, v4.scale(u, v4.dot(d, u)));
    if (v4.len(perp) > 1e-4) { w = v4.norm(perp); break; }
  }
  return indices.slice().sort((a, b) => {
    const da = v4.sub(points[a], c), db = v4.sub(points[b], c);
    return Math.atan2(v4.dot(da, w), v4.dot(da, u)) - Math.atan2(v4.dot(db, w), v4.dot(db, u));
  });
}

// Full combinatorial structure: vertices, edges, faces (ordered polygons), cells (vertex, face and
// edge lists) and per-vertex adjacency. Deterministic for a given name.
export function buildPolytope(name) {
  const raw = vertexSet(name);
  const R = Math.max(...raw.map(v4.len));
  const vertices = raw.map((v) => v4.scale(v, 1 / R));
  const n = vertices.length;
  // edges: nearest-neighbour pairs
  let minD = Infinity;
  for (let i = 1; i < n; i += 1) minD = Math.min(minD, v4.len(v4.sub(vertices[0], vertices[i])));
  const edges = [];
  const edgeIndex = new Map();
  const adjacency = Array.from({ length: n }, () => []);
  for (let i = 0; i < n; i += 1) for (let j = i + 1; j < n; j += 1) {
    if (Math.abs(v4.len(v4.sub(vertices[i], vertices[j])) - minD) < 1e-5) {
      edgeIndex.set(`${i},${j}`, edges.length);
      edges.push([i, j]);
      adjacency[i].push(j); adjacency[j].push(i);
    }
  }
  // cells from the dual's vertex directions
  const normals = dualNormals(name).map(v4.norm);
  const cells = normals.map((nrm) => {
    const dots = vertices.map((v) => v4.dot(v, nrm));
    const max = Math.max(...dots);
    const verts = dots.map((d, i) => (d > max - 1e-5 ? i : -1)).filter((i) => i >= 0);
    const centre = v4.scale(verts.reduce((acc, i) => v4.add(acc, vertices[i]), [0, 0, 0, 0]), 1 / verts.length);
    return { normal: nrm, vertices: verts, centre, faces: [], edges: [] };
  });
  // faces: ridges between adjacent cells
  const cellsOfVertex = Array.from({ length: n }, () => []);
  cells.forEach((c, ci) => c.vertices.forEach((v) => cellsOfVertex[v].push(ci)));
  const faces = [];
  for (let a = 0; a < cells.length; a += 1) {
    const candidates = new Set(cells[a].vertices.flatMap((v) => cellsOfVertex[v]).filter((b) => b > a));
    const setA = new Set(cells[a].vertices);
    for (const b of candidates) {
      const shared = cells[b].vertices.filter((v) => setA.has(v));
      if (shared.length >= 3) {
        const fi = faces.length;
        faces.push({ vertices: orderPolygon(vertices, shared), cells: [a, b] });
        cells[a].faces.push(fi); cells[b].faces.push(fi);
      }
    }
  }
  for (const c of cells) {
    const s = new Set(c.vertices);
    edges.forEach(([i, j], ei) => { if (s.has(i) && s.has(j)) c.edges.push(ei); });
  }
  const edgeCells = edges.map(() => 0);
  cells.forEach((c) => c.edges.forEach((e) => { edgeCells[e] += 1; }));
  return { name, vertices, edges, faces, cells, adjacency, edgeLength: minD / R * R / R, edgeCells };
}

// Breadth-first graph distances from every vertex (Uint8Array, row = source).
export function graphDistances(poly) {
  const n = poly.vertices.length;
  const table = new Uint8Array(n * n).fill(255);
  for (let s = 0; s < n; s += 1) {
    const queue = [s];
    table[s * n + s] = 0;
    for (let q = 0; q < queue.length; q += 1) {
      const v = queue[q], d = table[s * n + v];
      for (const u of poly.adjacency[v]) if (table[s * n + u] === 255) { table[s * n + u] = d + 1; queue.push(u); }
    }
  }
  return table;
}

// ---- quaternions and SO(4) -------------------------------------------------------------------------
// quaternion as [x, y, z, w] = w + x i + y j + z k
export const quat = {
  identity: () => [0, 0, 0, 1],
  mul: (a, b) => [
    a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
    a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
    a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
    a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]
  ],
  conj: (a) => [-a[0], -a[1], -a[2], a[3]],
  norm: (a) => { const l = Math.hypot(...a) || 1; return a.map((x) => x / l); },
  // exp of the pure quaternion (u * angle): rotation generator
  exp: (u, angle) => {
    const l = Math.hypot(u[0], u[1], u[2]);
    if (l < 1e-12 || Math.abs(angle) < 1e-12) return [0, 0, 0, 1];
    const s = Math.sin(angle * l) / l;
    return [u[0] * s, u[1] * s, u[2] * s, Math.cos(angle * l)];
  },
  slerp: (a, b, t) => {
    let d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
    let bb = b;
    if (d < 0) { d = -d; bb = b.map((x) => -x); }
    if (d > 0.9995) return quat.norm(a.map((x, i) => x + (bb[i] - x) * t));
    const th = Math.acos(d), s = Math.sin(th);
    const wa = Math.sin((1 - t) * th) / s, wb = Math.sin(t * th) / s;
    return a.map((x, i) => x * wa + bb[i] * wb);
  }
};

// Column-major 4x4 matrix of v -> qL v qR acting on (x, y, z, w).
export function rotationMatrix(qL, qR) {
  const m = new Float32Array(16);
  const basis = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]];
  basis.forEach((e, c) => {
    const r = quat.mul(quat.mul(qL, e), qR);   // e is (x, y, z, w) = quaternion [x, y, z, w]
    m.set(r, c * 4);
  });
  return m;
}
export function applyMatrix(m, v) {
  return [0, 1, 2, 3].map((r) => m[r] * v[0] + m[4 + r] * v[1] + m[8 + r] * v[2] + m[12 + r] * v[3]);
}

// Rotation taking the unit 4-vector u to +w (the projection axis): v -> conj(u) v.
export function orientationFacing(u) {
  return { qL: quat.conj(quat.norm(u)), qR: quat.identity() };
}

// Perspective projection from the point at distance d on the +w axis onto the hyperplane w = 0.
// Circumradius 1 and d >= 2 keep the denominator >= 1: no singularity, no clamping.
export function project(r, d) { const k = d / (d - r[3]); return [r[0] * k, r[1] * k, r[2] * k]; }

// ---- slicing ---------------------------------------------------------------------------------------
// Cross-section of the rotated polytope with the hyperplane w = h. Every cell (a convex 3D polytope
// lying in a hyperplane of R^4) meets it in a convex polygon; those polygons are exactly the faces
// of the 3D cross-section, and its vertices are the polytope's edges crossing w = h. Returns
// polygons of 4D points (all with w = h), each with the cell it came from.
export function crossSection(poly, position, h) {
  // position(cellIndex, vertexIndex) -> rotated 4D point (cells may be shrunk towards their centres)
  const out = [];
  poly.cells.forEach((cell, ci) => {
    const pts = [];
    for (const ei of cell.edges) {
      const [i, j] = poly.edges[ei], a = position(ci, i), b = position(ci, j);
      const da = a[3] - h, db = b[3] - h;
      if ((da < 0 && db >= 0) || (da >= 0 && db < 0)) {
        const t = da / (da - db);
        pts.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, h]);
      }
    }
    if (pts.length < 3) return;
    // order in the polygon's plane (it lies in 3D, w = h)
    const c = pts.reduce((acc, p) => [acc[0] + p[0], acc[1] + p[1], acc[2] + p[2]], [0, 0, 0]).map((x) => x / pts.length);
    const d0 = [pts[0][0] - c[0], pts[0][1] - c[1], pts[0][2] - c[2]];
    let nrm = null;
    for (let k = 1; k < pts.length && !nrm; k += 1) {
      const dk = [pts[k][0] - c[0], pts[k][1] - c[1], pts[k][2] - c[2]];
      const cr = [d0[1] * dk[2] - d0[2] * dk[1], d0[2] * dk[0] - d0[0] * dk[2], d0[0] * dk[1] - d0[1] * dk[0]];
      if (Math.hypot(...cr) > 1e-9) nrm = cr;
    }
    if (!nrm) return;
    const u = d0, w = [nrm[1] * u[2] - nrm[2] * u[1], nrm[2] * u[0] - nrm[0] * u[2], nrm[0] * u[1] - nrm[1] * u[0]];
    const ang = (p) => { const d = [p[0] - c[0], p[1] - c[1], p[2] - c[2]]; return Math.atan2(d[0] * w[0] + d[1] * w[1] + d[2] * w[2], d[0] * u[0] + d[1] * u[1] + d[2] * u[2]); };
    pts.sort((p, q) => ang(p) - ang(q));
    // drop coincident points (a vertex exactly on the hyperplane is shared by several edges)
    const clean = pts.filter((p, k) => k === 0 || Math.hypot(p[0] - pts[k - 1][0], p[1] - pts[k - 1][1], p[2] - pts[k - 1][2]) > 1e-6);
    if (clean.length >= 3) out.push({ cell: ci, points: clean, centre: c });
  });
  return out;
}

// Rotated position of vertex vi of cell ci with the cells shrunk towards their centres by k.
export function cellPositionFn(poly, m, k) {
  const cache = new Map();
  return (ci, vi) => {
    const key = ci * 100000 + vi;
    let r = cache.get(key);
    if (!r) {
      const c = poly.cells[ci].centre, v = poly.vertices[vi];
      r = applyMatrix(m, [0, 1, 2, 3].map((i) => c[i] + (v[i] - c[i]) * k));
      cache.set(key, r);
    }
    return r;
  };
}
