const HEAVY_PRESET_SCALES = new Map([
  [12, 0.72],
  [14, 0.68],
  [15, 0.76],
  [16, 0.70],
  [194, 0.72]
]);

// Worldshell High already doubles device-pixel density and adds persistent
// resonance, volumetrics, temporal echoes, and extra detail layers. Rendering
// those passes at 80% of the High backing size keeps substantially more detail
// than Standard while avoiding a near six-fold pixel-count jump before shader
// complexity is considered.
//
// Fungal Electrophysiology draws a stack of depth shells, each evaluating the
// hyphal field and every live conduction front, so its cost is close to linear
// in pixels with a large constant. At the full High backing size it renders in
// the high teens; at this scale it holds a smooth frame rate while still
// carrying roughly twice Standard's pixels and a third more shells.
const HIGH_QUALITY_PRESET_SCALES = new Map([
  // Ferrofluid's interacting SDFs cost 16–27 ms at 1080p on M3. High uses native
  // viewport resolution plus finer intersections, avoiding 4x Retina pixel cost.
  [224, 0.50],
  [193, 0.80],
  [289, 0.68],
  // 30% more linear detail than native-pixel Standard on a Retina display,
  // without quadrupling the work for thin cap and gill intersections.
  [297, 0.65],
  // Clifford Metamorphosis: a point-density image; its cost is orbits, not pixels, but every extra
  // pixel needs more orbits to stay smooth. 1.5x Standard's linear detail on a Retina display.
  [396, 0.75],
  // Quantum Circuit City: the HD remaster's bounded march is cheaper than the original
  // renderer, so Standard now renders at the normal Standard scale instead of 72% of it.
  // High carries 1.24x Standard's linear detail on a Retina display (never below native
  // pixels on 1x displays) with longer shadows and more occlusion samples.
  [13, 0.62],
  // Smuggler Run: the HD remaster traces every rock, gate and portal on its own. At the full
  // Retina backing size it misses 60 FPS (so did the original); 0.85 keeps 1.7x Standard's
  // linear detail with finer hit thresholds, more erosion octaves and a longer view.
  [215, 0.85],
  // Shadow Geometry: Impossible Apertures: one analytic/raymarched pass whose cost is dominated by
  // the shafts (equiangular haze). 1.24x Standard's linear detail on a Retina display, measured at
  // 8-16 ms per frame at 2381x1339 on an M3.
  [397, 0.62],
  // Living Firepit: raymarched woodland, volumetric flame and the director's constellation
  // segments. 1.24x Standard's linear detail on a Retina display; measured at 29-36 ms per
  // 1920x1080 High frame on an M3 (the original took 49-59 ms at that size).
  [388, 0.62],
  // Hypergeometry Engine: Dimensional Emergence: rasterised 4D polytopes with single-pass
  // order-independent transparency. 1.5x Standard's linear detail on a Retina display, measured at
  // 3.6-12.4 ms per 2880x1620 frame on an M3 (Standard at native 1920x1080: 1.7-5.6 ms).
  [398, 0.75],
  // Tesseract Unfolding (The Hyperdimensional Engine): a raymarched 4D Menger slice with soft
  // shadows, a reflection bounce on mirror surfaces and cage shadows from the core light; inside the
  // chamber it costs ~9 ms per 1920x1080 Standard frame on an M3. 1.3x Standard's linear detail on a
  // Retina display.
  [148, 0.65],
  // Twistor Space Manifold (HD restoration): the folded tube lattice with relaxed sphere tracing,
  // occlusion and a thickness probe, ~7 ms per 1920x1080 Standard frame on an M3 (the original
  // ~3.7 ms, with 5-15% of its pixels torn). 1.6x Standard's linear detail on a Retina display.
  [153, 0.65],
  // Spin Network Matrix (The Living Quantum Lattice): the lattice march with square-cut void
  // terminals, faceted crystal shading and up to six excitation waves; ~7.5 ms per 1920x1080
  // Standard frame and ~13 ms per 2304x1296 High frame on an M3 (the original ~2.2 ms, with
  // broken beams). 1.2x Standard's linear detail on a Retina display.
  [154, 0.6],
  // Toroidal Merkaba Field (The Recursive Crystal Temple): the four-level IFS march with
  // neighbour-sphere bounds, mineral shading (occlusion, a thickness probe) and up to six recursive
  // cascades; ~5 ms per 1920x1080 Standard frame and ~7.5 ms per 2304x1296 High frame on an M3 (the
  // original ~1.4 ms). 1.4x Standard's linear detail on a Retina display.
  [176, 0.7],
  // Audio-Reactive IFS Matrix (The Living Fractal Matrix): the cube-lattice march with per-cell wave
  // fronts, occlusion, edge normals and the cosmic dice; 7.7 ms (dice on screen 9.8 ms) per 1574x886
  // Standard frame on an M3 (the original 3.5 ms), ~12/15.5 ms at this High scale on a 2940x1912
  // backing. 1.46x Standard's linear detail on a Retina display.
  [166, 0.6]
]);

export function renderScaleForPreset(presetId, quality = 0) {
  const id = Number(presetId);
  const presetScale = HEAVY_PRESET_SCALES.get(id) || 1;
  const highQualityScale = Number(quality) > 0.5
    ? HIGH_QUALITY_PRESET_SCALES.get(id) || 1
    : 1;
  return presetScale * highQualityScale;
}

export function computeLiveRenderSizing({
  viewportWidth,
  viewportHeight,
  devicePixelRatio = 1,
  quality = 0,
  activePreset = 0,
  visualsReady = false,
  renderScaleOverride = null
}) {
  const ratio = quality > 0.5 ? Math.min(devicePixelRatio || 1, 2) : 1;
  const canvasWidth = Math.floor(viewportWidth * ratio);
  const canvasHeight = Math.floor(viewportHeight * ratio);
  if (!visualsReady) {
    return {
      ratio,
      canvasWidth,
      canvasHeight,
      renderWidth: canvasWidth,
      renderHeight: canvasHeight
    };
  }
  // Thin botanical silhouettes, metadata-clipped Physarum signals and hairline
  // attractor filaments (396) need native pixels in Standard. Upscaling a
  // clipped overlay spreads light back onto unsupported terrain. Preset 297
  // also uses directional edge AA.
  // Impossible Apertures (397) keeps native pixels in Standard for its fine rods and aperture rims
  // (4.8-8.7 ms per 1920x1080 frame on an M3).
  const qualityScale = quality > 0.5 || Number(activePreset) === 297 || Number(activePreset) === 390 || Number(activePreset) === 396 || Number(activePreset) === 397 || Number(activePreset) === 398 ? 1 : 0.82;
  const presetScale = qualityScale * renderScaleForPreset(activePreset, quality);
  // High must never fall below this preset's native-pixel Standard on 1x or
  // fractional-density displays; the Retina performance cap is not a blur mode.
  const defaultScale = (Number(activePreset) === 297 || Number(activePreset) === 396 || Number(activePreset) === 397 || Number(activePreset) === 398 || Number(activePreset) === 13 || Number(activePreset) === 224) && quality > 0.5
    ? Math.max(1 / ratio, presetScale)
    : presetScale;
  const override = Number(renderScaleOverride);
  const scale = Number.isFinite(override) && override > 0
    ? Math.max(0.5, Math.min(1, override))
    : defaultScale;
  return {
    ratio,
    canvasWidth,
    canvasHeight,
    renderWidth: Math.max(2, Math.floor(viewportWidth * ratio * scale)),
    renderHeight: Math.max(2, Math.floor(viewportHeight * ratio * scale))
  };
}
