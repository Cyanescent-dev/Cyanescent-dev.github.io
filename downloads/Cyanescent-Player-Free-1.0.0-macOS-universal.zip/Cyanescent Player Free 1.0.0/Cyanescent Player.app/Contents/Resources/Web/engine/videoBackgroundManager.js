import { capabilityEnabled, runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
function absoluteUrl(path) {
  try {
    return new URL(path, window.location.href).href;
  } catch {
    return path || "";
  }
}

function configureVideoElement(video) {
  if (!video) return;
  video.muted = true;
  video.playsInline = true;
  video.controls = false;
  video.preload = "metadata";
}

export function createVideoBackgroundManager({
  container,
  videoA,
  videoB,
  assetManager,
  presetConfigs = new Map(),
  shouldHoldPlaylistEnd = () => false,
  onPlaylistEndApproaching = () => false,
  logger = console,
  crossfadeMs = 2200
} = {}) {
  configureVideoElement(videoA);
  configureVideoElement(videoB);

  let active = false;
  let activePreset = null;
  let activeVideo = videoA;
  let inactiveVideo = videoB;
  let playlistIndex = 0;
  let transitionArmed = false;
  let currentPlaylist = [];
  let currentPlaylistItem = null;

  function configForPreset(presetId) {
    return capabilityEnabled("videoPresets") && runtimeAllowsPreset(presetId) ? presetConfigs.get(Number(presetId)) || null : null;
  }

  function showContainer() {
    container?.classList.add("active");
  }

  function hideContainer() {
    container?.classList.remove("active");
  }

  async function loadVideoSource(video, source) {
    if (!video || !source) return false;
    const nextSrc = absoluteUrl(source);
    if (video.__loadedSource === source && video.src === nextSrc) return true;
    video.__loadedSource = source;
    video.src = source;
    video.load();
    return true;
  }

  async function playVideo(video) {
    if (!video) return;
    configureVideoElement(video);
    try {
      await video.play();
    } catch (error) {
      logger.warn?.("Video background play failed:", error);
    }
  }

  function swapElements() {
    const previous = activeVideo;
    activeVideo = inactiveVideo;
    inactiveVideo = previous;
    return { previous, next: activeVideo };
  }

  async function fadeToItem(itemOrSource) {
    const source = typeof itemOrSource === "string" ? itemOrSource : (itemOrSource?.path || itemOrSource?.src || "");
    if (!source || !activeVideo || !inactiveVideo) return;
    const { previous, next } = swapElements();
    await loadVideoSource(next, source);
    await playVideo(next);
    window.setTimeout(() => {
      next.classList.add("active");
      previous.classList.remove("active");
      currentPlaylistItem = typeof itemOrSource === "string" ? { path: source } : itemOrSource;
    }, 80);
    window.setTimeout(() => {
      if (inactiveVideo === previous) {
        try { previous.pause(); } catch {}
        previous.removeAttribute("src");
        previous.load?.();
        previous.__loadedSource = "";
      }
    }, crossfadeMs + 250);
  }

  function firstSourceForConfig(config) {
    if (Array.isArray(config?.playlist) && config.playlist.length) {
      return config.playlist[0].path || config.playlist[0].src || "";
    }
    return config?.path || config?.src || "";
  }

  async function start(presetId) {
    const config = configForPreset(presetId);
    if (!config) {
      stop();
      return false;
    }
    if (active && activePreset === Number(presetId)) return true;

    stop();
    active = true;
    activePreset = Number(presetId);
    playlistIndex = 0;
    transitionArmed = false;
    currentPlaylist = Array.isArray(config.playlist) ? config.playlist : [];
    currentPlaylistItem = currentPlaylist[0] || config || null;
    showContainer();

    const source = firstSourceForConfig(config);
    if (!source) return false;
    await loadVideoSource(activeVideo, source);
    activeVideo.loop = !currentPlaylist.length;
    activeVideo.classList.add("active");
    await playVideo(activeVideo);
    return true;
  }

  function update() {
    if (!active || !currentPlaylist.length || !activeVideo) return;
    const duration = Number.isFinite(activeVideo.duration) && activeVideo.duration > 0 ? activeVideo.duration : 0;
    if (!duration) return;
    const transitionLead = Math.min(3, duration * 0.25);
    if (!transitionArmed && activeVideo.currentTime >= duration - transitionLead) {
      if (playlistIndex >= currentPlaylist.length - 1 && shouldHoldPlaylistEnd(activePreset)) {
        if (onPlaylistEndApproaching({
          presetId: activePreset,
          clipIndex: playlistIndex,
          clipCount: currentPlaylist.length,
          currentTime: activeVideo.currentTime,
          duration,
          transitionLead
        })) {
          transitionArmed = true;
        }
        return;
      }
      transitionArmed = true;
      playlistIndex = (playlistIndex + 1) % currentPlaylist.length;
      const next = currentPlaylist[playlistIndex];
      fadeToItem(next).finally(() => {
        transitionArmed = false;
      });
    }
  }

  function syncToPreset(presetId) {
    return start(presetId);
  }

  function stop() {
    if (!active && !activePreset) return;
    active = false;
    activePreset = null;
    currentPlaylist = [];
    currentPlaylistItem = null;
    transitionArmed = false;
    hideContainer();
    for (const video of [videoA, videoB]) {
      if (!video) continue;
      video.classList.remove("active");
      try { video.pause(); } catch {}
      video.removeAttribute("src");
      video.load?.();
      video.__loadedSource = "";
    }
    activeVideo = videoA;
    inactiveVideo = videoB;
  }

  function playlistState() {
    if (!active || !activeVideo) {
      return {
        stage: 0,
        localTime: 0,
        duration: 10
      };
    }
    const duration = Number.isFinite(activeVideo.duration) && activeVideo.duration > 0 ? activeVideo.duration : 10;
    return {
      stage: Number(currentPlaylistItem?.stage || 0),
      localTime: Number.isFinite(activeVideo.currentTime) ? activeVideo.currentTime : 0,
      duration
    };
  }

  function registerPreset(presetId, config) {
    if (!Number.isFinite(Number(presetId)) || !config) return;
    presetConfigs.set(Number(presetId), config);
  }

  function hasPreset(presetId) {
    return Boolean(configForPreset(presetId));
  }

  return {
    registerPreset,
    hasPreset,
    syncToPreset,
    update,
    stop,
    playlistState,
    activePreset: () => activePreset
  };
}
