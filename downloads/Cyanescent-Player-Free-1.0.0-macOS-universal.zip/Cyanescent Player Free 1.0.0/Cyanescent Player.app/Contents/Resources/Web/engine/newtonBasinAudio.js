// Newton Basin Descent: music -> visual intent. Pure JS (no GL) so the mapping is testable.
// It consumes Player's existing analysis unchanged (audioFeatures, smoothed bands, music-aware
// state and the tempo); it never analyses audio itself.
//
// The mapping is by instrument role, so a change in the arrangement is a visible change on screen:
//
//   beat + groove   a ripple wave out of the attractor wells on every beat of the track's beat
//                   grid while there is a groove (low end present); the bar decides which basin
//                   carries each one (see newtonBasinWaves.js); a short exposure / contrast pump.
//                   Without a beat grid, detected kicks drive the waves instead.
//   bass, sub       crest width, crater glow, and the depth of the pump
//   mids (pads)     seam shimmer and crater breathing, strongest in breakdowns
//   highs, hi-hats  specular glints on bright surfaces
//   energy          bloom, saturation and how hard every wave hits
//   no kick         breakdown mode: slow tides once a bar, dreamy bloom, softer grade
//   build-up        roll waves on a subdividing grid (8ths, 16ths, 32nds), rising exposure
//   drop            one large shockwave, a flash and a glint burst: when the groove returns after
//                   a break, or a build-up lets go
//
// Loud, mastered dance music saturates Player's band values (the kick band sits at 1 through a
// whole psytrance drive), so nothing here relies on absolute levels to find events: the groove is
// the low end relative to the track's own recent history, and hats are onsets relative to the
// treble's own local range (see createOnsetDetector).

const clamp = (value, low, high) => Math.min(high, Math.max(low, value));
const clamp01 = (value) => clamp(Number.isFinite(value) ? value : 0, 0, 1);

export function follow(current, target, dt, attack, release) {
  const time = target > current ? attack : release;
  return current + (target - current) * (1 - Math.exp(-dt / Math.max(1e-4, time)));
}

export const AUDIO_TIMING = Object.freeze({
  // seconds: [attack, release]
  bass: [0.04, 0.30],
  sub: [0.30, 1.20],
  mids: [0.08, 0.45],
  highs: [0.02, 0.12],
  energy: [0.80, 2.40],
  groove: [0.10, 0.60],
  scene: [0.80, 1.80],
  build: [0.50, 1.00],
  // seconds: exponential decay of impulses
  pump: 0.16,
  dropFlash: 1.6,
  hat: 0.09
});

// Onsets relative to a signal's own local range, so they work at any level: a loud, compressed
// track whose treble never drops below 0.35 still has hats that swing between 0.35 and 0.8.
export function createOnsetDetector({ window = 0.35, minRange = 0.08, rise = 0.6, rearm = 0.35, refractory = 0.06 } = {}) {
  let lo = NaN, hi = NaN, armed = true, last = -Infinity, norm = 0;
  return {
    step(x, dt, time) {
      if (!Number.isFinite(x)) return false;
      if (!Number.isFinite(lo)) { lo = x; hi = x; }
      const k = 1 - Math.exp(-dt / window);
      lo = x < lo ? x : lo + (x - lo) * k;
      hi = x > hi ? x : hi + (x - hi) * k;
      norm = (x - lo) / Math.max(hi - lo, minRange);
      if (norm < rearm) armed = true;
      if (armed && norm > rise && hi - lo >= minRange && time - last > refractory) { armed = false; last = time; return true; }
      return false;
    },
    get level() { return norm; },
    reset() { lo = hi = NaN; armed = true; last = -Infinity; norm = 0; }
  };
}

export const AUDIO_LIMITS = Object.freeze({
  beatLeadSeconds: 0.09,    // beat events fire this far ahead of the track's beat grid (see step)
  kickThreshold: 0.45,
  kickRefractory: 0.16,
  hatRefractory: 0.055,
  dropCooldown: 4.0,
  grooveGapBeats: 1.6,      // without a beat grid: no kick for this many beats and the groove falls away
  grooveOn: 0.35,           // groove presence above which the beat grid carries waves
  breakSeconds: 2.0,        // the groove coming back after at least this long away is a drop
  settleSeconds: 4.0        // nothing counts as a drop in the first seconds of playback
});

const INITIAL = Object.freeze({
  time: 0, beat: 0, beatSource: "clock", beatsPerSecond: 145 / 60,
  bass: 0.1, sub: 0.1, mids: 0.1, highs: 0.1, energy: 0.2, energyFast: 0.2, energySlow: 0.2,
  bassDrive: 0, subDrive: 0, midDrive: 0, highDrive: 0, energyDrive: 0, surge: 0,
  groove: 0, lowLevel: 0, lowPresence: 0, bassPeak: 0.3, energyLevel: 0, energyPeak: 0.3, lastBeat: null, build: 0, breakdown: 0, pump: 0, dropFlash: 0, hat: 0,
  kickCount: 0, waveCount: 0, rollCount: 0, tideCount: 0, hatCount: 0, dropCount: 0,
  breathPhase: 0, shimmerPhase: 0,
  exposure: 1, saturation: 1, contrast: 1, haze: 0, bloom: 0, craterGlow: 0, seamShimmer: 0, glintRate: 0
});

export function createNewtonAudioModel() {
  const state = { ...INITIAL };
  let previousKick = 0, lastKickAt = -Infinity;
  let dropArmed = true, buildPeaked = false, lastDropAt = -Infinity, lastRollIndex = null, lastTideBar = null, grooveLostAt = null;
  const hatOnsets = createOnsetDetector({ window: 0.3, minRange: 0.06, refractory: AUDIO_LIMITS.hatRefractory });

  function reset() {
    Object.assign(state, INITIAL);
    previousKick = 0; lastKickAt = -Infinity;
    dropArmed = true; buildPeaked = false; lastDropAt = -Infinity; lastRollIndex = null; lastTideBar = null; grooveLostAt = null;
    hatOnsets.reset();
  }

  function triggerDrop(events) {
    if (events.drop || state.time - lastDropAt <= AUDIO_LIMITS.dropCooldown) return;
    lastDropAt = state.time;
    state.dropFlash = 1;
    state.dropCount += 1;
    events.drop = 1;
    events.waves.push({ kind: "drop", strength: 1.35 });
  }

  // Advance by dt seconds of wall time. Returns the discrete events of this step:
  // { waves: [{ kind, strength, beatInBar? }], hats, kick, drop }.
  function step(dt, { audio = {}, smooth = {}, music = {} } = {}, { reactive = 1, beatsPerSecond = 145 / 60, leadSeconds = AUDIO_LIMITS.beatLeadSeconds } = {}) {
    dt = clamp(dt, 0, 0.1);
    const events = { waves: [], hats: 0, kick: 0, drop: 0 };
    const r = clamp(reactive, 0, 1.5);
    const T = AUDIO_TIMING;
    state.time += dt;

    // ---- continuous bands -------------------------------------------------------------------
    const rawEnergy = clamp01(audio.globalEnergy ?? music.adaptiveIntensity ?? 0.2);
    state.bass = follow(state.bass, clamp01(smooth.bass), dt, T.bass[0], T.bass[1]);
    state.sub = follow(state.sub, clamp01(smooth.bass), dt, T.sub[0], T.sub[1]);
    state.mids = follow(state.mids, clamp01(smooth.mids), dt, T.mids[0], T.mids[1]);
    state.highs = follow(state.highs, clamp01(smooth.highs), dt, T.highs[0], T.highs[1]);
    state.energy = follow(state.energy, rawEnergy, dt, T.energy[0], T.energy[1]);
    state.energyFast = follow(state.energyFast, rawEnergy, dt, 0.06, 0.35);
    state.energySlow = follow(state.energySlow, rawEnergy, dt, 3.0, 5.0);
    // Expanded range: quiet material sits near zero, driven material uses the whole range.
    const drive = (x, lo, hi) => Math.pow(clamp01((x - lo) / (hi - lo)), 1.1);
    state.bassDrive = drive(state.bass, 0.15, 0.80);
    state.subDrive = drive(state.sub, 0.15, 0.80);
    state.midDrive = drive(state.mids, 0.12, 0.72);
    state.highDrive = drive(state.highs, 0.10, 0.72);
    state.energyDrive = drive(state.energy, 0.12, 0.82);
    state.surge = clamp01((state.energyFast - state.energySlow) * 4);

    // ---- beat clock ---------------------------------------------------------------------------
    const bps = clamp(Number(beatsPerSecond) || 145 / 60, 1, 4);
    state.beatsPerSecond = bps;
    const trackBeat = Number(music.absoluteBeat);
    // The track's beat grid is a precise clock, so beat events are predicted slightly ahead: Player's
    // grid sits ~36 ms after the kick's attack (measured on a mastered track) and a frame takes ~2-3
    // display refreshes to reach the screen, so an unled beat lands visibly late.
    const lead = clamp(Number.isFinite(leadSeconds) ? leadSeconds : 0, -0.2, 0.3);
    if (Number.isFinite(trackBeat) && trackBeat > 0) { state.beat = trackBeat + lead * bps; state.beatSource = "track"; }
    else { state.beat += dt * bps; state.beatSource = "clock"; }

    // ---- groove: is the track driving, relative to what it has had lately? --------------------
    // Player's bands are dB-scaled analyser bytes and the low band barely moves on a loud track (a
    // psytrance breakdown with a bass pad still reads 0.85 against 0.96 in the drive), so the
    // groove needs the low end AND the overall energy to be near this track's own recent peak
    // (peaks decay over minutes, not within one breakdown), and defers to the analysis when it
    // calls the section calm.
    const lowNow = clamp01(Number.isFinite(audio.bassNow) ? audio.bassNow : smooth.bass);
    state.lowLevel = follow(state.lowLevel, lowNow, dt, 0.35, 0.5);
    state.bassPeak = Math.max(state.lowLevel, state.bassPeak - dt * state.bassPeak / 120);
    state.energyLevel = follow(state.energyLevel, rawEnergy, dt, 0.35, 0.6);
    state.energyPeak = Math.max(state.energyLevel, state.energyPeak - dt * state.energyPeak / 120);
    const lowRel = clamp01((state.lowLevel - 0.78 * state.bassPeak) / (0.12 * state.bassPeak + 1e-3));
    const energyRel = clamp01((state.energyLevel / Math.max(state.energyPeak, 0.05) - 0.74) / 0.12);
    const calmCue = clamp01((Math.max(clamp01(music.calm), clamp01(music.breakdown)) - 0.45) / 0.25);
    state.lowPresence = Math.min(lowRel, energyRel) * (1 - calmCue) * clamp01((state.lowLevel - 0.16) / 0.12);

    const waveFor = (beatInBar, kick) => {
      state.kickCount += 1;
      events.kick = kick;
      events.waves.push({ kind: "kick", strength: (0.55 + 0.45 * kick) * (0.45 + 0.55 * state.energyDrive), beatInBar });
      state.pump = Math.max(state.pump, 0.6 + 0.4 * kick);
      lastKickAt = state.time;
    };
    const kick = clamp01(audio.kickPulse);
    if (state.beatSource === "track") {
      // The track's own beat grid carries the rhythm: exact, and immune to a saturated kick band.
      const index = Math.floor(state.beat + 0.02);
      if (state.lastBeat !== null && index > state.lastBeat && index - state.lastBeat < 3 && state.groove > AUDIO_LIMITS.grooveOn) {
        waveFor(((index % 4) + 4) % 4, index % 4 === 0 ? 1 : 0.8);
      }
      state.lastBeat = index;
      state.groove = follow(state.groove, state.lowPresence, dt, T.groove[0], T.groove[1]);
    } else {
      // No beat grid (live input without tracking): detected kicks drive the waves.
      state.lastBeat = null;
      if (kick > AUDIO_LIMITS.kickThreshold && previousKick <= AUDIO_LIMITS.kickThreshold && state.time - lastKickAt > AUDIO_LIMITS.kickRefractory) {
        waveFor(state.kickCount % 4, kick);
      }
      const grooveTarget = state.time - lastKickAt < AUDIO_LIMITS.grooveGapBeats / bps + 0.1 ? 1 : 0;
      state.groove = follow(state.groove, grooveTarget, dt, T.groove[0], T.groove[1]);
    }
    previousKick = kick;
    // The groove coming back after a break is the drop.
    if (state.groove < 0.3) { if (grooveLostAt === null) grooveLostAt = state.time; }
    else if (state.groove > 0.6 && grooveLostAt !== null) {
      if (state.time - grooveLostAt > AUDIO_LIMITS.breakSeconds && state.time > AUDIO_LIMITS.settleSeconds && state.time - lastDropAt > AUDIO_LIMITS.dropCooldown) triggerDrop(events);
      grooveLostAt = null;
    }

    // ---- sections -----------------------------------------------------------------------------
    // A build is confirmed by rising energy; analysis sometimes calls a build inside a steady drive.
    const trend = Number.isFinite(music.energyTrend) ? music.energyTrend : 0.7;
    state.build = follow(state.build, clamp01(music.buildUp) * (0.35 + 0.65 * clamp01((trend - 0.45) / 0.25)), dt, T.build[0], T.build[1]);
    const calmTarget = clamp01(Math.max(clamp01(music.breakdown), clamp01(music.calm) * 0.7, 1 - state.groove));
    state.breakdown = follow(state.breakdown, calmTarget, dt, T.scene[0], T.scene[1]);
    // A drop is only a drop coming out of a breakdown or a build: Player's energy-surge detector
    // also fires inside a steady section, and a sustained "drop" role must not retrigger, so the
    // signal has to fall back below 0.3 before it can fire again.
    // Drops: a strong drop role from the analysis, or a build-up that lets go (the analysis calls
    // the build until the drop lands). Player's sectionChange and energy-surge flags are not used:
    // on real tracks the first sits near 1 for minutes and the second fires whenever the mix fills.
    const canDrop = state.time > AUDIO_LIMITS.settleSeconds && state.time - lastDropAt > AUDIO_LIMITS.dropCooldown;
    const dropRole = clamp01(music.drop);
    if (dropRole < 0.3) dropArmed = true;
    if (dropArmed && dropRole > 0.6 && canDrop) { dropArmed = false; triggerDrop(events); }
    const rawBuild = clamp01(music.buildUp);
    if (state.build > 0.8) buildPeaked = true;             // a full, energy-confirmed build
    if (buildPeaked && rawBuild < 0.5) { buildPeaked = false; if (canDrop) triggerDrop(events); }

    // Build-up: roll waves on a grid that subdivides as the build progresses.
    if (state.build > 0.25) {
      const division = state.build < 0.55 ? 2 : state.build < 0.85 ? 4 : 8;
      const index = Math.floor(state.beat * division);
      const onKickBeat = index % division === 0 && state.groove > 0.5;
      if (lastRollIndex !== null && index !== lastRollIndex && !onKickBeat && !events.kick) {
        events.waves.push({ kind: "roll", strength: 0.15 + 0.40 * state.build });
        state.rollCount += 1;
      }
      lastRollIndex = index;
    } else lastRollIndex = null;

    // Breakdown: a slow tide once a bar, carried by the pads.
    if (state.breakdown > 0.55) {
      const bar = Math.floor(state.beat / 4);
      if (lastTideBar !== null && bar !== lastTideBar) {
        events.waves.push({ kind: "tide", strength: (0.30 + 0.45 * state.midDrive) * state.breakdown });
        state.tideCount += 1;
      }
      lastTideBar = bar;
    } else lastTideBar = null;

    // ---- hi-hats: onsets of the treble relative to its own local range -------------------------
    const treble = Number.isFinite(audio.trebleNow) ? audio.trebleNow : clamp01(smooth.highs);
    if (hatOnsets.step(treble, dt, state.time)) {
      state.hat = 1;
      state.hatCount += 1;
      events.hats = 1;
    }

    // ---- impulses and phases ------------------------------------------------------------------
    state.pump *= Math.exp(-dt / T.pump);
    state.dropFlash *= Math.exp(-dt / T.dropFlash);
    state.hat *= Math.exp(-dt / T.hat);
    state.breathPhase += dt * bps / 4;                               // one breath per bar
    state.shimmerPhase += dt * (0.12 + 0.60 * state.midDrive);
    state.waveCount += events.waves.length;

    // ---- visual intent ------------------------------------------------------------------------
    const pump = state.pump * (0.45 + 0.55 * Math.max(state.bassDrive, state.energyDrive));
    const calm = state.breakdown;
    state.exposure = 1 + r * (0.075 * pump + 0.14 * state.dropFlash + 0.06 * state.build - 0.035 * calm);
    state.saturation = 1 + r * (0.10 * state.energyDrive + 0.16 * state.dropFlash + 0.05 * state.build - 0.14 * calm);
    state.contrast = 1 + r * (0.05 * pump + 0.05 * state.energyDrive + 0.04 * state.dropFlash - 0.07 * calm);
    state.haze = r * 0.06 * calm;
    state.bloom = r * (0.04 + 0.14 * state.energyDrive + 0.18 * pump + 0.75 * state.dropFlash + 0.14 * state.build + 0.10 * calm + 0.10 * state.surge);
    state.craterGlow = r * (0.10 + 0.50 * state.subDrive + 0.45 * calm * state.midDrive);
    state.seamShimmer = r * (0.06 + 0.60 * state.midDrive * (0.35 + 0.65 * calm) + 0.25 * state.build);
    // Glints per second: steady highs, bursts on every detected hat.
    state.glintRate = r * (40 * state.highDrive + 220 * state.hat * (0.4 + 0.6 * state.highDrive));
    return events;
  }

  return { state, step, reset };
}
