import { computeLiveRenderSizing } from "./renderSizing.js";
import {
  clearRenderTarget,
  createClearedRenderTargetPair,
  deleteRenderTarget
} from "./renderTargets.js";

export function createRenderSurfaceController({
  canvas,
  getGl,
  getQuality,
  getActivePreset,
  getExportResolutionOverride,
  isOfflineExport,
  isVisualsReady,
  drawWaveform,
  getRenderScaleOverride
} = {}) {
  let buffers = [];
  let readIndex = 0;
  let renderWidth = 1;
  let renderHeight = 1;
  let liveResizeSuspended = false;
  let resizePending = false;

  function setCanvasSize(width, height) {
    let changed = false;
    if (canvas.width !== width) {
      canvas.width = width;
      changed = true;
    }
    if (canvas.height !== height) {
      canvas.height = height;
      changed = true;
    }
    return changed;
  }

  function resize() {
    if (liveResizeSuspended && !isOfflineExport?.()) {
      resizePending = true;
      return;
    }
    resizePending = false;
    const gl = getGl();
    const exportSize = isOfflineExport?.() ? getExportResolutionOverride?.() : null;
    if (exportSize) {
      const width = Math.max(2, Math.floor(exportSize.width || 2));
      const height = Math.max(2, Math.floor(exportSize.height || 2));
      const canvasChanged = setCanvasSize(width, height);
      if (width === renderWidth && height === renderHeight) {
        if (canvasChanged) drawWaveform?.();
        return;
      }
      renderWidth = width;
      renderHeight = height;
      buffers.forEach((target) => deleteRenderTarget(gl, target));
      buffers = createClearedRenderTargetPair(gl, width, height);
      readIndex = 0;
      drawWaveform?.();
      return;
    }

    const sizing = computeLiveRenderSizing({
      viewportWidth: innerWidth,
      viewportHeight: innerHeight,
      devicePixelRatio: window.devicePixelRatio || 1,
      quality: getQuality?.() || 0,
      activePreset: getActivePreset?.() || 0,
      visualsReady: isVisualsReady?.(),
      renderScaleOverride: getRenderScaleOverride?.()
    });
    if (!isVisualsReady?.()) {
      if (setCanvasSize(sizing.canvasWidth, sizing.canvasHeight)) drawWaveform?.();
      return;
    }
    const width = sizing.renderWidth;
    const height = sizing.renderHeight;
    const canvasChanged = setCanvasSize(sizing.canvasWidth, sizing.canvasHeight);
    if (width === renderWidth && height === renderHeight) {
      if (canvasChanged) drawWaveform?.();
      return;
    }
    renderWidth = width;
    renderHeight = height;
    buffers.forEach((target) => deleteRenderTarget(gl, target));
    buffers = createClearedRenderTargetPair(gl, width, height);
    readIndex = 0;
    drawWaveform?.();
  }

  function clearFeedbackBuffers() {
    const gl = getGl();
    if (!isVisualsReady?.() || !buffers.length) return;
    for (const target of buffers) {
      clearRenderTarget(gl, target, renderWidth, renderHeight);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  return {
    resize,
    setLiveResizeSuspended(value) {
      liveResizeSuspended = Boolean(value);
      if (!liveResizeSuspended && resizePending) resize();
    },
    clearFeedbackBuffers,
    hasBuffers: () => buffers.length > 0,
    buffers: () => buffers,
    readIndex: () => readIndex,
    setReadIndex: (value) => { readIndex = value; },
    renderWidth: () => renderWidth,
    renderHeight: () => renderHeight,
    renderSize: () => ({ width: renderWidth, height: renderHeight })
  };
}
