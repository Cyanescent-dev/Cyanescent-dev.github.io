import { createForgeCues } from './forgeHybridCues.js';
const variation=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
const clamp=(v,lo=0,hi=1)=>Math.max(lo,Math.min(hi,Number(v)||0));
export const SIGNAL_LIMIT=96,ACTIVITY_BINS=128;
export function buildStinkhornGraph(topology){
  if(topology.schema!=='red-cage-mycelial-network-v2')throw new Error('Stinkhorn topology schema mismatch');
  const paths=new Map(topology.paths.map(p=>[p.id,p])),nodes=new Map(topology.nodes.map(n=>[n.id,n]));
  for(const p of paths.values()){
    if(!(p.length>0)||!nodes.has(p.startNodeID)||!nodes.has(p.endNodeID))throw new Error('Invalid graph endpoints');
    for(const id of nodes.get(p.endNodeID).outgoingPathIDs){const child=paths.get(id);if(!child||child.startNodeID!==p.endNodeID)throw new Error('Disconnected graph junction');}
  }
  const outgoing=id=>(nodes.get(id)?.outgoingPathIDs||[]).map(id=>paths.get(id)).filter(p=>
    // Crosslinks form cycles. Follow only routes descending in shortest crown
    // distance, retaining real branching and multi-parent convergences.
    nodes.get(p.endNodeID).distanceToCrown<nodes.get(p.startNodeID).distanceToCrown-1e-5)
    .sort((a,b)=>a.distanceToCrown-b.distanceToCrown||a.id-b.id);
  const columns=[...paths.values()].filter(p=>p.isPrimary&&p.kind==='column')
    .filter(p=>nodes.get(p.startNodeID).position[1]<1).sort((a,b)=>a.columnID-b.columnID);
  const floor=[...paths.values()].filter(p=>p.isPrimary&&p.kind==='floor-fine').sort((a,b)=>a.columnID-b.columnID);
  const route=id=>{const list=[],visited=new Set();let p=paths.get(id);
    while(p){if(visited.has(p.id))throw new Error('Crown route cycle');visited.add(p.id);list.push(p);
      if(p.endNodeID===topology.crownNodeID)return list;p=outgoing(p.endNodeID)[0];}return [];};
  const allPaths=[...paths.values()],feeders=new Map(columns.map(p=>[p.columnID,allPaths.filter(f=>f.kind==='hypha'&&f.columnID===p.columnID)]));
  return {paths,nodes,outgoing,columns,floor,allPaths,ambientPaths:allPaths.filter(p=>p.isPrimary&&p.kind!=='floor-fine'),feeders,route,crown:topology.crownNodeID,
    distance:id=>route(id).reduce((n,p)=>n+p.length,0)};
}
export function createStinkhornSignals(topology){
  const graph=buildStinkhornGraph(topology),cues=createForgeCues();
  const pool=Array.from({length:SIGNAL_LIMIT},()=>({active:false})),pending=[];
  const activity=new Float32Array(ACTIVITY_BINS*(Math.max(...graph.paths.keys())+1));
  const stats={launched:0,arrived:0,splits:0,merges:0,scheduled:0,dropped:0,replaced:0,peak:0};
  const state={time:0,energy:0,bass:0,mids:0,highs:0,crown:0,beat:0,build:0,breakdown:0,life:0};
  let previousKick=0,lastKick=-100,lastBeat=null,lastMid=-100,lastAmbient=-100,serial=0,lastTarget=null,releaseSerial=0;
  function reset(){for(const p of pool)p.active=false;pending.length=0;activity.fill(0);cues.reset();
    for(const k in stats)stats[k]=0;for(const k in state)state[k]=0;previousKick=0;lastKick=lastMid=lastAmbient=-100;lastBeat=null;serial=0;lastTarget=null;releaseSerial=0;}
  function launch(id,strength,speed=6,arc=0,target=null,route=null,allowMerge=true,traits={}){
    if(!graph.paths.has(id)||strength<.015)return null;
    const merge=allowMerge&&pool.find(p=>p.active&&p.path===id&&Math.abs(p.arc-arc)<.035&&Math.abs(p.speed-speed)<.2&&p.target===target);
    if(merge){merge.strength=Math.min(2.5,merge.strength+strength);stats.merges++;return merge;}
    let p=pool.find(p=>!p.active);
    // Significant rhythmic/phrase packets can displace a weak branch or a
    // draining wake. Scheduled arrivals stay protected from ordinary traffic.
    if(!p){const candidate=pool.filter(p=>p.active&&p.target===null)
      .sort((a,b)=>(a.strength*(a.arrived?.5:1))-(b.strength*(b.arrived?.5:1))||a.serial-b.serial)[0];
      if(candidate&&(target!==null||candidate.strength*(candidate.arrived?.5:1)<strength*.65)){p=candidate;stats.replaced++;}}
    if(!p){stats.dropped++;return null;}
    const floor=graph.paths.get(id).kind.startsWith('floor')||graph.paths.get(id).kind==='hypha';
    // Arc lengths are world metres along the RCN2 curve, never screen streaks.
    const seed=serial++,v=variation(seed+id*3.1);
    Object.assign(p,{active:true,path:id,arc,strength,speed,age:0,target,route,serial:seed,
      length:floor?.35+v*.65:1.15+v*1.65+Math.min(1,strength)*.7,front:floor?.12+v*.16:.22+variation(seed+23)*.32,
      history:[],arrived:false,groundHops:0,originGround:floor,ambient:false,...traits});stats.launched++;return p;
  }
  function scheduleCrown(targetTime,strength=1,ids=graph.columns.map(p=>p.id)){
    for(const id of ids){const route=graph.route(id);if(!route.length)continue;
      const distance=route.reduce((n,p)=>n+p.length,0),speed=7;
      const at=targetTime-distance/speed;
      if(at<state.time-.05)continue;
      if(pending.length<96){pending.push({at,id,strength,speed,target:targetTime,route:route.map(p=>p.id)});stats.scheduled++;}
    }
    pending.sort((a,b)=>a.at-b.at||a.id-b.id);
  }
  function advance(p,distance){let hops=0;
    if(p.arrived){p.arc+=distance;if(p.arc>graph.paths.get(p.path).length+p.length*1.5)p.active=false;return;}
    while(p.active&&distance>=0&&hops++<24){
      const path=graph.paths.get(p.path),remaining=path.length-p.arc;
      if(distance+1e-8<remaining){p.arc+=distance;break;}
      distance=Math.max(0,distance-remaining);p.arc=path.length;
      if(path.endNodeID===graph.crown){state.crown=Math.min(2.6,state.crown+p.strength*(p.target===null?.014:.22));stats.arrived++;p.arrived=true;p.arc+=distance;break;}
      let children=graph.outgoing(path.endNodeID);
      if(p.route){const ix=p.route.indexOf(path.id);children=children.filter(c=>c.id===p.route[ix+1]);}
      else {
        // At ground junctions, energy can spread into a real lateral link as
        // well as the outward cord. Allow two such hops, then use the existing
        // acyclic crown routing; no invented connections or persistent loops.
        if(p.originGround&&!p.ambient&&p.groundHops<2&&graph.nodes.get(path.endNodeID).position[1]<.2){
          children=graph.nodes.get(path.endNodeID).outgoingPathIDs.map(id=>graph.paths.get(id))
            .filter(c=>c.id!==path.id&&!p.history.some(h=>h.id===c.id))
            .sort((a,b)=>(a.kind==='floor-link'?1:0)-(b.kind==='floor-link'?1:0)||a.id-b.id);
        }
        children=children.slice(0,p.ambient?1:state.mids>.3||p.originGround&&state.energy>.35?2:1);
      }
      if(!children.length){p.active=false;break;}
      const strength=p.strength;
      const groundJunction=p.originGround&&graph.nodes.get(path.endNodeID).position[1]<.2;
      const weights=children.map((c,i)=>i===0?1:groundJunction?.35:c.isPrimary?.7:.42),total=weights.reduce((n,v)=>n+v,0);
      const primary=children[0];
      p.history.unshift({id:path.id,length:path.length,strength});
      // A bounded route wake keeps the luminous body attached across junctions.
      let wake=0;p.history=p.history.filter(h=>{const keep=wake<p.length*1.5;wake+=h.length;return keep;}).slice(0,12);
      if(path.kind.startsWith('floor')||path.kind==='hypha')p.groundHops++;
      if(primary.kind==='floor-cord'&&!p.ambient)p.length=Math.max(p.length,1.25+variation(p.serial+41)*1.55);
      p.path=primary.id;p.arc=0;p.strength=strength*weights[0]/total;
      // Only one continuation owns the original packet. Other branches get
      // the same elapsed distance, so camera/output cadence cannot cause jumps.
      for(let i=1;i<children.length;i++){const child=launch(children[i].id,strength*weights[i]/total,p.speed,0,p.target,p.route,false,{length:p.length,front:p.front,groundHops:p.groundHops,originGround:p.originGround,ambient:p.ambient});
        if(child){stats.splits++;advance(child,distance);}}
    }
    if(hops>=24)p.active=false;
  }
  function step(dt,input={},controls={}){
    dt=clamp(dt,0,.1);state.time+=dt;state.crown*=Math.exp(-dt/1.15);
    const {audio={},music={},smooth={},lookahead={},tempo:rawTempo}=input;
    const tempo=rawTempo||{};
    const c=cues.update({dt,audio,music,bands:smooth,lookahead,tempo,authoredBPM:145});
    state.energy=c.energy;state.bass=c.bass;state.mids=c.mids;state.highs=c.highs;state.beat=c.beat;state.breakdown=c.breakdown;
    state.build=clamp(music.buildUp??music.build);
    const life=(.08+.55*state.energy+.25*state.build)*(1-.78*state.breakdown);
    state.life+=(life-state.life)*(1-Math.exp(-dt/1.8));
    const bpm=Number(tempo.bpm)||Number(music.bpm)||145,bps=bpm/60;
    const beat=Number.isFinite(music.absoluteBeat)?Math.floor(music.absoluteBeat+.025*bps):null;
    const edge=beat!==null&&lastBeat!==null&&beat>lastBeat&&beat-lastBeat<3;
    const kick=clamp(audio.kickPulse),onset=kick>.48&&previousKick<=.48;
    const fired=state.time-lastKick>.18&&(onset||(edge&&state.energy>.32&&state.bass>.2&&state.breakdown<.7));
    previousKick=kick;lastBeat=beat;
    // Snapshot the population before routing; newly split children have already
    // consumed this time step and must not be advanced twice.
    const existing=pool.filter(p=>p.active).map(p=>[p,p.serial]);
    for(const [p,id] of existing)if(p.active&&p.serial===id){p.age+=dt;advance(p,p.speed*dt);if(p.age>12)p.active=false;}
    while(pending.length&&pending[0].at<=state.time){const s=pending.shift();const p=launch(s.id,s.strength,s.speed,0,s.target??null,s.route??null,false,s.traits||{});if(p)advance(p,(state.time-s.at)*s.speed);}
    if(fired&&(controls.pulses!==false||controls.ground!==false)){lastKick=state.time;
      const count=state.energy>.55?3:state.energy>.3?2:1;
      if(controls.pulses!==false)for(let k=0;k<count;k++){const col=(serial*5+k*7)%graph.columns.length,p=graph.columns[col];
        if(p){const strength=(.35+.9*state.bass+.35*state.energy)*(1-state.breakdown*.8),speed=3.4+state.energy*3.8;
          const seed=serial+beat*.37+k*11;launch(p.id,strength,speed);
          const followers=state.energy>.55&&variation(seed)>.58?2:state.energy>.3&&variation(seed)>.32?1:0;
          for(let j=0;j<followers&&pending.length<96;j++)pending.push({at:state.time+(.09+variation(seed+7)*.1)*(j+1),id:p.id,
            strength:strength*(.55+variation(seed+j+19)*.38),speed:speed*(.94+variation(seed+4)*.1),target:null});
          pending.sort((a,b)=>a.at-b.at||a.id-b.id);
        }}
      if(controls.ground!==false){const count=state.energy>.6?5:state.energy>.3?3:1;
        for(let k=0;k<count;k++){const seed=serial+k*17,path=graph.floor[(Math.floor(variation(seed)*18)+k*5)%graph.floor.length];
          const feeders=graph.feeders.get(path.columnID)||[];
          const p=k%2&&feeders.length?feeders[Math.floor(variation(seed+3)*feeders.length)]:path;
          const strength=(.45+.85*state.bass+.22*state.energy)*(1-state.breakdown*.82),speed=2.5+state.energy*3;
          launch(p.id,strength,speed);
          if(state.energy>.45&&variation(seed+13)>.55&&pending.length<96)pending.push({at:state.time+.12+variation(seed+8)*.14,id:p.id,strength:strength*.65,speed});
        }
        pending.sort((a,b)=>a.at-b.at||a.id-b.id);
      }
    }
    if(controls.pulses!==false&&state.mids>.15&&state.time-lastMid>2.5/(.3+state.mids)){
      const p=graph.columns[serial%graph.columns.length];if(p)launch(p.id,.15+.3*state.mids,3.2);lastMid=state.time;
    }
    if(controls.choreography!==false&&controls.pulses!==false&&Number.isFinite(music.absoluteBeat)){
      const next8=(Math.floor(music.absoluteBeat/8)+1)*8;
      const target=state.time+(next8-music.absoluteBeat)/bps;
      const major=next8%32===0,phrase=next8%16===0;
      // Horizon energy maxima are not timestamps. Only combine the existing
      // forecast with a known beat-grid boundary; report it as phrase targeting.
      const forecast=lookahead.ready?clamp(music.upcomingDrop):0;
      const strength=(major?1.05:phrase?.72:.35)+forecast*.45+state.build*.2;
      if(next8!==lastTarget&&target-state.time<3.4&&target-state.time>2.2&&state.energy>.16){
        const count=major?18:phrase?10:4;
        const ids=Array.from({length:count},(_,i)=>graph.columns[Math.floor(i*graph.columns.length/count)].id);
        scheduleCrown(target,strength*(1-state.breakdown*.68),ids);lastTarget=next8;
      }
      // With no useful advance forecast, a detected release launches into the
      // actual columns now and targets the following four-beat downbeat. The
      // release is travelling energy rather than an immediate crown flash.
      if(c.releaseSerial!==releaseSerial){releaseSerial=c.releaseSerial;
        const next4=(Math.floor(music.absoluteBeat/4)+1)*4,at=state.time+(next4-music.absoluteBeat)/bps;
        for(const path of graph.columns){const route=graph.route(path.id),distance=route.reduce((n,p)=>n+p.length,0);
          if(at-state.time>.2&&route.length)launch(path.id,.7+state.energy*.6,distance/(at-state.time),0,at,route.map(p=>p.id));}
      }
    }
    // Quiet life is sparse moving traffic, with a slow independent clock.
    // It uses the same physical paths and is always weaker than musical trains.
    if(controls.ambient!==false&&state.time-lastAmbient>3.8/(.65+state.life*2.4)){
      const candidates=graph.ambientPaths.filter(p=>(controls.ground!==false||!p.kind.startsWith('floor')&&p.kind!=='hypha')
        &&(controls.pulses!==false||p.kind.startsWith('floor')||p.kind==='hypha'));
      for(let k=0;k<(state.life>.35?2:1)&&candidates.length;k++){
        const seed=serial+state.time*3.1,p=candidates[Math.floor(variation(seed)*candidates.length)];
        launch(p.id,.03+state.life*.07,.3+state.life*.85,variation(seed+5)*p.length*.8,null,null,false,
          {ambient:true,length:.18+variation(seed+9)*.5,front:.08+variation(seed+2)*.08});
      }
      lastAmbient=state.time;
    }
    activity.fill(0);
    function paint(id,centre,strength,p){const path=graph.paths.get(id),offset=id*ACTIVITY_BINS;
      const low=Math.max(0,Math.floor((centre-p.length*1.5)/path.length*(ACTIVITY_BINS-1))),high=Math.min(ACTIVITY_BINS-1,Math.ceil((centre+p.front*2)/path.length*(ACTIVITY_BINS-1)));
      for(let i=low;i<=high;i++){const d=i/(ACTIVITY_BINS-1)*path.length-centre;
        // Broad luminous body, tapered wake and soft leading edge. Overlapping
        // trains add here, so the old 16/48 head limits cannot truncate ribbons.
        const body=d<0?Math.exp(-Math.pow(d/(p.length*.65),2)*2):Math.exp(-Math.pow(d/p.front,2)*2);
        const core=d<0?Math.exp(-Math.pow(d/(p.length*.34),2)*2):Math.exp(-Math.pow(d/(p.front*.65),2)*2);
        activity[offset+i]+=strength*(body*.7+core*.45);
      }
    }
    for(const p of pool)if(p.active){paint(p.path,p.arc,p.strength,p);
      let centre=p.arc;
      for(const h of p.history){centre+=h.length;if(centre-p.length*1.5>h.length)break;paint(h.id,centre,h.strength,p);}}
    stats.peak=Math.max(stats.peak,pool.filter(p=>p.active).length);
    return state;
  }
  return {graph,state,stats,pool,activity,pending,step,launch,scheduleCrown,reset};
}
