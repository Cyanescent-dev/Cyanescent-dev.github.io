export const DUOVERSE_HD_ID = 391;

// Values verified against the Forge manifest. Frame time is authoritative for
// fields; the MP4's presented media time selects the same zero-based frame.
export const DUOVERSE_HD = Object.freeze({
  id: DUOVERSE_HD_ID,
  assetRoot: "assets/forge/duoverse-hd",
  video: "duoverse1080p.mp4",
  authoredBPM: 145,
  beatsPerBar: 4,
  fps: 30,
  frameCount: 1788,
  videoWidth: 1920,
  videoHeight: 1080,
  fieldWidth: 512,
  fieldHeight: 512,
  surfacePattern: "surface/frame_",
  flowPattern: "flow/frame_",
  fieldOrigin: "top-left",
  seamlessLoop: true
});
