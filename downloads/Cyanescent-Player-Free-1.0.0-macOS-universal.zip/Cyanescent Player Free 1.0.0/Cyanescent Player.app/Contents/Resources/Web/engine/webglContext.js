import { bindFullscreenTriangleBuffer, createFullscreenTriangleBuffer } from "./geometryBuffers.js";
import { createVisualProgramController } from "./shaders.js";

export function createWebGlContextController({ canvas, ui, vertexSource }) {
  const glOptions = {
    alpha: true,
    antialias: false,
    depth: true,
    premultipliedAlpha: true,
    preserveDrawingBuffer: false
  };
  let gl = null;
  let quad = null;

  function ensureWebGl() {
    if (gl) return gl;
    gl = canvas.getContext("webgl2", glOptions);
    if (!gl) {
      ui.audioStatus.textContent = "WebGL2 unavailable";
      throw new Error("WebGL2 is required");
    }
    return gl;
  }

  const visualPrograms = createVisualProgramController({
    getGl: ensureWebGl,
    vertexSource,
    createQuad: createFullscreenTriangleBuffer,
    bindQuad: bindFullscreenTriangleBuffer,
    getQuad: () => quad,
    setQuad: (value) => {
      quad = value;
    }
  });

  function ensureFullscreenQuad() {
    const context = ensureWebGl();
    if (!quad) quad = createFullscreenTriangleBuffer(context);
    return quad;
  }

  function useProgramAndBindFullscreenQuad(programToUse) {
    const context = ensureWebGl();
    context.useProgram(programToUse);
    bindFullscreenTriangleBuffer(context, ensureFullscreenQuad());
  }

  return {
    getGl: () => gl,
    ensureWebGl,
    ensureFullscreenQuad,
    programFrom: (vertex, fragment, bindings) => visualPrograms.fromSources(vertex, fragment, bindings),
    program: (fragment) => visualPrograms.fullscreen(fragment),
    warmupDrawCall: (programToUse) => visualPrograms.warmup(programToUse),
    useProgramAndBindFullscreenQuad
  };
}
