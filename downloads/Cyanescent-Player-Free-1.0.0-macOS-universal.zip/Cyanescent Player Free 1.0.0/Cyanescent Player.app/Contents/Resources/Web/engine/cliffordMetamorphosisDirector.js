// Clifford Phase Space: Metamorphosis — music -> mathematics. Pure JS (no GL), testable.
//
// It consumes Player's existing analysis through the shared music model (newtonBasinAudio.js: beat
// grid, groove, build, breakdown, drop and hi-hat events that work on loud mastered tracks) plus the
// genuine 0.5/5/20-second lookahead, and turns it into the state of one mathematical universe:
//
//   route        where on the closed chaotic route through Clifford parameter space we are, and how
//                fast we travel (mids, energy; slower in breakdowns, accelerating through builds)
//   volume       thickness of the parameter volume (each depth slice is the attractor of a nearby
//                parameter set), the delay-coordinate lift and the twist: the "unfolding"
//   eruption     share of orbits seeded on a disc around the repelling fixed point and the disc's
//                size on a log scale: e = 1 is the whole attractor, e ~ 0.55 its unstable-manifold
//                skeleton (breakdowns), e -> 0 a single luminous point (the singularity before a drop)
//   pulses       kicks send light along the attractor's own unstable manifold; hats send short ones
//   flex         each kick snaps one coefficient of the map for an instant (the folds jump)
//   camera       authored shots (portrait, unfold, voyage, macro) changed on phrase boundaries
//   grade        exposure, bloom, saturation, flashes
//
// Drops jump to the next authored world and erupt it out of its fixed point. Anticipation (collapse
// into the singularity) needs either lookahead that agrees with a nearby phrase boundary, or an
// energy-confirmed build; it relaxes again if the drop does not come.
import { createNewtonAudioModel, follow } from "./newtonBasinAudio.js";
import { ROUTE_LENGTH, ROUTE_META, ROUTE_META_SAMPLES, ROUTE_WORLDS } from "./cliffordMetamorphosisItinerary.js";
import { nextWorldIndex } from "./cliffordMetamorphosisWorlds.js";

const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const TAU = Math.PI * 2;

export const SCENES = Object.freeze(["portrait", "unfold", "voyage", "macro"]);

// Authored shots. The depth axis is a time extrusion: the front face is the attractor now, the
// volume behind it the route already travelled. span: how much route history (route units),
// depth: how far back it reaches in space, bias: how strongly orbits favour the front face,
// lift: delay-coordinate relief, twist: rotation along the history (radians).
export const SHOTS = Object.freeze({
  portrait: { distance: 2.55, yaw: 0.0, pitch: 0.0, sway: 0.16, orbit: 0.0, span: 0.0, depth: 0.0, bias: 1, lift: 0.22, twist: 0.0, fov: 0.92, target: [0, 0, 0] },
  unfold:   { distance: 3.1, yaw: 0.62, pitch: 0.28, sway: 0.10, orbit: 0.42, span: 0.30, depth: 2.2, bias: 2.2, lift: 0.45, twist: 0.7, fov: 0.92, target: [0, 0, -0.7] },
  voyage:   { distance: 1.5, yaw: 0.30, pitch: 0.14, sway: 0.08, orbit: 0.30, span: 0.32, depth: 2.6, bias: 3.6, lift: 0.40, twist: 1.3, fov: 1.0, target: [0.1, 0.05, -0.3] },
  macro:    { distance: 1.05, yaw: 0.10, pitch: -0.08, sway: 0.22, orbit: 0.0, span: 0.0, depth: 0.0, bias: 1, lift: 0.95, twist: 0.0, fov: 0.85, target: [0.18, 0.12, 0] },
  singular: { distance: 2.35, yaw: 0.0, pitch: 0.0, sway: 0.05, orbit: 0.0, span: 0.0, depth: 0.0, bias: 1, lift: 0.18, twist: 0.0, fov: 0.92, target: [0, 0, 0] }
});

const PULSE_LIFE = { kick: 0.62, downbeat: 0.85, roll: 0.36, tide: 2.4, hat: 0.26, drop: 1.8 };
const PULSE_FRONT = { kick: 13, downbeat: 15, roll: 8, tide: 16, hat: 5, drop: 17 };

export function createCliffordDirector({ random = Math.random } = {}) {
  const audioModel = createNewtonAudioModel();
  const s = {};
  const pulses = [];
  let seedFlip = 0;

  function reset() {
    audioModel.reset();
    pulses.length = 0;
    Object.assign(s, {
      time: 0, route: ROUTE_WORLDS[0].at, routeSpeed: 0.03, routeAdvance: 0, worldIndex: 0,
      scene: "portrait", sceneSince: 0, sceneIndex: 0, lastPhrase: null,
      camera: { ...SHOTS.portrait, target: [...SHOTS.portrait.target] }, orbitAngle: 0, orbitPhase: 0, orbitAmp: 0, swayPhase: 0,
      span: 0, depth: 0.3, lift: 0.2, twist: 0, liftAngle: 0, sliceBias: 1,
      // The preset opens on the complete attractor at full presence: it is usually entered through
      // a transition, and growing it out of a point from black looked like a broken frame.
      erupt: 1, eruptShare: 0, eruptTarget: 1, phase: "flow", dropCount: 0, lastDropAt: -100,
      tension: 0, future: 0, bassReturn: 0, previousKick: 0, collapseSince: null, lastRelaxAt: -100, breakAt: null, rebounds: 0, reeruptions: 0, energyPeak: 0,
      flex: [0, 0, 0, 0], flexKick: [0, 0, 0, 0], flexDir: [1, 0, 0, 0],
      energy: 0.3, mids: 0.2, highs: 0.2, bass: 0.2, groove: 0, breakdown: 0, build: 0,
      flash: 0, pump: 0, hatGlint: 0, hueDrift: 0, retainTime: 0.08,
      exposure: 1, bloom: 0.3, glow: 0.2, saturation: 1, vignette: 0.35, presence: 1,
      kicks: 0, hats: 0, drops: 0, collapses: 0, relaxes: 0
    });
  }
  reset();

  const metaAt = (fraction) => {
    const k = Math.floor((((fraction % 1) + 1) % 1) * ROUTE_META_SAMPLES) % ROUTE_META_SAMPLES;
    return k;
  };
  // Narrow periodic windows on the route: sprint across them.
  function windowAhead(fraction) {
    let worst = Infinity;
    for (let q = -1; q <= 2; q += 1) worst = Math.min(worst, ROUTE_META.lyapunov[(metaAt(fraction) + q + ROUTE_META_SAMPLES) % ROUTE_META_SAMPLES]);
    return worst < 0.06;
  }

  function spawnPulse(kind, strength, span) {
    const life = PULSE_LIFE[kind];
    // Pulses light the front face, now and then a strand further back in the history.
    const slice = kind === "tide" || kind === "drop" || span < 0.05 ? 0 : Math.pow(random(), 3) * 0.6;
    const pulse = {
      kind, age: 0, life, strength, front: 0, frontMax: PULSE_FRONT[kind],
      seed: [random() * 4.4 - 2.2, random() * 4.4 - 2.2], slice,
      hue: random(), accent: kind === "hat" ? 0.35 : kind === "roll" ? 0.55 : 0.85,
      radius: kind === "tide" ? 0.005 : kind === "hat" ? 0.002 : 0.004
    };
    // Replace the oldest pulse of the same family when every slot is busy.
    if (pulses.length >= 10) {
      let oldest = 0;
      for (let i = 1; i < pulses.length; i += 1) if (pulses[i].age / pulses[i].life > pulses[oldest].age / pulses[oldest].life) oldest = i;
      pulses.splice(oldest, 1);
    }
    pulses.push(pulse);
  }

  // Shots hold for at least 8 s (the singular shot and eruptions are musical events and may cut in).
  function setScene(name, force = false) {
    if (s.scene === name) return;
    if (!force && name !== "singular" && s.scene !== "singular" && s.time - s.sceneSince < 8) return;
    s.scene = name; s.sceneSince = s.time;
  }

  // dt: wall seconds. input: { audio, smooth, music, lookahead, tempo }. controls: fixture overrides.
  function step(dt, input = {}, controls = {}) {
    dt = clamp(dt, 0, 0.1);
    s.time += dt;
    const { audio = {}, smooth = {}, music = {}, lookahead = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    const reactive = clamp(controls.reactive ?? 1, 0, 1.5);

    // ---- continuous musical envelopes -----------------------------------------------------------
    // Unsaturated shared envelopes keep dynamics on loud tracks (as in Helix Tunnel).
    const fast = clamp(audio.globalEnergyFast ?? a.energyFast), slow = clamp(audio.globalEnergySlow ?? a.energySlow);
    const energyNow = clamp(fast * 0.5 + slow * 0.2 + clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.3);
    s.energy = follow(s.energy, Math.max(energyNow, a.energyDrive * 0.9), dt, 0.25, 0.9);
    s.mids = follow(s.mids, a.midDrive, dt, 0.1, 0.5);
    s.highs = follow(s.highs, a.highDrive, dt, 0.03, 0.2);
    s.bass = follow(s.bass, Math.max(a.subDrive, clamp(((audio.bassRel ?? 1) - 0.8) * 1.6)), dt, 0.08, 0.6);
    s.groove = a.groove; s.breakdown = a.breakdown; s.build = a.build;
    const E = s.energy;

    // ---- lookahead: is a strong return coming? --------------------------------------------------
    const current = lookahead.current || {}, med = lookahead.medium || {}, long = lookahead.long || {};
    const rise = clamp(((med.maxEnergy || med.energy || 0) - (current.energy || 0) - 0.08) * 3.2);
    const bassReturn = clamp(((med.bass || 0) - (current.bass || 0) - 0.035) * 3);
    const farRise = clamp(((long.energy || 0) - (current.energy || 0) - 0.12) * 2);
    s.future = lookahead.ready
      ? clamp(Math.max(clamp(music.upcomingDrop) * 1.4, rise * (0.5 + 0.5 * bassReturn), clamp(music.upcomingBuild) * 0.5, farRise * 0.4))
      : 0;
    const phraseSeconds = Number(music.nextPhraseSeconds);
    const phraseValid = Number.isFinite(phraseSeconds) && phraseSeconds > 0 && Number.isFinite(music.absoluteBeat);
    s.bassReturn = bassReturn;
    const quiet = s.groove < 0.35 || s.breakdown > 0.6;
    // The groove returning after a genuine break (>= 3 s, about two bars) is a drop: a new world
    // erupts. A shorter gap (a one-bar kick drop) is a rebound inside the same world.
    // The groove envelope confirms a return about a second late, so the drop itself fires on the
    // first strong kick onset (or the shared model's drop) once a break has lasted long enough.
    const pulseNow = clamp(audio.kickPulse), lowNow = clamp(audio.bassNow ?? smooth.bass);
    const onset = pulseNow > 0.48 && s.previousKick <= 0.48 && lowNow > 0.3;
    s.previousKick = pulseNow;
    let grooveReturn = 0;
    if (quiet) { if (s.breakAt === null) s.breakAt = s.time; }
    if (s.breakAt !== null && (onset || events.drop || (!quiet && s.groove > 0.6))) {
      const gap = s.time - s.breakAt;
      // Inside a build the kick often keeps ticking; once the lookahead has wound the attractor
      // down, the first strong return is the drop however the break was punctuated.
      if (s.tension > 0.3 && gap > 1.5) { grooveReturn = Math.max(gap, 3); s.breakAt = null; }
      else if (gap > 0.8 && (!quiet || gap >= 3)) { grooveReturn = gap; s.breakAt = null; }
      else if (!quiet) s.breakAt = null;
    }
    const breakAge = s.breakAt === null ? 0 : s.time - s.breakAt;

    // ---- anticipation: collapse into the singularity ----------------------------------------------
    // Lookahead must agree with an imminent phrase boundary; without lookahead an energy-confirmed
    // build may only tighten the attractor into a knot. Both relax if no drop arrives.
    // A prediction needs the low end coming back in the 5 s window (or a confident drop section),
    // and after a false alarm the next one has to wait 16 s.
    const evidence = bassReturn > 0.15 || rise > 0.45 || clamp(music.upcomingDrop) > 0.5;
    const confident = clamp(music.upcomingDrop) > 0.8;   // the analysis labels a drop section just ahead
    const predicted = quiet && breakAge > 1.2 && s.future > 0.55 && evidence && phraseValid && phraseSeconds < 6.5
      && (s.time - s.lastRelaxAt > 16 || confident);
    const confirmedBuild = a.build > 0.8 && !lookahead.ready && quiet && breakAge > 1.2;
    const anticipate = clamp(controls.anticipation ?? 1, 0, 1);
    let collapseGoal = 0;
    // Reach the singular point about half a beat before the predicted boundary.
    if (predicted) collapseGoal = anticipate * clamp(s.future * 1.25) * clamp((6.5 - phraseSeconds) / 5.6);
    else if (confirmedBuild) collapseGoal = anticipate * 0.55;
    if (collapseGoal > 0.2 && s.collapseSince === null) { s.collapseSince = s.time; s.collapses += 1; }
    // A collapse that has waited 6 s without a drop is a false alarm: relax and hold off.
    if (s.collapseSince !== null && (s.time - s.collapseSince > 6 || collapseGoal < 0.05)) {
      s.collapseSince = null; s.lastRelaxAt = s.time; s.relaxes += 1; collapseGoal = 0;
    }
    if (s.collapseSince === null && s.time - s.lastRelaxAt < 16 && !confident) collapseGoal = 0;
    s.tension = follow(s.tension, collapseGoal, dt, 0.25, 1.4);

    // ---- drops: a new world erupts out of its fixed point ---------------------------------------
    const dropEvent = grooveReturn >= 3 && s.time > 4 && s.time - s.lastDropAt > 6 && (controls.drops ?? 1) > 0;
    if (grooveReturn > 0.8 && !dropEvent && s.time - s.lastDropAt > 2) {
      // Rebound: the same world, lit from inside.
      s.flash = Math.max(s.flash, 0.55); s.rebounds += 1;
      spawnPulse("drop", 0.9, 0);
    }
    // The track's own peak loudness (from the analysis windows), decaying over minutes.
    s.energyPeak = Math.max((current.energy || 0), (med.maxEnergy || 0) * 0.95, s.energyPeak - dt * s.energyPeak / 240);
    if (dropEvent) {
      s.lastDropAt = s.time; s.dropCount += 1; s.drops += 1;
      // A predicted drop (the attractor was wound down) or one heading for the track's peak opens a
      // new world; a lesser return (a kick tease) re-erupts the current world from its fixed point.
      const major = !lookahead.ready || s.tension > 0.3 || (med.maxEnergy || 0) >= 0.85 * s.energyPeak;
      if (major) {
        const next = controls.world >= 0 ? controls.world : nextWorldIndex(s.route);
        s.worldIndex = next;
        s.route = ROUTE_WORLDS[next].at + 0.002;
      } else s.reeruptions += 1;
      s.erupt = Math.min(s.erupt, 0.06); s.eruptShare = 1; s.tension = 0; s.collapseSince = null;
      s.flash = 1; s.phase = "eruption";
      s.sceneIndex = 0; setScene("singular", true);
      pulses.length = 0;
      spawnPulse("drop", 1.4, 0);
    }

    // ---- eruption envelope ------------------------------------------------------------------------
    // e is the log disc size (0 = point, ~0.45 = first filament at attractor scale, 1 = complete).
    const sinceDrop = s.time - s.lastDropAt;
    if (s.phase === "intro" && s.time > 3.2) s.phase = "flow";
    if (s.phase === "eruption" && s.erupt > 0.985) s.phase = "flow";
    if (s.phase === "intro" || s.phase === "eruption") {
      // Grow at a musical rate: about two bars to the complete attractor after a drop.
      const rate = s.phase === "intro" ? 0.34 : 0.55 + 0.35 * E;
      s.erupt = Math.min(1, s.erupt + dt * rate);
      s.eruptShare = 1;
    } else {
      // Breakdowns retreat to the unstable-manifold skeleton, breathing with the pads.
      const skeleton = clamp((s.breakdown - 0.45) / 0.4) * clamp(1 - s.groove * 1.5) * (controls.skeleton ?? 1);
      const breath = 0.06 * Math.sin(TAU * a.breathPhase) + 0.08 * (s.mids - 0.3);
      let eruptGoal = 1 - skeleton * (0.36 - breath);
      eruptGoal = Math.min(eruptGoal, 1 - s.tension * 0.93);
      // Moving orbits between the bulk seeds and the disc is invisible only while the disc image is
      // the complete attractor: the share changes first, the disc size waits for it (and back).
      if (eruptGoal < 0.985) {
        if (s.eruptShare < 0.98) { s.eruptShare = follow(s.eruptShare, 1, dt, 0.12, 0.12); s.erupt = follow(s.erupt, 1, dt, 0.3, 0.3); }
        else { s.eruptShare = 1; s.erupt = follow(s.erupt, eruptGoal, dt, 0.9, s.tension > 0.2 ? 0.45 : 1.6); }
      } else {
        s.erupt = follow(s.erupt, 1, dt, 0.9, 0.9);
        if (s.erupt > 0.98) s.eruptShare = follow(s.eruptShare, 0, dt, 0.4, 0.4);
      }
    }

    // ---- section -> scene -------------------------------------------------------------------------
    const beat = Number.isFinite(a.beat) ? a.beat : s.time * bps;
    const phrase = Math.floor(beat / 64);   // 16 bars
    const forced = SCENES.includes(controls.scene) ? controls.scene : null;
    if (forced) setScene(forced, true);
    else if (s.phase === "eruption" || s.phase === "intro") {
      if (s.erupt > 0.72) setScene(s.phase === "intro" ? "portrait" : "voyage", true);
    } else if (s.tension > 0.35) setScene("singular");
    // Builds unfold; Player's analysis also reports weak "builds" inside a full drive, so a build with
    // the kick still running must be a strong one.
    else if (s.build > 0.35 && s.groove < 0.4) setScene("unfold");
    else if (s.breakdown > 0.6 && s.groove < 0.4) {
      if (s.scene !== "portrait" && s.scene !== "macro") setScene(s.dropCount % 2 ? "macro" : "portrait");
      if (s.lastPhrase !== null && phrase !== s.lastPhrase && s.time - s.sceneSince > 12) setScene(s.scene === "portrait" ? "macro" : "portrait");
    } else if (s.lastPhrase !== null && phrase !== s.lastPhrase && s.time - s.sceneSince > 14) {
      s.sceneIndex = (s.sceneIndex + 1) % SCENES.length;
      setScene(SCENES[(SCENES.indexOf("voyage") + s.sceneIndex) % SCENES.length]);
    } else if (s.scene === "singular" && s.tension < 0.15) setScene("unfold");
    s.lastPhrase = phrase;

    // ---- travel along the route -------------------------------------------------------------------
    const travelBase = s.scene === "voyage" ? 0.075 : 0.035;
    let speed = (travelBase + 0.05 * E + 0.035 * s.mids) * (1 - 0.55 * s.breakdown * (1 - s.groove)) + 0.11 * s.build;
    speed *= 1 - 0.85 * s.tension;
    if (s.phase === "eruption") speed *= 0.25;
    // Thin, nearly one-dimensional attractors on the route are passages, not destinations.
    const mk = metaAt(s.route), ex = ROUTE_META.ex[mk], ey = ROUTE_META.ey[mk];
    const thin = clamp((0.45 - Math.min(ex, ey) / Math.max(ex, ey, 1e-3)) / 0.3);
    speed *= 1 + 2.5 * thin;
    speed *= clamp(controls.travel ?? 1, 0, 8);
    if (controls.freeze) speed = 0;
    s.routeSpeed = follow(s.routeSpeed, speed, dt, 0.4, 0.8);
    // A narrow periodic window ahead: cross it in a few frames (not smoothed, or it would lag).
    const sprint = windowAhead(s.route) && !controls.freeze ? 12 : 1;
    s.routeAdvance = Math.max(s.routeSpeed, sprint > 1 ? 0.03 : 0) * sprint * dt / ROUTE_LENGTH;
    s.route = (s.route + s.routeAdvance) % 1;
    s.worldIndex = Math.max(0, ROUTE_WORLDS.findLastIndex((w) => w.at <= s.route + 1e-9));

    // ---- kicks, rolls, tides, hats ------------------------------------------------------------------
    const shot = SHOTS[s.scene];
    for (const wave of events.waves) {
      if (wave.kind === "drop") continue;
      if (wave.kind === "kick") {
        s.kicks += 1;
        const downbeat = wave.beatInBar === 0;
        spawnPulse(downbeat ? "downbeat" : "kick", (0.75 + 0.5 * E) * (downbeat ? 1.25 : 1) * reactive, s.span);
        s.pump = 1;
        // Each bar flexes a different coefficient; the kick snaps it and lets it spring back.
        if (downbeat) {
          const axis = Math.floor(beat / 4) % 4, sign = Math.floor(beat / 16) % 2 ? -1 : 1;
          s.flexDir = [0, 0, 0, 0]; s.flexDir[axis] = sign;
        }
        const amount = (0.018 + 0.05 * E + 0.02 * s.bass) * reactive * (controls.flex ?? 1);
        for (let i = 0; i < 4; i += 1) s.flexKick[i] = s.flexDir[i] * amount;
      } else if (wave.kind === "roll") spawnPulse("roll", (0.35 + 0.5 * s.build) * reactive, s.span);
      else if (wave.kind === "tide") spawnPulse("tide", (0.55 + 0.6 * s.mids) * reactive, 0);
    }
    if (events.hats && s.highs > 0.15 && s.groove > 0.3) {
      s.hats += 1;
      seedFlip = (seedFlip + 1) % 3;
      if (seedFlip !== 1) spawnPulse("hat", (0.25 + 0.5 * s.highs) * reactive, s.span);
    }
    for (const pulse of pulses) {
      pulse.age += dt;
      const t = clamp(pulse.age / pulse.life);
      pulse.front = pulse.frontMax * Math.pow(t, 0.62);
    }
    for (let i = pulses.length - 1; i >= 0; i -= 1) if (pulses[i].age >= pulses[i].life) pulses.splice(i, 1);

    // ---- impulses ---------------------------------------------------------------------------------
    s.pump *= Math.exp(-dt / 0.14);
    s.flash *= Math.exp(-dt / 0.9);
    for (let i = 0; i < 4; i += 1) {
      s.flexKick[i] *= Math.exp(-dt / 0.11);
      // Bass leans slowly on the c and d coefficients: mass, not events.
      const lean = i === 2 ? 0.035 * s.bass * Math.sin(s.time * 0.21) : i === 3 ? 0.03 * s.bass * Math.cos(s.time * 0.17) : 0;
      s.flex[i] = s.flexKick[i] + lean * reactive;
    }

    // ---- volume, lift, twist ------------------------------------------------------------------------
    const tauShape = s.phase === "eruption" ? 0.6 : 1.8;
    const energyOpen = 0.65 + 0.7 * E;
    s.span = follow(s.span, shot.span * energyOpen * (1 + 0.6 * s.build) * (1 - s.tension), dt, tauShape, tauShape);
    s.sliceBias = follow(s.sliceBias, shot.bias, dt, tauShape, tauShape);
    s.depth = follow(s.depth, shot.depth * (0.8 + 0.4 * E + 0.25 * s.bass), dt, tauShape, tauShape);
    s.lift = follow(s.lift, shot.lift * (0.8 + 0.5 * s.bass + 0.3 * s.build), dt, 0.6, 1.2);
    s.twist = follow(s.twist, shot.twist * (0.6 + 0.6 * E + 0.8 * s.build), dt, tauShape, tauShape);
    s.liftAngle += dt * (0.05 + 0.12 * s.mids);

    // ---- camera -----------------------------------------------------------------------------------
    const cam = s.camera, tauCam = s.phase === "eruption" ? 0.8 : s.scene === "singular" ? 1.2 : 2.6;
    // Orbiting is a bounded swing (amplitude shot.orbit): a planar attractor must never be seen edge-on.
    s.orbitPhase += dt * (0.035 + 0.05 * E + 0.08 * s.build);
    s.orbitAmp = follow(s.orbitAmp, shot.orbit, dt, 2.5, 2.5);
    s.orbitAngle = s.orbitAmp * Math.sin(s.orbitPhase * TAU);
    s.swayPhase += dt * (0.05 + 0.06 * E + 0.05 * s.mids);
    for (const key of ["distance", "pitch", "sway", "fov"]) cam[key] = follow(cam[key], shot[key], dt, tauCam, tauCam);
    cam.yaw = follow(cam.yaw, shot.yaw, dt, tauCam, tauCam);
    for (let i = 0; i < 3; i += 1) cam.target[i] = follow(cam.target[i], shot.target[i], dt, tauCam, tauCam);
    s.hueDrift += dt * (0.004 + 0.02 * s.mids + 0.01 * s.build);

    // ---- grade --------------------------------------------------------------------------------------
    const pump = s.pump * (0.4 + 0.6 * Math.max(E, s.bass));
    s.exposure = (0.6 + 0.55 * E + 0.38 * pump + 0.25 * s.build * 0.5 + 0.55 * s.flash - 0.1 * s.breakdown * (1 - s.groove)) * (controls.brightness ?? 1);
    s.exposure *= 1 - 0.35 * s.tension + 0.9 * s.tension * s.tension; // the singularity concentrates the light
    s.bloom = 0.22 + 0.35 * E + 0.25 * pump + 0.9 * s.flash + 0.3 * s.tension;
    s.glow = 0.10 + 0.20 * E + 0.15 * s.breakdown + 0.6 * s.flash + 0.35 * s.tension;
    s.saturation = 1.12 + 0.25 * E + 0.2 * s.flash - 0.12 * s.breakdown * (1 - s.groove);
    s.hatGlint = follow(s.hatGlint, s.highs * 0.6 + a.hat * 0.8, dt, 0.02, 0.15);
    s.retainTime = follow(s.retainTime, s.breakdown > 0.6 ? 0.16 : s.phase === "eruption" ? 0.05 : 0.075 + 0.04 * (1 - E), dt, 0.5, 0.5);
    s.vignette = 0.32 + 0.15 * s.tension;
    s.presence = follow(s.presence, 1, dt, 0.5, 0.5);
    return events;
  }

  return { state: s, pulses, step, reset, audioState: audioModel.state };
}
