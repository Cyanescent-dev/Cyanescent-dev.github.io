export function createVisualRendererSetup({
  documentRef = document,
  ensureWebGl,
  compileProgram,
  fallbackFragmentSource,
  blitSource,
  textureAssets,
  ensureFullscreenQuad,
  resize,
  clearFeedbackBuffers,
  getActivePreset,
  queuePresetShaderModulePrime,
  presetShaderModuleId,
  scheduleFullShaderCompile,
  getVisualFullShaderReady,
  getFullRenderProgram,
  setRenderProgram,
  getShellRenderProgram,
  setShellRenderProgram,
  getBlitProgram,
  setBlitProgram,
  setShellActive,
  setVisualsReady,
  setFallbackActive,
  setErrorText,
  revealRenderLoop
}) {
  function ensureShellProgram() {
    let shell = getShellRenderProgram();
    if (!shell) {
      shell = compileProgram(fallbackFragmentSource);
      setShellRenderProgram(shell);
    }
    return shell;
  }

  function ensureBlitProgram() {
    let blit = getBlitProgram();
    if (!blit) {
      blit = compileProgram(blitSource);
      setBlitProgram(blit);
    }
    return blit;
  }

  function finishBoot({ reveal = false, fallback = false, errorText = "" } = {}) {
    setVisualsReady(true);
    setFallbackActive(Boolean(fallback));
    setErrorText(errorText);
    resize();
    clearFeedbackBuffers();
    if (reveal) revealRenderLoop?.();
  }

  function initializePrimary({ reveal = false, compileFull = true } = {}) {
    ensureWebGl();
    const shell = ensureShellProgram();
    const fullProgram = getFullRenderProgram();
    const renderProgram = getVisualFullShaderReady() && fullProgram ? fullProgram : shell;
    setRenderProgram(renderProgram);
    setShellActive(renderProgram === shell);
    ensureBlitProgram();
    textureAssets().ensureCoreTextures();
    ensureFullscreenQuad();
    const activePreset = getActivePreset();
    queuePresetShaderModulePrime(activePreset, reveal ? 2400 : 800);
    if (compileFull && presetShaderModuleId(activePreset) === null && !getVisualFullShaderReady()) {
      scheduleFullShaderCompile(reveal ? 6000 : 1800);
    }
  }

  function initializeFallback() {
    const shell = ensureShellProgram();
    setRenderProgram(shell);
    setShellActive(true);
    ensureBlitProgram();
    textureAssets().ensureCoreTextures();
    ensureFullscreenQuad();
  }

  function revealVisuals() {
    documentRef.body.classList.add("visuals-live");
    documentRef.body.classList.remove("visuals-idle");
  }

  return {
    finishBoot,
    initializePrimary,
    initializeFallback,
    revealVisuals
  };
}
