export function compileShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const error = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error(error || "Shader compile failed");
  }
  return shader;
}

export function createProgramFromSources(gl, vertexSource, fragmentSource, bindings = []) {
  const compiledVertex = compileShader(gl, gl.VERTEX_SHADER, vertexSource);
  const compiledFragment = compileShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
  const shaderProgram = gl.createProgram();
  gl.attachShader(shaderProgram, compiledVertex);
  gl.attachShader(shaderProgram, compiledFragment);
  for (const [index, name] of bindings) {
    gl.bindAttribLocation(shaderProgram, index, name);
  }
  gl.linkProgram(shaderProgram);
  gl.deleteShader(compiledVertex);
  gl.deleteShader(compiledFragment);
  if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
    const error = gl.getProgramInfoLog(shaderProgram);
    gl.deleteProgram(shaderProgram);
    throw new Error(error || "Shader link failed");
  }
  return shaderProgram;
}

export function createFullscreenProgram(gl, vertexSource, fragmentSource) {
  return createProgramFromSources(gl, vertexSource, fragmentSource, [[0, "position"]]);
}

export function createShaderProgramCompiler({
  getGl,
  vertexSource,
  createQuad,
  bindQuad,
  getQuad,
  setQuad,
  onError
} = {}) {
  function compileProgramFrom(vertex, fragment, bindings) {
    const gl = getGl();
    try {
      return createProgramFromSources(gl, vertex, fragment, bindings);
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }

  function compileFullscreenProgram(fragment) {
    const gl = getGl();
    try {
      return createFullscreenProgram(gl, vertexSource, fragment);
    } catch (error) {
      onError?.(error);
      throw error;
    }
  }

  function warmupDrawCall(programToUse) {
    if (!programToUse) return;
    const gl = getGl();
    let quad = getQuad?.();
    if (!quad) {
      quad = createQuad(gl);
      setQuad?.(quad);
    }
    const prevProgram = gl.getParameter(gl.CURRENT_PROGRAM);
    const prevArrayBuffer = gl.getParameter(gl.ARRAY_BUFFER_BINDING);
    const prevViewport = gl.getParameter(gl.VIEWPORT);
    gl.useProgram(programToUse);
    bindQuad(gl, quad);
    gl.viewport(0, 0, 1, 1);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    if (prevProgram) gl.useProgram(prevProgram);
    else gl.useProgram(null);
    gl.bindBuffer(gl.ARRAY_BUFFER, prevArrayBuffer);
    gl.viewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
  }

  return {
    programFrom: compileProgramFrom,
    program: compileFullscreenProgram,
    warmupDrawCall
  };
}

export function createVisualProgramController(options = {}) {
  const compiler = createShaderProgramCompiler(options);
  return {
    fromSources: (vertex, fragment, bindings) => compiler.programFrom(vertex, fragment, bindings),
    fullscreen: (fragment) => compiler.program(fragment),
    warmup: (programToUse) => compiler.warmupDrawCall(programToUse)
  };
}
