export const forgeCalligraphyVertexSource = `#version 300 es
precision highp float;
layout(location = 0) in vec4 aRibbon;
layout(location = 1) in vec4 aInk;
layout(location = 2) in vec2 aSource;
uniform vec2 uFieldSize;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform float uHighs;
uniform float uMids;
out vec2 vSourceUv;
out vec4 vInk;
void main() {
  float taper = pow(1.0 - aInk.x, 0.70);
  float width = (0.43 + 0.13 * uMids + 0.09 * uHighs) * taper + 0.07;
  vec2 pixel = aRibbon.xy + aRibbon.zw * aInk.y * width;
  vec2 uv = pixel / uFieldSize;
  vec2 point = vec2(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
  if (uCanvasAspect > uVideoAspect) point.x *= uVideoAspect / uCanvasAspect;
  else point.y *= uCanvasAspect / uVideoAspect;
  gl_Position = vec4(point, 0.0, 1.0);
  vSourceUv = vec2(aSource.x, 1.0 - aSource.y);
  vInk = aInk;
}`;

export const forgeCalligraphyFragmentSource = `#version 300 es
precision highp float;
in vec2 vSourceUv;
in vec4 vInk;
out vec4 outColor;
uniform sampler2D uVideo;
uniform float uPhase;
uniform float uHighs;
uniform float uMids;
uniform float uAnticipation;
uniform float uRelease;
uniform float uReleaseAge;
uniform float uPhrase;
uniform float uMaster;
uniform float uOpacity;
uniform float uOutputWidth;
uniform int uCompare;
void main() {
  if (uCompare == 1 && gl_FragCoord.x < uOutputWidth * 0.5) discard;
  vec3 beauty = texture(uVideo, vec2(vSourceUv.x, 1.0 - vSourceUv.y)).rgb;
  float light = max(beauty.r, max(beauty.g, beauty.b));
  // Retain the tint of the presented source spore with a soft white core.
  vec3 hue = mix(clamp(beauty / max(light, 0.035), 0.0, 1.0), vec3(1.0), 0.35);
  float core = exp(-vInk.y * vInk.y * 7.0);
  float taper = pow(1.0 - vInk.x, 1.05);
  // Musical onset strokes are encoded in vertex power. A fine fixed engraving
  // is only revealed as a stroke passes it; it does not animate independently.
  float stitches = pow(0.5 + 0.5 * sin(vInk.x * (19.0 + uHighs * 38.0 + uAnticipation * 25.0) + vInk.w), 8.0) * uHighs;
  float phrase = 0.88 + 0.12 * sin(uPhrase * 6.2831853 - vInk.x * 2.0);
  float release = exp(-pow((vInk.x - uReleaseAge * 0.65 + vInk.w * 0.02) / 0.10, 2.0)) * uRelease;
  float ink = (0.92 + stitches * 0.25 + release * 0.45) * core * taper * phrase;
  float alpha = clamp(ink * vInk.z * uMaster * uOpacity, 0.0, 0.67);
  outColor = vec4(hue * (0.77 + light * 0.23), alpha);
}`;
