import { createFullscreenProgram } from "./shaders.js";

export const WORLDSHELL_PRESET_ID = 193;
export const WORLDSHELL_RESONANCE_TEXTURE_UNIT = 12;

const vertexSource = `#version 300 es
in vec2 position;
out vec2 vUv;
void main() {
  vUv = position * 0.5 + 0.5;
  gl_Position = vec4(position, 0.0, 1.0);
}`;

// Texture contract exposed to Worldshell:
//   R: signed displacement encoded from [-1, 1] to [0, 1]
//   G: propagated impact energy / glow in [0, 1]
//   B: signed velocity encoded from [-1, 1] to [0, 1] (simulation internal)
//   A: reserved
// Keeping the public encoding identical for RGBA8 and RGBA16F makes the
// Worldshell shader independent of the render-target format available on a
// particular WebView/GPU.
const simulationFragmentSource = `#version 300 es
precision highp float;

in vec2 vUv;
out vec4 outState;

uniform sampler2D previousState;
uniform vec2 texelSize;
uniform float stepScale;
uniform float waveSpeed;
uniform float damping;
uniform float energyDecay;
uniform float turbulence;
uniform float simulationTime;
uniform vec4 impulses[4];

float decodeSigned(float encodedValue) {
  return encodedValue * 2.0 - 1.0;
}

vec2 wrappedDelta(vec2 a, vec2 b) {
  return fract(a - b + 0.5) - 0.5;
}

float impulseWave(vec4 impulse) {
  if (abs(impulse.w) < 0.0001 || impulse.z < 0.0001) return 0.0;
  float distanceFromCenter = length(wrappedDelta(vUv, impulse.xy));
  float normalizedDistance = distanceFromCenter / impulse.z;
  float core = exp(-normalizedDistance * normalizedDistance * 7.5);
  float rim = exp(-pow(normalizedDistance - 1.15, 2.0) * 18.0);
  return impulse.w * (core - rim * 0.24);
}

float fieldNoise(vec2 p) {
  vec3 q = fract(vec3(p.xyx) * vec3(123.34, 456.21, 93.17));
  q += dot(q, q.yzx + 34.45);
  return fract((q.x + q.y) * q.z) * 2.0 - 1.0;
}

void main() {
  vec4 state = texture(previousState, vUv);
  float height = decodeSigned(state.r);
  float velocity = decodeSigned(state.b);
  float energy = state.g;

  float north = decodeSigned(texture(previousState, vUv + vec2(0.0, texelSize.y)).r);
  float south = decodeSigned(texture(previousState, vUv - vec2(0.0, texelSize.y)).r);
  float east = decodeSigned(texture(previousState, vUv + vec2(texelSize.x, 0.0)).r);
  float west = decodeSigned(texture(previousState, vUv - vec2(texelSize.x, 0.0)).r);
  float diagonalA = decodeSigned(texture(previousState, vUv + texelSize).r);
  float diagonalB = decodeSigned(texture(previousState, vUv - texelSize).r);
  float diagonalC = decodeSigned(texture(previousState, vUv + vec2(texelSize.x, -texelSize.y)).r);
  float diagonalD = decodeSigned(texture(previousState, vUv + vec2(-texelSize.x, texelSize.y)).r);

  // The axial and diagonal taps create a rounder travelling front than a
  // four-neighbour stencil, which matters when the field is projected across
  // both the ocean and the enclosing shell.
  float axialLaplacian = north + south + east + west - 4.0 * height;
  float diagonalLaplacian = diagonalA + diagonalB + diagonalC + diagonalD - 4.0 * height;
  float laplacian = axialLaplacian * 0.78 + diagonalLaplacian * 0.11;

  float impulse = 0.0;
  for (int i = 0; i < 4; i += 1) impulse += impulseWave(impulses[i]);

  float agitation = fieldNoise(vUv * 37.0 + simulationTime * vec2(0.071, -0.053));
  float residualDrive = agitation * turbulence * (0.012 + energy * 0.022);
  velocity += (laplacian * waveSpeed + impulse + residualDrive) * stepScale;
  velocity *= pow(damping, stepScale);
  height += velocity * stepScale;

  // Soft limiting prevents stacked drop impulses from destabilising the wave
  // equation without flattening normal kick-sized waves.
  height /= 1.0 + abs(height) * 0.13;
  velocity /= 1.0 + abs(velocity) * 0.09;
  height = clamp(height, -0.985, 0.985);
  velocity = clamp(velocity, -0.985, 0.985);

  float localMotion = abs(velocity) * 0.72 + abs(laplacian) * 0.20;
  float impactEnergy = abs(impulse) * 0.92;
  energy = max(energy * pow(energyDecay, stepScale), localMotion + impactEnergy);
  energy = clamp(energy, 0.0, 1.0);

  outState = vec4(height * 0.5 + 0.5, energy, velocity * 0.5 + 0.5, 1.0);
}`;

function clamp01(value) {
  return Math.max(0, Math.min(1, Number(value) || 0));
}

function fract(value) {
  return value - Math.floor(value);
}

function hash01(value) {
  return fract(Math.sin(value * 12.9898 + 78.233) * 43758.5453123);
}

function restoreCapability(gl, capability, enabled) {
  if (enabled) gl.enable(capability);
  else gl.disable(capability);
}

function withPreservedGlState(gl, action) {
  const framebuffer = gl.getParameter(gl.FRAMEBUFFER_BINDING);
  const currentProgram = gl.getParameter(gl.CURRENT_PROGRAM);
  const vertexArray = gl.getParameter(gl.VERTEX_ARRAY_BINDING);
  const arrayBuffer = gl.getParameter(gl.ARRAY_BUFFER_BINDING);
  const viewport = Array.from(gl.getParameter(gl.VIEWPORT));
  const activeTexture = gl.getParameter(gl.ACTIVE_TEXTURE);
  const depthTest = gl.isEnabled(gl.DEPTH_TEST);
  const blend = gl.isEnabled(gl.BLEND);
  const scissor = gl.isEnabled(gl.SCISSOR_TEST);
  const cullFace = gl.isEnabled(gl.CULL_FACE);
  const depthMask = gl.getParameter(gl.DEPTH_WRITEMASK);
  const colorMask = Array.from(gl.getParameter(gl.COLOR_WRITEMASK));

  gl.activeTexture(gl.TEXTURE0);
  const texture0 = gl.getParameter(gl.TEXTURE_BINDING_2D);
  let activeTextureBinding = texture0;
  if (activeTexture !== gl.TEXTURE0) {
    gl.activeTexture(activeTexture);
    activeTextureBinding = gl.getParameter(gl.TEXTURE_BINDING_2D);
  }

  try {
    return action();
  } finally {
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
    gl.useProgram(currentProgram);
    gl.bindVertexArray(vertexArray);
    gl.bindBuffer(gl.ARRAY_BUFFER, arrayBuffer);
    gl.viewport(viewport[0], viewport[1], viewport[2], viewport[3]);
    restoreCapability(gl, gl.DEPTH_TEST, depthTest);
    restoreCapability(gl, gl.BLEND, blend);
    restoreCapability(gl, gl.SCISSOR_TEST, scissor);
    restoreCapability(gl, gl.CULL_FACE, cullFace);
    gl.depthMask(depthMask);
    gl.colorMask(colorMask[0], colorMask[1], colorMask[2], colorMask[3]);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture0);
    if (activeTexture !== gl.TEXTURE0) {
      gl.activeTexture(activeTexture);
      gl.bindTexture(gl.TEXTURE_2D, activeTextureBinding);
    }
    gl.activeTexture(activeTexture);
  }
}

function createTarget(gl, width, height, format) {
  const texture = gl.createTexture();
  const framebuffer = gl.createFramebuffer();
  if (!texture || !framebuffer) {
    if (framebuffer) gl.deleteFramebuffer(framebuffer);
    if (texture) gl.deleteTexture(texture);
    throw new Error("Worldshell resonance target allocation failed");
  }
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, format.filter);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, format.filter);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
  gl.texImage2D(
    gl.TEXTURE_2D,
    0,
    format.internalFormat,
    width,
    height,
    0,
    gl.RGBA,
    format.type,
    null
  );
  gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
  const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
  if (status !== gl.FRAMEBUFFER_COMPLETE) {
    gl.deleteFramebuffer(framebuffer);
    gl.deleteTexture(texture);
    throw new Error(`Worldshell resonance framebuffer incomplete (${status})`);
  }
  return { tex: texture, fb: framebuffer };
}

function deleteTarget(gl, target) {
  if (!target) return;
  if (target.tex) gl.deleteTexture(target.tex);
  if (target.fb) gl.deleteFramebuffer(target.fb);
}

function createTargetPair(gl, width, height, format) {
  const pair = [];
  try {
    pair.push(createTarget(gl, width, height, format));
    pair.push(createTarget(gl, width, height, format));
    return pair;
  } catch (error) {
    for (const target of pair) deleteTarget(gl, target);
    throw error;
  }
}

function uniform(gl, locations, program, name) {
  if (!locations.has(name)) locations.set(name, gl.getUniformLocation(program, name));
  return locations.get(name);
}

export function isWorldshellResonanceActive(presetId, quality) {
  return Math.round(Number(presetId)) === WORLDSHELL_PRESET_ID && Number(quality) > 0.5;
}

export function createNullWorldshellResonanceRuntime() {
  return {
    warm: () => false,
    step: () => false,
    bind: () => false,
    inject: () => {},
    reset: () => {},
    dispose: () => {},
    texture: () => null,
    ready: () => false,
    active: () => false,
    status: () => ({ ready: false, active: false, failed: false, format: "none", frames: 0 })
  };
}

export function createWorldshellResonanceRuntime({
  getGl,
  width = 192,
  height = 128,
  onError = (error) => console.warn("Worldshell resonance simulation disabled:", error)
} = {}) {
  const simulationWidth = Math.max(32, Math.min(512, Math.round(width)));
  const simulationHeight = Math.max(32, Math.min(512, Math.round(height)));
  let program = null;
  let quadBuffer = null;
  let quadVao = null;
  let targets = [];
  let readIndex = 0;
  let locations = new Map();
  let resourceContext = null;
  let formatName = "none";
  let failed = false;
  let errorMessage = "";
  let active = false;
  let lastStepAt = 0;
  let lastFrameToken = null;
  let previousKick = 0;
  let previousDrop = 0;
  let previousSection = 0;
  let lastBeatIndex = -1;
  let frameCount = 0;
  const pendingImpulses = [];
  const packedImpulses = new Float32Array(16);
  let bindLocationsByProgram = new WeakMap();
  let textureUnitLimitContext = null;
  let maxTextureUnitIndex = 0;
  let drawPathWarmed = false;

  function context() {
    const gl = getGl?.();
    if (!gl || gl.isContextLost?.()) return null;
    return gl;
  }

  function reportFailure(error) {
    if (failed) return;
    failed = true;
    errorMessage = error?.message || String(error);
    onError?.(error);
  }

  function releaseResources(gl) {
    const canDelete = gl && (!resourceContext || resourceContext === gl);
    if (canDelete) {
      for (const target of targets) deleteTarget(gl, target);
    }
    targets = [];
    if (canDelete && quadVao) gl.deleteVertexArray(quadVao);
    if (canDelete && quadBuffer) gl.deleteBuffer(quadBuffer);
    if (canDelete && program) gl.deleteProgram(program);
    program = null;
    quadBuffer = null;
    quadVao = null;
    locations = new Map();
    bindLocationsByProgram = new WeakMap();
    formatName = "none";
    resourceContext = null;
    drawPathWarmed = false;
  }

  function clearTargets(gl) {
    const initialState = new Float32Array([0.5, 0.0, 0.5, 1.0]);
    for (const target of targets) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, simulationWidth, simulationHeight);
      gl.clearBufferfv(gl.COLOR, 0, initialState);
    }
    readIndex = 0;
  }

  function allocateTargets(gl) {
    const floatFormatAvailable = Boolean(gl.getExtension("EXT_color_buffer_float"));
    const floatLinearAvailable = Boolean(gl.getExtension("OES_texture_float_linear"));
    if (floatFormatAvailable) {
      const halfFloatFormat = {
        internalFormat: gl.RGBA16F,
        type: gl.HALF_FLOAT,
        filter: floatLinearAvailable ? gl.LINEAR : gl.NEAREST
      };
      try {
        targets = createTargetPair(gl, simulationWidth, simulationHeight, halfFloatFormat);
        formatName = floatLinearAvailable ? "rgba16f-linear" : "rgba16f-nearest";
        return;
      } catch (error) {
        for (const target of targets) deleteTarget(gl, target);
        targets = [];
      }
    }

    const byteFormat = {
      internalFormat: gl.RGBA8,
      type: gl.UNSIGNED_BYTE,
      filter: gl.LINEAR
    };
    targets = createTargetPair(gl, simulationWidth, simulationHeight, byteFormat);
    formatName = "rgba8-linear";
  }

  function buildResources(gl) {
    resourceContext = gl;
    program = createFullscreenProgram(gl, vertexSource, simulationFragmentSource);
    quadBuffer = gl.createBuffer();
    quadVao = gl.createVertexArray();
    if (!quadBuffer || !quadVao) throw new Error("Worldshell resonance fullscreen geometry allocation failed");
    gl.bindVertexArray(quadVao);
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    allocateTargets(gl);
    clearTargets(gl);
  }

  function ensureResources(gl) {
    if (resourceContext === gl && program && targets.length === 2 && gl.isProgram(program)) return true;
    releaseResources(gl);
    withPreservedGlState(gl, () => buildResources(gl));
    return true;
  }

  function warm() {
    const gl = context();
    if (!gl || failed) return false;
    try {
      ensureResources(gl);
      if (!drawPathWarmed) {
        withPreservedGlState(gl, () => {
          renderSimulationStep(gl, {
            bass: 0,
            density: 0,
            flux: 0,
            highs: 0,
            time: 0
          }, 1, [], false);
          clearTargets(gl);
        });
        drawPathWarmed = true;
      }
      // The immediately following Worldshell pipeline warm now binds a real,
      // cleared resonance texture with worldshellResonanceReady=1. This
      // exercises both shader paths before the first user-visible selection.
      active = true;
      return true;
    } catch (error) {
      try {
        withPreservedGlState(gl, () => releaseResources(gl));
      } catch {
        // The analytic fallback remains available when cleanup is impossible.
      }
      reportFailure(error);
      return false;
    }
  }

  function resetEventState() {
    previousKick = 0;
    previousDrop = 0;
    previousSection = 0;
    lastBeatIndex = -1;
    lastStepAt = 0;
    lastFrameToken = null;
    pendingImpulses.length = 0;
  }

  function reset() {
    const gl = context();
    resetEventState();
    if (!gl || targets.length !== 2) return;
    try {
      withPreservedGlState(gl, () => clearTargets(gl));
    } catch (error) {
      active = false;
      reportFailure(error);
    }
  }

  function inject({ x = 0.5, y = 0.5, radius = 0.06, strength = 0.4 } = {}) {
    pendingImpulses.push([
      fract(Number(x) || 0),
      fract(Number(y) || 0),
      Math.max(0.005, Math.min(0.45, Number(radius) || 0.06)),
      Math.max(-1.5, Math.min(1.5, Number(strength) || 0))
    ]);
    if (pendingImpulses.length > 12) pendingImpulses.splice(0, pendingImpulses.length - 12);
  }

  function collectAutomaticImpulses(input) {
    const absoluteBeat = Math.max(0, Number(input.absoluteBeat) || 0);
    const beatIndex = Math.floor(absoluteBeat + 0.08);
    const kickDrive = Math.max(
      clamp01(input.kick),
      clamp01(input.kickPulse),
      clamp01(input.beatStrength) * 0.82
    );
    const dropDrive = Math.max(clamp01(input.drop), clamp01(input.dropDetected));
    const sectionDrive = clamp01(input.sectionChange);
    const bassDrive = Math.max(clamp01(input.bass), clamp01(input.bassRel));

    const kickEvent = kickDrive > 0.16
      && (previousKick <= 0.16 || (beatIndex !== lastBeatIndex && kickDrive > 0.24));
    if (kickEvent) {
      const seed = beatIndex + 1 + Math.floor((Number(input.trackProgress) || 0) * 97);
      inject({
        x: 0.12 + hash01(seed * 1.31) * 0.76,
        y: 0.13 + hash01(seed * 2.17 + 4.0) * 0.74,
        radius: 0.027 + bassDrive * 0.030,
        strength: (0.18 + kickDrive * 0.48 + bassDrive * 0.10)
          * (1 - clamp01(input.breakdownInfluence) * 0.55)
      });
      lastBeatIndex = beatIndex;
    }

    if (dropDrive > 0.34 && previousDrop <= 0.34) {
      inject({ x: 0.5, y: 0.5, radius: 0.15 + dropDrive * 0.055, strength: 0.72 + dropDrive * 0.50 });
      inject({ x: 0.0, y: 0.0, radius: 0.10 + bassDrive * 0.05, strength: -(0.30 + dropDrive * 0.22) });
    }

    if (sectionDrive > 0.58 && previousSection <= 0.58) {
      const sectionSeed = beatIndex + 211;
      inject({
        x: hash01(sectionSeed * 0.73),
        y: hash01(sectionSeed * 1.77),
        radius: 0.19,
        strength: 0.28 + sectionDrive * 0.24
      });
    }

    previousKick = kickDrive;
    previousDrop = dropDrive;
    previousSection = sectionDrive;
  }

  function renderSimulationStep(gl, input, stepScale, impulses, includeImpulses) {
    const writeIndex = 1 - readIndex;
    const readTarget = targets[readIndex];
    const writeTarget = targets[writeIndex];
    gl.bindFramebuffer(gl.FRAMEBUFFER, writeTarget.fb);
    gl.viewport(0, 0, simulationWidth, simulationHeight);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.BLEND);
    gl.disable(gl.SCISSOR_TEST);
    gl.disable(gl.CULL_FACE);
    gl.depthMask(false);
    gl.colorMask(true, true, true, true);
    gl.useProgram(program);
    gl.bindVertexArray(quadVao);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, readTarget.tex);
    gl.uniform1i(uniform(gl, locations, program, "previousState"), 0);
    gl.uniform2f(
      uniform(gl, locations, program, "texelSize"),
      1 / simulationWidth,
      1 / simulationHeight
    );
    gl.uniform1f(uniform(gl, locations, program, "stepScale"), stepScale);
    gl.uniform1f(uniform(gl, locations, program, "waveSpeed"), 0.155 + clamp01(input.bass) * 0.018);
    gl.uniform1f(uniform(gl, locations, program, "damping"), 0.968 - clamp01(input.density) * 0.006);
    gl.uniform1f(uniform(gl, locations, program, "energyDecay"), 0.951);
    gl.uniform1f(
      uniform(gl, locations, program, "turbulence"),
      clamp01(input.flux) * (0.20 + clamp01(input.highs) * 0.45)
        * (1 - clamp01(input.breakdownInfluence) * 0.45)
    );
    gl.uniform1f(uniform(gl, locations, program, "simulationTime"), Number(input.time) || 0);

    packedImpulses.fill(0);
    if (includeImpulses) {
      for (let index = 0; index < Math.min(4, impulses.length); index += 1) {
        packedImpulses.set(impulses[index], index * 4);
      }
    }
    gl.uniform4fv(uniform(gl, locations, program, "impulses[0]"), packedImpulses);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    readIndex = writeIndex;
  }

  function step(input = {}) {
    const shouldRun = isWorldshellResonanceActive(input.presetId, input.quality);
    if (!shouldRun) {
      if (active) resetEventState();
      active = false;
      return false;
    }

    const gl = context();
    if (!gl || failed) return false;
    const now = Number.isFinite(Number(input.nowMs))
      ? Number(input.nowMs)
      : (globalThis.performance?.now?.() || Date.now());
    const frameToken = input.frameToken ?? input.nowMs;
    if (frameToken !== undefined && frameToken !== null && frameToken === lastFrameToken) return active;
    lastFrameToken = frameToken;

    try {
      ensureResources(gl);
      if (!active) {
        withPreservedGlState(gl, () => clearTargets(gl));
        resetEventState();
        lastFrameToken = frameToken;
      }
      active = true;
      collectAutomaticImpulses(input);

      const suppliedDelta = Number(input.deltaSeconds);
      const measuredDelta = lastStepAt > 0 ? (now - lastStepAt) * 0.001 : 1 / 60;
      const deltaSeconds = Math.max(
        1 / 240,
        Math.min(1 / 20, Number.isFinite(suppliedDelta) ? suppliedDelta : measuredDelta)
      );
      lastStepAt = now;
      const substepCount = Math.max(1, Math.min(3, Math.ceil(deltaSeconds * 60)));
      const substepScale = deltaSeconds * 60 / substepCount;
      const impulses = pendingImpulses
        .splice(0, pendingImpulses.length)
        .sort((a, b) => Math.abs(b[3]) - Math.abs(a[3]))
        .slice(0, 4);

      withPreservedGlState(gl, () => {
        for (let index = 0; index < substepCount; index += 1) {
          renderSimulationStep(gl, input, substepScale, impulses, index === 0);
        }
      });
      frameCount += 1;
      return true;
    } catch (error) {
      active = false;
      try {
        withPreservedGlState(gl, () => releaseResources(gl));
      } catch {
        // The analytic Worldshell fallback remains usable even if cleanup is
        // impossible during a context-loss edge case.
      }
      reportFailure(error);
      return false;
    }
  }

  function bind(targetProgram, {
    textureUnit = WORLDSHELL_RESONANCE_TEXTURE_UNIT,
    fallbackTexture = null,
    presetId = WORLDSHELL_PRESET_ID,
    quality = 1
  } = {}) {
    const gl = context();
    if (!gl || !targetProgram) return false;
    const runtimeReady = !failed
      && active
      && isWorldshellResonanceActive(presetId, quality)
      && targets.length === 2;
    const texture = runtimeReady ? targets[readIndex].tex : fallbackTexture;
    if (textureUnitLimitContext !== gl) {
      textureUnitLimitContext = gl;
      maxTextureUnitIndex = Math.max(0, Number(gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS)) - 1);
    }
    const unit = Math.max(0, Math.min(
      maxTextureUnitIndex,
      Math.round(textureUnit)
    ));
    const previousActiveTexture = gl.getParameter(gl.ACTIVE_TEXTURE);
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    let bindLocations = bindLocationsByProgram.get(targetProgram);
    if (!bindLocations) {
      bindLocations = {
        texture: gl.getUniformLocation(targetProgram, "worldshellResonanceTexture"),
        ready: gl.getUniformLocation(targetProgram, "worldshellResonanceReady"),
        texel: gl.getUniformLocation(targetProgram, "worldshellResonanceTexel")
      };
      bindLocationsByProgram.set(targetProgram, bindLocations);
    }
    const textureLocation = bindLocations.texture;
    const readyLocation = bindLocations.ready;
    const texelLocation = bindLocations.texel;
    if (textureLocation !== null) gl.uniform1i(textureLocation, unit);
    if (readyLocation !== null) gl.uniform1f(readyLocation, runtimeReady ? 1 : 0);
    if (texelLocation !== null) {
      gl.uniform2f(
        texelLocation,
        runtimeReady ? 1 / simulationWidth : 1,
        runtimeReady ? 1 / simulationHeight : 1
      );
    }
    gl.activeTexture(previousActiveTexture);
    return runtimeReady;
  }

  function dispose() {
    const gl = context();
    if (gl) withPreservedGlState(gl, () => releaseResources(gl));
    else {
      program = null;
      quadBuffer = null;
      quadVao = null;
      targets = [];
      locations = new Map();
      resourceContext = null;
      formatName = "none";
    }
    active = false;
    resetEventState();
  }

  return {
    warm,
    step,
    bind,
    inject,
    reset,
    dispose,
    texture: () => (active && targets.length === 2 ? targets[readIndex].tex : null),
    ready: () => active && !failed && targets.length === 2,
    active: () => active,
    status: () => ({
      ready: active && !failed && targets.length === 2,
      active,
      failed,
      error: errorMessage,
      format: formatName,
      width: simulationWidth,
      height: simulationHeight,
      frames: frameCount
    })
  };
}
