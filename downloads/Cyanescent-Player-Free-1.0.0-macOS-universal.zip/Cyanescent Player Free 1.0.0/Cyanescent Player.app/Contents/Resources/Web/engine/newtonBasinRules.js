// Newton Basin Descent: glint attachment rules.
//
// Glints are specular sparkles that belong to the landscape. Each one is born on a visible
// surface texel and immediately converted to a WORLD position (camera position + ray * depth),
// so from then on it moves exactly as the landscape moves when the camera flies: every frame it
// is projected through the current camera. It never travels over the surface on its own.
//
// Every frame the glint is also re-checked against the current resolved field at its projected
// position. If the surface there is no longer the surface it was born on (something passed in
// front of it, it went over a silhouette, off screen, or into the sky), it fades out within a
// few frames and is removed. A glint therefore can never float in front of or behind the terrain.
//
// These constants are injected into the shaders, and `glintDecision` is the CPU reference of the
// same rule chain (used by tools/test-newton-basin.mjs).

export const GLINT = Object.freeze({
  spawnMaxDepth: 6.5,        // ray distance beyond which no glint is born (the far plain and fog)
  killDepth: 9.0,            // a glint whose surface lies beyond this is removed
  occludeRel: 0.05,          // the field depth at the glint must agree with its own distance:
  occludeAbs: 0.012,         //   |fieldDepth - distance| <= rel * distance + abs
  occludeFadeSeconds: 0.06,  // how quickly an occluded glint fades before it is removed
  edgeRel: 0.09,             // relative depth range over the 4-neighbourhood => silhouette
  margin: 0.006,             // field-UV margin
  minSurface: 0.35,          // surface mask (hit, no silhouette, not too far) needed to stay
  spawnSurface: 0.8,         // and to be born
  life: Object.freeze([[0.22, 0.55], [0.10, 0.32], [0.30, 0.70]]),   // per kind (seconds)
  markerSeconds: 0.6         // how long the attachment diagnostic shows a removed glint
});

// Glint kinds: 0 surf (born where a ripple wave breaks on dense structure), 1 hat (a specular
// sparkle on a bright surface, driven by the hi-hats), 2 drop (a burst when the drop hits).
export const GLINT_KIND = Object.freeze({ surf: 0, hat: 1, drop: 2 });

// Why a glint ended. 0 means it is still valid.
export const GLINT_END = Object.freeze({ none: 0, sky: 1, occluded: 2, edge: 3, offscreen: 4, life: 5 });
export const GLINT_END_NAMES = Object.freeze(["valid", "sky", "occluded", "silhouette edge", "off-screen", "life end"]);

// Reference of the shader rule chain for a live glint projected to `uv` at `distance` from the
// current camera, against the resolved field sample { hit, depth, surface } there. Returns
// { end, visible } where visible is the updated occlusion fade.
export function glintDecision({ uv, distance, field, visible = 1, dt = 1 / 60 }) {
  const m = GLINT.margin;
  if (uv[0] < m || uv[1] < m || uv[0] > 1 - m || uv[1] > 1 - m) return { end: GLINT_END.offscreen, visible: 0 };
  if (!field.hit || field.depth <= 0 || field.depth > GLINT.killDepth) return { end: GLINT_END.sky, visible: 0 };
  if (field.surface < GLINT.minSurface) return { end: GLINT_END.edge, visible: 0 };
  const occluded = Math.abs(field.depth - distance) > GLINT.occludeRel * distance + GLINT.occludeAbs;
  const next = Math.min(1, Math.max(0, visible + (occluded ? -1 : 1) * dt / GLINT.occludeFadeSeconds));
  if (occluded && next <= 0) return { end: GLINT_END.occluded, visible: 0 };
  return { end: GLINT_END.none, visible: next };
}

// Whether a candidate texel may give birth to a glint at all.
export function glintSpawnAllowed({ hit, depth, surface }) {
  return Boolean(hit) && depth > 0 && depth <= GLINT.spawnMaxDepth && surface >= GLINT.spawnSurface;
}

// Shader constants as GLSL #defines.
export function glintDefines() {
  const f = (value) => (Number.isInteger(value) ? `${value}.0` : String(value));
  return `
#define GT_SPAWN_MAX_DEPTH ${f(GLINT.spawnMaxDepth)}
#define GT_KILL_DEPTH ${f(GLINT.killDepth)}
#define GT_OCC_REL ${f(GLINT.occludeRel)}
#define GT_OCC_ABS ${f(GLINT.occludeAbs)}
#define GT_OCC_FADE ${f(GLINT.occludeFadeSeconds)}
#define GT_EDGE_REL ${f(GLINT.edgeRel)}
#define GT_MARGIN ${f(GLINT.margin)}
#define GT_MIN_SURFACE ${f(GLINT.minSurface)}
#define GT_SPAWN_SURFACE ${f(GLINT.spawnSurface)}
#define GT_MARKER ${f(GLINT.markerSeconds)}
const vec3 GT_LIFE_MIN = vec3(${GLINT.life.map((pair) => f(pair[0])).join(", ")});
const vec3 GT_LIFE_MAX = vec3(${GLINT.life.map((pair) => f(pair[1])).join(", ")});
`;
}
