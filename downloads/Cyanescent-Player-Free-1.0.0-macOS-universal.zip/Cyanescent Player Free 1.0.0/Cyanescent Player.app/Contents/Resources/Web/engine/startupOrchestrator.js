import {
  createAppReadySetter,
  createInitialBootActionProcessor,
  createSplashProgressSetter,
  createStartupWarmupTasks,
  createVisualEngineBootRunner
} from "./visualBoot.js";

export function createStartupOrchestrator({
  ui,
  setBootComplete,
  loadPlayerFiles,
  releaseObjectUrls,
  setPlayerQueue,
  appendNativeTracks,
  enterFullscreen,
  initializeDefaultFolderOptions,
  reportPlayerError,
  ensureFernGeometryResources,
  ensurePineResources,
  ensureAdditionalGeometryResources,
  warmPresetModules,
  isFullShaderReady,
  startFullShaderCompile,
  fullShaderStatus,
  compileFullShaderSynchronously,
  waitForFullShaderReady,
  createRenderer,
  allocateFrameBuffers,
  finalizeReady,
  finalizeError,
  onSplashProgress
}) {
  const setSplashProgressView = createSplashProgressSetter(ui);
  const setSplashProgress = (progress, status) => {
    setSplashProgressView(progress, status);
    onSplashProgress?.(progress, status);
  };
  const setAppReady = createAppReadySetter({
    ui,
    onReadyStateChanged: setBootComplete
  });

  const startupWarmupTasks = createStartupWarmupTasks({
    setProgress: setSplashProgress,
    ensureGeometryResources: ensureFernGeometryResources,
    ensurePineResources,
    ensureAdditionalGeometryResources,
    warmPresetModules,
    isFullShaderReady,
    startFullShaderCompile,
    fullShaderStatus,
    compileFullShaderSynchronously,
    waitForFullShaderReady
  });

  const processPendingInitialBootActions = createInitialBootActionProcessor({
    loadPlayerFiles: (files) => loadPlayerFiles(files, false),
    loadNativeTracks: (tracks, options = {}) => {
      if (appendNativeTracks) return appendNativeTracks(tracks, Boolean(options.autoplay), options);
      releaseObjectUrls();
      return setPlayerQueue(tracks, 0, Boolean(options.autoplay));
    },
    enterFullscreen,
    initializeDefaultFolderOptions,
    reportPlayerError
  });

  const runVisualEngineStartup = createVisualEngineBootRunner({
    ui,
    setAppReady,
    setProgress: setSplashProgress,
    createRenderer,
    warmGeometry: startupWarmupTasks.warmGeometry,
    warmPresetModules: startupWarmupTasks.warmPresetRegistry,
    warmFullShader: startupWarmupTasks.warmFullShader,
    allocateFrameBuffers,
    finalizeReady: () => {
      finalizeReady?.();
      processPendingInitialBootActions();
    },
    finalizeError: (error) => finalizeError?.(error),
    finalizeErrorReady: () => {
      processPendingInitialBootActions();
    }
  });

  return {
    setSplashProgress,
    setAppReady,
    processPendingInitialBootActions,
    startupWarmupTasks,
    runVisualEngineStartup
  };
}
