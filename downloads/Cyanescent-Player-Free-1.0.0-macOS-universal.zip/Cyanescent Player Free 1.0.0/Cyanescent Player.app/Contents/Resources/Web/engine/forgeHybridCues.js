const clamp = (x, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, x));

// Interpret the Player's existing analysis; this is choreography memory, not a
// new beat/section classifier. Genuine lookahead is only used when available.
export function createForgeCues() {
  const state = {
    energy: 0, bass: 0, mids: 0, highs: 0, kick: 0,
    anticipation: 0, upcomingBreakdown: 0, breakdown: 0,
    release: 0, releaseAge: 1000, releaseSerial: 0,
    phrase8: 0, phrase16: 0, phrase32: 0, beat: 0, seconds: 0,
    futureBrightness: 0, futureDensity: 0, riff: 0
  };
  let dropHigh = false;
  let lowSeconds = 0;
  let wasBreakdown = false;
  let lastReleaseSeconds = -Infinity;
  function reset() {
    for (const key of Object.keys(state)) state[key] = key === "releaseAge" ? 1000 : 0;
    dropHigh = false; lowSeconds = 0; wasBreakdown = false; lastReleaseSeconds = -Infinity;
  }
  function update({ dt, music = {}, audio = {}, bands = {}, lookahead = {}, tempo = {}, authoredBPM = 120 }) {
    dt = clamp(Number(dt) || 0, 0, 0.1);
    state.seconds += dt;
    function envelope(key, target, rise, fall) {
      target = clamp(Number(target) || 0);
      state[key] += (target - state[key]) * (1 - Math.exp(-dt / (target > state[key] ? rise : fall)));
    }
    envelope("energy", audio.globalEnergy ?? music.adaptiveIntensity, 0.30, 1.5);
    envelope("bass", bands.bass, 0.12, 0.7);
    envelope("mids", bands.mids, 0.14, 0.6);
    envelope("highs", bands.highs, 0.08, 0.4);
    envelope("kick", audio.kickPulse, 0.035, 0.22);
    envelope("anticipation", lookahead.ready ? Math.max(music.upcomingDrop || 0, (music.upcomingBuild || 0) * 0.45) : 0, 0.8, 1.2);
    envelope("upcomingBreakdown", lookahead.ready ? music.upcomingBreakdown : 0, 1.2, 1.5);
    envelope("futureBrightness", lookahead.ready ? music.futureBrightness : 0, 1.0, 1.0);
    envelope("futureDensity", lookahead.ready ? music.futureDensity : 0, 1.0, 1.0);
    envelope("riff", music.mainRiff, 0.8, 1.3);
    lowSeconds = state.energy < 0.25 ? lowSeconds + dt : Math.max(0, lowSeconds - dt * 2);
    const sustainedQuiet = lowSeconds >= 3 ? 0.85 : 0;
    const breakdownTarget = Math.max(Number(music.breakdown) || 0, sustainedQuiet);
    envelope("breakdown", breakdownTarget, 1.2, 1.8);
    const drop = Math.max(Number(music.drop) || 0, Number(audio.dropDetected) || 0) > 0.38;
    if (breakdownTarget > 0.60) wasBreakdown = true;
    const building = Math.max(Number(music.buildUp) || 0, Number(music.build) || 0,
      lookahead.ready ? Number(music.upcomingDrop) || 0 : 0) > 0.20;
    const returned = wasBreakdown && state.energy > 0.48 && breakdownTarget < 0.35 && !building;
    // The live transient detector can report another energy surge inside a
    // loud passage. Preserve a sixteen-beat release gesture rather than
    // restarting the sky and junction discharge on each such surge.
    const releaseSpacing = 16 * 60 / (Number(tempo.bpm) || authoredBPM);
    if (((drop && !dropHigh) || returned) && state.seconds - lastReleaseSeconds >= releaseSpacing) {
      state.release = 1; state.releaseAge = 0; state.releaseSerial++;
      lastReleaseSeconds = state.seconds;
      wasBreakdown = false; lowSeconds = 0;
    }
    dropHigh = drop;
    state.releaseAge += dt;
    state.release *= Math.exp(-dt / 4.0);
    const suppliedBeat = Number(music.absoluteBeat);
    state.beat = Number.isFinite(suppliedBeat) && suppliedBeat >= 0 ? suppliedBeat
      : state.beat + dt * (Number(tempo.bpm) || authoredBPM) / 60;
    state.phrase8 = ((state.beat % 8) + 8) % 8 / 8;
    state.phrase16 = ((state.beat % 16) + 16) % 16 / 16;
    state.phrase32 = ((state.beat % 32) + 32) % 32 / 32;
    return state;
  }
  return { state, update, reset };
}
