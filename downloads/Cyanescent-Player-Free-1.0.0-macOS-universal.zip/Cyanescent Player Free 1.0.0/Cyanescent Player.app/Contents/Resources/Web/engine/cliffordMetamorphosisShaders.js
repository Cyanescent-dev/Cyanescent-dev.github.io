// Clifford Phase Space: Metamorphosis — GLSL.
//
// One vertex is one orbit of the Clifford map, computed from scratch on the GPU every frame (no
// attributes, no persistent particle state). Its last iterates give the point, its direction of
// travel (colour) and the delay coordinate (depth). Points accumulate additively into a float
// density image that decays over a fraction of a second; the composite maps density through a
// logarithm as in the fractal-flame algorithm, so faint feathers and dense folds share the frame.
//
// Each orbit is drawn as a short antialiased streak along its local unstable direction (the tangent
// carried forward through the last iterations), evaluated inside a small point sprite. The natural
// (SRB) measure of a strange attractor is smooth along its unstable manifolds, so this is a density
// estimate with a kernel aligned to the filaments: strands stay sharp across, continuous along, and
// one primitive yields several samples (primitive count, not arithmetic or fill, is what limits a
// tile-based GPU here).
//
// Orbit ranges: [0, uBulkCount) is the attractor itself; then PULSE_SLOTS groups of uPulseVerts
// orbits, each the forward image of a tiny disc around one attractor point:
// light that runs along the attractor's own unstable manifold.

export const PULSE_SLOTS = 10;
export const WORLD_SLOTS = 10;

export const cmPointsVertexSource = `#version 300 es
precision highp float;
precision highp int;
#define PULSES ${PULSE_SLOTS}
#define WORLDS ${WORLD_SLOTS}
uniform highp sampler2D uRoute;   // row 0: a b c d; row 1: centre x, centre y, 1/extent, world coordinate; row 2: axis stretch
uniform int uRouteSamples;
uniform float uRouteU;            // route position, in samples
uniform float uRouteDU;           // route advance during the frame (shutter)
uniform float uSpan;              // length of route history behind the front face, in samples
uniform float uSliceBias;         // > 1 concentrates orbits at the front face
uniform vec4 uFlex;               // musical parameter offset now
uniform vec4 uFlexPrev;           // ... and at the previous frame
uniform int uIterations;
uniform int uBulkCount;
uniform int uPulseVerts;
uniform vec4 uPulseA[PULSES];     // origin seed xy, slice, front (iterations travelled)
uniform vec4 uPulseB[PULSES];     // strength, palette hue, disc radius, accent mix
uniform vec4 uPulseP[PULSES];     // parameter snapshot taken when the pulse was born
uniform vec4 uErupt;              // eruption disc: centre xy, radius, share of orbits seeded in the disc
uniform mat4 uViewProj;
uniform mat4 uViewProjPrev;
uniform vec4 uShape;              // volume depth, delay lift, twist (radians across the volume), lift axis angle
uniform vec4 uStyle;              // hue drift, depth fog, base weight, pulse weight
uniform vec4 uStyle2;             // slice hue spread, fold glint, saturation, centre slice weight
uniform uint uSeed;
uniform vec3 uPalette[WORLDS * 4];
uniform vec3 uAccent[WORLDS];
uniform vec2 uView;               // viewport size in pixels
uniform float uSegment;           // streak half length in pixels
out vec4 vColor;
out vec2 vDir;                    // streak direction in pixels (y up)

uint pcg(uint v) {
  uint state = v * 747796405u + 2891336453u;
  uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
  return (word >> 22u) ^ word;
}
float unit(inout uint h) { h = pcg(h); return float(h >> 8) * (1.0 / 16777216.0); }

vec4 routeRow(float u, int row) {
  float n = float(uRouteSamples);
  float w = mod(u, n);
  int k = int(floor(w));
  float t = w - float(k);
  int k1 = k + 1 == uRouteSamples ? 0 : k + 1;
  return mix(texelFetch(uRoute, ivec2(k, row), 0), texelFetch(uRoute, ivec2(k1, row), 0), t);
}

// GPU sin() has absolute, not relative, accuracy: for the tiny half-steps of the difference form
// it must be the Taylor series.
float sinSmall(float x) { return abs(x) < 0.01 ? x * (1.0 - x * x * (1.0 / 6.0)) : sin(x); }

vec2 clifford(vec4 p, vec2 z) {
  return vec2(sin(p.x * z.y) + p.z * cos(p.x * z.x), sin(p.y * z.x) + p.w * cos(p.y * z.y));
}

vec3 paletteAt(int world, float h) {
  h = fract(h) * 4.0;
  int i = int(floor(h));
  float t = h - float(i);
  t = t * t * (3.0 - 2.0 * t);
  int base = clamp(world, 0, WORLDS - 1) * 4;
  return mix(uPalette[base + i], uPalette[base + ((i + 1) & 3)], t);
}
vec3 palette(float worldCoord, float h) {
  float w = max(worldCoord, 0.0);
  int a = int(floor(w));
  float t = smoothstep(0.0, 1.0, w - float(a));
  int b = a + 1 >= WORLDS ? 0 : a + 1;
  return mix(paletteAt(a, h), paletteAt(b, h), t);
}

void offscreen() { gl_Position = vec4(3.0, 3.0, 3.0, 1.0); gl_PointSize = 1.0; vColor = vec4(0.0); vDir = vec2(1.0, 0.0); }

void main() {
  int id = gl_VertexID;
  uint h = pcg(uint(id) ^ (uSeed * 2654435761u));
  float tau = unit(h);                       // where in the frame interval this orbit is observed
  bool pulse = id >= uBulkCount;
  int slot = pulse ? (id - uBulkCount) / max(uPulseVerts, 1) : 0;
  if (pulse && (slot >= PULSES || uPulseB[slot].x <= 0.0)) { offscreen(); return; }

  // Depth slice s in [0, 1]: s = 0 is the front face (the attractor now), larger s is the route
  // already travelled (the attractor's recent forms), placed further back: a time extrusion.
  float s = pulse ? uPulseA[slot].z : pow(unit(h), uSliceBias);
  float u = uRouteU - tau * uRouteDU - s * uSpan;
  vec4 p = pulse ? uPulseP[slot] : routeRow(u, 0) + mix(uFlex, uFlexPrev, tau);
  vec4 meta = routeRow(u, 1);

  vec2 z;
  vec2 zp;
  int steps;
  bool local = false;   // iterating the offset from the fixed point (difference form)
  vec2 o = uErupt.xy;
  if (pulse) {
    // Every vertex of the slot computes the same origin on the attractor, then leaves it from a
    // tiny disc and travels 'front' iterations: the forward image of the disc, i.e. a growing
    // piece of the unstable manifold through that point.
    z = uPulseA[slot].xy;
    for (int k = 0; k < 14; k++) z = clifford(p, z);
    float a = unit(h) * 6.2831853, r = uPulseB[slot].z * sqrt(unit(h));
    z += r * vec2(cos(a), sin(a));
    float front = uPulseA[slot].w;
    steps = int(floor(front)) + (unit(h) < fract(front) ? 1 : 0);
  } else if (unit(h) < uErupt.w) {
    // The eruption: orbits leave a disc around the repelling fixed point. Its forward image grows
    // from a dot into a filament, a folded sheet and finally the whole attractor as the disc grows.
    // The disc can be far smaller than float precision around the fixed point o, so its orbits are
    // iterated as offsets d = z - o in exact difference form (o = F(o)):
    //   sin(A + h) - sin(A) = 2 cos(A + h/2) sin(h/2),  cos(A + h) - cos(A) = -2 sin(A + h/2) sin(h/2)
    // until they are large enough to continue in absolute coordinates.
    float a = unit(h) * 6.2831853, r = uErupt.z * sqrt(unit(h));
    z = r * vec2(cos(a), sin(a));
    local = true;
    steps = uIterations;
  } else {
    z = vec2(unit(h), unit(h)) * 4.4 - 2.2;
    steps = uIterations;
  }
  zp = z;
  // The local stretching over the last iterations (a finite-time Lyapunov estimate) marks the
  // fold edges of the attractor, where nearby orbits separate fastest.
  vec2 v = vec2(0.70710678);
  float stretch = 0.0;
  for (int k = 0; k < 40; k++) {
    if (k >= steps) break;
    if (local) {
      vec2 d = z;
      if (max(abs(d.x), abs(d.y)) > 0.02) { local = false; z = o + d; zp = z; }
      else {
        vec2 hx = p.x * d * 0.5, hy = p.y * d * 0.5;
        z = vec2(2.0 * cos(p.x * o.y + hx.y) * sinSmall(hx.y) - 2.0 * p.z * sin(p.x * o.x + hx.x) * sinSmall(hx.x),
                 2.0 * cos(p.y * o.x + hy.x) * sinSmall(hy.x) - 2.0 * p.w * sin(p.y * o.y + hy.y) * sinSmall(hy.y));
        zp = o + d;
        continue;
      }
    }
    if (k >= steps - 6) {
      vec2 jx = vec2(-p.x * p.z * sin(p.x * z.x), p.x * cos(p.x * z.y));
      vec2 jy = vec2(p.y * cos(p.y * z.x), -p.y * p.w * sin(p.y * z.y));
      vec2 w = vec2(dot(jx, v), dot(jy, v));
      float l = max(length(w), 1e-6);
      stretch += log(l);
      v = w / l;
    }
    zp = z;
    z = clifford(p, z);
  }
  if (local) z = o + z;
  if (any(isnan(z)) || any(isinf(z)) || abs(z.x) > 8.0 || abs(z.y) > 8.0) { offscreen(); return; }

  // Normalised phase coordinates (each slice framed by its own attractor), lifted into depth by the
  // delay coordinate (the previous iterate): strands that cross in the plane separate in space.
  vec2 stretchAxes = routeRow(u, 2).xy;
  vec2 q = (z - meta.xy) * meta.z * stretchAxes;
  vec2 qp = (zp - meta.xy) * meta.z * stretchAxes;
  float twist = uShape.z * s;
  q = mat2(cos(twist), sin(twist), -sin(twist), cos(twist)) * q;
  float lift = dot(qp, vec2(cos(uShape.w), sin(uShape.w)));
  vec3 position = vec3(q, -s * uShape.x + uShape.y * lift);
  vec3 tangent = vec3(mat2(cos(twist), sin(twist), -sin(twist), cos(twist)) * v * meta.z * stretchAxes, 0.0) * 0.01;
  vec4 c0 = mix(uViewProj * vec4(position, 1.0), uViewProjPrev * vec4(position, 1.0), tau);
  vec4 c1 = mix(uViewProj * vec4(position + tangent, 1.0), uViewProjPrev * vec4(position + tangent, 1.0), tau);
  if (c0.w <= 0.02 || c1.w <= 0.02) { offscreen(); return; }
  vec2 dir = (c1.xy / c1.w - c0.xy / c0.w) * uView;
  dir = length(dir) > 1e-6 ? normalize(dir) : vec2(1.0, 0.0);
  gl_Position = c0;
  gl_PointSize = 2.0 * ceil(uSegment) + 2.0;
  vDir = dir;

  float travel = atan(z.y - zp.y, z.x - zp.x) * 0.15915494 + 0.5;
  float hue = travel + uStyle.x + s * uStyle2.x;
  vec3 colour = palette(meta.w, hue);
  float fold = clamp(stretch * 0.25 - 0.1, 0.0, 1.0);
  colour = mix(colour, vec3(dot(colour, vec3(0.3333))), 1.0 - uStyle2.z);
  colour *= 1.0 + uStyle2.y * fold;
  float depth = c0.w;
  float fog = exp(-max(depth - 1.0, 0.0) * uStyle.y);
  float weight = uStyle.z * fog * mix(1.0, 1.0 - s, uStyle2.w);
  if (pulse) {
    int world = int(floor(max(meta.w, 0.0) + 0.5)) % WORLDS;
    vec3 accent = mix(palette(meta.w, uPulseB[slot].y), uAccent[world], uPulseB[slot].w);
    colour = accent;
    weight = uPulseB[slot].x * uStyle.w * fog;
  }
  vColor = vec4(colour * weight, weight);
}`;

export const cmPointsFragmentSource = `#version 300 es
precision highp float;
in vec4 vColor;
in vec2 vDir;
uniform float uSegment;
out vec4 outColor;
void main() {
  // Tent along the strand (half length uSegment), Gaussian across it (sigma 0.55 px); the kernel
  // integrates to one, so the orbit deposits the same weight whatever its orientation.
  float size = 2.0 * ceil(uSegment) + 2.0;
  vec2 d = vec2(gl_PointCoord.x - 0.5, 0.5 - gl_PointCoord.y) * size;
  float along = abs(dot(d, vDir));
  float across = dot(d, vec2(-vDir.y, vDir.x));
  float k = max(0.0, 1.0 - along / uSegment) * exp(-across * across * 1.65);
  if (k < 0.004) discard;
  outColor = vColor * (k / (uSegment * 1.3786));
}`;

// Exponential decay of the density image in place (blend: destination * constant colour).
export const cmFadeSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
void main() { outColor = vec4(0.0); }`;

// 2x2 box reduction (one bilinear tap at the shared corner of four texels).
export const cmDownSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uSource;
uniform vec2 uTexel;   // source texel size
void main() {
  vec4 a = texture(uSource, vUv + uTexel * vec2(-0.5, -0.5));
  vec4 b = texture(uSource, vUv + uTexel * vec2(0.5, -0.5));
  vec4 c = texture(uSource, vUv + uTexel * vec2(-0.5, 0.5));
  vec4 d = texture(uSource, vUv + uTexel * vec2(0.5, 0.5));
  outColor = 0.25 * (a + b + c + d);
}`;

// Exposure statistics: log density and coverage of every lit texel, averaged by the mip chain.
export const cmStatsSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uSource;
uniform float uNorm;
void main() {
  float d = texture(uSource, vUv).a * uNorm;
  float lit = d > 0.02 ? 1.0 : 0.0;
  outColor = vec4(log(1.0 + d) * lit, lit, d, 1.0);
}`;

// Bloom pyramid (as in Jimenez 2014): a 13-tap downsample that cannot alias a hot point into a
// square, and a 3x3 tent upsample that adds each level to the one above.
export const cmDown13Source = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uSource;
uniform vec2 uTexel;   // source texel size
vec4 t(vec2 o) { return texture(uSource, vUv + o * uTexel); }
void main() {
  vec4 a = t(vec2(-2, 2)), b = t(vec2(0, 2)), c = t(vec2(2, 2));
  vec4 d = t(vec2(-2, 0)), e = t(vec2(0, 0)), f = t(vec2(2, 0));
  vec4 g = t(vec2(-2, -2)), h = t(vec2(0, -2)), i = t(vec2(2, -2));
  vec4 j = t(vec2(-1, 1)), k = t(vec2(1, 1)), l = t(vec2(-1, -1)), m = t(vec2(1, -1));
  outColor = e * 0.125 + (a + c + g + i) * 0.03125 + (b + d + f + h) * 0.0625 + (j + k + l + m) * 0.125;
}`;

export const cmUpSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uBase;    // this level
uniform sampler2D uLower;   // the next smaller level, already upsampled into
uniform vec2 uTexel;        // texel size of uLower
uniform float uWeight;
vec4 t(vec2 o) { return texture(uLower, vUv + o * uTexel); }
void main() {
  vec4 tent = (t(vec2(-1, -1)) + t(vec2(1, -1)) + t(vec2(-1, 1)) + t(vec2(1, 1))
    + 2.0 * (t(vec2(0, -1)) + t(vec2(0, 1)) + t(vec2(-1, 0)) + t(vec2(1, 0))) + 4.0 * t(vec2(0))) / 16.0;
  outColor = texture(uBase, vUv) + tent * uWeight;
}`;

export const cmCompositeSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uAccum;
uniform sampler2D uHalf;
uniform sampler2D uBloom;
uniform sampler2D uBloomRaw;
uniform sampler2D uGlow;
uniform sampler2D uStats;
uniform float uStatsLevel;
uniform float uNorm;          // converts accumulated weight to density per orbit per pixel
uniform vec4 uTone;           // exposure, white point (in typical densities), gamma, vibrancy
uniform vec4 uGrade;          // bloom, glow, flash, saturation
uniform vec4 uFrame;          // aspect, vignette, presence, black level
uniform vec3 uTint;           // flash / atmosphere colour
uniform float uClarity;
uniform vec2 uResolution;

float mapDensity(float d, float typical, float white) {
  float x = d / max(typical, 1e-4);
  return log(1.0 + x) / log(1.0 + white);
}
vec3 shade(vec4 acc, float typical, float white, float gamma, float vibrancy) {
  float d = acc.a * uNorm;
  if (d <= 1e-6) return vec3(0.0);
  vec3 hue = acc.rgb / max(acc.a, 1e-8);
  float level = mapDensity(d, typical, white);
  float alpha = pow(clamp(level, 0.0, 4.0), 1.0 / gamma);
  // Flame vibrancy: per-channel log mapping keeps saturated colour in dense folds.
  vec3 perChannel = pow(clamp(log(1.0 + acc.rgb * uNorm / max(typical, 1e-4)) / log(1.0 + white), 0.0, 4.0), vec3(1.0 / gamma));
  return mix(perChannel, hue * alpha, vibrancy);
}
vec3 aces(vec3 x) {
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}
void main() {
  vec4 stats = textureLod(uStats, vec2(0.5), uStatsLevel);
  float meanLog = stats.x / max(stats.y, 1e-4);
  float typical = max(exp(meanLog) - 1.0, 0.02);
  // Density estimation as in the flame algorithm: where few orbits landed, estimate from a wider
  // footprint (the 2x2 and 4x4 averages) instead of showing sampling grain; dense folds stay sharp.
  vec4 fine = texture(uAccum, vUv);
  vec4 halfRes = texture(uHalf, vUv);
  vec4 quarter = texture(uBloomRaw, vUv);
  float sparse = clamp(1.0 - halfRes.a * uNorm / (typical * 1.5), 0.0, 1.0);
  vec4 estimate = mix(fine, halfRes, smoothstep(0.0, 0.6, sparse));
  estimate = mix(estimate, quarter, smoothstep(0.55, 1.0, sparse) * 0.7);
  vec3 colour = shade(estimate, typical, uTone.y, uTone.z, uTone.w);
  // Clarity: lift each filament against its neighbourhood (log density minus its blurred log
  // density), so fine strands read as structure rather than haze.
  float local = log(1.0 + estimate.a * uNorm / typical) - log(1.0 + quarter.a * uNorm / typical);
  colour *= exp(clamp(local, -1.5, 2.0) * uClarity);
  // Bloom is linear in energy: it only rises around genuinely hot structure (a log mapping would
  // make the faint tails of the blur visible as halos).
  vec3 bloom = texture(uBloom, vUv).rgb * uNorm / typical * 0.012;
  vec3 glow = texture(uGlow, vUv).rgb * uNorm / typical * 0.012;
  bloom = bloom / (1.0 + 0.25 * bloom);
  glow = glow / (1.0 + 0.25 * glow);
  colour = colour * uTone.x + bloom * uGrade.x + glow * uGrade.y;
  // The drop flash is light from the structure itself (its glow), never a uniform screen tint.
  colour += uTint * uGrade.z * 3.0 * dot(glow + bloom, vec3(0.3333));
  float l = dot(colour, vec3(0.2126, 0.7152, 0.0722));
  colour = max(mix(vec3(l), colour, uGrade.w), 0.0);
  vec2 c = (vUv - 0.5) * vec2(uFrame.x, 1.0);
  colour *= 1.0 - uFrame.y * smoothstep(0.35, 1.25, length(c));
  colour = aces(colour * 1.15);
  colour = pow(colour, vec3(1.0 / 2.2));
  colour = max(colour, vec3(uFrame.w)) * uFrame.z;
  // Ordered dither against banding in the dark gradients.
  float n = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
  outColor = vec4(colour + n / 255.0, 1.0);
}`;
