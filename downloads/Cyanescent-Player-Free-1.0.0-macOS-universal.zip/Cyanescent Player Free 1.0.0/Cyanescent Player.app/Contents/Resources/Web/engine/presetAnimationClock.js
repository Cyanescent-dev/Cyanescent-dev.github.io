// Animation participation is distinct from the active pointer / Adaptive hold
// clock. Retain completed transition epochs until an explicit activation changes
// the matching activation timestamp. Video transitions retain their old clocks.
export function presetAnimationStartedAt(presetId, transition, activePreset, activeStartedAt) {
  const startedAt = Number(activeStartedAt) || 0;
  if (!transition) return startedAt;
  for (const side of ['from', 'to']) {
    if (Number(presetId) !== Number(transition[side])) continue;
    const epoch = transition[`${side}PresetStartedAt`];
    if (!Number.isFinite(epoch)) continue;
    if (transition.active || (Number(presetId) === Number(activePreset)
        && transition[`${side}ActivatedAt`] === startedAt)) return epoch;
  }
  return startedAt;
}
