// Newton Basin Descent shaders.
//
// Coordinate conventions (see runtime.json): field UV "fuv" has its origin at the top-left,
// u right, v down, and is the same UV as the beauty video. Field textures, the video texture and
// the small video copy are all stored top row first, so row j of each is fuv.y = (j + .5) / H.
// Flow directions are unit vectors in square screen pixels, +y down.
//
// Passes per frame:
//   down       the full-resolution video -> a 240x135 box-filtered copy (bloom, relief, glint colour)
//   resolve    two neighbouring package samples -> current-camera fields (MRT)
//                A = boundary(texels), flow.xy * weight, weight
//                B = smooth iteration A, log2|p|, depth, region code
//                C = surface hit, temporal agreement, local scale (texels), arg(p) in turns
//   prep       S = region-aware smoothed iteration count, surface mask, seam, fractal dust
//              (its gradient is taken where it is used, from the bilinear texture)
//   glints     world-anchored specular glints (transform feedback)
//   composite  the video itself, graded by the music, with ripple waves travelling through the
//              iteration field, crater glow, seam shimmer and bloom
//   draw       the glints

import { glintDefines } from "./newtonBasinRules.js";

export const WAVE_UNIFORM_SLOTS = 12;

const common = `
uniform vec2 uSize;
uniform float uMaxDist;
uniform float uAspect;
uniform float uBudget;
uniform vec2 uRhoRange;
struct NbCam { vec3 pos; vec3 fwd; vec3 right; vec3 up; float tanHalf; };
vec3 nbRay(NbCam c, vec2 fuv) {
  vec2 s = vec2((2.0 * fuv.x - 1.0) * uAspect, 1.0 - 2.0 * fuv.y) * c.tanHalf;
  return normalize(c.fwd + c.right * s.x + c.up * s.y);
}
bool nbProject(NbCam c, vec3 P, out vec2 fuv, out float z) {
  vec3 d = P - c.pos;
  z = dot(d, c.fwd);
  if (z < 0.001) { fuv = vec2(-1.0); return false; }
  vec2 s = vec2(dot(d, c.right), dot(d, c.up)) / (z * c.tanHalf);
  fuv = vec2(0.5 + 0.5 * s.x / uAspect, 0.5 - 0.5 * s.y);
  return true;
}
float nbHash(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
// Smooth iteration count A from its byte: quarter steps to the knee, coarse beyond.
float nbIter(float byte01) {
  float u = byte01 * 255.0;
  return u < 192.0 ? u * 0.25 : 48.0 + (u - 192.0) / 63.0 * (uBudget - 48.0);
}
const vec3 NB_LUMA = vec3(0.2126, 0.7152, 0.0722);
// Warm gold, pale turquoise and soft violet for the three Newton roots; cyan-white for the escape
// region. Every use mixes them with the video's own hue.
vec3 nbRegionTint(float code) {
  if (code < 1.5) return vec3(0.72, 0.90, 1.00);
  if (code < 2.5) return vec3(1.00, 0.76, 0.42);
  if (code < 3.5) return vec3(0.50, 1.00, 0.88);
  if (code < 4.5) return vec3(0.76, 0.62, 1.00);
  return vec3(0.90, 0.74, 0.98);
}
// Crest colours: the same restrained palette, assigned so each basin's wave contrasts with that
// basin's own surface (the warm gold slopes carry cool light, the icy turquoise plates warm light,
// the dark violet sea a pale lilac-white).
vec3 nbCrestTint(float code) {
  if (code < 1.5) return vec3(1.00, 0.86, 0.62);
  if (code < 2.5) return vec3(0.62, 0.92, 1.00);
  if (code < 3.5) return vec3(1.00, 0.80, 0.48);
  if (code < 4.5) return vec3(0.90, 0.84, 1.00);
  return vec3(0.80, 0.95, 1.00);
}
// Gradient of the smoothed iteration count (counts per field texel, fuv axes) from the prep
// texture; its bilinear filtering makes this smooth everywhere the count is.
vec3 nbGradA(sampler2D S, vec2 fuv) {
  vec2 t = 1.0 / uSize;
  float gx = 0.5 * (texture(S, fuv + vec2(t.x, 0.0)).r - texture(S, fuv - vec2(t.x, 0.0)).r);
  float gy = 0.5 * (texture(S, fuv + vec2(0.0, t.y)).r - texture(S, fuv - vec2(0.0, t.y)).r);
  return vec3(gx, gy, length(vec2(gx, gy)));
}
// Wave region gains: (escape, root 0, root 1, root 2); the exhausted region follows the escape one.
float nbRegionGain(vec4 gains, float code) {
  if (code < 1.5) return gains.x;
  if (code < 2.5) return gains.y;
  if (code < 3.5) return gains.z;
  if (code < 4.5) return gains.w;
  return gains.x;
}
`;

// ------------------------------------------------------------------ down

export const newtonDownsampleSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uVideo;
uniform vec2 uSmallSize;
// A box filter over each 8x8 block of the frame: 16 bilinear taps, each averaging 2x2 pixels.
void main() {
  vec2 fuv = gl_FragCoord.xy / uSmallSize;
  vec2 cell = 1.0 / uSmallSize;
  vec3 c = vec3(0.0);
  for (int j = 0; j < 4; j++) {
    for (int i = 0; i < 4; i++) {
      c += texture(uVideo, fuv + (vec2(float(i), float(j)) - 1.5) * 0.25 * cell).rgb;
    }
  }
  c *= 1.0 / 16.0;
  outColor = vec4(c, dot(c, vec3(0.2126, 0.7152, 0.0722)));
}`;

// ------------------------------------------------------------------ resolve

export const newtonResolveSource = `#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
layout(location = 0) out vec4 outA;
layout(location = 1) out vec4 outB;
layout(location = 2) out vec4 outC;
uniform sampler2D uA0;
uniform sampler2D uB0;
uniform sampler2D uA1;
uniform sampler2D uB1;
uniform float uMix;
uniform float uReproject;
uniform vec3 uPos0; uniform vec3 uFwd0; uniform vec3 uRight0; uniform vec3 uUp0; uniform float uTan0;
uniform vec3 uPos1; uniform vec3 uFwd1; uniform vec3 uRight1; uniform vec3 uUp1; uniform float uTan1;
uniform vec3 uPosN; uniform vec3 uFwdN; uniform vec3 uRightN; uniform vec3 uUpN; uniform float uTanN;
${common}

struct NbTexel { float region; float hit; float fv; float bnd; float it; float depth; float rho; float theta; vec2 flow; };

NbTexel fetchT(sampler2D a, sampler2D b, ivec2 p) {
  p = clamp(p, ivec2(0), ivec2(uSize) - 1);
  vec4 A = texelFetch(a, p, 0);
  vec4 B = texelFetch(b, p, 0);
  int flags = int(A.r * 255.0 + 0.5);
  NbTexel t;
  t.region = float(flags & 7);
  t.hit = float((flags >> 3) & 1);
  t.fv = float((flags >> 4) & 1);
  t.bnd = uMaxDist * A.g * A.g;
  float angle = A.b * 255.0 / 256.0 * 6.2831853;
  t.flow = t.fv > 0.5 ? vec2(cos(angle), sin(angle)) : vec2(0.0);
  t.it = t.hit > 0.5 ? nbIter(A.a) : 0.0;
  int bits = int(B.r * 255.0 + 0.5) | (int(B.g * 255.0 + 0.5) << 8);
  t.depth = t.hit > 0.5 ? unpackHalf2x16(uint(bits)).x : 0.0;
  t.rho = uRhoRange.x + (uRhoRange.y - uRhoRange.x) * B.b;
  t.theta = B.a * 255.0 / 256.0;
  return t;
}

struct NbSlot { float region; float hit; float bnd; float it; float depth; float rho; float theta; vec2 flow; float flowW; };

// Validity-aware bilinear sample of one package sample at fuv q. The boundary distance is
// continuous and filters freely; iteration, log-radius, depth and flow only combine texels of
// the same region and compatible depth; region, hit and arg(p) are nearest.
NbSlot sampleSlot(sampler2D a, sampler2D b, vec2 q) {
  vec2 st = q * uSize - 0.5;
  ivec2 base = ivec2(floor(st));
  vec2 f = st - floor(st);
  NbTexel c = fetchT(a, b, ivec2(floor(q * uSize)));
  NbSlot s;
  s.region = c.region; s.hit = c.hit; s.bnd = 0.0; s.theta = c.theta;
  float itSum = 0.0, rhoSum = 0.0, depthSum = 0.0, compatSum = 0.0, flowW = 0.0;
  vec2 flowSum = vec2(0.0);
  for (int j = 0; j < 2; j++) {
    for (int i = 0; i < 2; i++) {
      NbTexel t = fetchT(a, b, base + ivec2(i, j));
      float w = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
      s.bnd += t.bnd * w;
      float compat = (t.region == c.region && t.hit > 0.5 && c.hit > 0.5 &&
                      abs(t.depth - c.depth) < 0.1 * c.depth + 0.01) ? 1.0 : 0.0;
      float cw = w * compat;
      itSum += t.it * cw; rhoSum += t.rho * cw; depthSum += t.depth * cw; compatSum += cw;
      float fw = cw * t.fv;
      flowSum += t.flow * fw; flowW += fw;
    }
  }
  s.it = compatSum > 0.0 ? itSum / compatSum : c.it;
  s.rho = compatSum > 0.0 ? rhoSum / compatSum : c.rho;
  s.depth = compatSum > 0.0 ? depthSum / compatSum : c.depth;
  float len = length(flowSum);
  s.flow = flowW > 0.001 && len > 0.001 ? flowSum / len : vec2(0.0);
  s.flowW = flowW > 0.001 ? clamp(len / flowW, 0.0, 1.0) * min(1.0, flowW * 1.05) : 0.0;
  return s;
}

// How much room the basin interfaces leave around this texel: the largest boundary distance
// in a +-6 texel window. Small means fractal dust (an interface at every texel).
float localScale(sampler2D a, ivec2 p) {
  float best = 0.0;
  for (int j = -2; j <= 2; j++) {
    for (int i = -2; i <= 2; i++) {
      ivec2 q = clamp(p + ivec2(i, j) * 3, ivec2(0), ivec2(uSize) - 1);
      float g = texelFetch(a, q, 0).g;
      best = max(best, uMaxDist * g * g);
    }
  }
  return best;
}

void main() {
  ivec2 p = ivec2(gl_FragCoord.xy);
  vec2 fuv = (vec2(p) + 0.5) / uSize;
  NbCam c0 = NbCam(uPos0, uFwd0, uRight0, uUp0, uTan0);
  NbCam c1 = NbCam(uPos1, uFwd1, uRight1, uUp1, uTan1);
  NbCam cn = NbCam(uPosN, uFwdN, uRightN, uUpN, uTanN);
  bool nearIs1 = uMix >= 0.5;
  NbTexel t0 = fetchT(uA0, uB0, p);
  NbTexel t1 = fetchT(uA1, uB1, p);
  NbTexel base = t0;
  if (nearIs1) base = t1;
  vec2 q0 = fuv;
  vec2 q1 = fuv;
  // Carry both samples to the current camera through the surface they describe, so the
  // structure stays locked to the video between samples.
  if (uReproject > 0.5 && base.hit > 0.5 && base.depth > 0.0) {
    vec3 P = cn.pos + nbRay(cn, fuv) * base.depth;
    float z;
    vec2 q;
    if (nbProject(c0, P, q, z) && all(greaterThan(q, vec2(0.0))) && all(lessThan(q, vec2(1.0)))) {
      NbTexel t = fetchT(uA0, uB0, ivec2(floor(q * uSize)));
      float expected = length(P - c0.pos);
      if (t.hit > 0.5 && abs(t.depth - expected) < 0.06 * expected + 0.02) q0 = q;
    }
    if (nbProject(c1, P, q, z) && all(greaterThan(q, vec2(0.0))) && all(lessThan(q, vec2(1.0)))) {
      NbTexel t = fetchT(uA1, uB1, ivec2(floor(q * uSize)));
      float expected = length(P - c1.pos);
      if (t.hit > 0.5 && abs(t.depth - expected) < 0.06 * expected + 0.02) q1 = q;
    }
  }
  NbSlot s0 = sampleSlot(uA0, uB0, q0);
  NbSlot s1 = sampleSlot(uA1, uB1, q1);
  NbSlot n = s0;
  if (nearIs1) n = s1;
  // Categorical data and topology changes: never blend across different surfaces.
  bool agree = s0.region == s1.region && s0.hit > 0.5 && s1.hit > 0.5;
  float m = agree ? uMix : (nearIs1 ? 1.0 : 0.0);
  float d0 = s0.depth;
  float d1 = s1.depth;
  if (uReproject > 0.5) {
    if (s0.hit > 0.5) d0 = length(c0.pos + nbRay(c0, q0) * s0.depth - cn.pos);
    if (s1.hit > 0.5) d1 = length(c1.pos + nbRay(c1, q1) * s1.depth - cn.pos);
  }
  float depth = agree ? mix(d0, d1, m) : (n.hit > 0.5 ? (nearIs1 ? d1 : d0) : 0.0);
  vec2 flowV = mix(s0.flow * s0.flowW, s1.flow * s1.flowW, m);
  float flowWeight = mix(s0.flowW, s1.flowW, m);
  float scale = 0.0;
  if (nearIs1) scale = localScale(uA1, ivec2(floor(q1 * uSize)));
  else scale = localScale(uA0, ivec2(floor(q0 * uSize)));
  outA = vec4(mix(s0.bnd, s1.bnd, m), flowV, flowWeight);
  outB = vec4(mix(s0.it, s1.it, m), mix(s0.rho, s1.rho, m), depth, n.region);
  outC = vec4(n.hit, agree ? 1.0 : 0.0, scale, n.theta);
}`;

// ------------------------------------------------------------------ prep

// S = (smoothed iteration count, surface mask, seam, fractal dust). The count is stored in
// quarter steps; on the broad basin slopes it changes by less than a step per texel, so its
// contours would stair-step. A region- and depth-aware Gaussian turns the steps back into the
// smooth ramp they came from without ever mixing two basins or two surfaces.
export const newtonPrepSource = `#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
out vec4 outS;
uniform sampler2D uFieldA;
uniform sampler2D uFieldB;
uniform sampler2D uFieldC;
${common}
void main() {
  ivec2 p = ivec2(gl_FragCoord.xy);
  ivec2 hi = ivec2(uSize) - 1;
  vec4 a = texelFetch(uFieldA, p, 0);
  vec4 b = texelFetch(uFieldB, p, 0);
  vec4 c = texelFetch(uFieldC, p, 0);
  float region = b.a, depth = b.b, hit = c.r;
  float edge = 0.0;
  for (int k = 0; k < 4; k++) {
    ivec2 o = k == 0 ? ivec2(1, 0) : k == 1 ? ivec2(-1, 0) : k == 2 ? ivec2(0, 1) : ivec2(0, -1);
    ivec2 q = clamp(p + o, ivec2(0), hi);
    float dn = texelFetch(uFieldB, q, 0).b;
    float hn = texelFetch(uFieldC, q, 0).r;
    edge = max(edge, hn > 0.5 ? abs(dn - depth) / max(depth, 0.2) : 1.0);
  }
  float surface = hit * step(0.5, region) * (1.0 - smoothstep(0.07, 0.26, edge)) * (1.0 - smoothstep(5.0, 9.0, depth));
  float sum = 0.0, wsum = 0.0;
  for (int j = -2; j <= 2; j++) {
    for (int i = -2; i <= 2; i++) {
      ivec2 q = clamp(p + ivec2(i, j), ivec2(0), hi);
      vec4 bq = texelFetch(uFieldB, q, 0);
      if (texelFetch(uFieldC, q, 0).r < 0.5 || abs(bq.a - region) > 0.5 || abs(bq.b - depth) > 0.08 * depth + 0.01) continue;
      float w = exp(-float(i * i + j * j) / 3.4);
      sum += bq.r * w;
      wsum += w;
    }
  }
  float As = wsum > 0.0 ? sum / wsum : b.r;
  float dB = max(a.r - 0.5, 0.0);
  float seam = exp(-dB * dB / 0.8) * smoothstep(1.4, 2.8, c.b) * hit;
  float dust = (1.0 - smoothstep(1.0, 2.2, c.b)) * hit;
  outS = vec4(hit > 0.5 ? As : 0.0, surface, seam, dust);
}`;

// ---------------------------------------------------------------- composite

export const newtonCompositeSource = `#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uVideo;     // full-resolution frame
uniform sampler2D uSmall;     // 240x135 box-filtered copy
uniform sampler2D uS;
uniform sampler2D uFieldA;
uniform sampler2D uFieldB;
uniform sampler2D uFieldC;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform vec2 uViewPx;         // the video rectangle in canvas pixels
uniform int uDebug;
uniform float uFade;          // presence of the field-driven layers
uniform vec4 uGrade;          // exposure, saturation, contrast, haze
uniform vec4 uLight;          // bloom, crater glow, seam shimmer, shimmer phase
uniform vec4 uMix;            // waves, craters, seams, lens (control x reactive)
uniform float uBreath;        // crater breathing phase (turns, one per bar)
uniform vec4 uWaveA[${WAVE_UNIFORM_SLOTS}];   // front (counts), amplitude, crest half-width (px at 720p), wake tail (counts)
uniform vec4 uWaveB[${WAVE_UNIFORM_SLOTS}];   // region gains: escape, root 0, root 1, root 2
uniform vec4 uWaveC[${WAVE_UNIFORM_SLOTS}];   // lens strength, kind
uniform int uAnchorCount;
uniform vec4 uAnchorA[16];    // debug only: u, v, radius, presence
uniform vec4 uAnchorB[16];    // debug only: region code
${common}

vec3 videoAt(vec2 fuv, vec2 px) {
  // The canvas is usually smaller than the 1080p frame: four taps a quarter pixel apart make a
  // box filter instead of plain bilinear minification.
  vec2 h = 0.25 / uViewPx;
  return 0.25 * (texture(uVideo, fuv + vec2(-h.x, -h.y)).rgb + texture(uVideo, fuv + vec2(h.x, -h.y)).rgb
               + texture(uVideo, fuv + vec2(-h.x, h.y)).rgb + texture(uVideo, fuv + vec2(h.x, h.y)).rgb);
}

// Highlights roll off instead of clipping, so a flash never posterises the sky.
vec3 shoulder(vec3 c) {
  vec3 over = max(c - 0.78, 0.0);
  return min(c, vec3(0.78)) + 0.22 * (1.0 - exp(-over / 0.22));
}
vec3 grade(vec3 c) {
  c *= uGrade.x;
  float l = dot(c, NB_LUMA);
  c = mix(vec3(l), c, uGrade.y);
  vec3 s = clamp(c, 0.0, 1.0);
  c = mix(c, s * s * (3.0 - 2.0 * s), clamp((uGrade.z - 1.0) * 2.0, -0.4, 0.35));
  c += (1.0 - c) * vec3(0.74, 0.80, 1.0) * uGrade.w;
  return shoulder(max(c, 0.0));
}

// Bloom from the frame's own highlights: two rings of taps on the 1/8-resolution copy.
vec3 bloomAt(vec2 fuv) {
  vec2 cell = 1.0 / vec2(textureSize(uSmall, 0));
  vec3 b = max(texture(uSmall, fuv).rgb - 0.74, 0.0) * 0.8;
  for (int k = 0; k < 8; k++) {
    float a = float(k) * 0.7853982;
    vec2 d = vec2(cos(a), sin(a)) * cell;
    b += max(texture(uSmall, fuv + d * 2.5).rgb - 0.70, 0.0) * 0.16;
    b += max(texture(uSmall, fuv + d * 6.0).rgb - 0.64, 0.0) * 0.09;
  }
  return b;
}

float lineMask(float d, float halfWidth) {
  float aa = max(fwidth(d) * 0.8, 0.05);
  return 1.0 - smoothstep(halfWidth - aa, halfWidth + aa, d);
}

void main() {
  vec2 uv = vUv;
  if (uCanvasAspect > uVideoAspect) uv.x = (uv.x - 0.5) * uCanvasAspect / uVideoAspect + 0.5;
  else uv.y = (uv.y - 0.5) * uVideoAspect / uCanvasAspect + 0.5;
  if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) { outColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
  vec2 fuv = vec2(uv.x, 1.0 - uv.y);
  ivec2 fp = ivec2(clamp(floor(fuv * uSize), vec2(0.0), uSize - 1.0));
  vec4 S = texture(uS, fuv);
  vec3 G = nbGradA(uS, fuv);
  vec4 nB = texelFetch(uFieldB, fp, 0);
  vec4 nC = texelFetch(uFieldC, fp, 0);
  vec4 fA = texture(uFieldA, fuv);
  float region = nB.a;
  float A = S.r;
  float surface = S.g * uFade;
  float g = max(G.z, 1e-4);                       // counts per field texel
  float pxPerTexel = uViewPx.x / uSize.x;
  float pxScale = uViewPx.y / 720.0;

  // ---- ripple waves: fronts of constant A travelling out of the attractor wells ------------
  // Crests are drawn at a constant screen width from the analytic distance to the front, and
  // only where the contours are resolvable; where they crowd into the fractal seams the wave has
  // broken and becomes a soft surge instead (the glints sparkle there).
  float resolvable = smoothstep(0.010, 0.030, g) * (1.0 - smoothstep(1.1, 2.6, g));
  float dense = smoothstep(0.7, 2.2, g);
  float nearSeam = smoothstep(0.5, 1.8, fA.r);    // waves stop at their basin's interface
  float crest = 0.0, halo = 0.0, trough = 0.0, wake = 0.0, surge = 0.0;
  vec2 lensPx = vec2(0.0);
  vec2 dir = G.xy / g;
  for (int k = 0; k < ${WAVE_UNIFORM_SLOTS}; k++) {
    vec4 wa = uWaveA[k];
    if (wa.y < 0.004) continue;
    float amp = wa.y * nbRegionGain(uWaveB[k], region);
    float dA = A - wa.x;                           // > 0 ahead of the front, < 0 already passed
    float x = dA * pxPerTexel / g / (wa.z * pxScale);
    float profile = exp(-x * x);
    // A ripple is a short packet: the leading crest and two fading echoes behind it.
    float e1 = x + 3.0, e2 = x + 6.0;
    crest += amp * (profile + 0.42 * exp(-e1 * e1) + 0.16 * exp(-e2 * e2));
    halo += amp * exp(-x * x * 0.08);
    float ahead = x - 2.4;
    trough += amp * exp(-ahead * ahead);
    wake += amp * (dA < 0.0 ? exp(dA / wa.w) * smoothstep(0.0, 1.5, -x + 1.5) : 0.0);
    surge += amp * exp(-dA * dA / 2.5) * dense;
    lensPx += dir * amp * uWaveC[k].x * (-2.0 * x * profile);
  }
  // Contours that bend hard (around every spike of the violet basin) would draw scribbles:
  // compare the gradient direction a little way along the contour on both sides.
  vec2 tangent = vec2(-dir.y, dir.x) * 1.5 / uSize;
  vec3 Ga = nbGradA(uS, fuv + tangent);
  vec3 Gb = nbGradA(uS, fuv - tangent);
  float coherence = 0.5 * (dot(dir, Ga.xy / max(Ga.z, 1e-4)) + dot(dir, Gb.xy / max(Gb.z, 1e-4)));
  float waveMask = resolvable * nearSeam * mix(0.25, 1.0, smoothstep(0.55, 0.9, coherence));
  crest *= waveMask; halo *= waveMask; trough *= waveMask; wake *= waveMask; lensPx *= waveMask;

  // ---- debug views --------------------------------------------------------------------------
  if (uDebug == 1) { outColor = vec4(mix(videoAt(fuv, uViewPx) * 0.35, nbRegionTint(region), 0.65 * nC.r), 1.0); return; }
  if (uDebug == 2) {
    float d = max(fA.r - 0.5, 0.0);
    outColor = vec4(mix(vec3(fract(d * 0.125) * 0.5), vec3(1.0, 0.85, 0.3), lineMask(d, 0.5)), 1.0);
    return;
  }
  if (uDebug == 3) { outColor = vec4(0.5 + 0.5 * fA.g, 0.5 - 0.5 * fA.b, 0.5 * fA.a, 1.0); return; }
  if (uDebug == 4) {
    float f = abs(fract(A) - 0.5);
    outColor = vec4(vec3(clamp(A / 40.0, 0.0, 1.0)) * (0.55 + 0.45 * smoothstep(0.3, 0.5, f)), 1.0);
    return;
  }
  if (uDebug == 5) { outColor = vec4(vec3(clamp(nB.b / 14.0, 0.0, 1.0)), 1.0); return; }
  if (uDebug == 6) {
    vec3 c = videoAt(fuv, uViewPx) * 0.35;
    for (int i = 0; i < 16; i++) {
      if (i >= uAnchorCount) break;
      vec4 an = uAnchorA[i];
      float r = length((fuv - an.xy) * uSize);
      float on = (1.0 - smoothstep(0.8, 1.6, r)) * step(0.02, an.w);
      c = mix(c, nbRegionTint(uAnchorB[i].x), on);
    }
    outColor = vec4(c, 1.0);
    return;
  }
  if (uDebug == 7) {
    vec3 hueColor = 0.5 + 0.5 * cos(6.2832 * (nC.a + vec3(0.0, 0.33, 0.67)));
    float shellLine = smoothstep(0.40, 0.5, abs(fract(texture(uFieldB, fuv).g * 2.5) - 0.5));
    outColor = vec4(mix(hueColor * 0.55, vec3(1.0), shellLine) * nC.r, 1.0);
    return;
  }
  if (uDebug == 8 || uDebug == 10) { outColor = vec4(videoAt(fuv, uViewPx) * 0.14, 1.0); return; }
  if (uDebug == 9) { outColor = vec4(mix(vec3(0.9, 0.1, 0.1), vec3(0.1, 0.75, 0.35), S.g) * (0.3 + 0.7 * nC.r), 1.0); return; }
  if (uDebug == 12) {
    outColor = vec4(vec3(clamp(log2(1.0 + A) / 6.0, 0.0, 1.0)) * 0.5 + vec3(1.0, 0.8, 0.3) * crest + vec3(0.2, 0.5, 0.2) * wake + vec3(0.3, 0.6, 1.0) * surge * 0.5, 1.0);
    return;
  }

  // ---- the frame itself, refracted by the passing crests and graded by the music -----------
  vec2 lensUv = lensPx * pxScale * uMix.w * surface / uViewPx;
  vec3 base = grade(videoAt(fuv - lensUv, uViewPx));
  vec3 lowPass = grade(texture(uSmall, fuv - lensUv).rgb);
  vec3 detail = base - lowPass;                    // the relief and grooves of the frame
  float luma = dot(base, NB_LUMA);
  vec3 hue = base / max(max(base.r, max(base.g, base.b)), 0.12);
  vec3 tint = mix(nbRegionTint(region), hue, 0.35);
  vec3 crestColor = mix(nbCrestTint(region), hue, 0.12);
  vec3 col = base;
  vec3 before = base;
  float W = uMix.x * surface;

  // Behind the crest the wave reveals the terrain: the frame's own grooves and relief gain
  // contrast (no wash of light over it), with only a breath of the basin's colour.
  float wakeL = clamp(wake * W, 0.0, 1.2);
  col += detail * wakeL * 1.6;
  col += (1.0 - col) * tint * wakeL * 0.05;
  // The crest: a thin line of light in the basin's colour with a soft halo, and a faint trough
  // just ahead of it, so the wave reads as relief on the surface rather than paint on the glass.
  col *= 1.0 - 0.28 * clamp(trough * W, 0.0, 1.5) * (0.4 + 0.6 * smoothstep(0.25, 0.7, luma));
  float crestL = clamp(crest * W, 0.0, 1.4);
  float haloL = clamp(halo * W, 0.0, 2.0);
  col += (1.0 - col) * crestColor * (crestL * 0.90 + haloL * 0.16);
  // Where the wave breaks on the fractal seams it surges through the dust.
  col += detail * clamp(surge * W, 0.0, 1.2) * 1.2 + (1.0 - col) * crestColor * clamp(surge * W, 0.0, 1.2) * 0.10;

  // Attractor wells: the craters breathe once a bar with the bass and the pads.
  float crater = (1.0 - smoothstep(0.4, 2.2, A)) * surface;
  float breath = 0.55 + 0.45 * cos(6.2831853 * uBreath);
  vec3 warm = mix(tint, vec3(1.0, 0.82, 0.55), 0.35);
  float craterL = crater * uLight.y * uMix.y * breath;
  col += detail * craterL * 1.5 + (1.0 - col) * warm * craterL * 0.10;

  // Seams: bands of light flowing along the basin interfaces, carried by the mids.
  float seamBand = pow(0.5 + 0.5 * cos(6.2831853 * (A * 0.30 - uLight.w)), 3.0);
  float seamL = (S.b * seamBand + S.a * 0.25 * seamBand) * uLight.z * uMix.z * surface;
  col += (1.0 - col) * mix(tint, vec3(1.0), 0.25) * seamL * 0.45;

  // Bloom from the frame's own highlights only.
  col += bloomAt(fuv) * uLight.x;

  if (uDebug == 11) { outColor = vec4(clamp(abs(col - before) * 2.5, 0.0, 1.0), 1.0); return; }
  outColor = vec4(shoulder(max(col, 0.0)), 1.0);
}`;

// -------------------------------------------------------- glint update (TF)

export const newtonGlintUpdateSource = `#version 300 es
precision highp float;
precision highp int;
${glintDefines()}
layout(location = 0) in vec4 aState0;   // world position, age (< 0: dead)
layout(location = 1) in vec4 aState1;   // life (< 0: diagnostic marker, -life = end reason), seed, kind, amplitude
layout(location = 2) in vec4 aState2;   // projected fuv, occlusion visibility, last end reason
out vec4 vState0;
out vec4 vState1;
out vec4 vState2;
uniform sampler2D uS;
uniform sampler2D uFieldB;
uniform sampler2D uFieldC;
uniform sampler2D uSmall;
uniform float uDelta;
uniform float uClock;
uniform float uCapacity;
uniform vec4 uRates;          // expected births this frame: surf, hat, drop
uniform vec2 uViewPx;
uniform float uDebugAttach;
uniform vec3 uPosN; uniform vec3 uFwdN; uniform vec3 uRightN; uniform vec3 uUpN; uniform float uTanN;
uniform vec4 uWaveA[${WAVE_UNIFORM_SLOTS}];
uniform vec4 uWaveB[${WAVE_UNIFORM_SLOTS}];
${common}

float fieldDepth(vec2 fuv) { return texelFetch(uFieldB, ivec2(clamp(floor(fuv * uSize), vec2(0.0), uSize - 1.0)), 0).b; }
float fieldHit(vec2 fuv) { return texelFetch(uFieldC, ivec2(clamp(floor(fuv * uSize), vec2(0.0), uSize - 1.0)), 0).r; }

// How strongly a wave crest is breaking at fuv right now (0 = no crest there).
float surfAt(vec2 fuv, vec4 S) {
  vec3 G = nbGradA(uS, fuv);
  float g = max(G.z, 1e-4);
  float structure = max(max(S.a, S.b), smoothstep(0.35, 1.2, g));
  if (structure < 0.2) return 0.0;
  float region = texelFetch(uFieldB, ivec2(clamp(floor(fuv * uSize), vec2(0.0), uSize - 1.0)), 0).a;
  float best = 0.0;
  for (int k = 0; k < ${WAVE_UNIFORM_SLOTS}; k++) {
    vec4 wa = uWaveA[k];
    if (wa.y < 0.02) continue;
    float dPx = abs(S.r - wa.x) * (uViewPx.x / uSize.x) / g;
    float near = 1.0 - smoothstep(wa.z * 1.5, wa.z * 4.0, dPx);
    best = max(best, near * wa.y * nbRegionGain(uWaveB[k], region));
  }
  return best * structure;
}

void main() {
  float id = float(gl_VertexID);
  vec3 P = aState0.xyz;
  float age = aState0.w;
  float life = aState1.x;
  float seed = aState1.y;
  float kind = aState1.z;
  float amp = aState1.w;
  vec2 fuv = aState2.xy;
  float vis = aState2.z;
  float lastEnd = aState2.w;
  NbCam cam = NbCam(uPosN, uFwdN, uRightN, uUpN, uTanN);

  // A removed glint stays on screen in the attachment diagnostic, coloured by why it ended.
  if (life < 0.0) {
    age += uDelta;
    if (age > GT_MARKER || uDebugAttach < 0.5) { age = -1.0; life = 0.0; }
    vState0 = vec4(P, age); vState1 = vec4(life, seed, kind, amp); vState2 = vec4(fuv, vis, lastEnd);
    gl_Position = vec4(0.0);
    return;
  }

  float endReason = 0.0;
  bool alive = age >= 0.0 && life > 0.0;
  if (alive) {
    age += uDelta;
    float z;
    vec2 q;
    bool front = nbProject(cam, P, q, z);
    float dist = length(P - cam.pos);
    // The rule chain of glintDecision() in newtonBasinRules.js.
    if (!front || any(lessThan(q, vec2(GT_MARGIN))) || any(greaterThan(q, vec2(1.0 - GT_MARGIN)))) endReason = 4.0;
    else {
      fuv = q;
      float depth = fieldDepth(q);
      float surface = texture(uS, q).g;
      if (fieldHit(q) < 0.5 || depth <= 0.0 || depth > GT_KILL_DEPTH) endReason = 1.0;
      else if (surface < GT_MIN_SURFACE) endReason = 3.0;
      else {
        bool occluded = abs(depth - dist) > GT_OCC_REL * dist + GT_OCC_ABS;
        vis = clamp(vis + (occluded ? -1.0 : 1.0) * uDelta / GT_OCC_FADE, 0.0, 1.0);
        if (occluded && vis <= 0.0) endReason = 2.0;
      }
    }
    if (endReason < 0.5 && age >= life) endReason = 5.0;
    if (endReason > 0.5) alive = false;
  }

  if (!alive) {
    if (endReason > 0.5 && endReason < 4.5 && uDebugAttach > 0.5) {
      vState0 = vec4(P, 0.0); vState1 = vec4(-endReason, seed, kind, amp); vState2 = vec4(fuv, vis, endReason);
      gl_Position = vec4(0.0);
      return;
    }
    if (endReason > 0.5) lastEnd = endReason;
    age = -1.0;
    life = 0.0;
    float total = uRates.x + uRates.y + uRates.z;
    float cycle = floor(uClock * 60.0);
    if (total > 0.0 && nbHash(vec2(id * 0.731, cycle)) < total / uCapacity * 1.6) {
      float pick = nbHash(vec2(id * 1.37, cycle + 7.0)) * total;
      float want = pick < uRates.x ? 0.0 : pick < uRates.x + uRates.y ? 1.0 : 2.0;
      for (int attempt = 0; attempt < 6; attempt++) {
        float key = id * 17.31 + cycle * 91.7 + float(attempt) * 53.19;
        vec2 cand = vec2(nbHash(vec2(key, 1.7)), nbHash(vec2(key, 9.3)));
        if (any(lessThan(cand, vec2(GT_MARGIN * 2.0))) || any(greaterThan(cand, vec2(1.0 - GT_MARGIN * 2.0)))) continue;
        vec4 S = texture(uS, cand);
        float depth = fieldDepth(cand);
        if (fieldHit(cand) < 0.5 || depth <= 0.0 || depth > GT_SPAWN_MAX_DEPTH || S.g < GT_SPAWN_SURFACE) continue;
        float luma = texture(uSmall, cand).a;
        // A specular glint needs a highlight: brighter than its own surroundings, not merely a
        // bright matte slope.
        vec2 cell = 4.0 / vec2(textureSize(uSmall, 0));
        float around = 0.25 * (texture(uSmall, cand + vec2(cell.x, 0.0)).a + texture(uSmall, cand - vec2(cell.x, 0.0)).a
                             + texture(uSmall, cand + vec2(0.0, cell.y)).a + texture(uSmall, cand - vec2(0.0, cell.y)).a);
        float highlight = smoothstep(0.03, 0.12, luma - around);
        float accept = 0.0;
        if (want < 0.5) accept = surfAt(cand, S);
        else if (want < 1.5) accept = smoothstep(0.50, 0.80, luma) * highlight;
        else accept = smoothstep(0.30, 0.65, luma) * max(highlight, 0.35);
        if (nbHash(vec2(key, 4.4)) > accept) continue;
        P = cam.pos + nbRay(cam, cand) * depth;
        fuv = cand;
        seed = nbHash(vec2(key, 2.2));
        kind = want;
        age = 0.0;
        life = mix(GT_LIFE_MIN[int(kind)], GT_LIFE_MAX[int(kind)], seed);
        amp = kind < 0.5 ? clamp(accept, 0.3, 1.2) : kind < 1.5 ? 0.55 + 0.45 * seed : 1.0;
        vis = 1.0;
        lastEnd = 0.0;
        break;
      }
    }
  }
  vState0 = vec4(P, age);
  vState1 = vec4(life, seed, kind, amp);
  vState2 = vec4(fuv, vis, lastEnd);
  gl_Position = vec4(0.0);
}`;

export const newtonGlintVertexSource = `#version 300 es
precision highp float;
precision highp int;
${glintDefines()}
layout(location = 0) in vec4 aState0;
layout(location = 1) in vec4 aState1;
layout(location = 2) in vec4 aState2;
out float vEnergy;
out float vReason;
out float vKind;
out vec3 vColor;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform float uPxScale;
uniform float uFade;
uniform float uAmount;
uniform float uDebugAttach;
uniform vec3 uCamPos;
uniform sampler2D uSmall;
void main() {
  vEnergy = 0.0;
  vReason = 0.0;
  vKind = aState1.z;
  vColor = vec3(1.0);
  gl_PointSize = 1.0;
  gl_Position = vec4(2.0, 2.0, 0.0, 1.0);
  float age = aState0.w;
  float life = aState1.x;
  bool marker = life < 0.0;
  if (marker) { if (uDebugAttach < 0.5 || age > GT_MARKER) return; }
  else if (life <= 0.0 || age < 0.0 || age >= life) return;
  vec2 fuv = aState2.xy;
  vec2 point = vec2(fuv.x * 2.0 - 1.0, 1.0 - fuv.y * 2.0);
  if (uCanvasAspect > uVideoAspect) point.x *= uVideoAspect / uCanvasAspect;
  else point.y *= uCanvasAspect / uVideoAspect;
  gl_Position = vec4(point, 0.0, 1.0);
  if (marker) { vEnergy = 1.0 - age / GT_MARKER; vReason = -life; gl_PointSize = 10.0 * uPxScale; return; }
  float dist = length(aState0.xyz - uCamPos);
  float amp = aState1.w;
  float seed = aState1.y;
  float t = age / life;
  float twinkle = 0.78 + 0.22 * sin(age * 47.0 + seed * 40.0);
  vEnergy = smoothstep(0.0, 0.035, age) * pow(1.0 - t, 1.6) * aState2.z * uFade * uAmount * amp * twinkle;
  vec3 video = textureLod(uSmall, fuv, 0.0).rgb;
  vec3 hue = video / max(max(video.r, max(video.g, video.b)), 0.2);
  vColor = mix(hue, vec3(1.0), vKind > 1.5 ? 0.45 : 0.62);
  float core = clamp(2.2 / max(dist, 0.5), 0.8, 2.4) * (0.8 + 0.35 * amp) * (vKind > 1.5 ? 1.25 : 1.0);
  gl_PointSize = core * 9.0 * uPxScale;
}`;

export const newtonGlintFragmentSource = `#version 300 es
precision highp float;
in float vEnergy;
in float vReason;
in float vKind;
in vec3 vColor;
out vec4 outColor;
uniform float uDebugAttach;
vec3 reasonColor(float r) {
  if (r < 1.5) return vec3(1.00, 0.15, 0.15);   // sky / no surface
  if (r < 2.5) return vec3(1.00, 0.55, 0.10);   // occluded
  if (r < 3.5) return vec3(0.30, 0.40, 1.00);   // silhouette edge
  return vec3(0.60, 0.60, 0.60);                // off-screen
}
void main() {
  if (vEnergy < 0.002) discard;
  vec2 p = gl_PointCoord * 2.0 - 1.0;
  if (vReason > 0.5) {
    float ring = smoothstep(0.45, 0.6, length(p)) * (1.0 - smoothstep(0.75, 0.9, length(p)));
    outColor = vec4(reasonColor(vReason) * ring * vEnergy, 0.0);
    return;
  }
  // A small specular glint: a hot core, a soft halo and a faint four-point star.
  float r2 = dot(p, p);
  float core = exp(-r2 * 70.0);
  float halo = exp(-r2 * 11.0) * 0.20;
  float arms = exp(-abs(p.x) * 4.5 - p.y * p.y * 700.0) + exp(-abs(p.y) * 4.5 - p.x * p.x * 700.0);
  float star = core * 1.4 + halo + arms * 0.32;
  vec3 color = uDebugAttach > 0.5 ? vec3(1.0, 0.95, 0.35) : vColor;
  outColor = vec4(color * star * vEnergy, 0.0);
}`;

export const newtonGlintDummyFragment = `#version 300 es
precision highp float;
out vec4 color;
void main() { color = vec4(0.0); }`;
