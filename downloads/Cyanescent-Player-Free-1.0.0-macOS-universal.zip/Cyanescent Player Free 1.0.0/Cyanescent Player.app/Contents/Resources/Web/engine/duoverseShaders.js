// All coordinates in these shaders use video UVs. Export rows are top-first;
// field textures are flipped on upload, so a top-first particle y samples 1-y.
export const duoverseFieldGLSL = `
uniform sampler2D uSurface;
uniform sampler2D uFlow;
vec4 surfaceAt(vec2 uv) { return texture(uSurface, uv); }
vec4 flowAt(vec2 uv) { return texture(uFlow, uv); }
float supportAt(vec2 uv) {
  vec4 s = surfaceAt(uv), f = flowAt(uv);
  return s.a * smoothstep(0.48, 0.78, f.a) * step(0.14, abs(s.r - 0.5));
}
`;

export const duoverseOverlaySource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uColor;
uniform float uCanvasAspect, uVideoAspect, uIntensity, uGlow, uEnergy, uBass, uMids, uHighs, uBreath, uJunctionPulse;
uniform int uDebug;
${duoverseFieldGLSL}
void main() {
  vec2 uv = vUv;
  if (uCanvasAspect > uVideoAspect) uv.x = (uv.x - 0.5) * uCanvasAspect / uVideoAspect + 0.5;
  else uv.y = (uv.y - 0.5) * uVideoAspect / uCanvasAspect + 0.5;
  if (any(lessThan(uv, vec2(0))) || any(greaterThan(uv, vec2(1)))) { outColor = vec4(0); return; }
  vec4 s = surfaceAt(uv), f = flowAt(uv);
  float support = supportAt(uv);
  float generation = clamp(s.b * 2.0, 0.0, 1.0); // Exported generation / 4; scene-visible hierarchy mostly 0..2.
  if (uDebug == 1) { outColor = vec4(vec3(s.a), 1); return; }
  if (uDebug == 2) { outColor = vec4(vec3(generation, 0.18 + generation * 0.62, 1.0 - generation), 1); return; }
  if (uDebug == 3) { outColor = vec4(s.r > 0.51 ? vec3(0.16, 0.8, 0.9) : vec3(0.95, 0.52, 0.15), 1); return; }
  if (uDebug == 4) { outColor = vec4(f.rg, f.b, 1); return; }
  if (uDebug == 5) { outColor = vec4(vec3(f.b), 1); return; }
  if (uDebug == 6) { outColor = vec4(vec3(f.a), 1); return; }
  if (uDebug == 8) { outColor = vec4(0.0, 0.0, 0.0, 0.86); return; }
  if (uDebug == 7) {
    vec2 texel = 1.0 / vec2(textureSize(uSurface, 0));
    float materialEdge = max(abs(s.r - surfaceAt(uv + vec2(texel.x, 0.0)).r),
                             abs(s.r - surfaceAt(uv + vec2(0.0, texel.y)).r));
    float generationEdge = max(abs(s.b - surfaceAt(uv + vec2(texel.x, 0.0)).b),
                               abs(s.b - surfaceAt(uv + vec2(0.0, texel.y)).b));
    float edge = max(step(0.35, materialEdge), smoothstep(0.09, 0.20, generationEdge));
    float alpha = edge * support * 0.80;
    outColor = vec4(vec3(0.95, 0.05, 0.09) * alpha, alpha);
    return;
  }
  vec3 source = texture(uColor, uv).rgb;
  float luma = max(max(source.r, source.g), source.b);
  vec3 hue = mix(source / max(luma, 0.12), vec3(1.0), s.r > 0.51 ? 0.33 : 0.18);
  float hierarchy = mix(0.45 + uBass * 0.55, 0.42 + uHighs * 0.45, generation);
  float edge = smoothstep(0.29, 0.53, s.g) * (1.0 - smoothstep(0.67, 0.91, s.g));
  float junction = smoothstep(0.40, 0.86, f.b) * uJunctionPulse * (0.15 + uMids * 0.55);
  float aura = support * (edge * 0.025 * hierarchy + junction * 0.045) * (0.72 + uBreath * 0.28);
  aura *= uIntensity * uGlow * smoothstep(0.04, 0.22, luma);
  outColor = vec4(hue * aura, clamp(aura, 0.0, 0.14));
}`;

export const duoverseUpdateSource = `#version 300 es
precision highp float;
layout(location=0) in vec4 aState0; // x, top-first y, age, lifetime
layout(location=1) in vec4 aState1; // heading x/y, speed, material sign
out vec4 vState0;
out vec4 vState1;
uniform float uDelta, uClock, uAmount, uSpeed, uBass, uMids, uHighs, uEnergy, uKick, uReverse, uRecovery;
uniform sampler2D uColor;
${duoverseFieldGLSL}
float hash(float n) { return fract(sin(n * 127.1) * 43758.5453123); }
float luminanceAt(vec2 uv) { vec3 c = texture(uColor, clamp(uv, vec2(0), vec2(1))).rgb; return max(max(c.r, c.g), c.b); }
float detailAt(vec2 uv) {
  vec2 texel = 1.0 / vec2(textureSize(uColor, 0));
  return abs(luminanceAt(uv + vec2(texel.x, 0)) - luminanceAt(uv - vec2(texel.x, 0))) +
         abs(luminanceAt(uv + vec2(0, texel.y)) - luminanceAt(uv - vec2(0, texel.y)));
}
void main() {
  float id = float(gl_VertexID);
  vec2 position = aState0.xy;
  float age = aState0.z + uDelta;
  float lifetime = aState0.w;
  vec2 heading = aState1.xy;
  float speed = aState1.z;
  float material = aState1.w;
  bool respawn = age >= lifetime || age < 0.0 || any(lessThan(position, vec2(0.0))) || any(greaterThan(position, vec2(1.0)));
  if (!respawn) {
    vec2 uv = vec2(position.x, 1.0 - position.y);
    vec4 s = surfaceAt(uv), f = flowAt(uv);
    vec2 guidance = f.rg * 2.0 - 1.0;
    float confidence = f.a;
    if (confidence < 0.42 || s.a < 0.38 || detailAt(uv) < 0.055 || (s.r - 0.5) * material < 0.025) {
      lifetime = min(lifetime, age + 0.20); // graceful exit at bad vectors or material boundary
    } else {
      // The export calls this an axis: orient each sample to the previous heading
      // so tangential sign flips cannot reverse a packet by 180 degrees.
      if (dot(guidance, heading) < 0.0) guidance = -guidance;
      vec2 nextHeading = normalize(mix(heading, guidance, 0.30 + uMids * 0.12));
      vec2 lookahead = position + nextHeading * speed * uDelta * uSpeed * 1.8;
      vec4 nextSurface = surfaceAt(vec2(clamp(lookahead.x, 0.0, 1.0), 1.0 - clamp(lookahead.y, 0.0, 1.0)));
      if ((nextSurface.r - 0.5) * material < 0.025) lifetime = min(lifetime, age + 0.16);
      else {
        heading = nextHeading;
        vec2 normal = vec2(-heading.y, heading.x);
        vec2 edgeOffset = vec2(normal.x, -normal.y) * vec2(2.0 / 320.0, 2.0 / 180.0);
        float toward = detailAt(uv + edgeOffset) - detailAt(uv - edgeOffset);
        position += normal * clamp(toward, -0.45, 0.45) * 0.0011;
        float reverse = hash(id * 0.734) < uReverse ? -1.0 : 1.0;
        float generation = clamp(s.b * 2.0, 0.0, 1.0);
        float band = mix(0.58 + uBass * 0.68, 0.64 + uHighs * 0.45, generation);
        float impulse = 1.0 + 0.48 * uKick + 0.42 * uRecovery;
        position += heading * speed * uSpeed * uDelta * band * impulse * reverse * smoothstep(0.40, 0.84, confidence);
      }
    }
  }
  if (respawn) {
    bool accepted = false;
    float cycle = floor(uClock * 4.0) + floor(age / max(lifetime, 0.1));
    for (int attempt = 0; attempt < 10; attempt++) {
      float key = id * 17.31 + cycle * 91.73 + float(attempt) * 53.19;
      vec2 candidate = vec2(hash(key), hash(key + 5.237));
      vec2 uv = vec2(candidate.x, 1.0 - candidate.y);
      vec4 s = surfaceAt(uv), f = flowAt(uv);
      float generation = clamp(s.b * 2.0, 0.0, 1.0);
      float band = generation < 0.28 ? uBass : generation < 0.65 ? uMids : uHighs;
      float activity = 0.15 + 0.44 * uEnergy + 0.33 * band + 0.20 * uKick + 0.24 * uRecovery;
      if (supportAt(uv) > 0.53 && s.g > 0.27 && detailAt(uv) > 0.135 &&
          hash(key + 9.42) < activity && hash(key + 1.18) < uAmount) {
        position = candidate;
        heading = normalize(f.rg * 2.0 - 1.0);
        if (length(heading) < 0.5) heading = vec2(0.0, 1.0);
        speed = mix(0.050, 0.115, generation) * (0.74 + hash(key + 3.1) * 0.48);
        material = s.r > 0.5 ? 1.0 : -1.0;
        age = 0.0;
        lifetime = mix(2.7, 1.3, generation) * (0.70 + hash(key + 11.1) * 0.55);
        accepted = true;
        break;
      }
    }
    if (!accepted) { age = -1.0; lifetime = 0.0; }
  }
  vState0 = vec4(position, age, lifetime);
  vState1 = vec4(heading, speed, material);
  gl_Position = vec4(0.0);
}`;

export const duoverseParticleVertexSource = `#version 300 es
precision highp float;
layout(location=0) in vec4 aState0;
layout(location=1) in vec4 aState1;
out vec2 vSourceUv;
out vec2 vHeading;
out float vLife, vGeneration, vMaterial, vJunction, vGradient, vConfidence;
uniform float uCanvasAspect, uVideoAspect, uScale;
${duoverseFieldGLSL}
void main() {
  vec2 position = aState0.xy;
  vec2 point = vec2(position.x * 2.0 - 1.0, 1.0 - position.y * 2.0);
  if (uCanvasAspect > uVideoAspect) point.x *= uVideoAspect / uCanvasAspect;
  else point.y *= uCanvasAspect / uVideoAspect;
  gl_Position = vec4(point, 0.0, 1.0);
  vSourceUv = vec2(position.x, 1.0 - position.y);
  vec4 s = surfaceAt(vSourceUv), f = flowAt(vSourceUv);
  vGeneration = clamp(s.b * 2.0, 0.0, 1.0);
  vMaterial = s.r;
  vJunction = f.b;
  vGradient = s.g;
  vConfidence = f.a;
  vHeading = aState1.xy;
  vLife = aState0.z >= 0.0 && aState0.z < aState0.w ?
    smoothstep(0.0, 0.18, aState0.z) * smoothstep(0.0, 0.36, aState0.w - aState0.z) * supportAt(vSourceUv) : 0.0;
  gl_PointSize = vLife > 0.003 ? mix(19.0, 8.0, vGeneration) * (vMaterial > 0.5 ? 1.15 : 0.77) *
    (1.0 + 0.45 * smoothstep(0.52, 0.92, vJunction)) * uScale : 1.0;
}`;

export const duoverseParticleFragmentSource = `#version 300 es
precision highp float;
in vec2 vSourceUv, vHeading;
in float vLife, vGeneration, vMaterial, vJunction, vGradient, vConfidence;
out vec4 outColor;
uniform sampler2D uColor;
uniform float uIntensity, uTrail, uBass, uMids, uHighs, uKick, uJunctionPulse, uBreath;
uniform int uParticleDebug;
void main() {
  if (vLife < 0.003) discard;
  vec2 p = gl_PointCoord * 2.0 - 1.0;
  vec2 dir = normalize(vHeading + vec2(0.0001));
  // Make the packet elongated along the exported strand direction.
  float along = dot(p, vec2(dir.x, -dir.y));
  float across = dot(p, vec2(-dir.y, -dir.x));
  float glass = step(0.51, vMaterial);
  float core = exp(-across * across * mix(20.0, 12.0, glass) - along * along * 2.8);
  float trail = exp(-across * across * mix(12.0, 5.5, glass) - (along + 0.36) * (along + 0.36) * 2.0);
  float generationBand = vGeneration < 0.28 ? uBass : vGeneration < 0.65 ? uMids : uHighs;
  float junction = smoothstep(0.43, 0.85, vJunction) * (0.14 + uJunctionPulse) * (0.25 + uMids * 0.62);
  float alpha = (core * (0.45 + 0.60 * generationBand) + trail * 0.25 * uTrail) * vLife * uIntensity;
  alpha *= 0.45 + 0.55 * smoothstep(0.42, 0.82, vConfidence);
  alpha *= 0.82 + uBreath * 0.18;
  alpha += junction * core * vLife * 0.32;
  alpha *= mix(0.68 + uKick * 0.56 + uHighs * 0.26, 0.75 + uMids * 0.4, glass) * 1.65;
  vec3 source = texture(uColor, vSourceUv).rgb;
  float luma = max(max(source.r, source.g), source.b);
  vec3 hue = mix(source / max(luma, 0.10), vec3(1.0), mix(0.20, 0.43, glass));
  // The beauty pixel supplies the evolving palette; metal stays sharper,
  // glass carries a wider, softer halo.
  outColor = vec4(uParticleDebug == 1 ? vec3(1.0, 0.88, 0.15) : hue, clamp(alpha * (uParticleDebug == 1 ? 2.0 : 1.0), 0.0, 0.82));
}`;
