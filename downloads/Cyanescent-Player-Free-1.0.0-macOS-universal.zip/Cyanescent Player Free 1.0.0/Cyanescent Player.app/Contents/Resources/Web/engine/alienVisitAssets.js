import { capabilityEnabled } from "../config/runtimeCapabilities.js";
// The Alien Visits library: rare, semi-transparent video intrusions that play
// over whatever preset is running. Filenames are listed here rather than
// discovered at runtime because the app loads from a packaged bundle with no
// directory listing available -- the same convention presetBackgroundUrls uses
// in visualAssets.js.
//
// This list is filtered through editionIncludesAsset(), so an edition that
// does not stage assets/AlienVisits simply has no encounters rather than
// requesting files that are not there.
import { editionIncludesAsset } from "../generated/editionConfig.js";

const ALIEN_VISIT_DIRECTORY = "assets/AlienVisits";

// Exact on-disk names, generated from the directory. Several contain an
// ellipsis, an apostrophe or a comma, so callers must encodeURI() before
// assigning to video.src; the raw form is kept here because that is what
// editionIncludesAsset() matches against.
const ALIEN_VISIT_FILES = Object.freeze([
  "Alien_examining_sacred_object_1080p_202608020137.mp4",
  "Alien_probe_discovers_fractal_ma…_202608020122.mp4",
  "Black_monolith_floating_in_space_202608020136.mp4",
  "Cosmic_organisms_blooming_in_space_202608022107.mp4",
  "Gigantic_lifeform_swimming_throu…_1080p_202608020130.mp4",
  "Glowing_orb_drifting_fractal_lan…_202608020146.mp4",
  "Higher-dimensional_being_emergin…_1080p_202608020125.mp4",
  "Humanity's_first_flyby_alien_sphere_202608020134.mp4",
  "Humanoid_silhouette_materialisin…_1080p_202608020143.mp4",
  "Luminous_craft_passing_overhead_1080p_202608020128.mp4",
  "Reality_wrinkles,_crack_opens_di…_202608020139.mp4",
  "Window_appears_in_darkness_1080p_202608020133.mp4",
]);

export function alienVisitSources() {
  if (!capabilityEnabled("alienVisits")) return [];
  return ALIEN_VISIT_FILES
    .map((name) => `${ALIEN_VISIT_DIRECTORY}/${name}`)
    .filter((path) => editionIncludesAsset(path));
}

export function alienVisitLibrarySize() {
  return ALIEN_VISIT_FILES.length;
}
