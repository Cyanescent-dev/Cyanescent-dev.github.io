function dataUrlBase64(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  const chunkSize = 0x8000;
  let binary = "";
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, Math.min(bytes.length, index + chunkSize)));
  }
  return btoa(binary);
}

function preferredMimeType() {
  if (typeof MediaRecorder === "undefined" || typeof MediaRecorder.isTypeSupported !== "function") return "";
  const candidates = [
    "video/mp4;codecs=avc1.42E01E",
    "video/mp4",
    "video/webm;codecs=vp9",
    "video/webm"
  ];
  return candidates.find((type) => MediaRecorder.isTypeSupported(type)) || "";
}

function extensionForMimeType(mimeType) {
  return mimeType.includes("mp4") ? "mp4" : "webm";
}

// Diagnostic recorder only. Forge presets use a hardware-composited video
// underneath a transparent WebGL canvas, so recording the canvas alone loses
// the visual foundation. Combine those surfaces only while recording a trial.
export function createPresetTrialVideoCapture({
  canvas,
  nativeApp = () => null,
  targetFps = 30,
  stopAtSeconds = null,
  getAudioStream = () => null,
  getBackgroundVideo = () => null,
  enabled = false
} = {}) {
  let recorder = null;
  let stream = null;
  let chunks = [];
  let started = false;
  let frameCount = 0;
  let mimeType = "";
  let stopPromise = null;
  let captureCanvas = null;
  let captureContext = null;
  let composite = false;
  let nextCaptureDeadline = null;
  let recordingSeconds = 0;
  const captureFps = Math.max(1, Number(targetFps) || 30);

  function drawComposite() {
    if (!captureContext) return;
    if (captureCanvas.width !== canvas.width || captureCanvas.height !== canvas.height) {
      captureCanvas.width = canvas.width;
      captureCanvas.height = canvas.height;
    }
    captureContext.globalAlpha = 1;
    captureContext.fillStyle = "#03040a";
    captureContext.fillRect(0, 0, captureCanvas.width, captureCanvas.height);
    const video = getBackgroundVideo();
    if (video?.readyState >= 2 && video.style?.display !== "none") {
      const aspect = video.videoWidth / video.videoHeight;
      const width = Math.min(captureCanvas.width, captureCanvas.height * aspect);
      const height = width / aspect;
      const opacity = Number.parseFloat(video.style?.opacity);
      captureContext.globalAlpha = Number.isFinite(opacity) ? Math.min(1, Math.max(0, opacity)) : 1;
      captureContext.drawImage(video, (captureCanvas.width - width) * 0.5,
        (captureCanvas.height - height) * 0.5, width, height);
    }
    captureContext.globalAlpha = 1;
    // Called immediately after a rendered frame, before WebKit can discard
    // the accelerated default framebuffer.
    captureContext.drawImage(canvas, 0, 0);
  }

  function start() {
    if (!enabled || started) return false;
    if (!canvas?.captureStream || typeof MediaRecorder === "undefined") {
      nativeApp()?.postMessage({ command: "presetTrialVideoUnavailable", reason: "MediaRecorder or canvas.captureStream is unavailable." });
      return false;
    }
    mimeType = preferredMimeType();
    if (!mimeType) {
      nativeApp()?.postMessage({ command: "presetTrialVideoUnavailable", reason: "No supported MP4 or WebM MediaRecorder MIME type was found." });
      return false;
    }
    try {
      composite = Boolean(getBackgroundVideo());
      if (composite) {
        captureCanvas = document.createElement("canvas");
        captureContext = captureCanvas.getContext("2d");
        if (!captureContext) throw new Error("Diagnostic video compositor is unavailable.");
        drawComposite();
      }
      stream = (captureCanvas || canvas).captureStream(captureFps);
      // Clone tracks so finishing a diagnostic recording never stops the
      // player's own audio stream. Synthetic fixtures remain silent.
      for (const track of getAudioStream()?.getAudioTracks?.() || []) stream.addTrack(track.clone());
      recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 8_000_000 });
      chunks = [];
      frameCount = 0;
      recordingSeconds = 0;
      nextCaptureDeadline = null;
      recorder.ondataavailable = (event) => {
        if (event.data?.size) chunks.push(event.data);
      };
      recorder.onerror = (event) => {
        nativeApp()?.postMessage({ command: "presetTrialVideoUnavailable", reason: String(event?.error?.message || "MediaRecorder error") });
      };
      recorder.start(250);
      started = true;
      nativeApp()?.postMessage({ command: "presetTrialVideoStarted", mimeType,
        targetFps: captureFps, captureKind: composite ? "video-webgl-composite" : "webgl" });
      return true;
    } catch (error) {
      stream?.getTracks?.().forEach((track) => track.stop());
      stream = null;
      nativeApp()?.postMessage({ command: "presetTrialVideoUnavailable", reason: String(error?.message || error) });
      return false;
    }
  }

  function noteFrame(simulationSeconds = null) {
    if (!started) return;
    const seconds = Number.isFinite(simulationSeconds) ? Number(simulationSeconds) : performance.now() / 1000;
    recordingSeconds = seconds;
    if (nextCaptureDeadline === null) nextCaptureDeadline = seconds;
    if (seconds + 0.000001 >= nextCaptureDeadline) {
      drawComposite();
      frameCount += 1;
      const period = 1 / captureFps;
      nextCaptureDeadline += period;
      // Preserve the recording cadence when render FPS is not a multiple of
      // capture FPS. A stalled renderer gets one current frame, not a burst of
      // duplicate catch-up frames on subsequent callbacks.
      if (seconds - nextCaptureDeadline > period * 2) nextCaptureDeadline = seconds + period;
    }
    if (Number.isFinite(stopAtSeconds) && Number(simulationSeconds) >= Number(stopAtSeconds)) {
      void stop();
    }
  }

  function stop() {
    if (stopPromise) return stopPromise;
    if (!started || !recorder) return Promise.resolve(false);
    stopPromise = new Promise((resolve) => {
      const activeRecorder = recorder;
      activeRecorder.onstop = async () => {
        try {
          const blob = new Blob(chunks, { type: mimeType });
          const data = await blob.arrayBuffer();
          nativeApp()?.postMessage({
            command: "presetTrialVideo",
            data: dataUrlBase64(data),
            mimeType,
            extension: extensionForMimeType(mimeType),
            bytes: data.byteLength,
            frameCount,
            durationSeconds: recordingSeconds,
            captureFps,
            captureKind: composite ? "video-webgl-composite" : "webgl"
          });
          resolve(true);
        } catch (error) {
          nativeApp()?.postMessage({ command: "presetTrialVideoUnavailable", reason: String(error?.message || error) });
          resolve(false);
        } finally {
          stream?.getTracks?.().forEach((track) => track.stop());
          stream = null;
          recorder = null;
          started = false;
          chunks = [];
          stopPromise = null;
          captureCanvas = null;
          captureContext = null;
          composite = false;
        }
      };
      try {
        activeRecorder.stop();
      } catch (error) {
        nativeApp()?.postMessage({ command: "presetTrialVideoUnavailable", reason: String(error?.message || error) });
        resolve(false);
      }
    });
    return stopPromise;
  }

  return { start, stop, noteFrame };
}
