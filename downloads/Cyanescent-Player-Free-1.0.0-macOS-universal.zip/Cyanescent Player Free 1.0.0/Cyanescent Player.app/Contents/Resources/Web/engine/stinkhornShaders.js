export const stinkhornCopySource=`#version 300 es
precision highp float;
in vec2 vUv; out vec4 outColor; uniform sampler2D uVideo;
void main(){outColor=texture(uVideo,vUv);}`;
export const stinkhornCompositeSource=`#version 300 es
precision highp float; precision highp int;
in vec2 vUv; out vec4 outColor;
uniform sampler2D uVideo,uGeometry,uStructure,uNetwork,uFlow,uActivity,uPathData;
uniform float uCrownEnergy,uTime,uEnergy,uHighs,uInterior,uLife;
uniform vec4 uAmounts;uniform int uCompare,uQuality;
uniform vec2 uResolution; uniform float uAspect,uReady,uIntensity; uniform int uDebug;
uniform vec3 uPosition,uForward,uRight,uUp,uCrown; uniform float uTan;
vec3 worldRay(vec2 uv){return normalize(uForward+uRight*(2.0*uv.x-1.0)*uAspect*uTan+uUp*(1.0-2.0*uv.y)*uTan);}
float packet(float id,float arc){int row=int(round(id))-1;float x=clamp(arc,0.0,1.0)*127.0;int a=int(floor(x));
return mix(texelFetch(uActivity,ivec2(a,row),0).r,texelFetch(uActivity,ivec2(min(a+1,127),row),0).r,fract(x));}
struct EmissionField {vec4 network;vec4 geometry;vec2 uv;float material;float weight;float coverage;};
EmissionField fieldAt(ivec2 at,float coverage,vec3 base){
 ivec2 size=textureSize(uStructure,0);at=clamp(at,ivec2(0),size-1);
 EmissionField f;f.network=texelFetch(uNetwork,at,0);f.geometry=texelFetch(uGeometry,at,0);
 f.material=texelFetch(uStructure,at,0).r;f.uv=(vec2(at)+.5)/vec2(size);f.coverage=coverage;
 vec3 difference=(texture(uVideo,f.uv).rgb-base)*vec3(.85,1.0,.85);
 f.weight=coverage*exp(-dot(difference,difference)*24.0);return f;
}
float cageCoverage(EmissionField f){return (f.material==1.0||f.material==2.0)?f.coverage:0.0;}
float nearerCoverage(EmissionField f,EmissionField other){
 if(other.geometry.r<=0.0||other.network.r==f.network.r)return 0.0;
 return other.coverage*smoothstep(max(.18,f.geometry.r*.025),max(.36,f.geometry.r*.05),f.geometry.r-other.geometry.r);
}
vec3 networkEmission(EmissionField f,EmissionField a,EmissionField b,EmissionField c,vec3 ray,float total,float textureLife){
 vec4 nn=f.network,gg=f.geometry;
 if(nn.a<.5||nn.r<.5||gg.r<=0.0||(f.material!=6.0&&f.material!=7.0))return vec3(0);
 // Same-path braid fibres remain one bundle. Different nearer paths/materials
 // suppress a farther emitter continuously, without a nearest-texel anchor.
 float obstruction=nearerCoverage(f,a)+nearerCoverage(f,b)+nearerCoverage(f,c);
 float transmission=1.0-smoothstep(.05,.65,obstruction);
 int id=int(round(nn.r))-1;vec4 path=texelFetch(uPathData,ivec2(id,0),0);
 bool floorPath=path.y<2.5||path.y==11.0||path.y==12.0;
 float amount=floorPath?uAmounts.y*(1.0-.45*uInterior):uAmounts.x*(.12+.88*smoothstep(.15,.85,uInterior));
 float signal=packet(nn.r,nn.g)*amount;
 vec3 hit=uPosition+worldRay(f.uv)*gg.r;
 float variation=.5+.5*sin(nn.g*path.x*1.4+float(id)*.91+uTime*.22);
 vec3 lavender=mix(vec3(.74,.29,.76),vec3(.82,.37,.70),variation);
 vec3 tint=floorPath?mix(vec3(.91,.96,1),lavender,smoothstep(.12,.85,signal))
   :mix(vec3(.91,.96,1),lavender,smoothstep(.06,.8,hit.y));
 float rest=(.0025+.006*uLife)*(.7+.3*sin(uTime*.8+float(id)*1.7+nn.g*19.0))*amount;
 float glimmer=pow(max(0.0,sin(nn.g*path.x*69.0-uTime*5.0+float(id))),24.0)*(.006*uLife+.028*uHighs)*amount;
 float facing=.78+.22*abs(dot(normalize(gg.gba),ray));float power=1.0-exp(-signal*.95);
 // Lavender shoulders, warmer centres and full-resolution fibrous contrast.
 vec3 light=(tint*(rest+power*.98+glimmer)+vec3(.98,.78,.77)*power*power*.18)*facing*textureLife;
 return f.weight/max(total,1e-6)*light*transmission;
}
vec2 crownCoverage(EmissionField f,vec3 ray,float front){
 if(f.material==1.0||f.material==2.0)return vec2(0);
 float visibility=f.geometry.r>0.0?smoothstep(0.0,1.6,f.geometry.r-front):1.0,surface=0.0;
 if(f.geometry.r>0.0){vec3 d=uPosition+ray*f.geometry.r-uCrown;surface=exp(-dot(d,d)/38.0)*.17;}
 return f.weight*vec2(visibility,surface);
}
vec3 emission(vec2 uv,vec3 base){
 vec3 ray=worldRay(uv);ivec2 size=textureSize(uStructure,0);
 vec2 p=uv*vec2(size)-.5,t=fract(p);ivec2 q=ivec2(floor(p));
 // Four explicit samples keep the compiler's accesses static. No per-fragment
 // dynamically indexed field arrays or additional full-resolution buffers.
 EmissionField a=fieldAt(q,(1.0-t.x)*(1.0-t.y),base);
 EmissionField b=fieldAt(q+ivec2(1,0),t.x*(1.0-t.y),base);
 EmissionField c=fieldAt(q+ivec2(0,1),(1.0-t.x)*t.y,base);
 EmissionField d=fieldAt(q+ivec2(1,1),t.x*t.y,base);
 float total=a.weight+b.weight+c.weight+d.weight,cage=cageCoverage(a)+cageCoverage(b)+cageCoverage(c)+cageCoverage(d);
 float textureLife=.65+.55*sqrt(max(0.0,dot(base,vec3(.2126,.7152,.0722))));
 vec3 networkLight=networkEmission(a,b,c,d,ray,total,textureLife)+networkEmission(b,a,c,d,ray,total,textureLife)
   +networkEmission(c,a,b,d,ray,total,textureLife)+networkEmission(d,a,b,c,ray,total,textureLife);
 float red=1.0-smoothstep(.025,.06,base.r-base.g*1.22);
 networkLight*=red*(1.0-smoothstep(0.0,.65,cage));
 vec3 crownLight=vec3(0);
 if(uCrownEnergy>.005&&uAmounts.z>.0){
   vec3 delta=uCrown-uPosition;float along=dot(delta,ray),front=max(0.0,along-5.5);
   // Interpolate independently evaluated first-hit visibility rather than
   // fictional depths across a foreground/canopy discontinuity.
   vec2 visible=(crownCoverage(a,ray,front)+crownCoverage(b,ray,front)+crownCoverage(c,ray,front)+crownCoverage(d,ray,front))/max(total,1e-6);
   float perpendicular2=max(0.0,dot(delta,delta)-along*along);
   float halo=exp(-perpendicular2/42.0)*.27+exp(-perpendicular2/9.5)*.43+exp(-perpendicular2/.48)*.16;
   float energy=1.0-exp(-uCrownEnergy*.8);
   float foreground=(1.0-smoothstep(0.0,.45,cage))*red;
   crownLight=vec3(.72,.35,.72)*energy*(halo*visible.x+visible.y)*foreground
     *smoothstep(0.0,.8,along)*smoothstep(.15,.8,uInterior)*uAmounts.z;
 }
 return networkLight+crownLight;
}

void main(){
 vec2 uv=vec2(uCompare==1?fract(vUv.x*2.0):vUv.x,1.0-vUv.y);float aspect=uResolution.x/uResolution.y*(uCompare==1?.5:1.0);
 if(aspect>uAspect)uv.x=(uv.x-.5)*aspect/uAspect+.5;else uv.y=(uv.y-.5)*uAspect/aspect+.5;
 if(any(lessThan(uv,vec2(0)))||any(greaterThan(uv,vec2(1)))){outColor=vec4(0,0,0,1);return;}
 vec3 base=texture(uVideo,uv).rgb,c=base;
 vec4 g=texture(uGeometry,uv),s=texture(uStructure,uv),n=texture(uNetwork,uv);
 if(uReady>.5){
 vec3 light=emission(uv,base);
 // No full-frame grading: beauty is identical with augmentation disabled.
 // Bounded emissive exposure preserves beauty texture and colour headroom.
 // At intensity zero this is exactly the original Forge video.
 c=base+(1.0-base)*(1.0-exp(-max(vec3(0),light)*uIntensity*1.45));
 if(uCompare==1&&vUv.x<.5)c=base;
 if(uDebug==9)c=light*2.0;

 if(uDebug==1)c=base;
 if(uDebug==2)c=vec3(fract(s.r*.31),fract(s.r*.71),fract(s.r*.11));
 if(uDebug==3)c=vec3(g.r/20.0,g.ba*.5+.5);
 if(uDebug==4)c=n.a*vec3(fract(n.r*.173),n.g,fract(n.r*.619));
 if(uDebug==7)c=vec3(texture(uFlow,uv).rg*12.0+.5,texture(uFlow,uv).b);
 if(uDebug==8){vec3 d=uCrown-uPosition;float z=dot(d,uForward);
  vec2 p=vec2(.5+.5*dot(d,uRight)/(z*uAspect*uTan),.5-.5*dot(d,uUp)/(z*uTan));
  vec2 q=abs((uv-p)*vec2(1920,1080));if(z>0.0&&min(q.x,q.y)<1.5&&max(q.x,q.y)<12.0)c=vec3(.2,1,.4);}
 }
 outColor=vec4(c,1);
}`;
export const stinkhornPathVertex=`#version 300 es
precision highp float;
layout(location=0)in vec4 aPoint; // top-left uv, GPU transmission, flags
uniform float uAspect;uniform vec2 uResolution;out float vVisibility;
void main(){vec2 p=aPoint.xy*2.0-1.0;p.y=-p.y;float a=uResolution.x/uResolution.y;
if(a>uAspect)p.x*=uAspect/a;else p.y*=a/uAspect;
gl_Position=vec4(p,0,1);vVisibility=aPoint.z;}`;
export const stinkhornPathFragment=`#version 300 es
precision highp float;in float vVisibility;out vec4 outColor;uniform int uDebug;
void main(){if(uDebug!=6&&vVisibility<=0.0)discard;outColor=vec4(uDebug==6?mix(vec3(.7,.02,.02),vec3(.1,1,.2),vVisibility):vec3(.3,.8,1)*vVisibility,.8);}`;
export const stinkhornSporeVertex=`#version 300 es
precision highp float;layout(location=0)in vec4 aSpore;
uniform vec3 uPosition,uForward,uRight,uUp;uniform float uTan,uAspect,uIntensity;
uniform vec2 uResolution;uniform int uCompare;
out vec2 vImageUv;out float vDistance,vPower;
void main(){vec3 d=aSpore.xyz-uPosition;float z=dot(d,uForward);
vec2 p=vec2(dot(d,uRight)/(z*uTan*uAspect),dot(d,uUp)/(z*uTan));
vImageUv=vec2(p.x*.5+.5,.5-p.y*.5);vDistance=length(d);vPower=aSpore.w*uIntensity;
float aspect=uResolution.x/uResolution.y*(uCompare==1?.5:1.0);
if(aspect>uAspect)p.x*=uAspect/aspect;else p.y*=aspect/uAspect;
if(uCompare==1)p.x=p.x*.5+.5;
gl_Position=z>0.0?vec4(p,0,1):vec4(3,3,0,1);
gl_PointSize=clamp(.007*uResolution.y/max(.1,z*uTan),1.2,3.2);}`;
export const stinkhornSporeFragment=`#version 300 es
precision highp float;in vec2 vImageUv;in float vDistance,vPower;
uniform sampler2D uGeometry,uStructure;out vec4 outColor;
void main(){float ray=texture(uGeometry,vImageUv).r;
if(ray>0.0&&ray<vDistance-.015)discard;
if(texture(uStructure,vImageUv).r==1.0)discard;
ivec2 size=textureSize(uStructure,0),p=ivec2(floor(vImageUv*vec2(size)-.5));
for(int y=0;y<2;y++)for(int x=0;x<2;x++)if(texelFetch(uStructure,clamp(p+ivec2(x,y),ivec2(0),size-1),0).r==1.0)discard;
float q=length(gl_PointCoord-.5)*2.0;float alpha=exp(-q*q*5.0)*vPower;
outColor=vec4(.85,.57,.73,alpha);}`;
