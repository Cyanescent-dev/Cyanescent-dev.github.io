// Clifford Phase Space: Metamorphosis — the authored worlds on the route and their colour.
//
// Each world is a parameter region found by sampling the Clifford parameter space and inspecting
// renders (see docs/CLIFFORD_METAMORPHOSIS.md). Its palette is a cyclic four-stop gradient indexed
// by the orbit's direction of travel, which varies smoothly along every strand, so colour follows
// the folds; the accent lights the pulses that run along the attractor.
import { ROUTE_WORLDS } from "./cliffordMetamorphosisItinerary.js";

const hex = (value) => {
  const n = parseInt(value.slice(1), 16);
  // sRGB to linear: the density image is accumulated and tone mapped in linear light.
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) => Math.pow(c / 255, 2.2));
};

export const WORLD_STYLES = Object.freeze({
  arch:     { title: "Twin Cathedral",  stops: ["#12e6d2", "#0a46e0", "#9a2cf5", "#ff4fc8"], accent: "#ffc861" },
  nautilus: { title: "Nautilus",        stops: ["#ff5a5f", "#ffb03a", "#ff2b9c", "#1ec8d2"], accent: "#3ff2ff" },
  orchid:   { title: "Orchid Vortex",   stops: ["#b93cff", "#ff4fd2", "#ffd2f2", "#14c88c"], accent: "#ffd84a" },
  eye:      { title: "Eye of the Storm", stops: ["#ffc43a", "#ff6a21", "#06606e", "#36f0d2"], accent: "#ff3fb0" },
  crown:    { title: "Emerald Crown",   stops: ["#00dc86", "#b4ff3a", "#18b0ff", "#0a36f0"], accent: "#ff6f61" },
  rings:    { title: "Opal Rings",      stops: ["#ff8ae6", "#58e6ff", "#9a7cff", "#ffe27a"], accent: "#a03cff" },
  disc:     { title: "Electric Mobius", stops: ["#ff00c4", "#6400ff", "#00b0ff", "#b8ff3a"], accent: "#c6ff3a" },
  wing:     { title: "Sunset Wing",     stops: ["#ff3a3a", "#ff963a", "#ffe066", "#ff2a90"], accent: "#30f0ff" },
  knot:     { title: "Ice Knot",        stops: ["#bfe8ff", "#4c8cff", "#a46cff", "#2c20ff"], accent: "#ffb43a" }
});

// Flat uniform arrays in route order; slot WORLD count (the loop's end) repeats the first world.
export function worldPaletteUniforms(slots) {
  const palette = new Float32Array(slots * 4 * 3), accent = new Float32Array(slots * 3);
  for (let s = 0; s < slots; s += 1) {
    const world = ROUTE_WORLDS[s % ROUTE_WORLDS.length];
    const style = WORLD_STYLES[world.name];
    style.stops.forEach((stop, i) => palette.set(hex(stop), (s * 4 + i) * 3));
    accent.set(hex(style.accent), s * 3);
  }
  return { palette, accent };
}

// Continuous world coordinate at a route fraction: k at world k's anchor, fractional in between,
// ROUTE_WORLDS.length at the end of the loop.
export function worldCoordinate(fraction) {
  const f = ((fraction % 1) + 1) % 1, n = ROUTE_WORLDS.length;
  for (let k = 0; k < n; k += 1) {
    const a = ROUTE_WORLDS[k].at, b = k + 1 < n ? ROUTE_WORLDS[k + 1].at : 1;
    if (f >= a && f < b) {
      // Hold each world's colour around its anchor, cross over in the middle of the corridor.
      const t = (f - a) / Math.max(1e-9, b - a);
      return k + Math.min(1, Math.max(0, (t - 0.35) / 0.3));
    }
  }
  return 0;
}

export function nextWorldIndex(fraction) {
  const f = ((fraction % 1) + 1) % 1;
  const index = ROUTE_WORLDS.findIndex((w) => w.at > f + 1e-6);
  return index < 0 ? 0 : index;
}
