import { runtimeAllowsPreset, requireRuntimePreset } from '../config/runtimeCapabilities.js';
import { presetAnimationStartedAt } from "./presetAnimationClock.js";
import { createMandelbrotNewtonDirector, MANDELBROT_NEWTON_PRESET_ID } from "../presets/mandelbrotNewtonDirector.js";
import { createStinkhornRuntime } from './stinkhornRuntime.js';
import { bindSacredGeometryRotation, SACRED_GEOMETRY_PRESET_ID } from "../presets/sacredGeometryRotation.js";
import { STINKHORN_ID } from './stinkhornField.js';
import { createFerrofluidField, updateFerrofluidField, bindFerrofluidField, FERROFLUID_ORACLE_ID } from "../presets/ferrofluidOracleField.js";
import {
  createRenderTarget,
  deleteRenderTarget,
  ensureSizedRenderTargetWithDepth
} from "./renderTargets.js";
import { createVisualBackgroundCompositor } from "./visualBackgroundCompositor.js";
import { createForgeHybridRuntime } from "./forgeHybridRuntime.js";
import { APOLLONIAN_PHYSARUM_GENESIS, APOLLONIAN_PHYSARUM_GENESIS_ID } from "./forgeHybridAsset.js";
import { createDuoverseRuntime } from "./duoverseRuntime.js";
import { DUOVERSE_HD, DUOVERSE_HD_ID } from "./duoverseAsset.js";
import { createNewtonBasinRuntime } from "./newtonBasinRuntime.js";
import { NEWTON_BASIN_DESCENT, NEWTON_BASIN_DESCENT_ID } from "./newtonBasinAsset.js";
import { createNewtonLawRuntime } from "./newtonLawRuntime.js";
import { NEWTONS_LAW, NEWTONS_LAW_ID } from "./newtonLawAsset.js";
import { createArtificialConsciousnessRuntime } from "./artificialConsciousnessRuntime.js";
import { ARTIFICIAL_CONSCIOUSNESS, ARTIFICIAL_CONSCIOUSNESS_ID } from "./artificialConsciousnessAsset.js";
import { createHelixTunnelRuntime } from "./helixTunnelRuntime.js";
import { HELIX_TUNNEL_ID } from "./helixTunnelAsset.js";
import { createCliffordMetamorphosisRuntime, CLIFFORD_METAMORPHOSIS_ID } from "./cliffordMetamorphosisRuntime.js";
import { createImpossibleAperturesRuntime, IMPOSSIBLE_APERTURES_ID } from "./impossibleAperturesRuntime.js";
import { createHypergeometryRuntime, HYPERGEOMETRY_ID } from "./hypergeometryRuntime.js";
import { bindSporeMemoryMycelium, SPORE_MEMORY_PRESET_ID } from "../presets/sporeMemoryMycelium.js";
import { bindLivingFirepitDirector, LIVING_FIREPIT_PRESET_ID } from "../presets/livingFirepitDirector.js";
import { bindCrystalResonanceDirector, CRYSTAL_RESONANCE_PRESET_ID } from "../presets/crystalResonanceDirector.js";
import { bindTesseractUnfoldingDirector, TESSERACT_UNFOLDING_PRESET_ID } from "../presets/tesseractUnfoldingDirector.js";
import { bindTwistorSpaceManifoldDirector, TWISTOR_SPACE_MANIFOLD_PRESET_ID } from "../presets/twistorSpaceManifoldDirector.js";
import { bindSpinNetworkMatrixDirector, SPIN_NETWORK_MATRIX_PRESET_ID } from "../presets/spinNetworkMatrixDirector.js";
import { bindToroidalMerkabaDirector, TOROIDAL_MERKABA_PRESET_ID } from "../presets/toroidalMerkabaDirector.js";
import { bindFractalLightningCathedralDirector, FRACTAL_LIGHTNING_CATHEDRAL_PRESET_ID } from "../presets/fractalLightningCathedralDirector.js";
import { bindHyperbolicCarpetDirector, HYPERBOLIC_CARPET_PRESET_ID } from "../presets/hyperbolicCarpetDirector.js";
import { bindChaoticButterflyDirector, prepareChaoticButterflyOffline, endChaoticButterflyOffline, CHAOTIC_BUTTERFLY_PRESET_ID } from "../presets/chaoticButterflyTunnelsDirector.js";
import { bindFractalBreakerDirector, prepareFractalBreakerOffline, endFractalBreakerOffline, FRACTAL_BREAKER_PRESET_ID } from "../presets/fractalBreakerDirector.js";
import { bindIfsMatrixDirector, prepareIfsMatrixOffline, endIfsMatrixOffline, IFS_MATRIX_PRESET_ID } from "../presets/ifsMatrixDirector.js";
import { bindWoodstockDirector, prepareWoodstockOffline, endWoodstockOffline, WOODSTOCK_PRESET_ID } from "../presets/woodstockDirector.js";
import { createGpuTimerCollector, transitionDiagnosticId } from "./transitionDiagnostics.js";
import {
  computeWorldshellChoreographyState,
  createWorldshellChoreographyState
} from "./worldshellChoreography.js";
import {
  createWorldshellResonanceRuntime,
  WORLDSHELL_PRESET_ID
} from "./worldshellResonanceRuntime.js";

const uniformLocationCache = new WeakMap();
const presentationDensityCache = new WeakMap();
const WORLDSHELL_WAVEFORM_TEXTURE_UNIT = 11;
const INTERNAL_FEEDBACK_PRESETS = new Set([
  APOLLONIAN_PHYSARUM_GENESIS_ID, DUOVERSE_HD_ID, NEWTON_BASIN_DESCENT_ID,
  NEWTONS_LAW_ID, ARTIFICIAL_CONSCIOUSNESS_ID, STINKHORN_ID, HELIX_TUNNEL_ID,
  CLIFFORD_METAMORPHOSIS_ID, IMPOSSIBLE_APERTURES_ID, HYPERGEOMETRY_ID
]);

function getCachedUniformLocation(context, program, name) {
  let programCache = uniformLocationCache.get(program);
  if (!programCache) {
    programCache = new Map();
    uniformLocationCache.set(program, programCache);
  }
  if (!programCache.has(name)) {
    programCache.set(name, context.getUniformLocation(program, name));
  }
  return programCache.get(name);
}
const crossFadeFragmentSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D fromFrame;
uniform sampler2D toFrame;
uniform sampler2D fromBackgroundImage;
uniform sampler2D toBackgroundImage;
uniform float mixRatio;
uniform vec2 sourceResolution;
uniform float sharpenStrength;
uniform float fromBackgroundReady;
uniform float toBackgroundReady;
uniform vec2 outputResolution;

vec3 presetBackground(sampler2D image, vec2 uv) {
  vec2 cover = uv;
  float canvasAspect = outputResolution.x / max(1.0, outputResolution.y);
  float imageAspect = 16.0 / 9.0;
  if (canvasAspect > imageAspect) {
    cover.y = (cover.y - 0.5) * (imageAspect / canvasAspect) + 0.5;
  } else {
    cover.x = (cover.x - 0.5) * (canvasAspect / imageAspect) + 0.5;
  }
  vec3 bg = texture(image, clamp(cover, vec2(0.0), vec2(1.0))).rgb;
  float r = length((uv * 2.0 - 1.0) * vec2(canvasAspect, 1.0));
  float vignette = smoothstep(1.34, 0.18, r);
  return bg * (0.70 + 0.30 * vignette);
}

vec3 compositePresetBackground(vec3 visual, sampler2D image, float ready, vec2 uv) {
  vec3 bg = presetBackground(image, uv);
  float visualLuma = max(visual.r, max(visual.g, visual.b));
  float preserveVisual = smoothstep(0.05, 0.42, visualLuma);
  vec3 withBackground = mix(bg * 0.90, bg * 0.60 + visual * 0.92, preserveVisual);
  return mix(visual, withBackground, ready);
}

vec3 mixedFrame(vec2 uv) {
  vec3 fromVisual = texture(fromFrame, uv).rgb;
  vec3 toVisual = texture(toFrame, uv).rgb;
  vec3 fromComposited = compositePresetBackground(fromVisual, fromBackgroundImage, fromBackgroundReady, uv);
  vec3 toComposited = compositePresetBackground(toVisual, toBackgroundImage, toBackgroundReady, uv);
  return mix(fromComposited, toComposited, mixRatio);
}

void main() {
  vec3 center = mixedFrame(vUv);
  float fromAlpha = mix(texture(fromFrame, vUv).a, 1.0, fromBackgroundReady);
  float toAlpha = mix(texture(toFrame, vUv).a, 1.0, toBackgroundReady);
  float outputAlpha = mix(fromAlpha, toAlpha, mixRatio);
  if (sharpenStrength <= 0.001) {
    outColor = vec4(center, outputAlpha);
    return;
  }
  vec2 texel = 1.0 / max(sourceResolution, vec2(1.0));
  vec3 north = mixedFrame(vUv + vec2(0.0, texel.y));
  vec3 south = mixedFrame(vUv - vec2(0.0, texel.y));
  vec3 east = mixedFrame(vUv + vec2(texel.x, 0.0));
  vec3 west = mixedFrame(vUv - vec2(texel.x, 0.0));
  vec3 localMean = (north + south + east + west) * 0.25;
  vec3 localMin = min(center, min(min(north, south), min(east, west)));
  vec3 localMax = max(center, max(max(north, south), max(east, west)));
  float contrast = max(localMax.r - localMin.r, max(localMax.g - localMin.g, localMax.b - localMin.b));
  float adaptive = smoothstep(0.018, 0.20, contrast);
  vec3 detail = clamp(center - localMean, vec3(-0.10), vec3(0.10));
  outColor = vec4(clamp(center + detail * sharpenStrength * adaptive, 0.0, 1.0), outputAlpha);
}`;

const WORLDSHELL_CHOREOGRAPHY_UNIFORM_FIELDS = [
  ["worldshellMorph", "worldturn"],
  ["worldshellBuildCharge", "buildCharge"],
  ["worldshellDropAge", "dropAge"],
  ["worldshellDropStrength", "dropStrengthLatch"],
  ["worldshellSectionMorph", "sectionMorph"],
  ["worldshellSectionSeedFrom", "sectionSeedFrom"],
  ["worldshellSectionSeed", "sectionSeed"],
  ["worldshellCameraImpulse", "cameraImpulse"],
  ["worldshellBeatEnvelope", "beatEnvelope"],
  ["worldshellBarPhase", "barPhase"],
  ["worldshellShockAge", "dropAge"],
  ["worldshellAnticipation", "anticipation"],
  ["worldshellInhale", "inhale"],
  ["worldshellImpact", "impact"],
  ["worldshellPropagation", "propagation"],
  ["worldshellAftershock", "aftershock"],
  ["worldshellRecovery", "recovery"],
  ["worldshellPressure", "pressure"],
  ["worldshellCameraTravel", "cameraTravel"],
  ["worldshellTravelDrive", "travelDrive"],
  ["worldshellBreakdown", "breakdownInfluence"],
  ["worldshellGeometryTime", "geometryTime"]
];

export function createVisualFrameRenderer({
  getGl,
  getCanvas,
  program,
  programFrom,
  setAttribs,
  renderSurface,
  resize,
  clearFeedbackBuffers,
  renderProgramForPreset,
  textureAssets,
  getTransition,
  getActivePreset,
  getActivePresetStartedAt,
  getSensitivity,
  getQuality,
  getSmooth,
  getSlowLevel,
  getSlowBass,
  getScionBiofeedback,
  getWavePhaseAccum,
  getVideoBackgroundState,
  getMusicAwareState,
  getLookaheadState,
  getAudioFeatures,
  getForgeTempo,
  getForgeShouldPlay,
  getOfflineClock,
  getKnotOrbitPhase,
  getFeedbackStep,
  getTimeData,
  getFrequencyData,
  getTrackTime,
  getAnalysisTimeline,
  getTrackProgress,
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  isSpecialGeometryPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  specialGeometryRenderer,
  isPresetProgramReady = () => true,
  canCoverVideoPreparation = () => false,
  isVideoCoveringOutput = () => false,
  setRenderProgram,
  diagnosticsEnabled = () => false
} = {}) {
  const mandelbrotNewtonDirector = createMandelbrotNewtonDirector();
  const ferrofluidField = createFerrofluidField();
  let crossFadeProgram = null;
  let renderedFeedback = null;
  let lastContinuityStage = "";
  let transitionGeometryTarget = null;
  let transitionGeometryTargetAux = null;
  let backgroundCompositor = null;
  let pipelineWarmTargets = null;
  let warmQualityOverride = null;
  const warmedPresetPipelines = new Set();
  const videoPreparedTransitions = new Set();
  let deferredWorldshellVideoTransition = "";
  let queuedPresetPreflight = null;
  let presetPreflightTimer = 0;
  let gpuTimerCollector = null;
  let diagnosticFrameNumber = 0;
  let worldshellChoreography = createWorldshellChoreographyState();
  const neutralWorldshellChoreography = createWorldshellChoreographyState();
  let worldshellFrameState = null;
  let worldshellLastVisibleAt = -Infinity;
  let worldshellLastTrackTime = null;
  let worldshellEntryToken = 0;
  const waveformSamples = new Float32Array(64);
  const worldshellWaveformSamples = new Uint8Array(64);
  const lastQueuedWorldshellWaveformSamples = new Uint8Array(64);
  const neutralWorldshellWaveformSamples = new Uint8Array(64).fill(128);
  const worldshellWaveformTextures = [];
  let activeWorldshellWaveformTexture = 0;
  const worldshellResonance = createWorldshellResonanceRuntime({
    getGl,
    width: 256,
    height: 192
  });
  const forgeHybrid = createForgeHybridRuntime({
    getGl,
    program,
    programFrom,
    setAttribs,
    asset: APOLLONIAN_PHYSARUM_GENESIS
  });
  const duoverse = createDuoverseRuntime({ getGl, program, programFrom, setAttribs, asset: DUOVERSE_HD });
  const newtonBasin = createNewtonBasinRuntime({ getGl, program, programFrom, setAttribs, asset: NEWTON_BASIN_DESCENT });
  const newtonLaw = createNewtonLawRuntime({ getGl, program, programFrom, setAttribs, asset: NEWTONS_LAW });
  const artificialConsciousness = createArtificialConsciousnessRuntime({ getGl, program, programFrom, setAttribs, asset: ARTIFICIAL_CONSCIOUSNESS });
  const stinkhorn = createStinkhornRuntime({ getGl, program, programFrom, setAttribs });
  const helixTunnel = createHelixTunnelRuntime({ getGl, program, setAttribs });
  const cliffordMetamorphosis = createCliffordMetamorphosisRuntime({ getGl, program, programFrom, setAttribs });
  const impossibleApertures = createImpossibleAperturesRuntime({ getGl, program, setAttribs });
  const hypergeometry = createHypergeometryRuntime({ getGl, program, programFrom, setAttribs });
  function gl() {
    return getGl?.();
  }
  function bindWorldshellWaveformTexture(context, programToUse, samplesChanged) {
    const location = getCachedUniformLocation(context, programToUse, "worldshellWaveformTexture");
    if (!location) return;
    context.activeTexture(context.TEXTURE0 + WORLDSHELL_WAVEFORM_TEXTURE_UNIT);
    while (worldshellWaveformTextures.length < 4) {
      const texture = context.createTexture();
      if (!texture) return;
      worldshellWaveformTextures.push(texture);
      context.bindTexture(context.TEXTURE_2D, texture);
      context.texParameteri(context.TEXTURE_2D, context.TEXTURE_MIN_FILTER, context.LINEAR);
      context.texParameteri(context.TEXTURE_2D, context.TEXTURE_MAG_FILTER, context.LINEAR);
      context.texParameteri(context.TEXTURE_2D, context.TEXTURE_WRAP_S, context.CLAMP_TO_EDGE);
      context.texParameteri(context.TEXTURE_2D, context.TEXTURE_WRAP_T, context.CLAMP_TO_EDGE);
      context.texImage2D(
        context.TEXTURE_2D,
        0,
        context.R8,
        64,
        1,
        0,
        context.RED,
        context.UNSIGNED_BYTE,
        neutralWorldshellWaveformSamples
      );
    }
    const textureForThisDraw = activeWorldshellWaveformTexture;
    if (samplesChanged) {
      const uploadTexture = (activeWorldshellWaveformTexture + 1) % worldshellWaveformTextures.length;
      context.bindTexture(context.TEXTURE_2D, worldshellWaveformTextures[uploadTexture]);
      context.texSubImage2D(
        context.TEXTURE_2D,
        0,
        0,
        0,
        64,
        1,
        context.RED,
        context.UNSIGNED_BYTE,
        worldshellWaveformSamples
      );
      lastQueuedWorldshellWaveformSamples.set(worldshellWaveformSamples);
      activeWorldshellWaveformTexture = uploadTexture;
    }
    context.bindTexture(context.TEXTURE_2D, worldshellWaveformTextures[textureForThisDraw]);
    context.uniform1i(location, WORLDSHELL_WAVEFORM_TEXTURE_UNIT);
  }
  function canvas() {
    return getCanvas?.();
  }
  function gpuTimers() {
    if (!gpuTimerCollector) {
      gpuTimerCollector = createGpuTimerCollector(gl(), { enabled: diagnosticsEnabled });
    }
    return gpuTimerCollector;
  }
  function presetPipelineKey(presetId, qualityValue) {
    return `${Number(presetId)}:q${Number(qualityValue) > 0.5 ? 1 : 0}`;
  }
  function worldshellVisible(activePreset, transition = {}) {
    if (Math.round(Number(activePreset)) === WORLDSHELL_PRESET_ID) return true;
    if (!transition.active) return false;
    return Math.round(Number(transition.from)) === WORLDSHELL_PRESET_ID
      || Math.round(Number(transition.to)) === WORLDSHELL_PRESET_ID;
  }
  function prepareWorldshellFrame(now, t, activePreset, transition = {}) {
    const visible = worldshellVisible(activePreset, transition);
    const qualityValue = getQuality?.() || 0;
    if (!visible) {
      worldshellFrameState = null;
      worldshellLastTrackTime = null;
      worldshellResonance.step({
        presetId: activePreset,
        quality: qualityValue,
        nowMs: now,
        frameToken: now
      });
      return null;
    }

    const musicAwareState = getMusicAwareState?.() || {};
    const lookaheadState = getLookaheadState?.() || {};
    const currentAnalysis = lookaheadState.current || {};
    const audioFeatures = getAudioFeatures?.() || {};
    const smooth = getSmooth?.() || {};
    const suppliedTrackTime = Number(getTrackTime?.());
    const currentTime = Number.isFinite(suppliedTrackTime) ? Math.max(0, suppliedTrackTime) : Math.max(0, t);
    const trackDeltaBeforeReset = worldshellLastTrackTime == null
      ? 0
      : currentTime - worldshellLastTrackTime;
    const renderClockRewound = Number.isFinite(worldshellLastVisibleAt) && now < worldshellLastVisibleAt - 1;
    const forwardSeek = trackDeltaBeforeReset > 0.35;
    const presetEntered = renderClockRewound || forwardSeek || now - worldshellLastVisibleAt > 500;
    if (presetEntered) worldshellEntryToken += 1;
    worldshellLastVisibleAt = now;
    const suppliedAbsoluteBeat = Number(musicAwareState.absoluteBeat);
    const hasAnalysedBeatGrid = Boolean(lookaheadState.ready)
      || (Number.isFinite(suppliedAbsoluteBeat) && suppliedAbsoluteBeat > 0);
    const absoluteBeat = hasAnalysedBeatGrid ? suppliedAbsoluteBeat : currentTime * 2.4;
    const beatPhase = hasAnalysedBeatGrid
      ? musicAwareState.beatPhase
      : absoluteBeat - Math.floor(absoluteBeat);
    worldshellChoreography = computeWorldshellChoreographyState({
      previousState: worldshellChoreography,
      currentTime,
      trackProgress: getTrackProgress?.() || 0,
      presetActive: true,
      presetEntered,
      entryToken: worldshellEntryToken,
      beatInfo: {
        absoluteBeat,
        beatIndex: Math.floor(absoluteBeat),
        beatPhase
      },
      phraseInfo: {
        progress: musicAwareState.phraseProgress,
        pulse: musicAwareState.phrasePulse,
        nextPhraseSeconds: musicAwareState.nextPhraseSeconds
      },
      musicAwareState,
      lookaheadState,
      audioFeatures,
      analysis: currentAnalysis,
      bands: smooth
    });
    worldshellFrameState = worldshellChoreography;
    if (worldshellChoreography.resetReason !== "none") {
      worldshellResonance.reset();
    }
    const trackDelta = worldshellLastTrackTime == null || presetEntered
      ? 1 / 60
      : currentTime - worldshellLastTrackTime;
    worldshellLastTrackTime = currentTime;
    worldshellResonance.step({
      presetId: WORLDSHELL_PRESET_ID,
      quality: qualityValue,
      nowMs: now,
      frameToken: currentTime,
      deltaSeconds: Math.max(1 / 240, Math.min(1 / 20, trackDelta > 0 ? trackDelta : 1 / 240)),
      time: currentTime,
      kick: smooth.kick,
      kickPulse: Math.max(audioFeatures.kickPulse || 0, worldshellChoreography.beatEnvelope || 0),
      beatStrength: currentAnalysis.beatStrength || 0,
      drop: worldshellChoreography.impact || 0,
      dropDetected: audioFeatures.dropDetected || 0,
      sectionChange: worldshellChoreography.sectionMorph === 0 ? 1 : 0,
      breakdownInfluence: worldshellChoreography.breakdownInfluence,
      absoluteBeat,
      bass: smooth.bass,
      bassRel: audioFeatures.bassRel,
      density: currentAnalysis.density || musicAwareState.futureDensity || 0,
      flux: currentAnalysis.flux || 0,
      highs: smooth.highs,
      trackProgress: getTrackProgress?.() || 0
    });
    return worldshellFrameState;
  }
  function ensurePipelineWarmTargets(size = 64) {
    if (pipelineWarmTargets) return pipelineWarmTargets;
    pipelineWarmTargets = [createRenderTarget(gl(), size, size), createRenderTarget(gl(), size, size)];
    return pipelineWarmTargets;
  }
  function releasePipelineWarmTargets() {
    if (!pipelineWarmTargets) return;
    for (const target of pipelineWarmTargets) deleteRenderTarget(gl(), target);
    pipelineWarmTargets = null;
  }
  function ensureCrossFadeProgram() {
    if (!crossFadeProgram) crossFadeProgram = program?.(crossFadeFragmentSource);
    return crossFadeProgram;
  }
  function renderGeometryPresetToTarget(presetId, targetFbo, width, height, now) {
    if (isFiddleheadPreset?.(presetId)) {
      renderFiddleheadGeometry?.(now, targetFbo, width, height);
    } else if (isPineconePreset?.(presetId)) {
      renderPinecone3D?.(now, targetFbo, width, height, presetId);
    } else if (isQuantumFluidPreset?.(presetId)) {
      renderQuantumFluid3D?.(now, targetFbo, width, height, presetId);
    } else if (isKleinianCoralCathedralPreset?.(presetId)) {
      renderKleinianCoralCathedral?.(now, targetFbo, width, height);
    } else if (isBloodCellNebulaPreset?.(presetId)) {
      renderBloodCellNebula?.(now, targetFbo, width, height);
    }
  }
  function renderPresetToTarget(target, presetId, previousTexture, transitionPhaseValue, now, t) {
    const { width, height } = renderSurface.renderSize();
    if (isSpecialGeometryPreset?.(presetId)) {
      renderGeometryPresetToTarget(presetId, target.fb, width, height, now);
    } else {
      const context = gl();
      context.disable(context.DEPTH_TEST);
      context.depthMask(false);
      context.colorMask(true, true, true, true);
      drawShaderPresetToTarget(target, presetId, previousTexture, transitionPhaseValue, now, t);
    }
    return target.tex;
  }
  function ensureTransitionGeometryTarget(width, height) {
    transitionGeometryTarget = ensureSizedRenderTargetWithDepth(gl(), transitionGeometryTarget, width, height);
  }
  function ensureTransitionGeometryTargetAux(width, height) {
    transitionGeometryTargetAux = ensureSizedRenderTargetWithDepth(gl(), transitionGeometryTargetAux, width, height);
  }
  function animationStartedAt(presetValue) {
    return presetAnimationStartedAt(presetValue, getTransition?.(),
      getActivePreset?.(), getActivePresetStartedAt?.());
  }
  function shaderPresetTime(now, presetValue) {
    const clock = getOfflineClock?.();
    if (clock?.presetTimes && Number.isFinite(clock.presetTimes[presetValue])) return clock.presetTimes[presetValue];
    return Math.max(0, (now - animationStartedAt(presetValue)) * 0.001);
  }
  function setRenderProgramUniforms(programToUse, now, t, presetValue, transitionPhaseValue, previousTexture) {
    const context = gl();
    const { width: renderWidth, height: renderHeight } = renderSurface.renderSize();
    const transition = getTransition?.() || {};
    const smooth = getSmooth?.() || {};
    const musicAwareState = getMusicAwareState?.() || {};
    const lookaheadState = getLookaheadState?.() || {};
    const currentAnalysis = lookaheadState.current || {};
    const shortAnalysis = lookaheadState.short || currentAnalysis;
    const mediumAnalysis = lookaheadState.medium || shortAnalysis;
    const longAnalysis = lookaheadState.long || mediumAnalysis;
    const audioFeatures = getAudioFeatures?.() || {};
    const isWorldshell = Math.round(Number(presetValue)) === WORLDSHELL_PRESET_ID;
    const isSelfContainedPreset = isWorldshell;
    // Self-contained shader worlds own their visual language entirely in
    // shader code. Avoid needlessly allocating/binding legacy artwork each
    // frame for those presets.
    const assets = isSelfContainedPreset ? null : textureAssets?.();
    setRenderProgram?.(programToUse);
    setAttribs?.(programToUse);
    context.activeTexture(context.TEXTURE0);
    context.bindTexture(context.TEXTURE_2D, previousTexture);
    context.uniform1i(getCachedUniformLocation(context, programToUse, "previousFrame"), 0);
    if (!isSelfContainedPreset) {
      context.activeTexture(context.TEXTURE1);
      context.bindTexture(context.TEXTURE_2D, assets?.ensureOmTexture?.() || previousTexture);
      context.uniform1i(getCachedUniformLocation(context, programToUse, "omTexture"), 1);
      context.activeTexture(context.TEXTURE3);
      context.bindTexture(context.TEXTURE_2D, assets?.ensureFlowerTexture?.() || previousTexture);
      context.uniform1i(getCachedUniformLocation(context, programToUse, "flowerTexture"), 3);
      // Geode textures
      context.activeTexture(context.TEXTURE2);
      context.bindTexture(context.TEXTURE_2D, assets?.ensurePresetShaderTexture?.(presetValue) || previousTexture);
      context.uniform1i(getCachedUniformLocation(context, programToUse, "presetBackground"), 2);
    }
    context.uniform2f(getCachedUniformLocation(context, programToUse, "resolution"), renderWidth, renderHeight);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "time"), t);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "kick"), smooth.kick);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "bass"), smooth.bass);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "mids"), smooth.mids);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "highs"), smooth.highs);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "brightness"), smooth.brightness);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "level"), smooth.level);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_slowLevel"), getSlowLevel?.() || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_slowBass"), getSlowBass?.() || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_wavePhase"), getWavePhaseAccum?.() || 0);
    const scionBiofeedback = getScionBiofeedback?.() || {};
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_scionPresence"), scionBiofeedback.presence || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_scionSignal"), scionBiofeedback.signal || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_scionSlow"), scionBiofeedback.slow || 0);
    const videoBackgroundState = getVideoBackgroundState?.() || {};
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_evoStage"), videoBackgroundState.stage || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_evoLocalTime"), videoBackgroundState.localTime || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "u_evoStageDuration"), videoBackgroundState.duration || 10);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "sensitivity"), getSensitivity?.() || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "preset"), presetValue);
    const qualityValue = warmQualityOverride ?? getQuality?.() ?? 0;
    context.uniform1f(
      getCachedUniformLocation(context, programToUse, "quality"),
      qualityValue
    );
    context.uniform1f(getCachedUniformLocation(context, programToUse, "transitionPhase"), transitionPhaseValue);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "transitionSeed"), transition.seed || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "transitionToPreset"), transition.active ? transition.to : presetValue);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "transitionSwapAt"), transition.active ? (transition.swapAt ?? 0.5) : 0.5);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "futureEnergy"), musicAwareState.futureEnergy || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "futureBrightness"), musicAwareState.futureBrightness || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "futureDensity"), musicAwareState.futureDensity || 0);
    if (isWorldshell) {
      context.uniform1f(getCachedUniformLocation(context, programToUse, "analysisPeak"), currentAnalysis.peak || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "analysisCrest"), currentAnalysis.crest || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "analysisFlux"), currentAnalysis.flux || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "analysisBeatStrength"), currentAnalysis.beatStrength || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "analysisDensity"), currentAnalysis.density || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "analysisSectionProbability"), currentAnalysis.sectionProbability || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureEnergyShort"), shortAnalysis.energy || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureEnergyMedium"), mediumAnalysis.energy || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureEnergyLong"), longAnalysis.energy || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureBrightnessShort"), shortAnalysis.brightness || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureBrightnessMedium"), mediumAnalysis.brightness || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureBrightnessLong"), longAnalysis.brightness || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureDensityShort"), shortAnalysis.density || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureDensityMedium"), mediumAnalysis.density || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "futureDensityLong"), longAnalysis.density || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "upcomingDropState"), musicAwareState.upcomingDrop || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "upcomingBreakdownState"), musicAwareState.upcomingBreakdown || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "upcomingBuildState"), musicAwareState.upcomingBuild || 0);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "nextPhraseSeconds"), musicAwareState.nextPhraseSeconds || 0);
      const choreography = worldshellFrameState || neutralWorldshellChoreography;
      for (const [name, field] of WORLDSHELL_CHOREOGRAPHY_UNIFORM_FIELDS) {
        const rawValue = Number(choreography[field]) || 0;
        const value = name === "worldshellSectionSeedFrom" || name === "worldshellSectionSeed"
          ? Math.floor(Math.max(0, Math.min(1, rawValue)) * 4095 + 0.5)
          : rawValue;
        context.uniform1f(getCachedUniformLocation(context, programToUse, name), value);
      }
      worldshellResonance.bind(programToUse, {
        fallbackTexture: previousTexture,
        presetId: presetValue,
        quality: qualityValue
      });
    }
    context.uniform1f(getCachedUniformLocation(context, programToUse, "sectionChange"), musicAwareState.sectionChange || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "energyTrend"), musicAwareState.energyTrend || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "breakdownState"), musicAwareState.breakdown || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "mainRiffState"), musicAwareState.mainRiff || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "dropState"), musicAwareState.drop || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "buildUpState"), musicAwareState.buildUp || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "calmState"), musicAwareState.calm || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "highEnergyState"), musicAwareState.highEnergy || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "adaptiveIntensity"), musicAwareState.adaptiveIntensity || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "phrasePulse"), musicAwareState.phrasePulse || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "phraseProgress"), musicAwareState.phraseProgress || 0);
    const choreographyStateForBeat = isWorldshell ? worldshellFrameState : null;
    context.uniform1f(
      getCachedUniformLocation(context, programToUse, "beatPhase"),
      choreographyStateForBeat
        ? choreographyStateForBeat.absoluteBeat - Math.floor(choreographyStateForBeat.absoluteBeat)
        : musicAwareState.beatPhase || 0
    );
    context.uniform1f(
      getCachedUniformLocation(context, programToUse, "absoluteBeat"),
      choreographyStateForBeat ? choreographyStateForBeat.absoluteBeat : musicAwareState.absoluteBeat || (t * 2.4)
    );
    context.uniform1f(getCachedUniformLocation(context, programToUse, "transitionStyle"), transition.style || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "transitionSide"), transition.active && transition.swapped ? 1 : 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "presetTime"), shaderPresetTime(now, presetValue));
    if (Math.round(Number(presetValue)) === MANDELBROT_NEWTON_PRESET_ID) {
      const journey = mandelbrotNewtonDirector.sample({
        time: shaderPresetTime(now, presetValue), trackTime: getTrackTime?.(),
        analysis: getAnalysisTimeline?.(), entryToken: animationStartedAt(presetValue),
        offline: Boolean(getOfflineClock?.()), music: musicAwareState,
        warmup: warmQualityOverride !== null
      });
      context.uniform2f(getCachedUniformLocation(context, programToUse, "mnmJourney"), journey.morph, journey.framing);
      context.uniform1f(getCachedUniformLocation(context, programToUse, "presetTime"), journey.time);
    }
    if (Math.round(Number(presetValue)) === FERROFLUID_ORACLE_ID && warmQualityOverride === null) {
      updateFerrofluidField(ferrofluidField, now * .001, {
        audio: audioFeatures, smooth, music: musicAwareState, lookahead: lookaheadState,
        slowLevel: getSlowLevel?.() || 0, slowBass: getSlowBass?.() || 0,
        trackTime: getTrackTime?.()
      });
      bindFerrofluidField(context, programToUse, ferrofluidField, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === SPORE_MEMORY_PRESET_ID) {
      bindSporeMemoryMycelium(context, programToUse, shaderPresetTime(now, presetValue), {
        mids: smooth.mids,
        bass: getSlowBass?.() || smooth.bass,
        energy: audioFeatures.globalEnergy,
        kick: audioFeatures.kickPulse
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === SACRED_GEOMETRY_PRESET_ID && warmQualityOverride === null) {
      bindSacredGeometryRotation(context, programToUse, t, musicAwareState, audioFeatures, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === CRYSTAL_RESONANCE_PRESET_ID && warmQualityOverride === null) {
      // Crystal Resonance's director: beat-aligned Chladni mode schedule and plate resonance.
      bindCrystalResonanceDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === LIVING_FIREPIT_PRESET_ID) {
      // Living Firepit's director: camera, choreography, hero events and constellation segments.
      bindLivingFirepitDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, lookahead: lookaheadState,
        slowLevel: getSlowLevel?.() || 0, slowBass: getSlowBass?.() || 0
      }, getCachedUniformLocation, { width: renderWidth, height: renderHeight, quality: qualityValue });
    }
    if (Math.round(Number(presetValue)) === TESSERACT_UNFOLDING_PRESET_ID && warmQualityOverride === null) {
      // Tesseract Unfolding's director: the machine's SO(4) rotation, the journey camera, apertures,
      // nested frames and light pulses.
      bindTesseractUnfoldingDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, lookahead: lookaheadState, tempo: getForgeTempo?.()
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === TWISTOR_SPACE_MANIFOLD_PRESET_ID && warmQualityOverride === null) {
      // Twistor Space Manifold's director: smooth fold morph, bass breathing, the camera journey
      // and kick pulses travelling through the branches.
      bindTwistorSpaceManifoldDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, tempo: getForgeTempo?.()
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === SPIN_NETWORK_MATRIX_PRESET_ID && warmQualityOverride === null) {
      // Spin Network Matrix's director: the corridor-and-chamber journey, lattice breathing and
      // twist, excitation waves through the conduits, palette and structural evolution.
      bindSpinNetworkMatrixDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, tempo: getForgeTempo?.()
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === TOROIDAL_MERKABA_PRESET_ID && warmQualityOverride === null) {
      // Toroidal Merkaba Field's director: the camera through the apertures and halls, build
      // slowdowns and drop surges, fold breathing, cascades down and up the recursive levels, palette.
      bindToroidalMerkabaDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, tempo: getForgeTempo?.()
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === FRACTAL_LIGHTNING_CATHEDRAL_PRESET_ID && warmQualityOverride === null) {
      // Fractal Lightning Cathedral's director: electrical events through the network (kick
      // impulses, breakdown solitaries, converging build currents, the drop's discharge), pier
      // charge, branch reach, colour and the accumulated camera journey.
      bindFractalLightningCathedralDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, tempo: getForgeTempo?.(), lookahead: lookaheadState,
        slowLevel: getSlowLevel?.() || 0, slowBass: getSlowBass?.() || 0
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === HYPERBOLIC_CARPET_PRESET_ID && warmQualityOverride === null) {
      // Hyperbolic Carpet's director: the slow float beneath the canopy, light travelling through
      // the tessellation's generations and contours (kicks, build rolls, breakdown tides, the drop
      // cascade), bass tension, mid flow, treble shimmer and the phrase crossfade.
      bindHyperbolicCarpetDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, tempo: getForgeTempo?.()
      }, getCachedUniformLocation);
    }
    if (Math.round(Number(presetValue)) === CHAOTIC_BUTTERFLY_PRESET_ID && warmQualityOverride === null) {
      // Chaotic Butterfly Tunnels' director: the giant wings' stroke, posture and travelling wave,
      // the pre-drop breath and the drop's unfurling, vein light, swarm and journey clocks.
      // Offline export advances it in prepareOfflineFrame (deterministic replay) and only binds here.
      bindChaoticButterflyDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, tempo: getForgeTempo?.()
      }, getCachedUniformLocation, { offline: Boolean(getOfflineClock?.()) });
    }
    if (Math.round(Number(presetValue)) === FRACTAL_BREAKER_PRESET_ID && warmQualityOverride === null) {
      // Fractal Breaker's director: the camera's passage past the inversion poles (the emergent
      // wave, timed to the Drop Map), music-paced structural clocks, kick and treble light.
      // Offline export advances it in prepareOfflineFrame (deterministic replay) and only binds here.
      bindFractalBreakerDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState
      }, getCachedUniformLocation, { offline: Boolean(getOfflineClock?.()) });
    }
    if (Math.round(Number(presetValue)) === WOODSTOCK_PRESET_ID && warmQualityOverride === null) {
      bindWoodstockDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState, tempo: getForgeTempo?.(),
        lookahead: lookaheadState, trackTime: getTrackTime?.()
      }, getCachedUniformLocation, { offline: Boolean(getOfflineClock?.()), entryToken: animationStartedAt(presetValue) });
    }
    if (Math.round(Number(presetValue)) === IFS_MATRIX_PRESET_ID && warmQualityOverride === null) {
      // Audio-Reactive IFS Matrix's director: the corridor journey through the cube lattice,
      // breathing groups, travelling wave fronts, palette and the cosmic dice hero.
      // Offline export advances it in prepareOfflineFrame (deterministic replay) and only binds here.
      bindIfsMatrixDirector(context, programToUse, shaderPresetTime(now, presetValue), {
        audio: audioFeatures, smooth, music: musicAwareState
      }, getCachedUniformLocation, { offline: Boolean(getOfflineClock?.()) });
    }
    if (Math.round(Number(presetValue)) === 369) {
      // Earthstar: reuse replayable Player envelopes, beat grid and Drop Map.
      // No persistent preset state to leak across transitions, seeks or re-entry.
      context.uniform4f(getCachedUniformLocation(context, programToUse, "erStructure"),
        audioFeatures.bassSlow || 0, audioFeatures.midSlow || 0,
        audioFeatures.trebleSlow || 0, audioFeatures.globalEnergySlow || 0);
      const mapped = Number(musicAwareState.dropKnown) > 0.5;
      const tempo = getForgeTempo?.();
      const bpm = Number(tempo?.bpm) || Number(musicAwareState.bpm) || 0;
      context.uniform4f(getCachedUniformLocation(context, programToUse, "erDrop"),
        mapped ? Math.max(0, musicAwareState.dropAge ?? 64) : 64,
        mapped ? (musicAwareState.dropLastStrength || 0) : 0,
        mapped ? (musicAwareState.dropLeadIn || 0) : 0,
        mapped ? (musicAwareState.dropNextStrength || 0) : 0);
      context.uniform4f(getCachedUniformLocation(context, programToUse, "erTiming"),
        Math.max(1, Math.min(4, bpm / 60)),
        bpm > 0 && Number(musicAwareState.absoluteBeat) > 0 ? 1 : 0, mapped ? 1 : 0, 1);
    }
    if (Math.round(Number(presetValue)) === 380) {
      // Stateless preset-local binding: live and export already share these
      // envelopes. Seeking samples the existing replay; no additional director.
      context.uniform4f(getCachedUniformLocation(context, programToUse, "tkrStructure"),
        audioFeatures.bassSlow || 0, audioFeatures.midSlow || 0,
        audioFeatures.trebleSlow || 0, audioFeatures.globalEnergySlow || 0);
      const mapped = Number(musicAwareState.dropKnown) > 0.5;
      context.uniform4f(getCachedUniformLocation(context, programToUse, "tkrDrop"),
        mapped ? (musicAwareState.dropAge ?? 64) : 64,
        mapped ? (musicAwareState.dropLastStrength || 0) : 0,
        mapped ? (musicAwareState.dropLeadIn || 0) : 0,
        mapped ? (musicAwareState.dropNextStrength || 0) : 0);
    }
    context.uniform1f(getCachedUniformLocation(context, programToUse, "trackProgress"), getTrackProgress?.() || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "bassRel"), audioFeatures.bassRel || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "midRel"), audioFeatures.midRel || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "trebleRel"), audioFeatures.trebleRel || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "kickPulse"), audioFeatures.kickPulse || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "globalEnergy"), audioFeatures.globalEnergy || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "dropDetected"), audioFeatures.dropDetected || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "omTextureReady"), assets?.omReady?.() || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "flowerTextureReady"), assets?.flowerReady?.() || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "presetBackgroundReady"), assets?.presetShaderTextureReady?.(presetValue) || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "knotOrbitPhase"), getKnotOrbitPhase?.() || 0);
    context.uniform1f(getCachedUniformLocation(context, programToUse, "feedbackStep"), Math.max(0.01, Math.min(4.0, getFeedbackStep?.() || 1)));
    waveformSamples.fill(0);
    worldshellWaveformSamples.fill(128);
    const timeData = getTimeData?.();
    if (timeData && timeData.length > 0) {
      const step = timeData.length / 64;
      for (let i = 0; i < 64; i += 1) {
        const idx = Math.min(timeData.length - 1, Math.floor(i * step));
        const sample = timeData[idx];
        waveformSamples[i] = (sample - 128) / 128.0;
        worldshellWaveformSamples[i] = sample;
      }
    }
    if (Math.round(Number(presetValue)) === WORLDSHELL_PRESET_ID) {
      let samplesChanged = worldshellWaveformTextures.length === 0;
      for (let i = 0; i < 64 && !samplesChanged; i += 1) {
        samplesChanged = worldshellWaveformSamples[i] !== lastQueuedWorldshellWaveformSamples[i];
      }
      bindWorldshellWaveformTexture(context, programToUse, samplesChanged);
    } else {
      const waveformLocation = getCachedUniformLocation(context, programToUse, "u_waveform");
      if (waveformLocation) context.uniform1fv(waveformLocation, waveformSamples);
    }
  }
  function drawShaderPresetToTarget(target, presetValue, previousTexture, transitionPhaseValue, now, t) {
    const context = gl();
    const { width: renderWidth, height: renderHeight } = renderSurface.renderSize();
    const qualityValue = warmQualityOverride ?? getQuality?.() ?? 0;
    const width = target.width || renderWidth;
    const height = target.height || renderHeight;
    if (Number(presetValue) === APOLLONIAN_PHYSARUM_GENESIS_ID && warmQualityOverride === null) {
      forgeHybrid.render({
        target, width, height, now,
        tempo: getForgeTempo?.(),
        playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {},
        audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {},
        lookahead: getLookaheadState?.() || {}
      });
      return;
    }
    if (Number(presetValue) === STINKHORN_ID && warmQualityOverride === null) {
      stinkhorn.render({target,width,height,now,quality:qualityValue,playing:getForgeShouldPlay?.() !== false,
        tempo:getForgeTempo?.(),music:getMusicAwareState?.() || {},audio:getAudioFeatures?.() || {},
        smooth:getSmooth?.() || {},lookahead:getLookaheadState?.() || {}});
      return;
    }
    if (Number(presetValue) === HELIX_TUNNEL_ID && warmQualityOverride === null) {
      helixTunnel.render({
        target, width, height, now, quality: qualityValue,
        tempo: getForgeTempo?.(), playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {}, audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {}, lookahead: getLookaheadState?.() || {}
      });
      return;
    }
    if (Number(presetValue) === CLIFFORD_METAMORPHOSIS_ID && warmQualityOverride === null) {
      cliffordMetamorphosis.render({
        target, width, height, now, quality: qualityValue,
        tempo: getForgeTempo?.(), playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {}, audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {}, lookahead: getLookaheadState?.() || {}
      });
      return;
    }
    if (Number(presetValue) === HYPERGEOMETRY_ID && warmQualityOverride === null) {
      hypergeometry.render({
        target, width, height, now, quality: qualityValue,
        tempo: getForgeTempo?.(), playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {}, audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {}, lookahead: getLookaheadState?.() || {}
      });
      return;
    }
    if (Number(presetValue) === IMPOSSIBLE_APERTURES_ID && warmQualityOverride === null) {
      impossibleApertures.render({
        target, width, height, now, quality: qualityValue,
        tempo: getForgeTempo?.(), playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {}, audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {}, lookahead: getLookaheadState?.() || {}
      });
      return;
    }
    if (Number(presetValue) === DUOVERSE_HD_ID && warmQualityOverride === null) {
      duoverse.render({
        target, width, height, now,
        tempo: getForgeTempo?.(),
        playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {},
        audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {}
      });
      return;
    }
    if (Number(presetValue) === NEWTONS_LAW_ID && warmQualityOverride === null) {
      newtonLaw.render({
        target, width, height, now,
        tempo: getForgeTempo?.(),
        playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {},
        audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {}
      });
      return;
    }
    if (Number(presetValue) === ARTIFICIAL_CONSCIOUSNESS_ID && warmQualityOverride === null) {
      artificialConsciousness.render({
        target, width, height, now,
        tempo: getForgeTempo?.(),
        playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {},
        audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {},
        spectrum: getFrequencyData?.() || null
      });
      return;
    }
    if (Number(presetValue) === NEWTON_BASIN_DESCENT_ID && warmQualityOverride === null) {
      newtonBasin.render({
        target, width, height, now,
        tempo: getForgeTempo?.(),
        playing: getForgeShouldPlay?.() !== false,
        music: getMusicAwareState?.() || {},
        audio: getAudioFeatures?.() || {},
        smooth: getSmooth?.() || {}
      });
      return;
    }
    context.bindFramebuffer(context.FRAMEBUFFER, target.fb);
    context.viewport(0, 0, width, height);
    const programToUse = renderProgramForPreset?.(presetValue, qualityValue);
    setRenderProgramUniforms(programToUse, now, t, presetValue, transitionPhaseValue, previousTexture);
    context.drawArrays(context.TRIANGLES, 0, 3);
  }
  function blitTextureToCanvas(texture, blitProgram) {
    const context = gl();
    const targetCanvas = canvas();
    context.bindFramebuffer(context.FRAMEBUFFER, null);
    context.viewport(0, 0, targetCanvas.width, targetCanvas.height);
    setAttribs?.(blitProgram);
    context.activeTexture(context.TEXTURE0);
    context.bindTexture(context.TEXTURE_2D, texture);
    context.uniform1i(getCachedUniformLocation(context, blitProgram, "frame"), 0);
    context.drawArrays(context.TRIANGLES, 0, 3);
  }
  function presetBackgroundCompositor() {
    if (!backgroundCompositor) {
      backgroundCompositor = createVisualBackgroundCompositor({
        getGl,
        getCanvas,
        program,
        setAttribs,
        textureAssets,
        fallbackBlit: blitTextureToCanvas
      });
    }
    return backgroundCompositor;
  }
  function warmCrossFadePipeline() {
    const context = gl();
    const warmTargets = ensurePipelineWarmTargets();
    const transitionProgram = ensureCrossFadeProgram();
    context.bindFramebuffer(context.FRAMEBUFFER, warmTargets[0].fb);
    context.viewport(0, 0, 64, 64);
    setAttribs?.(transitionProgram);
    context.activeTexture(context.TEXTURE0);
    context.bindTexture(context.TEXTURE_2D, warmTargets[1].tex);
    context.uniform1i(getCachedUniformLocation(context, transitionProgram, "fromFrame"), 0);
    context.activeTexture(context.TEXTURE1);
    context.bindTexture(context.TEXTURE_2D, warmTargets[1].tex);
    context.uniform1i(getCachedUniformLocation(context, transitionProgram, "toFrame"), 1);
    context.uniform1f(getCachedUniformLocation(context, transitionProgram, "mixRatio"), 0.5);
    context.uniform2f(getCachedUniformLocation(context, transitionProgram, "sourceResolution"), 64, 64);
    context.uniform1f(getCachedUniformLocation(context, transitionProgram, "sharpenStrength"), 0);
    context.drawArrays(context.TRIANGLES, 0, 3);
    context.finish?.();
  }
  async function warmPresetPipelines(presetIds, {
    qualities = [0, 1],
    onProgress = null,
    releaseTargets = true,
    fullResolutionPresetIds = []
  } = {}) {
    const context = gl();
    const candidates = Array.from(new Set((presetIds || []).map(Number)))
      .filter((id) => runtimeAllowsPreset(id))
      .filter((presetId) => !isSpecialGeometryPreset?.(presetId));
    const work = [];
    for (const qualityValue of qualities) {
      for (const presetId of candidates) {
        const key = presetPipelineKey(presetId, qualityValue);
        if (!warmedPresetPipelines.has(key)) work.push({ presetId, qualityValue, key });
      }
    }
    if (!work.length) return { warmed: 0, skipped: candidates.length * qualities.length };
    const warmTargets = ensurePipelineWarmTargets();
    const fullResolutionPresets = new Set((fullResolutionPresetIds || []).map(Number));
    const liveTargets = renderSurface.hasBuffers?.() ? renderSurface.buffers() : null;
    const previousFramebuffer = context.getParameter(context.FRAMEBUFFER_BINDING);
    const previousViewport = context.getParameter(context.VIEWPORT);
    let warmed = 0;
    try {
      warmCrossFadePipeline();
      for (let index = 0; index < work.length; index += 1) {
        const item = work[index];
        if (!isPresetProgramReady?.(item.presetId, item.qualityValue)) continue;
        const targetIndex = index % 2;
        const startedAt = performance.now();
        warmQualityOverride = item.qualityValue;
        if (item.presetId === WORLDSHELL_PRESET_ID && item.qualityValue > 0.5) {
          worldshellResonance.warm();
        }
        const targetPair = liveTargets
          && item.qualityValue > 0.5
          && fullResolutionPresets.has(item.presetId)
          ? liveTargets
          : warmTargets;
        // Runtime presets draw their own programs (the registry entry is only a stub): build and
        // draw them now, so entering the preset never compiles shaders on a live frame.
        if (item.presetId === CLIFFORD_METAMORPHOSIS_ID) cliffordMetamorphosis.warm(targetPair[targetIndex]);
        if (item.presetId === IMPOSSIBLE_APERTURES_ID) impossibleApertures.warm(targetPair[targetIndex]);
        if (item.presetId === HYPERGEOMETRY_ID) hypergeometry.warm(targetPair[targetIndex]);
        drawShaderPresetToTarget(
          targetPair[targetIndex],
          item.presetId,
          targetPair[1 - targetIndex].tex,
          0,
          performance.now(),
          performance.now() * 0.001
        );
        context.finish?.();
        warmedPresetPipelines.add(item.key);
        warmed += 1;
        const elapsedMs = performance.now() - startedAt;
        if (diagnosticsEnabled?.() && elapsedMs >= 20) {
          console.warn(`[TransitionDiag] event=preset_pipeline_warm preset=${item.presetId} quality=${item.qualityValue} elapsed_ms=${elapsedMs.toFixed(1)}`);
        }
        onProgress?.((index + 1) / work.length, item.presetId, item.qualityValue);
        const isPrewarming = new URLSearchParams(window.location.search).get("prewarm") === "1";
        if (index % 2 === 1) {
          if (isPrewarming && index % 20 !== 19) {
            await Promise.resolve();
          } else {
            await new Promise((resolve) => window.setTimeout(resolve, 0));
          }
        }
      }
    } finally {
      warmQualityOverride = null;
      context.bindFramebuffer(context.FRAMEBUFFER, previousFramebuffer);
      context.viewport(previousViewport[0], previousViewport[1], previousViewport[2], previousViewport[3]);
      if (releaseTargets) releasePipelineWarmTargets();
    }
    return { warmed, skipped: work.length - warmed };
  }
  function prepareTransitionInfrastructure() {
    if (!renderSurface.hasBuffers()) return false;
    const { width, height } = renderSurface.renderSize();
    ensureCrossFadeProgram();
    ensureTransitionGeometryTargetAux(width, height);
    ensureTransitionGeometryTarget(width, height);
    return true;
  }
  function queuePresetPreflight(presetId, delay = 120) {
    const preset = Number(presetId);
    if (!runtimeAllowsPreset(preset) || isSpecialGeometryPreset?.(preset)) return;
    const key = presetPipelineKey(preset, getQuality?.() || 0);
    if (warmedPresetPipelines.has(key)) return;
    queuedPresetPreflight = preset;
    window.clearTimeout(presetPreflightTimer);
    presetPreflightTimer = window.setTimeout(() => {
      if (getTransition?.()?.active || queuedPresetPreflight !== preset) {
        queuePresetPreflight(preset, 300);
        return;
      }
      queuedPresetPreflight = null;
      warmPresetPipelines([preset], { qualities: [getQuality?.() || 0] }).catch((error) => {
        console.warn("Preset pipeline preflight failed:", error);
      });
    }, delay);
  }
  function blitTextureToCanvasWithPreset(texture, presetValue, blitProgram) {
    if (Number(presetValue) === APOLLONIAN_PHYSARUM_GENESIS_ID || Number(presetValue) === DUOVERSE_HD_ID
        || Number(presetValue) === NEWTON_BASIN_DESCENT_ID || Number(presetValue) === NEWTONS_LAW_ID
        || Number(presetValue) === ARTIFICIAL_CONSCIOUSNESS_ID || Number(presetValue) === CLIFFORD_METAMORPHOSIS_ID
        || Number(presetValue) === IMPOSSIBLE_APERTURES_ID || Number(presetValue) === HYPERGEOMETRY_ID) {
      blitTextureToCanvas(texture, blitProgram);
      return;
    }
    const { width, height } = renderSurface.renderSize();
    const targetCanvas = canvas();
    const scale = Math.min(width / Math.max(1, targetCanvas.width), height / Math.max(1, targetCanvas.height));
    const sharpenStrength = 0;
    presetBackgroundCompositor().composite(texture, presetValue, blitProgram, {
      sharpenStrength,
      edgeAntialias: Number(presetValue) === 297,
      sourceWidth: width,
      sourceHeight: height
    });
  }
  // Optional display-only mathematical field. It never writes a feedback FBO.
  function presentPresetField(texture, presetValue, now, t, opacity = 1) {
    const fieldProgram = renderProgramForPreset?.(presetValue, getQuality?.() || 0)?.presentationProgram;
    if (!fieldProgram || opacity <= 0.001) return;
    const context = gl();
    const targetCanvas = canvas();
    const blendEnabled = context.isEnabled(context.BLEND);
    const factors = [context.BLEND_SRC_RGB, context.BLEND_DST_RGB, context.BLEND_SRC_ALPHA, context.BLEND_DST_ALPHA]
      .map((name) => context.getParameter(name));
    const equations = [context.getParameter(context.BLEND_EQUATION_RGB), context.getParameter(context.BLEND_EQUATION_ALPHA)];
    const ditherEnabled = context.isEnabled(context.DITHER);
    try {
      // Display-only fields do not consume artwork, waveform textures or the
      // hero's feedback/transition uniforms. Avoid rebinding that full pipeline.
      const smooth = getSmooth?.() || {};
      const features = getAudioFeatures?.() || {};
      const music = getMusicAwareState?.() || {};
      const inputs = {
        time: t, sensitivity: getSensitivity?.() || 0,
        level: smooth.level || 0, mids: smooth.mids || 0, highs: smooth.highs || 0,
        brightness: smooth.brightness || 0, u_slowLevel: getSlowLevel?.() || 0,
        globalEnergy: features.globalEnergy || 0, kickPulse: features.kickPulse || 0,
        beatPhase: music.beatPhase || 0, dropDetected: features.dropDetected || 0,
        dropState: music.drop || 0
      };
      function bindField(programToUse) {
        setRenderProgram?.(programToUse);
        setAttribs?.(programToUse);
        context.activeTexture(context.TEXTURE0);
        context.bindTexture(context.TEXTURE_2D, texture);
        context.uniform1i(getCachedUniformLocation(context, programToUse, "previousFrame"), 0);
        for (const [name, value] of Object.entries(inputs)) {
          context.uniform1f(getCachedUniformLocation(context, programToUse, name), value);
        }
        context.uniform2f(getCachedUniformLocation(context, programToUse, "resolution"), targetCanvas.width, targetCanvas.height);
        context.uniform1f(getCachedUniformLocation(context, programToUse, "presentationOpacity"), 1);
      }
      let density = presentationDensityCache.get(fieldProgram);
      if (fieldProgram.densityProgram) {
        if (!density || density.width !== targetCanvas.width || density.height !== targetCanvas.height) {
          if (density) deleteRenderTarget(context, density.target);
          density = { target: createRenderTarget(context, targetCanvas.width, targetCanvas.height),
            width: targetCanvas.width, height: targetCanvas.height, updatedAt: -Infinity, mathTime: -Infinity };
          presentationDensityCache.set(fieldProgram, density);
        }
        if (now - density.updatedAt >= fieldProgram.densityIntervalMs || now < density.updatedAt
            || Math.abs(t - density.mathTime) * 1000 >= fieldProgram.densityIntervalMs) {
          context.bindFramebuffer(context.FRAMEBUFFER, density.target.fb);
          context.viewport(0, 0, density.width, density.height);
          context.disable(context.BLEND);
          context.disable(context.DITHER);
          bindField(fieldProgram.densityProgram);
          context.drawArrays(context.TRIANGLES, 0, 3);
          density.updatedAt = now;
          density.mathTime = t;
        }
      }
      context.bindFramebuffer(context.FRAMEBUFFER, null);
      context.viewport(0, 0, targetCanvas.width, targetCanvas.height);
      bindField(fieldProgram);
      if (density) {
        context.activeTexture(context.TEXTURE1);
        context.bindTexture(context.TEXTURE_2D, density.target.tex);
        context.uniform1i(getCachedUniformLocation(context, fieldProgram, "phaseFieldDensity"), 1);
      }
      context.uniform2f(getCachedUniformLocation(context, fieldProgram, "resolution"), targetCanvas.width, targetCanvas.height);
      context.uniform1f(getCachedUniformLocation(context, fieldProgram, "presentationOpacity"), opacity);
      context.disable(context.DITHER);
      context.enable(context.BLEND);
      context.blendEquation(context.FUNC_ADD);
      context.blendFuncSeparate(context.ONE, context.ONE_MINUS_SRC_ALPHA, context.ZERO, context.ONE);
      context.drawArrays(context.TRIANGLES, 0, 3);
    } finally {
      context.blendFuncSeparate(...factors);
      context.blendEquationSeparate(...equations);
      if (blendEnabled) context.enable(context.BLEND); else context.disable(context.BLEND);
      if (ditherEnabled) context.enable(context.DITHER); else context.disable(context.DITHER);
    }
  }
  function transitionBackground(presetValue, fallbackTexture) {
    const assets = textureAssets?.();
    const preset = Number(presetValue);
    const texture = assets?.ensurePresetBackgroundTexture?.(preset) || fallbackTexture;
    const ready = assets?.presetBackgroundCompositeReady?.(preset) || 0;
    return { texture, ready };
  }
  // Reuse the main pair as two independent history slots while the existing
  // depth targets hold the current outputs. Copy only shaders with an active
  // previousFrame sampler; specialised runtimes own their internal histories.
  // No additional full-size textures and no attachment/ownership changes.
  function copyPresetHistory(source, destination) {
    const context = gl();
    context.bindFramebuffer(context.READ_FRAMEBUFFER, source.fb);
    context.bindFramebuffer(context.DRAW_FRAMEBUFFER, destination.fb);
    context.blitFramebuffer(0, 0, source.width, source.height,
      0, 0, destination.width, destination.height, context.COLOR_BUFFER_BIT, context.NEAREST);
  }
  function consumesPreviousFrame(presetId) {
    if (isSpecialGeometryPreset?.(presetId) || INTERNAL_FEEDBACK_PRESETS.has(Number(presetId))) return false;
    const shader = renderProgramForPreset?.(presetId, getQuality?.() || 0);
    return shader && getCachedUniformLocation(gl(), shader, "previousFrame") !== null;
  }
  function prepareRenderedFeedback(transition, buffers, readIndex, width, height) {
    const offline = getOfflineClock?.();
    const rendered = transition.active && !transition.suppressShaderTransition;
    // Offline state is reconstructed for each frame. Match its stable timeline
    // identity instead of the object reference used by the live engine.
    const sameTransition = offline && renderedFeedback?.offline
      ? transitionDiagnosticId(renderedFeedback.transition) === transitionDiagnosticId(transition)
        && offline.videoTimeSeconds >= renderedFeedback.time
      : renderedFeedback?.transition === transition;
    if (renderedFeedback && offline && renderedFeedback.offline && offline.videoTimeSeconds < renderedFeedback.time) {
      renderedFeedback = null; // never reuse retained future-side ownership on a backwards preview seek
    }
    let retainedIncoming = false;
    if (renderedFeedback && (!sameTransition || !rendered
        || renderedFeedback.buffers !== buffers || renderedFeedback.width !== width || renderedFeedback.height !== height)) {
      // Complete, cancel or interrupt against the actual retained participant,
      // never against the old transition's intended destination unconditionally.
      const retainedPreset = rendered ? transition.from : getActivePreset?.();
      const epoch = animationStartedAt(retainedPreset);
      const side = renderedFeedback.sides.find(item => Number(item.preset) === Number(retainedPreset) && item.epoch === epoch);
      if (side && renderedFeedback.buffers === buffers && renderedFeedback.width === width && renderedFeedback.height === height) {
        copyPresetHistory(side.target, buffers[readIndex]);
      }
      const incoming = rendered && renderedFeedback.sides.find(item =>
        Number(item.preset) === Number(transition.to) && item.epoch === animationStartedAt(transition.to));
      if (incoming && renderedFeedback.buffers === buffers && renderedFeedback.width === width && renderedFeedback.height === height) {
        copyPresetHistory(incoming.target, buffers[1 - readIndex]);
        retainedIncoming = true;
      }
      renderedFeedback = null;
    }
    if (renderedFeedback && offline) renderedFeedback.time = offline.videoTimeSeconds;
    if (!rendered || renderedFeedback) return;
    const context = gl();
    // Fresh incoming history must not contain the outgoing preset's pixels or
    // packed shader state. Explicit reactivations get a fresh slot as well.
    const incomingIndex = 1 - readIndex;
    if (!retainedIncoming) {
      context.bindFramebuffer(context.FRAMEBUFFER, buffers[incomingIndex].fb);
      context.colorMask(true, true, true, true);
      context.clearColor(0, 0, 0, 1);
      context.clear(context.COLOR_BUFFER_BIT);
    }
    specialGeometryRenderer?.setPreviousFrameWasPine3D?.(false);
    renderedFeedback = { transition, buffers, width, height, offline: Boolean(offline), time: offline?.videoTimeSeconds,
      fromIndex: readIndex, toIndex: incomingIndex, sides: [] };
  }
  function renderShaderOrSpecialTransitionFrame(now, t, transitionPhase, blitProgram) {
    const context = gl();
    if (!renderSurface.hasBuffers()) resize?.();
    if (!renderSurface.hasBuffers()) throw new Error("Render surface buffers are unavailable");
    const buffers = renderSurface.buffers();
    const readIndex = renderSurface.readIndex();
    const { width: renderWidth, height: renderHeight } = renderSurface.renderSize();
    const writeIndex = 1 - readIndex;
    const transition = getTransition?.() || {};
    prepareRenderedFeedback(transition, buffers, readIndex, renderWidth, renderHeight);
    const activePresetAtFrame = getActivePreset?.();
    const forgeInFrame = Number(activePresetAtFrame) === APOLLONIAN_PHYSARUM_GENESIS_ID ||
      (transition.active && (Number(transition.from) === APOLLONIAN_PHYSARUM_GENESIS_ID ||
        Number(transition.to) === APOLLONIAN_PHYSARUM_GENESIS_ID));
    if (!forgeInFrame) forgeHybrid.stop();
    const stinkhornInFrame = Number(activePresetAtFrame) === STINKHORN_ID ||
      (transition.active && (Number(transition.from) === STINKHORN_ID || Number(transition.to) === STINKHORN_ID));
    if (!stinkhornInFrame) stinkhorn.stop();
    const helixInFrame = Number(activePresetAtFrame) === HELIX_TUNNEL_ID ||
      (transition.active && (Number(transition.from) === HELIX_TUNNEL_ID || Number(transition.to) === HELIX_TUNNEL_ID));
    if (!helixInFrame) helixTunnel.stop();
    const cliffordInFrame = Number(activePresetAtFrame) === CLIFFORD_METAMORPHOSIS_ID ||
      (transition.active && (Number(transition.from) === CLIFFORD_METAMORPHOSIS_ID || Number(transition.to) === CLIFFORD_METAMORPHOSIS_ID));
    if (!cliffordInFrame) cliffordMetamorphosis.stop();
    const aperturesInFrame = Number(activePresetAtFrame) === IMPOSSIBLE_APERTURES_ID ||
      (transition.active && (Number(transition.from) === IMPOSSIBLE_APERTURES_ID || Number(transition.to) === IMPOSSIBLE_APERTURES_ID));
    if (!aperturesInFrame) impossibleApertures.stop();
    const hypergeometryInFrame = Number(activePresetAtFrame) === HYPERGEOMETRY_ID ||
      (transition.active && (Number(transition.from) === HYPERGEOMETRY_ID || Number(transition.to) === HYPERGEOMETRY_ID));
    if (!hypergeometryInFrame) hypergeometry.stop();
    const duoverseInFrame = Number(activePresetAtFrame) === DUOVERSE_HD_ID ||
      (transition.active && (Number(transition.from) === DUOVERSE_HD_ID || Number(transition.to) === DUOVERSE_HD_ID));
    if (!duoverseInFrame) duoverse.stop();
    const newtonInFrame = Number(activePresetAtFrame) === NEWTON_BASIN_DESCENT_ID ||
      (transition.active && (Number(transition.from) === NEWTON_BASIN_DESCENT_ID || Number(transition.to) === NEWTON_BASIN_DESCENT_ID));
    if (!newtonInFrame) newtonBasin.stop();
    const lawInFrame = Number(activePresetAtFrame) === NEWTONS_LAW_ID ||
      (transition.active && (Number(transition.from) === NEWTONS_LAW_ID || Number(transition.to) === NEWTONS_LAW_ID));
    if (!lawInFrame) newtonLaw.stop();
    const consciousnessInFrame = Number(activePresetAtFrame) === ARTIFICIAL_CONSCIOUSNESS_ID ||
      (transition.active && (Number(transition.from) === ARTIFICIAL_CONSCIOUSNESS_ID || Number(transition.to) === ARTIFICIAL_CONSCIOUSNESS_ID));
    if (!consciousnessInFrame) artificialConsciousness.stop();
    prepareWorldshellFrame(now, t, activePresetAtFrame, transition);
    diagnosticFrameNumber += 1;
    const diagnosticId = transitionDiagnosticId(transition);
    const timers = gpuTimers();
    const diagnostics = {
      diagnosticId,
      frameNumber: diagnosticFrameNumber,
      renderWidth,
      renderHeight,
      branch: transition.active ? "transition" : "steady",
      cpuStages: {},
      gpuResults: diagnosticsEnabled?.() ? timers.poll() : [],
      gpuTimerSupported: diagnosticsEnabled?.() ? timers.supported() : false,
      gpuTimerReason: diagnosticsEnabled?.() ? timers.disabledReason() : ""
    };
    if (diagnosticsEnabled?.()) {
      const distanceToSwap = transitionPhase - (transition.swapAt ?? 0.48);
      const boundary = transition.swapped
        ? (distanceToSwap <= 0.04 ? "after-swap" : "incoming")
        : (distanceToSwap >= -0.04 ? "before-swap" : "outgoing");
      const stage = transition.active ? `${diagnosticId}:${boundary}` : `${diagnosticId}:steady`;
      if (stage !== lastContinuityStage) {
        lastContinuityStage = stage;
        console.info("[TransitionContinuity]", JSON.stringify({
          stage, now, source: transition.source, active: activePresetAtFrame, from: transition.from, to: transition.to,
          progress: transitionPhase, swapAt: transition.swapAt, activeStartedAt: getActivePresetStartedAt?.(),
          fromStartedAt: animationStartedAt(transition.from), toStartedAt: animationStartedAt(transition.to),
          fromTime: shaderPresetTime(now, transition.from), toTime: shaderPresetTime(now, transition.to),
          historyFrom: renderedFeedback?.fromIndex, historyTo: renderedFeedback?.toIndex,
          fromTarget: "transitionGeometryTargetAux", toTarget: "transitionGeometryTarget",
          readIndex, writeIndex, width: renderWidth, height: renderHeight, glError: context.getError()
        }));
      }
    }
    function measure(stage, action, { gpu = true } = {}) {
      const startedAt = performance.now();
      const token = gpu ? timers.begin(stage, diagnosticId, diagnosticFrameNumber) : null;
      try {
        return action();
      } finally {
        timers.end(token);
        diagnostics.cpuStages[stage] = performance.now() - startedAt;
      }
    }
    if (transition.active && transition.suppressShaderTransition) {
      diagnostics.branch = "video-covered";
      const activePreset = getActivePreset?.();
      const videoPreparationKey = transitionDiagnosticId(transition);
      const targetIsWorldshell = Math.round(Number(transition.to)) === WORLDSHELL_PRESET_ID;
      const activeIsWorldshell = Math.round(Number(activePreset)) === WORLDSHELL_PRESET_ID;
      // Metadata-video preparation needs more than a single shader preflight.
      // Start Helix's asynchronous beauty/field load under the visible cover,
      // retaining frame zero until the normal incoming render takes ownership.
      if (!transition.swapped && Number(transition.to) === STINKHORN_ID && isVideoCoveringOutput?.(.92)) stinkhorn.prepare();
      if (!transition.swapped && Number(transition.to) === HELIX_TUNNEL_ID
          && isVideoCoveringOutput?.(.92)) helixTunnel.prepare();
      const qualityValue = getQuality?.() || 0;
      const incomingPipelineIsWarm = warmedPresetPipelines.has(
        presetPipelineKey(transition.to, qualityValue)
      );
      if (!transition.swapped
          && !videoPreparedTransitions.has(videoPreparationKey)
          && canCoverVideoPreparation?.()
          && !isSpecialGeometryPreset?.(transition.to)) {
        // WorldShell is compiled and pipeline-warmed during splash. Repeating a
        // full hidden render while video is playing adds GPU contention but the
        // result is not used at hand-off, so deliberately leave it alone.
        if (targetIsWorldshell && incomingPipelineIsWarm) {
          diagnostics.cpuStages.incoming_preflight_skipped = 0;
        } else {
          measure("incoming_preflight", () => {
            ensureTransitionGeometryTarget(renderWidth, renderHeight);
            renderPresetToTarget(
              transitionGeometryTarget,
              transition.to,
              buffers[readIndex].tex,
              0,
              now,
              t
            );
          });
        }
        videoPreparedTransitions.add(videoPreparationKey);
        if (videoPreparedTransitions.size > 64) videoPreparedTransitions.clear();
      }
      if (activeIsWorldshell && isVideoCoveringOutput?.(0.92)) {
        // Continue conductor/resonance state above, but do not submit hidden
        // WorldShell frames while the video owns the display compositor.
        deferredWorldshellVideoTransition = videoPreparationKey;
        diagnostics.cpuStages.active_deferred_for_video = 0;
        return diagnostics;
      }
      if (activeIsWorldshell && deferredWorldshellVideoTransition === videoPreparationKey) {
        // The feedback buffer still contains the outgoing preset. Start the
        // newly visible WorldShell from a clean temporal surface instead of
        // leaking a stray outgoing frame into the reveal.
        clearFeedbackBuffers?.();
        deferredWorldshellVideoTransition = "";
        diagnostics.cpuStages.worldshell_video_handoff = 0;
      }
      if (isSpecialGeometryPreset?.(activePreset)) {
        measure("target_setup", () => ensureTransitionGeometryTarget(renderWidth, renderHeight), { gpu: false });
        measure("active", () => renderPresetToTarget(transitionGeometryTarget, activePreset, buffers[readIndex].tex, 0, now, t));
        measure("presentation", () => blitTextureToCanvasWithPreset(transitionGeometryTarget.tex, activePreset, blitProgram));
        measure("field", () => presentPresetField(transitionGeometryTarget.tex, activePreset, now, t));
        return diagnostics;
      }
      context.disable(context.DEPTH_TEST);
      context.depthMask(false);
      context.colorMask(true, true, true, true);
      measure("active", () => drawShaderPresetToTarget(buffers[writeIndex], activePreset, buffers[readIndex].tex, 0, now, t));
      measure("presentation", () => blitTextureToCanvasWithPreset(buffers[writeIndex].tex, activePreset, blitProgram));
      measure("field", () => presentPresetField(buffers[writeIndex].tex, activePreset, now, t));
      renderSurface.setReadIndex(writeIndex);
      return diagnostics;
    }
    if (transition.active) {
      diagnostics.branch = "rendered-crossfade";
      if (!crossFadeProgram) measure("transition_program", ensureCrossFadeProgram, { gpu: false });
      let fromTex = null;
      let toTex = null;
      measure("target_setup", () => {
        ensureTransitionGeometryTargetAux(renderWidth, renderHeight);
        ensureTransitionGeometryTarget(renderWidth, renderHeight);
      }, { gpu: false });
      const fromIndex = renderedFeedback?.fromIndex ?? readIndex;
      const toIndex = renderedFeedback?.toIndex ?? readIndex;
      fromTex = measure("outgoing", () => renderPresetToTarget(transitionGeometryTargetAux, transition.from, buffers[fromIndex].tex, 0, now, t));
      toTex = measure("incoming", () => renderPresetToTarget(transitionGeometryTarget, transition.to, buffers[toIndex].tex, 0, now, t));
      if (renderedFeedback) {
        renderedFeedback.sides = [
          { preset: transition.from, epoch: animationStartedAt(transition.from), target: transitionGeometryTargetAux },
          { preset: transition.to, epoch: animationStartedAt(transition.to), target: transitionGeometryTarget }
        ];
        measure("feedback", () => {
          if (consumesPreviousFrame(transition.from)) copyPresetHistory(transitionGeometryTargetAux, buffers[fromIndex]);
          if (consumesPreviousFrame(transition.to)) copyPresetHistory(transitionGeometryTarget, buffers[toIndex]);
        });
      }
      const targetCanvas = canvas();
      context.bindFramebuffer(context.FRAMEBUFFER, null);
      context.viewport(0, 0, targetCanvas.width, targetCanvas.height);
      setAttribs?.(crossFadeProgram);
      context.activeTexture(context.TEXTURE0);
      context.bindTexture(context.TEXTURE_2D, fromTex);
      context.uniform1i(getCachedUniformLocation(context, crossFadeProgram, "fromFrame"), 0);
      context.activeTexture(context.TEXTURE1);
      context.bindTexture(context.TEXTURE_2D, toTex);
      context.uniform1i(getCachedUniformLocation(context, crossFadeProgram, "toFrame"), 1);
      const fromBackground = transitionBackground(transition.from, fromTex);
      const toBackground = transitionBackground(transition.to, toTex);
      context.activeTexture(context.TEXTURE2);
      context.bindTexture(context.TEXTURE_2D, fromBackground.texture);
      context.uniform1i(getCachedUniformLocation(context, crossFadeProgram, "fromBackgroundImage"), 2);
      context.activeTexture(context.TEXTURE3);
      context.bindTexture(context.TEXTURE_2D, toBackground.texture);
      context.uniform1i(getCachedUniformLocation(context, crossFadeProgram, "toBackgroundImage"), 3);
      context.uniform1f(getCachedUniformLocation(context, crossFadeProgram, "mixRatio"), transitionPhase);
      context.uniform1f(getCachedUniformLocation(context, crossFadeProgram, "fromBackgroundReady"), fromBackground.ready);
      context.uniform1f(getCachedUniformLocation(context, crossFadeProgram, "toBackgroundReady"), toBackground.ready);
      context.uniform2f(getCachedUniformLocation(context, crossFadeProgram, "outputResolution"), targetCanvas.width, targetCanvas.height);
      const sharpenStrength = 0;
      context.uniform2f(
        getCachedUniformLocation(context, crossFadeProgram, "sourceResolution"),
        renderWidth,
        renderHeight
      );
      context.uniform1f(getCachedUniformLocation(context, crossFadeProgram, "sharpenStrength"), sharpenStrength);
      measure("composite", () => context.drawArrays(context.TRIANGLES, 0, 3));
      measure("field", () => {
        presentPresetField(fromTex, transition.from, now, t, 1 - transitionPhase);
        presentPresetField(toTex, transition.to, now, t, transitionPhase);
      });
      return diagnostics;
    }
    if (specialGeometryRenderer?.getPreviousFrameWasPine3D?.()) {
      clearFeedbackBuffers?.();
      specialGeometryRenderer.setPreviousFrameWasPine3D(false);
    }
    context.disable(context.DEPTH_TEST);
    context.depthMask(false);
    context.colorMask(true, true, true, true);
    const activePreset = getActivePreset?.();
    measure("active", () => renderPresetToTarget(buffers[writeIndex], activePreset, buffers[readIndex].tex, transitionPhase, now, t));
    measure("presentation", () => blitTextureToCanvasWithPreset(buffers[writeIndex].tex, activePreset, blitProgram));
    measure("field", () => presentPresetField(buffers[writeIndex].tex, activePreset, now, t));
    renderSurface.setReadIndex(writeIndex);
    return diagnostics;
  }
  return {
    renderShaderOrSpecialTransitionFrame,
    // keepPreset: the preset becoming active must keep running (stopping it here restarted it from
    // scratch at the end of every transition into it).
    stopForgeHybrid: (keepPreset) => {
      if (Number(keepPreset) !== IMPOSSIBLE_APERTURES_ID) impossibleApertures.stop();
      if (Number(keepPreset) !== HYPERGEOMETRY_ID) hypergeometry.stop();
      if (Number(keepPreset) !== CLIFFORD_METAMORPHOSIS_ID) cliffordMetamorphosis.stop();
      if (Number(keepPreset) !== STINKHORN_ID) stinkhorn.stop();
      helixTunnel.stop(); forgeHybrid.stop(); duoverse.stop(); newtonBasin.stop(); newtonLaw.stop(); artificialConsciousness.stop();
    },
    async prepareOfflineFrame(state, clock, sampleInputsAt) {
      for (const id of [state.preset, state.transition?.from, state.transition?.to].filter(id => id != null)) requireRuntimePreset(id);
      const resources = {};
      const starts = state.transition ? { [state.transition.from]: state.transition.fromPresetStart,
        [state.transition.to]: state.transition.toPresetStart } : { [state.preset]: state.presetStart };
      if (Number(state.preset) === IMPOSSIBLE_APERTURES_ID || (state.transition && !state.transition.suppressShaderTransition &&
          [state.transition.from, state.transition.to].some((id) => Number(id) === IMPOSSIBLE_APERTURES_ID))) {
        await impossibleApertures.prepareOffline(clock.presetTimes[IMPOSSIBLE_APERTURES_ID] || 0, {
          fps: clock.fps,
          inputsAt: (time) => sampleInputsAt?.(starts[IMPOSSIBLE_APERTURES_ID] + time) || {
            audio: getAudioFeatures?.() || {}, smooth: getSmooth?.() || {}, music: getMusicAwareState?.() || {},
            lookahead: getLookaheadState?.() || {}, tempo: getForgeTempo?.()
          }
        });
        resources.shaderAnimationTime = impossibleApertures.director.state.time;
      }
      if (Number(state.preset) === CHAOTIC_BUTTERFLY_PRESET_ID || (state.transition && !state.transition.suppressShaderTransition &&
          [state.transition.from, state.transition.to].some((id) => Number(id) === CHAOTIC_BUTTERFLY_PRESET_ID))) {
        await prepareChaoticButterflyOffline(clock.presetTimes[CHAOTIC_BUTTERFLY_PRESET_ID] || 0, {
          fps: clock.fps,
          inputsAt: (time) => sampleInputsAt?.(starts[CHAOTIC_BUTTERFLY_PRESET_ID] + time) || {
            audio: getAudioFeatures?.() || {}, smooth: getSmooth?.() || {}, music: getMusicAwareState?.() || {},
            tempo: getForgeTempo?.()
          }
        });
      }
      if (Number(state.preset) === FRACTAL_BREAKER_PRESET_ID || (state.transition && !state.transition.suppressShaderTransition &&
          [state.transition.from, state.transition.to].some((id) => Number(id) === FRACTAL_BREAKER_PRESET_ID))) {
        await prepareFractalBreakerOffline(clock.presetTimes[FRACTAL_BREAKER_PRESET_ID] || 0, {
          fps: clock.fps,
          inputsAt: (time) => sampleInputsAt?.(starts[FRACTAL_BREAKER_PRESET_ID] + time) || {
            audio: getAudioFeatures?.() || {}, smooth: getSmooth?.() || {}, music: getMusicAwareState?.() || {}
          }
        });
      }
      if (Number(state.preset) === WOODSTOCK_PRESET_ID || (state.transition && !state.transition.suppressShaderTransition &&
          [state.transition.from, state.transition.to].some((id) => Number(id) === WOODSTOCK_PRESET_ID))) {
        await prepareWoodstockOffline(clock.presetTimes[WOODSTOCK_PRESET_ID] || 0, {
          inputsAt: (time) => sampleInputsAt?.(starts[WOODSTOCK_PRESET_ID] + time) || {
            audio: getAudioFeatures?.() || {}, smooth: getSmooth?.() || {}, music: getMusicAwareState?.() || {},
            lookahead: getLookaheadState?.() || {}, tempo: getForgeTempo?.()
          }
        });
      }
      if (Number(state.preset) === IFS_MATRIX_PRESET_ID || (state.transition && !state.transition.suppressShaderTransition &&
          [state.transition.from, state.transition.to].some((id) => Number(id) === IFS_MATRIX_PRESET_ID))) {
        await prepareIfsMatrixOffline(clock.presetTimes[IFS_MATRIX_PRESET_ID] || 0, {
          fps: clock.fps,
          inputsAt: (time) => sampleInputsAt?.(starts[IFS_MATRIX_PRESET_ID] + time) || {
            audio: getAudioFeatures?.() || {}, smooth: getSmooth?.() || {}, music: getMusicAwareState?.() || {}
          }
        });
      }
      if (Number(state.preset) === NEWTON_BASIN_DESCENT_ID || (state.transition && !state.transition.suppressShaderTransition &&
          [state.transition.from, state.transition.to].some((id) => Number(id) === NEWTON_BASIN_DESCENT_ID))) {
        resources.forgeVideo = await newtonBasin.prepareOffline(clock.presetTimes[NEWTON_BASIN_DESCENT_ID] || 0, getForgeTempo?.());
      }
      return resources;
    },
    endOfflineFrame() {
      renderedFeedback = null;
      endChaoticButterflyOffline();
      endFractalBreakerOffline();
      endIfsMatrixOffline();
      endWoodstockOffline();
      stinkhorn.endOffline();
      newtonBasin.endOffline();
      impossibleApertures.endOffline();
    },
    prepareStinkhornOffline: time => { requireRuntimePreset(STINKHORN_ID); return stinkhorn.prepareOffline(time); },
    endStinkhornOffline: () => stinkhorn.endOffline(),
    renderPresetToTarget,
    drawShaderPresetToTarget,
    blitTextureToCanvas,
    warmPresetPipelines,
    prepareTransitionInfrastructure,
    queuePresetPreflight,
    isPresetPipelineWarm: (presetId, qualityValue = getQuality?.() || 0) => (
      warmedPresetPipelines.has(presetPipelineKey(presetId, qualityValue))
    ),
    worldshellResonanceStatus: () => worldshellResonance.status()
  };
}
