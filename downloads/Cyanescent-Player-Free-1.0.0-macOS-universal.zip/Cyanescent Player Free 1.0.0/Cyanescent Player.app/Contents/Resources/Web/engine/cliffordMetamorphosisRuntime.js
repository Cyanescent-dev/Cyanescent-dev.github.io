// Clifford Phase Space: Metamorphosis — the live renderer (preset 396).
//
// Per frame: the director turns the music into the state of the mathematical universe; one points
// draw computes ~1-3 million Clifford orbits on the GPU (gl_VertexID only) into a float density
// image that decays in place; a reduction pyramid supplies bloom and exposure statistics; the
// composite applies fractal-flame log-density tone mapping into the frame target, so the normal
// preset transitions, previews and blits work unchanged.
import { createCliffordDirector } from "./cliffordMetamorphosisDirector.js";
import { ROUTE_CONTROL, ROUTE_LENGTH, ROUTE_META, ROUTE_META_SAMPLES, ROUTE_WORLDS } from "./cliffordMetamorphosisItinerary.js";
import { cliffordStep, discGrowthProfile, discRadiusForLength, eruptionOrigin, resampleLoop, routeAt } from "./cliffordMetamorphosisMath.js";
import { worldCoordinate, worldPaletteUniforms } from "./cliffordMetamorphosisWorlds.js";
import {
  PULSE_SLOTS, WORLD_SLOTS, cmCompositeSource, cmDown13Source, cmDownSource, cmFadeSource,
  cmPointsFragmentSource, cmPointsVertexSource, cmStatsSource, cmUpSource
} from "./cliffordMetamorphosisShaders.js";

export const CLIFFORD_METAMORPHOSIS_ID = 396;
export const CLIFFORD_METAMORPHOSIS_NAME = "Clifford Phase Space: Metamorphosis";

const ROUTE_SAMPLES = 2048;
const LOG_PREFIX = "[CliffordMetamorphosis]";
// Orbits per frame and map iterations per orbit. High also renders at the full Retina backing size.
export const QUALITY = Object.freeze({
  standard: { bulk: 1_000_000, iterations: 22, pulseVerts: 14_000, segment: 2.0 },
  high: { bulk: 3_000_000, iterations: 26, pulseVerts: 30_000, segment: 2.0 }
});
const STATS_W = 64, STATS_H = 36, STATS_LEVEL = 6;
const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));

// Fixture names select still states for visual checks: cm-w3-portrait-freeze, cm-e40-w0, cm-song ...
export function parseCliffordFixture(fixture) {
  const controls = {};
  if (!/^cm-/.test(fixture || "")) return controls;
  for (const token of fixture.slice(3).split("-")) {
    let m;
    if ((m = /^w(\d+)$/.exec(token))) controls.world = Number(m[1]);
    else if ((m = /^e(\d+)$/.exec(token))) controls.erupt = Number(m[1]) / 100;
    else if (["portrait", "unfold", "voyage", "macro", "singular"].includes(token)) controls.scene = token;
    else if (token === "freeze") controls.freeze = true;
    else if (token === "nodrops") controls.drops = 0;
    else if (token === "off") controls.reactive = 0;
    else if ((m = /^x(\d+)$/.exec(token))) controls.load = Number(m[1]);   // orbit count multiplier (performance tests)
    else if (token === "high") controls.quality = 1;
    else if ((m = /^i(\d+)$/.exec(token))) controls.iterations = Number(m[1]);
    else if (token === "h16") controls.half = true;
    else if (token === "cull") controls.cull = true;
    else if (token === "tour") controls.tour = true;
    else if (token === "esweep") controls.esweep = true;
    else if ((m = /^r(\d+)$/.exec(token))) controls.radius = Math.pow(10, -Number(m[1]));   // eruption from a point to complete over 16 s   // a new world every 4 s, complete and still
    else if ((m = /^c(\d+)$/.exec(token))) controls.clarity = Number(m[1]) / 100;
    else if ((m = /^seg(\d+)$/.exec(token))) controls.segment = Number(m[1]) / 2;   // half-length in pixels
  }
  return controls;
}

export function createCliffordMetamorphosisRuntime({ getGl, program, programFrom, setAttribs }) {
  const director = createCliffordDirector();
  const route = resampleLoop(ROUTE_CONTROL, ROUTE_SAMPLES);
  const palettes = worldPaletteUniforms(WORLD_SLOTS);
  const pulseA = new Float32Array(PULSE_SLOTS * 4), pulseB = new Float32Array(PULSE_SLOTS * 4), pulseP = new Float32Array(PULSE_SLOTS * 4);
  const viewProj = new Float32Array(16), viewProjPrev = new Float32Array(16);
  let active = false, fatal = "", gpu = null, lastAt = 0, frame = 0, controls = {}, startMs = 0;
  let origin = null, accumFormat = "", hadPrev = false, routePrev = 0, flexPrev = [0, 0, 0, 0];
  let reportAt = 0, reportFrames = 0, cpuMs = 0, cpuCount = 0;
  // Load governor: the orbit count adapts so the frame rate holds (a passively cooled GPU clocks
  // down after a minute of full load). The image is exposure-normalised, so only grain changes.
  // A reduction that does not speed frames up means the limit is elsewhere (the page itself is
  // throttled, e.g. to 30 Hz): the load is restored and left alone for a while.
  const governor = { load: 1, interval: 1 / 60, slowFor: 0, fastFor: 0, ceiling: 1, ceilingUntil: 0, trial: null, pausedUntil: 0 };
  function govern(dt, now) {
    if (!(dt > 0) || dt > 0.25) return;
    governor.interval += (dt - governor.interval) * 0.1;
    if (governor.trial && now - governor.trial.at > 2000) {
      if (governor.interval > governor.trial.interval * 0.9) {
        governor.load = governor.trial.load; governor.pausedUntil = now + 20000;
      }
      governor.trial = null;
    }
    if (governor.trial || now < governor.pausedUntil) return;
    if (governor.interval > 1 / 52) { governor.slowFor += dt; governor.fastFor = 0; }
    else if (governor.interval < 1 / 58) { governor.fastFor += dt; governor.slowFor = 0; }
    if (governor.slowFor > 0.6) {
      governor.trial = { at: now, interval: governor.interval, load: governor.load };
      governor.ceiling = governor.load * 0.97; governor.ceilingUntil = now + 30000;
      governor.load = Math.max(0.35, governor.load * 0.82); governor.slowFor = 0;
    } else if (governor.fastFor > 4) {
      const ceiling = now < governor.ceilingUntil ? governor.ceiling : 1;
      governor.load = Math.min(ceiling, governor.load * 1.04); governor.fastFor = 3.5;
    }
  }
  const locations = new WeakMap();
  const trial = () => document.body.classList.contains("preset-trial-role");

  function loc(gl, p, name) {
    let map = locations.get(p);
    if (!map) { map = new Map(); locations.set(p, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(p, name));
    return map.get(name);
  }
  function makeTexture(gl, width, height, internal, format, type, filter, mipmaps = false) {
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, mipmaps ? gl.NEAREST_MIPMAP_NEAREST : filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, width, height, 0, format, type, null);
    if (mipmaps) gl.generateMipmap(gl.TEXTURE_2D);
    return texture;
  }
  function makeTarget(gl, width, height, internal, filter, mipmaps = false) {
    const tex = makeTexture(gl, width, height, internal, gl.RGBA, internal === gl.RGBA32F ? gl.FLOAT : gl.HALF_FLOAT, filter, mipmaps);
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    if (status !== gl.FRAMEBUFFER_COMPLETE) throw new Error(`framebuffer ${width}x${height} incomplete (${status})`);
    return { tex, fb, width, height };
  }
  function freeTarget(gl, target) { if (target) { gl.deleteTexture(target.tex); gl.deleteFramebuffer(target.fb); } }

  // Programs, the route table and the VAO are created once and kept across stop/start, so entering
  // the preset never compiles shaders on a live frame; warm() builds them during Player's pipeline
  // warm-up. They are rebuilt only if the GL context changes or is lost. The size-dependent
  // density and bloom targets are released on stop.
  function ensureGpu() {
    const gl = getGl();
    if (gpu && gpu.gl === gl && !gl.isContextLost?.()) return gpu;
    gpu = null;
    if (!gl.getExtension("EXT_color_buffer_float")) throw new Error("float render targets are unavailable");
    const programs = {
      points: programFrom(cmPointsVertexSource, cmPointsFragmentSource, []),
      fade: program(cmFadeSource), down: program(cmDownSource), stats: program(cmStatsSource),
      down13: program(cmDown13Source), up: program(cmUpSource), composite: program(cmCompositeSource)
    };
    for (const [name, value] of Object.entries(programs)) if (!value) throw new Error(`${name} program did not compile`);
    // Route table: row 0 the parameters, row 1 framing and the world coordinate (colour).
    // Row 2: per-axis framing. Thin attractors are stretched (at most ~2.2x) across their thin
    // axis so they stay readable instead of collapsing into a line.
    const table = new Float32Array(ROUTE_SAMPLES * 3 * 4);
    table.set(route.params, 0);
    for (let k = 0; k < ROUTE_SAMPLES; k += 1) {
      const f = k / ROUTE_SAMPLES, m = f * ROUTE_META_SAMPLES;
      const meta = (key) => routeAt(ROUTE_META[key], 1, ROUTE_META_SAMPLES, m)[0];
      const ex = meta("ex"), ey = meta("ey"), big = Math.max(ex, ey, 0.05);
      table.set([meta("cx"), meta("cy"), 1 / big, worldCoordinate(f)], (ROUTE_SAMPLES + k) * 4);
      table.set([big / Math.max(ex, 0.45 * big), big / Math.max(ey, 0.45 * big), 0, 0], (2 * ROUTE_SAMPLES + k) * 4);
    }
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    const routeTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, routeTex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, ROUTE_SAMPLES, 3, 0, gl.RGBA, gl.FLOAT, table);
    gpu = { gl, programs, routeTex, vao: gl.createVertexArray(), size: [0, 0], format: "", accum: null, half: null, quarter: null, down: [], up: [], stats: null };
    return gpu;
  }

  // Compile and draw every program once into a 1x1 corner of target (forces the driver to finish
  // building its pipelines). The output is discarded by the caller.
  function warm(target) {
    const gl = getGl();
    try {
      const g = ensureGpu();
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, 1, 1);
      gl.disable(gl.BLEND);
      for (const name of ["fade", "down", "stats", "down13", "up", "composite"]) fullscreen(gl, g.programs[name]);
      gl.useProgram(g.programs.points);
      gl.bindVertexArray(g.vao);
      gl.uniform1i(loc(gl, g.programs.points, "uBulkCount"), 1);
      gl.drawArrays(gl.POINTS, 0, 1);
      gl.bindVertexArray(null);
    } catch (error) {
      fatal = String(error?.message || error);
      console.error(`${LOG_PREFIX} warm-up failed:`, error);
    }
  }

  function start() {
    active = true; fatal = ""; frame = 0; lastAt = 0; hadPrev = false; origin = null;
    director.reset();
    controls = parseCliffordFixture(new URLSearchParams(window.location.search).get("fixture") || "");
    if (controls.world >= 0 && controls.world < ROUTE_WORLDS.length) director.state.route = ROUTE_WORLDS[controls.world].at + 0.002;
    window.__cliffordMetamorphosisControls = controls;
    const begin = performance.now();
    try {
      const gl = getGl();
      ensureGpu();
      accumFormat = gl.getExtension("EXT_float_blend") && !controls.half ? "RGBA32F" : "RGBA16F";
    } catch (error) {
      fatal = String(error?.message || error);
      console.error(`${LOG_PREFIX} GPU setup failed:`, error);
    }
    startMs = performance.now() - begin;
  }

  function freeTargets(gl) {
    for (const t of [gpu.accum, gpu.half, gpu.quarter, ...gpu.down, ...gpu.up, gpu.stats]) freeTarget(gl, t);
    Object.assign(gpu, { size: [0, 0], format: "", accum: null, half: null, quarter: null, down: [], up: [], stats: null });
  }
  function ensureTargets(gl, width, height) {
    if (gpu.size[0] === width && gpu.size[1] === height && gpu.format === accumFormat) return;
    for (const t of [gpu.accum, gpu.half, gpu.quarter, ...gpu.down, ...gpu.up, gpu.stats]) freeTarget(gl, t);
    const internal = accumFormat === "RGBA32F" ? gl.RGBA32F : gl.RGBA16F;
    const level = (shift) => makeTarget(gl, Math.max(2, width >> shift), Math.max(2, height >> shift), gl.RGBA16F, gl.LINEAR);
    gpu.accum = makeTarget(gl, width, height, internal, gl.NEAREST);
    // Box averages for density estimation; a 13-tap pyramid (1/8 .. 1/32) and its upsampled sums
    // (1/4 .. 1/16) for bloom.
    gpu.half = level(1);
    gpu.quarter = level(2);
    gpu.down = [level(3), level(4), level(5)];
    gpu.up = [level(2), level(3), level(4)];
    gpu.stats = makeTarget(gl, STATS_W, STATS_H, gl.RGBA16F, gl.NEAREST, true);
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.accum.fb);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gpu.size = [width, height]; gpu.format = accumFormat;
  }

  // Camera: orbit around a target with a slow musical sway; perspective projection.
  function cameraMatrix(out, state, aspect) {
    const cam = state.camera;
    const yaw = cam.yaw + state.orbitAngle + cam.sway * Math.sin(state.swayPhase * Math.PI * 2);
    const pitch = cam.pitch + cam.sway * 0.55 * Math.sin(state.swayPhase * Math.PI * 2 * 0.71 + 1.3);
    // Fit the normalised attractor (half size ~1) to the screen whichever way round it is.
    const fit = aspect < 1.2 ? 1.2 / aspect : 1;
    const distance = cam.distance * fit;
    const t = cam.target;
    const eye = [t[0] + distance * Math.cos(pitch) * Math.sin(yaw), t[1] + distance * Math.sin(pitch), t[2] + distance * Math.cos(pitch) * Math.cos(yaw)];
    let f = [t[0] - eye[0], t[1] - eye[1], t[2] - eye[2]];
    const fl = Math.hypot(...f); f = f.map((v) => v / fl);
    // right = forward x up (+y), up = right x forward
    let r = [-f[2], 0, f[0]];
    const rl = Math.hypot(...r) || 1; r = r.map((v) => v / rl);
    const u = [r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]];
    const view = [
      r[0], u[0], -f[0], 0,
      r[1], u[1], -f[1], 0,
      r[2], u[2], -f[2], 0,
      -(r[0] * eye[0] + r[1] * eye[1] + r[2] * eye[2]), -(u[0] * eye[0] + u[1] * eye[1] + u[2] * eye[2]), f[0] * eye[0] + f[1] * eye[1] + f[2] * eye[2], 1
    ];
    const near = 0.03, far = 60, k = 1 / Math.tan(cam.fov / 2);
    const proj = [k / aspect, 0, 0, 0, 0, k, 0, 0, 0, 0, (far + near) / (near - far), -1, 0, 0, (2 * far * near) / (near - far), 0];
    for (let c = 0; c < 4; c += 1) for (let rr = 0; rr < 4; rr += 1) {
      let sum = 0;
      for (let q = 0; q < 4; q += 1) sum += proj[q * 4 + rr] * view[c * 4 + q];
      out[c * 4 + rr] = sum;
    }
    return out;
  }

  function fullscreen(gl, p) { gl.useProgram(p); setAttribs(p); gl.drawArrays(gl.TRIANGLES, 0, 3); }
  function bindTex(gl, p, name, unit, texture) {
    gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(loc(gl, p, name), unit);
  }

  function render({ target, width, height, now, quality = 0, playing = true, audio = {}, smooth = {}, music = {}, lookahead = {}, tempo = {} }) {
    if (!active) start();
    const stamp = performance.now();
    const gl = getGl();
    const dt = lastAt ? clamp((now - lastAt) / 1000, 0, 0.1) : 1 / 60;
    lastAt = now; frame += 1;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    if (!fatal) {
      try { ensureGpu(); } catch (error) { fatal = String(error?.message || error); }
    }
    if (fatal || !gpu) { gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); publish(now); return; }

    const base = (controls.quality ?? quality) > 0.5 ? QUALITY.high : QUALITY.standard;
    if (playing && !controls.load) govern(dt, now);
    const q = { ...base, bulk: Math.round(base.bulk * (controls.load ? controls.load / 4 : governor.load)), iterations: controls.iterations || base.iterations };
    // A collapsing attractor covers few pixels: far fewer orbits draw it just as well, and a million
    // orbits landing on one pixel would serialise the blending.
    director.step(playing ? dt : 0, { audio, smooth, music, lookahead, tempo }, controls);
    const s = director.state;
    if (controls.tour) {
      const k = Math.floor(s.time / 4) % ROUTE_WORLDS.length;
      s.route = ROUTE_WORLDS[k].at + 0.002; s.worldIndex = k; s.erupt = 1; s.eruptShare = 0; s.phase = "flow";
    }
    if (Number.isFinite(controls.erupt)) { s.erupt = controls.erupt; s.eruptShare = 1; }
    if (controls.esweep) { s.erupt = Math.min(1, s.time / 16); s.eruptShare = 1; s.phase = "flow"; }

    // Route position (in table samples), the centre slice's parameters and framing.
    const u = s.route * ROUTE_SAMPLES;
    const centre = routeAt(route.params, 4, ROUTE_SAMPLES, u);
    const p = centre.map((v, i) => v + s.flex[i]);
    const m = s.route * ROUTE_META_SAMPLES;
    const extent = Math.max(routeAt(ROUTE_META.ex, 1, ROUTE_META_SAMPLES, m)[0], routeAt(ROUTE_META.ey, 1, ROUTE_META_SAMPLES, m)[0], 0.05);
    // The eruption disc around the repelling fixed point, sized so its forward image (a piece of
    // unstable manifold) is 10^(8e - 3) attractor extents long: e = 0 a point, e = 0.375 a filament
    // as long as the attractor, e = 0.5 a single knotted curve, e = 0.75 a dense knot of curves,
    // e = 1 the manifold wound through the attractor so often that it is the attractor.
    let erupt = [0, 0, 0, 0];
    if (s.eruptShare > 0.001) {
      origin = eruptionOrigin(p, origin);
      let ox, oy, expansion;
      if (origin) ({ x: ox, y: oy, expansion } = origin);
      else {
        let x = 0.1, y = 0.1;
        for (let i = 0; i < 300; i += 1) [x, y] = cliffordStep(p, x, y);
        ox = x; oy = y; expansion = Math.exp(Math.max(0.15, routeAt(ROUTE_META.lyapunov, 1, ROUTE_META_SAMPLES, m)[0]));
      }
      const lyap = routeAt(ROUTE_META.lyapunov, 1, ROUTE_META_SAMPLES, m)[0];
      const profile = origin ? discGrowthProfile(p, origin, q.iterations) : Float64Array.from({ length: q.iterations + 1 }, (_, k) => Math.pow(expansion, k));
      const radius = Math.min(3, discRadiusForLength(profile, extent * Math.pow(10, 8 * s.erupt - 3), lyap));
      erupt = [ox, oy, controls.radius ?? radius, s.eruptShare];
    } else origin = null;

    const aspect = width / Math.max(1, height);
    cameraMatrix(viewProj, s, aspect);
    if (!hadPrev) { viewProjPrev.set(viewProj); routePrev = u; flexPrev = s.flex.slice(); hadPrev = true; }
    let routeDU = u - routePrev;
    if (routeDU < -ROUTE_SAMPLES / 2) routeDU += ROUTE_SAMPLES;
    if (Math.abs(routeDU) > 4) routeDU = 0;   // a drop jump is a cut, not motion

    // Pulse uniforms. Each pulse keeps the parameters of its birth so its origin stays put.
    pulseA.fill(0); pulseB.fill(0); pulseP.fill(0);
    director.pulses.slice(0, PULSE_SLOTS).forEach((pulse, i) => {
      if (!pulse.params) pulse.params = routeAt(route.params, 4, ROUTE_SAMPLES, u - pulse.slice * s.span * ROUTE_SAMPLES / ROUTE_LENGTH);
      const fade = Math.pow(1 - pulse.age / pulse.life, 1.4);
      pulseA.set([pulse.seed[0], pulse.seed[1], pulse.slice, pulse.front], i * 4);
      pulseB.set([pulse.strength * fade, pulse.hue, pulse.radius, pulse.accent], i * 4);
      pulseP.set(pulse.params, i * 4);
    });

    ensureTargets(gl, width, height);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    gl.disable(gl.SCISSOR_TEST);

    // 1) decay the density image in place
    const retain = Math.exp(-dt / Math.max(0.02, s.retainTime));
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.accum.fb);
    gl.viewport(0, 0, width, height);
    gl.enable(gl.BLEND);
    gl.blendEquation(gl.FUNC_ADD);
    gl.blendColor(retain, retain, retain, retain);
    gl.blendFunc(gl.ZERO, gl.CONSTANT_COLOR);
    fullscreen(gl, gpu.programs.fade);

    // 2) the orbits
    const P = gpu.programs.points;
    gl.blendFunc(gl.ONE, gl.ONE);
    gl.useProgram(P);
    gl.bindVertexArray(gpu.vao);
    bindTex(gl, P, "uRoute", 0, gpu.routeTex);
    gl.uniform1i(loc(gl, P, "uRouteSamples"), ROUTE_SAMPLES);
    gl.uniform1f(loc(gl, P, "uRouteU"), u);
    gl.uniform1f(loc(gl, P, "uRouteDU"), routeDU);
    // span is in route length units; one table sample is ROUTE_LENGTH / ROUTE_SAMPLES long.
    gl.uniform1f(loc(gl, P, "uSpan"), s.span * ROUTE_SAMPLES / ROUTE_LENGTH);
    gl.uniform1f(loc(gl, P, "uSliceBias"), s.sliceBias);
    gl.uniform4fv(loc(gl, P, "uFlex"), s.flex);
    gl.uniform4fv(loc(gl, P, "uFlexPrev"), flexPrev);
    gl.uniform1i(loc(gl, P, "uIterations"), q.iterations);
    gl.uniform1i(loc(gl, P, "uBulkCount"), q.bulk);
    gl.uniform1i(loc(gl, P, "uPulseVerts"), q.pulseVerts);
    gl.uniform4fv(loc(gl, P, "uPulseA[0]"), pulseA);
    gl.uniform4fv(loc(gl, P, "uPulseB[0]"), pulseB);
    gl.uniform4fv(loc(gl, P, "uPulseP[0]"), pulseP);
    gl.uniform4fv(loc(gl, P, "uErupt"), erupt);
    if (controls.cull) viewProj.fill(0);
    gl.uniformMatrix4fv(loc(gl, P, "uViewProj"), false, viewProj);
    gl.uniformMatrix4fv(loc(gl, P, "uViewProjPrev"), false, viewProjPrev);
    gl.uniform4f(loc(gl, P, "uShape"), s.depth, s.lift * (1 + 0.45 * s.pump), s.twist, s.liftAngle);
    const pixelsPerOrbit = (width * height) / q.bulk;
    // A pulse carries about a third of the attractor's light, concentrated on its manifold piece.
    gl.uniform4f(loc(gl, P, "uStyle"), s.hueDrift, 0.22, 1, 0.35 * q.bulk / q.pulseVerts);
    gl.uniform4f(loc(gl, P, "uStyle2"), 0.3, 0.5 + 1.6 * s.hatGlint, 1, 0.85);
    gl.uniform1ui(loc(gl, P, "uSeed"), (frame * 7919) >>> 0);
    gl.uniform3fv(loc(gl, P, "uPalette[0]"), palettes.palette);
    gl.uniform3fv(loc(gl, P, "uAccent[0]"), palettes.accent);
    gl.uniform2f(loc(gl, P, "uView"), width, height);
    gl.uniform1f(loc(gl, P, "uSegment"), controls.segment ?? q.segment);
    const drawn = Math.round(q.bulk * (s.eruptShare > 0.5 ? 0.2 + 0.8 * Math.pow(Math.min(1, s.erupt / 0.8), 2) : 1));
    gl.uniform1i(loc(gl, P, "uBulkCount"), drawn);
    gl.drawArrays(gl.POINTS, 0, drawn + PULSE_SLOTS * q.pulseVerts);
    gl.bindVertexArray(null);
    gl.disable(gl.BLEND);

    // 3) reduction pyramid: half -> quarter (bloom) -> eighth (glow); exposure statistics
    const D = gpu.programs.down;
    const down = (source, dest) => {
      gl.bindFramebuffer(gl.FRAMEBUFFER, dest.fb); gl.viewport(0, 0, dest.width, dest.height);
      gl.useProgram(D); bindTex(gl, D, "uSource", 0, source.tex);
      gl.uniform2f(loc(gl, D, "uTexel"), 1 / source.width, 1 / source.height);
      fullscreen(gl, D);
    };
    down(gpu.accum, gpu.half);
    down(gpu.half, gpu.quarter);
    const D13 = gpu.programs.down13;
    let source = gpu.quarter;
    for (const dest of gpu.down) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, dest.fb); gl.viewport(0, 0, dest.width, dest.height);
      gl.useProgram(D13); bindTex(gl, D13, "uSource", 0, source.tex);
      gl.uniform2f(loc(gl, D13, "uTexel"), 1 / source.width, 1 / source.height);
      fullscreen(gl, D13);
      source = dest;
    }
    const norm = (1 - retain) * pixelsPerOrbit;
    const S = gpu.programs.stats;
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.stats.fb); gl.viewport(0, 0, STATS_W, STATS_H);
    gl.useProgram(S); bindTex(gl, S, "uSource", 0, gpu.down[0].tex);
    gl.uniform1f(loc(gl, S, "uNorm"), norm);
    fullscreen(gl, S);
    gl.bindTexture(gl.TEXTURE_2D, gpu.stats.tex);
    gl.generateMipmap(gl.TEXTURE_2D);
    // Upsample: up[2] = down[1] + tent(down[2]); up[1] = down[0] + tent(up[2]); up[0] = quarter + tent(up[1]).
    const U = gpu.programs.up;
    const bases = [gpu.quarter, gpu.down[0], gpu.down[1]];
    for (let k = 2; k >= 0; k -= 1) {
      const lower = k === 2 ? gpu.down[2] : gpu.up[k + 1];
      gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.up[k].fb); gl.viewport(0, 0, gpu.up[k].width, gpu.up[k].height);
      gl.useProgram(U); bindTex(gl, U, "uBase", 0, bases[k].tex); bindTex(gl, U, "uLower", 1, lower.tex);
      gl.uniform2f(loc(gl, U, "uTexel"), 1 / lower.width, 1 / lower.height);
      gl.uniform1f(loc(gl, U, "uWeight"), 1.0);
      fullscreen(gl, U);
    }

    // 4) composite into the frame target
    const C = gpu.programs.composite;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    gl.useProgram(C);
    bindTex(gl, C, "uAccum", 0, gpu.accum.tex);
    bindTex(gl, C, "uBloom", 1, gpu.up[0].tex);
    bindTex(gl, C, "uGlow", 2, gpu.up[2].tex);
    bindTex(gl, C, "uStats", 3, gpu.stats.tex);
    bindTex(gl, C, "uHalf", 4, gpu.half.tex);
    bindTex(gl, C, "uBloomRaw", 5, gpu.quarter.tex);
    gl.uniform1f(loc(gl, C, "uStatsLevel"), STATS_LEVEL);
    gl.uniform1f(loc(gl, C, "uNorm"), norm);
    // Log density as in the fractal-flame algorithm, in linear light: a typical lit pixel sits low,
    // only densities ~30x typical reach white, so feathers and folds both keep their structure.
    gl.uniform4f(loc(gl, C, "uTone"), s.exposure, 30.0, 1.15, 0.82);
    gl.uniform4f(loc(gl, C, "uGrade"), s.bloom * 0.16, s.glow * 0.22, s.flash * 0.25, s.saturation);
    gl.uniform4f(loc(gl, C, "uFrame"), aspect, s.vignette, s.presence, 0.0);
    const world = ROUTE_WORLDS[s.worldIndex];
    gl.uniform3f(loc(gl, C, "uTint"), ...(world ? palettes.accent.subarray(s.worldIndex * 3, s.worldIndex * 3 + 3) : [1, 1, 1]));
    gl.uniform2f(loc(gl, C, "uResolution"), width, height);
    gl.uniform1f(loc(gl, C, "uClarity"), controls.clarity ?? 0.7);
    fullscreen(gl, C);

    viewProjPrev.set(viewProj); routePrev = u; flexPrev = s.flex.slice();
    cpuMs += performance.now() - stamp; cpuCount += 1;
    publish(now, { width, height, quality: base === QUALITY.high ? "high" : "standard", bulk: q.bulk, iterations: q.iterations, origin: Boolean(origin), radius: erupt[2] });
  }

  function publish(now, extra = {}) {
    if (now - reportAt < (trial() ? 1000 : 3000)) return;
    const fps = reportAt ? (frame - reportFrames) * 1000 / (now - reportAt) : 0;
    reportAt = now; reportFrames = frame;
    const s = director.state;
    window.__cliffordMetamorphosisDiagnostics = {
      fatal, accumFormat, startMs: +startMs.toFixed(1), fps, load: +governor.load.toFixed(3), cpuMs: cpuMs / Math.max(1, cpuCount), ...extra,
      t: +s.time.toFixed(1), route: s.route, world: ROUTE_WORLDS[s.worldIndex]?.name, rebounds: s.rebounds, reeruptions: s.reeruptions, scene: s.scene, phase: s.phase,
      erupt: s.erupt, share: s.eruptShare, tension: s.tension, future: s.future, span: s.span, speed: s.routeSpeed,
      energy: s.energy, groove: s.groove, breakdown: s.breakdown, build: s.build,
      kicks: s.kicks, hats: s.hats, drops: s.drops, collapses: s.collapses, relaxes: s.relaxes, pulses: director.pulses.length,
      beatSource: director.audioState.beatSource, controls
    };
    cpuMs = 0; cpuCount = 0;
    if (trial()) window.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "info", text: `${LOG_PREFIX} ${JSON.stringify(window.__cliffordMetamorphosisDiagnostics)}` });
  }

  // Leaving the preset releases the screen-sized targets; programs and the route table stay.
  function stop() {
    if (!active) return;
    active = false;
    const gl = getGl();
    if (gpu && gl && gpu.gl === gl && !gl.isContextLost?.()) freeTargets(gl);
    window.__cliffordMetamorphosisDiagnostics = window.__cliffordMetamorphosisControls = null;
  }

  return { render, stop, warm, controls: () => controls, director, isActive: () => active };
}
