import {
  chooseAdaptivePreset,
  detectAdaptiveMusicalEvent,
  eventTypeForSectionLabel,
  selectAdaptiveLandingTime,
  transitionStyleForMusicalEvent
} from "./adaptiveTransitions.js";
import {
  MusicalEventType,
  VisualTransitionMode
} from "./transitions.js";
import { createDiversityCycle } from "./diversityCycle.js";

const emptyState = Object.freeze({});

export const AdaptiveTransitionTimingPreset = Object.freeze({
  SHORT: "short",
  MEDIUM: "medium",
  LONG: "long"
});

export const AdaptiveTransitionTimingRanges = Object.freeze({
  [AdaptiveTransitionTimingPreset.SHORT]: Object.freeze({ min: 20, max: 40 }),
  [AdaptiveTransitionTimingPreset.MEDIUM]: Object.freeze({ min: 40, max: 70 }),
  [AdaptiveTransitionTimingPreset.LONG]: Object.freeze({ min: 65, max: 110 })
});

export function adaptiveTransitionTimingRange(value) {
  return AdaptiveTransitionTimingRanges[value] || AdaptiveTransitionTimingRanges[AdaptiveTransitionTimingPreset.MEDIUM];
}

export function adaptiveTransitionProtectionShift(minimum, transitionSeconds = 2.6) {
  if (!Number.isFinite(minimum) || minimum <= 0) return 0;
  return Math.max(0, minimum + transitionSeconds - AdaptiveTransitionTimingRanges.short.min);
}

export class AdaptiveTransitionManager {
  constructor(deps = {}) {
    this.deps = deps;
    this.minPresetDuration = 40;
    this.maxPresetDuration = 70;
    this.lookaheadMin = 3.0;
    this.lookaheadMax = 18.0;
    this.lastPresetStartTime = null;
    this.lastTransitionTime = -Infinity;
    this.pending = null;
    this.diversity = createDiversityCycle();
    this.debug = this.createDebugState();
    this.debugElement = null;
  }

  createDebugState() {
    return {
      eventType: "none",
      confidence: 0,
      eventTime: null,
      landingTime: null,
      loopBeats: null,
      transitionStyle: null,
      nextPreset: null,
      secondsUntilTransition: null
    };
  }

  reset() {
    this.pending = null;
    this.lastPresetStartTime = null;
    this.lastTransitionTime = -Infinity;
    this.debug = this.createDebugState();
  }

  markPresetStarted(startTime = this.currentTime()) {
    this.pending = null;
    this.lastPresetStartTime = Math.max(0, Number(startTime) || 0);
    this.lastTransitionTime = -Infinity;
    this.debug = this.createDebugState();
  }

  handleSeek(newTime = this.currentTime()) {
    this.pending = null;
    this.lastPresetStartTime = Math.max(0, newTime - this.minPresetDuration);
    this.lastTransitionTime = -Infinity;
    this.debug = this.createDebugState();
  }

  currentTime() {
    return this.deps.currentTime?.() || 0;
  }

  transitionMode() {
    return this.deps.transitionMode?.() || VisualTransitionMode.STATIC;
  }

  timingRange() {
    return adaptiveTransitionTimingRange(this.deps.adaptiveTimingPreset?.());
  }

  syncTimingRange() {
    const range = this.timingRange();
    this.minPresetDuration = range.min;
    this.maxPresetDuration = range.max;
  }

  setTimingPreset(value) {
    const range = adaptiveTransitionTimingRange(value);
    this.minPresetDuration = range.min;
    this.maxPresetDuration = range.max;
    // The UI may already have updated the dependency. Invalidate the plan,
    // but retain the activation origin and the controller's wall-clock age.
    this.pending = null;
    this.debug = this.createDebugState();
  }

  analysisTimeline() {
    return this.deps.analysisTimeline?.() || null;
  }

  musicAwareState() {
    return this.deps.musicAwareState?.() || emptyState;
  }

  lookaheadState() {
    return this.deps.lookaheadState?.() || emptyState;
  }

  activePreset() {
    return this.deps.activePreset?.() ?? 0;
  }

  presetMetadata() {
    return this.deps.presetMetadata?.() || [];
  }

  presetMetadataById() {
    return this.deps.presetMetadataById?.() || new Map();
  }

  eligiblePresetIds() {
    return new Set((this.deps.eligiblePresetIds?.() || []).map(Number));
  }

  eligiblePresetMetadata() {
    const eligibleIds = this.eligiblePresetIds();
    return this.presetMetadata().filter((metadata) => eligibleIds.has(Number(metadata.id)));
  }

  transitionDurationSeconds() {
    return 2.6;
  }

  ensurePresetStartTime(currentTime) {
    if (this.lastPresetStartTime === null) {
      this.lastPresetStartTime = Math.max(0, currentTime - this.minPresetDuration);
    }
  }

  schedulingStartTime(currentTime = this.currentTime()) {
    // Protected minima use elapsed wall time since activation, independent of
    // audio seeks, playback speed and timing-setting changes. Keep the legacy
    // exact-play (Evolution of Dance) path and ordinary audio windows intact.
    const age = this.activePresetAgeSeconds();
    if (this.activePresetMinimumPlaySeconds() > 0 && this.activePresetExactPlaySeconds() <= 0 && age !== null) {
      return currentTime - age;
    }
    return this.lastPresetStartTime ?? 0;
  }

  protectedWindowShift() {
    // Shift all three ranges by the same amount. This retains their offsets
    // and widths, so Long can never acquire an earlier deadline than Medium.
    return adaptiveTransitionProtectionShift(this.activePresetMinimumPlaySeconds(), this.transitionDurationSeconds());
  }

  earliestLandingTime(currentTime = this.currentTime()) {
    const exact = this.activePresetExactLandingTime(currentTime);
    if (exact !== null) return exact;
    return this.schedulingStartTime(currentTime) + this.minPresetDuration + this.protectedWindowShift();
  }

  latestLandingTime(currentTime = this.currentTime()) {
    const exact = this.activePresetExactLandingTime(currentTime);
    if (exact !== null) return exact;
    return this.schedulingStartTime(currentTime) + this.maxPresetDuration + this.protectedWindowShift();
  }

  reachableLatestLandingTime(currentTime = this.currentTime()) {
    const transitionLead = this.transitionDurationSeconds() + 0.35;
    return Math.max(this.latestLandingTime(currentTime), currentTime + transitionLead);
  }

  activePresetMinimumPlaySeconds() {
    const seconds = Number(this.deps.presetMinimumPlaySeconds?.(this.activePreset()) || 0);
    return Number.isFinite(seconds) && seconds > 0 ? seconds : 0;
  }

  activePresetAgeSeconds() {
    const seconds = Number(this.deps.activePresetAgeSeconds?.());
    return Number.isFinite(seconds) && seconds >= 0 ? seconds : null;
  }

  activePresetExactPlaySeconds() {
    const seconds = Number(this.deps.presetExactPlaySeconds?.(this.activePreset()) || 0);
    return Number.isFinite(seconds) && seconds > 0 ? seconds : 0;
  }

  activePresetExactLandingTime(currentTime = this.currentTime()) {
    const seconds = this.activePresetExactPlaySeconds();
    if (seconds <= 0) return null;
    const activePresetAge = this.activePresetAgeSeconds();
    const naturalLandingTime = activePresetAge !== null
      ? currentTime + Math.max(0, seconds - activePresetAge)
      : (this.lastPresetStartTime ?? 0) + seconds;
    const soonestPossibleLandingTime = currentTime + this.transitionDurationSeconds() + 0.35;
    return Math.max(naturalLandingTime, soonestPossibleLandingTime);
  }

  loopBoundariesBetween(startTime, endTime) {
    return this.analysisTimeline()?.getLoopBoundariesBetween(startTime, endTime, [8, 16, 32]) || [];
  }

  selectLandingTime(event, currentTime) {
    const transitionLead = this.transitionDurationSeconds() + 0.35;
    const exactLandingTime = this.activePresetExactLandingTime(currentTime);
    if (exactLandingTime !== null) {
      return {
        time: exactLandingTime,
        beats: null,
        exact: true
      };
    }
    const earliest = Math.max(currentTime + transitionLead, this.earliestLandingTime(currentTime));
    const latest = Math.max(earliest, this.latestLandingTime(currentTime));
    return selectAdaptiveLandingTime({
      event,
      currentTime,
      earliest,
      latest,
      transitionLead,
      loopBoundaries: this.loopBoundariesBetween(earliest, latest)
    });
  }

  eventForCurrentState(currentTime) {
    const timeline = this.analysisTimeline();
    const current = timeline?.getFeatures(currentTime);
    const medium = timeline?.getLookaheadFeatures(currentTime, 10);
    const section = timeline?.getSectionAt(currentTime);
    let type = this.eventTypeForSection(section?.label) || MusicalEventType.SECTION_CHANGE;
    if (current && medium) {
      if (current.energy > 0.44 && medium.density > 0.34) type = MusicalEventType.HIGH_ENERGY;
      if (current.energy < 0.24 && medium.energy < 0.30) type = MusicalEventType.CALM_SECTION;
    }
    return {
      type,
      time: this.latestLandingTime(currentTime),
      confidence: 0.62,
      reason: "max duration boundary"
    };
  }

  createPending(event, currentTime) {
    const targetPreset = this.choosePreset(event);
    if (targetPreset === null || targetPreset === this.activePreset()) return null;
    const landing = this.selectLandingTime(event, currentTime);
    const pending = {
      ...event,
      targetPreset,
      eventTime: event.time,
      landingTime: landing.time,
      loopBeats: landing.beats,
      transitionStyle: this.transitionStyleForEvent(event.type),
      startTime: Math.max(currentTime + 0.35, landing.time - this.transitionDurationSeconds())
    };
    this.deps.onPendingPreset?.(targetPreset, pending);
    return pending;
  }

  transitionStyleForEvent(type) {
    return transitionStyleForMusicalEvent(type);
  }

  refreshPendingDebug(currentTime) {
    if (!this.pending) return;
    this.debug = {
      eventType: this.pending.type || "none",
      confidence: this.pending.confidence || 0,
      eventTime: this.pending.eventTime || null,
      landingTime: this.pending.landingTime || null,
      loopBeats: this.pending.loopBeats || null,
      transitionStyle: this.pending.transitionStyle ?? null,
      nextPreset: this.pending.targetPreset ?? null,
      secondsUntilTransition: Math.max(0, this.pending.startTime - currentTime),
      reason: this.pending.reason || ""
    };
  }

  update(now) {
    if (this.transitionMode() !== VisualTransitionMode.ADAPTIVE) {
      this.reset();
      this.renderDebug();
      return;
    }
    if (!this.deps.canRun?.()) {
      this.renderDebug();
      return;
    }

    this.syncTimingRange();
    const currentTime = this.currentTime();
    this.ensurePresetStartTime(currentTime);

    if (this.pending && currentTime > this.pending.landingTime + 2.0) {
      this.pending = null;
    }

    const latestLanding = this.latestLandingTime(currentTime);
    const reachableLatestLanding = this.reachableLatestLandingTime(currentTime);
    if (this.pending && this.pending.landingTime > reachableLatestLanding + 0.1) {
      this.pending = null;
    }

    if (!this.pending) {
      const event = this.detectEvent(currentTime);
      const eventOccursAfterProtection = this.activePresetMinimumPlaySeconds() <= 0
        || Number(event?.time) >= (this.activePresetExactPlaySeconds() > 0
          ? (this.lastPresetStartTime ?? 0) + this.activePresetMinimumPlaySeconds() + this.transitionDurationSeconds()
          : Math.max(this.earliestLandingTime(currentTime),
            currentTime + this.transitionDurationSeconds() + 0.35));
      if (event && event.confidence >= 0.58 && eventOccursAfterProtection) {
        this.pending = this.createPending(event, currentTime);
      }
      if (!this.pending && currentTime >= latestLanding - this.transitionDurationSeconds() - 1.0) {
        this.pending = this.createPending(this.eventForCurrentState(currentTime), currentTime);
      }
    }
    this.refreshPendingDebug(currentTime);

    if (this.pending && currentTime >= this.pending.startTime
      && (this.activePresetExactPlaySeconds() > 0 || this.activePresetMinimumPlaySeconds() <= 0
        || currentTime >= this.schedulingStartTime(currentTime) + this.activePresetMinimumPlaySeconds())) {
      if (this.deps.beginPresetTransition?.(this.pending.targetPreset, this.pending.transitionStyle || 0)) {
        this.lastPresetStartTime = this.pending.landingTime;
        this.lastTransitionTime = currentTime;
      }
      this.pending = null;
    }

    this.renderDebug(currentTime);
  }

  detectEvent(currentTime) {
    const timeline = this.analysisTimeline();
    const current = timeline?.getFeatures(currentTime);
    const near = timeline?.getLookaheadFeatures(currentTime, 5);
    const medium = timeline?.getLookaheadFeatures(currentTime, 10);
    const long = timeline?.getLookaheadFeatures(currentTime, 20);
    if (!current || !near || !medium || !long) return null;
    const { best } = detectAdaptiveMusicalEvent({
      currentTime,
      current,
      near,
      medium,
      long,
      upcomingSection: this.nextSection(currentTime),
      musicAwareState: this.musicAwareState()
    });
    this.debug = {
      eventType: best?.type || "none",
      confidence: best?.confidence || 0,
      eventTime: best?.time || null,
      landingTime: this.pending?.landingTime || null,
      loopBeats: this.pending?.loopBeats || null,
      transitionStyle: this.pending?.transitionStyle ?? null,
      nextPreset: this.pending?.targetPreset ?? null,
      secondsUntilTransition: this.pending ? Math.max(0, this.pending.startTime - currentTime) : null,
      reason: best?.reason || ""
    };
    return best;
  }

  nextSection(currentTime) {
    const sections = this.analysisTimeline()?.sections || [];
    if (!sections.length) return null;
    return sections.find((section) => {
      const secondsAway = section.start - currentTime;
      return secondsAway >= this.lookaheadMin && secondsAway <= this.lookaheadMax;
    }) || null;
  }

  eventTypeForSection(label) {
    return eventTypeForSectionLabel(label);
  }

  choosePreset(event) {
    const eligibleMetadata = this.eligiblePresetMetadata();
    return chooseAdaptivePreset({
      event,
      activePreset: this.activePreset(),
      presetMetadata: eligibleMetadata,
      presetMetadataById: this.presetMetadataById(),
      recentPresets: this.diversity.recentIds().map(Number),
      candidatePresetIds: this.diversity.candidates(eligibleMetadata.map((metadata) => metadata.id), {
        activeId: this.activePreset()
      }),
      currentTime: this.currentTime()
    });
  }

  notePresetActivated(presetId) {
    this.diversity.record(presetId, this.eligiblePresetMetadata().map((metadata) => metadata.id));
  }

  renderDebug(currentTime = this.currentTime()) {
    if (!globalThis.window?.CYANESCENT_DEBUG_ADAPTIVE) {
      if (this.debugElement) this.debugElement.style.display = "none";
      return;
    }
    if (!this.debugElement) {
      this.debugElement = document.createElement("pre");
      this.debugElement.style.cssText = "position:fixed;right:24px;bottom:24px;z-index:30;max-width:340px;padding:12px;border:1px solid rgba(190,218,244,.25);border-radius:8px;background:rgba(4,8,14,.82);color:#d8e8f6;font:11px/1.35 ui-monospace,SFMono-Regular,Menlo,monospace;pointer-events:none;white-space:pre-wrap;";
      document.body.appendChild(this.debugElement);
    }
    const lookahead = this.lookaheadState();
    const musicAware = this.musicAwareState();
    const metadataById = this.presetMetadataById();
    const current = lookahead.current || {};
    const future = lookahead.medium || {};
    const queuedName = this.pending ? metadataById.get(this.pending.targetPreset)?.name : "none";
    const presetAge = this.lastPresetStartTime === null ? 0 : Math.max(0, currentTime - this.lastPresetStartTime);
    const minimumPlaySeconds = this.activePresetMinimumPlaySeconds();
    const timingLabel = minimumPlaySeconds > this.maxPresetDuration
      ? `${minimumPlaySeconds.toFixed(1)}s full-play`
      : `${this.minPresetDuration}-${this.maxPresetDuration}s`;
    this.debugElement.style.display = "block";
    this.debugElement.textContent = [
      "Adaptive debug",
      `mode: ${this.transitionMode()}`,
      `energy: ${(current.energy || 0).toFixed(2)} -> ${(future.energy || 0).toFixed(2)}`,
      `brain: build ${(musicAware.buildUp || 0).toFixed(2)} drop ${(musicAware.upcomingDrop || 0).toFixed(2)} calm ${(musicAware.calm || 0).toFixed(2)}`,
      `event: ${this.debug.eventType} ${(this.debug.confidence || 0).toFixed(2)}`,
      `event in: ${this.debug.eventTime ? Math.max(0, this.debug.eventTime - currentTime).toFixed(1) + "s" : "none"}`,
      `preset age: ${presetAge.toFixed(1)}s / ${timingLabel}`,
      `preset: ${metadataById.get(this.activePreset())?.name || this.activePreset()}`,
      `queued: ${queuedName}`,
      `landing in: ${this.debug.landingTime ? Math.max(0, this.debug.landingTime - currentTime).toFixed(1) + "s" : "none"}`,
      `loop: ${this.debug.loopBeats ? this.debug.loopBeats + " beats" : "unsnapped"}`,
      `transition style: ${this.debug.transitionStyle ?? "none"}`,
      `transition in: ${this.debug.secondsUntilTransition === null ? "none" : this.debug.secondsUntilTransition.toFixed(1) + "s"}`,
      `reason: ${this.debug.reason || "none"}`
    ].join("\n");
  }
}
