import { createOfflineAnimationClock } from "./offlineAnimationClock.js";
// Shadow Geometry: Impossible Apertures — the live renderer (preset 397).
//
// Per frame: the director turns the music into the state of the sculptures, the lights and the
// journey; one fullscreen pass (impossibleAperturesShaders.js) renders the current and the next
// station into the frame target, so the normal preset transitions, previews and blits work
// unchanged. The anamorphic lattice's two polytope patterns are baked once per lattice variant
// into distance-field textures.
import { createImpossibleAperturesDirector } from "./impossibleAperturesDirector.js";
import { APERTURE_COS, MEMBRANE_R, LATTICE, ORRERY_CORE, SPACING, clearOfCamera, v3 } from "./impossibleAperturesJourney.js";
import { iaPatternSource, iaSceneSource, PATTERN_EXTENT, PATTERN_SEGMENTS } from "./impossibleAperturesShaders.js";

export const IMPOSSIBLE_APERTURES_ID = 397;
export const IMPOSSIBLE_APERTURES_NAME = "Shadow Geometry: Impossible Apertures";

const LOG_PREFIX = "[ImpossibleApertures]";
const PATTERN_SIZE = 1024;
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, x));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };

// Fixture names select controlled states for visual checks, e.g. ia-s-48-freeze, ia-k2-through.
// Numbers use "m" for minus and "p" for the decimal point: ia-k2-um17p6-freeze.
export function parseImpossibleAperturesFixture(fixture) {
  const controls = {};
  if (!/^ia-/.test(fixture || "")) return controls;
  const num = (text) => Number(text.replace(/^m/, "-").replace("p", "."));
  for (const token of fixture.slice(3).split("-")) {
    let m;
    if ((m = /^s(m?\d+(?:p\d+)?)$/.exec(token))) controls.startS = num(m[1]);
    else if ((m = /^k(\d+)$/.exec(token))) controls.startStation = Number(m[1]);
    else if ((m = /^u(m?\d+(?:p\d+)?)$/.exec(token))) controls.startU = num(m[1]);
    else if ((m = /^v(\d+(?:p\d+)?)$/.exec(token))) controls.speed = num(m[1]);
    else if ((m = /^drop(\d+)$/.exec(token))) controls.dropAt = Number(m[1]);
    else if (token === "freeze") controls.freeze = true;
    else if (token === "high") controls.quality = 1;
    else if (token === "std") controls.quality = 0;
    else if (token === "off") controls.reactive = 0;
    else if (token === "through") controls.through = true;
    else if (token === "nodrops") controls.drops = 0;
    else if (token === "nohaze") controls.haze = 0;
  }
  return controls;
}

export function createImpossibleAperturesRuntime({ getGl, program, setAttribs }) {
  const director = createImpossibleAperturesDirector();
  let offline = false;
  const offlineClock = createOfflineAnimationClock({
    reset: () => { director.reset(); applyStart(); },
    step: (dt, inputs) => director.step(dt, inputs, controls)
  });
  const U = {
    st: new Float32Array(8), stB: new Float32Array(8), stRot: new Float32Array(18), stP: new Float32Array(64),
    stCol: new Float32Array(32), light: new Float32Array(32), lightC: new Float32Array(32)
  };
  let active = false, fatal = "", gpu = null, lastAt = 0, frame = 0, controls = {};
  let reportAt = 0, reportFrames = 0, cpuMs = 0, cpuCount = 0, bakedVariant = -1, startMs = 0;
  const locations = new WeakMap();
  const trial = () => typeof document !== "undefined" && document.body?.classList.contains("preset-trial-role");

  function loc(gl, p, name) {
    let map = locations.get(p);
    if (!map) { map = new Map(); locations.set(p, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(p, name));
    return map.get(name);
  }
  function makePatternTarget(gl) {
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R16F, PATTERN_SIZE, PATTERN_SIZE, 0, gl.RED, gl.HALF_FLOAT, null);
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    if (status !== gl.FRAMEBUFFER_COMPLETE) throw new Error(`pattern framebuffer incomplete (${status})`);
    return { tex, fb };
  }

  // GPU resources (programs, pattern targets) are created once and kept across stop/start, so
  // entering the preset never compiles shaders on a live frame; warm() builds them during Player's
  // pipeline warm-up. They are rebuilt only if the GL context changes or is lost.
  function ensureGpu() {
    const gl = getGl();
    if (gpu && gpu.gl === gl && !gl.isContextLost?.()) return gpu;
    gpu = null; bakedVariant = -1;
    if (!gl.getExtension("EXT_color_buffer_float")) throw new Error("float render targets are unavailable");
    const programs = { scene: program(iaSceneSource), pattern: program(iaPatternSource) };
    for (const [name, value] of Object.entries(programs)) if (!value) throw new Error(`${name} program did not compile`);
    gpu = { gl, programs, patA: makePatternTarget(gl), patB: makePatternTarget(gl) };
    return gpu;
  }

  // Compile and draw every program once into a 1x1 corner of target (forces the driver to finish
  // building its pipelines). The output is discarded by the caller.
  function warm(target) {
    const gl = getGl();
    try {
      const g = ensureGpu();
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, 1, 1);
      gl.disable(gl.BLEND);
      for (const p of [g.programs.pattern, g.programs.scene]) {
        gl.useProgram(p);
        setAttribs(p);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      }
    } catch (error) {
      fatal = String(error?.message || error);
      console.error(`${LOG_PREFIX} warm-up failed:`, error);
    }
  }

  function start() {
    active = true; fatal = ""; frame = 0; lastAt = 0;
    director.reset();
    const query = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("fixture") || "" : "";
    controls = { ...parseImpossibleAperturesFixture(query), ...(controls.external || {}) };
    applyStart();
    if (typeof window !== "undefined") window.__impossibleAperturesControls = controls;
    const begin = performance.now();
    try {
      ensureGpu();
    } catch (error) {
      fatal = String(error?.message || error);
      console.error(`${LOG_PREFIX} GPU setup failed:`, error);
    }
    startMs = performance.now() - begin;
  }
  function applyStart() {
    const s = director.state;
    if (Number.isFinite(controls.startStation)) s.s = controls.startStation * SPACING + (Number.isFinite(controls.startU) ? controls.startU : -66);
    if (Number.isFinite(controls.startS)) s.s = controls.startS;
  }

  function bakePattern(gl, target, pattern, stroke, node) {
    const P = gpu.programs.pattern;
    const segs = new Float32Array(PATTERN_SEGMENTS * 4);
    const list = pattern.segments.slice(0, PATTERN_SEGMENTS);
    list.forEach((seg, i) => segs.set(seg, i * 4));
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, PATTERN_SIZE, PATTERN_SIZE);
    gl.useProgram(P);
    setAttribs(P);
    gl.uniform4fv(loc(gl, P, "uSeg[0]"), segs);
    gl.uniform1i(loc(gl, P, "uCount"), list.length);
    const rings = [0, 0, 0, 0];
    (pattern.rings || []).slice(0, 4).forEach((r, i) => { rings[i] = r; });
    gl.uniform4fv(loc(gl, P, "uRings"), rings);
    gl.uniform1f(loc(gl, P, "uNode"), node || 0);
    gl.uniform1f(loc(gl, P, "uExtent"), PATTERN_EXTENT);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  function ensurePatterns(gl, lattice) {
    if (!lattice || bakedVariant === lattice.variantIndex) return;
    const v = lattice.variant;
    bakePattern(gl, gpu.patA, v.view(), v.strokeA, v.node);
    bakePattern(gl, gpu.patB, v.shadow(), v.strokeB, v.node * 0.8);
    bakedVariant = lattice.variantIndex;
  }

  // ---- director state -> uniforms --------------------------------------------------------------
  function fillStation(slot, station, mode, presence, s, cam) {
    const b = slot * 8, c = station.center, psi = station.psi, E = s.energy;
    const B = clamp(s.breakdown * (1 - s.groove));
    U.st.set([c[0], c[1], c[2], station.typeIndex], slot * 4);
    U.stB.set([presence, MEMBRANE_R, APERTURE_COS, 1.0], slot * 4);
    const cs = Math.cos(psi), sn = Math.sin(psi);
    // world -> sculpture frame: rotate by -psi about the journey axis (lattice: identity)
    // world -> sculpture: rotate by -psi about the journey axis, then (orrery only, after a drop the
    // camera is passing) tilt about the local x axis so the opened poles sweep their beams around.
    const tilt = station.type === "orrery" && slot === 0 ? 1.15 * s.tilt : 0;
    const ct = Math.cos(tilt), st = Math.sin(tilt);
    const rot = station.type === "lattice" ? [1, 0, 0, 0, 1, 0, 0, 0, 1]
      : [cs, -sn * ct, -sn * st, sn, cs * ct, cs * st, 0, -st, ct];
    U.stRot.set(rot, slot * 9);
    const pal = station.palette;
    [pal.surf, pal.sheen, pal.edge, pal.pearl].forEach((col, i) => U.stCol.set([...col, 1], (slot * 4 + i) * 4));
    const P = new Array(32).fill(0);
    const lights = [], lightCols = [], spots = [];
    const kickBand = s.kicks > 0 ? Math.exp(-s.kickAge / 0.55) : 0;
    const main = (0.5 + 0.65 * E) * (1 + 0.45 * s.kickPulse) * (1 - 0.55 * s.preDrop) * (1 + 0.6 * s.flash);
    const colour = (0.22 + 0.95 * E) * (1 - 0.7 * B) * (1 - 0.6 * s.preDrop);
    const toWorld = (x, y, z) => [c[0] + x * cs - y * sn, c[1] + x * sn + y * cs, c[2] + z];
    if (station.type === "orrery") {
      const sh = station.shells, sep = s.orSeparate;
      P.splice(0, 4, sh.rOut * (1 + 0.05 * sep), sh.thOut, sh.rIn * (1 - 0.13 * sep), sh.thIn);
      P.splice(4, 4, sh.K, sh.row, sh.twist, sh.holeOut + s.orHole);
      // Inner apertures: open wide when the music aligns (the projection simplifies to the outer
      // spiral alone), close to sparse points in breakdowns.
      P.splice(8, 4, sh.Kin, sh.rowIn, sh.twistIn, clamp(sh.holeIn + s.orInnerOpen + s.orHole, 0.15, 1.05));
      const fo = s.orFlow, fi = (((s.orDelta % 1) + 1) % 1);
      P.splice(12, 4, fo * sh.row, fo * sh.twist + s.orSpinOut, -fi * sh.rowIn, -fi * sh.twistIn - s.orSpinOut * 0.6);
      P.splice(16, 4, station.poles, mode.iris, ORRERY_CORE, -2.8 + s.kickAge * 7.5);
      P.splice(20, 4, 1.4 * kickBand * (0.5 + 0.5 * E), 0, 0, 0);
      lights.push([...c, 0.12]);
      // The opened poles let the core's light out unobstructed; dim it so the burst keeps its structure.
      const open = clamp((mode.iris - 0.2) / 0.8);
      lightCols.push(pal.lights[0].map((x) => x * 1.25 * main * (1 - 0.4 * open) * presence));
      for (let i = 0; i < 3; i += 1) {
        const a = s.lightOrbit * (i === 2 ? -1.3 : 1) + i * TAU / 3 + 0.4;
        const z = 2.6 * Math.sin(s.lightOrbit * 0.7 + i * 2.1);
        lights.push([...toWorld(9.4 * Math.cos(a), 9.4 * Math.sin(a), z), 0.14]);
        const gate = i === 2 ? smooth(0.5, 0.8, E) : 1;
        lightCols.push(pal.lights[i + 1].map((x) => x * 1.6 * colour * gate * presence));
        // The cone just covers the shells, so the wall only receives light that came through apertures.
        spots[i + 1] = Math.cos(Math.asin(Math.min(0.97, (sh.rOut - 0.3) / Math.hypot(9.4, z))));
      }
    } else if (station.type === "weave") {
      const t = station.torus, br = s.wvBreath;
      P.splice(0, 4, t.R * (1 + 0.025 * br), t.r1 * (1 + 0.05 * br), t.r2 * (1 + 0.035 * br), t.thick);
      P.splice(4, 4, t.n1, t.k1, s.wvPhase1, t.w1);
      P.splice(8, 4, t.n2, t.k2, s.wvPhase2, t.w2);
      const louver = s.wvLouver + 1.25 * s.wvLouverKick;
      P.splice(12, 4, louver, -louver * 0.8, s.wvKickPhi + s.kickAge * 3.2 - psi, 1.3 * kickBand);
      for (let i = 0; i < 4; i += 1) {
        const a = s.lightOrbit * 0.5 + i * TAU / 4 + 0.3;
        lights.push([...toWorld(4.2 * Math.cos(a), 4.2 * Math.sin(a), -22), i === 0 ? 0.1 : 0.08]);
        const k = i === 0 ? 2.2 * main : 1.9 * colour * (i === 3 ? smooth(0.45, 0.75, E) : 1);
        lightCols.push(pal.lights[i].map((x) => x * k * presence));
        // Fitted to the torus as seen from 22 units in front.
        spots[i] = Math.cos(Math.atan((t.R + t.r2 + 1.2) / 22) + 0.08);
      }
    } else {
      const L = station.lattice;
      lights.push([...L.Lstar, 0.045]);
      lightCols.push(pal.lights[0].map((x) => x * 1.35 * main * presence));
      spots[0] = Math.cos(0.36);
      // Coloured lights on the sphere of radius D around the centre, scattered away from L* on the
      // side away from V; they converge on L* (their shadows merging into pattern B) with tension.
      const toV = v3.norm(v3.sub(L.vdir, v3.scale(L.ldir, v3.dot(L.vdir, L.ldir))));
      const side = v3.cross(L.ldir, toV);
      for (let i = 0; i < 3; i += 1) {
        const az = Math.PI + (i - 1) * 1.15 + 0.35 * Math.sin(s.latOrbit + i * 2.0);
        const tangent = v3.add(v3.scale(toV, Math.cos(az)), v3.scale(side, Math.sin(az)));
        const ang = 0.46 * (1 - s.latConverge);
        const dir = v3.norm(v3.add(v3.scale(L.ldir, Math.cos(ang)), v3.scale(tangent, Math.sin(ang))));
        lights.push([...v3.add(c, v3.scale(dir, L.D)), 0.07]);
        lightCols.push(pal.lights[i + 1].map((x) => x * 1.1 * Math.max(colour, 0.5 * s.latConverge) * presence));
        spots[i + 1] = Math.cos(0.36);
      }
    }
    U.stP.set(P, b * 4);
    // Lights step aside smoothly rather than let the camera fly through them.
    for (const l of lights) l.splice(0, 3, ...clearOfCamera(l.slice(0, 3), cam.pos));
    lights.forEach((l, i) => U.light.set(l, (slot * 4 + i) * 4));
    lightCols.forEach((l, i) => U.lightC.set([...l, spots[i] ?? 0], (slot * 4 + i) * 4));
  }

  function render({ target, width, height, now, quality = 0, playing = true, audio = {}, smooth: smoothBands = {}, music = {}, lookahead = {}, tempo = {} }) {
    if (!active) start();
    const stamp = performance.now();
    const gl = getGl();
    const dt = lastAt ? clamp((now - lastAt) / 1000, 0, 0.1) : 1 / 60;
    lastAt = now; frame += 1;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    if (!fatal) {
      try { ensureGpu(); } catch (error) { fatal = String(error?.message || error); }
    }
    if (fatal || !gpu) { gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); publish(now); return; }

    if (!offline) director.step(playing ? dt : 0, { audio, smooth: smoothBands, music, lookahead, tempo }, controls);
    const s = director.state;
    const f = director.frame();
    const cam = f.pose;
    const camZ = cam.pos[2];
    const presenceCur = smooth(MEMBRANE_R + 70, MEMBRANE_R + 8, f.current.center[2] - camZ);
    const presenceNext = smooth(MEMBRANE_R + 70, MEMBRANE_R + 8, f.next.center[2] - camZ);
    fillStation(0, f.current, f.modeCurrent, presenceCur, s, cam);
    fillStation(1, f.next, f.modeNext, presenceNext, s, cam);
    const lattice = f.current.type === "lattice" ? f.current : f.next.type === "lattice" ? f.next : null;

    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.disable(gl.SCISSOR_TEST); gl.disable(gl.BLEND);
    ensurePatterns(gl, lattice?.lattice);

    const q = (controls.quality ?? quality) > 0.5 ? 1 : 0;
    const S = gpu.programs.scene;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    gl.useProgram(S);
    setAttribs(S);
    gl.uniform2f(loc(gl, S, "uRes"), width, height);
    gl.uniform1f(loc(gl, S, "uTime"), s.time);
    gl.uniform1i(loc(gl, S, "uQuality"), q);
    gl.uniform3fv(loc(gl, S, "uCamPos"), cam.pos);
    gl.uniform3fv(loc(gl, S, "uCamFwd"), cam.fwd);
    gl.uniform3fv(loc(gl, S, "uCamRight"), cam.right);
    gl.uniform3fv(loc(gl, S, "uCamUp"), cam.up);
    gl.uniform1f(loc(gl, S, "uFocal"), 1.55);
    gl.uniform4fv(loc(gl, S, "uSt[0]"), U.st);
    gl.uniform4fv(loc(gl, S, "uStB[0]"), U.stB);
    gl.uniformMatrix3fv(loc(gl, S, "uStRot[0]"), false, U.stRot);
    gl.uniform4fv(loc(gl, S, "uStP[0]"), U.stP);
    gl.uniform4fv(loc(gl, S, "uStCol[0]"), U.stCol);
    gl.uniform4fv(loc(gl, S, "uLight[0]"), U.light);
    gl.uniform4fv(loc(gl, S, "uLightC[0]"), U.lightC);
    gl.uniform4f(loc(gl, S, "uMusic"), s.kickPulse, s.bass, s.highs, s.energy);
    gl.uniform4f(loc(gl, S, "uGrade"), s.exposure, s.haze, s.flash * 0.6, s.saturation);
    gl.uniform4f(loc(gl, S, "uGrade2"), 0.35, 1, clamp(s.highs * 0.6 + s.hatGlint * 0.8), 0.6 + 0.8 * s.energy);
    if (lattice) {
      const L = lattice.lattice;
      gl.uniform3fv(loc(gl, S, "uLatC"), lattice.center);
      gl.uniform4f(loc(gl, S, "uLatV"), ...L.V, L.D);
      gl.uniform4f(loc(gl, S, "uLatL"), ...L.Lstar, L.D);
      gl.uniformMatrix3fv(loc(gl, S, "uLatMA"), false, L.frameA.mat);
      gl.uniformMatrix3fv(loc(gl, S, "uLatMB"), false, L.frameB.mat);
      gl.uniform4f(loc(gl, S, "uLatP"), LATTICE.radius, L.variant.strokeA, L.variant.strokeB, LATTICE.bound);
      const alignDist = v3.len(v3.sub(cam.pos, L.V));
      gl.uniform4f(loc(gl, S, "uLatK"), s.latKickR, Math.exp(-s.kickAge / 0.6) * (0.4 + 0.8 * s.energy), Math.exp(-((alignDist / 1.4) ** 2)) + 0.5 * s.latSnap, PATTERN_EXTENT);
      s.alignDist = alignDist;
    }
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, gpu.patA.tex);
    gl.uniform1i(loc(gl, S, "uPatA"), 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, gpu.patB.tex);
    gl.uniform1i(loc(gl, S, "uPatB"), 1);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.activeTexture(gl.TEXTURE0);

    cpuMs += performance.now() - stamp; cpuCount += 1;
    publish(now, { width, height, quality: q ? "high" : "standard", station: f.k, type: f.current.type, u: +(camZ - f.current.center[2]).toFixed(2) });
  }

  function publish(now, extra = {}) {
    if (now - reportAt < (trial() ? 1000 : 3000)) return;
    const fps = reportAt ? (frame - reportFrames) * 1000 / (now - reportAt) : 0;
    reportAt = now; reportFrames = frame;
    const s = director.state;
    const diagnostics = {
      fatal, fps, cpuMs: cpuMs / Math.max(1, cpuCount), startMs: +startMs.toFixed(1), ...extra,
      t: +s.time.toFixed(1), s: +s.s.toFixed(1), speed: +s.speed.toFixed(2), phase: s.phase,
      energy: +s.energy.toFixed(2), groove: +s.groove.toFixed(2), breakdown: +s.breakdown.toFixed(2), build: +s.build.toFixed(2),
      tension: +s.tension.toFixed(2), future: +s.future.toFixed(2), kicks: s.kicks, hats: s.hats, drops: s.drops, throughs: s.throughs,
      alignDist: s.alignDist === undefined ? null : +s.alignDist.toFixed(2), beatSource: director.audioState.beatSource, controls
    };
    if (typeof window !== "undefined") window.__impossibleAperturesDiagnostics = diagnostics;
    cpuMs = 0; cpuCount = 0;
    if (trial()) window.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "info", text: `${LOG_PREFIX} ${JSON.stringify(diagnostics)}` });
  }

  // Leaving the preset ends the journey; the GPU resources stay for the next visit.
  function stop() {
    if (!active) return;
    active = false; offline = false; offlineClock.end();
    if (typeof window !== "undefined") window.__impossibleAperturesDiagnostics = window.__impossibleAperturesControls = null;
  }

  // External controls (offline capture tools) override fixture tokens; applied on the next start.
  function setControls(next) { controls = { ...controls, ...next, external: next }; if (active) applyStart(); }

  async function prepareOffline(time, options) {
    if (!active) start();
    offline = true;
    await offlineClock.advanceAsync(time, options);
  }
  function endOffline() { offline = false; offlineClock.end(); lastAt = 0; }
  return { render, stop, warm, prepareOffline, endOffline, director, controls: () => controls, setControls, isActive: () => active };
}
