export function setSplashProgress(ui, progress, status) {
  const clamped = Math.max(0, Math.min(1, progress));
  const percent = Math.round(clamped * 100);
  if (ui.engineSplashStatus && status) ui.engineSplashStatus.textContent = status;
  if (ui.engineSplashBar) ui.engineSplashBar.style.width = `${percent}%`;
  if (ui.engineSplashPercent) ui.engineSplashPercent.textContent = `${percent}%`;
}

export function waitForNextPaint() {
  return new Promise((resolve) => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      resolve();
    };
    requestAnimationFrame(finish);
    // A prewarmed renderer may live in an ordered-out AppKit window. WebKit
    // can suspend rAF for that surface even though explicit WebGL compilation
    // remains available, so warmup must not depend on a presented frame.
    window.setTimeout(finish, 50);
  });
}

export function waitMs(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

export function setAppReadyState({ ui, ready, onReadyStateChanged }) {
  window.__cyanescentFullAppReady = ready;
  document.body.classList.toggle("engine-booting", !ready);
  document.body.classList.toggle("engine-ready", ready);
  ui.engineSplash?.classList.toggle("hidden", ready);
  onReadyStateChanged?.(ready);
  if (ready && window.__cyanescentUiPreviewActive) {
    window.__cyanescentUiPreviewStage?.("app-ready-event-dispatched");
    window.dispatchEvent(new CustomEvent("cyanescent-app-ready"));
  }
}

export function createSplashProgressSetter(ui) {
  return function setProgress(progress, status) {
    setSplashProgress(ui, progress, status);
  };
}

export function createAppReadySetter({ ui, onReadyStateChanged }) {
  return function setReady(ready) {
    setAppReadyState({ ui, ready, onReadyStateChanged });
  };
}

export function createInitialBootActionProcessor({
  target = window,
  loadPlayerFiles,
  loadNativeTracks,
  enterFullscreen,
  initializeDefaultFolderOptions,
  reportPlayerError
} = {}) {
  let handled = false;
  return function processPendingInitialBootActions() {
    if (handled) return;
    handled = true;

    if (target.__pendingPlayerFiles?.length) {
      const files = target.__pendingPlayerFiles.splice(0);
      loadPlayerFiles?.(files).catch((error) => reportPlayerError?.("Could not load track", error));
    }

    if (target.__pendingNativeTracks) {
      const pending = target.__pendingNativeTracks;
      target.__pendingNativeTracks = null;
      const batches = pending.batches || [{tracks: Array.isArray(pending) ? pending : pending.tracks,
        options: Array.isArray(pending) ? {} : pending.options || {}}];
      // A deliberate picker/drop supersedes an automatic boot scan, while all
      // deliberate batches append in arrival order even if one load fails.
      const explicit = batches.some(batch => batch.options.source !== 'default-startup');
      void (async () => {
        for (const {tracks, options} of batches) {
          if (!tracks?.length || (explicit && options.source === 'default-startup')) continue;
          try { await loadNativeTracks?.(tracks, options); }
          catch (error) { reportPlayerError?.('Could not load track', error); }
        }
      })();
    }

    if (target.__pendingFullscreenLaunch) {
      target.__pendingFullscreenLaunch = false;
      enterFullscreen?.();
    }

    initializeDefaultFolderOptions?.();
  };
}

export function createVisualEngineBootRunner({
  ui,
  setAppReady,
  setProgress,
  createRenderer,
  warmGeometry,
  warmPresetModules,
  warmFullShader,
  allocateFrameBuffers,
  finalizeReady,
  finalizeError,
  finalizeErrorReady
}) {
  let warmupPromise = null;
  // quiet: warm up on demand (the main window's export renderer) without the startup
  // splash or leaving the ready state; the app stays usable while it runs.
  return async function warmVisualEngineAtStartup({ quiet = false } = {}) {
    if (warmupPromise) return warmupPromise;
    window.__cyanescentUiPreviewStage?.("visual-warmup-started");
    if (!quiet) setAppReady(false);
    warmupPromise = (async () => {
      try {
        setProgress(0.01, "Creating visual renderer");
        await waitForNextPaint();
        createRenderer();

        await warmGeometry();
        await warmPresetModules();
        await warmFullShader();

        setProgress(0.98, "Allocating frame buffers");
        await waitForNextPaint();
        await allocateFrameBuffers();

        setProgress(0.99, "Finalizing visual timeline");
        await waitForNextPaint();
        await waitMs(160);
        setProgress(1, "Visual engine ready");
        await waitMs(180);
        setAppReady(true);
        window.__cyanescentUiPreviewStage?.("visual-warmup-completed");
        finalizeReady?.();
        return true;
      } catch (error) {
        const fallbackActive = Boolean(finalizeError?.(error));
        setProgress(1, fallbackActive ? "Backup visual engine ready" : "Visual engine failed");
        console.error(error);
        await waitMs(350);
        setAppReady(true);
        window.__cyanescentUiPreviewStage?.("visual-warmup-fallback-completed");
        finalizeErrorReady?.();
        return false;
      }
    })();
    return warmupPromise;
  };
}

export function createStartupWarmupTasks({
  setProgress,
  waitForPaint = waitForNextPaint,
  ensureGeometryResources,
  ensurePineResources,
  ensureAdditionalGeometryResources,
  warmPresetModules,
  isFullShaderReady,
  startFullShaderCompile,
  fullShaderStatus,
  compileFullShaderSynchronously,
  waitForFullShaderReady
}) {
  async function warmGeometry() {
    setProgress(0.03, "Preparing geometry renderers");
    await waitForPaint();
    ensureGeometryResources?.();
    setProgress(0.06, "Preparing botanical and molecular geometry");
    await waitForPaint();
    ensurePineResources?.();
    ensureAdditionalGeometryResources?.();
  }

  async function warmPresetRegistry() {
    setProgress(0.08, "Preparing preset registry");
    await waitForPaint();
    setProgress(0.10, "Compiling modular presets");
    await waitForPaint();
    if (warmPresetModules) {
      await warmPresetModules((ratio, status) => {
        // Map 0-1 ratio to 0.10-0.95 progress range
        setProgress(0.10 + (ratio * 0.85), status);
      });
    }
    setProgress(0.96, "Preset modules ready");
    await waitForPaint();
  }

  async function warmFullShader() {
    if (isFullShaderReady?.()) return;
    setProgress(0.97, "Compiling full visual shader pack");
    await waitForPaint();
    startFullShaderCompile?.();
    if (fullShaderStatus?.() === "unsupported") {
      setProgress(0.97, "Compiling visual shader pack");
      await waitForPaint();
      compileFullShaderSynchronously?.();
      return;
    }
    await waitForFullShaderReady?.();
  }

  return {
    warmGeometry,
    warmPresetRegistry,
    warmFullShader
  };
}
