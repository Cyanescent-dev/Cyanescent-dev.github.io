export const helixCopySource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uVideo;
void main(){outColor=texture(uVideo,vUv);}`;
export const helixCompositeSource = `#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uVideo, uHistoryA, uHistoryB;
uniform sampler2D uFieldA0, uFieldB0, uFieldA1, uFieldB1;
uniform float uHistory, uHistoryMix, uFieldMix, uPresence, uStartup;
uniform vec2 uResolution, uVideoSize;
uniform vec3 uPosition, uForward, uRight, uUp;
uniform vec3 uRefPosition0, uRefForward0, uRefRight0, uRefUp0;
uniform vec3 uRefPosition1, uRefForward1, uRefRight1, uRefUp1;
uniform vec2 uRefTurns;
uniform float uReproject;
vec2 imageUv0, imageUv1;
uniform float uTan, uAspect, uTime, uEnergy, uTension, uFlash, uKick, uBass, uMids, uHighs, uHat;
uniform vec4 uAmounts; // pulses, glow, shockwaves, circuits
uniform vec2 uPolish; // compression, bloom
uniform vec4 uPackets[16]; // relative turn, width, amplitude, strand (0/1/2 both)
uniform vec4 uWaves[2]; // ahead along axis, clear radius, strength, width
uniform int uDebug, uQuality;
struct Field { float kind; float coverage; float lit; vec2 flow; float turn; float depth; };
Field decode(sampler2D a, sampler2D b, ivec2 p){
  ivec2 size=textureSize(a,0); p=clamp(p,ivec2(0),size-1);
  vec4 x=texelFetch(a,p,0); vec2 geometry=texelFetch(b,p,0).rg;
  uint flags=uint(round(x.r*255.0));
  Field f; f.kind=float(flags & 7u); f.coverage=float(flags >> 3u)/31.0;
  f.lit=x.g; f.flow=x.ba*2.0-1.0;
  f.turn=geometry.x; f.depth=geometry.y;
  return f;
}
bool agree(Field a,Field b){return a.kind==b.kind && abs(a.turn-b.turn)<.14 && abs(a.depth-b.depth)<max(1.2,a.depth*.10);}
Field blendField(Field a,Field b,float t){
  Field f=a; if(t>=.5)f=b;
  if(agree(a,b)){
    f.coverage=mix(a.coverage,b.coverage,t); f.lit=mix(a.lit,b.lit,t);
    f.flow=mix(a.flow,b.flow,t); f.turn=mix(a.turn,b.turn,t); f.depth=mix(a.depth,b.depth,t);
  }else{
    f.coverage=mix(a.coverage,b.coverage,t); f.lit=mix(a.lit,b.lit,t);
  }
  return f;
}
Field spatial(sampler2D a,sampler2D b,vec2 uv){
  vec2 p=uv*vec2(textureSize(a,0))-.5; ivec2 q=ivec2(floor(p)); vec2 t=fract(p);
  Field f00=decode(a,b,q), f10=decode(a,b,q+ivec2(1,0)), f01=decode(a,b,q+ivec2(0,1)), f11=decode(a,b,q+ivec2(1));
  return blendField(blendField(f00,f10,t.x),blendField(f01,f11,t.x),t.y);
}
vec3 viewRay(vec2 uv,vec3 forward,vec3 right,vec3 up){
  return normalize(forward+right*(2.0*uv.x-1.0)*uAspect*uTan+up*(1.0-2.0*uv.y)*uTan);
}
vec2 projectRay(vec3 ray,vec3 forward,vec3 right,vec3 up){
  float z=max(.001,dot(ray,forward));
  return vec2(.5+.5*dot(ray,right)/(z*uAspect*uTan),.5-.5*dot(ray,up)/(z*uTan));
}
// Backward gather from the actual two decoded source cameras. Exported depth
// supplies translation; flow.RG is never treated as optical flow. Two bounded
// corrections are enough for these small source-frame camera separations.
vec2 referenceUv(sampler2D depth,vec2 uv,vec3 pos,vec3 forward,vec3 right,vec3 up){
  vec3 targetRay=viewRay(uv,uForward,uRight,uUp);
  vec2 q=projectRay(targetRay,forward,right,up); vec2 initial=q;
  if(uReproject<.5)return uv;
  for(int k=0;k<2;k++){
    float d=texture(depth,clamp(q,vec2(0),vec2(1))).g;
    if(d<.1 || d>280.0)break;
    vec3 ray=viewRay(q,forward,right,up);
    vec3 hit=pos+ray*d/max(.08,dot(ray,forward));
    vec2 projected=projectRay(hit-uPosition,uForward,uRight,uUp);
    q+=clamp(uv-projected,vec2(-.055),vec2(.055));
  }
  // Bound translation at silhouettes: the reduced depth field cannot infer
  // newly exposed detail. Camera rotation remains fully compensated.
  vec2 bound=vec2(3.0)/uVideoSize;
  return clamp(clamp(q,initial-bound,initial+bound),vec2(.0001),vec2(.9999));
}
void mapImages(vec2 uv){
  imageUv0=referenceUv(uFieldB0,uv,uRefPosition0,uRefForward0,uRefRight0,uRefUp0);
  imageUv1=referenceUv(uFieldB1,uv,uRefPosition1,uRefForward1,uRefRight1,uRefUp1);
}
Field referencedField(sampler2D a,sampler2D b,vec2 uv,vec3 pos,vec3 forward,vec3 right,vec3 up,float turn){
  Field f=spatial(a,b,uv);
  vec3 ray=viewRay(uv,forward,right,up);
  vec3 hit=pos+ray*f.depth/max(.08,dot(ray,forward));
  f.depth=dot(hit-uPosition,uForward); f.turn+=turn;
  return f;
}
Field fieldAt(vec2 uv){
  mapImages(uv);
  Field a=referencedField(uFieldA0,uFieldB0,imageUv0,uRefPosition0,uRefForward0,uRefRight0,uRefUp0,uRefTurns.x);
  Field b=referencedField(uFieldA1,uFieldB1,imageUv1,uRefPosition1,uRefForward1,uRefRight1,uRefUp1,uRefTurns.y);
  return blendField(a,b,uHistoryMix);
}
vec3 beauty(vec2 offset){
  vec3 a=texture(uHistoryA,imageUv0+offset).rgb;
  vec3 b=texture(uHistoryB,imageUv1+offset).rgb;
  return mix(a,b,uHistoryMix);
}
void main(){
  // Same aspect-fit and top-left coordinates as the decoder and Forge fields.
  float canvasAspect=uResolution.x/uResolution.y;
  vec2 uv=vec2(vUv.x,1.0-vUv.y);
  if(canvasAspect>uAspect)uv.x=(uv.x-.5)*canvasAspect/uAspect+.5;
  else uv.y=(uv.y-.5)*uAspect/canvasAspect+.5;
  if(any(lessThan(uv,vec2(0)))||any(greaterThan(uv,vec2(1)))){outColor=vec4(.002,.001,.006,1);return;}
  Field f=fieldAt(uv);
  vec3 ray=normalize(uForward+uRight*(2.0*uv.x-1.0)*uAspect*uTan+uUp*(1.0-2.0*uv.y)*uTan);
  // Project world +z through the current exported basis. This is the tunnel's
  // vanishing point, not necessarily the image centre.
  vec2 axis=vec2(.5+.5*dot(vec3(0,0,1),uRight)/(dot(vec3(0,0,1),uForward)*uTan*uAspect),
                 .5-.5*dot(vec3(0,0,1),uUp)/(dot(vec3(0,0,1),uForward)*uTan));
  vec3 ringLight=vec3(0); float compression=0.0;
  for(int i=0;i<2;i++){
    vec4 w=uWaves[i]; if(w.z<.001)continue;
    // Intersection with the world-axis plane at the wave's depth. Off-axis
    // cameras produce projected ellipses and moving centres automatically.
    float distance=w.x/max(.08,ray.z);
    vec2 worldXY=uPosition.xy+ray.xy*distance;
    float radial=length(worldXY)-w.y;
    float waveDepth=distance*dot(ray,uForward);
    float visible=1.0-smoothstep(.0,1.2,waveDepth-f.depth);
    if(f.coverage<.1)visible=1.0;
    // A thin, antialiased conductor with a tight halo. Angular current bands
    // give the double wave material detail without filling the corridor with
    // a broad uniform blue disc. Both strands' colours meet at pale hot edges.
    float width=max(w.w,.65*fwidth(radial));
    float core=exp(-pow(radial/width,2.0));
    float filament=exp(-pow((radial+width*1.8)/(width*.4),2.0));
    float halo=exp(-pow(radial/(width*2.8),2.0));
    float angle=atan(worldXY.y,worldXY.x);
    float bands=.70+.30*cos(angle*8.0-w.x*.075);
    vec3 waveTint=mix(vec3(.15,.80,1.0),vec3(1.0,.18,.63),.5+.5*sin(angle*2.0+w.x*.035));
    float fog=exp(-w.x/160.0);
    ringLight+=(mix(waveTint,vec3(.86,.97,1),.7)*core*.85+waveTint*(halo*.10+filament*.18))*bands*w.z*visible*fog;
    // Travelling squeeze restricted to the actual surface-depth slice. The
    // same UV displacement is applied to beauty AND reactive attachments.
    float band=exp(-pow((f.depth-waveDepth)/max(2.0,w.x*.075),2.0));
    compression+=band*w.z*.0032;
  }
  vec2 displaced=clamp(uv+(uv-axis)*compression*uPolish.x*uPresence,vec2(.001),vec2(.999));
  if(compression*uPolish.x*uPresence>.00001)f=fieldAt(displaced);
  vec3 base=beauty(vec2(0));
  float lit=f.lit*f.coverage;
  // Reinforce only coloured source highlights under the exported luminous
  // mask, so reduced-resolution field silhouettes never paint the open sky.
  float colourLight=max(base.g,base.b)-base.r*.25;
  float sourceLight=smoothstep(.16,.50,colourLight);
  float structure=(f.kind>0.5?1.0:0.0)*f.coverage;
  // Source-colour evidence recovers near-camera luminous rails lost between
  // reduced-resolution mask texels. Still clipped by actual structure class.
  lit=max(lit*sourceLight,sourceLight*structure*.42);
  float foreground=1.0+.65*exp(-max(0.0,f.depth)/28.0);
  lit*=foreground;
  vec3 light=vec3(0);
  // Evaluate emissive machinery only under its actual visible light mask.
  // Most beauty pixels have no current: avoid sixteen Gaussian/pow paths there.
  if(lit>.001){
  float packets=0.0;
  for(int i=0;i<16;i++){
    vec4 p=uPackets[i];
    if(p.z<.001)continue;
    float strand=p.w>1.5?1.0:(abs(f.kind-(p.w+1.0))<.3?1.0:0.0);
    float distance=abs(f.turn-p.x), width=max(.02,p.y);
    if(strand<.5 || distance>width*3.5)continue;
    packets+=exp(-pow(distance/width,2.0))*p.z;
  }
  float current=(.08+.85*uBass+.24*uTension)*uAmounts.y;
  float breath=.8+.2*sin(uTime*.7+f.turn*8.0);
  float ticks=pow(max(0.0,sin(f.turn*205.0-uTime*(12.0+26.0*uHighs)+atan(f.flow.y,f.flow.x)*2.0)),22.0);
  ticks*=pow(max(0.0,sin(f.turn*31.0-uTime*3.0)),4.0);
  float circuitry=ticks*(.12*uHighs+1.0*uHat)*uAmounts.w;
  vec3 tint=f.kind<1.5?vec3(.12,.78,1.0):vec3(1.0,.16,.67);
  // Bridges keep the source's local cyan/magenta palette.
  if(f.kind>2.5)tint=mix(vec3(.16,.62,1),vec3(1,.18,.58),smoothstep(.25,.6,base.r));
  light=lit*tint*(current*breath+packets*uAmounts.x*(.8+.8*uMids)+circuitry);
  light+=lit*mix(tint,vec3(.82,.95,1),uFlash*.7)*(uKick*.78+uFlash*1.15);
  }
  light+=ringLight*uAmounts.z;
  // Bloom samples source luminous detail, not whole-screen exposure. High
  // adds diagonals; Standard has a bounded four-tap halo.
  vec2 px=vec2(2.0)/uVideoSize;
  vec3 halo=vec3(0);
  if(structure>.001 && uPresence>.001){
  halo+=max(beauty(vec2(px.x,0))-.48,0.0);
  halo+=max(beauty(-vec2(px.x,0))-.48,0.0);
  halo+=max(beauty(vec2(0,px.y))-.48,0.0);
  halo+=max(beauty(-vec2(0,px.y))-.48,0.0);
  if(uQuality>0){
    halo+=max(beauty(px)-.48,0.0);halo+=max(beauty(-px)-.48,0.0);
    halo*=.6667;
  }
  }
  // Give already-bright foreground rails headroom: quiet music dims their
  // own luminous pixels, then bass and ordinary kicks energise those pixels.
  // This is masked local current, not global exposure or a screen overlay.
  base*=mix(1.0,.56+.50*uBass+.30*uKick+.30*uFlash,
    clamp(sourceLight*structure*uPresence*uAmounts.y,0.0,1.0));
  vec3 c=base*(.89+.12*uEnergy)+light*uPresence;
  c+=halo*.18*uPolish.y*(.2+uBass+.6*uFlash)*structure*uPresence;
  c+=light*uPresence*.15*uPolish.y;
  // Soft shoulder preserves the dark purple identity and controlled pale peaks.
  c=c/(1.0+max(c-vec3(.8),0.0)*.55);
  if(uDebug==1)c=mix(base,vec3(f.kind/4.0,f.coverage,f.lit),.72);
  if(uDebug==2)c=vec3(f.flow*.5+.5,f.lit)*structure;
  if(uDebug==3)c=vec3(fract(f.turn),clamp(f.depth/100.,0.,1.),lit);
  if(uDebug==4){
    c=base*.35+light;
    float crossMark=max(1.0-smoothstep(.001,.002,abs(uv.x-axis.x)),1.0-smoothstep(.001,.002,abs(uv.y-axis.y)));
    c+=vec3(.2,.9,.55)*crossMark*.35;
  }
  outColor=vec4(max(c,vec3(0))*uStartup,1);
}`;
