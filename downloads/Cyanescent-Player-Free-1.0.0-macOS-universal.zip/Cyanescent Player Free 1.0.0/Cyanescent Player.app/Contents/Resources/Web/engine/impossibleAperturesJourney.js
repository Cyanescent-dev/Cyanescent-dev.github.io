// Shadow Geometry: Impossible Apertures — the journey (pure JS, no GL, testable).
//
// The camera travels along +z through a chain of stations, one sculpture each, every station
// enclosed in a pearl membrane (a sphere with apertures where the journey axis crosses it). The
// lateral path inside a station is choreographed for its sculpture, in the spirit of the original
// Shadow Geometry's sg_camPos: approach along the axis of symmetry (the object reads as a flat
// mandala), slide sideways (it opens into three dimensions), pass beside or through it, return to
// the axis and leave through the exit aperture, where the next lantern is already glowing.

const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, x));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
// Cosine bell: 1 at 0, 0 beyond |u| = w, C1 everywhere.
export const bell = (u, w) => (Math.abs(u) >= w ? 0 : 0.5 + 0.5 * Math.cos(Math.PI * u / w));

export const SPACING = 108;
export const MEMBRANE_R = 44;
export const APERTURE_DEG = 21;
export const APERTURE_COS = Math.cos(APERTURE_DEG * Math.PI / 180);
export const TYPES = Object.freeze(["orrery", "weave", "lattice"]);
// Orrery: the core's radius, and the polar angle beyond which an opened iris keeps radial struts
// (the fly-through path stays well inside it).
export const ORRERY_CORE = 0.32;
export const IRIS_STRUT_START = 0.6;

// ---- vectors ----------------------------------------------------------------------------------
export const v3 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  scale: (a, k) => [a[0] * k, a[1] * k, a[2] * k],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: (a) => Math.hypot(a[0], a[1], a[2]),
  norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
  lerp: (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]
};

// Direction at polar angle theta from -z, azimuth psi about z.
export const polarDir = (theta, psi) => [Math.sin(theta) * Math.cos(psi), Math.sin(theta) * Math.sin(psi), -Math.cos(theta)];

// Rows (right, up, forward) as a column-major mat3 that maps world vectors into that frame.
export function frameMatrix(fwd, upHint = [0, 1, 0], roll = 0) {
  const f = v3.norm(fwd);
  let r = v3.cross(f, upHint);
  if (v3.len(r) < 1e-4) r = v3.cross(f, [1, 0, 0]);
  r = v3.norm(r);
  let u = v3.cross(r, f);
  if (roll) {
    const c = Math.cos(roll), s = Math.sin(roll);
    [r, u] = [v3.add(v3.scale(r, c), v3.scale(u, s)), v3.add(v3.scale(u, c), v3.scale(r, -s))];
  }
  return { right: r, up: u, fwd: f, mat: Float32Array.from([r[0], u[0], f[0], r[1], u[1], f[1], r[2], u[2], f[2]]) };
}
// Up reference for the camera: world up, leaning towards the direction of travel (+z) as the view
// steepens, so a camera looking straight down at a sculpture keeps "forward" at the top of the
// frame. [0, 1, -1.5 fy] is never parallel to a unit view direction, so the frame never flips.
export const upHintFor = (fwd) => [0, 1, -1.5 * fwd[1]];
export const rotZ = (a) => { const c = Math.cos(a), s = Math.sin(a); return Float32Array.from([c, -s, 0, s, c, 0, 0, 0, 1]); };

// ---- patterns: Petrie projections of polytopes ------------------------------------------------
// The anamorphic lattice resolves into the shadow of a higher-dimensional polytope: the n-cube
// projected onto its Coxeter (Petrie) plane, basis e_k -> (cos k pi/n, sin k pi/n), or the
// n-simplex (the complete graph on n+1 points of a circle). Normalised so the rim radius is 1.
export function hypercubePetrie(n, rotation = 0) {
  const verts = [];
  for (let m = 0; m < 1 << n; m += 1) {
    let x = 0, y = 0;
    for (let k = 0; k < n; k += 1) {
      const s = (m >> k) & 1 ? 1 : -1, a = k * Math.PI / n + rotation;
      x += s * Math.cos(a); y += s * Math.sin(a);
    }
    verts.push([x, y]);
  }
  const radius = Math.max(...verts.map(([x, y]) => Math.hypot(x, y)));
  const segments = [];
  for (let m = 0; m < 1 << n; m += 1) for (let k = 0; k < n; k += 1) {
    const m2 = m ^ (1 << k);
    if (m < m2) segments.push([...verts[m], ...verts[m2]].map((v) => v / radius));
  }
  return { segments, rings: [], name: `${n}-cube` };
}
export function simplexPetrie(n, rotation = 0) {
  const count = n + 1;
  const verts = Array.from({ length: count }, (_, j) => [Math.cos(TAU * j / count + rotation), Math.sin(TAU * j / count + rotation)]);
  const segments = [];
  for (let i = 0; i < count; i += 1) for (let j = i + 1; j < count; j += 1) segments.push([...verts[i], ...verts[j]]);
  return { segments, rings: [], name: `${n}-simplex` };
}

// Pattern pairs for successive lattice stations: what the sculpture shows from V, what its shadow
// shows under L*. The two always differ in symmetry, so the second revelation is a different one.
export const LATTICE_VARIANTS = Object.freeze([
  { view: () => hypercubePetrie(5, Math.PI / 2), shadow: () => simplexPetrie(6, Math.PI / 2), strokeA: 0.011, strokeB: 0.014, node: 0.02 },
  { view: () => hypercubePetrie(4, Math.PI / 2), shadow: () => simplexPetrie(8, Math.PI / 2), strokeA: 0.013, strokeB: 0.011, node: 0.024 },
  { view: () => simplexPetrie(10, Math.PI / 2), shadow: () => hypercubePetrie(5, 0), strokeA: 0.009, strokeB: 0.011, node: 0.018 }
]);

// ---- stations -----------------------------------------------------------------------------------
const PALETTES = Object.freeze({
  orrery: [
    { surf: [0.020, 0.017, 0.032], sheen: [0.52, 0.34, 1.0], edge: [0.30, 0.95, 1.0], pearl: [0.80, 0.82, 0.96],
      lights: [[1.0, 0.76, 0.42], [0.20, 0.92, 0.95], [0.62, 0.30, 1.0], [1.0, 0.55, 0.22]] },
    { surf: [0.014, 0.026, 0.024], sheen: [0.20, 0.95, 0.70], edge: [1.0, 0.45, 0.85], pearl: [0.80, 0.92, 0.88],
      lights: [[1.0, 0.90, 0.70], [1.0, 0.30, 0.75], [0.25, 1.0, 0.65], [0.55, 0.45, 1.0]] }
  ],
  weave: [
    { surf: [0.80, 0.77, 0.74], sheen: [0.60, 0.80, 1.0], edge: [1.0, 0.70, 0.35], pearl: [0.82, 0.86, 0.92],
      lights: [[1.0, 0.88, 0.66], [0.18, 0.90, 0.95], [0.66, 0.32, 1.0], [1.0, 0.36, 0.62]] },
    { surf: [0.70, 0.74, 0.80], sheen: [1.0, 0.70, 0.90], edge: [0.35, 1.0, 0.80], pearl: [0.90, 0.84, 0.92],
      lights: [[1.0, 0.92, 0.75], [1.0, 0.55, 0.20], [0.30, 0.95, 0.55], [0.40, 0.50, 1.0]] }
  ],
  lattice: [
    { surf: [0.95, 0.80, 0.56], sheen: [1.0, 0.86, 0.62], edge: [1.0, 0.88, 0.62], pearl: [0.88, 0.85, 0.82],
      lights: [[1.0, 0.92, 0.78], [0.95, 0.28, 0.90], [0.18, 0.95, 0.88], [1.0, 0.70, 0.20]] },
    { surf: [0.86, 0.88, 0.95], sheen: [0.70, 0.90, 1.0], edge: [0.55, 0.95, 1.0], pearl: [0.86, 0.86, 0.94],
      lights: [[0.95, 0.96, 1.0], [1.0, 0.45, 0.20], [0.35, 0.40, 1.0], [0.30, 1.0, 0.50]] }
  ]
});

// Lattice geometry: V and L* at equal distance from the centre, separated by gamma, each outside
// the other's cone. The two cones overlap without limit behind the centre, so the sculpture is cut
// by a bound sphere; tools/test-impossible-apertures.mjs checks that the first crossing of almost
// every ray of either pattern lies inside it, so the view from V and the shadow from L* stay
// complete (measured: every first crossing within 10.3 of the centre).
export const LATTICE = Object.freeze({ D: 21, thetaV: 0.58, gamma: 0.70, radius: 6.6, bound: 10.6 });

export function stationAt(k) {
  const type = TYPES[((k % 3) + 3) % 3];
  const variant = Math.floor(k / 3);
  const center = [0, 0, k * SPACING];
  // A golden-angle turn per station so successive approaches never look the same.
  const psi = (k * 2.39996) % TAU;
  const palette = PALETTES[type][((variant % 2) + 2) % 2];
  const station = { k, type, typeIndex: TYPES.indexOf(type), variant, center, psi, palette };
  if (type === "orrery") {
    const K = [13, 17, 11][((variant % 3) + 3) % 3];
    const sp = TAU / K;
    // The inner shell carries the mirror lattice with more apertures: seen from the core, the two
    // spirals cross into a moire whose symmetry changes as they turn against each other.
    const Ki = K + 4, spi = TAU / Ki;
    station.shells = {
      rOut: 7.0, thOut: 0.24, rIn: 5.15, thIn: 0.20,
      K, row: sp * 0.92, twist: sp * (0.5 + (variant % 2 ? -0.11 : 0.13)), holeOut: 0.66,
      Kin: Ki, rowIn: spi * 0.92, twistIn: -spi * (0.5 + (variant % 2 ? -0.11 : 0.13)), holeIn: 0.62
    };
    station.poles = 2.35;
  } else if (type === "weave") {
    const variants = [[14, 1, 20, -1], [12, 1, 18, -1], [16, 1, 22, -1]];
    const [n1, k1, n2, k2] = variants[((variant % 3) + 3) % 3];
    station.torus = { R: 7.6, r1: 2.0, r2: 3.25, thick: 0.07, n1, k1, n2, k2, w1: 0.62, w2: 0.58 };
    station.through = variant % 2 === 0;
  } else {
    const L = LATTICE;
    const vdir = polarDir(L.thetaV, psi);
    // L* sits at the same polar angle, rotated in azimuth so the angle V-centre-L* is gamma.
    const cosDpsi = (Math.cos(L.gamma) - Math.cos(L.thetaV) ** 2) / Math.sin(L.thetaV) ** 2;
    const ldir = polarDir(L.thetaV, psi + Math.acos(clamp(cosDpsi, -1, 1)));
    station.lattice = {
      ...L, vdir, ldir,
      V: v3.add(center, v3.scale(vdir, L.D)),
      Lstar: v3.add(center, v3.scale(ldir, L.D)),
      variant: LATTICE_VARIANTS[((variant % LATTICE_VARIANTS.length) + LATTICE_VARIANTS.length) % LATTICE_VARIANTS.length],
      variantIndex: ((variant % LATTICE_VARIANTS.length) + LATTICE_VARIANTS.length) % LATTICE_VARIANTS.length
    };
    // Where pattern B lands: the ray from L* through the centre meets the membrane.
    const toward = v3.scale(ldir, -1), oc = v3.sub(station.lattice.Lstar, center);
    const bq = v3.dot(oc, toward), cq = v3.dot(oc, oc) - MEMBRANE_R * MEMBRANE_R;
    station.lattice.shadowCentre = v3.add(station.lattice.Lstar, v3.scale(toward, -bq + Math.sqrt(bq * bq - cq)));
    station.lattice.uV = -L.D * Math.cos(L.thetaV);
    // The roll at V that lays the sculpture and its shadow along the frame's wide axis, reduced to
    // (-pi/2, pi/2] so it eases in without ever flipping.
    const look = v3.norm(v3.sub(v3.lerp(center, station.lattice.shadowCentre, SHADOW_SHARE), station.lattice.V));
    const right0 = v3.norm(v3.cross(look, upHintFor(look))), up0 = v3.cross(right0, look);
    const sep = v3.sub(station.lattice.shadowCentre, center);
    let roll = Math.atan2(v3.dot(sep, up0), v3.dot(sep, right0));
    if (roll > Math.PI / 2) roll -= Math.PI;
    if (roll <= -Math.PI / 2) roll += Math.PI;
    // A gentle roll only: the pair fits the frame's height anyway, and a large roll disorients.
    station.lattice.rollV = clamp(roll, -0.45, 0.45);
    station.lattice.mV = L.D * Math.sin(L.thetaV);
    // Cone frames: z towards the centre; the in-plane "up" is fixed per station.
    station.lattice.frameA = frameMatrix(v3.scale(vdir, -1), [0, 1, 0]);
    station.lattice.frameB = frameMatrix(v3.scale(ldir, -1), [0, 1, 0]);
  }
  return station;
}

// ---- the path -----------------------------------------------------------------------------------
// Lateral offset (x, y) of the camera from the journey axis at local coordinate u = z - z_k.
// mode carries the director's choices for this station: through (0..1) = pass through the
// sculpture's opened aperture instead of around it.
export function lateralOffset(station, u, mode = {}) {
  const psi = station.psi;
  if (station.type === "orrery") {
    const around = 13.2 * bell(u, 30);
    const through = 1.2 * bell(u, 30);
    const m = around + (through - around) * clamp(mode.through ?? 0);
    const a = psi + 0.85 * clamp(u / 30, -1, 1) + 0.25 * Math.sin(u * 0.09);
    return [m * Math.cos(a), m * Math.sin(a)];
  }
  if (station.type === "weave") {
    if (station.through) {
      // Slide out to reveal the linked rings, swing back onto the axis, thread the hole.
      const m = 11.5 * bell(u + 20.5, 13.5);
      const a = psi + 1.1 * clamp((u + 20.5) / 13.5, -1, 1);
      return [m * Math.cos(a), m * Math.sin(a)];
    }
    const m = 15.5 * bell(u, 32);
    const a = psi + 1.2 * clamp(u / 32, -1, 1);
    return [m * Math.cos(a), m * Math.sin(a)];
  }
  // Lattice: the path passes exactly through V, sliding sideways through it (the alignment is a
  // single point), then orbits the sculpture and returns to the axis.
  const L = station.lattice;
  const w = 46;
  const peak = L.mV / bell(L.uV, w);
  const m = peak * bell(u, w);
  const a = psi - 0.052 * (u - L.uV);
  return [m * Math.cos(a), m * Math.sin(a)];
}

export function nearestStationIndex(s) { return Math.round(s / SPACING); }

// Camera position on the journey at s (world z).
export function pathPosition(s, stationFor, modeFor = () => ({})) {
  const k = nearestStationIndex(s);
  const st = stationFor(k);
  const u = s - st.center[2];
  const [x, y] = lateralOffset(st, u, modeFor(k));
  return [x, y, s];
}

// How strongly the camera looks at the sculpture rather than along the path.
// At V the camera looks a quarter of the way from the sculpture towards its shadow (the alignment
// depends only on where the camera is, not where it looks), so both revelations share the frame.
export const SHADOW_SHARE = 0.25;
export function latticeLock(station, u) {
  return station.type === "lattice" ? 1 - smooth(1.5, 14, Math.abs(u - station.lattice.uV)) : 0;
}
export function focusPoint(station) {
  return station.type === "lattice" ? v3.lerp(station.center, station.lattice.shadowCentre, SHADOW_SHARE) : station.center;
}

export function focusWeight(station, u, mode = {}) {
  // Blends are wide on purpose: a smoothstep's steepest slope is 1.5 / width, and turning from the
  // sculpture back to the path ahead can be a swing of ~1.6 rad.
  if (station.type === "lattice") {
    const L = station.lattice;
    return Math.max(latticeLock(station, u), 0.9 * smooth(-46, -32, u) * (1 - smooth(-2, 28, u)));
  }
  if (station.type === "weave" && station.through) return 0.9 * smooth(-46, -32, u) * (1 - smooth(-22, -4, u));
  if (station.type === "orrery") {
    const leave = 1 - smooth(-22, -4, u) * clamp(mode.through ?? 0);
    return 0.88 * smooth(-46, -32, u) * (1 - smooth(-6, 24, u)) * leave;
  }
  return 0.85 * smooth(-46, -32, u) * (1 - smooth(-10, 34, u));
}

// Points of the path where the camera slows: the axial "mandala" view of every station and the
// anamorphic viewpoint V. weight is how much the camera wants to hold there.
export function holdPoints(station) {
  if (station.type === "lattice") return [{ u: station.lattice.uV, weight: 1, width: 5.5, kind: "alignment" }];
  return [{ u: -30, weight: 0.45, width: 7, kind: "axial" }];
}

export function cameraPose(s, stationFor, modeFor = () => ({}), { lookAhead = 14, time = 0 } = {}) {
  const pos = pathPosition(s, stationFor, modeFor);
  const k = nearestStationIndex(s);
  const st = stationFor(k);
  const u = s - st.center[2];
  const ahead = pathPosition(s + lookAhead, stationFor, modeFor);
  const focus = focusWeight(st, u, modeFor(k));
  const lock = latticeLock(st, u);
  const target = v3.lerp(ahead, v3.lerp(st.center, focusPoint(st), lock), focus);
  // Bank into lateral acceleration, as the original did with its sideways velocity.
  // Lateral acceleration over +-6 units of travel (a short window makes the bank whip).
  const pa = pathPosition(s - 6, stationFor, modeFor), pb = pathPosition(s + 6, stationFor, modeFor);
  const accel = v3.scale(v3.sub(v3.add(pa, pb), v3.scale(pos, 2)), 1 / 36);
  const fwd = v3.norm(v3.sub(target, pos));
  const right0 = v3.norm(v3.cross(fwd, upHintFor(fwd)));
  const sway = clamp(-1.0 * v3.dot(accel, right0), -0.26, 0.26) + 0.06 * Math.sin(time * 0.13);
  const roll = st.type === "lattice" ? 1 - smooth(1.5, 24, Math.abs(u - st.lattice.uV)) : 0;
  const bank = sway * (1 - roll) + (roll > 0 ? st.lattice.rollV * roll : 0);
  const frame = frameMatrix(fwd, upHintFor(fwd), bank);
  return { pos, target, fwd: frame.fwd, right: frame.right, up: frame.up, bank, focus, station: st, u };
}

// A light closer to the camera than this steps aside (continuously: at distance d < c it is moved
// to c * (1 - (1 - d / c)^2 / 2), never closer than c / 2).
export const LIGHT_CLEARANCE = 3.5;
export function clearOfCamera(p, cam, c = LIGHT_CLEARANCE) {
  const away = v3.sub(p, cam), d = v3.len(away);
  if (d >= c || d < 1e-6) return p;
  const want = c * (1 - 0.5 * (1 - d / c) ** 2);
  return v3.add(cam, v3.scale(away, want / d));
}

// Distance from p to the station's sculpture, conservatively (for camera safety tests).
export function sculptureClearance(station, p, mode = {}) {
  const q = v3.sub(p, station.center);
  const r = v3.len(q);
  if (station.type === "orrery") {
    const sh = station.shells;
    const shellGap = Math.min(Math.abs(r - sh.rOut) - sh.thOut, Math.abs(r - sh.rIn) - sh.thIn, r - ORRERY_CORE);
    if ((mode.iris ?? 0) > 0.5) {
      // An opened iris: inside the polar cone (struts only start 0.5 rad from the pole) the shells
      // are absent, so the clearance there is the distance to the cone's surface.
      const ang = Math.acos(Math.min(1, Math.abs(q[2]) / Math.max(r, 1e-6)));
      const open = Math.min(mode.iris, IRIS_STRUT_START);
      if (ang < open) return Math.max(shellGap, Math.min((open - ang) * r, r - ORRERY_CORE));
    }
    return shellGap;
  }
  if (station.type === "weave") {
    const t = station.torus;
    const rho = Math.hypot(q[0], q[1]);
    return Math.hypot(rho - t.R, q[2]) - t.r2 - 0.25;
  }
  return r - station.lattice.bound;
}
