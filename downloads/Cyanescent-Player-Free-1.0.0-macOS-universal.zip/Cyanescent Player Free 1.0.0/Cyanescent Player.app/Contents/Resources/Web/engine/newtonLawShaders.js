// Newtons Law shaders.
//
// Coordinate conventions (see runtime.json): field UV "fuv" has its origin at the top-left, u
// right, v down, and is the same UV as the beauty video. Every texture here (package samples,
// resolved fields, the video and its small copy) is stored top row first. World space is the
// Forge's: y up, the fractal plane spans x and z.
//
// Passes per frame:
//   down       the video frame -> a 240x135 box-filtered copy (shared with Newton Basin Descent)
//   resolve    two neighbouring package samples -> current-camera fields (MRT)
//                N = world normal (the renderer's own shading normal), ray depth
//                S = filament glow, boundary proximity, orbit depth, region code
//                C = surface hit, temporal agreement
//   shadow     field resolution: for each light, a screen-space march toward it through the
//              depth field (soft shadow factor), and the surface mask (silhouettes, distance)
//   composite  the video relit by the lights (soft spot pools shaded with the renderer's normals and
//              shadows, glints on the frame's own detail, filament glow), graded, with bloom
export { newtonDownsampleSource as newtonLawDownsampleSource } from "./newtonBasinShaders.js";

export const LAW_LIGHTS = 4;

const common = `
uniform vec2 uSize;
uniform float uAspect;
struct LwCam { vec3 pos; vec3 fwd; vec3 right; vec3 up; float tanHalf; };
vec3 lwRay(LwCam c, vec2 fuv) {
  vec2 s = vec2((2.0 * fuv.x - 1.0) * uAspect, 1.0 - 2.0 * fuv.y) * c.tanHalf;
  return normalize(c.fwd + c.right * s.x + c.up * s.y);
}
bool lwProject(LwCam c, vec3 P, out vec2 fuv, out float z) {
  vec3 d = P - c.pos;
  z = dot(d, c.fwd);
  if (z < 0.001) { fuv = vec2(-1.0); return false; }
  vec2 s = vec2(dot(d, c.right), dot(d, c.up)) / (z * c.tanHalf);
  fuv = vec2(0.5 + 0.5 * s.x / uAspect, 0.5 - 0.5 * s.y);
  return true;
}
// The Forge's octahedral normal: n = (x, 1 - |x| - |z|, z), folded when n.y < 0.
vec3 lwOct(float ox, float oz) {
  vec3 n = vec3(ox, 1.0 - abs(ox) - abs(oz), oz);
  if (n.y < 0.0) {
    n.x = (1.0 - abs(oz)) * (ox >= 0.0 ? 1.0 : -1.0);
    n.z = (1.0 - abs(ox)) * (oz >= 0.0 ? 1.0 : -1.0);
  }
  return normalize(n);
}
const vec3 LW_LUMA = vec3(0.2126, 0.7152, 0.0722);
`;

const cameraUniforms = (suffix) => `uniform vec3 uPos${suffix}; uniform vec3 uFwd${suffix}; uniform vec3 uRight${suffix}; uniform vec3 uUp${suffix}; uniform float uTan${suffix};`;

// ------------------------------------------------------------------ resolve

export const newtonLawResolveSource = `#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
layout(location = 0) out vec4 outN;
layout(location = 1) out vec4 outS;
layout(location = 2) out vec4 outC;
uniform sampler2D uA0;
uniform sampler2D uB0;
uniform sampler2D uA1;
uniform sampler2D uB1;
uniform float uMix;
${cameraUniforms("0")}
${cameraUniforms("1")}
${cameraUniforms("N")}
${common}

struct LwTexel { float region; float hit; float filament; float proximity; float orbitDepth; float depth; vec3 normal; };

LwTexel fetchT(sampler2D a, sampler2D b, ivec2 p) {
  p = clamp(p, ivec2(0), ivec2(uSize) - 1);
  vec4 A = texelFetch(a, p, 0);
  vec4 B = texelFetch(b, p, 0);
  int flags = int(A.r * 255.0 + 0.5);
  LwTexel t;
  t.region = float(flags & 7);
  t.hit = float((flags >> 3) & 1);
  t.filament = A.g * A.g;
  t.proximity = A.b;
  t.orbitDepth = A.a;
  int bits = int(B.r * 255.0 + 0.5) | (int(B.g * 255.0 + 0.5) << 8);
  t.depth = t.hit > 0.5 ? unpackHalf2x16(uint(bits)).x : 0.0;
  t.normal = t.hit > 0.5 ? lwOct(B.b * 2.0 - 1.0, B.a * 2.0 - 1.0) : vec3(0.0, 1.0, 0.0);
  return t;
}

struct LwSlot { float region; float hit; float filament; float proximity; float orbitDepth; float depth; vec3 normal; };

// Validity-aware bilinear sample: depth, normal, proximity and orbit depth only combine texels
// of the same region and a compatible depth; the filament glow combines all visible texels;
// region and hit are nearest.
LwSlot sampleSlot(sampler2D a, sampler2D b, vec2 q) {
  vec2 st = q * uSize - 0.5;
  ivec2 base = ivec2(floor(st));
  vec2 f = st - floor(st);
  LwTexel c = fetchT(a, b, ivec2(floor(q * uSize)));
  LwSlot s;
  s.region = c.region; s.hit = c.hit;
  float wSum = 0.0, dSum = 0.0, pSum = 0.0, oSum = 0.0, fSum = 0.0, fW = 0.0;
  vec3 nSum = vec3(0.0);
  for (int j = 0; j < 2; j++) {
    for (int i = 0; i < 2; i++) {
      LwTexel t = fetchT(a, b, base + ivec2(i, j));
      float w = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
      if (t.hit > 0.5) { fSum += t.filament * w; fW += w; }
      float compat = (t.region == c.region && t.hit > 0.5 && c.hit > 0.5 && abs(t.depth - c.depth) < 0.08 * c.depth + 0.01) ? 1.0 : 0.0;
      float cw = w * compat;
      wSum += cw; dSum += t.depth * cw; pSum += t.proximity * cw; oSum += t.orbitDepth * cw; nSum += t.normal * cw;
    }
  }
  s.depth = wSum > 0.0 ? dSum / wSum : c.depth;
  s.proximity = wSum > 0.0 ? pSum / wSum : c.proximity;
  s.orbitDepth = wSum > 0.0 ? oSum / wSum : c.orbitDepth;
  s.normal = length(nSum) > 1e-4 ? normalize(nSum) : c.normal;
  s.filament = fW > 0.0 ? fSum / fW : 0.0;
  return s;
}

void main() {
  ivec2 p = ivec2(gl_FragCoord.xy);
  vec2 fuv = (vec2(p) + 0.5) / uSize;
  LwCam c0 = LwCam(uPos0, uFwd0, uRight0, uUp0, uTan0);
  LwCam c1 = LwCam(uPos1, uFwd1, uRight1, uUp1, uTan1);
  LwCam cn = LwCam(uPosN, uFwdN, uRightN, uUpN, uTanN);
  bool nearIs1 = uMix >= 0.5;
  LwTexel base = fetchT(uA0, uB0, p);
  if (nearIs1) base = fetchT(uA1, uB1, p);
  vec2 q0 = fuv, q1 = fuv;
  // Carry both samples to the current camera through the surface they describe.
  if (base.hit > 0.5 && base.depth > 0.0) {
    vec3 P = cn.pos + lwRay(cn, fuv) * base.depth;
    float z;
    vec2 q;
    if (lwProject(c0, P, q, z) && all(greaterThan(q, vec2(0.0))) && all(lessThan(q, vec2(1.0)))) {
      LwTexel t = fetchT(uA0, uB0, ivec2(floor(q * uSize)));
      float expected = length(P - c0.pos);
      if (t.hit > 0.5 && abs(t.depth - expected) < 0.06 * expected + 0.02) q0 = q;
    }
    if (lwProject(c1, P, q, z) && all(greaterThan(q, vec2(0.0))) && all(lessThan(q, vec2(1.0)))) {
      LwTexel t = fetchT(uA1, uB1, ivec2(floor(q * uSize)));
      float expected = length(P - c1.pos);
      if (t.hit > 0.5 && abs(t.depth - expected) < 0.06 * expected + 0.02) q1 = q;
    }
  }
  LwSlot s0 = sampleSlot(uA0, uB0, q0);
  LwSlot s1 = sampleSlot(uA1, uB1, q1);
  LwSlot n = s0;
  if (nearIs1) n = s1;
  bool agree = s0.region == s1.region && s0.hit > 0.5 && s1.hit > 0.5;
  float m = agree ? uMix : (nearIs1 ? 1.0 : 0.0);
  float d0 = s0.hit > 0.5 ? length(c0.pos + lwRay(c0, q0) * s0.depth - cn.pos) : 0.0;
  float d1 = s1.hit > 0.5 ? length(c1.pos + lwRay(c1, q1) * s1.depth - cn.pos) : 0.0;
  float depth = agree ? mix(d0, d1, m) : (n.hit > 0.5 ? (nearIs1 ? d1 : d0) : 0.0);
  vec3 normal = normalize(mix(s0.normal, s1.normal, m) + vec3(0.0, 1e-4, 0.0));
  if (!agree) normal = n.normal;
  outN = vec4(normal, depth);
  outS = vec4(mix(s0.filament, s1.filament, m), mix(s0.proximity, s1.proximity, m), mix(s0.orbitDepth, s1.orbitDepth, m), n.region);
  outC = vec4(n.hit, agree ? 1.0 : 0.0, 0.0, 0.0);
}`;

// ------------------------------------------------------------------- shadow

// Soft screen-space shadows toward each light, at field resolution: march from the surface
// point toward the light and ask the depth field whether a visible surface stands in front of
// the ray. Screen-space shadows cannot see what is off screen or hidden; they only ever darken
// where the frame itself shows the occluder, which is what keeps them consistent with the video.
export const newtonLawShadowSource = `#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
layout(location = 0) out vec4 outShadow;
layout(location = 1) out vec4 outMask;
uniform sampler2D uN;
uniform sampler2D uC;
uniform vec4 uLightA[${LAW_LIGHTS}];   // position, reach
uniform vec4 uLightB[${LAW_LIGHTS}];   // colour * intensity, specular
uniform float uShadowSteps;
${cameraUniforms("N")}
${common}
void main() {
  ivec2 p = ivec2(gl_FragCoord.xy);
  ivec2 hi = ivec2(uSize) - 1;
  vec2 fuv = (vec2(p) + 0.5) / uSize;
  vec4 N = texelFetch(uN, p, 0);
  float hit = texelFetch(uC, p, 0).r;
  if (hit < 0.5 || N.w <= 0.0) { outShadow = vec4(1.0); outMask = vec4(0.0); return; }
  float depth = N.w;
  float edge = 0.0;
  for (int k = 0; k < 4; k++) {
    ivec2 o = k == 0 ? ivec2(1, 0) : k == 1 ? ivec2(-1, 0) : k == 2 ? ivec2(0, 1) : ivec2(0, -1);
    ivec2 q = clamp(p + o, ivec2(0), hi);
    float dn = texelFetch(uN, q, 0).w;
    edge = max(edge, texelFetch(uC, q, 0).r > 0.5 ? abs(dn - depth) / max(depth, 0.2) : 1.0);
  }
  float surface = (1.0 - smoothstep(0.06, 0.22, edge)) * (1.0 - smoothstep(6.0, 11.0, depth));
  LwCam cn = LwCam(uPosN, uFwdN, uRightN, uUpN, uTanN);
  vec3 P = cn.pos + lwRay(cn, fuv) * depth;
  vec3 Nn = normalize(N.xyz);
  P += Nn * 0.01;
  vec4 shadow = vec4(1.0);
  for (int k = 0; k < ${LAW_LIGHTS}; k++) {
    if (dot(uLightB[k].rgb, vec3(1.0)) < 0.002) continue;
    // Point lights sit at uLightA.xyz; a directional light (reach 0) gives the direction towards it.
    bool directional = uLightA[k].w <= 0.0;
    vec3 toLight = directional ? normalize(uLightA[k].xyz) * 1.8 : uLightA[k].xyz - P;
    float dist = length(toLight);
    vec3 dir = toLight / dist;
    if (dot(dir, Nn) <= 0.0) { shadow[k] = 1.0; continue; }   // facing away: N.L already darkens it
    float span = min(dist, 1.8);
    float occ = 0.0;
    for (int s = 1; s <= 14; s++) {
      if (float(s) > uShadowSteps) break;
      float t = span * pow(float(s) / uShadowSteps, 1.35);
      vec3 Q = P + dir * t;
      vec2 q; float z;
      if (!lwProject(cn, Q, q, z) || any(lessThan(q, vec2(0.0))) || any(greaterThan(q, vec2(1.0)))) break;
      vec4 Nq = texture(uN, q);
      if (Nq.w <= 0.0) continue;
      float behind = length(Q - cn.pos) - Nq.w;
      // A visible surface in front of the ray point, but not so far in front that it is a
      // different, unrelated layer of the scene (screen-space thickness).
      occ = max(occ, smoothstep(0.012 * z, 0.05 * z, behind) * (1.0 - smoothstep(0.35, 0.8, behind)));
    }
    shadow[k] = 1.0 - occ;
  }
  outShadow = shadow;
  outMask = vec4(surface, 0.0, 0.0, 0.0);
}`;

// ---------------------------------------------------------------- composite

export const newtonLawCompositeSource = `#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uVideo;
uniform sampler2D uSmall;
uniform sampler2D uN;
uniform sampler2D uS;
uniform sampler2D uC;
uniform sampler2D uShadow;
uniform sampler2D uMask;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform vec2 uViewPx;
uniform int uDebug;
uniform float uFade;
uniform vec4 uGrade;          // exposure, saturation, contrast, haze
uniform vec4 uLook;           // world dim, light gain, glitter, filament glow
uniform vec4 uLook2;          // bloom, filament flow phase (bands), shadow strength, unused
uniform vec4 uLightA[${LAW_LIGHTS}];
uniform vec4 uLightB[${LAW_LIGHTS}];
uniform vec4 uLightC[${LAW_LIGHTS}];   // spot aim, cos(cone)
${cameraUniforms("N")}
${common}

vec3 videoAt(vec2 fuv) {
  vec2 h = 0.25 / uViewPx;
  return 0.25 * (texture(uVideo, fuv + vec2(-h.x, -h.y)).rgb + texture(uVideo, fuv + vec2(h.x, -h.y)).rgb
               + texture(uVideo, fuv + vec2(-h.x, h.y)).rgb + texture(uVideo, fuv + vec2(h.x, h.y)).rgb);
}
vec3 shoulder(vec3 c) {
  vec3 over = max(c - 0.8, 0.0);
  return min(c, vec3(0.8)) + 0.2 * (1.0 - exp(-over / 0.2));
}
// Coloured light must stay coloured when it is bright: compress the brightest channel and scale
// the others with it, instead of letting every channel clip to white.
vec3 hueShoulder(vec3 c) {
  float m = max(c.r, max(c.g, c.b));
  if (m <= 0.8) return c;
  float t = 0.8 + 0.2 * (1.0 - exp(-(m - 0.8) / 0.2));
  return c * (t / m);
}
vec3 grade(vec3 c) {
  c *= uGrade.x;
  float l = dot(c, LW_LUMA);
  c = mix(vec3(l), c, uGrade.y);
  vec3 s = clamp(c, 0.0, 1.0);
  c = mix(c, s * s * (3.0 - 2.0 * s), clamp((uGrade.z - 1.0) * 2.0, -0.4, 0.35));
  c += (1.0 - c) * vec3(0.70, 0.76, 1.0) * uGrade.w;
  return shoulder(max(c, 0.0));
}
vec3 bloomAt(vec2 fuv) {
  vec2 cell = 1.0 / vec2(textureSize(uSmall, 0));
  vec3 b = max(texture(uSmall, fuv).rgb - 0.72, 0.0) * 0.8;
  for (int k = 0; k < 8; k++) {
    float a = float(k) * 0.7853982;
    vec2 d = vec2(cos(a), sin(a)) * cell;
    b += max(texture(uSmall, fuv + d * 2.5).rgb - 0.68, 0.0) * 0.16;
    b += max(texture(uSmall, fuv + d * 6.0).rgb - 0.62, 0.0) * 0.09;
  }
  return b;
}
vec3 regionTint(float code) {
  if (code < 0.5) return vec3(0.0);
  if (code < 1.5) return vec3(0.25, 0.45, 1.0);
  if (code < 2.5) return vec3(1.0, 0.70, 0.36);
  if (code < 3.5) return vec3(0.30, 0.95, 0.85);
  if (code < 4.5) return vec3(0.70, 0.48, 1.0);
  return vec3(1.0, 0.3, 0.9);
}

// Every field quantity is upsampled from 320x180 with a joint bilateral filter guided by the
// full-resolution frame: of the four texels around a pixel, the ones whose own video colour
// matches this pixel's count most. Light, shadow and masks therefore follow the frame's real
// edges instead of the field's texel grid (no stair-stepped fractal edges).
struct LwSample { vec4 N; vec4 S; float hit; vec4 shadow; float surface; float shininess; float gloss; };

LwSample upsample(vec2 fuv, vec3 guide) {
  vec2 st = fuv * uSize - 0.5;
  ivec2 base = ivec2(floor(st));
  vec2 f = st - floor(st);
  ivec2 hi = ivec2(uSize) - 1;
  LwSample o;
  o.N = vec4(0.0); o.S = vec4(0.0); o.hit = 0.0; o.shadow = vec4(0.0); o.surface = 0.0; o.shininess = 0.0; o.gloss = 0.0;
  float wSum = 0.0;
  LwSample nearest = o;
  float nearestW = -1.0;
  for (int j = 0; j < 2; j++) {
    for (int i = 0; i < 2; i++) {
      ivec2 q = clamp(base + ivec2(i, j), ivec2(0), hi);
      float wb = (i == 0 ? 1.0 - f.x : f.x) * (j == 0 ? 1.0 - f.y : f.y);
      vec3 g = texelFetch(uSmall, q, 0).rgb - guide;
      float w = wb * exp(-dot(g, g) * 30.0) + 1e-5 * wb;
      vec4 N = texelFetch(uN, q, 0);
      vec4 S = texelFetch(uS, q, 0);
      float region = S.a;
      float shin = region > 4.5 ? 90.0 : region < 1.5 ? 28.0 : 48.0;
      float gloss = region > 4.5 ? 1.5 : region < 1.5 ? 0.55 : 1.0;
      o.N += N * w; o.S += S * w; o.hit += texelFetch(uC, q, 0).r * w;
      o.shadow += texelFetch(uShadow, q, 0) * w; o.surface += texelFetch(uMask, q, 0).r * w;
      o.shininess += shin * w; o.gloss += gloss * w;
      wSum += w;
      if (w > nearestW) { nearestW = w; nearest.S = S; }
    }
  }
  float inv = 1.0 / wSum;
  o.N *= inv; o.S *= inv; o.hit *= inv; o.shadow *= inv; o.surface *= inv; o.shininess *= inv; o.gloss *= inv;
  o.S.a = nearest.S.a;   // the region code is categorical: the best-matching texel's
  return o;
}

void main() {
  vec2 uv = vUv;
  if (uCanvasAspect > uVideoAspect) uv.x = (uv.x - 0.5) * uCanvasAspect / uVideoAspect + 0.5;
  else uv.y = (uv.y - 0.5) * uVideoAspect / uCanvasAspect + 0.5;
  if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) { outColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
  vec2 fuv = vec2(uv.x, 1.0 - uv.y);
  vec3 video = videoAt(fuv);
  LwSample F = upsample(fuv, video);
  vec4 Nd = F.N;
  vec4 S = F.S;
  float region = S.a;
  float hit = F.hit;
  vec4 shadow = mix(vec4(1.0), F.shadow, uLook2.z);
  float surface = F.surface * uFade;
  vec3 N = normalize(Nd.xyz + vec3(0.0, 1e-4, 0.0));
  LwCam cn = LwCam(uPosN, uFwdN, uRightN, uUpN, uTanN);
  vec3 ray = lwRay(cn, fuv);
  vec3 P = cn.pos + ray * Nd.w;
  vec3 V = -ray;

  // Lights: soft spot pools over the landmarks and the raking sweep, shaded with the renderer's
  // own normals and the marched shadows.
  vec3 diffuse = vec3(0.0), spec = vec3(0.0);
  float excite = 0.0;
  for (int k = 0; k < ${LAW_LIGHTS}; k++) {
    vec3 energy = uLightB[k].rgb;
    if (dot(energy, vec3(1.0)) < 0.002) continue;
    bool directional = uLightA[k].w <= 0.0;
    vec3 L;
    float falloff = 1.0;
    if (directional) L = normalize(uLightA[k].xyz);
    else {
      vec3 toLight = uLightA[k].xyz - P;
      float d = length(toLight);
      L = toLight / d;
      float x = d / uLightA[k].w;
      // Soft cone: full inside 45% of the angle, fading out to 170%, so a pool of light melts
      // into the terrain instead of drawing a disc.
      float cone = uLightC[k].w;
      float spot = 1.0;
      if (cone > -0.5) {
        float angle = acos(clamp(cone, -1.0, 1.0));
        spot = smoothstep(cos(min(angle * 1.7, 1.55)), cos(angle * 0.45), dot(-L, uLightC[k].xyz));
        spot *= spot;
      }
      falloff = mix(0.02, 1.0, spot) / (1.0 + x * x);
    }
    float s = shadow[k];
    float ndl = max((dot(N, L) + 0.12) / 1.12, 0.0);
    diffuse += energy * ndl * falloff * s;
    vec3 H = normalize(L + V);
    spec += energy * pow(max(dot(N, H), 0.0), F.shininess) * falloff * s * uLightB[k].a * F.gloss * step(0.0, dot(N, L));
    excite += dot(energy, LW_LUMA) * falloff;
  }

  // Debug views.
  if (uDebug == 1) { outColor = vec4(mix(video * 0.35, regionTint(region), 0.65 * hit), 1.0); return; }
  if (uDebug == 2) { outColor = vec4((N * 0.5 + 0.5) * hit, 1.0); return; }
  if (uDebug == 3) { outColor = vec4(vec3(clamp(Nd.w / 8.0, 0.0, 1.0)), 1.0); return; }
  if (uDebug == 4) { outColor = vec4(mix(video * 0.2, vec3(1.0, 0.85, 0.55), clamp(sqrt(S.r) * 1.2, 0.0, 1.0)), 1.0); return; }
  if (uDebug == 5) { outColor = vec4(mix(vec3(0.05, 0.08, 0.2), vec3(0.4, 1.0, 0.8), S.g) * hit, 1.0); return; }
  if (uDebug == 6) { outColor = vec4(video * 0.25 + shadow.rgb * 0.6 * hit, 1.0); return; }
  if (uDebug == 7) { outColor = vec4(shoulder(vec3(0.18) + diffuse * 0.6 + spec) * surface, 1.0); return; }
  if (uDebug == 9) { outColor = vec4(mix(vec3(0.9, 0.1, 0.1), vec3(0.1, 0.8, 0.35), surface) * (0.3 + 0.7 * hit), 1.0); return; }

  // The frame, relit.
  vec3 base = grade(video);
  vec3 low = grade(texture(uSmall, fuv).rgb);
  float detail = dot(base - low, LW_LUMA);
  float luma = dot(base, LW_LUMA);
  vec3 hue = base / max(max(base.r, max(base.g, base.b)), 0.08);
  // What the new light reflects: the frame's own colour, and its hue on the renderer's shadow
  // sides (which the original key light left dark).
  vec3 albedo = base + hue * 0.16 * (1.0 - smoothstep(0.1, 0.5, luma));
  // Part of the light is seen against the surface's brightness rather than its colour, so a
  // coloured light keeps its own hue on complementary surfaces (no muddy products).
  albedo = mix(albedo, vec3(dot(albedo, LW_LUMA)) * 1.15, 0.35);
  vec3 col = base * (1.0 - uLook.x * surface);
  col += albedo * diffuse * uLook.y * surface;
  // Glints: specular sits on the frame's own fine relief, so it sparkles at full resolution.
  col += spec * (0.30 + 3.0 * max(detail, 0.0)) * uLook.z * surface;
  // The render's own luminous filaments: they flare with the pads and hats, most of all under a
  // light, and bands of light run along the orbit-depth bands with the beat.
  float flow = pow(0.5 + 0.5 * cos(6.2831853 * (S.b * 7.0 - uLook2.y)), 6.0);
  float filament = S.r * (1.0 + 1.6 * flow);
  col += base * filament * (uLook.w + 1.4 * excite * uLook.w) * 1.4 * surface;

  col += bloomAt(fuv) * uLook2.x;
  if (uDebug == 8) { outColor = vec4(clamp(abs(col - base) * 2.5, 0.0, 1.0), 1.0); return; }
  outColor = vec4(hueShoulder(max(col, 0.0)), 1.0);
}`;
