import { createPresetCalibration } from "../ui/presetCalibration.js";
import { STINKHORN_ASSET, createStinkhornStore } from './stinkhornField.js';
import { createStinkhornSignals,ACTIVITY_BINS } from './stinkhornSignals.js';
import { createForgeFramePresenter } from './forgeFramePresenter.js';
import { stinkhornCopySource,stinkhornCompositeSource,stinkhornPathVertex,stinkhornPathFragment,stinkhornSporeVertex,stinkhornSporeFragment } from './stinkhornShaders.js';
import {createStinkhornSpores} from './stinkhornSpores.js';
export function createStinkhornRuntime({getGl,program,programFrom,setAttribs,asset=STINKHORN_ASSET,profile={}}) {
  // Lossless fields and the presented-frame clock drive preset 360.
  const {compositeSource=stinkhornCompositeSource,createSignals=createStinkhornSignals,
    prefix='stinkhorn',label='Stinkhorn',enableSpores=true,pathTraits=false}=profile;
  const controlsKey=`__${prefix}Controls`,diagnosticsKey=`__${prefix}Diagnostics`;
  const controls={intensity:1,pulses:true,ground:true,crown:true,spores:enableSpores,ambient:true,debug:0,compare:false};
  const calibration=createPresetCalibration({presetId:360,
    presetName:'Red Cage Stinkhorn',controls,
    buildPanel:createPanel,clearPanel:()=>{panel=null;}});
  let signals=null,activityTex=null,pathTex=null;
  const spores=createStinkhornSpores();let sporeProg=null,sporeBuffer=null,sporeCount=0,panel=null;
  let active=false,generation=0,pkg=null,presenter=null,store=null,prog=null,copy=null,pathProg=null,buffer=null,fields=[],uploaded=-1;
  let loading=null,error='',lastNow=null,shown=null,offline=null,reportAt=0,frames=0,lastFrames=0,cpuMs=0,measured=0,matched=0,misses=0;
  const locations=new WeakMap();
  function loc(p,n){let map=locations.get(p);if(!map){map=new Map();locations.set(p,map);}if(!map.has(n))map.set(n,getGl().getUniformLocation(p,n));return map.get(n);}
  const fixture=()=>new URLSearchParams(window.location.search).get('fixture')||'';
  function prepare(){if(active)return loading;active=true;const token=++generation;const gl=getGl();error='';lastNow=null;
    try { prog=program(compositeSource);copy=program(stinkhornCopySource);pathProg=programFrom(stinkhornPathVertex,stinkhornPathFragment);buffer=gl.createBuffer();
    sporeProg=programFrom(stinkhornSporeVertex,stinkhornSporeFragment);sporeBuffer=gl.createBuffer();spores.reset(); } catch(e){error=String(e.message||e);console.error('[Stinkhorn] Shader: '+error);stop();throw e;}
    fields=Array.from({length:4},()=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
      for(const [p,v]of[[gl.TEXTURE_MIN_FILTER,gl.NEAREST],[gl.TEXTURE_MAG_FILTER,gl.NEAREST],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,p,v);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,480,270,0,gl.RGBA,gl.HALF_FLOAT,null);return t;});
    window[controlsKey]=controls;
    const f=fixture();if(f.startsWith(prefix+'-')){controls.debug=({beauty:1,material:2,depth:3,network:4,paths:5,visibility:6,flow:7,crown:8,emission:9})[f.replace(`${prefix}-`,'').replace(/-t[\d.]+$/,'')]||0;
    controls.compare=f.includes('-compare');controls.intensity=f.includes('-off')||f.includes('-beauty')?0:1;}
    calibration.start();
    loading=(async()=>{const json=async name=>{const r=await fetch(`${asset.assetRoot}/${name}`);if(!r.ok)throw new Error(`${name}: HTTP ${r.status}`);return r.json();};
      const p=await json('runtime.json');if(p.schema!=='cyanescent-stinkhorn-runtime'||p.version!==2||p.source.frames!==asset.frames||p.source.fps!==asset.fps||p.fields.width!==480||p.fields.height!==270)throw new Error('Stinkhorn package incompatible');
      const [timeline,topology,index]=await Promise.all([json(p.files.timeline),json(p.files.topology),json(p.files.decodeIndex)]);
      if(!active||token!==generation)return;
      pkg={...p,timeline,topology};
      const staticResponse=await fetch(`${asset.assetRoot}/${p.files.staticRecord}`);
      if(!staticResponse.ok)throw new Error('Missing static RCN2 record');
      const staticRecord=new Uint8Array(await staticResponse.arrayBuffer());
      if(!active||token!==generation)return;pkg.staticRecord=staticRecord;
      signals=createSignals(topology);
      function floatTexture(width,height,data){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
        for(const [p,v]of[[gl.TEXTURE_MIN_FILTER,gl.NEAREST],[gl.TEXTURE_MAG_FILTER,gl.NEAREST],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,p,v);
        gl.texImage2D(gl.TEXTURE_2D,0,data?gl.RGBA32F:gl.R32F,width,height,0,data?gl.RGBA:gl.RED,gl.FLOAT,data);return t;}
      const rows=signals.activity.length/ACTIVITY_BINS,data=new Float32Array(rows*4);
      const kinds={'floor-fine':1,'floor-cord':2,column:3,'dome-radial':4,'crown-radial':5,'dome-link':6,'crown-weave':7,'dome-branch':8,'floor-link':11,hypha:12,'column-branch':13};
      for(const path of topology.paths)data.set([path.length,kinds[path.kind]||10,pathTraits?path.distanceToCrown:0,pathTraits?(path.isPrimary?1:0):0],path.id*4);
      pathTex=floatTexture(rows,1,data);activityTex=floatTexture(ACTIVITY_BINS,rows,null);
      let time=Number(f.match(/-t([\d.]+)$/)?.[1]||0);if(f===`${prefix}-loop`)time=asset.durationSeconds-3;
      store=createStinkhornStore({pkg,urlFor:name=>`${asset.assetRoot}/${name}`});store.prefetch(Math.floor(time*asset.fps));
      presenter=createForgeFramePresenter({gl,asset,index,copyProgram:copy,setAttribs,startTime:time,onError:e=>{if(token===generation){error=String(e.message||e);console.error('[Stinkhorn]',error);}}});
      await presenter.ready;
    })().catch(e=>{if(token===generation){error=String(e.message||e);console.error('[Stinkhorn]',error);}});return loading;}
  function bind(p,n,unit,t){const gl=getGl();gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,t);gl.uniform1i(loc(p,n),unit);}
  function createPanel(){panel=document.createElement('div');panel.style.cssText='position:fixed;right:16px;top:50px;z-index:10000;background:#18131fe8;color:white;padding:12px;font:12px monospace;display:grid;gap:8px';
    const title=document.createElement('b');title.textContent=`${label} diagnostics`;panel.appendChild(title);
    for(const [name,label]of [['intensity','Augmentation'],['pulses','Network pulses'],['ground','Ground signals'],['crown','Crown convergence'],['spores','Spores'],['ambient','Ambient life'],['compare','Original / augmented']]){
      if(name==='spores'&&!enableSpores)continue;
      const line=document.createElement('label'),input=document.createElement('input');line.textContent=label+' ';input.dataset.key=name;input.type=name==='intensity'?'range':'checkbox';
      if(name==='intensity'){input.min='0';input.max='1.5';input.step='.05';input.value=String(controls[name]);}else input.checked=controls[name];
      input.addEventListener('input',()=>{controls[name]=name==='intensity'?Number(input.value):input.checked;});line.appendChild(input);panel.appendChild(line);}
    const select=document.createElement('select');select.dataset.key='debug';for(const [value,label]of ['Augmented','Beauty','Materials','Geometry / depth','Network surface','Path centrelines','GPU visibility','Camera flow','Crown marker','Emission'].entries()){
      const option=document.createElement('option');option.value=String(value);option.textContent=label;select.appendChild(option);}
    select.addEventListener('change',()=>{controls.debug=Number(select.value);});panel.appendChild(select);document.body.appendChild(panel);return panel;}
  function paths(frame,width,height){const gl=getGl(),vertices=[];
    for(const p of frame.record.paths.values())for(let i=1;i<p.count;i++){
      const a=(p.offset+i-1)*20,b=a+20,s=frame.record.samples;
      if(s[a+6]<=0||s[b+6]<=0||Math.abs(s[a+4]-s[b+4])>1||Math.abs(s[a+5]-s[b+5])>1)continue;
      for(const o of [a,b])vertices.push(s[o+4],s[o+5],(Math.round(s[o+12])&7)===7?s[o+18]:0,s[o+12]);}
    gl.useProgram(pathProg);gl.uniform2f(loc(pathProg,'uResolution'),width,height);gl.uniform1f(loc(pathProg,'uAspect'),asset.width/asset.height);gl.uniform1i(loc(pathProg,'uDebug'),controls.debug);
    gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,4,gl.FLOAT,false,16,0);
    gl.drawArrays(gl.LINES,0,vertices.length/4);
  }
  function render({target,width,height,now,playing=true,...input}){
    if(!active)prepare();const stamp=performance.now(),gl=getGl();const dt=lastNow===null?0:Math.max(0,Math.min(.1,(now-lastNow)/1000));lastNow=now;frames++;
    shown=offline||presenter?.step(dt,playing,fixture().includes('-still'))||shown;
    const effectPlaying=Boolean(offline)||playing;
    if(shown)store?.prefetch(shown.frame);const frame=shown?store?.get(shown.frame):null;
    if(signals)signals.step(effectPlaying?dt:0,{...input,camera:shown?pkg?.timeline[shown.frame]?.camera:null,networkField:pathTraits?frame?.images[2]:null},controls);
    if(frame)matched++;else misses++;
    gl.bindFramebuffer(gl.FRAMEBUFFER,target.fb);gl.viewport(0,0,width,height);gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);
    if(!prog||!pkg||!shown){gl.clearColor(0,0,0,1);gl.clear(gl.COLOR_BUFFER_BIT);return;}
    gl.useProgram(prog);bind(prog,'uVideo',0,shown.texture);
    if(frame&&uploaded!==shown.frame){gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);for(let i=0;i<4;i++){gl.activeTexture(gl.TEXTURE1+i);gl.bindTexture(gl.TEXTURE_2D,fields[i]);gl.texSubImage2D(gl.TEXTURE_2D,0,0,0,480,270,gl.RGBA,gl.HALF_FLOAT,frame.images[i]);}uploaded=shown.frame;}
    ['uGeometry','uStructure','uNetwork','uFlow'].forEach((n,i)=>bind(prog,n,i+1,fields[i]));
    if(activityTex){bind(prog,'uActivity',5,activityTex);gl.texSubImage2D(gl.TEXTURE_2D,0,0,0,ACTIVITY_BINS,signals.activity.length/ACTIVITY_BINS,gl.RED,gl.FLOAT,signals.activity);bind(prog,'uPathData',6,pathTex);}
    const scene=pkg.timeline[shown.frame],c=scene.camera;
    for(const [n,v]of Object.entries({Position:c.position,Forward:c.forward,Right:c.right,Up:c.up,Crown:scene.crown.world}))gl.uniform3fv(loc(prog,`u${n}`),v);
    gl.uniform2f(loc(prog,'uResolution'),width,height);gl.uniform1f(loc(prog,'uAspect'),c.aspect);gl.uniform1f(loc(prog,'uTan'),c.tanHalfVerticalFOV);
    gl.uniform1f(loc(prog,'uReady'),frame?1:0);gl.uniform1f(loc(prog,'uIntensity'),frame?controls.intensity:0);gl.uniform1i(loc(prog,'uDebug'),frame?controls.debug:0);
    gl.uniform1f(loc(prog,'uCrownEnergy'),signals?.state.crown||0);gl.uniform1f(loc(prog,'uTime'),signals?.state.time||0);gl.uniform1f(loc(prog,'uEnergy'),signals?.state.energy||0);gl.uniform1f(loc(prog,'uHighs'),signals?.state.highs||0);
    gl.uniform1f(loc(prog,'uInterior'),scene.interior);gl.uniform1f(loc(prog,'uLife'),signals?.state.life||0);
    gl.uniform4f(loc(prog,'uAmounts'),controls.pulses?1:0,controls.ground?1:0,controls.crown?1:0,controls.spores?1:0);gl.uniform1i(loc(prog,'uCompare'),controls.compare?1:0);gl.uniform1i(loc(prog,'uQuality'),input.quality>.5?1:0);
    setAttribs(prog);gl.drawArrays(gl.TRIANGLES,0,3);
    if(frame&&(controls.debug===5||controls.debug===6))paths(frame,width,height);
    sporeCount=spores.update(effectPlaying?dt:0,signals.state,scene.interior,enableSpores&&controls.spores&&controls.intensity>0);
    if(frame&&sporeCount&&controls.spores&&controls.intensity>0&&controls.debug===0){
      gl.useProgram(sporeProg);bind(sporeProg,'uGeometry',1,fields[0]);bind(sporeProg,'uStructure',2,fields[1]);
      for(const [n,v]of Object.entries({Position:c.position,Forward:c.forward,Right:c.right,Up:c.up}))gl.uniform3fv(loc(sporeProg,`u${n}`),v);
      gl.uniform2f(loc(sporeProg,'uResolution'),width,height);gl.uniform1f(loc(sporeProg,'uTan'),c.tanHalfVerticalFOV);gl.uniform1f(loc(sporeProg,'uAspect'),c.aspect);gl.uniform1f(loc(sporeProg,'uIntensity'),controls.intensity);gl.uniform1i(loc(sporeProg,'uCompare'),controls.compare?1:0);
      gl.bindBuffer(gl.ARRAY_BUFFER,sporeBuffer);gl.bufferData(gl.ARRAY_BUFFER,spores.vertices.subarray(0,sporeCount*4),gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,4,gl.FLOAT,false,16,0);
      gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE);gl.drawArrays(gl.POINTS,0,sporeCount);gl.disable(gl.BLEND);
    }
    cpuMs+=performance.now()-stamp;measured++;
    if(now-reportAt>1000){const fps=reportAt?(frames-lastFrames)*1000/(now-reportAt):0;reportAt=now;lastFrames=frames;
      window[diagnosticsKey]={videoReady:true,videoTime:shown.time%asset.durationSeconds,displayedVideoTime:shown.time%asset.durationSeconds,
        frame:shown.frame,fieldFrame:frame?.record.frame??-1,fieldReady:!!frame,frameCoherent:!!frame,matched,misses,fps,cpuMs:cpuMs/Math.max(1,measured),
        memoryMB:store?.memoryBytes()/1048576,presentationMB:13*asset.width*asset.height*4/1048576,store:{...store?.stats},presentation:{...presenter?.stats},decoderStats:presenter?.decoderStats,
        spores:sporeCount,signals:signals?{...signals.stats,active:signals.pool.filter(p=>p.active).length,crown:signals.state.crown,energy:signals.state.energy,time:signals.state.time}:null,error};
      if(document.body.classList.contains('preset-trial-role'))window.webkit?.messageHandlers?.nativeApp?.postMessage({command:'logConsole',type:'info',text:`[${label}] ${JSON.stringify(window[diagnosticsKey])}`});cpuMs=measured=0;}
  }
  async function prepareOffline(time){await prepare();if(error)throw new Error(error);if(!presenter)throw new Error('Stinkhorn load cancelled');
    if(!offline){signals.reset();spores.reset();lastNow=null;}
    const t=Math.floor(time*asset.fps+1e-6)/asset.fps;offline=await presenter.exact(t);
    const deadline=performance.now()+15000;store.prefetch(offline.frame);
    while(!store.get(offline.frame)){if(performance.now()>deadline)throw new Error('Stinkhorn export fields timed out');await new Promise(r=>setTimeout(r,5));}return offline;}
  function stop(){if(!active)return;active=false;generation++;presenter?.stop();store?.dispose();presenter=store=pkg=shown=offline=null;uploaded=-1;
    const gl=getGl();for(const t of [...fields,activityTex,pathTex])if(t)gl.deleteTexture(t);signals=null;activityTex=pathTex=null;for(const p of [prog,copy,pathProg,sporeProg])if(p)gl.deleteProgram(p);for(const b of [buffer,sporeBuffer])if(b)gl.deleteBuffer(b);sporeProg=sporeBuffer=null;spores.reset();calibration.stop();panel=null;fields=[];prog=copy=pathProg=buffer=null;
    window[controlsKey]=window[diagnosticsKey]=null;}
  return {prepare,render,stop,prepareOffline,endOffline(){if(offline)stop();},controls,isActive:()=>active};
}
