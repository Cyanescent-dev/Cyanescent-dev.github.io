// Forge's RCN2 v2 contract. Distances below are never interchangeable:
// geometry.R = ray distance; sample[6] = forward depth; sample[15] = graph arc.
import { parseSegment, readSample, segmentName, halfBitsToFloat } from './newtonBasinField.js';
export const STINKHORN_ID = 360;
export const STINKHORN_ASSET = Object.freeze({ assetRoot: 'assets/forge/red-cage-stinkhorn', video: 'hornworld.mp4',
  width: 1920, height: 1080, fps: 30, frames: 1986, durationSeconds: 66.2 });
export {forgeSourceFrame as sourceFrame} from './forgeVideoHistory.js';
export function projectWorld(camera, point) {
  const d = point.map((v,k) => v-camera.position[k]);
  const dot = a => a.reduce((v,x,k) => v+x*d[k],0);
  const depth = dot(camera.forward);
  return { uv: [.5+.5*dot(camera.right)/(depth*camera.aspect*camera.tanHalfVerticalFOV),
    .5-.5*dot(camera.up)/(depth*camera.tanHalfVerticalFOV)], depth, rayDistance: Math.hypot(...d) };
}
export function parseRCN2(bytes, expectedFrame = null) {
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length < 64 || v.getUint32(0,true) !== 0x324e4352 || v.getUint32(4,true) !== 2) throw new Error('Invalid RCN2 v2 header');
  const h = Array.from({length:16},(_,i) => v.getUint32(i*4,true));
  if (expectedFrame !== null && h[2] !== expectedFrame) throw new Error('RCN2 frame stamp mismatch');
  if (h[6] !== 12 || h[7] !== 12 || h[8] !== 20 || bytes.length !== 64+h[3]*48+h[4]*48+h[5]*80) throw new Error('RCN2 layout/size mismatch');
  const paths = new Map();
  for (let i=0;i<h[3];i++) {
    const o = 64+i*48;
    const p = { id:v.getUint32(o,true), kind:v.getUint32(o+4,true), column:v.getInt32(o+8,true),
      radial:v.getInt32(o+12,true), parent:v.getInt32(o+16,true), start:v.getUint32(o+20,true), end:v.getUint32(o+24,true),
      offset:v.getUint32(o+28,true), count:v.getUint32(o+32,true), length:v.getFloat32(o+36,true), distanceToCrown:v.getFloat32(o+40,true) };
    if (paths.has(p.id) || p.offset+p.count > h[5] || p.count < 2 || !(p.length>0)) throw new Error('Invalid RCN2 path');
    paths.set(p.id,p);
  }
  const nodeOffset=64+h[3]*48, sampleOffset=nodeOffset+h[4]*48;
  return { frame:h[2], paths, nodes:new Float32Array(bytes.buffer,bytes.byteOffset+nodeOffset,h[4]*12),
    samples:new Float32Array(bytes.buffer,bytes.byteOffset+sampleOffset,h[5]*20), width:h[9], height:h[10] };
}
export function pathSample(record, id, distance) {
  const p=record.paths.get(id); if (!p) return null;
  const s=record.samples; let lo=0, hi=p.count-1;
  while (hi-lo>1) { const m=(hi+lo)>>1; if(s[(p.offset+m)*20+15]<=distance)lo=m;else hi=m; }
  const a=(p.offset+lo)*20,b=(p.offset+hi)*20;
  const t=Math.max(0,Math.min(1,(distance-s[a+15])/Math.max(1e-6,s[b+15]-s[a+15])));
  const mix=k => s[a+k]+(s[b+k]-s[a+k])*t;
  // A GPU-unprobed or occluded endpoint cannot be interpolated into visibility.
  const visible=(Math.round(s[a+12])&7)===7 && (Math.round(s[b+12])&7)===7;
  return { uv:[mix(4),mix(5)], world:[mix(1),mix(2),mix(3)], depth:mix(6), arc:distance,
    radius:mix(14), pixels:mix(17), visibility:visible ? Math.min(s[a+18],s[b+18]) : 0, firstHit:mix(19) };
}
export function visibleSignal(sample, camera, surface, pathID) {
  if (!sample || sample.visibility<=0 || sample.depth<=0 || surface.material===1 || !surface.valid || surface.pathID!==pathID) return false;
  const ray=projectWorld(camera,sample.world).rayDistance;
  return surface.depth>0 && Math.abs(ray-surface.depth)<=sample.radius+Math.max(.02,surface.depth*.004);
}
export function unpackStinkhornFrame(raw, fields, frame, template=null, buffer=null) {
  const n=fields.fieldBytes;
  if(fields.filter==='half-delta-planar-v1'){
    if(!template)throw new Error('Missing static RCN2 template');
    const pixels=fields.width*fields.height,images=[];
    for(let image=0;image<4;image++){
      const out=buffer?.images?.[image]||new Uint16Array(pixels*4);
      for(let channel=0;channel<4;channel++){
        const low=image*n+channel*pixels*2,high=low+pixels;let previous=0;
        for(let i=0;i<pixels;i++){if(i%fields.width===0)previous=0;
          previous=(previous+raw[low+i]+raw[high+i]*256)&65535;out[i*4+channel]=previous;}
      }images.push(out);
    }
    const bytes=buffer?.recordBytes||new Uint8Array(template.length);bytes.set(template);
    const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    v.setUint32(8,frame,true);const pathCount=v.getUint32(12,true),nodeCount=v.getUint32(16,true),sampleCount=v.getUint32(20,true);
    const no=64+pathCount*48,so=no+nodeCount*48;
    const projected=new Uint32Array(raw.buffer,raw.byteOffset+n*4,(raw.byteLength-n*4)/4);
    const nodes=new Uint32Array(bytes.buffer,bytes.byteOffset+no,nodeCount*12),samples=new Uint32Array(bytes.buffer,bytes.byteOffset+so,sampleCount*20);
    const expected=nodeCount*fields.nodeProjected.length+sampleCount*fields.sampleProjected.length;
    if(projected.length!==expected)throw new Error('Projected RCN2 word count mismatch');
    let at=0;
    for(let i=0;i<nodeCount;i++)for(const k of fields.nodeProjected)nodes[i*12+k]=projected[at++];
    for(let i=0;i<sampleCount;i++)for(const k of fields.sampleProjected)samples[i*20+k]=projected[at++];
    return {images,recordBytes:bytes,record:parseRCN2(bytes,frame),bytes:n*4+bytes.byteLength};
  }
  if(raw.length < n*4+64)throw new Error('Truncated Stinkhorn frame');
  const images=Array.from({length:4},(_,i)=>new Uint16Array(raw.buffer,raw.byteOffset+i*n,n/2));
  return { images, record:parseRCN2(raw.subarray(n*4),frame), bytes:raw.byteLength };
}
export function fieldTexel(image, offset) { return Array.from(image.subarray(offset,offset+4),halfBitsToFloat); }

// Variable-size NBF payloads, unlike the old eight-plane field store. Bounded
// decoded window and segment cache; cancelled fetches and obsolete generations
// cannot repopulate a disposed store.
export function createStinkhornStore({pkg,urlFor,fetcher=fetch,ahead=10,behind=1}) {
  const samples=new Map(),segments=new Map(),queued=[],controllers=new Set(),pool=[],failures=new Map();
  let running=0,epoch=0,disposed=false;
  const stats={decoded:0,failures:0,decodeMs:0,maxDecodeMs:0,lastError:''};
  const info=pkg.fields, wrap=i=>((i%info.sampleCount)+info.sampleCount)%info.sampleCount;
  async function segment(i) {
    if(segments.has(i))return segments.get(i);
    const token=epoch,controller=new AbortController();controllers.add(controller);
    const promise=(async()=>{
      try {
        const res=await fetcher(urlFor(`${info.directory}/${segmentName(info.filePattern,i)}`),{signal:controller.signal});
        if(!res.ok)throw new Error(`Stinkhorn segment HTTP ${res.status}`);
        const seg=parseSegment(new Uint8Array(await res.arrayBuffer()));
        if(seg.firstSample!==i*info.samplesPerSegment)throw new Error('Segment stamp mismatch');
        return seg;
      } catch(e){if(token===epoch)segments.delete(i);throw e;}
      finally{controllers.delete(controller);}
    })();segments.set(i,promise);return promise;
  }
  function pump() {
    while(!disposed && running<2 && queued.length) {
      const {i,token}=queued.shift(); if(token!==epoch || !samples.has(i))continue;
      running++;
      (async()=>{
        const seg=await segment(Math.floor(i/info.samplesPerSegment));
        const started=performance.now(), at=i%info.samplesPerSegment;
        const raw=await readSample(seg,at,info.codec,seg.entries[at].raw);
        if(token!==epoch || !samples.has(i))return;
        samples.set(i,unpackStinkhornFrame(raw,info,i,pkg.staticRecord,pool.pop()));stats.decoded++;
        const ms=performance.now()-started;stats.decodeMs+=ms;stats.maxDecodeMs=Math.max(stats.maxDecodeMs,ms);
      })().catch(e=>{if(token===epoch){samples.delete(i);failures.set(i,Date.now());stats.failures++;stats.lastError=String(e.message||e);}})
        .finally(()=>{running--;pump();});
    }
  }
  function prefetch(frame) {
    if(disposed || frame<0)return;
    const keep=new Set(); for(let k=-behind;k<=ahead;k++)keep.add(wrap(frame+k));
    for(const [i,entry] of samples)if(!keep.has(i)){if(entry&&pool.length<2)pool.push(entry);samples.delete(i);}
    for(let k=queued.length-1;k>=0;k--)if(!keep.has(queued[k].i))queued.splice(k,1);
    const needed=new Set([...keep].map(i=>Math.floor(i/info.samplesPerSegment)));
    for(const i of segments.keys())if(!needed.has(i))segments.delete(i);
    // Current frame goes first, then future frames; wrap retains the loop head.
    for(let k=0;k<=ahead;k++){const i=wrap(frame+k);if(!samples.has(i)&&(!failures.has(i)||Date.now()-failures.get(i)>2000)){samples.set(i,null);queued.push({i,token:epoch});}}
    pump();
  }
  return {prefetch,get:i=>samples.get(i)||null,stats,
    memoryBytes:()=>[...samples.values(),...pool].reduce((n,v)=>n+(v?.bytes||0),0),
    dispose(){disposed=true;epoch++;queued.length=pool.length=0;samples.clear();segments.clear();failures.clear();for(const c of controllers)c.abort();controllers.clear();}};
}
