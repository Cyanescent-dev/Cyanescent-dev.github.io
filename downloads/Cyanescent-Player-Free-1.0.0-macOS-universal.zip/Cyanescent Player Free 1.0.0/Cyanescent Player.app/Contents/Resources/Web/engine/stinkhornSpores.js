// Small fixed pool in the physical chamber; video loops do not reseed it.
export function createStinkhornSpores(capacity=32){
  const particles=Array.from({length:capacity},()=>({active:false})),vertices=new Float32Array(capacity*4);
  let serial=1,credit=0;
  const random=()=>{serial=(Math.imul(serial,1664525)+1013904223)>>>0;return serial/4294967296;};
  function update(dt,state,interior,enabled){
    if(enabled&&interior>.6)credit+=dt*(.35+state.highs*2.5+state.energy*.5);
    if(credit>1){credit-=1;const p=particles.find(p=>!p.active);
      if(p){const a=random()*Math.PI*2,r=.2+random()*1.05;Object.assign(p,{active:true,x:Math.cos(a)*r,z:Math.sin(a)*r,y:1.7+random()*2.1,age:0,life:5+random()*4,phase:random()*6.28,power:.12+state.highs*.3});}}
    let count=0;
    for(const p of particles)if(p.active){p.age+=dt;p.y+=dt*.024;
      if(p.age>p.life){p.active=false;continue;}
      const fade=Math.min(1,p.age/.8,(p.life-p.age)/1.2);
      vertices.set([p.x+Math.sin(p.phase+p.age*.38)*.018,p.y,p.z+Math.cos(p.phase+p.age*.3)*.016,p.power*fade],count*4);count++;}
    return count;
  }
  return {particles,vertices,update,reset(){for(const p of particles)p.active=false;credit=0;serial=1;vertices.fill(0);}};
}
