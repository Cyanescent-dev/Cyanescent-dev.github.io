export const NEWTON_BASIN_DESCENT_ID = 392;

// Paths and the few numbers the runtime cross-checks against runtime.json (the
// self-describing manifest written by scripts/compile-newton-basin-runtime.mjs,
// which is authoritative for everything else). tools/test-newton-basin.mjs
// verifies this descriptor against the installed package.
export const NEWTON_BASIN_DESCENT = Object.freeze({
  id: NEWTON_BASIN_DESCENT_ID,
  name: "Newton Basin Descent V1",
  assetRoot: "assets/forge/newton-basin-descent",
  manifest: "runtime.json",
  video: "newton-basin-descent-1080p.mp4",
  schema: "cyanescent-newton-basin-runtime",
  packageVersion: 2,
  referenceBPM: 145,
  videoWidth: 1920,
  videoHeight: 1080,
  videoFps: 60,
  sourceFps: 30,
  durationSeconds: 66.2,
  fieldWidth: 320,
  fieldHeight: 180,
  fieldRateHz: 20,
  sampleCount: 1324,
  seamlessLoop: false
});
