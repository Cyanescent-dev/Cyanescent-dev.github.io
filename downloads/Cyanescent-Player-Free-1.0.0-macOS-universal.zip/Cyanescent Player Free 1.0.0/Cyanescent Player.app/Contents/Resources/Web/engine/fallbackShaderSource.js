export const fallbackFragmentSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform vec2 resolution;
uniform float time;
uniform float kick;
uniform float bass;
uniform float mids;
uniform float highs;
uniform float level;
uniform float preset;
uniform float futureEnergy;
uniform float transitionPhase;

#define PI 3.14159265359

vec3 fallbackPalette(float t) {
  return 0.52 + 0.48 * cos(PI * 2.0 * (vec3(0.00, 0.33, 0.67) + t));
}

float fallbackLine(vec2 p, vec2 a, vec2 b, float width) {
  vec2 pa = p - a;
  vec2 ba = b - a;
  float h = clamp(dot(pa, ba) / max(dot(ba, ba), 0.0001), 0.0, 1.0);
  return 1.0 - smoothstep(width, width * 2.8, length(pa - ba * h));
}

float fallbackCircle(vec2 p, float radius, float width) {
  return 1.0 - smoothstep(width, width * 2.8, abs(length(p) - radius));
}

float fallbackBlob(vec2 p, vec2 radii) {
  return 1.0 - smoothstep(1.0, 1.22, length(p / radii));
}

float fallbackFlower(vec2 p) {
  float f = fallbackCircle(p, 0.18, 0.007);
  for (int i = 0; i < 6; i++) {
    float a = float(i) * PI / 3.0;
    vec2 c = vec2(cos(a), sin(a)) * 0.18;
    f += fallbackCircle(p - c, 0.18, 0.006);
    vec2 c2 = vec2(cos(a + PI / 6.0), sin(a + PI / 6.0)) * 0.31;
    f += fallbackCircle(p - c2, 0.18, 0.005) * 0.65;
  }
  return f;
}

vec3 fallbackEvolution(vec2 p) {
  float journey = mod(time, 60.0);
  float stage = journey < 8.0 ? 0.0 : journey < 16.0 ? 1.0 : journey < 26.0 ? 2.0 : journey < 34.0 ? 3.0 : journey < 44.0 ? 4.0 : journey < 54.0 ? 5.0 : 6.0;
  float r = length(p);
  vec3 color = mix(vec3(0.018, 0.010, 0.018), vec3(0.004, 0.018, 0.030), smoothstep(-0.9, 0.9, p.y));
  float pulse = max(kick, max(bass, level));
  if (stage < 0.5) {
    color = mix(vec3(0.14, 0.035, 0.012), vec3(0.004, 0.006, 0.020), smoothstep(-0.65, 0.90, p.y));
    for (int i = 0; i < 3; i++) {
      float fi = float(i);
      float x = -0.65 + fi * 0.62;
      float ridge = -0.78 + (1.0 - clamp(abs(p.x - x) / 0.34, 0.0, 1.0)) * 0.42;
      float cone = (1.0 - smoothstep(ridge - 0.03, ridge + 0.03, p.y)) * smoothstep(-1.04, -0.78, p.y);
      float lava = fallbackLine(p, vec2(x, ridge), vec2(x + 0.08 * sin(fi), -0.84), 0.006 + bass * 0.004);
      color += vec3(0.15, 0.07, 0.03) * cone + vec3(1.0, 0.34, 0.04) * lava * 0.45;
    }
    for (int i = 0; i < 4; i++) {
      float fi = float(i);
      float ph = fract(time * (0.04 + fi * 0.005) + fi * 0.23);
      vec2 head = vec2(mix(1.2, -1.15, ph), 0.82 - ph * 0.95 + fi * 0.04);
      color += vec3(1.0, 0.7, 0.35) * fallbackLine(p, head + vec2(0.16, 0.08), head, 0.004) * 0.5;
    }
  } else if (stage < 1.5) {
    color = mix(vec3(0.002, 0.022, 0.026), vec3(0.010, 0.075, 0.064), smoothstep(-0.9, 0.75, p.y));
    for (int i = 0; i < 8; i++) {
      float fi = float(i);
      vec2 pos = vec2(cos(fi * 2.399 + time * 0.16), sin(fi * 1.7 + time * 0.13)) * vec2(0.55, 0.34);
      vec2 local = p - pos;
      float wobble = 0.016 * sin(atan(local.y, local.x) * 5.0 + time * 1.2 + fi);
      color += fallbackPalette(0.15 + fi * 0.08) * fallbackBlob(local, vec2(0.085 + wobble, 0.060 + pulse * 0.012)) * 0.42;
    }
    for (int i = 0; i < 9; i++) {
      float fi = float(i);
      vec2 root = vec2(-1.0 + fi * 0.25, -0.82);
      vec2 tip = root + vec2(0.05 * sin(time * 0.2 + fi), 0.26 + 0.10 * sin(fi));
      color += vec3(0.09, 0.48, 0.23) * fallbackLine(p, root, tip, 0.006) * 0.28;
    }
  } else if (stage < 2.5) {
    color = mix(vec3(0.002, 0.018, 0.045), vec3(0.01, 0.16, 0.22), 1.0 - smoothstep(-0.8, 0.9, p.y));
    color += vec3(0.12, 0.46, 0.62) * smoothstep(0.86, 1.0, abs(sin(p.y * 8.0 + time * 0.6))) * 0.10;
    for (int i = 0; i < 18; i++) {
      float fi = float(i);
      vec2 pos = vec2(cos(fi * 0.55 + time * 0.24), sin(fi * 0.83 + time * 0.18)) * vec2(0.72, 0.40);
      vec2 local = (p - pos) * mat2(1.0, 0.0, 0.0, 1.0);
      color += fallbackPalette(0.54 + fi * 0.025) * (fallbackBlob(local, vec2(0.055, 0.022)) + fallbackBlob(local + vec2(0.060, 0.0), vec2(0.028, 0.030)) * 0.7) * 0.42;
    }
  } else if (stage < 3.5) {
    float pond = fallbackBlob((p - vec2(0.0, -0.12)) * vec2(0.85, 1.12), vec2(0.85, 0.55));
    color = mix(vec3(0.13, 0.08, 0.035), vec3(0.004, 0.065, 0.054), pond);
    for (int i = 0; i < 7; i++) {
      float fi = float(i);
      vec2 pos = vec2(cos(fi * 0.9 + time * 0.18), sin(fi * 1.3 + time * 0.13)) * vec2(0.62, 0.34) + vec2(0.0, -0.10 + kick * 0.05);
      color += vec3(0.18, 0.75, 0.30) * fallbackBlob(p - pos, vec2(0.055, 0.080)) * 0.48;
      color += vec3(1.0, 0.85, 0.35) * fallbackCircle(p - pos - vec2(0.0, 0.08), 0.012, 0.005) * 0.35;
    }
  } else if (stage < 4.5) {
    color = vec3(0.006, 0.014, 0.008) + vec3(0.035, 0.15, 0.04) * smoothstep(0.5, 1.0, sin(p.x * 6.0 + p.y * 4.0 + time * 0.18));
    color += vec3(0.18, 0.09, 0.035) * fallbackLine(p, vec2(-0.78, -0.95), vec2(-0.64, 0.82), 0.050);
    color += vec3(0.12, 0.40, 0.10) * fallbackLine(p, vec2(-0.66, 0.42), vec2(0.55, 0.48), 0.030);
    for (int i = 0; i < 7; i++) {
      float fi = float(i);
      vec2 pos = vec2(-0.55 + fi * 0.18, -0.35 + kick * 0.06 + 0.12 * sin(time * 0.8 + fi));
      if (i == 0) pos = vec2(-0.18 + sin(time * 0.8) * 0.22, 0.18 - cos(time * 0.8) * 0.22);
      color += vec3(0.72, 0.42, 0.16) * (fallbackBlob(p - pos, vec2(0.040, 0.075)) + fallbackCircle(p - pos - vec2(0.0, 0.09), 0.030, 0.016)) * 0.56;
    }
  } else if (stage < 5.5) {
    color = vec3(0.010, 0.004, 0.020);
    vec2 peak = vec2(0.0, 0.56);
    vec2 la = vec2(-1.05, -0.52);
    vec2 ra = vec2(1.05, -0.52);
    color += vec3(0.18, 0.80, 1.0) * (fallbackLine(p, la, peak, 0.012) + fallbackLine(p, ra, peak, 0.012) + fallbackLine(p, la, ra, 0.006)) * 0.38;
    for (int i = 0; i < 7; i++) {
      float fi = float(i);
      vec2 pos = vec2(cos(fi * 0.9) * 0.52, sin(fi * 0.9) * 0.25 - 0.15 + kick * 0.06);
      vec2 local = p - pos;
      color += fallbackPalette(0.60 + fi * 0.05) * (fallbackLine(local, vec2(0.0, -0.08), vec2(0.0, 0.08), 0.010) + fallbackCircle(local - vec2(0.0, 0.12), 0.025, 0.012)) * 0.65;
    }
    for (int i = 0; i < 7; i++) {
      float fi = float(i);
      color += fallbackPalette(0.54 + fi * 0.08) * fallbackLine(p, vec2(0.0, 0.70), vec2(cos(-0.8 + fi * 0.27) * 1.2, sin(-0.8 + fi * 0.27) * 0.8), 0.0025) * 0.35;
    }
  } else {
    float reveal = smoothstep(54.8, 59.0, journey);
    for (int i = 0; i < 12; i++) {
      float fi = float(i);
      vec2 start = vec2(cos(fi * 2.399 + time * 0.10), sin(fi * 1.7 + time * 0.08)) * vec2(0.68, 0.40);
      vec2 pos = mix(start, vec2(0.0), reveal);
      color += vec3(1.0, 0.90, 0.62) * (fallbackLine(p - pos, vec2(0.0, -0.06), vec2(0.0, 0.06), 0.005) + fallbackCircle(p - pos - vec2(0.0, 0.09), 0.020, 0.008)) * 0.72;
    }
    float flower = fallbackFlower(p * (0.95 - bass * 0.02));
    color += vec3(1.0, 0.86, 0.42) * flower * reveal * 0.90 + vec3(0.50, 0.94, 1.0) * flower * highs * reveal * 0.22;
  }
  float carry = (1.0 - smoothstep(0.0, 5.0, journey)) * fallbackFlower(p * 0.95);
  color += vec3(1.0, 0.84, 0.44) * carry * 0.70;
  color *= 1.0 - smoothstep(1.18, 1.72, r) * 0.72;
  return color / (1.0 + color * 0.55);
}

void main() {
  vec2 uv = vUv;
  vec2 p = (uv - 0.5) * vec2(resolution.x / max(resolution.y, 1.0), 1.0);
  if (preset > 42.5 && preset < 43.5) {
    outColor = vec4(pow(fallbackEvolution(p), vec3(0.90)), 1.0);
    return;
  }
  float r = length(p);
  float a = atan(p.y, p.x);
  float pulse = max(level, max(bass, kick));
  float mode = preset * 0.037;
  float tunnel = smoothstep(0.72, 1.0, sin(24.0 * log(r + 0.08) - time * (0.9 + pulse * 1.8) + a * (5.0 + sin(mode) * 3.0)));
  float lattice = smoothstep(0.84, 1.0, abs(sin(p.x * 10.0 + sin(p.y * 5.0 + time * 0.24) * 2.0)) * abs(sin(p.y * 9.0 - time * 0.18)));
  float ring = exp(-abs(r - (0.28 + 0.24 * sin(time * 0.09 + futureEnergy))) * 8.0);
  vec3 color = vec3(0.010, 0.014, 0.018);
  color += fallbackPalette(0.10 + a / (PI * 2.0) + time * 0.018 + mode) * tunnel * exp(-r * 0.72) * (0.18 + pulse * 0.40);
  color += fallbackPalette(0.45 + r * 0.32 + time * 0.012) * lattice * (0.08 + mids * 0.18 + highs * 0.12);
  color += fallbackPalette(0.72 + time * 0.020) * ring * (0.10 + kick * 0.32);
  color *= 1.0 - smoothstep(1.18, 1.65, r);
  color = color / (1.0 + color * 0.64);
  outColor = vec4(pow(color, vec3(0.90)), 1.0);
}`;
