// Artificial Consciousness: the per-frame timeline package layout, shared by the compiler
// (scripts/compile-artificial-consciousness-runtime.mjs), the runtime and the tests. No DOM, no GL.
//
// The export's metadata.jsonl carries, for every video frame, the Forge's GPU header (the story
// state, entity frame, clocks, lobes ...) and the camera. timeline.bin keeps exactly what the
// placement law needs, as 28 vec4 slots per frame (448 bytes), so the runtime can rebuild the
// network for the frame the video is showing and upload one frame as a std140 uniform block.
import { frameStateFromMetadata } from "./artificialConsciousnessNetwork.js";

export const TIMELINE_SLOTS = Object.freeze([
  "stage", "awake", "trans", "torus", "disc", "centre", "axisX", "axisY", "axisZ", "attention", "clocks",
  "look2", "warp", "flow", "aperture", "lobeAngle0", "lobeAngle1", "lobeAmp0", "lobeAmp1", "lobeWidth0", "lobeWidth1",
  "camPos", "camForward", "camRight", "camUp", "story", "mood", "time"
]);
export const TIMELINE_SLOT_COUNT = TIMELINE_SLOTS.length;
export const TIMELINE_FLOATS = TIMELINE_SLOT_COUNT * 4;
export const PHASES = Object.freeze(["computation", "self-organization", "coherence", "attention", "awakening", "transcendence"]);

const slot = (name) => TIMELINE_SLOTS.indexOf(name);
const pad4 = (list) => [list[0] ?? 0, list[1] ?? 0, list[2] ?? 0, list[3] ?? 0];

// One metadata.jsonl line -> TIMELINE_FLOATS floats.
export function packFrame(meta) {
  const h = meta.world.header, c = meta.camera, w = meta.world;
  const out = new Float32Array(TIMELINE_FLOATS);
  const put = (name, values) => out.set(pad4(values), slot(name) * 4);
  put("stage", h.stage); put("awake", h.awake); put("trans", h.trans); put("torus", h.torus); put("disc", h.disc);
  put("centre", h.centre); put("axisX", h.axisX); put("axisY", h.axisY); put("axisZ", h.axisZ);
  put("attention", h.attention); put("clocks", h.clocks); put("look2", h.look2); put("warp", h.warp);
  put("flow", h.flow); put("aperture", h.aperture);
  put("lobeAngle0", h.lobeAngle0); put("lobeAngle1", h.lobeAngle1); put("lobeAmp0", h.lobeAmp0); put("lobeAmp1", h.lobeAmp1);
  put("lobeWidth0", h.lobeWidth0); put("lobeWidth1", h.lobeWidth1);
  put("camPos", [...c.position, c.tanHalfVerticalFOV]);
  put("camForward", [...c.forward, c.aspect]);
  put("camRight", [...c.right, meta.resolution.beauty[0]]);
  put("camUp", [...c.up, meta.resolution.beauty[1]]);
  put("story", [w.story.emergence, w.story.coherence, w.story.awakening, w.story.transcendence]);
  put("mood", [w.consciousness, w.synchrony, w.attention.weight, w.aperture.openness]);
  put("time", [meta.beats, meta.bar, Math.max(0, PHASES.indexOf(w.phase)), meta.frame]);
  return out;
}

// timeline floats of one frame -> the same plain-number frame state frameStateFromMetadata gives
// (the CPU reference path; tests compare the two).
export function unpackFrame(floats, look, seed, offset = 0) {
  const get = (name) => Array.from(floats.subarray(offset + slot(name) * 4, offset + slot(name) * 4 + 4));
  const camPos = get("camPos"), camFwd = get("camForward"), camRight = get("camRight"), camUp = get("camUp");
  return {
    seed: seed >>> 0,
    stage: get("stage"), awake: get("awake"), trans: get("trans"), torus: get("torus"), disc: get("disc"),
    centre: get("centre"), axisX: get("axisX"), axisY: get("axisY"), axisZ: get("axisZ"), attention: get("attention"),
    clocks: get("clocks"), look: look.slice(), look2: get("look2"), warp: get("warp"), flow: get("flow"), aperture: get("aperture"),
    lobeAngle: [...get("lobeAngle0"), ...get("lobeAngle1")], lobeAmp: [...get("lobeAmp0"), ...get("lobeAmp1")],
    lobeWidth: [...get("lobeWidth0"), ...get("lobeWidth1")],
    regionCount: 6,
    camera: {
      position: camPos.slice(0, 3), forward: camFwd.slice(0, 3), right: camRight.slice(0, 3), up: camUp.slice(0, 3),
      tanHalfFov: camPos[3], aspect: camFwd[3], width: camRight[3], height: camUp[3]
    }
  };
}

// The story scalars the music layer reads, from one frame of the timeline.
export function storyAt(floats, offset = 0) {
  const at = (name, k) => floats[offset + slot(name) * 4 + k];
  return {
    emergence: at("story", 0), coherence: at("story", 1), awakening: at("story", 2), transcendence: at("story", 3),
    consciousness: at("mood", 0), synchrony: at("mood", 1), attention: at("mood", 2), aperture: at("mood", 3),
    beats: at("time", 0), bar: at("time", 1), phase: at("time", 2),
    lift: at("stage", 0), fold: at("stage", 1), breath: at("awake", 0), front: at("awake", 1), aligned: at("awake", 2),
    colourState: at("awake", 3), expansion: at("trans", 1), peel: at("trans", 2), frontRadius: at("flow", 2)
  };
}

// Frame the video is showing at media time `seconds` (the video and the timeline are both 30 fps).
export function frameIndexAt(seconds, fps, count) {
  const index = Math.round(seconds * fps);
  return Math.min(count - 1, Math.max(0, index));
}

export { frameStateFromMetadata };
