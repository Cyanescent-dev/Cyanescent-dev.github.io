// Shadow Geometry: Impossible Apertures — music -> geometry, light and journey (pure JS, testable).
//
// It consumes Player's existing analysis through the shared music model (newtonBasinAudio.js: beat
// grid, groove, build, breakdown, drop and hi-hat events that work on loud mastered tracks) plus the
// 0.5/5/20-second lookahead. Music changes the sculptures' configuration, the lights and the
// journey, not just brightness:
//
//   energy      how much of the world is lit: one light in a breakdown, every coloured light and
//               dense light shafts at the peak; travel speed
//   bass        aperture dilation (orrery), torus breathing (weave), shaft density
//   kicks       a band of light running along the aperture rims pole to pole (orrery), pulses
//               running round the ribbons (weave), a ring expanding through the polytope (lattice);
//               the main light flares
//   mids        relative rotation of the orrery's shells (shadow moire), the weave's fibre flow,
//               the coloured lights' orbits
//   highs/hats  glints and rim light
//   breakdown   components separate (shells move apart, louvres close, lights scatter and dim),
//               the camera slows
//   build       components move towards alignment (orrery apertures line up so the shadow cleans
//               into one spiral, louvres open, the lattice's coloured lights converge on L* so
//               their shadows merge), the light contracts just before the predicted drop, and the
//               camera times its arrival at the next viewpoint for the boundary
//   drop        the orrery's polar irises open and the camera flies through the sculpture; the
//               weave's louvres snap open; the lattice's lights snap to L*; light floods the haze
import { createNewtonAudioModel, follow } from "./newtonBasinAudio.js";
import { SPACING, MEMBRANE_R, holdPoints, stationAt, sculptureClearance, cameraPose, v3 } from "./impossibleAperturesJourney.js";

const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const TAU = Math.PI * 2;

export const START_S = -62;            // outside the first membrane, the lantern ahead
const IRIS_OPEN = 0.98;                // radians: polar iris half-angle when open
// Where on a station the camera should be when a predicted drop lands (local u).
const dropTarget = (station) => (station.type === "lattice" ? station.lattice.uV : station.type === "orrery" ? -17 : -24);

export function createImpossibleAperturesDirector() {
  const audioModel = createNewtonAudioModel();
  const stations = new Map();
  const modes = new Map();
  const s = {};
  const stationFor = (k) => {
    if (!stations.has(k)) stations.set(k, stationAt(k));
    return stations.get(k);
  };
  const modeFor = (k) => {
    if (!modes.has(k)) modes.set(k, { through: 0, throughGoal: 0, iris: -0.12, irisGoal: -0.12 });
    return modes.get(k);
  };

  function reset() {
    audioModel.reset();
    stations.clear(); modes.clear();
    Object.assign(s, {
      time: 0, s: START_S, speed: 4.5, speedBoost: 0,
      energy: 0.35, bass: 0.2, mids: 0.25, highs: 0.2, groove: 0, breakdown: 0, build: 0,
      tension: 0, future: 0, previousKick: 0, breakAt: null, lastDropAt: -100, collapseSince: null, lastRelaxAt: -100,
      kickPulse: 0, kickAge: 10, flash: 0, surge: 0, hatGlint: 0, preDrop: 0,
      // orrery
      orFlow: 0, orSpinOut: 0, orDelta: 0.5, orInnerOpen: 0, orSeparate: 0, orHole: 0,
      // weave
      wvPhase1: 0, wvPhase2: 0, wvLouver: 0.12, wvLouverKick: 0, wvBreath: 0, wvKickPhi: 0,
      // lattice
      latConverge: 0.3, latOrbit: 0, latKickR: 2, latSnap: 0,
      lightOrbit: 0, exposure: 1, haze: 0.5, saturation: 1.05, levelPeak: 0.3, tilt: 0, tiltGoal: 0, forcedDrop: false,
      kicks: 0, hats: 0, drops: 0, throughs: 0, holds: 0, phase: "intro", event: ""
    });
  }
  reset();

  function currentIndex(z) {
    // The station whose membrane the camera is in or approaching.
    return Math.ceil((z - MEMBRANE_R) / SPACING - 1e-9);
  }

  function step(dt, input = {}, controls = {}) {
    dt = clamp(dt, 0, 0.1);
    s.time += dt;
    const { audio = {}, smooth: smoothBands = {}, music = {}, lookahead = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth: smoothBands, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    const reactive = clamp(controls.reactive ?? 1, 0, 1.5);
    s.event = "";

    // ---- envelopes -------------------------------------------------------------------------------
    const fast = clamp(audio.globalEnergyFast ?? a.energyFast), slow = clamp(audio.globalEnergySlow ?? a.energySlow);
    const energyNow = clamp(fast * 0.5 + slow * 0.2 + clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.3);
    // Loud masters saturate every absolute level (a psytrance drive sits near 0.9 throughout), so
    // energy is built from structure: the groove, the level relative to the track's own recent peak,
    // and the post-drop surge. A drive sits near 0.65, a breakdown near 0.2, after a drop near 1.
    s.levelPeak = Math.max(energyNow, s.levelPeak - dt * s.levelPeak / 90);
    const rel = clamp((energyNow / Math.max(s.levelPeak, 0.05) - 0.55) / 0.45);
    s.mids = follow(s.mids, a.midDrive, dt, 0.1, 0.5);
    s.highs = follow(s.highs, a.highDrive, dt, 0.03, 0.2);
    s.bass = follow(s.bass, Math.max(a.subDrive, clamp(((audio.bassRel ?? 1) - 0.8) * 1.6)), dt, 0.08, 0.6);
    s.groove = a.groove; s.breakdown = a.breakdown; s.build = a.build;
    const energyGoal = clamp(0.12 + 0.38 * s.groove * (1 - 0.6 * s.breakdown) + 0.15 * rel + 0.38 * s.surge + 0.08 * s.highs * s.groove);
    s.energy = follow(s.energy, energyGoal * reactive + 0.3 * (1 - reactive), dt, 0.4, 1.4);
    const E = s.energy;

    // ---- lookahead: is a strong return coming? (as in Clifford Metamorphosis) ----------------------
    const current = lookahead.current || {}, med = lookahead.medium || {}, long = lookahead.long || {};
    const rise = clamp(((med.maxEnergy || med.energy || 0) - (current.energy || 0) - 0.08) * 3.2);
    const bassReturn = clamp(((med.bass || 0) - (current.bass || 0) - 0.035) * 3);
    const farRise = clamp(((long.energy || 0) - (current.energy || 0) - 0.12) * 2);
    s.future = lookahead.ready
      ? clamp(Math.max(clamp(music.upcomingDrop) * 1.4, rise * (0.5 + 0.5 * bassReturn), clamp(music.upcomingBuild) * 0.5, farRise * 0.4))
      : 0;
    const phraseSeconds = Number(music.nextPhraseSeconds);
    const phraseValid = Number.isFinite(phraseSeconds) && phraseSeconds > 0;
    const quiet = s.groove < 0.35 || s.breakdown > 0.6;
    const pulseNow = clamp(audio.kickPulse), lowNow = clamp(audio.bassNow ?? smoothBands.bass);
    const onset = pulseNow > 0.48 && s.previousKick <= 0.48 && lowNow > 0.3;
    s.previousKick = pulseNow;
    let grooveReturn = 0;
    if (quiet) { if (s.breakAt === null) s.breakAt = s.time; }
    if (s.breakAt !== null && (onset || events.drop || (!quiet && s.groove > 0.6))) {
      const gap = s.time - s.breakAt;
      if (s.tension > 0.3 && gap > 1.5) { grooveReturn = Math.max(gap, 3); s.breakAt = null; }
      else if (gap > 0.8 && (!quiet || gap >= 3)) { grooveReturn = gap; s.breakAt = null; }
      else if (!quiet) s.breakAt = null;
    }
    const breakAge = s.breakAt === null ? 0 : s.time - s.breakAt;

    // Tension: the configuration moves towards alignment ahead of a predicted drop; an
    // energy-confirmed build without lookahead tightens part of the way. False alarms relax.
    const evidence = bassReturn > 0.15 || rise > 0.45 || clamp(music.upcomingDrop) > 0.5;
    const confident = clamp(music.upcomingDrop) > 0.8;
    // The kick often keeps running through a build, so a prediction does not wait for silence: the
    // lookahead must expect a strong return and the groove must be loosening or a build under way.
    const loosening = quiet || s.groove < 0.8 || a.build > 0.5;
    const predicted = loosening && s.future > 0.6 && evidence && phraseValid && phraseSeconds < 9 && s.time > 6
      && s.time - s.lastDropAt > 12 && (s.time - s.lastRelaxAt > 16 || confident);
    const confirmedBuild = a.build > 0.6 && quiet && breakAge > 1.2;
    let goal = 0;
    if (predicted) goal = clamp(s.future * 1.25) * clamp((9 - phraseSeconds) / 7);
    else if (confirmedBuild) goal = 0.6 * a.build;
    goal *= clamp(controls.anticipation ?? 1);
    if (goal > 0.2 && s.collapseSince === null) s.collapseSince = s.time;
    if (s.collapseSince !== null && (s.time - s.collapseSince > 14 || goal < 0.05)) {
      s.collapseSince = null; s.lastRelaxAt = s.time; goal = 0;
    }
    s.tension = follow(s.tension, goal, dt, 0.6, 1.6);
    // The last ~1.5 s before a predicted boundary the light contracts.
    s.preDrop = follow(s.preDrop, predicted && phraseSeconds < 1.6 ? 1 : 0, dt, 0.25, 0.15);

    // ---- where are we ----------------------------------------------------------------------------
    const k = currentIndex(s.s);
    const st = stationFor(k);
    const u = s.s - st.center[2];
    const mode = modeFor(k);

    // ---- drops -----------------------------------------------------------------------------------
    const forced = Number.isFinite(controls.dropAt) && s.time >= controls.dropAt && !s.forcedDrop;
    if (forced) s.forcedDrop = true;
    const dropEvent = (grooveReturn >= 3 || forced)
      && s.time > 4 && s.time - s.lastDropAt > 6 && (controls.drops ?? 1) > 0;
    if (dropEvent) {
      s.lastDropAt = s.time; s.drops += 1; s.tension = 0; s.collapseSince = null;
      s.flash = 1; s.surge = 1; s.speedBoost = 1;
      s.event = `drop:${st.type}`;
      if (st.type === "orrery" && u < -15) {
        // An enormous aperture opens and the camera goes through.
        mode.irisGoal = IRIS_OPEN; mode.throughGoal = 1; s.throughs += 1;
      } else if (st.type === "orrery" && u < 26) {
        // Too close to fly in: the irises open anyway and the sculpture tilts, so its polar beams
        // sweep across the membrane.
        mode.irisGoal = IRIS_OPEN; s.tiltGoal = 1;
      }
      if (st.type === "weave") s.wvLouverKick = 1;
      if (st.type === "lattice") { s.latSnap = 1; s.latKickR = 0; }
    }
    // A shorter break (a one-bar kick drop) is a rebound: a flare and a kick wave.
    if (grooveReturn > 0.8 && !dropEvent && s.time - s.lastDropAt > 2) { s.flash = Math.max(s.flash, 0.4); s.surge = Math.max(s.surge, 0.5); }

    // ---- kicks and hats ----------------------------------------------------------------------------
    for (const wave of events.waves) {
      if (wave.kind !== "kick") continue;
      s.kicks += 1;
      s.kickPulse = Math.max(s.kickPulse, (0.6 + 0.4 * (wave.beatInBar === 0 ? 1 : 0.7)) * reactive);
      s.kickAge = 0;
      s.wvKickPhi = (s.wvKickPhi + 2.4) % TAU;
      if (s.latKickR > 1.3) s.latKickR = 0;
    }
    if (events.hats && s.highs > 0.15) { s.hats += 1; s.hatGlint = Math.min(1, s.hatGlint + 0.5); }
    s.kickAge += dt;
    s.kickPulse *= Math.exp(-dt / 0.16);
    s.hatGlint *= Math.exp(-dt / 0.12);
    s.flash *= Math.exp(-dt / 0.7);
    s.surge *= Math.exp(-dt / 7);
    s.speedBoost *= Math.exp(-dt / 3.0);
    s.latKickR = Math.min(2, s.latKickR + dt * 2.2);
    s.latSnap *= Math.exp(-dt / 4);

    // ---- sculpture configuration --------------------------------------------------------------------
    const B = clamp(s.breakdown * (1 - s.groove));
    const T = s.tension;
    // Orrery: the apertures stream from pole to pole along the loxodromes; the inner shell's mirror
    // lattice flows the other way (delta), so the core's projection is a moire of two spirals whose
    // symmetry keeps changing. Alignment (tension, drops) opens the inner apertures wide and the
    // shadow simplifies to the outer spiral alone; breakdowns close them to sparse points.
    s.orFlow = (s.orFlow + dt * (0.025 + 0.06 * E + 0.05 * s.bass + 0.3 * s.surge) * reactive) % 1;
    s.orDelta += dt * (0.02 + 0.07 * s.mids + 0.1 * s.surge) * reactive;
    const innerGoal = Math.max(0.42 * smooth(0.05, 0.6, T), 0.3 * s.surge) - 0.3 * B + 0.06 * (E - 0.5);
    s.orInnerOpen = follow(s.orInnerOpen, innerGoal, dt, 0.8, 1.6);
    s.orSpinOut = (s.orSpinOut + dt * (0.02 + 0.05 * s.mids) * reactive) % TAU;
    s.orSeparate = follow(s.orSeparate, B, dt, 2.5, 1.5);
    s.orHole = follow(s.orHole, 0.06 * s.bass + 0.05 * s.kickPulse - 0.08 * B, dt, 0.05, 0.4);
    // Weave: fibres flow round their tori (counter-rotating), louvres open with energy and builds.
    s.wvPhase1 = (s.wvPhase1 + dt * (0.04 + 0.22 * s.mids + 0.15 * s.surge) * reactive) % TAU;
    s.wvPhase2 = (s.wvPhase2 - dt * (0.03 + 0.17 * s.mids + 0.12 * s.surge) * reactive + TAU) % TAU;
    const louverGoal = 0.1 + 0.35 * E + 0.9 * T - 0.1 * B;
    s.wvLouver = follow(s.wvLouver, louverGoal, dt, 1.2, 1.8);
    s.wvLouverKick *= Math.exp(-dt / 2.4);
    s.wvBreath = follow(s.wvBreath, s.bass * 0.7 + 0.5 * s.kickPulse, dt, 0.06, 0.35);
    // Lattice: the coloured lights converge on L* as tension rises, scatter in breakdowns.
    const convGoal = Math.max(T > 0.05 ? 0.35 + 0.65 * smooth(0, 0.8, T) : 0.25 + 0.25 * Math.sin(s.time * 0.21) ** 2 - 0.25 * B, s.latSnap);
    s.latConverge = follow(s.latConverge, clamp(convGoal), dt, s.latSnap > 0.5 ? 0.15 : 1.5, 1.5);
    s.latOrbit += dt * (0.05 + 0.25 * s.mids) * reactive;
    s.lightOrbit += dt * (0.06 + 0.22 * s.mids) * reactive;

    // ---- modes (orrery iris and through-path) ------------------------------------------------------
    for (const [kk, m] of modes) {
      const local = s.s - stationFor(kk).center[2];
      if (local > 16) { m.irisGoal = -0.12; m.throughGoal = 0; }
      m.iris = follow(m.iris, m.irisGoal, dt, 1.1, 2.2);
      // The path only commits to the opening while the iris is open enough to clear the shells.
      const ready = clamp((m.iris - 0.55) / 0.3);
      m.through = follow(m.through, m.throughGoal * ready, dt, 0.9, 1.2);
    }
    // Anticipation: approaching an orrery while a drop is predicted, the irises crack open and the
    // path commits to flying through (the opening completes on the drop; it closes if none comes).
    if (st.type === "orrery" && u < -14 && u > -60) {
      if (T > 0.3) { mode.throughGoal = 1; mode.irisGoal = Math.max(mode.irisGoal, 0.25 + 0.3 * T); }
      else if (mode.irisGoal < IRIS_OPEN && mode.throughGoal > 0 && T < 0.1) { mode.throughGoal = 0; mode.irisGoal = -0.12; }
    }
    if (controls.through) { mode.irisGoal = IRIS_OPEN; mode.throughGoal = 1; }
    s.tiltGoal *= Math.exp(-dt / 3.5);
    s.tilt = follow(s.tilt, s.tiltGoal, dt, 1.2, 2.5);

    // ---- travel ----------------------------------------------------------------------------------
    let base = (3.2 + 4.6 * E) * (1 - 0.35 * B) * (1 + 0.6 * s.speedBoost);
    // Holds: slow down at the axial view and, strongly, at the anamorphic viewpoint.
    let hold = 1, steered = false;
    for (const kk of [k, k + 1]) {
      const sk = stationFor(kk);
      for (const hp of holdPoints(sk)) {
        const dz = s.s - (sk.center[2] + hp.u);
        const near = 1 - smooth(0, hp.width, Math.abs(dz));
        const strength = hp.kind === "alignment" ? 0.96 : 0.5 * (0.6 + 0.6 * B);
        hold = Math.min(hold, 1 - strength * near * hp.weight);
      }
      // Ahead of a predicted drop: time the arrival at this station's drop point for the boundary
      // (the anamorphic viewpoint, or the place where the orrery's opening iris can be entered).
      const target = dropTarget(sk);
      const dz = s.s - (sk.center[2] + target);
      if (T > 0.3 && phraseValid && dz < -4 && dz > -90 && !steered) {
        const want = clamp(-dz / Math.max(phraseSeconds, 0.5), base * 0.45, base * 2.4);
        base = base + (want - base) * T;
        steered = true;
      }
    }
    if (controls.freeze) base = 0;
    if (Number.isFinite(controls.speed)) base = controls.speed;
    s.speed = follow(s.speed, base * Math.max(hold, 0.05), dt, 0.6, 0.6);
    // Never stall completely, but the alignment hold lingers.
    s.s += Math.max(s.speed, controls.freeze || controls.speed === 0 ? 0 : 0.18) * dt;
    if (Number.isFinite(controls.s)) s.s = controls.s;

    // ---- grade --------------------------------------------------------------------------------------
    s.exposure = (0.85 + 0.35 * E + 0.25 * s.flash - 0.12 * B - 0.35 * s.preDrop) * (controls.brightness ?? 1);
    s.haze = (0.25 + 0.75 * E + 0.6 * s.surge + 0.25 * s.bass - 0.25 * s.preDrop) * (controls.haze ?? 1);
    s.saturation = 1.05 + 0.15 * E - 0.1 * B;
    s.phase = dropEvent ? "drop" : T > 0.3 ? "build" : B > 0.5 ? "breakdown" : E > 0.8 ? "peak" : "drive";
    return events;
  }

  // Everything the renderer needs for this frame, derived from the state (no side effects except
  // creating stations and modes on first use).
  function frame() {
    const k = currentIndex(s.s);
    const pose = cameraPose(s.s, stationFor, modeFor, { time: s.time });
    return { k, pose, current: stationFor(k), next: stationFor(k + 1), modeCurrent: modeFor(k), modeNext: modeFor(k + 1) };
  }

  return { state: s, step, reset, frame, stationFor, modeFor, audioState: audioModel.state, currentIndex };
}

export { sculptureClearance, v3 };
