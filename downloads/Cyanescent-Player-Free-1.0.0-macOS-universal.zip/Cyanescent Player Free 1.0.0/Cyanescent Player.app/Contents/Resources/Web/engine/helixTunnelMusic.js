// Choreography over Player's existing band/onset/groove model, beat grid and
// genuine 0.5/5/20-second lookahead. No independent audio analysis.
import { createNewtonAudioModel, follow } from './newtonBasinAudio.js';
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number(x) || 0));
export function energyVelocity(energy) {
  const e = clamp(energy); return 1.25 + 1.35 * Math.pow(e, 1.2);
}
export function createHelixMusic() {
  const audioModel = createNewtonAudioModel();
  const s = { time: 0, velocity: 1.35, acceleration: 0, target: 1.35, energy: 0, tension: 0,
    impulse: 0, flash: 0, kick: 0, bass: 0, mids: 0, highs: 0, hat: 0, phase: 'cruise',
    kickCount: 0, dropCount: 0, recoilCount: 0, breakAge: 0, future: 0, thrust: 0, pressure: 0 };
  let lastKick = -100, previousKick = 0, lastDrop = -100, breakAt = null, armed = false;
  let recoilAt = -100, recoiled = false, hadDrive = false, beatIndex = null, returnAt = null, brakeAt = null;
  function reset() {
    audioModel.reset(); Object.assign(s, { time: 0, velocity: 1.35, acceleration: 0, target: 1.35, energy: 0,
      tension: 0, impulse: 0, flash: 0, kick: 0, bass: 0, mids: 0, highs: 0, hat: 0, phase: 'cruise',
      kickCount: 0, dropCount: 0, recoilCount: 0, breakAge: 0, future: 0, thrust: 0, pressure: 0 });
    lastKick = lastDrop = recoilAt = -100; previousKick = 0; breakAt = null; armed = recoiled = hadDrive = false; beatIndex = null; returnAt = brakeAt = null;
  }
  function step(dt, input = {}, controls = {}) {
    dt = clamp(dt, 0, .05); s.time += dt;
    const { audio = {}, music = {}, smooth = {}, lookahead = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const ev = audioModel.step(dt, input, { beatsPerSecond: bps, leadSeconds: .035 });
    const a = audioModel.state;
    // Unsaturated shared envelopes keep the rails breathing on loud tracks.
    const relativeBass = clamp(((audio.bassRel ?? 1) - .65) * .8);
    s.bass = follow(s.bass, clamp((audio.bassFast ?? a.bassDrive) * .72 + relativeBass * .28), dt, .045, .20);
    s.mids = follow(s.mids, clamp(audio.midFast ?? a.midDrive), dt, .055, .22);
    s.highs = follow(s.highs, clamp(audio.trebleFast ?? a.highDrive), dt, .025, .12); s.hat = a.hat;
    // Shared fast/slow envelopes retain dynamics that the normalized Forge
    // energyDrive clips away on mastered tracks. Only one energy smoother.
    const fast = clamp(audio.globalEnergyFast ?? a.energyFast);
    const slow = clamp(audio.globalEnergySlow ?? a.energySlow);
    const energy = clamp(fast * .55 + slow * .20 + clamp(music.adaptiveIntensity ?? a.energyDrive) * .25);
    s.energy = follow(s.energy, energy, dt, .18, .55);
    const pressure = clamp(((audio.bassRel ?? 1) - .85) * 2.5);
    s.pressure = follow(s.pressure, pressure, dt, .055, .18);
    const pulse = clamp(audio.kickPulse);
    const detected = pulse > .48 && previousKick <= .48 && s.time - lastKick > .20;
    const index = Number.isFinite(music.absoluteBeat) ? Math.floor(music.absoluteBeat + .035 * bps) : null;
    const gridEdge = index !== null && beatIndex !== null && index > beatIndex && index - beatIndex < 3;
    beatIndex = index; previousKick = pulse;
    // Use the analysed groove for saturated music, and real onsets without a grid.
    // Neither a bare beat clock nor a persistent drop role is sufficient for a launch.
    const kick = s.time - lastKick > .20 && (detected || ev.kick > 0 || (gridEdge && a.lowPresence > .6 && a.groove > .25))
      ? Math.max(pulse, ev.kick, gridEdge ? .78 : 0) : 0;
    const events = { kick: 0, drop: 0, hat: ev.hats };
    s.impulse *= Math.exp(-dt / 1.15); s.flash *= Math.exp(-dt / .48); s.kick *= Math.exp(-dt / .26);
    const gap = s.time - lastKick;
    const calm = Math.max(clamp(music.breakdown), clamp(music.calm) * .75);
    const missing = gap > Math.max(.85, 1.9 / bps) && (a.groove < .35 || a.lowPresence < .28 || calm > .6);
    if (missing) {
      if (breakAt === null) { breakAt = s.time; recoiled = false; returnAt = brakeAt = null; }
      s.breakAge = s.time - breakAt;
      if (s.breakAge > 1.3 && (hadDrive || s.time > 4)) armed = true;
    }
    // Horizons are window aggregates, not an exact timestamp of the next drop.
    // The existing phrase boundary narrows the release window; never claim a
    // precise future kick from a long-window maximum.
    const current = lookahead.current || {}, med = lookahead.medium || {}, long = lookahead.long || {};
    const rise = clamp(((med.maxEnergy || med.energy || 0) - (current.energy || 0) - .08) * 3.2);
    const bassReturn = clamp(((med.bass || 0) - (current.bass || 0) - .035) * 3);
    const farRise = clamp(((long.energy || 0) - (current.energy || 0) - .12) * 2);
    s.future = lookahead.ready ? clamp(Math.max(clamp(music.upcomingDrop) * 1.5,
      rise * (.5 + .5 * bassReturn), clamp(music.upcomingBuild) * .6, farRise * .45)) : 0;
    // The 20-second forecast contributes modest early charging. Only the
    // stronger near-window/section evidence can qualify a recoil.
    const phraseSeconds = Number(music.nextPhraseSeconds);
    const phraseValid = index !== null && Number.isFinite(phraseSeconds) && phraseSeconds > 0;
    const near = phraseValid ? clamp(1 - phraseSeconds / 4) : 0;
    const anticipate = clamp(controls.anticipation ?? 1, 0, 1.5);
    const tensionTarget = missing && armed ? anticipate * s.future * (.25 + .75 * near) : 0;
    s.tension = follow(s.tension, tensionTarget, dt, .6, .35);
    if (kick) {
      events.kick = kick; s.kick = kick; s.kickCount++; lastKick = s.time; hadDrive = true;
      // Hero release requires the returning strong low-end beat after a real gap.
      const lowNow = clamp(audio.bassNow ?? smooth.bass);
      const strongReturn = kick >= .6 || (detected && lowNow > .50);
      if (armed && s.breakAge > 1.3 && strongReturn && s.time - lastDrop > 6 && (a.lowPresence > .3 || s.bass > .3 || lowNow > .50)) {
        events.drop = 1; s.dropCount++; s.impulse = 1; s.flash = 1; lastDrop = s.time;
      }
      // A sampled attack can cross the detector threshold before its peak.
      // Keep a phrase armed through weak returning ticks; a later confirmed
      // low-end beat may complete it. Ordinary kicks cannot re-arm a launch.
      if (armed && returnAt === null) returnAt = s.time;
      if (!armed || events.drop) {
        breakAt = null; s.breakAge = 0; armed = false; recoiled = false; returnAt = brakeAt = null;
      }
    }
    if (armed && returnAt !== null && s.time - returnAt > 1.5) {
      breakAt = null; s.breakAge = 0; armed = false; recoiled = false; returnAt = brakeAt = null;
    }
    const response = clamp(controls.propulsion ?? 1, 0, 1.5);
    s.thrust = follow(s.thrust, s.kick, dt, .035, .12);
    let target = 1 + (energyVelocity(s.energy) + .18 * s.pressure + .08 * s.mids - 1) * response;
    const coasting = missing && (hadDrive || armed && s.future > .12);
    // Window aggregates can keep predicting a drop throughout a long break.
    // Allow a short window per forecast, then coast even if the forecast
    // stays high or successive phrase boundaries pass without a returning kick.
    const nearRelease = missing && armed && lookahead.ready && s.future > .5 && s.tension > .32
      && phraseValid && phraseSeconds < 3.2;
    if (!recoiled && s.future < .35) brakeAt = null;
    if (nearRelease && brakeAt === null) brakeAt = s.time;
    const brakeWindow = brakeAt !== null && s.time - brakeAt < 4;
    const braking = nearRelease && brakeWindow && !recoiled;
    const coastTarget = Math.min(target, Math.max(1.1, target * .78));
    if (coasting) target = braking
      ? Math.min(target, 1.1 * Math.pow(1 - s.tension, 3) - .04 * s.tension)
      : coastTarget;
    if (!recoiled && braking && s.future > .58 && s.tension > .54
      && phraseSeconds < 1.65 && s.velocity < .22 && (controls.recoil ?? 1) > 0) {
      recoiled = true; recoilAt = s.time; s.recoilCount++;
    }
    const recoilAge = s.time - recoilAt;
    const reversing = missing && recoiled && brakeWindow && recoilAge < .9;
    const holding = missing && recoiled && brakeWindow && recoilAge >= .9 && recoilAge < 1.2;
    if (reversing) target = -.16 * clamp(controls.recoil ?? 1);
    else if (holding) target = 0;
    target += (s.impulse * .65 + s.thrust * .52) * response;
    // Acceleration follows a target acceleration; speed has its own inertia.
    // A returning drop accelerates rapidly, ordinary kicks retain a smooth but perceptible thrust envelope.
    s.target = clamp(target, -.18, 3.2);
    const desired = clamp((s.target - s.velocity) / (s.impulse > .35 ? .16 : reversing ? .18 : .20), reversing ? -1.2 : -2.7, s.impulse > .35 ? 4.0 : 3.0);
    s.acceleration = follow(s.acceleration, desired, dt, .045, .075);
    s.velocity = clamp(s.velocity + s.acceleration * dt, -.18, 3.2);
    if (Math.abs(s.velocity - s.target) < .003 && Math.abs(s.acceleration) < .025) { s.velocity = s.target; s.acceleration = 0; }
    s.phase = s.impulse > .25 ? 'launch' : reversing ? 'recoil' : holding ? 'hold'
      : braking ? 'brake' : coasting ? 'coast' : 'cruise';
    return events;
  }
  return { state: s, step, reset, audioState: audioModel.state };
}
