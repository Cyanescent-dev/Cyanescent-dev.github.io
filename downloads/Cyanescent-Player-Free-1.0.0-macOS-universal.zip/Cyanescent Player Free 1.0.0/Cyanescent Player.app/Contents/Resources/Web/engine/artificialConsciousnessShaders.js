// Artificial Consciousness shaders.
//
// The Forge world is a network of ~28 000 nodes and ~58 000 connections drawn as fine luminous lines.
// topology.bin + the frame's header rebuild every node position exactly (artificialConsciousnessNetwork.js
// is the JS reference; the GLSL below is the same maths), so the preset draws its own live light along
// the video's actual wiring.
//
// Coordinate conventions: video UV "fuv" has its origin at the top-left (v down); the video texture and
// the overlay texture are both stored top row first. World space is the Forge's (y up).
//
// Passes per frame:
//   node       every node (one texel each): position, presence, entity / aligned / facing, colour
//              (acPlace + the colour part of acNodeKernel)
//   edges      instanced ribbons, one per visible connection, additively into the overlay target:
//              the geometry of acEdgeGeometry, the brightness from the music layer (waves, sparks, streams ...)
//   sprites    firing nodes and the aperture ring
//   blur       a small glow pyramid of the overlay
//   composite  the video, graded, with the overlay screened over it
export const AC_NODE_W = 256;
export const AC_NODE_H = 128;
export const AC_EDGE_W = 512;
export const AC_EDGE_H = 128;
export const AC_WAVES = 10;
export const AC_SPARKS = 16;
export const AC_ROLES = 6;
export const AC_EDGE_KINDS = 17;
export const AC_CURVE_SEGMENTS = 24;
// Kinds drawn as a single straight quad (K = mid in acEdgeGeometry); the others are curves.
export const AC_STRAIGHT_KINDS = Object.freeze([0, 1, 2, 3, 8, 9, 11, 12, 14, 15]);

const header = `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
`;

const common = `
layout(std140) uniform Frame { vec4 uF[28]; };
uniform uint uSeed;
uniform vec4 uLookC;     // signal density, connectivity, line weight, glow
uniform float uNodeCount;
const float PI = 3.14159265359;
const float TAU = 6.28318530718;
const int NODE_W = ${AC_NODE_W};
const int EDGE_W = ${AC_EDGE_W};

#define F_STAGE uF[0]
#define F_AWAKE uF[1]
#define F_TRANS uF[2]
#define F_TORUS uF[3]
#define F_DISC uF[4]
#define F_CENTRE uF[5]
#define F_AXISX uF[6]
#define F_AXISY uF[7]
#define F_AXISZ uF[8]
#define F_ATTN uF[9]
#define F_CLOCKS uF[10]
#define F_LOOK2 uF[11]
#define F_WARP uF[12]
#define F_FLOW uF[13]
#define F_APERTURE uF[14]
#define F_CAMPOS uF[21]
#define F_CAMFWD uF[22]
#define F_CAMRIGHT uF[23]
#define F_CAMUP uF[24]
#define F_STORY uF[25]
#define F_MOOD uF[26]

float sat(float x) { return clamp(x, 0.0, 1.0); }
float smoother(float x) { x = sat(x); return x * x * x * (x * (x * 6.0 - 15.0) + 10.0); }
float wrapAngle(float d) { return d - TAU * floor((d + PI) / TAU); }

uint hashU32(uint v) {
  v ^= v >> 17u; v *= 0xed5ad4bbu;
  v ^= v >> 11u; v *= 0xac4c1b51u;
  v ^= v >> 15u; v *= 0x31848babu;
  v ^= v >> 14u;
  return v;
}
uint hashCombine(uint a, uint b) { return hashU32(a ^ (b + 0x9e3779b9u + (a << 6u) + (a >> 2u))); }
float hashF(uint a) { return float(hashU32(a) & 0x00ffffffu) / 16777216.0; }
float hashF2(uint a, uint b) { return hashF(hashCombine(a, b)); }

float acLobe(float theta) {
  float sum = 0.0;
  for (int q = 0; q < 6; q++) {
    float ang = q < 4 ? uF[15][q] : uF[16][q - 4];
    float amp = q < 4 ? uF[17][q] : uF[18][q - 4];
    float wid = q < 4 ? uF[19][q] : uF[20][q - 4];
    float d = wrapAngle(theta - ang) / max(wid, 1e-3);
    sum += amp * exp(-d * d);
  }
  return sum - 0.55;
}
vec3 acToWorld(vec3 l) { return F_CENTRE.xyz + (F_AXISX.xyz * l.x + F_AXISY.xyz * l.y + F_AXISZ.xyz * l.z) * F_CENTRE.w; }
vec3 acToLocal(vec3 p) {
  vec3 d = (p - F_CENTRE.xyz) / max(F_CENTRE.w, 1e-4);
  return vec3(dot(d, F_AXISX.xyz), dot(d, F_AXISY.xyz), dot(d, F_AXISZ.xyz));
}
vec3 acFlare(vec3 l) {
  float beta = F_AXISX.w;
  if (beta <= 0.0) return l;
  vec3 al = vec3(dot(F_ATTN.xyz, F_AXISX.xyz), dot(F_ATTN.xyz, F_AXISY.xyz), dot(F_ATTN.xyz, F_AXISZ.xyz));
  float u = dot(l, al) / max(F_AXISY.w, 1.0);
  return l / max(1.0 - beta * u, 0.35);
}
vec3 acRotateAxis(vec3 v, vec3 axis, float angle) {
  float c = cos(angle), s = sin(angle);
  return v * c + cross(axis, v) * s + axis * dot(axis, v) * (1.0 - c);
}
vec2 acHexCentre(vec2 p, float size) {
  float q = (0.57735026919 * p.x - 0.33333333333 * p.y) / size;
  float r = (0.66666666667 * p.y) / size;
  float x = q, z = r, y = -x - z;
  float rx = round(x), ry = round(y), rz = round(z);
  float dx = abs(rx - x), dy = abs(ry - y), dz = abs(rz - z);
  if (dx > dy && dx > dz) rx = -ry - rz; else if (dy > dz) ry = -rx - rz; else rz = -rx - ry;
  return vec2(size * 1.73205080757 * (rx + rz * 0.5), size * 1.5 * rz);
}

struct Placed { vec3 pos; vec3 nrm; float presence; float entity; float fold; };

Placed acPeel(vec2 p0) {
  Placed o;
  o.nrm = vec3(0.0); o.fold = 0.0; o.entity = 0.0; o.presence = 1.0;
  o.pos = vec3(p0.x, 0.0, p0.y);
  float front = F_TRANS.z;
  if (front <= 0.0) return o;
  vec2 c = acHexCentre(p0, 13.0);
  float tr = length(c);
  uint hx = uint(int(floor(c.x * 8.0)));
  uint hz = uint(int(floor(c.y * 8.0)));
  float jit = hashF(hashCombine(uSeed ^ 0x5eedu, (hx * 73856093u) ^ (hz * 19349663u)));
  float u = sat((front - tr - jit * 16.0) / 36.0);
  if (u <= 0.0) return o;
  vec2 radial = tr > 1e-3 ? c / tr : vec2(1.0, 0.0);
  vec3 axis = normalize(vec3(-radial.y, 0.0, radial.x));
  float angle = u * u * (1.1 + jit * 1.6) * (jit > 0.5 ? 1.0 : -1.0);
  vec3 rel = acRotateAxis(vec3(p0.x - c.x, 0.0, p0.y - c.y), axis, angle);
  vec3 centre = vec3(c.x + radial.x * u * u * 18.0, -u * u * 75.0, c.y + radial.y * u * u * 18.0);
  o.presence = 1.0 - 0.72 * smoothstep(0.35, 1.0, u);
  o.pos = centre + rel;
  return o;
}

Placed acPlaceBloom(vec4 pl, vec4 ex) {
  Placed o;
  int structure = int(round(ex.x));
  float u = pl.z, phi = pl.w;
  float g = sat((F_TRANS.x - ex.w) / 0.35);
  float rhoT = F_TORUS.y, rT = F_TORUS.x, expand = F_TRANS.y, spin = F_LOOK2.z;
  vec3 local;
  float presence;
  if (structure == 0) {
    float rMeta = (2.3 + 0.16 * u) * rhoT * (1.0 + 0.6 * expand);
    float thetaM = uF[15].x + spin * 0.5;
    float radial = rT + rMeta * cos(phi);
    local = vec3(radial * cos(thetaM), rMeta * sin(phi), radial * sin(thetaM));
    presence = sat((g * PI * 1.02 - abs(wrapAngle(phi - PI))) / 0.25);
  } else {
    uint j = hashCombine(uSeed, uint(structure));
    float a1 = TAU * (float(structure) / 5.0 + 0.15 * hashF2(j, 0xb1u));
    float a2 = 0.35 + 0.9 * hashF2(j, 0xb2u);
    vec3 nrm = vec3(sin(a2) * cos(a1), cos(a2), sin(a2) * sin(a1));
    float radius = (rT + rhoT) * (1.3 + 0.13 * float(structure)) * (1.0 + 0.3 * expand);
    vec3 e1 = vec3(0.0, 1.0, 0.0) - nrm * nrm.y;
    e1 = length(e1) > 1e-6 ? normalize(e1) : vec3(1.0, 0.0, 0.0);
    vec3 e2 = cross(nrm, e1);
    local = (e1 * cos(phi) + e2 * sin(phi)) * radius + nrm * (u - 0.5) * 1.6;
    presence = sat((g * PI * 1.02 - abs(wrapAngle(phi))) / 0.25);
  }
  o.pos = acToWorld(acFlare(local));
  o.nrm = vec3(0.0); o.presence = presence; o.entity = 1.0; o.fold = 0.0;
  return o;
}

// acPlace. pl = (plane x, plane z, ring radius, ring angle); at = (shell, kind, region, phase); ex = (module, ring, importance, birth)
Placed acPlace(vec4 pl, vec4 at, vec4 ex) {
  float shell = at.x;
  vec2 p0 = pl.xy;
  float r = pl.z, theta = pl.w;
  if (shell < 0.5) return acPeel(p0);
  if (shell > 4.5) return acPlaceBloom(pl, ex);
  Placed o;
  float F = F_STAGE.y;
  float rhoN = r / 44.0;
  float eLocal = smoother(F_STAGE.x * 1.6 - rhoN * 0.6);
  float spin = F_LOOK2.z;
  float thetaS = theta + F * spin;
  float aperture = F_AXISZ.w;
  vec3 local;
  vec3 normalLocal = vec3(0.0, 1.0, 0.0);
  if (shell > 3.5) {
    float hole = F_TORUS.x - F_TORUS.y - F_TORUS.z;
    float target = (0.34 + 0.56 * r / 4.2) * hole;
    float radius = r + (target - r) * aperture * F;
    float twist = F * spin + aperture * F * (0.9 - 0.5 * r / 4.2) + aperture * F * TAU * F_CLOCKS.w * 0.25;
    float ang = atan(p0.y, p0.x) + twist;
    vec2 q = r > 1e-6 ? vec2(cos(ang), sin(ang)) * radius : vec2(0.0);
    float y = 9.0 * eLocal * (1.0 - F) + F * F_TORUS.y * 0.55 * aperture;
    if (r < 1e-6) y = 9.0 * smoother(F_STAGE.x * 1.6) * (1.0 - F) + F * F_TORUS.y * 0.55 * aperture;
    local = vec3(q.x, y, q.y);
  } else {
    float shellOffset = shell - 2.0;
    float rMid = 24.5;
    float L = 39.0;
    float sN = (r - rMid) / L;
    float rhoT = F_TORUS.y;
    float A = F * TAU * F_TORUS.w;
    float lenF = L + (TAU * F_TORUS.w * rhoT - L) * F;
    float lobe = acLobe(theta);
    float a = sN * A + F_WARP.y * F * F * sin(theta + F_WARP.w);
    vec2 m, nm;
    float rc = 0.0;
    if (A < 1e-3) { m = vec2(sN * lenF, 0.0); nm = vec2(0.0, 1.0); }
    else {
      rc = lenF / A;
      float sh = sin(0.5 * a);
      m = vec2(rc * sin(a), rc * 2.0 * sh * sh);
      nm = vec2(-sin(a), cos(a));
    }
    float hShell = shellOffset * (1.6 * eLocal + (F_TORUS.z - 1.6 * eLocal) * F);
    m += nm * hShell;
    if (A >= 1e-3) {
      vec2 c = vec2(0.0, rc);
      m = c + (m - c) * (1.0 + F * F * lobe);
    }
    float rMaj = rMid + (F_TORUS.x * (1.0 + F * F_WARP.z * cos(2.0 * theta + F_WARP.w) + F * 0.18 * lobe) - rMid) * F;
    float rhoXZ = rMaj + m.x;
    float dome = 9.0 * (1.0 - rhoN * rhoN) * (1.0 - rhoN * rhoN) * eLocal * (1.0 - F);
    float ripple = 0.5 * sin(rhoN * 9.0 - TAU * F_CLOCKS.z * 2.0) * eLocal * (1.0 - F) * F_STAGE.z;
    float y = -rhoT * F + m.y + dome + ripple + F * F_WARP.x * sin(2.0 * theta + F_WARP.w * 1.7);
    local = vec3(rhoXZ * cos(thetaS), y, rhoXZ * sin(thetaS));
    vec2 polar = vec2(r * cos(theta), r * sin(theta));
    local.x += (p0.x - polar.x) * (1.0 - F);
    local.z += (p0.y - polar.y) * (1.0 - F);
    local *= 1.0 + F_TRANS.y * (shell < 1.5 ? 0.12 : (shell < 2.5 ? 0.5 : 1.9));
    float aS = (A < 1e-3) ? 0.0 : a;
    normalLocal = vec3(sin(aS) * cos(thetaS), -cos(aS), sin(aS) * sin(thetaS));
  }
  o.pos = acToWorld(acFlare(local));
  o.nrm = F_AXISX.xyz * normalLocal.x + F_AXISY.xyz * normalLocal.y + F_AXISZ.xyz * normalLocal.z;
  o.presence = shell > 3.5 ? (r < 1e-6 ? 1.0 - 0.85 * aperture : 1.0 - 0.7 * aperture) : 1.0;
  o.entity = sat(max(eLocal, F) * 50.0);
  o.fold = shell > 3.5 ? 0.0 : F;
  return o;
}

vec3 acCycle4(float t, vec3 a, vec3 b, vec3 c, vec3 d) {
  float x = (t - floor(t)) * 4.0;
  float f = x - floor(x);
  f = f * f * (3.0 - 2.0 * f);
  int i = int(floor(x));
  if (i == 0) return mix(a, b, f);
  if (i == 1) return mix(b, c, f);
  if (i == 2) return mix(c, d, f);
  return mix(d, a, f);
}
vec3 acMachineColour(float shell) {
  if (shell < -0.5) return vec3(0.15, 0.30, 0.70);
  if (shell < 0.5) return vec3(0.19, 0.38, 0.80);
  if (shell > 4.5) return vec3(0.50, 0.78, 1.00);
  if (shell > 3.5) return vec3(0.40, 0.78, 1.00);
  return vec3(0.24, 0.58, 1.00);
}
vec3 acAwakeColour(float shell, float t) {
  const vec3 gold = vec3(1.00, 0.76, 0.44);
  const vec3 rose = vec3(1.00, 0.40, 0.58);
  const vec3 violet = vec3(0.60, 0.42, 1.00);
  const vec3 pale = vec3(1.00, 0.90, 0.74);
  if (shell > 4.5) return acCycle4(t, gold, rose, violet, vec3(0.35, 0.80, 1.0));
  if (shell > 3.5) return pale;
  if (shell < 1.5) return mix(gold, pale, 0.25);
  if (shell < 2.5) return rose;
  return violet;
}
float acKindIntensity(float kind) {
  int k = int(kind + 0.5);
  if (k == 1) return 1.7;
  if (k == 2) return 2.6;
  if (k == 3) return 2.2;
  if (k == 4) return 1.5;
  if (k == 5) return 0.55;
  if (k == 6) return 1.05;
  return 1.0;
}

// Static attributes per node (three RGBA32F images) and the per-frame node state (three RGBA32F targets).
ivec2 nodeTexel(int id) { return ivec2(id % NODE_W, id / NODE_W); }
ivec2 edgeTexel(int id) { return ivec2(id % EDGE_W, id / EDGE_W); }
`;

// ------------------------------------------------------------------ node pass

export const acNodeSource = `${header}
in vec2 vUv;
layout(location = 0) out vec4 oPos;      // xyz world, w presence
layout(location = 1) out vec4 oState;    // entity, aligned (behind the awakening front), facing, network distance
layout(location = 2) out vec4 oColour;   // rgb colour (cold machine -> spectral -> awake), w intensity
uniform sampler2D uNodeA;
uniform sampler2D uNodeB;
uniform sampler2D uNodeC;
${common}
void main() {
  ivec2 px = ivec2(gl_FragCoord.xy);
  int id = px.y * NODE_W + px.x;
  if (float(id) >= uNodeCount) { oPos = vec4(0.0); oState = vec4(0.0); oColour = vec4(0.0); return; }
  vec4 pl = texelFetch(uNodeA, px, 0);
  vec4 at = texelFetch(uNodeB, px, 0);
  vec4 ex = texelFetch(uNodeC, px, 0);
  Placed placed = acPlace(pl, at, ex);
  float shell = at.x, kind = at.y, phase = at.w, r = pl.z;
  float coh = F_STAGE.z;
  float dNet = shell > 4.5 ? 0.0 : r;
  float frontR = F_FLOW.z, frontW = F_FLOW.y;
  float aligned = F_AWAKE.y > 0.0 ? smoothstep(-frontW, frontW, frontR - dNet) : 0.0;

  float waveQ = dNet / 16.0 - F_CLOCKS.z * 4.0;
  float wave = pow(0.5 + 0.5 * cos(TAU * waveQ), 10.0);
  vec3 col = acMachineColour(shell);
  float entityish = placed.entity;
  float spectralT = F_LOOK2.x + 0.13 * at.z + 0.06 * wave + 0.07 * (shell - 2.0) + 0.35;
  vec3 spectral = acCycle4(spectralT, vec3(0.25, 0.80, 1.00), vec3(0.28, 0.42, 1.00), vec3(0.62, 0.36, 1.00), vec3(0.35, 0.55, 1.00));
  col = mix(col, spectral, smoothstep(0.35, 0.85, coh) * (entityish > 0.5 ? 0.75 : 0.2));
  float colourLocal = aligned * F_AWAKE.w;
  vec3 awakeCol = acAwakeColour(shell, F_LOOK2.x + phase * 0.5 + 0.1 * F_CLOCKS.w);
  col = mix(col, awakeCol, colourLocal * (entityish > 0.5 ? 1.0 : 0.12));
  if (shell > 4.5) col = mix(col, awakeCol, 0.85);

  float intensity = acKindIntensity(kind);
  if (shell > 0.5 && shell < 3.5) {
    float rhoN = r / 44.0;
    float eLocal = smoother(F_STAGE.x * 1.6 - rhoN * 0.6);
    intensity *= mix(0.3, 1.0, smoother(max(eLocal, F_STAGE.y) * 1.5)) * mix(1.0, 0.62, F_STAGE.y);
  }
  if (shell > 3.5 && shell < 4.5) intensity *= mix(0.45, 1.0, max(coh, F_AXISZ.w));
  if (shell < -0.5) {
    intensity *= 1.0 - smoothstep(165.0, 228.0, r);
    intensity *= 1.0 - 0.55 * F_TRANS.y;
  }
  if (shell < 0.5 && shell > -0.5) intensity *= 1.0 - 0.4 * F_STAGE.y;
  if (shell > 2.5 && shell < 3.5) intensity *= 1.0 - 0.7 * sat(F_TRANS.y);

  vec3 toCam = normalize(F_CAMPOS.xyz - placed.pos);
  float facing = 1.0;
  if (placed.fold > 0.0) {
    float d = dot(placed.nrm, toCam);
    facing = mix(1.0, 0.25 + 0.75 * smoothstep(-0.3, 0.35, d), placed.fold);
  }
  oPos = vec4(placed.pos, placed.presence);
  oState = vec4(placed.entity, aligned, facing, dNet);
  oColour = vec4(col, intensity);
}
`;

// ------------------------------------------------------------------ edge ribbons

const edgeCommon = `
uniform sampler2D uNodeA;
uniform sampler2D uNodeB;
uniform sampler2D uNodeC;
uniform sampler2D uPos;
uniform sampler2D uState;
uniform sampler2D uColour;
uniform sampler2D uEdges;
uniform sampler2D uList;
uniform vec2 uView;        // overlay target size in pixels
uniform float uPx;         // overlay pixels per 1440p video pixel
uniform int uSegments;     // curve segments (curved class); 1 for the straight class
uniform int uCurved;
uniform float uDebug;
uniform float uGlow;       // extra ribbon softness from the music (0..1)
const float EDGE_WIDTH[17] = float[17](0.050, 0.045, 0.035, 0.035, 0.050, 0.070, 0.085, 0.100, 0.040, 0.035, 0.075, 0.030, 0.080, 0.085, 0.070, 0.060, 0.060);
const float EDGE_INTENSITY[17] = float[17](0.90, 0.70, 0.55, 0.35, 0.80, 1.00, 1.20, 1.50, 0.55, 0.45, 0.90, 0.50, 1.30, 1.30, 1.40, 1.40, 0.90);
`;

export const acEdgeVertexSource = `${header}
${common}
${edgeCommon}
flat out vec4 fPlane;       // plane x z of node a, node b
flat out vec4 fAttr;        // theta a, theta b, shell a, shell b
flat out vec4 fModule;      // module a, module b, kind, growth
flat out vec4 fTintA;       // colour a, intensity a
flat out vec4 fTintB;
flat out vec4 fMisc;        // visibility, intensity scale, widthPx, length (px)
flat out vec4 fMisc2;       // entity a, entity b, aligned a, aligned b
flat out uint fHash;
flat out vec2 fRegionR;     // ring radius a, b
out vec2 vAcross;           // signed pixel offset across the ribbon, t along the edge
out float vT;
out float vAlong;           // pixels from the start (negative before it)
out float vSigma;

struct Geom { vec3 A, K, B; float vis, growth, intensity, width; int kind; uint eh; };

Geom acEdgeGeometry(int e, vec4 ed, vec4 sa, vec4 sb, vec4 ea, vec4 eb, vec4 attrA) {
  Geom g;
  uint flags = uint(ed.z + 0.5);
  g.kind = int(flags & 255u);
  float rank = ed.w;
  g.width = EDGE_WIDTH[g.kind];
  g.intensity = EDGE_INTENSITY[g.kind];
  g.A = sa.xyz; g.B = sb.xyz;
  float vis = min(sa.w, sb.w);
  float growth = 1.0;
  float coh = F_STAGE.z, F = F_STAGE.y, tau = F_TRANS.x;
  g.eh = hashCombine(uSeed ^ 0xed9eu, uint(e));
  if ((flags & 65536u) != 0u) vis *= sat((uLookC.y - hashF(g.eh)) / 0.04);
  int k = g.kind;
  if (k == 6 || k == 7 || k == 5) growth = sat((coh - rank) / 0.12);
  else if (k == 11) vis *= 1.0 - smoothstep(0.55, 0.92, F);
  else if (k == 13) growth = sat((tau - rank) / 0.25);
  else if (k == 16) growth = sat((coh - rank) / 0.15);
  float awakeColour = F_AWAKE.w, aperture = F_AXISZ.w;
  if (k == 0 || k == 1 || k == 2 || k == 3) g.intensity *= mix(1.0, 0.5, F) * (1.0 - 0.3 * awakeColour);
  else if (k == 5 || k == 6) g.intensity *= mix(1.0, 1.5, F);
  if (k == 15 && F > 0.0) g.intensity *= mix(1.0, mix(0.35, 1.0, aperture), F);
  if (k == 4 || k == 3) {
    g.intensity *= mix(0.45, 1.0, smoothstep(0.1, 0.6, coh));
    if (attrA.x < -0.5) g.intensity *= 0.55;
  }
  vec3 mid = 0.5 * (g.A + g.B);
  float len = distance(g.A, g.B);
  vec3 outward = mid - F_CENTRE.xyz;
  outward = length(outward) > 1e-4 ? normalize(outward) : vec3(0.0, 1.0, 0.0);
  float arcLift = F_DISC.w;
  vec3 lm = acToLocal(mid);
  vec2 ringDir = length(lm.xz) > 1e-4 ? normalize(lm.xz) : vec2(1.0, 0.0);
  vec3 tubeOut = lm - vec3(ringDir.x * F_TORUS.x, 0.0, ringDir.y * F_TORUS.x);
  tubeOut = length(tubeOut) > 1e-4 ? normalize(tubeOut) : vec3(0.0, 1.0, 0.0);
  vec3 tubeOutWorld = F_AXISX.xyz * tubeOut.x + F_AXISY.xyz * tubeOut.y + F_AXISZ.xyz * tubeOut.z;
  bool entityEdge = ea.x > 0.5 && eb.x > 0.5 && attrA.x < 3.5;
  vec3 foldBow = entityEdge ? tubeOutWorld : outward;
  vec3 K = mid;
  if (k == 4 || k == 5) {
    K += vec3(0.0, 1.0, 0.0) * len * 0.08 * arcLift * (1.0 - F) + foldBow * len * 0.32 * F;
  } else if (k == 6 || k == 7 || k == 10) {
    float lift = k == 10 ? 0.5 : 1.0;
    K += vec3(0.0, 1.0, 0.0) * len * (0.06 + 0.3 * arcLift) * lift * (1.0 - F) + foldBow * len * 0.6 * F;
  } else if (k == 13) {
    K = mid + outward * (len * 0.4 + 8.0 * F_CENTRE.w) * (0.6 + 0.4 * growth);
  } else if (k == 16) {
    K = mid + foldBow * len * 0.45;
    float conv = smoother((F_STAGE.w - (0.17 + 0.2 * hashF(g.eh ^ 0x0c0du))) / 0.3);
    if (conv > 0.0) {
      vec3 la = acToLocal(g.A);
      float phi = atan(la.z, la.x) + 0.7 + 0.3 * (hashF(g.eh ^ 0x4a11u) - 0.5);
      vec3 rim = F_APERTURE.xyz + (F_AXISX.xyz * cos(phi) + F_AXISZ.xyz * sin(phi)) * F_APERTURE.w;
      vec3 kc = rim - F_AXISY.xyz * (0.55 * distance(g.A, rim));
      g.B = mix(g.B, rim, conv);
      K = mix(K, kc, conv);
      growth = max(growth, conv);
    }
    g.intensity *= 0.12 + 2.3 * conv;
  }
  g.K = K; g.vis = vis; g.growth = growth;
  return g;
}

vec3 bez(vec3 a, vec3 k, vec3 b, float t) { float u = 1.0 - t; return a * (u * u) + k * (2.0 * u * t) + b * (t * t); }
vec3 bezD(vec3 a, vec3 k, vec3 b, float t) { return 2.0 * (1.0 - t) * (k - a) + 2.0 * t * (b - k); }
// pixel position in the overlay target (origin top-left) and view depth
vec3 projectPx(vec3 p) {
  vec3 c = p - F_CAMPOS.xyz;
  float z = dot(c, F_CAMFWD.xyz);
  float zs = max(z, 1e-4);
  vec2 ndc = vec2(dot(c, F_CAMRIGHT.xyz) / (zs * F_CAMFWD.w * F_CAMPOS.w), dot(c, F_CAMUP.xyz) / (zs * F_CAMPOS.w));
  return vec3((ndc.x + 1.0) * 0.5 * uView.x, (1.0 - ndc.y) * 0.5 * uView.y, z);
}

void main() {
  int inst = gl_InstanceID;
  int e = int(texelFetch(uList, edgeTexel(inst), 0).r + 0.5);
  vec4 ed = texelFetch(uEdges, edgeTexel(e), 0);
  int ia = int(ed.x + 0.5), ib = int(ed.y + 0.5);
  ivec2 ta = nodeTexel(ia), tb = nodeTexel(ib);
  vec4 sa = texelFetch(uPos, ta, 0), sb = texelFetch(uPos, tb, 0);
  vec4 ea = texelFetch(uState, ta, 0), eb = texelFetch(uState, tb, 0);
  vec4 attrA = texelFetch(uNodeB, ta, 0), attrB = texelFetch(uNodeB, tb, 0);
  Geom g = acEdgeGeometry(e, ed, sa, sb, ea, eb, attrA);
  gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
  if (g.vis < 1e-3 || g.growth <= 0.0) return;
  float nearZ = 0.05;
  vec3 pA = projectPx(g.A), pK = projectPx(g.K), pB = projectPx(g.B);
  if (min(pA.z, min(pK.z, pB.z)) < nearZ) return;
  vec2 lo = min(min(pA.xy, pK.xy), pB.xy), hi = max(max(pA.xy, pK.xy), pB.xy);
  if (hi.x < -20.0 || hi.y < -20.0 || lo.x > uView.x + 20.0 || lo.y > uView.y + 20.0) return;
  float lenPx = distance(pA.xy, pK.xy) + distance(pK.xy, pB.xy);
  float depth = max(0.5 * (pA.z + pB.z), nearZ);
  float lensW = uView.y / (2.0 * F_CAMPOS.w);                 // overlay pixels per world unit at unit depth
  float widthPx = g.width * uLookC.z * lensW / depth;
  float sigma = max(max(widthPx / 2.355, 0.55 * uPx), 0.42 * uPx) * (1.0 + 0.9 * uGlow);
  float half_ = 3.0 * sigma + 1.0;

  float t; float along; float side;
  vec2 pos2;
  if (uCurved == 0) {
    int v = gl_VertexID;
    side = (v & 1) == 0 ? -1.0 : 1.0;
    bool endV = v >= 2;
    t = endV ? g.growth : 0.0;
    vec3 P0 = g.A, P1 = bez(g.A, g.K, g.B, g.growth);
    vec2 s0 = pA.xy, s1 = projectPx(P1).xy;
    float L = max(distance(s0, s1), 1e-3);
    vec2 dir = (s1 - s0) / L;
    vec2 nrm = vec2(-dir.y, dir.x);
    along = endV ? L + half_ : -half_;
    pos2 = s0 + dir * along + nrm * side * half_;
    lenPx = L;
  } else {
    int v = gl_VertexID;
    int seg = v / 2;
    side = (v & 1) == 0 ? -1.0 : 1.0;
    float u = float(seg) / float(uSegments);
    t = g.growth * u;
    vec3 P = bez(g.A, g.K, g.B, t);
    vec3 D = bezD(g.A, g.K, g.B, t);
    vec3 sP = projectPx(P);
    vec3 sQ = projectPx(P + D * 0.002);
    vec2 dir = sQ.xy - sP.xy;
    dir = length(dir) > 1e-6 ? normalize(dir) : vec2(1.0, 0.0);
    vec2 nrm = vec2(-dir.y, dir.x);
    pos2 = sP.xy + nrm * side * half_;
    along = u * lenPx;
    if (sP.z < nearZ) { pos2 = vec2(-9999.0); }
  }
  gl_Position = vec4(pos2.x / uView.x * 2.0 - 1.0, pos2.y / uView.y * 2.0 - 1.0, 0.0, 1.0);

  vAcross = vec2(side * half_, 0.0);
  vT = t;
  vAlong = along;
  vSigma = sigma;
  fPlane = vec4(texelFetch(uNodeA, ta, 0).xy, texelFetch(uNodeA, tb, 0).xy);
  vec4 plA = texelFetch(uNodeA, ta, 0), plB = texelFetch(uNodeA, tb, 0);
  vec4 exA = texelFetch(uNodeC, ta, 0), exB = texelFetch(uNodeC, tb, 0);
  fAttr = vec4(plA.w, plB.w, attrA.x, attrB.x);
  fModule = vec4(exA.x, exB.x, float(g.kind), g.growth);
  fRegionR = vec2(plA.z, plB.z);
  vec4 cA = texelFetch(uColour, ta, 0), cB = texelFetch(uColour, tb, 0);
  fTintA = vec4(cA.rgb, cA.w * ea.z);
  fTintB = vec4(cB.rgb, cB.w * eb.z);
  fMisc = vec4(g.vis, g.intensity, widthPx, lenPx);
  fMisc2 = vec4(ea.x, eb.x, ea.y, eb.y);
  fHash = g.eh;
}
`;

const kindWeightTable = `
uniform float uKindW[${AC_ROLES * AC_EDGE_KINDS}];
float kindW(int role, int kind) { return uKindW[role * ${AC_EDGE_KINDS} + kind]; }
`;

export const acEdgeFragmentSource = `${header}
${common}
${kindWeightTable}
in vec2 vAcross;
in float vT;
in float vAlong;
in float vSigma;
flat in vec4 fPlane;
flat in vec4 fAttr;
flat in vec4 fModule;
flat in vec4 fTintA;
flat in vec4 fTintB;
flat in vec4 fMisc;
flat in vec4 fMisc2;
flat in uint fHash;
flat in vec2 fRegionR;
uniform float uDebug;
uniform float uPx;
uniform vec4 uWaveA[${AC_WAVES}];   // centre x, centre z, front radius, width (world units)
uniform vec4 uWaveB[${AC_WAVES}];   // amplitude, tail (in widths), direction (+1 out, -1 in), role
uniform vec4 uWaveC[${AC_WAVES}];   // colour rgb, unused
uniform vec4 uSpark[${AC_SPARKS}];  // plane x, plane z, ripple radius, amplitude
uniform vec4 uMA;                   // bass, mids, highs, energy (drives 0..1)
uniform vec4 uMB;                   // strobe, held-breath dim, drop flash, build
uniform vec4 uMC;                   // beat (continuous), beat phase, stream head (0..1), stream gain
uniform vec4 uMD;                   // machine, organic, loop gain, unused
uniform vec4 uSpec[4];              // spectrum, 16 bands low -> high
out vec4 outColor;

float comet(float x, float tl) {    // x: signed distance behind the head (>= 0 is the tail)
  return x >= 0.0 ? exp(-x / tl) : exp(-x * x * 9.0);
}
// phase-wrapped comet along an edge: head at fraction h (0..1), tail behind it
float cometWrap(float t, float h, float k) {
  float x = fract(h - t);
  return exp(-x * k) * (1.0 - smoothstep(0.86, 1.0, x));
}
int specIndex(float r) {
  float x = clamp(log(max(r, 5.0) / 5.0) / log(46.0), 0.0, 0.999);
  return int(x * 16.0);
}
vec3 normTint(vec3 c) { return c / max(max(c.r, max(c.g, c.b)), 1e-3); }

void main() {
  float t = vT;
  int kind = int(fModule.z + 0.5);
  float shA = fAttr.z, shB = fAttr.w;
  bool bloom = shA > 4.5;
  // position in the plane of the point on the edge
  vec2 p = mix(fPlane.xy, fPlane.zw, t);
  float r = mix(fRegionR.x, fRegionR.y, t);
  float th = fAttr.x + wrapAngle(fAttr.y - fAttr.x) * t;
  float structure = fModule.x;
  float dNet = bloom ? 36.0 + 26.0 * abs(wrapAngle(th - (structure < 0.5 ? PI : 0.0))) : length(p);
  vec3 tint = mix(fTintA.rgb, fTintB.rgb, t);
  float tintI = mix(fTintA.w, fTintB.w, t);
  vec3 base = normTint(tint);
  float aligned = mix(fMisc2.z, fMisc2.w, t);
  float entity = mix(fMisc2.x, fMisc2.y, t);
  float vis = fMisc.x;
  float L = 0.0;
  vec3 colAcc = vec3(0.0);
  uint h1 = fHash;

  if (uDebug > 0.5) {
    // alignment view: every connection, flat colour by kind
    float k = float(kind) / 16.0;
    vec3 c = 0.5 + 0.5 * cos(TAU * (k + vec3(0.0, 0.33, 0.67)));
    L = 0.55; colAcc = c;
  } else {
    // ---- waves: fronts travelling through the network's wiring (plane distance) ----
    for (int w = 0; w < ${AC_WAVES}; w++) {
      vec4 A = uWaveA[w];
      vec4 B = uWaveB[w];
      if (B.x <= 0.001) continue;
      float d = bloom ? dNet : length(p - A.xy);
      float x = B.z * (A.z - d) / A.w;
      float prof = x >= 0.0 ? exp(-x / max(B.y, 0.05)) : exp(-x * x * 7.0);
      float kw = kindW(int(B.w + 0.5), kind);
      float lw = B.x * prof * kw;
      L += lw;
      colAcc += lw * mix(base, uWaveC[w].rgb, 0.55);
    }
    // ---- sparks: local ripples around firing nodes ----
    for (int s = 0; s < ${AC_SPARKS}; s++) {
      vec4 S = uSpark[s];
      if (S.w <= 0.001) continue;
      float d = length(p - S.xy);
      float x = (S.z - d) / 1.6;
      float prof = x >= 0.0 ? exp(-x / 1.3) : exp(-x * x * 7.0);
      float lw = S.w * prof * kindW(2, kind);
      L += lw;
      colAcc += lw * mix(base, vec3(1.0), 0.6);
    }
    // ---- bass: the long-range links and radial buses breathe and carry slow bolts ----
    if (kind == 6 || kind == 7 || kind == 5 || kind == 10 || kind == 4) {
      float kw = kind == 4 ? 0.35 : 1.0;
      float dash = pow(0.5 + 0.5 * cos(TAU * (t * 2.0 - uMC.x * 0.5 + hashF(h1 ^ 0x77u))), 5.0);
      float b = uMA.x * kw * (0.18 + 0.82 * dash);
      L += b; colAcc += b * mix(base, vec3(1.0), 0.25);
    }
    // ---- mids: module hubs and their wiring swell in patches ----
    if (kind == 3 || kind == 4 || kind == 0) {
      float mph = hashF2(uSeed ^ 0x3d0du, uint(structure)) ;
      float pat = pow(0.5 + 0.5 * cos(TAU * (uMC.x * 0.25 + mph)), 3.0);
      float kw = kind == 3 ? 1.0 : kind == 4 ? 0.8 : 0.35;
      float m = uMA.y * kw * (0.12 + 0.88 * pat);
      L += m; colAcc += m * base;
    }
    // ---- perception chords: streams that arrive at the aperture on the beat ----
    if (kind == 16) {
      float head = fract(uMC.z + 0.10 * hashF(h1 ^ 0x51u));
      float pk = cometWrap(t, head, 7.0);
      float g = uMC.w * (0.25 + 0.75 * aligned);
      L += g * pk * 1.15; colAcc += g * pk * 1.15 * mix(base, vec3(1.0), 0.3);
    }
    // ---- grown loops: packets circulate round the meta ring and the armillary loops ----
    if (kind == 12 || kind == 14 || kind == 13) {
      float ph = th / TAU + (kind == 13 ? t : 0.0);
      float dir = hashF(h1 ^ 0x9u) < 0.5 ? 1.0 : -1.0;
      float pk = pow(0.5 + 0.5 * cos(TAU * (ph * 3.0 - dir * uMC.x * 0.5 + structure * 0.37)), 8.0);
      float g = uMD.z * (0.1 + 0.9 * pk);
      L += g; colAcc += g * mix(base, vec3(1.0), 0.3);
    }
    // ---- the network hears: ring radius <-> frequency (bass at the heart, treble at the rim) ----
    if (kind == 0 || kind == 1 || kind == 8 || kind == 9) {
      int si = specIndex(r);
      float sv = uSpec[si >> 2][si & 3];
      float e = sv * sv * (0.25 + 0.75 * sv);
      float hear = 0.55 * e * uMA.w * (0.35 + 0.65 * (1.0 - entity * 0.5));
      L += hear; colAcc += hear * base;
    }
    // ---- build: the whole network ticks on a shared phase ----
    L += uMB.x * kindW(5, kind) * (0.3 + 0.7 * entity);
    colAcc += uMB.x * kindW(5, kind) * (0.3 + 0.7 * entity) * base;
  }
  // global attenuations: the Forge's own, the held breath, the substrate's far fade
  float fade = 1.0 - smoothstep(165.0, 228.0, dNet) * step(shA, -0.5);
  float scale = fMisc.y * 0.65 + 0.35;
  float gain = 2.4 * vis * fade * (1.0 - 0.85 * uMB.y) * scale * (0.5 + 0.5 * mix(1.0, tintI, 0.5));
  L *= gain; colAcc *= gain;
  // across / along profile
  float a = vAcross.x;
  float sg = vSigma;
  float across = exp(-0.5 * a * a / (sg * sg));
  float len = fMisc.w;
  float over = max(max(-vAlong, vAlong - len), 0.0);
  float cap = exp(-0.5 * over * over / (sg * sg));
  vec3 col = L > 1e-4 ? colAcc / L : base;
  outColor = vec4(col * L * across * cap, 1.0);
}
`;

// ------------------------------------------------------------------ pyramid + composite

export const acDownsampleSource = `${header}
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uSrc;
void main() {
  vec2 cell = 1.0 / vec2(textureSize(uSrc, 0));
  vec3 s = vec3(0.0);
  for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) s += texture(uSrc, vUv + (vec2(float(i), float(j)) - 1.5) * cell).rgb;
  outColor = vec4(s / 16.0, 1.0);
}
`;

export const acBlurSource = `${header}
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uSrc;
uniform vec2 uDir;     // texel step
void main() {
  vec3 s = texture(uSrc, vUv).rgb * 0.2270270270;
  s += (texture(uSrc, vUv + uDir * 1.3846153846).rgb + texture(uSrc, vUv - uDir * 1.3846153846).rgb) * 0.3162162162;
  s += (texture(uSrc, vUv + uDir * 3.2307692308).rgb + texture(uSrc, vUv - uDir * 3.2307692308).rgb) * 0.0702702703;
  outColor = vec4(s, 1.0);
}
`;

export const acCompositeSource = `${header}
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uVideo;
uniform sampler2D uOverlay;
uniform sampler2D uGlow;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform vec4 uGrade;      // exposure, saturation, contrast, dim
uniform vec4 uOverlayGain; // overlay gain, glow gain, fade, unused
const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);
vec3 grade(vec3 c) {
  c *= uGrade.x;
  float l = dot(c, LUMA);
  c = mix(vec3(l), c, uGrade.y);
  vec3 s = clamp(c, 0.0, 1.0);
  c = mix(c, s * s * (3.0 - 2.0 * s), clamp((uGrade.z - 1.0) * 2.0, -0.4, 0.35));
  return max(c, 0.0) * (1.0 - uGrade.w);
}
void main() {
  vec2 uv = vUv;
  if (uCanvasAspect > uVideoAspect) uv.x = (uv.x - 0.5) * uCanvasAspect / uVideoAspect + 0.5;
  else uv.y = (uv.y - 0.5) * uVideoAspect / uCanvasAspect + 0.5;
  if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) { outColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
  vec2 fuv = vec2(uv.x, 1.0 - uv.y);
  vec3 video = grade(texture(uVideo, fuv).rgb);
  vec3 ov = texture(uOverlay, fuv).rgb * uOverlayGain.x + texture(uGlow, fuv).rgb * uOverlayGain.y;
  float om = max(max(ov.r, ov.g), ov.b) * uOverlayGain.z;
  ov = om > 1e-5 ? ov * uOverlayGain.z * ((1.0 - exp(-om)) / om) : vec3(0.0);   // hue-preserving soft clip: coloured light stays coloured
  vec3 c = 1.0 - (1.0 - clamp(video, 0.0, 1.0)) * (1.0 - ov);
  outColor = vec4(c, 1.0);
}
`;

// ------------------------------------------------------------------ the aperture (the hero)
// The opening the perception chords converge on: a ring of light round its rim that a bright comet circles once
// a bar, a halo that swells on every arrival, and a beam along the entity's axis that blooms on drops.
export const AC_APERTURE_RING_SEGMENTS = 96;

export const acApertureVertexSource = `${header}
${common}
uniform vec2 uView;
uniform float uPx;
uniform int uMode;      // 0 ring, 1 halo, 2 beam
uniform vec4 uMB;
uniform vec4 uMC;
uniform vec4 uMD;
uniform vec4 uMA;
flat out vec4 fInfo;    // strength, sigma, length px, mode
out vec2 vLocal;        // across / along in pixels
out float vPhase;
vec3 projectPx(vec3 p) {
  vec3 c = p - F_CAMPOS.xyz;
  float z = dot(c, F_CAMFWD.xyz);
  float zs = max(z, 1e-4);
  vec2 ndc = vec2(dot(c, F_CAMRIGHT.xyz) / (zs * F_CAMFWD.w * F_CAMPOS.w), dot(c, F_CAMUP.xyz) / (zs * F_CAMPOS.w));
  return vec3((ndc.x + 1.0) * 0.5 * uView.x, (1.0 - ndc.y) * 0.5 * uView.y, z);
}
void main() {
  float open = F_AXISZ.w;
  gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
  if (open < 0.03) return;
  vec3 C = F_APERTURE.xyz;
  float rim = F_APERTURE.w;
  vec3 pc = projectPx(C);
  if (pc.z < 0.5) return;
  float lensW = uView.y / (2.0 * F_CAMPOS.w);
  float rimPx = rim * lensW / pc.z;
  float impact = uMD.w, drop = uMB.z;
  vec2 pos2;
  float strength, sigma, lenPx = 0.0;
  if (uMode == 0) {
    int seg = gl_VertexID / 2;
    float side = (gl_VertexID & 1) == 0 ? -1.0 : 1.0;
    float phi = TAU * float(seg) / ${AC_APERTURE_RING_SEGMENTS}.0;
    vec3 P = C + (F_AXISX.xyz * cos(phi) + F_AXISZ.xyz * sin(phi)) * rim;
    vec3 Q = C + (F_AXISX.xyz * cos(phi + 0.02) + F_AXISZ.xyz * sin(phi + 0.02)) * rim;
    vec3 sP = projectPx(P), sQ = projectPx(Q);
    vec2 dir = normalize(sQ.xy - sP.xy + 1e-6);
    sigma = (1.3 + 2.4 * impact + 2.0 * drop) * uPx * 1.4;
    pos2 = sP.xy + vec2(-dir.y, dir.x) * side * (3.0 * sigma + 1.0);
    vLocal = vec2(side * (3.0 * sigma + 1.0), 0.0);
    vPhase = phi / TAU;
    strength = open * (0.25 + 1.6 * impact + 1.2 * drop + 0.5 * uMC.w + 0.3 * uMA.w);
  } else {
    // a quad: halo = square round the centre, beam = strip along the projected axis
    int v = gl_VertexID;
    vec2 q = vec2((v & 1) == 0 ? -1.0 : 1.0, v >= 2 ? 1.0 : -1.0);
    if (uMode == 1) {
      float radius = rimPx * (1.5 + 1.2 * impact + 1.5 * drop);
      pos2 = pc.xy + q * radius * 2.2;
      vLocal = q * 2.2;
      sigma = radius;
      strength = open * (0.12 + 0.32 * impact + 0.4 * drop + 0.1 * uMC.w);
    } else {
      vec3 tip = projectPx(C + F_AXISY.xyz * rim * 3.0);
      vec2 axis = tip.xy - pc.xy;
      float lp = length(axis);
      vec2 dir = lp > 1e-3 ? axis / lp : vec2(0.0, -1.0);
      lenPx = max(lp, rimPx * 3.0);
      float widthPx = rimPx * (0.35 + 0.5 * drop);
      vec2 nrm = vec2(-dir.y, dir.x);
      float along = (q.y * 0.5 + 0.5) * lenPx;
      pos2 = pc.xy + dir * along + nrm * q.x * widthPx * 3.0;
      vLocal = vec2(q.x * 3.0, q.y * 0.5 + 0.5);
      sigma = widthPx;
      strength = open * (0.1 * uMC.w + 0.7 * impact + 1.1 * drop);
    }
  }
  fInfo = vec4(strength, sigma, lenPx, float(uMode));
  gl_Position = vec4(pos2.x / uView.x * 2.0 - 1.0, pos2.y / uView.y * 2.0 - 1.0, 0.0, 1.0);
}
`;

export const acApertureFragmentSource = `${header}
${common}
flat in vec4 fInfo;
in vec2 vLocal;
in float vPhase;
uniform vec4 uMC;
uniform vec4 uMB;
out vec4 outColor;
void main() {
  int mode = int(fInfo.w + 0.5);
  float strength = fInfo.x;
  vec3 warm = mix(vec3(1.0, 0.82, 0.55), vec3(1.0), 0.5);
  vec3 cold = vec3(0.7, 0.92, 1.0);
  vec3 col = mix(cold, warm, F_AWAKE.w);
  float L;
  if (mode == 0) {
    float a = vLocal.x / fInfo.y;
    float comet = exp(-fract(vPhase * 1.0 - uMC.x * 0.25) * 5.0);
    float sparkle = 0.55 + 0.45 * pow(0.5 + 0.5 * sin(TAU * (vPhase * 12.0 + uMC.x * 0.5)), 2.0);
    L = strength * exp(-0.5 * a * a) * (0.35 + 1.1 * comet) * sparkle;
  } else if (mode == 1) {
    float d = length(vLocal) / 2.2;
    L = strength * exp(-d * d * 3.0) * 0.8;
  } else {
    float across = exp(-0.5 * vLocal.x * vLocal.x);
    float along = pow(1.0 - vLocal.y, 1.6) * smoothstep(0.0, 0.04, vLocal.y);
    L = strength * across * along;
  }
  outColor = vec4(col * L, 1.0);
}
`;
