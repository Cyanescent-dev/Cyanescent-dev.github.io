import { formatDiagnosticFields, transitionDiagnosticId } from "./transitionDiagnostics.js";

let lastStallWarningAt = -Infinity;
let lastGapWarningAt = -Infinity;
let lastDiagnosticFrameAt = null;
let observedTransition = null;
let pendingGpuSummary = null;
let coveredPreparationGapUntil = -Infinity;
const gpuAggregates = new Map();
const cpuAggregates = new Map();

function transitionKind(transition, context = {}) {
  if (transition?.suppressShaderTransition || context.video?.selectedId) return "video";
  return "rendered";
}

function recordGpuResults(results = []) {
  for (const result of results) {
    if (!result?.diagnosticId || result.diagnosticId === "none") continue;
    let stages = gpuAggregates.get(result.diagnosticId);
    if (!stages) {
      stages = new Map();
      gpuAggregates.set(result.diagnosticId, stages);
    }
    const aggregate = stages.get(result.stage) || { count: 0, totalMs: 0, maxMs: 0 };
    aggregate.count += 1;
    aggregate.totalMs += Number(result.gpuMs) || 0;
    aggregate.maxMs = Math.max(aggregate.maxMs, Number(result.gpuMs) || 0);
    stages.set(result.stage, aggregate);
  }
}

function gpuSummary(diagnosticId) {
  const stages = gpuAggregates.get(diagnosticId);
  if (!stages) return {};
  return Object.fromEntries([...stages].map(([stage, value]) => [stage, {
    samples: value.count,
    averageMs: value.count ? value.totalMs / value.count : 0,
    maxMs: value.maxMs
  }]));
}

function recordCpuFrame(diagnosticId, totalMs, renderMs, stages = {}) {
  if (!diagnosticId || diagnosticId === "none") return;
  const aggregate = cpuAggregates.get(diagnosticId) || {
    frames: 0,
    totalMs: 0,
    maxTotalMs: 0,
    maxRenderMs: 0,
    stages: new Map()
  };
  aggregate.frames += 1;
  aggregate.totalMs += Number(totalMs) || 0;
  aggregate.maxTotalMs = Math.max(aggregate.maxTotalMs, Number(totalMs) || 0);
  aggregate.maxRenderMs = Math.max(aggregate.maxRenderMs, Number(renderMs) || 0);
  for (const [stage, elapsed] of Object.entries(stages || {})) {
    const value = Number(elapsed) || 0;
    const stageAggregate = aggregate.stages.get(stage) || { totalMs: 0, maxMs: 0 };
    stageAggregate.totalMs += value;
    stageAggregate.maxMs = Math.max(stageAggregate.maxMs, value);
    aggregate.stages.set(stage, stageAggregate);
  }
  cpuAggregates.set(diagnosticId, aggregate);
}

function cpuSummary(diagnosticId) {
  const aggregate = cpuAggregates.get(diagnosticId);
  if (!aggregate) return {};
  return {
    frames: aggregate.frames,
    averageTotalMs: aggregate.frames ? aggregate.totalMs / aggregate.frames : 0,
    maxTotalMs: aggregate.maxTotalMs,
    maxRenderMs: aggregate.maxRenderMs,
    stages: Object.fromEntries([...aggregate.stages].map(([stage, value]) => [stage, {
      averageMs: aggregate.frames ? value.totalMs / aggregate.frames : 0,
      maxMs: value.maxMs
    }]))
  };
}

export function renderLiveVisualizerFrame({
  now,
  performanceNow = () => performance.now(),
  isOfflineExport,
  skipVisuals,
  resize,
  updateAudio,
  updateKnotOrbitPhase,
  updateVisualTransitions,
  updatePresetTransition,
  updateLiveFeedbackStep,
  getActivePreset,
  getTransition,
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  renderShaderOrSpecialTransitionFrame,
  diagnosticsEnabled = () => false,
  getTransitionDiagnosticContext,
  getPresetName,
  updatePerformanceMeter,
  onFrameMetrics,
  requestNextVisualFrame
} = {}) {
  if (isOfflineExport?.()) {
    requestNextVisualFrame?.();
    return;
  }

  const renderStart = performanceNow();
  const diagnosticEnabled = Boolean(diagnosticsEnabled?.());
  const frameGapMs = lastDiagnosticFrameAt === null ? 0 : Math.max(0, Number(now) - lastDiagnosticFrameAt);
  lastDiagnosticFrameAt = Number(now);
  const resizeStart = performanceNow();
  resize?.();
  const resizeMs = performanceNow() - resizeStart;
  const audioStart = performanceNow();
  updateAudio?.();
  updateKnotOrbitPhase?.(now);
  const audioMs = performanceNow() - audioStart;
  const schedulingStart = performanceNow();
  updateVisualTransitions?.(now);
  const schedulingMs = performanceNow() - schedulingStart;
  const handoffStart = performanceNow();
  const transitionPhase = updatePresetTransition?.(now) ?? 0;
  const handoffMs = performanceNow() - handoffStart;
  const t = now * 0.001;
  updateLiveFeedbackStep?.(now);

  const activePreset = getActivePreset?.();
  const transition = getTransition?.();
  const diagnosticContext = diagnosticEnabled ? (getTransitionDiagnosticContext?.() || {}) : {};
  const currentDiagnosticId = transitionDiagnosticId(transition);
  if (diagnosticEnabled && transition?.active && observedTransition?.diagnosticId !== currentDiagnosticId) {
    observedTransition = {
      diagnosticId: currentDiagnosticId,
      from: transition.from,
      to: transition.to,
      swapped: Boolean(transition.swapped),
      kind: transitionKind(transition, diagnosticContext)
    };
    console.warn(`[TransitionDiag] ${formatDiagnosticFields({
      event: "begin",
      id: currentDiagnosticId,
      kind: observedTransition.kind,
      from: transition.from,
      from_name: getPresetName?.(transition.from) || "",
      to: transition.to,
      to_name: getPresetName?.(transition.to) || "",
      duration_ms: Number(transition.duration) || 0,
      swap_at: Number(transition.swapAt) || 0,
      quality: diagnosticContext.quality,
      fullscreen: diagnosticContext.fullscreen,
      shader_from: diagnosticContext.shaderFrom?.state,
      shader_to: diagnosticContext.shaderTo?.state,
      video_id: diagnosticContext.video?.selectedId
    })}`);
  } else if (diagnosticEnabled && transition?.active && observedTransition && !observedTransition.swapped && transition.swapped) {
    observedTransition.swapped = true;
    console.warn(`[TransitionDiag] ${formatDiagnosticFields({ event: "swap", id: currentDiagnosticId, from: transition.from, to: transition.to })}`);
  } else if (diagnosticEnabled && !transition?.active && observedTransition) {
    console.warn(`[TransitionDiag] ${formatDiagnosticFields({
      event: "end",
      id: observedTransition.diagnosticId,
      kind: observedTransition.kind,
      from: observedTransition.from,
      to: observedTransition.to
    })}`);
    pendingGpuSummary = { diagnosticId: observedTransition.diagnosticId, framesRemaining: 30 };
    observedTransition = null;
  }
  const renderStageStart = performanceNow();

  function finishFrame(renderDiagnostics = null) {
    const finishedAt = performanceNow();
    const renderMs = finishedAt - renderStageStart;
    const totalMs = finishedAt - renderStart;
    const videoState = diagnosticContext.video || {};
    const coveredPreparation = Boolean(
      renderDiagnostics?.branch === "video-covered"
      && Number(renderDiagnostics?.cpuStages?.incoming_preflight) > 0
      && Number(videoState.opacity) >= 0.995
      && videoState.playbackStarted
      && !videoState.paused
      && Number(videoState.readyState) >= 2
    );
    if (totalMs >= 120 && now - lastStallWarningAt >= 500) {
      lastStallWarningAt = now;
      if (coveredPreparation) coveredPreparationGapUntil = Number(now) + 1500;
      const transitionLabel = transition?.active
        ? `${transition.from ?? "?"}->${transition.to ?? "?"}`
        : "none";
      const fullscreen = globalThis.document?.body?.classList?.contains("fullscreen-ui") ?? false;
      if (!coveredPreparation) {
        console.warn(
          `Visual frame stall: total_ms=${totalMs.toFixed(1)} resize_ms=${resizeMs.toFixed(1)} ` +
          `audio_ms=${audioMs.toFixed(1)} scheduling_ms=${schedulingMs.toFixed(1)} ` +
          `handoff_ms=${handoffMs.toFixed(1)} render_ms=${renderMs.toFixed(1)} ` +
          `preset=${activePreset ?? "?"} transition=${transitionLabel} fullscreen=${fullscreen}`
        );
      }
      if (diagnosticEnabled) {
        const video = videoState;
        console.warn(`[TransitionDiag] ${formatDiagnosticFields({
          event: coveredPreparation ? "covered_preflight" : "stall",
          id: renderDiagnostics?.diagnosticId || currentDiagnosticId,
          kind: renderDiagnostics?.branch || transitionKind(transition, diagnosticContext),
          from: transition?.from,
          from_name: getPresetName?.(transition?.from) || "",
          to: transition?.to,
          to_name: getPresetName?.(transition?.to) || "",
          active: activePreset,
          frame_gap_ms: frameGapMs,
          total_ms: totalMs,
          render_ms: renderMs,
          width: renderDiagnostics?.renderWidth,
          height: renderDiagnostics?.renderHeight,
          quality: diagnosticContext.quality,
          fullscreen,
          cpu_stages: JSON.stringify(renderDiagnostics?.cpuStages || {}),
          gpu_timer: renderDiagnostics?.gpuTimerSupported ? "supported" : (renderDiagnostics?.gpuTimerReason || "disabled"),
          shader_from: diagnosticContext.shaderFrom?.state,
          shader_to: diagnosticContext.shaderTo?.state,
          video_id: video.selectedId,
          video_ready: video.readyState,
          video_time: video.currentTime,
          video_paused: video.paused,
          video_event: video.lastEvent,
          video_event_age_ms: video.lastEventAgeMs,
          video_waits: video.waitingEvents,
          video_stalls: video.stalledEvents,
          video_dropped: video.playbackQuality?.droppedFrames,
          video_frames: video.playbackQuality?.totalFrames
        })}`);
      }
    }
    // Logged unconditionally, unlike the diagnostics-only raf_gap below. When
    // requestAnimationFrame simply stops being called there is no slow frame to
    // report, so the stall warning above stays silent while the transition's
    // wall clock keeps running. That is exactly how a transition ends up tens of
    // seconds past its own end the next time anything renders.
    if (frameGapMs >= 250 && totalMs < 120 && now - lastGapWarningAt >= 1000) {
      lastGapWarningAt = now;
      const classes = globalThis.document?.body?.classList;
      const transitionElapsedMs = transition?.active
        ? Number(now) - Number(transition.start || now)
        : 0;
      console.warn(
        `Visual frame gap: frame_gap_ms=${frameGapMs.toFixed(0)} ` +
        `current_frame_ms=${totalMs.toFixed(1)} ` +
        `role=${classes?.contains("visual-output-role") ? "output" : "controller"} ` +
        `visibility=${globalThis.document?.visibilityState ?? "unknown"} ` +
        `fullscreen=${classes?.contains("fullscreen-ui") ?? false} ` +
        `transition=${transition?.active ? `${transition.from ?? "?"}->${transition.to ?? "?"}` : "none"} ` +
        `transition_elapsed_ms=${transitionElapsedMs.toFixed(0)}`
      );
    }
    if (diagnosticEnabled && frameGapMs >= 120 && totalMs < 120) {
      console.warn(`[TransitionDiag] ${formatDiagnosticFields({
        event: Number(now) <= coveredPreparationGapUntil ? "covered_preflight_gap" : "raf_gap",
        id: renderDiagnostics?.diagnosticId || currentDiagnosticId,
        frame_gap_ms: frameGapMs,
        current_frame_ms: totalMs
      })}`);
    }
    if (diagnosticEnabled) {
      recordCpuFrame(
        renderDiagnostics?.diagnosticId || currentDiagnosticId,
        totalMs,
        renderMs,
        renderDiagnostics?.cpuStages
      );
      recordGpuResults(renderDiagnostics?.gpuResults || []);
      if (pendingGpuSummary) {
        pendingGpuSummary.framesRemaining -= 1;
        if (pendingGpuSummary.framesRemaining <= 0) {
          const summary = gpuSummary(pendingGpuSummary.diagnosticId);
          console.warn(`[TransitionDiag] ${formatDiagnosticFields({
            event: "transition_summary",
            id: pendingGpuSummary.diagnosticId,
            cpu: JSON.stringify(cpuSummary(pendingGpuSummary.diagnosticId)),
            gpu_timer: renderDiagnostics?.gpuTimerSupported ? "supported" : (renderDiagnostics?.gpuTimerReason || "disabled"),
            stages: JSON.stringify(summary)
          })}`);
          gpuAggregates.delete(pendingGpuSummary.diagnosticId);
          cpuAggregates.delete(pendingGpuSummary.diagnosticId);
          pendingGpuSummary = null;
        }
      }
    }
    updatePerformanceMeter?.(now, totalMs);
    onFrameMetrics?.({
      now,
      frameGapMs,
      totalMs,
      renderMs,
      activePreset,
      transition,
      renderDiagnostics
    });
    requestNextVisualFrame?.();
  }

  if (skipVisuals) {
    finishFrame();
    return;
  }

  if (!transition?.active && isFiddleheadPreset?.(activePreset)) {
    renderFiddleheadGeometry?.(now);
    finishFrame();
    return;
  }

  if (!transition?.active && isPineconePreset?.(activePreset)) {
    renderPinecone3D?.(now, null, undefined, undefined, activePreset);
    finishFrame();
    return;
  }

  if (!transition?.active && isQuantumFluidPreset?.(activePreset)) {
    renderQuantumFluid3D?.(now, null, undefined, undefined, activePreset);
    finishFrame();
    return;
  }

  if (!transition?.active && isKleinianCoralCathedralPreset?.(activePreset)) {
    renderKleinianCoralCathedral?.(now);
    finishFrame();
    return;
  }

  if (!transition?.active && isBloodCellNebulaPreset?.(activePreset)) {
    renderBloodCellNebula?.(now);
    finishFrame();
    return;
  }

  const renderDiagnostics = renderShaderOrSpecialTransitionFrame?.(now, t, transitionPhase);
  finishFrame(renderDiagnostics);
}

export function createLiveRenderLoopController({
  requestAnimationFrameFn = requestAnimationFrame,
  renderFrame,
  isReady = () => true
} = {}) {
  let running = false;

  function requestNextFrame() {
    if (running) requestAnimationFrameFn(renderFrame);
  }

  function start() {
    if (!isReady() || running) return;
    running = true;
    requestAnimationFrameFn(renderFrame);
  }

  function stop() {
    running = false;
  }

  function isRunning() {
    return running;
  }

  return {
    requestNextFrame,
    start,
    stop,
    isRunning
  };
}
