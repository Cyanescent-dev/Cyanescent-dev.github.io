// Newton Basin Descent: runtime-field package reader and the pure timeline /
// sampling rules shared by the WebGL runtime and tools/test-newton-basin.mjs.
// No DOM or WebGL here. The package format is written by
// scripts/compile-newton-basin-runtime.mjs (scripts/newton-basin-runtime-lib.mjs).

export const NBF_MAGIC = "NBF1";
export const NBF_HEADER_BYTES = 16;
export const NBF_ENTRY_BYTES = 12;
export const PLANE_ORDER = Object.freeze(["flags", "boundary", "flowAngle", "iteration", "depthLo", "depthHi", "domainRadius", "domainAngle"]);
export const PACKAGE_VERSION = 2;
export const REGION_SKY = 0;
export const REGION_ESCAPED = 1;
export const REGION_EXHAUSTED = 5;
export const ANCHOR_RECORD_BYTES = 16;
export const MAX_ANCHORS = 12;
export const ANCHOR_SAMPLE_BYTES = 1 + MAX_ANCHORS * ANCHOR_RECORD_BYTES;

const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

// ---------------------------------------------------------------- half floats

export function halfBitsToFloat(bits) {
  const exponent = (bits >> 10) & 31;
  const fraction = bits & 1023;
  const sign = bits & 0x8000 ? -1 : 1;
  if (exponent === 0) return sign * 2 ** -14 * (fraction / 1024);
  if (exponent === 31) return fraction ? NaN : sign * Infinity;
  return sign * 2 ** (exponent - 15) * (1 + fraction / 1024);
}

// ------------------------------------------------------------ package reading

export function parseSegment(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  if (bytes.length < NBF_HEADER_BYTES) throw new Error("Newton segment is truncated");
  for (let i = 0; i < 4; i += 1) if (bytes[i] !== NBF_MAGIC.charCodeAt(i)) throw new Error("Newton segment has a bad signature");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const version = view.getUint16(4, true);
  if (version !== 1) throw new Error(`Unsupported Newton segment version ${version}`);
  const count = view.getUint16(6, true);
  const firstSample = view.getUint32(8, true);
  const entries = [];
  for (let i = 0; i < count; i += 1) {
    const at = NBF_HEADER_BYTES + i * NBF_ENTRY_BYTES;
    const entry = { offset: view.getUint32(at, true), stored: view.getUint32(at + 4, true), raw: view.getUint32(at + 8, true) };
    if (entry.offset + entry.stored > bytes.length) throw new Error("Newton segment entry runs past the end of the file");
    entries.push(entry);
  }
  return { version, count, firstSample, entries, bytes };
}

// Decode one sample payload to planar bytes (PLANE_ORDER, top row first).
// "deflate" is a zlib stream; DecompressionStream runs off the main thread.
export async function readSample(segment, indexInSegment, codec, expectedRawBytes) {
  const entry = segment.entries[indexInSegment];
  if (!entry) throw new Error(`Newton segment has no sample ${indexInSegment}`);
  const stored = segment.bytes.subarray(entry.offset, entry.offset + entry.stored);
  if (entry.raw !== expectedRawBytes) throw new Error(`Newton sample is ${entry.raw} bytes, expected ${expectedRawBytes}`);
  if (codec === "none") return stored.slice();
  if (codec !== "deflate") throw new Error(`Unknown Newton sample codec "${codec}"`);
  if (typeof DecompressionStream !== "function") throw new Error("DecompressionStream is unavailable");
  const stream = new Blob([stored]).stream().pipeThrough(new DecompressionStream("deflate"));
  const out = new Uint8Array(await new Response(stream).arrayBuffer());
  if (out.length !== expectedRawBytes) throw new Error(`Newton sample inflated to ${out.length} bytes, expected ${expectedRawBytes}`);
  return out;
}

// Planar -> two GPU-ready RGBA8 images, rows kept top first (no flip):
//   A = flags, boundary, flowAngle, iteration     B = depthLo, depthHi, domainRadius, domainAngle
export function interleaveSample(raw, width, height, outA, outB) {
  const count = width * height;
  const flags = raw.subarray(0, count), boundary = raw.subarray(count, count * 2);
  const flowAngle = raw.subarray(count * 2, count * 3), iteration = raw.subarray(count * 3, count * 4);
  const depthLo = raw.subarray(count * 4, count * 5), depthHi = raw.subarray(count * 5, count * 6);
  const domainRadius = raw.subarray(count * 6, count * 7), domainAngle = raw.subarray(count * 7, count * 8);
  for (let i = 0, o = 0; i < count; i += 1, o += 4) {
    outA[o] = flags[i]; outA[o + 1] = boundary[i]; outA[o + 2] = flowAngle[i]; outA[o + 3] = iteration[i];
    outB[o] = depthLo[i]; outB[o + 1] = depthHi[i]; outB[o + 2] = domainRadius[i]; outB[o + 3] = domainAngle[i];
  }
}

export function segmentLocation(sampleIndex, samplesPerSegment) {
  return { segment: Math.floor(sampleIndex / samplesPerSegment), index: sampleIndex % samplesPerSegment };
}

export function segmentName(pattern, segment) {
  return pattern.replace("%04d", String(segment).padStart(4, "0"));
}

// ---------------------------------------------------------------- CPU reference

export function decodeIterationByte(byte, encoding) {
  if (byte < encoding.kneeByte) return byte / 4;
  return encoding.knee + ((byte - encoding.kneeByte) / (255 - encoding.kneeByte)) * (encoding.budget - encoding.knee);
}

export function decodeDomainRadiusByte(byte, encoding) {
  return encoding.radius.min + (byte / 255) * (encoding.radius.max - encoding.radius.min);
}

// Decoded texel of one sample image pair. This is the reference for what the
// shaders decode; tests check it against the compiler's encoders.
export function decodeTexel(imageA, imageB, width, x, y, encoding) {
  const o = (y * width + x) * 4;
  const flags = imageA[o];
  const distance = (byte) => encoding.boundary.maxTexels * (byte / 255) * (byte / 255);
  const flowValid = (flags & 0x10) !== 0;
  const hit = (flags & 0x08) !== 0;
  const angle = (imageA[o + 2] / 256) * 2 * Math.PI;
  return {
    region: flags & 0x07, hit, flowValid,
    boundary: distance(imageA[o + 1]),
    flowX: flowValid ? Math.cos(angle) : 0, flowY: flowValid ? Math.sin(angle) : 0,
    iteration: decodeIterationByte(imageA[o + 3], encoding.iteration),
    depth: hit ? halfBitsToFloat(imageB[o] | (imageB[o + 1] << 8)) : 0,
    rho: decodeDomainRadiusByte(imageB[o + 2], encoding.domain), theta: imageB[o + 3] / 256
  };
}

// Temporal rule between two neighbouring samples at mix in [0, 1].
// Categorical data (region, validity) is taken from the nearer sample and is never
// blended. Continuous data blends only where both samples describe the same
// surface (same region, both hits); across a topology change it uses the nearer
// valid sample and reports agree = 0 so effects fade instead of smearing. The domain
// angle is categorical-like (it wraps) and is always taken from the nearer sample.
export function resolveTexel(a, b, mix) {
  const nearer = mix < 0.5 ? a : b;
  const other = mix < 0.5 ? b : a;
  const agree = a.region === b.region && a.hit && b.hit;
  const out = {
    region: nearer.region, hit: nearer.hit, agree: agree ? 1 : 0,
    flowValid: nearer.flowValid, theta: nearer.theta
  };
  if (!agree) {
    Object.assign(out, { boundary: nearer.boundary, iteration: nearer.iteration, rho: nearer.rho,
      depth: nearer.hit ? nearer.depth : other.hit ? other.depth : 0, flowX: nearer.flowX, flowY: nearer.flowY });
    return out;
  }
  const lerp = (p, q) => p + (q - p) * mix;
  out.boundary = lerp(a.boundary, b.boundary);
  out.iteration = lerp(a.iteration, b.iteration);
  out.rho = lerp(a.rho, b.rho);
  out.depth = lerp(a.depth, b.depth);
  if (a.flowValid && b.flowValid) {
    const x = lerp(a.flowX, b.flowX), y = lerp(a.flowY, b.flowY), length = Math.hypot(x, y);
    if (length > 0.05) { out.flowX = x / length; out.flowY = y / length; }
    else { out.flowX = nearer.flowX; out.flowY = nearer.flowY; }
    out.flowValid = true;
  } else {
    out.flowX = nearer.flowX; out.flowY = nearer.flowY;
  }
  return out;
}

// ---------------------------------------------------------- timeline / clock

export function sampleTimes(runtime) {
  const { sourceFrames } = runtime.fields;
  const fps = runtime.source.fps;
  return Float64Array.from(sourceFrames, (frame) => frame / fps);
}

// Bracket time t between two samples using the real sample timestamps. Times
// outside the timeline clamp to the first / last sample.
export function locateSample(times, t) {
  const last = times.length - 1;
  if (!(t > times[0])) return { i0: 0, i1: 0, mix: 0 };
  if (t >= times[last]) return { i0: last, i1: last, mix: 0 };
  let low = 0, high = last;
  while (high - low > 1) {
    const middle = (low + high) >> 1;
    if (times[middle] <= t) low = middle; else high = middle;
  }
  return { i0: low, i1: low + 1, mix: (t - times[low]) / (times[low + 1] - times[low]) };
}

// Classify a change of the authoritative video media time between two frames.
// Field time is the video media time, so the field follows every seek, pause and
// loop for free; this only decides when transient effect state must be dropped.
export function classifyTimeStep(previous, current, durationSeconds, wallSeconds, playbackRate) {
  if (!Number.isFinite(previous) || !Number.isFinite(current)) return "reset";
  const delta = current - previous;
  if (delta < -0.5 && previous > durationSeconds - 1.5 && current < 1.5) return "loop";
  if (delta < -0.01) return "seek";
  const expected = Math.max(0.05, wallSeconds * Math.max(0.25, playbackRate) * 2.5 + 0.12);
  if (delta > expected) return "seek";
  return "continue";
}

// Reactive-layer fade across the (non-seamless) loop seam so it never shows a
// stale state at the cut. 0 at the cut, 1 away from it.
export function loopFade(mediaTime, durationSeconds, fadeSeconds, hasLooped) {
  const tail = clamp((durationSeconds - mediaTime) / fadeSeconds, 0, 1);
  const head = hasLooped ? clamp(mediaTime / fadeSeconds, 0, 1) : 1;
  return tail * head;
}

// ------------------------------------------------------------------ scene

export function cameraAt(timeline, i0, i1, mix, out = {}) {
  const c = timeline.camera;
  const lerp = (offset, k) => c[i0 * 12 + offset + k] + (c[i1 * 12 + offset + k] - c[i0 * 12 + offset + k]) * mix;
  const vec = (name, offset, normalise) => {
    const v = out[name] || (out[name] = [0, 0, 0]);
    v[0] = lerp(offset, 0); v[1] = lerp(offset, 1); v[2] = lerp(offset, 2);
    if (normalise) {
      const length = Math.hypot(v[0], v[1], v[2]) || 1;
      v[0] /= length; v[1] /= length; v[2] /= length;
    }
  };
  vec("position", 0, false); vec("forward", 3, true); vec("right", 6, true); vec("up", 9, true);
  out.tanHalfFov = timeline.tanHalfFov[i0] + (timeline.tanHalfFov[i1] - timeline.tanHalfFov[i0]) * mix;
  out.aspect = timeline.aspect;
  return out;
}

export function morphAt(timeline, i0, i1, mix, out = {}) {
  out.balance = timeline.balance[i0] + (timeline.balance[i1] - timeline.balance[i0]) * mix;
  out.coexist = timeline.coexist[i0] + (timeline.coexist[i1] - timeline.coexist[i0]) * mix;
  out.lawPhase = timeline.lawPhase[mix < 0.5 ? i0 : i1];
  return out;
}

// How fast the surface is changing under the camera (0 calm .. 1 fast): flow-driven
// effects shorten and reseed as this rises so nothing slides off the structure.
export function motionAt(timeline, i0, i1, mix) {
  const a = timeline.attachRisk[i0], b = timeline.attachRisk[i1];
  return a + (b - a) * mix;
}

// Root reference screen positions for the nearer sample, only when the export
// reports them and they are inside the frame; the caller treats [] as "none".
export function rootReferencesAt(timeline, i0, i1, mix) {
  const index = mix < 0.5 ? i0 : i1;
  const roots = [];
  for (let id = 0; id < 3; id += 1) {
    const at = index * 12 + id * 4;
    const [u, v, depth, inFrame] = timeline.roots.slice(at, at + 4);
    if (inFrame > 0.5 && depth > 0 && u >= 0 && u <= 1 && v >= 0 && v <= 1) roots.push({ id, u, v, depth });
  }
  return roots;
}

// ------------------------------------------------------------------ anchors

export function parseAnchors(bytes, sample) {
  const base = sample * ANCHOR_SAMPLE_BYTES;
  if (base + ANCHOR_SAMPLE_BYTES > bytes.length) return [];
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const count = Math.min(MAX_ANCHORS, bytes[base]);
  const anchors = [];
  for (let i = 0; i < count; i += 1) {
    const at = base + 1 + i * ANCHOR_RECORD_BYTES;
    anchors.push({
      id: bytes[at], code: bytes[at + 1], u: view.getUint16(at + 2, true) / 65535, v: view.getUint16(at + 4, true) / 65535,
      radius: view.getUint16(at + 6, true) / 64, depth: halfBitsToFloat(view.getUint16(at + 8, true)), strength: bytes[at + 10] / 255,
      rho: -8 + (bytes[at + 11] / 255) * 12, theta: bytes[at + 12] / 256
    });
  }
  return anchors;
}

// Blend the anchors of two neighbouring samples by stable id. An anchor present
// in only one sample fades with the mix so nothing pops.
export function interpolateAnchors(list0, list1, mix) {
  const byId = new Map();
  for (const anchor of list0) byId.set(anchor.id, { from: anchor, to: null });
  for (const anchor of list1) {
    const entry = byId.get(anchor.id);
    if (entry) entry.to = anchor; else byId.set(anchor.id, { from: null, to: anchor });
  }
  const out = [];
  for (const { from, to } of byId.values()) {
    if (from && to && from.code === to.code) {
      const lerp = (p, q) => p + (q - p) * mix;
      out.push({ id: from.id, code: from.code, u: lerp(from.u, to.u), v: lerp(from.v, to.v), radius: lerp(from.radius, to.radius),
        depth: lerp(from.depth, to.depth), strength: lerp(from.strength, to.strength), presence: 1,
        rho: lerp(from.rho, to.rho), theta: mix < 0.5 ? from.theta : to.theta });
    } else {
      const source = from || to;
      const presence = from ? 1 - mix : mix;
      out.push({ ...source, presence });
    }
  }
  return out.sort((a, b) => b.strength * b.presence - a.strength * a.presence);
}

// -------------------------------------------------------------- morph weights

// Continuous weights for the behaviour mix, from the Forge world state. Never a
// hard switch between three presets: every weight is a smooth function of
// balance / coexist and the flow validity fraction.
export function morphWeights({ balance, coexist }, flowValidFraction = 1) {
  const smooth = (edge0, edge1, x) => {
    const t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
    return t * t * (3 - 2 * t);
  };
  const flowPresence = clamp(flowValidFraction, 0, 1);
  const newton = smooth(0.5, 0.92, balance) * flowPresence;
  const mandelbrot = 1 - smooth(0.06, 0.5, balance);
  const hybrid = clamp(Math.max(coexist, 1 - Math.abs(balance - 0.55) / 0.45) * (1 - newton * 0.6), 0, 1);
  return { mandelbrot, hybrid, newton, flow: smooth(0.02, 0.35, balance) * flowPresence, root: smooth(0.62, 0.95, balance) };
}

// ------------------------------------------------------------- field store

// Streams decoded samples for the runtime: fetches segment files, inflates one
// sample at a time, and keeps only a small window of interleaved RGBA8 images
// (two neighbouring samples are what the renderer needs). Decoded buffers are
// pooled, so steady-state playback allocates nothing per frame. Missing or
// corrupt data never throws into the render loop: get() returns null and the
// caller fades the reactive layer while the video keeps playing.
// transformRaw (optional) runs on each inflated planar sample before interleaving; another
// preset built on this container uses it to undo its row filter.
export function createFieldStore({ runtime, fetchBytes, urlFor, behind = 2, ahead = 14, concurrency = 2, now = () => Date.now(), transformRaw = null }) {
  const info = runtime.fields;
  const imageBytes = info.width * info.height * 4;
  const samples = new Map();
  const segments = new Map();
  const pool = [];
  const queue = [];
  let running = 0;
  let generation = 0;
  const stats = { segmentFetches: 0, samplesDecoded: 0, failures: 0, lastError: "", decodeMs: 0, maxDecodeMs: 0, fetchMs: 0 };

  function takeBuffer() { return pool.pop() || { a: new Uint8Array(imageBytes), b: new Uint8Array(imageBytes) }; }

  async function loadSegment(index) {
    let entry = segments.get(index);
    if (entry?.parsed) return entry.parsed;
    if (entry?.promise) return entry.promise;
    if (entry?.failedAt && now() - entry.failedAt < 2000) throw new Error(entry.error);
    entry = { promise: null, parsed: null, failedAt: 0, error: "" };
    segments.set(index, entry);
    const token = generation;
    const started = now();
    entry.promise = (async () => {
      try {
        const bytes = await fetchBytes(urlFor(`${info.directory}/${segmentName(info.filePattern, index)}`));
        const parsed = parseSegment(bytes);
        if (parsed.firstSample !== index * info.samplesPerSegment) throw new Error(`segment ${index} starts at sample ${parsed.firstSample}`);
        if (token === generation) { entry.parsed = parsed; stats.segmentFetches += 1; stats.fetchMs += now() - started; }
        return parsed;
      } catch (error) {
        entry.failedAt = now(); entry.error = String(error?.message || error);
        stats.failures += 1; stats.lastError = entry.error;
        throw error;
      } finally { entry.promise = null; }
    })();
    return entry.promise;
  }

  async function decode(index, token) {
    const at = segmentLocation(index, info.samplesPerSegment);
    const segment = await loadSegment(at.segment);
    const started = now();
    const raw = await readSample(segment, at.index, info.codec, info.rawSampleBytes);
    if (token !== generation) return;
    if (transformRaw) transformRaw(raw);
    const buffer = takeBuffer();
    interleaveSample(raw, info.width, info.height, buffer.a, buffer.b);
    const entry = samples.get(index);
    if (!entry) { pool.push(buffer); return; }
    entry.a = buffer.a; entry.b = buffer.b; entry.state = "ready";
    const cost = now() - started;
    stats.samplesDecoded += 1; stats.decodeMs += cost; stats.maxDecodeMs = Math.max(stats.maxDecodeMs, cost);
  }

  function pump() {
    while (running < concurrency && queue.length) {
      const { index, token } = queue.shift();
      const entry = samples.get(index);
      if (!entry || token !== generation || entry.state !== "queued") continue;
      entry.state = "loading";
      running += 1;
      decode(index, token).catch((error) => {
        const current = samples.get(index);
        if (current && token === generation) { current.state = "failed"; current.failedAt = now(); stats.failures += 1; stats.lastError = String(error?.message || error); }
      }).finally(() => { running -= 1; pump(); });
    }
  }

  function request(index, urgent = false) {
    if (!Number.isInteger(index) || index < 0 || index >= info.sampleCount) return;
    let entry = samples.get(index);
    if (entry && entry.state === "failed" && now() - entry.failedAt > 2000) { samples.delete(index); entry = undefined; }
    if (entry) return;
    samples.set(index, { state: "queued", a: null, b: null, failedAt: 0 });
    const item = { index, token: generation };
    if (urgent) queue.unshift(item); else queue.push(item);
    pump();
  }

  function retain(keep) {
    for (const [index, entry] of samples) {
      if (keep.has(index)) continue;
      if (entry.a) pool.push({ a: entry.a, b: entry.b });
      samples.delete(index);
    }
    const neededSegments = new Set([...keep].map((index) => Math.floor(index / info.samplesPerSegment)));
    for (const index of segments.keys()) if (!neededSegments.has(index)) segments.delete(index);
    if (pool.length > 6) pool.length = 6;
  }

  function prefetch(center, needed = []) {
    const keep = new Set();
    for (const index of needed) { request(index, true); keep.add(index); }
    for (let index = Math.max(0, center - behind); index <= Math.min(info.sampleCount - 1, center + ahead); index += 1) {
      request(index);
      keep.add(index);
    }
    // The loop restarts at sample 0: warm it before the playhead gets there.
    if (center + ahead >= info.sampleCount - 1) {
      for (let index = 0; index <= Math.min(info.sampleCount - 1, 3); index += 1) { request(index); keep.add(index); }
    }
    retain(keep);
  }

  function get(index) {
    const entry = samples.get(index);
    return entry && entry.state === "ready" ? entry : null;
  }

  function dispose() {
    generation += 1;
    samples.clear(); segments.clear(); queue.length = 0; pool.length = 0;
  }

  async function ready(indices, timeoutMs = 15000) {
    const token = generation;
    prefetch(indices[0], indices);
    const deadline = now() + timeoutMs;
    while (!indices.every((index) => get(index))) {
      if (token !== generation) throw new Error("Forge metadata wait cancelled");
      if (indices.some((index) => samples.get(index)?.state === "failed")) throw new Error(stats.lastError || "Forge metadata decode failed");
      if (now() > deadline) throw new Error("Forge metadata readiness timed out");
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
    return indices.map(get);
  }
  return { request, prefetch, get, ready, dispose, stats, size: () => samples.size };
}
