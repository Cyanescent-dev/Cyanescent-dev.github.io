// Artificial Consciousness: music -> light travelling the network. Pure JS, no GL, so the mapping is
// testable. It consumes Newton Basin Descent's music model (newtonBasinAudio.js: beat grid, groove,
// build, drop, hats, breakdown) unchanged, plus the story state of the video frame being shown, and
// produces the uniforms the edge shader draws.
//
// The idea: the background video is a network becoming conscious. The live layer is that same network
// listening. Every element lies on the network's real connections (the shaders rebuild every node and
// connection of the video exactly), and what each instrument does follows the story:
//
//   kick          a wave through the wiring on every beat of the track's beat grid. Before the awakening it
//                 is a forward pass: it leaves the core (or one of the six lobes) and runs outward; once the
//                 flows have aligned it is perception: it runs inward and arrives at the aperture exactly on
//                 the next beat (the beat grid is a precise clock, so arrival can be scheduled).
//   hi-hats       neurons firing: small ripples around hub nodes
//   bass          the long-range links and radial buses breathe and carry slow bolts
//   mids / pads   module hubs swell in patches
//   build-up      roll waves on a subdividing grid; the whole network ticks on a shared phase (synchrony)
//   breakdown     slow tides once a bar; the streams slow and dim
//   drop          one big front from the aperture out through the structure and the loops it grows
//
// The story (consciousness, aligned, aperture, transcendence ...) gates everything: the machine is crisp
// and cold, the awake network warm and flowing; elements that the video has not grown yet simply have no
// wiring to travel along.
import { AC_ROLES, AC_EDGE_KINDS, AC_WAVES, AC_SPARKS } from "./artificialConsciousnessShaders.js";

export const ROLE = Object.freeze({ KICK: 0, DROP: 1, SPARK: 2, TIDE: 3, ROLL: 4, BUILD: 5 });

// Per role, how strongly each connection kind carries the light (ring fan bridge hubstar hublink region
// long spoke subring subfan subbus tether meta reach satellite core attention).
export const KIND_WEIGHTS = Object.freeze([
  /* KICK  */ [0.95, 0.75, 0.55, 0.55, 1.00, 1.20, 1.30, 1.20, 0.80, 0.60, 1.10, 0.50, 1.00, 1.00, 1.00, 1.40, 1.30],
  /* DROP  */ [1.10, 0.95, 0.80, 0.70, 1.10, 1.30, 1.40, 1.30, 1.00, 0.80, 1.20, 0.60, 1.20, 1.20, 1.20, 1.50, 1.40],
  /* SPARK */ [1.00, 0.90, 0.70, 0.85, 0.80, 0.50, 0.30, 0.30, 1.00, 0.90, 0.50, 0.60, 0.30, 0.30, 0.30, 0.80, 0.40],
  /* TIDE  */ [0.60, 0.50, 0.40, 0.30, 0.80, 1.00, 1.00, 1.00, 0.50, 0.40, 0.70, 0.30, 0.80, 0.80, 0.80, 1.00, 0.80],
  /* ROLL  */ [0.60, 0.50, 0.40, 0.60, 1.00, 1.00, 1.00, 1.00, 0.40, 0.30, 0.60, 0.30, 0.60, 0.60, 0.60, 0.90, 0.80],
  /* BUILD */ [0.60, 0.40, 0.30, 0.60, 0.80, 1.00, 1.00, 1.00, 0.15, 0.10, 0.50, 0.20, 0.80, 0.80, 0.80, 1.00, 1.00]
]);
if (KIND_WEIGHTS.length !== AC_ROLES || KIND_WEIGHTS.some((row) => row.length !== AC_EDGE_KINDS)) throw new Error("kind weight table has the wrong shape");

const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
const clamp01 = (x) => clamp(Number.isFinite(x) ? x : 0, 0, 1);
const mix = (a, b, t) => a + (b - a) * t;
const smoothstep = (a, b, x) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };

// Colours: cold machine light -> warm, awake light.
const COLD = [0.55, 0.85, 1.0];
const WHITE = [1.0, 1.0, 1.0];
const GOLD = [1.0, 0.78, 0.46];
const ROSE = [1.0, 0.45, 0.62];
const VIOLET = [0.66, 0.48, 1.0];
const lerp3 = (a, b, t) => [mix(a[0], b[0], t), mix(a[1], b[1], t), mix(a[2], b[2], t)];

// Tiny deterministic generator (a counter hashed), so a run is reproducible.
function rng(seed) {
  let s = seed >>> 0;
  return () => { s = (Math.imul(s ^ (s >>> 15), 0x2c1b3c6d) + 0x297a2d39) >>> 0; s ^= s >>> 12; s = Math.imul(s, 0x85ebca6b) >>> 0; s ^= s >>> 13; return (s >>> 0) / 4294967296; };
}

export const MUSIC_LIMITS = Object.freeze({
  maxWaves: AC_WAVES,
  maxSparks: AC_SPARKS,
  sparkLifeSeconds: 0.34,
  sparkSpeed: 16,           // world units per second
  sparkMaxRadius: 9
});

// Which story state is the video in? All scalars 0..1. `story` is storyAt() of the frame.
export function storyLook(story) {
  const consciousness = clamp01(story.consciousness);
  const aligned = clamp01(story.aligned * Math.max(story.colourState, 0.35));
  const machine = 1 - smoothstep(0.02, 0.35, consciousness);
  const organic = smoothstep(0.10, 0.80, consciousness);
  const awake = smoothstep(0.35, 0.8, consciousness) * clamp01(story.front * 1.2);
  return {
    consciousness, aligned, machine, organic, awake,
    aperture: clamp01(story.aperture), transcendence: clamp01(story.transcendence), breath: clamp01(story.breath),
    synchrony: clamp01(story.synchrony), expansion: clamp01(story.expansion)
  };
}

// Wave light colour for the current story and event: cold white-cyan for the machine, the awake palette
// (gold -> rose -> violet by bar) for the conscious network, white hot for accents.
export function waveColour(look, accent, bar) {
  const palette = [GOLD, ROSE, VIOLET, GOLD][((Math.floor(bar) % 4) + 4) % 4];
  const warm = lerp3(palette, WHITE, 0.25);
  const base = lerp3(COLD, warm, look.awake);
  return lerp3(base, WHITE, 0.35 * accent);
}

export function createMusicLayer({ regionAngles: initialAngles = [0.66, 1.75, 2.8, 3.87, 5.05, 6.04], hubPicker: initialPicker = null, seed = 20260908 } = {}) {
  let regionAngles = initialAngles.slice(0, 6);
  let hubPicker = initialPicker;
  const rand = rng(seed);
  let waves = [];
  let sparks = [];
  let lastBeatIndex = null;
  let impact = 0, strobe = 0, dropFlash = 0, kickLevel = 0;
  const state = {
    waveCount: 0, sparkCount: 0, waves: [], bass: 0, mids: 0, highs: 0, energy: 0, strobe: 0, dim: 0, dropFlash: 0, build: 0,
    impact: 0, stageDim: 0, beat: 0, beatPhase: 0, streamHead: 0, streamGain: 0, loopGain: 0, machine: 1, organic: 0, direction: "out", kicks: 0,
    drops: 0, rolls: 0, tides: 0, hats: 0, spectrum: new Float32Array(16)
  };
  const uniforms = {
    waveA: new Float32Array(AC_WAVES * 4), waveB: new Float32Array(AC_WAVES * 4), waveC: new Float32Array(AC_WAVES * 4),
    spark: new Float32Array(AC_SPARKS * 4), A: new Float32Array(4), B: new Float32Array(4), C: new Float32Array(4), D: new Float32Array(4),
    spec: new Float32Array(16), kindWeights: new Float32Array(AC_ROLES * AC_EDGE_KINDS)
  };
  KIND_WEIGHTS.forEach((row, role) => uniforms.kindWeights.set(row, role * AC_EDGE_KINDS));

  function reset() {
    waves = []; sparks = []; lastBeatIndex = null; impact = strobe = dropFlash = kickLevel = 0;
    for (const key of ["kicks", "drops", "rolls", "tides", "hats"]) state[key] = 0;
  }

  const regionCentre = (index, radius = 27) => {
    const a = regionAngles[((index % 6) + 6) % 6];
    return [Math.cos(a) * radius, Math.sin(a) * radius];
  };

  function addWave(wave) {
    waves.push(wave);
    if (waves.length > MUSIC_LIMITS.maxWaves) waves.shift();
  }

  // Advance by dt seconds. `audio` is the Newton audio model's state, `events` its events for this step.
  function step(dt, { audio, events, story, beatsPerBar = 4, reactive = 1, spectrum = null, controls = {} }) {
    dt = clamp(dt, 0, 0.1);
    const look = storyLook(story);
    const beat = audio.beat;
    const bar = beat / beatsPerBar;
    const r = clamp(reactive, 0, 1.5);
    const accentGain = r * (0.35 + 0.65 * clamp01(audio.energyDrive + 0.25));
    const inward = look.aligned > 0.55;

    // ---- events -> waves -------------------------------------------------------------------
    for (const event of events?.waves || []) {
      const strength = clamp(event.strength, 0, 1.6);
      if (event.kind === "kick") {
        state.kicks += 1;
        const downbeat = event.beatInBar === 0;
        // beats 2-4 take turns round the six lobes; the downbeat is the whole network
        const lobe = ((Math.floor(bar) * 3 + (event.beatInBar | 0) - 1) % 6 + 6) % 6;
        const centre = downbeat || inward ? [0, 0] : regionCentre(lobe);
        const amp = (downbeat ? 1.0 : 0.72) * strength * accentGain * mix(0.9, 1.15, look.machine);
        const colour = waveColour(look, downbeat ? 1 : 0.3, bar);
        if (inward) {
          // perception: starts at the rim of the network and arrives at the aperture one beat later
          addWave({ role: ROLE.KICK, birth: beat, life: 1.45, cx: 0, cz: 0, startR: downbeat ? 78 : 56, endR: 0, dir: -1, width: downbeat ? 7 : 5.2, tail: 1.5, amp, colour, arrive: true });
          impact = Math.max(impact, 0.55 + 0.45 * strength);          // the previous wave arrives now
        } else {
          addWave({ role: ROLE.KICK, birth: beat, life: 2.2, cx: centre[0], cz: centre[1], startR: 0, endR: downbeat ? 150 : 72, dir: 1, width: downbeat ? mix(4.5, 8, look.organic) : mix(4.0, 6.5, look.organic), tail: mix(0.9, 1.7, look.organic), amp, colour });
        }
        kickLevel = Math.max(kickLevel, strength);
      } else if (event.kind === "roll") {
        state.rolls += 1;
        const lobe = Math.floor(rand() * 6);
        const c = regionCentre(lobe, 20 + 14 * rand());
        addWave({ role: ROLE.ROLL, birth: beat, life: 0.7, cx: c[0], cz: c[1], startR: 0, endR: 30, dir: 1, width: 2.2, tail: 0.8, amp: strength * 1.2 * r, colour: waveColour(look, 0.5, bar) });
        strobe = Math.max(strobe, 0.12 + 0.30 * audio.build);
      } else if (event.kind === "tide") {
        state.tides += 1;
        addWave({ role: ROLE.TIDE, birth: beat, life: 3.6, cx: 0, cz: 0, startR: inward ? 90 : 0, endR: inward ? 0 : 110, dir: inward ? -1 : 1, width: 16, tail: 2.2, amp: strength * r * 0.9, colour: waveColour(look, 0, bar) });
      } else if (event.kind === "drop") {
        state.drops += 1;
        addWave({ role: ROLE.DROP, birth: beat, life: 3.0, cx: 0, cz: 0, startR: 0, endR: 235, dir: 1, width: 9, tail: 1.8, amp: 1.5 * r, colour: waveColour(look, 1, bar) });
        addWave({ role: ROLE.DROP, birth: beat + 0.35, life: 3.0, cx: 0, cz: 0, startR: 0, endR: 235, dir: 1, width: 4.5, tail: 1.2, amp: 0.9 * r, colour: lerp3(GOLD, WHITE, 0.4) });
        dropFlash = 1;
      }
    }

    // ---- hats -> sparks ----------------------------------------------------------------------
    if (events?.hats && controls.sparks !== 0) {
      state.hats += 1;
      const count = 1 + Math.floor(clamp01(audio.highDrive) * 3 * (0.6 + 0.4 * look.machine));
      for (let k = 0; k < count; k += 1) {
        const origin = hubPicker ? hubPicker(rand, look) : null;
        if (origin) sparks.push({ x: origin[0], z: origin[1], age: 0, amp: (0.9 + 0.6 * rand()) * r * (0.5 + 0.5 * audio.highDrive) * (controls.sparks ?? 1) });
      }
      if (sparks.length > MUSIC_LIMITS.maxSparks) sparks.splice(0, sparks.length - MUSIC_LIMITS.maxSparks);
    }

    // ---- age everything -----------------------------------------------------------------------
    waves = waves.filter((w) => beat - w.birth < w.life && beat - w.birth > -1);
    for (const s of sparks) s.age += dt;
    sparks = sparks.filter((s) => s.age < MUSIC_LIMITS.sparkLifeSeconds);
    impact *= Math.exp(-dt / 0.11);
    strobe *= Math.exp(-dt / 0.09);
    dropFlash *= Math.exp(-dt / 0.55);
    kickLevel *= Math.exp(-dt / 0.25);

    // ---- uniforms --------------------------------------------------------------------------------
    uniforms.waveA.fill(0); uniforms.waveB.fill(0); uniforms.waveC.fill(0); uniforms.spark.fill(0);
    let n = 0;
    for (const w of waves) {
      const age = beat - w.birth;
      if (age < 0) continue;                                 // scheduled for later
      const u = clamp01(age / w.life);
      const travel = w.dir > 0 ? u : u;                      // eased below
      const eased = w.arrive ? Math.min(age / (w.life - 0.45), 1) : Math.pow(travel, 0.8);
      const front = w.startR + (w.endR - w.startR) * eased;
      const fade = w.arrive ? (age < 1.0 ? 1 : Math.exp(-(age - 1.0) * 9)) : Math.exp(-u * (w.role === ROLE.DROP ? 1.4 : 2.4));
      const grow = w.role === ROLE.DROP ? 1 + 0.8 * u : 1 + 0.5 * u;
      const arriveBoost = w.arrive ? 0.55 + 0.45 * eased : 1;
      const o = n * 4;
      uniforms.waveA[o] = w.cx; uniforms.waveA[o + 1] = w.cz; uniforms.waveA[o + 2] = front; uniforms.waveA[o + 3] = w.width * grow;
      uniforms.waveB[o] = w.amp * fade * arriveBoost; uniforms.waveB[o + 1] = w.tail; uniforms.waveB[o + 2] = w.dir; uniforms.waveB[o + 3] = w.role;
      uniforms.waveC[o] = w.colour[0]; uniforms.waveC[o + 1] = w.colour[1]; uniforms.waveC[o + 2] = w.colour[2];
      n += 1;
      if (n >= AC_WAVES) break;
    }
    state.waveCount = n;
    let m = 0;
    for (const s of sparks) {
      const radius = Math.min(MUSIC_LIMITS.sparkMaxRadius, s.age * MUSIC_LIMITS.sparkSpeed);
      const fade = 1 - s.age / MUSIC_LIMITS.sparkLifeSeconds;
      const o = m * 4;
      uniforms.spark[o] = s.x; uniforms.spark[o + 1] = s.z; uniforms.spark[o + 2] = radius; uniforms.spark[o + 3] = s.amp * fade * fade;
      m += 1;
    }
    state.sparkCount = m;

    const drive = (x) => clamp01(x);
    state.bass = drive(audio.subDrive * 0.6 + audio.bassDrive * 0.4) * r;
    state.mids = drive(audio.midDrive) * r;
    state.highs = drive(audio.highDrive) * r;
    state.energy = drive(audio.energyDrive) * r;
    state.strobe = strobe * (0.4 + 0.6 * look.synchrony + 0.4 * audio.build);
    state.dim = look.breath * 0.9;
    state.stageDim = r * clamp01(audio.groove) * (0.45 + 0.55 * clamp01(audio.energyDrive)) * (1 - 0.4 * look.awake);
    state.dropFlash = dropFlash;
    state.impact = impact;
    state.build = audio.build;
    state.beat = beat;
    state.beatPhase = beat - Math.floor(beat);
    state.streamHead = state.beatPhase;
    const groove = clamp01(audio.groove);
    state.streamGain = r * (0.20 + 0.80 * groove) * (0.35 + 0.65 * clamp01(audio.energyDrive + 0.2)) * (1 + 0.6 * impact + 0.4 * dropFlash) * (1 + 0.5 * audio.build);
    state.loopGain = r * (0.12 + 0.55 * state.highs + 0.45 * state.energy) * look.transcendence * (1 + 0.8 * dropFlash);
    state.machine = look.machine; state.organic = look.organic;
    state.direction = inward ? "in" : "out";

    // spectrum -> 16 bands (real analyser bytes when given, else synthesised from the bands)
    const spec = state.spectrum;
    if (spectrum && spectrum.length >= 32) {
      const bins = spectrum.length;
      for (let b = 0; b < 16; b += 1) {
        const lo = Math.floor(Math.pow(bins, b / 16)), hi = Math.max(lo + 1, Math.floor(Math.pow(bins, (b + 1) / 16)));
        let sum = 0;
        for (let i = lo; i < hi && i < bins; i += 1) sum += spectrum[i];
        const level = sum / Math.max(1, hi - lo) / 255;
        spec[b] += (level - spec[b]) * (level > spec[b] ? 0.6 : 0.18);
      }
    } else {
      for (let b = 0; b < 16; b += 1) {
        const x = b / 15;
        const target = clamp01(mix(mix(audio.bass, audio.mids, smoothstep(0.1, 0.5, x)), audio.highs, smoothstep(0.5, 0.95, x)));
        spec[b] += (target - spec[b]) * 0.25;
      }
    }
    uniforms.spec.set(spec);
    uniforms.A.set([state.bass, state.mids, state.highs, state.energy]);
    uniforms.B.set([state.strobe, state.dim, state.dropFlash, state.build]);
    uniforms.C.set([state.beat, state.beatPhase, state.streamHead, state.streamGain]);
    uniforms.D.set([state.machine, state.organic, state.loopGain, impact]);
    state.waves = waves;
    return state;
  }

  const setRegionAngles = (angles) => { if (angles && angles.length >= 6) regionAngles = angles.slice(0, 6); };
  const setHubPicker = (picker) => { hubPicker = picker; };
  return { state, uniforms, step, reset, regionCentre, setRegionAngles, setHubPicker };
}
