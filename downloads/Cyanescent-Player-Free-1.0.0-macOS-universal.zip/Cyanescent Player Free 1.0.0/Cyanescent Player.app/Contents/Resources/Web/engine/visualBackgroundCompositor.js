const backgroundCompositeFragmentSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D frame;
uniform sampler2D backgroundImage;
uniform vec2 resolution;
uniform vec2 sourceResolution;
uniform float backgroundReady;
uniform float sharpenStrength;
uniform float edgeAntialias;

vec3 antialiasedFrame(vec2 uv, vec3 center) {
  if (edgeAntialias < 0.5 || uv.y * sourceResolution.y < 1.5) return center;
  vec2 px=1.0/max(sourceResolution,vec2(1.0));
  vec3 luma=vec3(0.299,0.587,0.114);
  float nw=dot(texture(frame,uv+px*vec2(-1,1)).rgb,luma);
  float ne=dot(texture(frame,uv+px*vec2(1,1)).rgb,luma);
  float sw=dot(texture(frame,uv+px*vec2(-1,-1)).rgb,luma);
  float se=dot(texture(frame,uv+px*vec2(1,-1)).rgb,luma);
  float middle=dot(center,luma);
  float lo=min(middle,min(min(nw,ne),min(sw,se)));
  float hi=max(middle,max(max(nw,ne),max(sw,se)));
  // Only high-contrast edges receive directional filtering. Smooth tissue and
  // low-contrast fibres keep their original samples; no temporal history.
  if(hi-lo<max(0.045,hi*0.16)) return center;
  vec2 direction=vec2(-(nw+ne-sw-se),nw+sw-ne-se);
  float reduction=max((nw+ne+sw+se)*0.03125,0.0078125);
  direction=clamp(direction/(min(abs(direction.x),abs(direction.y))+reduction),vec2(-4),vec2(4))*px;
  vec3 a=0.5*(texture(frame,uv-direction/6.0).rgb+texture(frame,uv+direction/6.0).rgb);
  vec3 b=a*0.5+0.25*(texture(frame,uv-direction*0.5).rgb+texture(frame,uv+direction*0.5).rgb);
  float filtered=dot(b,luma);
  return filtered<lo||filtered>hi?a:b;
}

vec3 sharpenedFrame(vec2 uv) {
  vec3 center = antialiasedFrame(uv, texture(frame, uv).rgb);
  if (sharpenStrength <= 0.001) return center;
  vec2 texel = 1.0 / max(sourceResolution, vec2(1.0));
  vec3 north = texture(frame, uv + vec2(0.0, texel.y)).rgb;
  vec3 south = texture(frame, uv - vec2(0.0, texel.y)).rgb;
  vec3 east = texture(frame, uv + vec2(texel.x, 0.0)).rgb;
  vec3 west = texture(frame, uv - vec2(texel.x, 0.0)).rgb;
  vec3 localMean = (north + south + east + west) * 0.25;
  vec3 localMin = min(center, min(min(north, south), min(east, west)));
  vec3 localMax = max(center, max(max(north, south), max(east, west)));
  float contrast = max(localMax.r - localMin.r, max(localMax.g - localMin.g, localMax.b - localMin.b));
  float adaptive = smoothstep(0.018, 0.20, contrast);
  vec3 detail = clamp(center - localMean, vec3(-0.10), vec3(0.10));
  return clamp(center + detail * sharpenStrength * adaptive, 0.0, 1.0);
}

vec3 presetBackground(vec2 uv) {
  vec2 cover = uv;
  float canvasAspect = resolution.x / max(1.0, resolution.y);
  float imageAspect = 16.0 / 9.0;
  if (canvasAspect > imageAspect) {
    cover.y = (cover.y - 0.5) * (imageAspect / canvasAspect) + 0.5;
  } else {
    cover.x = (cover.x - 0.5) * (canvasAspect / imageAspect) + 0.5;
  }
  vec3 bg = texture(backgroundImage, clamp(cover, vec2(0.0), vec2(1.0))).rgb;
  float r = length((uv * 2.0 - 1.0) * vec2(canvasAspect, 1.0));
  float vignette = smoothstep(1.34, 0.18, r);
  return bg * (0.70 + 0.30 * vignette);
}

void main() {
  vec3 visual = sharpenedFrame(vUv);
  vec3 bg = presetBackground(vUv);
  float visualLuma = max(visual.r, max(visual.g, visual.b));
  float preserveVisual = smoothstep(0.05, 0.42, visualLuma);
  vec3 base = mix(bg * 0.90, bg * 0.60 + visual * 0.92, preserveVisual);
  outColor = vec4(mix(visual, base, backgroundReady), 1.0);
}`;

export function createVisualBackgroundCompositor({
  getGl,
  getCanvas,
  program,
  setAttribs,
  textureAssets,
  fallbackBlit
} = {}) {
  let compositeProgram = null;

  function composite(texture, presetValue, blitProgram, {
    sharpenStrength = 0,
    edgeAntialias = false,
    sourceWidth = 0,
    sourceHeight = 0
  } = {}) {
    const gl = getGl?.();
    const canvas = getCanvas?.();
    const assets = textureAssets?.();
    const backgroundTexture = assets?.ensurePresetBackgroundTexture?.(presetValue);
    const backgroundReady = assets?.presetBackgroundCompositeReady?.(presetValue) || 0;
    if (!gl || !canvas) return;
    if ((!backgroundTexture || backgroundReady <= 0) && sharpenStrength <= 0 && !edgeAntialias) {
      fallbackBlit?.(texture, blitProgram);
      return;
    }

    if (!compositeProgram) compositeProgram = program?.(backgroundCompositeFragmentSource);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, canvas.width, canvas.height);
    setAttribs?.(compositeProgram);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(gl.getUniformLocation(compositeProgram, "frame"), 0);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, backgroundTexture || texture);
    gl.uniform1i(gl.getUniformLocation(compositeProgram, "backgroundImage"), 1);

    gl.uniform2f(gl.getUniformLocation(compositeProgram, "resolution"), canvas.width, canvas.height);
    gl.uniform2f(
      gl.getUniformLocation(compositeProgram, "sourceResolution"),
      Math.max(1, Number(sourceWidth) || canvas.width),
      Math.max(1, Number(sourceHeight) || canvas.height)
    );
    gl.uniform1f(gl.getUniformLocation(compositeProgram, "backgroundReady"), backgroundReady);
    gl.uniform1f(gl.getUniformLocation(compositeProgram, "sharpenStrength"), Math.max(0, sharpenStrength));
    gl.uniform1f(gl.getUniformLocation(compositeProgram, "edgeAntialias"), edgeAntialias ? 1 : 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  return { composite };
}
