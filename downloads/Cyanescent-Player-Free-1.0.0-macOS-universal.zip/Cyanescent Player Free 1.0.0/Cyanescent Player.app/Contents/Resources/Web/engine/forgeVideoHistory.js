// Bounded frame history for short mechanical recoil in metadata-video presets.
// The caller owns GPU frames. Times are unwrapped media times, never wall time.
// No negative playbackRate, repeated seeks, decoder stalls or metadata guesses.
export function createForgeVideoHistory(capacity = 20) {
  const frames = Array.from({ length: capacity }, (_, slot) => ({ slot, time: NaN, valid: false }));
  let head = -1, count = 0;
  function push(time) {
    if (!Number.isFinite(time)) return null;
    if (head >= 0 && Math.abs(frames[head].time - time) < .0001) return null;
    head = (head + 1) % capacity; count = Math.min(count + 1, capacity);
    Object.assign(frames[head], { time, valid: true }); return frames[head];
  }
  function pair(time) {
    if (!count) return null;
    let a = frames[(head - count + 1 + capacity) % capacity], b = a;
    if (time <= a.time) return { a, b, mix: 0, time: a.time };
    for (let k = count - 2; k >= 0; k--) {
      b = frames[(head - k + capacity) % capacity];
      if (time <= b.time) return { a, b, mix: Math.max(0, Math.min(1, (time - a.time) / Math.max(1e-6, b.time - a.time))), time };
      a = b;
    }
    return { a, b: a, mix: 0, time: a.time };
  }
  function clear() { head = -1; count = 0; for (const frame of frames) frame.valid = false; }
  return { frames, push, pair, clear, get count() { return count; }, get newest() { return head >= 0 ? frames[head].time : NaN; } };
}
export function unwrapMediaTime(previous, media, duration) {
  if (!Number.isFinite(previous)) return media;
  const base = Math.floor(previous / duration) * duration;
  let t = base + media;
  if (t - previous < -duration * .5) t += duration;
  if (t - previous > duration * .5) t -= duration;
  return t;
}
export function wrappedMediaTime(time, duration) { return ((time % duration) + duration) % duration; }
export function forgeSourceFrame(time,fps,count) {
  if(!Number.isFinite(time))return -1;
  return ((Math.round(time*fps)%count)+count)%count;
}

// Presentation is driven by musical velocity, not decoder callback cadence.
// The caller keeps a small decoded reservoir ahead. Clamping happens only on
// actual buffer underflow; normal frames advance at precisely rate * dt.
export function createForgePresentationClock(fps, delaySeconds = .07) {
  let cursor = NaN;
  return {
    reset(time = NaN) { cursor = time; },
    get time() { return cursor; },
    step(history, dt, rate, ageSeconds = 0, playing = true) {
      if (!history.count) return null;
      if (!Number.isFinite(cursor)) cursor = history.newest - Math.max(2 / fps, delaySeconds);
      else if (playing) cursor += Math.max(0, dt) * Math.max(0, rate);
      const pair = history.pair(cursor); cursor = pair.time; return pair;
    }
  };
}
