import { createLiveRenderLoopController, renderLiveVisualizerFrame } from "./liveRenderLoop.js";
import { createVisualEngineController } from "./visualEngineController.js";

export function createLiveVisualRuntime({
  requestAnimationFrameFn = requestAnimationFrame,
  isVisualsReady,
  isPlaybackStarting,
  initializeRenderer,
  initializeFallbackRenderer,
  finishBoot,
  revealVisuals,
  setStatus,
  setDiagnostic,
  setErrorText,
  isOfflineExport,
  resize,
  updateAudio,
  updateKnotOrbitPhase,
  updateVisualTransitions,
  updatePresetTransition,
  updateLiveFeedbackStep,
  getActivePreset,
  getTransition,
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  renderShaderOrSpecialTransitionFrame,
  diagnosticsEnabled,
  getTransitionDiagnosticContext,
  getPresetName,
  updatePerformanceMeter,
  onFrameMetrics,
  skipVisuals
}) {
  let visualEngineRuntime = null;

  const liveRenderLoop = createLiveRenderLoopController({
    requestAnimationFrameFn,
    renderFrame: (now) => visualEngineRuntime.render(now),
    isReady: isVisualsReady
  });

  function requestNextVisualFrame() {
    visualEngineRuntime.requestRenderLoop();
  }

  function startVisualRenderLoop() {
    visualEngineRuntime.startRenderLoop();
  }

  visualEngineRuntime = createVisualEngineController({
    isPlaybackStarting,
    initializeRenderer,
    initializeFallbackRenderer,
    finishBoot,
    revealVisuals,
    startRenderLoop: () => liveRenderLoop.start(),
    stopRenderLoop: () => liveRenderLoop.stop(),
    requestRenderLoop: () => liveRenderLoop.requestNextFrame(),
    setStatus,
    setDiagnostic,
    setErrorText,
    renderFrame: (now) => {
      renderLiveVisualizerFrame({
        now,
        isOfflineExport,
        skipVisuals: skipVisuals?.(),
        resize,
        updateAudio,
        updateKnotOrbitPhase,
        updateVisualTransitions,
        updatePresetTransition,
        updateLiveFeedbackStep,
        getActivePreset,
        getTransition,
        isFiddleheadPreset,
        isPineconePreset,
        isQuantumFluidPreset,
        isKleinianCoralCathedralPreset,
        isBloodCellNebulaPreset,
        renderFiddleheadGeometry,
        renderPinecone3D,
        renderQuantumFluid3D,
        renderKleinianCoralCathedral,
        renderBloodCellNebula,
        renderShaderOrSpecialTransitionFrame,
        diagnosticsEnabled,
        getTransitionDiagnosticContext,
        getPresetName,
        updatePerformanceMeter,
        onFrameMetrics,
        requestNextVisualFrame
      });
    }
  });

  return {
    isRenderLoopRunning: () => liveRenderLoop.isRunning(),
    requestNextVisualFrame,
    startVisualRenderLoop,
    initialize: (options = {}) => visualEngineRuntime.initialize(options),
    schedule: (delay = 650, options = {}) => visualEngineRuntime.schedule(delay, options),
    activate: (delay = 0) => visualEngineRuntime.activate(delay),
    prewarm: (delay = 2200) => visualEngineRuntime.prewarm(delay),
    markUserInteraction: () => visualEngineRuntime.markUserInteraction()
  };
}
