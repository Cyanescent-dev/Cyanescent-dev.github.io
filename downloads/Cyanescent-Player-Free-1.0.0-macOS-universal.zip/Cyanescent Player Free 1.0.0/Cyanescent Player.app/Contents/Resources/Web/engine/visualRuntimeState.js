import { clamp01 } from "../utils/math.js";

export function createVisualRuntimeState({
  getAudioFeatures,
  getMusicAwareState,
  getSlowLevel
} = {}) {
  let knotOrbitPhase = 0;
  let knotOrbitPhaseLastAt = 0;
  let knotOrbitEnergySmooth = 0;
  let feedbackStep = 1;
  let lastFeedbackStepAt = 0;
  let wavePhaseAccum = 0;

  function updateKnotOrbitPhase(now) {
    if (!knotOrbitPhaseLastAt) {
      knotOrbitPhaseLastAt = now;
      return;
    }
    const dt = Math.max(0, Math.min(0.05, (now - knotOrbitPhaseLastAt) / 1000));
    knotOrbitPhaseLastAt = now;
    const audioFeatures = getAudioFeatures?.() || {};
    const musicAwareState = getMusicAwareState?.() || {};
    const target = clamp01((audioFeatures.globalEnergy || 0) * 1.20 + (musicAwareState.highEnergy || 0) * 0.35);
    const smoothAmount = 1 - Math.exp(-dt / 2.4);
    knotOrbitEnergySmooth += (target - knotOrbitEnergySmooth) * smoothAmount;
    const rpm = 8.5 * (1 + knotOrbitEnergySmooth);
    knotOrbitPhase = (knotOrbitPhase + dt * Math.PI * 2 * (rpm / 60)) % (Math.PI * 2 * 1000);
  }

  function updateLiveFeedbackStep(now) {
    if (!lastFeedbackStepAt) {
      lastFeedbackStepAt = now;
      feedbackStep = 1.0;
      return;
    }
    const dt = Math.max(0, Math.min(0.1, (now - lastFeedbackStepAt) / 1000));
    lastFeedbackStepAt = now;
    feedbackStep = dt * 60.0;
    wavePhaseAccum += dt * (0.45 + (getSlowLevel?.() || 0) * 1.35);
  }

  function setOfflineState({
    knotOrbitPhase: nextKnotOrbitPhase,
    feedbackStep: nextFeedbackStep,
    wavePhaseAccum: nextWavePhaseAccum
  } = {}) {
    if (Number.isFinite(nextKnotOrbitPhase)) knotOrbitPhase = nextKnotOrbitPhase;
    if (Number.isFinite(nextFeedbackStep)) feedbackStep = nextFeedbackStep;
    if (Number.isFinite(nextWavePhaseAccum)) wavePhaseAccum = nextWavePhaseAccum;
  }

  function resetFeedbackStepTiming() {
    lastFeedbackStepAt = 0;
  }

  return {
    updateKnotOrbitPhase,
    updateLiveFeedbackStep,
    setOfflineState,
    resetFeedbackStepTiming,
    getKnotOrbitPhase: () => knotOrbitPhase,
    getFeedbackStep: () => feedbackStep,
    getWavePhaseAccum: () => wavePhaseAccum
  };
}
