// Fixed authored-speed Forge presentation, reusable by static-world hybrids.
// Owns a small GPU reservoir. Every slot is stamped in its decoder callback;
// callers select metadata from that stamp, never from HTMLVideo.currentTime.
import { createForgeVideoDecoder } from './forgeVideoDecoder.js';
import { createForgeVideoHistory, createForgePresentationClock, unwrapMediaTime,forgeSourceFrame as sourceFrame } from './forgeVideoHistory.js';
export function createForgeFramePresenter({gl,asset,index,copyProgram,setAttribs,startTime=0,onError=console.error}) {
  const history=createForgeVideoHistory(12),clock=createForgePresentationClock(asset.fps);
  clock.reset(startTime);
  let decoder=null,video=null,active=true,callback=0,epoch=0,started=false,lastAt=0,lastStamp=NaN,playPending=false;
  let resumeTime=startTime,armNative=null,nativeEpoch=0,rearmAt=0;
  const stats={uploads:0,uploadMs:0,maxUploadMs:0,loops:0,underflows:0,decoder:'loading',fallback:'',recoveries:0,callbackRearms:0};
  function texture(){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
    for(const [p,v]of[[gl.TEXTURE_MIN_FILTER,gl.LINEAR],[gl.TEXTURE_MAG_FILTER,gl.LINEAR],[gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE],[gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE]])gl.texParameteri(gl.TEXTURE_2D,p,v);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,asset.width,asset.height,0,gl.RGBA,gl.UNSIGNED_BYTE,null);return t;}
  const upload=texture(),slots=history.frames.map(()=>{const tex=texture(),fb=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);
    if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Forge presentation framebuffer incomplete');return {tex,fb};});
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  const videoLocation=gl.getUniformLocation(copyProgram,'uVideo');
  function latch(time,pixels){if(!active||time<resumeTime-.5/asset.fps)return;
    const savedFb=gl.getParameter(gl.FRAMEBUFFER_BINDING),viewport=gl.getParameter(gl.VIEWPORT),at=performance.now();
    const frame=history.push(time);if(!frame)return;
    try {gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,upload);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
      gl.bindFramebuffer(gl.FRAMEBUFFER,slots[frame.slot].fb);gl.viewport(0,0,asset.width,asset.height);gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);
      gl.useProgram(copyProgram);gl.uniform1i(videoLocation,0);setAttribs(copyProgram);gl.drawArrays(gl.TRIANGLES,0,3);
      if(Number.isFinite(lastStamp)&&sourceFrame(time,asset.fps,asset.frames)<sourceFrame(lastStamp,asset.fps,asset.frames))stats.loops++;
      lastStamp=time;stats.uploads++;const ms=performance.now()-at;stats.uploadMs+=ms;stats.maxUploadMs=Math.max(stats.maxUploadMs,ms);lastAt=at;
    }catch(e){onError(e);}finally{gl.bindFramebuffer(gl.FRAMEBUFFER,savedFb);gl.viewport(...viewport);}}
  function recover(e){if(!active)return;
    if(stats.recoveries>=2){onError(e);return;}
    stats.recoveries++;resumeTime=clock.time;epoch++;decoder?.stop();decoder=null;
    history.clear();started=false;clock.reset(resumeTime);start().catch(onError);
  }
  async function start(){const token=epoch;
    try {const d=await createForgeVideoDecoder({url:encodeURI(`${asset.assetRoot}/${asset.video}`),index,
        onFrame:(time,pixels)=>{if(token===epoch)latch(time,pixels);},onError:recover});if(!active||token!==epoch){d.stop();return;}decoder=d;stats.decoder='webcodecs';decoder.seek(resumeTime);decoder.pump(resumeTime,.22);
    }catch(e){if(!active||token!==epoch)return;stats.fallback=String(e.message||e);stats.decoder='html-video';
      video=document.createElement('video');video.muted=true;video.loop=true;video.playsInline=true;video.preload='auto';video.className='forge-hybrid-video';document.body.appendChild(video);
      video.src=encodeURI(`${asset.assetRoot}/${asset.video}`);
      video.addEventListener('loadedmetadata',()=>{if(active){video.currentTime=resumeTime%asset.durationSeconds;video.play().catch(onError);}});
      if(!video.requestVideoFrameCallback){onError(new Error('Verified video frame callbacks unavailable'));return;}
      armNative=()=>{if(!active||!video)return;if(callback)video.cancelVideoFrameCallback(callback);
        const callbackToken=++nativeEpoch;rearmAt=performance.now();stats.callbackRearms++;
        const tick=(_now,info)=>{if(!active||token!==epoch||callbackToken!==nativeEpoch)return;
          latch(unwrapMediaTime(Number.isFinite(lastStamp)?lastStamp:resumeTime,Math.round(info.mediaTime*asset.fps)/asset.fps,asset.durationSeconds),video);callback=video.requestVideoFrameCallback(tick);};
        callback=video.requestVideoFrameCallback(tick);};armNative();video.load();
    }}
  const ready=start();
  function step(dt,playing=true,held=false){if(!active)return null;
    if(decoder)decoder.pump(clock.time,.22);
    if(!started&&history.count>=2)started=true;
    if(video){if(!playing||held)video.pause();else if(video.paused&&!playPending){playPending=true;video.play().catch(onError).finally(()=>{playPending=false;});}}
    if(video?.readyState>=2&&!video.paused&&performance.now()-Math.max(lastAt,rearmAt)>250)armNative?.();
    const previous=clock.time;
    const pair=clock.step(history,dt,1,0,playing&&started&&!held);
    if(!pair)return null;
    if(started&&playing&&!held&&pair.time-previous<dt*.5)stats.underflows++;
    // No camera interpolation: the selected beauty is an exact native 30fps
    // frame, while music and graph packets continue at Player's output cadence.
    const frame=pair.a;
    return {texture:slots[frame.slot].tex,time:frame.time,frame:sourceFrame(frame.time,asset.fps,asset.frames)};
  }
  async function exact(time){await ready;if(!active)throw new Error('Presenter disposed');
    if(decoder){
      let pair=history.pair(time);
      if(!pair||Math.abs(pair.a.time-time)>.5/asset.fps){resumeTime=time;history.clear();clock.reset(time);decoder.seek(time);}
      const deadline=performance.now()+15000;
      while(active){decoder.pump(time,.32);pair=history.pair(time+1e-6);
        if(pair&&Math.abs(pair.a.time-time)<.5/asset.fps)return {texture:slots[pair.a.slot].tex,time:pair.a.time,frame:sourceFrame(pair.a.time,asset.fps,asset.frames)};
        if(performance.now()>deadline)throw new Error('Forge export frame decode timed out');await new Promise(r=>setTimeout(r,5));}
    }else if(video){resumeTime=lastStamp=time;history.clear();video.pause();video.currentTime=time%asset.durationSeconds;
      const deadline=performance.now()+15000;
      while(active){const pair=history.pair(time+1e-6);if(pair&&Math.abs(pair.a.time-time)<.5/asset.fps)return {texture:slots[pair.a.slot].tex,time:pair.a.time,frame:sourceFrame(pair.a.time,asset.fps,asset.frames)};
        if(performance.now()>deadline)throw new Error('Forge export frame presentation timed out');await new Promise(r=>setTimeout(r,5));}
    }
    throw new Error('Forge frame decoder unavailable');
  }
  return {step,exact,ready,stats,getVideo:()=>video,get decoderStats(){return decoder?.stats();},
    get lastCallbackAge(){return performance.now()-lastAt;},
    stop(){if(!active)return;active=false;epoch++;decoder?.stop();decoder=null;
      if(callback)video?.cancelVideoFrameCallback?.(callback);video?.pause();video?.removeAttribute('src');video?.load();video?.remove();video=null;
      for(const s of slots){gl.deleteFramebuffer(s.fb);gl.deleteTexture(s.tex);}gl.deleteTexture(upload);history.clear();}};
}
