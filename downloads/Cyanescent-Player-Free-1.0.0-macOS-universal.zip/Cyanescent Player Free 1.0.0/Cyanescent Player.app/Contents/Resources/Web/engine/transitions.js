import { enforceTransitionCapabilities } from "../config/runtimeCapabilities.js";
import { nextTransitionDiagnosticId } from "./transitionDiagnostics.js";

export const RenderMode = Object.freeze({
  LIVE: "live",
  OFFLINE_EXPORT: "offlineExport"
});

export const VisualTransitionMode = Object.freeze({
  STATIC: "static",
  SHUFFLE: "shuffle",
  ADAPTIVE: "adaptive"
});

export const MusicRole = Object.freeze({
  CALM: 0,
  BUILD: 1,
  DROP: 2,
  HIGH: 3,
  BREAKDOWN: 4,
  WIND_DOWN: 5,
  SHIFT: 6
});

export const TransitionEnergyStyle = Object.freeze({
  STEADY: 0,
  RISING: 1,
  FALLING: 2
});

export const MusicalEventType = Object.freeze({
  BUILD_UP: "buildUp",
  DROP: "drop",
  BREAKDOWN: "breakdown",
  CALM_SECTION: "calmSection",
  HIGH_ENERGY: "highEnergySection",
  SECTION_CHANGE: "sectionChange"
});

export function transitionDurationForStyle(style) {
  if (style === TransitionEnergyStyle.RISING) return 2600;
  if (style === TransitionEnergyStyle.FALLING) return 12000;
  return 12000;
}

export function transitionSwapPointForStyle(style) {
  if (style === TransitionEnergyStyle.RISING) return 0.82;
  if (style === TransitionEnergyStyle.FALLING) return 0.62;
  return 0.50;
}

export function createPresetTransitionState({
  from,
  to,
  now,
  source = "manual",
  style = 0,
  duration = 2600,
  swapAt = 0.48,
  seed = Math.random(),
  videoTransitionId = "",
  forceVideoTransition = false,
  suppressVideoTransition = false,
  suppressShaderTransition = false,
  useVideoTransitions
}) {
  return enforceTransitionCapabilities({
    diagnosticId: nextTransitionDiagnosticId(),
    active: true,
    from,
    to,
    start: now,
    duration,
    swapped: false,
    swapAt,
    seed,
    source,
    style,
    videoTransitionId,
    forceVideoTransition,
    suppressVideoTransition,
    suppressShaderTransition,
    // Pin the implementation when scheduled, including across output documents.
    useVideoTransitions
  });
}

export function createInactivePresetTransition(preset, seed = Math.random()) {
  return {
    active: false,
    from: preset,
    to: preset,
    start: 0,
    duration: 2600,
    swapped: false,
    swapAt: 0.5,
    seed,
    style: 0
  };
}

export function presetTransitionProgress(transition, now, swapPhase = 0.48) {
  if (!transition?.active) {
    return { phase: 0, shouldSwap: false, complete: false };
  }
  const duration = Math.max(1, transition.duration || 2600);
  const phase = Math.min(1, Math.max(0, (now - transition.start) / duration));
  return {
    phase,
    shouldSwap: !transition.swapped && phase >= swapPhase,
    complete: phase >= 1
  };
}

export function parseEnergyLevel(label) {
  const match = String(label || "").match(/Energy\s*([1-5])|E([1-5])/i);
  if (!match) return 0;
  return Number(match[1] || match[2] || 0) || 0;
}
