// Newtons Law: runtime-field package layout and the pure helpers shared by the WebGL runtime,
// the compiler (scripts/newton-law-runtime-lib.mjs) and tools/test-newton-law.mjs. No DOM or
// WebGL here.
//
// The container, the streaming field store and the clock / camera / morph rules are Newton Basin
// Descent's (newtonBasinField.js), reused unchanged: one media-time clock, categorical data
// nearest-sampled, samples reprojected to the current camera.
export {
  parseSegment, readSample, interleaveSample, sampleTimes, locateSample, classifyTimeStep, loopFade,
  cameraAt, morphAt, motionAt, morphWeights, createFieldStore, halfBitsToFloat
} from "./newtonBasinField.js";
import { halfBitsToFloat } from "./newtonBasinField.js";

// Eight planar bytes per texel. The runtime interleaves them into two RGBA8 images:
//   A = flags, filament, proximity, orbitDepth      B = depthLo, depthHi, octX, octZ
export const LAW_PLANES = Object.freeze(["flags", "filament", "proximity", "orbitDepth", "depthLo", "depthHi", "octX", "octZ"]);

// Smooth planes are stored as differences along each row (like PNG's Sub filter), which roughly
// halves what zlib has to store for depth and normals. Depth is differenced as one 16-bit value.
export const LAW_FILTER = Object.freeze({
  name: "row-delta-v1",
  bytePlanes: Object.freeze(["filament", "proximity", "orbitDepth", "octX", "octZ"]),
  wordPlane: Object.freeze(["depthLo", "depthHi"])
});

function planeIndices() {
  return {
    bytes: LAW_FILTER.bytePlanes.map((name) => LAW_PLANES.indexOf(name)),
    lo: LAW_PLANES.indexOf(LAW_FILTER.wordPlane[0]), hi: LAW_PLANES.indexOf(LAW_FILTER.wordPlane[1])
  };
}

// In place: raw planar sample -> row differences (compiler side).
export function filterRows(payload, width, height) {
  const count = width * height, { bytes, lo, hi } = planeIndices();
  for (const k of bytes) {
    const base = k * count;
    for (let y = 0; y < height; y += 1) {
      const row = base + y * width;
      for (let x = width - 1; x > 0; x -= 1) payload[row + x] = (payload[row + x] - payload[row + x - 1]) & 255;
    }
  }
  for (let y = 0; y < height; y += 1) {
    const row = y * width;
    for (let x = width - 1; x > 0; x -= 1) {
      const i = row + x;
      const a = payload[lo * count + i] | (payload[hi * count + i] << 8);
      const b = payload[lo * count + i - 1] | (payload[hi * count + i - 1] << 8);
      const d = (a - b) & 0xffff;
      payload[lo * count + i] = d & 255; payload[hi * count + i] = d >> 8;
    }
  }
  return payload;
}

// In place: row differences -> planar sample (runtime side; a prefix sum per row).
export function unfilterRows(payload, width, height) {
  const count = width * height, { bytes, lo, hi } = planeIndices();
  for (const k of bytes) {
    const base = k * count;
    for (let y = 0; y < height; y += 1) {
      const row = base + y * width;
      for (let x = 1; x < width; x += 1) payload[row + x] = (payload[row + x] + payload[row + x - 1]) & 255;
    }
  }
  for (let y = 0; y < height; y += 1) {
    const row = y * width;
    for (let x = 1; x < width; x += 1) {
      const i = row + x;
      const d = payload[lo * count + i] | (payload[hi * count + i] << 8);
      const b = payload[lo * count + i - 1] | (payload[hi * count + i - 1] << 8);
      const a = (b + d) & 0xffff;
      payload[lo * count + i] = a & 255; payload[hi * count + i] = a >> 8;
    }
  }
  return payload;
}

// CPU reference decode of one texel from the two interleaved images (the shaders mirror it).
export function decodeLawTexel(imageA, imageB, width, x, y) {
  const o = (y * width + x) * 4;
  const flags = imageA[o];
  const hit = (flags >> 3) & 1;
  const f = imageA[o + 1] / 255;
  let nx = imageB[o + 2] / 255 * 2 - 1, nz = imageB[o + 3] / 255 * 2 - 1;
  let ny = 1 - Math.abs(nx) - Math.abs(nz);
  if (ny < 0) { const ox = nx, oz = nz; nx = (1 - Math.abs(oz)) * (ox >= 0 ? 1 : -1); nz = (1 - Math.abs(ox)) * (oz >= 0 ? 1 : -1); }
  const length = Math.hypot(nx, ny, nz) || 1;
  return {
    region: flags & 7, hit,
    filament: f * f, proximity: imageA[o + 2] / 255, orbitDepth: imageA[o + 3] / 255,
    depth: hit ? halfBitsToFloat(imageB[o] | (imageB[o + 1] << 8)) : 0,
    normal: [nx / length, ny / length, nz / length]
  };
}

// Where a complex-plane point sits in the world for timeline sample i (inverse plane mapping).
export function planeToWorldAt(timeline, i, p) {
  const cx = timeline.plane[i * 4], cy = timeline.plane[i * 4 + 1], s = timeline.plane[i * 4 + 2], rotation = timeline.plane[i * 4 + 3];
  const dx = (p[0] - cx) / s, dy = (p[1] - cy) / s;
  const c = Math.cos(-rotation), sn = Math.sin(-rotation);
  return [dx * c - dy * sn, dx * sn + dy * c];
}

// ------------------------------------------------------------- landmarks
// Layout of landmarks.bin (see scripts/newton-law-runtime-lib.mjs findLandmarks): per sample, a
// count byte and up to 8 records of 20 bytes.
export const LANDMARK_LIMIT = 8;
export const LANDMARK_RECORD_BYTES = 20;
export const LANDMARK_SAMPLE_BYTES = 1 + LANDMARK_LIMIT * LANDMARK_RECORD_BYTES;
export const LANDMARK_KIND_NAMES = Object.freeze(["lake", "well", "ring"]);

export function parseLandmarks(bytes, sample) {
  const base = sample * LANDMARK_SAMPLE_BYTES;
  if (!bytes || base + LANDMARK_SAMPLE_BYTES > bytes.length) return [];
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const count = Math.min(LANDMARK_LIMIT, bytes[base]);
  const list = [];
  for (let slot = 0; slot < count; slot += 1) {
    const at = base + 1 + slot * LANDMARK_RECORD_BYTES;
    list.push({
      id: view.getUint16(at, true), kind: bytes[at + 2], region: bytes[at + 3],
      u: view.getUint16(at + 4, true) / 65535, v: view.getUint16(at + 6, true) / 65535,
      position: [halfBitsToFloat(view.getUint16(at + 8, true)), halfBitsToFloat(view.getUint16(at + 10, true)), halfBitsToFloat(view.getUint16(at + 12, true))],
      radius: halfBitsToFloat(view.getUint16(at + 14, true)), salience: halfBitsToFloat(view.getUint16(at + 16, true))
    });
  }
  return list;
}

// Blend two neighbouring samples' landmarks by id. A landmark present in only one sample fades
// (its salience scales with how close that sample is), so nothing pops.
export function interpolateLandmarks(list0, list1, mix) {
  const byId = new Map(list1.map((landmark) => [landmark.id, landmark]));
  const out = [];
  for (const a of list0) {
    const b = byId.get(a.id);
    if (b) {
      byId.delete(a.id);
      out.push({
        ...a, u: a.u + (b.u - a.u) * mix, v: a.v + (b.v - a.v) * mix,
        position: a.position.map((value, k) => value + (b.position[k] - value) * mix),
        radius: a.radius + (b.radius - a.radius) * mix, salience: a.salience + (b.salience - a.salience) * mix
      });
    } else out.push({ ...a, salience: a.salience * (1 - mix) });
  }
  for (const b of byId.values()) out.push({ ...b, salience: b.salience * mix });
  return out;
}
