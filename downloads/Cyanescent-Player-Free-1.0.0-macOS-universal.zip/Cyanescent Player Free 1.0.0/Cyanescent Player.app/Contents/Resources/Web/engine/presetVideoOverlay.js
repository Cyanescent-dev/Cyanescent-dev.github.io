// A single-video, radially-masked foreground overlay for a preset's "hero"
// video (e.g. Phase Space Reef's clam). This is deliberately not the same
// system as videoBackgroundManager.js: that one crossfades full-bleed clips
// behind the canvas (z-index 0); this one plays one clip above the canvas
// (z-index 2, see .preset-video-overlay in styles.css) with a CSS radial
// mask so the procedural background stays visible around the edges.
//
// Playback is a deliberate cycle rather than a loop: fade in, play the clip
// once from the start, fade out before/at its natural end, pause for a few
// seconds with only the background running, then restart. `update()` is
// expected to be called once per rendered frame (mirroring
// videoBackgroundManager's update() convention) so the cycle advances in
// lockstep with the render loop instead of drifting on its own timers.

const STAGE = Object.freeze({
  IDLE: "idle",
  // Source is (re)loading/seeking and has no visible frame yet — the CSS
  // opacity fade must not be running against a blank element, so this is
  // distinct from FADE_IN, which only starts once a frame is confirmed.
  LOADING: "loading",
  FADE_IN: "fade-in",
  PLAYING: "playing",
  FADE_OUT: "fade-out",
  PAUSED: "paused"
});

function configureVideoElement(video) {
  if (!video) return;
  video.muted = true;
  video.playsInline = true;
  video.controls = false;
  video.loop = false;
  video.preload = "auto";
}

export function createPresetVideoOverlay({
  video,
  source,
  fadeMs = 2200,
  pauseMs = 4000,
  logger = console,
  now = () => performance.now()
} = {}) {
  configureVideoElement(video);

  let active = false;
  let stage = STAGE.IDLE;
  let stageStartedAt = 0;
  let sourceLoaded = false;
  let pendingReveal = null; // { event, handler } — the listener awaiting a real frame

  function loadSourceIfNeeded() {
    if (!video || sourceLoaded || !source) return;
    video.src = source;
    video.load();
    sourceLoaded = true;
  }

  function clearPendingReveal() {
    if (!pendingReveal || !video) return;
    video.removeEventListener(pendingReveal.event, pendingReveal.handler);
    pendingReveal = null;
  }

  function reveal() {
    if (!active || stage !== STAGE.LOADING) return;
    stage = STAGE.FADE_IN;
    stageStartedAt = now();
    video.classList.add("active");
  }

  async function beginPlaybackCycle() {
    if (!video) return;
    clearPendingReveal();
    const firstLoad = !sourceLoaded;
    loadSourceIfNeeded();
    stage = STAGE.LOADING;
    stageStartedAt = now();
    // Don't add the "active" class (which starts the CSS opacity fade)
    // until there's an actual decoded frame behind it — otherwise the
    // 2200ms fade plays out against a blank element while the (large,
    // freshly-(re)loaded) video is still buffering, and by the time a real
    // frame appears the element is already at full opacity: a hard pop
    // instead of a fade. "loadeddata" fires once real decoded data exists
    // after a fresh load; "seeked" fires once a seek (our restart-from-0)
    // has actually landed on a frame.
    const eventName = firstLoad ? "loadeddata" : "seeked";
    const handler = () => {
      pendingReveal = null;
      reveal();
    };
    pendingReveal = { event: eventName, handler };
    video.addEventListener(eventName, handler, { once: true });
    try {
      video.currentTime = 0;
    } catch {
      // Metadata not loaded yet — the browser clamps to 0 on its own once
      // the source is ready, so this is safe to ignore.
    }
    try {
      await video.play();
    } catch (error) {
      logger.warn?.("Phase Space Reef clam overlay failed to play:", error);
    }
  }

  function start() {
    if (active) return;
    active = true;
    beginPlaybackCycle();
  }

  function stop() {
    if (!active) return;
    active = false;
    stage = STAGE.IDLE;
    clearPendingReveal();
    video?.classList.remove("active");
    if (video) {
      try { video.pause(); } catch {}
    }
  }

  function update() {
    if (!active || !video) return;
    // FADE_OUT/PAUSED intentionally pause the element; LOADING/FADE_IN/
    // PLAYING should always be playing. If the browser paused it out from
    // under us (autoplay-policy hiccups, a backgrounded window regaining
    // focus) the fade/loop timing below is still tracking wall-clock time
    // against the assumption that video.currentTime is advancing, so retry
    // play() rather than silently drifting out of sync with the actual
    // frame.
    if (video.paused && (stage === STAGE.LOADING || stage === STAGE.FADE_IN || stage === STAGE.PLAYING)) {
      video.play().catch(() => {});
    }
    const elapsed = now() - stageStartedAt;
    switch (stage) {
      case STAGE.LOADING:
        // Waiting on the "loadeddata"/"seeked" listener in
        // beginPlaybackCycle() to call reveal(); nothing to advance here.
        break;
      case STAGE.FADE_IN:
        if (elapsed >= fadeMs) {
          stage = STAGE.PLAYING;
          stageStartedAt = now();
        }
        break;
      case STAGE.PLAYING: {
        const duration = Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 0;
        if (duration && video.currentTime >= duration - fadeMs / 1000) {
          stage = STAGE.FADE_OUT;
          stageStartedAt = now();
          video.classList.remove("active");
        }
        break;
      }
      case STAGE.FADE_OUT:
        if (elapsed >= fadeMs) {
          try { video.pause(); } catch {}
          stage = STAGE.PAUSED;
          stageStartedAt = now();
        }
        break;
      case STAGE.PAUSED:
        if (elapsed >= pauseMs) {
          beginPlaybackCycle();
        }
        break;
      default:
        break;
    }
  }

  return {
    start,
    stop,
    update,
    isActive: () => active
  };
}
