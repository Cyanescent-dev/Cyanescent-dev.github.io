import { capabilityEnabled } from "../config/runtimeCapabilities.js";
// Alien Visits: rare, semi-transparent video intrusions composited over the
// running preset. The point is that the underlying visual never stops and is
// never replaced -- this is not a preset change and not a video mode. One
// <video> element sits above the canvas (z-index 3, see .alien-visit-overlay
// in styles.css) and is faded to ~80% for the length of one 8 s clip, so the
// preset keeps rendering and bleeds through the footage the whole time.
//
// Structured after presetVideoOverlay.js: update() is called once per rendered
// frame from the render loop rather than driven by its own timers, so the
// schedule advances in lockstep with the visuals and stops dead when they do.
//
// Opacity is animated here in JS rather than by a CSS transition because the
// brief calls for a specific non-linear shape -- a fast intrusion that settles,
// not an even crossfade -- and a CSS transition can only ease between two
// endpoints.

const SESSION_MS = 2 * 60 * 60 * 1000;    // one 2-hour visual session
const MIN_GAP_MS = 6 * 60 * 1000;
const MAX_GAP_MS = 16 * 60 * 1000;
const SLOT_JITTER = 0.38;                 // of one nominal slot, each way
const FIRST_SLOT_BIAS = 0.55;             // keeps the first visit off t=0

// Once a visit is due it waits for something to happen in the music. This is a
// preference, not a requirement: after the timeout it fires anyway, so a quiet
// ambient passage cannot swallow an encounter.
const MUSICAL_WAIT_MS = 45 * 1000;
const MUSICAL_SCORE_THRESHOLD = 0.75;

// How long a visit keeps automatic preset transitions held off after it has
// faded out, so a transition never treads on the tail of an encounter.
const POST_VISIT_HOLD_MS = 2000;

const WARMUP_LEAD_MS = 20 * 1000;         // start buffering this far ahead
const LOAD_TIMEOUT_MS = 6000;
const RE_ENABLE_LEAD_MS = 60 * 1000;      // re-enabling never fires instantly

const FADE_IN_MS = 1000;
const FADE_OUT_MS = 1000;
const PEAK_OPACITY = 0.8;
const FALLBACK_DURATION_MS = 8000;

// Fast in, then settle: 0 -> 30% -> 65% -> 80%. Reaching two thirds of the way
// inside the first 38% of the fade is what makes it read as an intrusion.
const FADE_IN_CURVE = Object.freeze([[0, 0], [0.15, 0.3], [0.38, 0.65], [1, PEAK_OPACITY]]);
// And back out, front-loaded the same way: 80% -> 40% -> 10% -> 0.
const FADE_OUT_CURVE = Object.freeze([[0, PEAK_OPACITY], [0.3, 0.4], [0.62, 0.1], [1, 0]]);

const STAGE = Object.freeze({
  IDLE: "idle",
  ARMED: "armed",       // due, waiting for a musical moment
  LOADING: "loading",   // playing but no decoded frame yet, still invisible
  FADE_IN: "fade-in",
  HOLD: "hold",
  FADE_OUT: "fade-out"
});

function smoothstep(t) {
  const x = Math.max(0, Math.min(1, t));
  return x * x * (3 - 2 * x);
}

// Piecewise interpolation through the keyframes above, eased between each pair
// so the joins are not visible as kinks in the fade.
function curveAt(curve, t) {
  const x = Math.max(0, Math.min(1, t));
  for (let i = 1; i < curve.length; i += 1) {
    const [t0, v0] = curve[i - 1];
    const [t1, v1] = curve[i];
    if (x <= t1) {
      const span = t1 - t0;
      const local = span > 0 ? (x - t0) / span : 1;
      return v0 + (v1 - v0) * smoothstep(local);
    }
  }
  return curve[curve.length - 1][1];
}

function shuffled(items, random) {
  const pool = [...items];
  for (let i = pool.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool;
}

// Randomised but evenly spread: each visit gets its own slot in the window and
// jitters inside it, then gaps are clamped into [MIN_GAP, MAX_GAP]. Drawing
// gaps independently instead would let early clustering eat the window and
// strand the last few clips.
function buildSchedule(count, random) {
  if (count <= 0) return [];
  const slot = SESSION_MS / count;
  const jitter = slot * SLOT_JITTER;
  const times = [];
  for (let i = 0; i < count; i += 1) {
    const nominal = (i + FIRST_SLOT_BIAS) * slot;
    let time = nominal + (random() * 2 - 1) * jitter;
    if (i > 0) {
      time = Math.max(time, times[i - 1] + MIN_GAP_MS);
      time = Math.min(time, times[i - 1] + MAX_GAP_MS);
    } else {
      time = Math.max(time, MIN_GAP_MS * 0.25);
    }
    // Leave room for the clip itself to finish inside the session.
    time = Math.min(time, SESSION_MS - FALLBACK_DURATION_MS * 2);
    times.push(time);
  }
  return times;
}

// Reuses the existing analysis rather than adding any of its own. Anything the
// audience would register as an event -- a drop, a section change, a phrase
// boundary, a rising edge -- is a good moment for reality to break.
function musicalMomentScore(music, features) {
  const drop = Math.max(Number(music?.drop) || 0, Number(features?.dropDetected) || 0);
  const section = Number(music?.sectionChange) || 0;
  const phrase = Number(music?.phrasePulse) || 0;
  const build = Number(music?.buildUp) || 0;
  const trend = Number(music?.energyTrend);
  const rising = Number.isFinite(trend) ? Math.max(0, trend - 0.5) * 2 : 0;
  const kick = Number(features?.kickPulse) || 0;
  return drop * 1.0
    + section * 0.8
    + phrase * 0.85
    + build * 0.45
    + rising * 0.6
    + kick * 0.25;
}

function configureVideoElement(video) {
  if (!video) return;
  video.muted = true;
  video.playsInline = true;
  video.controls = false;
  video.loop = false;
  video.preload = "auto";
}

export function createAlienVisitDirector({
  video,
  sources = [],
  isEnabled = () => true,
  isSessionActive = () => true,
  // Whether the visualiser is somewhere an encounter can sensibly land: well
  // inside a rendered preset, not over a transition, and not over a preset
  // that is itself video. Supplied by the app so this module does not need to
  // know anything about presets or transitions.
  isSceneSafe = () => true,
  // Narrower than isSceneSafe, and deliberately so: this is the only thing
  // allowed to cut an encounter short, so it must not include the settle or
  // clearance timers -- those can legitimately flip mid-visit and would abort
  // a perfectly good encounter.
  isTransitionActive = () => false,
  getMusicAwareState = () => null,
  getAudioFeatures = () => null,
  logger = console,
  now = () => performance.now(),
  random = Math.random
} = {}) {
  configureVideoElement(video);

  const library = sources.filter(Boolean);
  let pool = [];
  let poolIndex = 0;
  let schedule = [];
  let scheduleIndex = 0;
  let sessionElapsed = 0;
  let lastTick = null;
  let stage = STAGE.IDLE;
  let stageStartedAt = 0;
  let armedAt = 0;
  let visitStartedAt = 0;
  let visitDurationMs = FALLBACK_DURATION_MS;
  let warmedSource = "";
  let pendingReveal = null;
  // Deliberately not seeded from isEnabled(): the director is constructed
  // before the options controller exists, so the setting is read per frame in
  // update() instead. That also makes the option the single source of truth,
  // rather than something that can drift from the toggle.
  let enabled = capabilityEnabled("alienVisits");
  let visitCount = 0;
  let holdTransitionsUntil = 0;
  let earlyFadeFrom = null;

  function resetSession() {
    pool = shuffled(library, random);
    poolIndex = 0;
    schedule = buildSchedule(pool.length, random);
    scheduleIndex = 0;
    sessionElapsed = 0;
  }

  resetSession();

  function setOpacity(value) {
    if (!video) return;
    video.style.opacity = String(Math.max(0, Math.min(1, value)));
  }

  function clearPendingReveal() {
    if (!pendingReveal || !video) return;
    video.removeEventListener(pendingReveal.event, pendingReveal.handler);
    pendingReveal = null;
  }

  // Drop the buffered clip as soon as it has played. Holding twelve 1080p
  // sources open would be pointless: only one plays at a time and the next is
  // not due for several minutes.
  function releaseVideo() {
    clearPendingReveal();
    if (!video) return;
    setOpacity(0);
    try { video.pause(); } catch {}
    video.removeAttribute("src");
    try { video.load(); } catch {}
    warmedSource = "";
  }

  function warmSource(source) {
    if (!video || !source || warmedSource === source) return;
    warmedSource = source;
    video.src = encodeURI(source);
    try { video.load(); } catch {}
  }

  function currentSource() {
    return pool[poolIndex] || "";
  }

  function abortVisit(reason) {
    logger.warn?.(`Alien visit aborted (${reason})`);
    releaseVideo();
    stage = STAGE.IDLE;
    // The clip keeps its place in the pool so the session still shows all of
    // them; only the schedule slot is spent.
    scheduleIndex += 1;
  }

  async function beginVisit(nowMs) {
    const source = currentSource();
    if (!video || !source) {
      abortVisit("no source");
      return;
    }
    warmSource(source);
    stage = STAGE.LOADING;
    stageStartedAt = nowMs;
    earlyFadeFrom = null;
    setOpacity(0);
    // Do not start the fade against a blank element: wait for a decoded frame,
    // otherwise the intrusion lands as a pop once buffering catches up.
    const handler = () => {
      pendingReveal = null;
      if (stage !== STAGE.LOADING) return;
      stage = STAGE.FADE_IN;
      stageStartedAt = now();
      visitStartedAt = stageStartedAt;
      const duration = Number(video.duration);
      visitDurationMs = Number.isFinite(duration) && duration > 0
        ? duration * 1000
        : FALLBACK_DURATION_MS;
    };
    pendingReveal = { event: "loadeddata", handler };
    video.addEventListener("loadeddata", handler, { once: true });
    if (video.readyState >= 2) handler();
    try { video.currentTime = 0; } catch {}
    try {
      await video.play();
    } catch (error) {
      logger.warn?.("Alien visit failed to play:", error);
    }
  }

  function finishVisit() {
    earlyFadeFrom = null;
    releaseVideo();
    stage = STAGE.IDLE;
    poolIndex += 1;
    scheduleIndex += 1;
    visitCount += 1;
  }

  function visitInProgress() {
    return stage === STAGE.LOADING
      || stage === STAGE.FADE_IN
      || stage === STAGE.HOLD
      || stage === STAGE.FADE_OUT;
  }

  function advanceVisit(nowMs) {
    if (!video) return;
    // The element should be playing throughout; if the browser paused it out
    // from under us the fade timing would keep running against a frozen frame.
    if (video.paused && stage !== STAGE.IDLE && stage !== STAGE.ARMED) {
      video.play().catch(() => {});
    }
    // A transition can only reach here via a manual preset change: automatic
    // ones are held off for the duration. Bail out rather than riding over the
    // crossfade, which is what looked broken.
    if (isTransitionActive() && stage === STAGE.LOADING) {
      // Nothing is on screen yet, so there is nothing to fade -- drop it and
      // keep the clip in the pool for its next slot.
      abortVisit("transition started during load");
      return;
    }
    if (isTransitionActive() && (stage === STAGE.FADE_IN || stage === STAGE.HOLD)) {
      // Carry the current opacity into the fade-out so it steps down from
      // where it actually is instead of jumping back up to the hold value.
      const from = Number(video.style.opacity) || 0;
      earlyFadeFrom = Math.min(from, PEAK_OPACITY);
      stage = STAGE.FADE_OUT;
      stageStartedAt = nowMs;
    }
    const stageElapsed = nowMs - stageStartedAt;
    switch (stage) {
      case STAGE.LOADING:
        if (stageElapsed >= LOAD_TIMEOUT_MS) abortVisit("load timeout");
        break;
      case STAGE.FADE_IN:
        setOpacity(curveAt(FADE_IN_CURVE, stageElapsed / FADE_IN_MS));
        if (stageElapsed >= FADE_IN_MS) {
          setOpacity(PEAK_OPACITY);
          stage = STAGE.HOLD;
          stageStartedAt = nowMs;
        }
        break;
      case STAGE.HOLD: {
        setOpacity(PEAK_OPACITY);
        const sinceStart = nowMs - visitStartedAt;
        if (sinceStart >= Math.max(FADE_IN_MS, visitDurationMs - FADE_OUT_MS)) {
          stage = STAGE.FADE_OUT;
          stageStartedAt = nowMs;
        }
        break;
      }
      case STAGE.FADE_OUT: {
        const shaped = curveAt(FADE_OUT_CURVE, stageElapsed / FADE_OUT_MS);
        // An early bail scales the curve to wherever the fade-in had reached.
        setOpacity(earlyFadeFrom === null ? shaped : shaped * (earlyFadeFrom / PEAK_OPACITY));
        if (stageElapsed >= FADE_OUT_MS) finishVisit();
        break;
      }
      default:
        break;
    }
  }

  function update(nowMs = now()) {
    if (!video) return;
    syncEnabledFromOptions();
    const previous = lastTick;
    lastTick = nowMs;

    // A visit already under way always runs to completion, including when the
    // feature is switched off mid-encounter -- it fades out cleanly instead of
    // being cut.
    if (visitInProgress()) {
      holdTransitionsUntil = nowMs + POST_VISIT_HOLD_MS;
      advanceVisit(nowMs);
      return;
    }

    if (!enabled || !library.length) return;

    // The session clock only runs while the visuals are actually running, so a
    // paused set does not silently burn encounters.
    if (!isSessionActive()) return;
    const delta = previous === null ? 0 : Math.max(0, Math.min(250, nowMs - previous));
    sessionElapsed += delta;

    if (sessionElapsed >= SESSION_MS) {
      resetSession();
      return;
    }
    if (scheduleIndex >= schedule.length) return;

    const dueAt = schedule[scheduleIndex];

    if (stage === STAGE.ARMED) {
      // Scene safety is a hard gate. MUSICAL_WAIT_MS only waives the
      // preference for a musical moment; it never lets an encounter land on a
      // transition or on a video-backed preset. If the scene stays unsafe the
      // visit simply waits -- its slot slips rather than firing somewhere it
      // would look broken.
      if (!isSceneSafe()) return;
      const waited = nowMs - armedAt;
      const score = musicalMomentScore(getMusicAwareState(), getAudioFeatures());
      if (score >= MUSICAL_SCORE_THRESHOLD || waited >= MUSICAL_WAIT_MS) beginVisit(nowMs);
      return;
    }

    if (sessionElapsed >= dueAt) {
      stage = STAGE.ARMED;
      armedAt = nowMs;
      warmSource(currentSource());
      return;
    }

    if (sessionElapsed >= dueAt - WARMUP_LEAD_MS) warmSource(currentSource());
  }

  function syncEnabledFromOptions() {
    let live = enabled;
    try {
      live = capabilityEnabled("alienVisits") && Boolean(isEnabled());
    } catch {
      // Options not constructed yet; keep the current state.
      return;
    }
    if (live !== enabled) setEnabled(live);
  }

  function setEnabled(value) {
    const next = capabilityEnabled("alienVisits") && Boolean(value);
    if (next === enabled) return;
    enabled = next;
    if (!enabled) {
      // A visit in flight is left alone; update() keeps advancing it to its
      // fade-out. Anything not yet visible is torn down now.
      if (stage === STAGE.ARMED) stage = STAGE.IDLE;
      if (!visitInProgress()) releaseVideo();
      return;
    }
    // Turning the feature back on must not read as "pressing this plays a
    // video": push anything already due out past a lead-in.
    const lead = sessionElapsed + RE_ENABLE_LEAD_MS;
    for (let i = scheduleIndex; i < schedule.length; i += 1) {
      if (schedule[i] < lead) schedule[i] = lead + (i - scheduleIndex) * MIN_GAP_MS;
    }
  }

  function stop() {
    releaseVideo();
    stage = STAGE.IDLE;
  }

  return {
    update,
    setEnabled,
    stop,
    isVisiting: visitInProgress,
    // True while an encounter is visible and for a short tail afterwards. The
    // transition controller checks this so an automatic preset change can
    // never start on top of a visit -- which is what makes the scene gate
    // above sufficient rather than merely likely to work.
    isHoldingTransitions: () => visitInProgress() || now() < holdTransitionsUntil,
    // Exposed for the harness and for diagnostics; not used by the renderer.
    debugState: () => ({
      enabled,
      stage,
      librarySize: library.length,
      poolIndex,
      scheduleIndex,
      visitCount,
      sessionElapsedMs: sessionElapsed,
      sceneSafe: (() => { try { return Boolean(isSceneSafe()); } catch { return false; } })(),
      scheduleMs: [...schedule],
      pool: [...pool]
    })
  };
}

export const __alienVisitInternals = Object.freeze({
  SESSION_MS,
  MIN_GAP_MS,
  MAX_GAP_MS,
  PEAK_OPACITY,
  POST_VISIT_HOLD_MS,
  FADE_IN_MS,
  FADE_OUT_MS,
  FADE_IN_CURVE,
  FADE_OUT_CURVE,
  buildSchedule,
  shuffled,
  curveAt,
  musicalMomentScore
});
