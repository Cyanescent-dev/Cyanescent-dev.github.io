import { createPresetCalibration } from "../ui/presetCalibration.js";
import { forgePlaybackTarget } from "./forgeHybridRuntime.js";
import { ARTIFICIAL_CONSCIOUSNESS } from "./artificialConsciousnessAsset.js";
import { createNewtonAudioModel } from "./newtonBasinAudio.js";
import { classifyTimeStep } from "./newtonBasinField.js";
import * as Network from "./artificialConsciousnessNetwork.js";
import { TIMELINE_FLOATS, TIMELINE_SLOT_COUNT, frameIndexAt, storyAt, unpackFrame } from "./artificialConsciousnessField.js";
import { createMusicLayer } from "./artificialConsciousnessMusic.js";
import {
  AC_CURVE_SEGMENTS, AC_EDGE_H, AC_EDGE_W, AC_NODE_H, AC_NODE_W, AC_SPARKS, AC_STRAIGHT_KINDS, AC_WAVES,
  AC_APERTURE_RING_SEGMENTS, acApertureFragmentSource, acApertureVertexSource, acBlurSource, acCompositeSource, acDownsampleSource, acEdgeFragmentSource, acEdgeVertexSource, acNodeSource
} from "./artificialConsciousnessShaders.js";

const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const LOG_PREFIX = "[ArtificialConsciousness]";
const UBO_BINDING = 7;
const GLOW_DIVISOR = 4;

// Artificial Consciousness draws the beauty video itself (a WebGL texture of the playing <video>) and
// lights the video's own network on top of it: the Forge's network is rebuilt exactly on the GPU from
// topology.bin and the frame's header, and the music layer sends waves, sparks and streams along its
// real connections (artificialConsciousnessMusic.js). The <video> element stays in the page underneath
// as the decoder; if the GPU path is unavailable it is simply what the viewer sees.
export function createArtificialConsciousnessRuntime({ getGl, program, programFrom, setAttribs, asset = ARTIFICIAL_CONSCIOUSNESS }) {
  const controls = {
    reactive: 1.0, overlay: 1.0, glow: 1.0, sparks: 1.0, streams: 1.0, grade: 1.0, beatOffsetMs: 90,
    bpmLock: true, testBPM: 0, debug: 0
  };
  const calibration = createPresetCalibration({
    presetId: 394, presetName: "Artificial Consciousness", controls, buildPanel: makePanel,
    clearPanel: () => { panel = null; }
  });
  const audioModel = createNewtonAudioModel();
  const music = createMusicLayer();
  let active = false, token = 0, video = null, videoCallback = 0, playingPending = false;
  let presentedTime = NaN, lastPresented = NaN, presentedFrames = 0, callbackSkips = 0, uploadedFrame = -1;
  let lastAt = 0, lastMediaTime = NaN, loops = 0, seeks = 0, lastLabelAt = 0;
  let targetRate = 1, tempoBPM = 0, tempoAbsent = 0, started = false, waitingForBar = true;
  let pkg = null, packageError = "", packageState = "idle", fatal = "";
  let topology = null, timeline = null, hubs = null;
  let programs = null, gpu = null, videoTexture = null, videoTextureReady = false, emptyVao = null;
  let panel = null;
  let frames = 0, fps = 0, reportAt = 0, reportFrames = 0, startCostMs = 0;
  let fixtureSeek = NaN, fixtureSeekDone = false, fixtureHold = false;
  let nodeFrame = -1, currentFrame = 0, lastFrameState = null, nodeCheckAt = 0, nodeCheck = null;
  let lastMusic = null;
  const uniformLocations = new WeakMap();
  const timings = { video: 0, nodes: 0, edges: 0, glow: 0, composite: 0, frames: 0, total: 0, nodePasses: 0 };
  const glErrors = {};
  const counts = { straight: 0, curved: 0 };
  const trialMode = () => document.body.classList.contains("preset-trial-role");
  function checkGl(gl, stage) {
    if (!trialMode() || frames % 120 !== 0) return;
    const code = gl.getError();
    if (code) glErrors[stage] = `0x${code.toString(16)}`;
  }

  // ------------------------------------------------------------- GL helpers
  function loc(gl, shader, name) {
    let map = uniformLocations.get(shader);
    if (!map) { map = new Map(); uniformLocations.set(shader, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(shader, name));
    return map.get(name);
  }
  const u1 = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1f(l, v); };
  const u1i = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1i(l, v); };
  const u1ui = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1ui(l, v); };
  const u2 = (gl, s, n, a, b) => { const l = loc(gl, s, n); if (l !== null) gl.uniform2f(l, a, b); };
  const u4 = (gl, s, n, a, b, c, d) => { const l = loc(gl, s, n); if (l !== null) gl.uniform4f(l, a, b, c, d); };
  const u4v = (gl, s, n, array) => { const l = loc(gl, s, n); if (l !== null) gl.uniform4fv(l, array); };
  const u1v = (gl, s, n, array) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1fv(l, array); };
  function tex(gl, s, name, unit, texture) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    const l = loc(gl, s, name);
    if (l !== null) gl.uniform1i(l, unit);
  }
  function makeTexture(gl, width, height, { internal = gl.RGBA8, format = gl.RGBA, type = gl.UNSIGNED_BYTE, filter = gl.NEAREST, data = null } = {}) {
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);        // other presets leave this set: row 0 must stay row 0
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, width, height, 0, format, type, data);
    return texture;
  }
  function framebufferFor(gl, textures) {
    const fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    textures.forEach((texture, i) => gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0 + i, gl.TEXTURE_2D, texture, 0));
    gl.drawBuffers(textures.map((_, i) => gl.COLOR_ATTACHMENT0 + i));
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error("Artificial Consciousness framebuffer is incomplete");
    return fbo;
  }
  function fullscreen(gl, prog) { gl.useProgram(prog); setAttribs(prog); gl.drawArrays(gl.TRIANGLES, 0, 3); }
  function bindFrameBlock(gl, prog) {
    const index = gl.getUniformBlockIndex(prog, "Frame");
    if (index !== gl.INVALID_INDEX) gl.uniformBlockBinding(prog, index, UBO_BINDING);
  }

  // ------------------------------------------------------------------ panel
  function makePanel() {
    panel = document.createElement("details");
    panel.className = "forge-hybrid-controls";
    panel.innerHTML = `<summary>Artificial Consciousness controls</summary>
      <label>Reactive amount <input type="range" data-key="reactive" min="0" max="1.5" step="0.01"></label>
      <label>Network light <input type="range" data-key="overlay" min="0" max="1.5" step="0.01"></label>
      <label>Glow <input type="range" data-key="glow" min="0" max="1.5" step="0.01"></label>
      <label>Sparks <input type="range" data-key="sparks" min="0" max="1.5" step="0.01"></label>
      <label>Streams <input type="range" data-key="streams" min="0" max="1.5" step="0.01"></label>
      <label>Grade <input type="range" data-key="grade" min="0" max="1.5" step="0.01"></label>
      <label>Beat offset (ms, + = earlier) <input type="range" data-key="beatOffsetMs" min="-100" max="250" step="5"></label>
      <label>BPM lock <input type="checkbox" data-key="bpmLock"></label>
      <label>Test BPM <select data-key="testBPM"><option value="0">Track</option><option value="140">140</option><option value="145">145</option><option value="150">150</option></select></label>
      <label>View <select data-key="debug"><option value="0">Beauty + light</option><option value="1">Network over beauty (alignment)</option><option value="2">Light only</option><option value="3">Network only</option></select></label>`;
    for (const input of panel.querySelectorAll("[data-key]")) {
      const key = input.dataset.key;
      if (input.type === "checkbox") input.checked = controls[key]; else input.value = String(controls[key]);
      input.addEventListener("input", () => { controls[key] = input.type === "checkbox" ? input.checked : Number(input.value); });
    }
    document.body.appendChild(panel);
    return panel;
  }

  // ---------------------------------------------------------------- package
  async function fetchJson(name) {
    const response = await fetch(`${asset.assetRoot}/${name}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`${name}: HTTP ${response.status}`);
    return response.json();
  }
  async function fetchBytes(name) {
    const response = await fetch(`${asset.assetRoot}/${name}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`${name}: HTTP ${response.status}`);
    return new Uint8Array(await response.arrayBuffer());
  }
  async function loadPackage(generation) {
    packageState = "loading";
    try {
      const manifest = await fetchJson(asset.manifest);
      if (manifest.schema !== asset.schema || manifest.version !== asset.packageVersion) {
        throw new Error(`unrecognised runtime package (${manifest.schema} v${manifest.version}; this build reads v${asset.packageVersion}, recompile with scripts/compile-artificial-consciousness-runtime.mjs)`);
      }
      if (manifest.timeline.frames !== asset.frameCount || manifest.topology.nodeCount !== asset.nodeCount || manifest.topology.edgeCount !== asset.edgeCount || manifest.timeline.floatsPerFrame !== TIMELINE_FLOATS) {
        throw new Error("runtime.json disagrees with artificialConsciousnessAsset.js (recompile the package or update the descriptor)");
      }
      const [topologyBytes, timelineBytes] = await Promise.all([fetchBytes(manifest.topology.file), fetchBytes(manifest.timeline.file)]);
      if (generation !== token) return;
      const aligned = new Uint8Array(timelineBytes.length);
      aligned.set(timelineBytes);
      timeline = new Float32Array(aligned.buffer);
      topology = Network.parseTopology(topologyBytes);
      hubs = buildHubCandidates(topology);
      pkg = manifest;
      if (programs && gpu) uploadStatic(getGl());
      packageState = "ready";
    } catch (error) {
      if (generation !== token) return;
      packageError = String(error?.message || error);
      packageState = "failed";
      console.warn(`${LOG_PREFIX} runtime package unavailable; showing the beauty video without its light.`, packageError);
    }
  }

  // Nodes the hi-hats can fire: module and region hubs of the entity shells and the substrate's hubs.
  function buildHubCandidates(t) {
    const entity = [], substrate = [];
    for (let i = 0; i < t.nodeCount; i += 1) {
      const shell = Network.nodeShell(t, i), kind = Network.nodeKind(t, i);
      if (shell >= 0 && shell < 3.5 && (kind === 1 || kind === 2)) entity.push(i);
      else if (shell < -0.5 && kind === 6) substrate.push(i);
    }
    return { entity, substrate };
  }

  // A hat fires a hub that is on screen in the frame being shown.
  function pickHub(rand, look) {
    if (!hubs || !topology || !timeline) return null;
    const state = lastFrameState || unpackFrame(timeline, pkg.timeline.look, topology.seed, currentFrame * TIMELINE_FLOATS);
    lastFrameState = state;
    const lifted = state.stage[1] > 0.3 || state.stage[0] > 0.6;
    for (let attempt = 0; attempt < 14; attempt += 1) {
      const pool = (lifted ? rand() < 0.75 : rand() < 0.4) ? hubs.entity : hubs.substrate;
      if (!pool.length) continue;
      const i = pool[Math.floor(rand() * pool.length)];
      const placed = Network.placeNode(state, topology, i, {});
      if (placed.presence < 0.6) continue;
      if (lifted && Network.nodeShell(topology, i) >= 0 && placed.entity < 0.5) continue;
      const uv = Network.toUv(state.camera, placed.position);
      if (uv.depth <= 0.5 || uv.u < 0.03 || uv.u > 0.97 || uv.v < 0.03 || uv.v > 0.97) continue;
      return [topology.nodes[i * Network.NODE_FLOATS], topology.nodes[i * Network.NODE_FLOATS + 1]];
    }
    return null;
  }
  music.setHubPicker?.(pickHub);

  // ------------------------------------------------------------- lifecycle
  function start() {
    if (active) return;
    const startedAt = performance.now();
    active = true; token += 1;
    presentedTime = NaN; lastPresented = NaN; presentedFrames = callbackSkips = 0; uploadedFrame = -1; videoTextureReady = false;
    lastAt = 0; lastMediaTime = NaN; loops = seeks = 0; started = false; waitingForBar = true;
    frames = 0; nodeFrame = -1; lastFrameState = null;
    pkg = null; topology = null; timeline = null; hubs = null;
    packageError = ""; packageState = "idle"; fatal = "";
    targetRate = 1; tempoBPM = 0; tempoAbsent = 0;
    audioModel.reset(); music.reset();
    for (const key of Object.keys(timings)) timings[key] = 0;
    video = document.createElement("video");
    video.muted = true; video.playsInline = true; video.loop = true; video.preload = "auto";
    video.className = "forge-hybrid-video";
    document.body.appendChild(video);
    window.__artificialConsciousnessVideo = video;
    video.src = encodeURI(`${asset.assetRoot}/${asset.video}`);
    video.load();
    if (video.requestVideoFrameCallback) {
      const generation = token;
      const callback = (_now, info) => {
        if (!active || generation !== token || !video) return;
        if (Number.isFinite(info.mediaTime)) {
          if (Number.isFinite(lastPresented) && info.mediaTime > lastPresented + 1.5 / asset.videoFps && info.mediaTime - lastPresented < 0.5) callbackSkips += 1;
          lastPresented = info.mediaTime;
          presentedTime = info.mediaTime;
          presentedFrames += 1;
        }
        videoCallback = video.requestVideoFrameCallback(callback);
      };
      videoCallback = video.requestVideoFrameCallback(callback);
    }
    const gl = getGl();
    const floatExtension = gl.getExtension("EXT_color_buffer_float");
    if (!floatExtension) fatal = "float render targets are unavailable";
    else {
      try { buildGpuResources(gl); }
      catch (error) { fatal = String(error?.message || error); console.error(`${LOG_PREFIX} GPU setup failed:`, error); }
    }
    window.__artificialConsciousnessControls = controls;
    calibration.start();
    const fixture = new URLSearchParams(window.location.search).get("fixture") || "";
    const match = /^ac-([a-z0-9]+)(?:-t([\d.]+))?$/.exec(fixture);
    if (match) {
      if (match[1] === "network") controls.debug = 1;
      if (match[1] === "waves") controls.debug = 2;
      if (match[1] === "off") controls.reactive = 0;
      // paused frames for measuring alignment: the beauty alone (still) or the rebuilt network alone (stillnet)
      if (match[1] === "still" || match[1] === "stillnet") { fixtureHold = true; controls.reactive = 0; controls.debug = match[1] === "stillnet" ? 3 : 0; }
      if (match[1] === "loop") fixtureSeek = Math.max(0, asset.durationSeconds - 3);
      if (match[2]) fixtureSeek = Number(match[2]);
    } else fixtureSeek = NaN;
    if (!match) fixtureHold = false;
    fixtureSeekDone = false;
    loadPackage(token);
    startCostMs = performance.now() - startedAt;
  }

  function buildGpuResources(gl) {
    programs = {
      node: program(acNodeSource),
      down: program(acDownsampleSource),
      blur: program(acBlurSource),
      composite: program(acCompositeSource),
      straight: programFrom(acEdgeVertexSource, acEdgeFragmentSource, []),
      curved: programFrom(acEdgeVertexSource, acEdgeFragmentSource, []),
      aperture: programFrom(acApertureVertexSource, acApertureFragmentSource, [])
    };
    for (const name of Object.keys(programs)) if (!programs[name]) throw new Error(`Artificial Consciousness ${name} program did not compile`);
    for (const name of ["node", "straight", "curved", "aperture"]) bindFrameBlock(gl, programs[name]);
    videoTexture = makeTexture(gl, 2, 2, { filter: gl.LINEAR });
    gpu = { overlay: null, overlayFbo: null, glow: [], glowFbo: [], size: [0, 0] };
    const f32 = { internal: gl.RGBA32F, format: gl.RGBA, type: gl.FLOAT };
    gpu.nodeStatic = [0, 1, 2].map(() => makeTexture(gl, AC_NODE_W, AC_NODE_H, f32));
    gpu.edges = makeTexture(gl, AC_EDGE_W, AC_EDGE_H, f32);
    const single = { internal: gl.R32F, format: gl.RED, type: gl.FLOAT };
    gpu.listStraight = makeTexture(gl, AC_EDGE_W, AC_EDGE_H, single);
    gpu.listCurved = makeTexture(gl, AC_EDGE_W, AC_EDGE_H, single);
    gpu.nodeState = [0, 1, 2].map(() => makeTexture(gl, AC_NODE_W, AC_NODE_H, f32));
    gpu.nodeFbo = framebufferFor(gl, gpu.nodeState);
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.nodeFbo);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gpu.ubo = gl.createBuffer();
    gl.bindBuffer(gl.UNIFORM_BUFFER, gpu.ubo);
    gl.bufferData(gl.UNIFORM_BUFFER, TIMELINE_SLOT_COUNT * 16, gl.DYNAMIC_DRAW);
    gl.bindBuffer(gl.UNIFORM_BUFFER, null);
    emptyVao = gl.createVertexArray();
    if (pkg) uploadStatic(gl);
  }

  // The network itself: three images of node attributes, the connection table and the two draw lists.
  function uploadStatic(gl) {
    const count = topology.nodeCount;
    const a = new Float32Array(AC_NODE_W * AC_NODE_H * 4), b = new Float32Array(a.length), c = new Float32Array(a.length);
    for (let i = 0; i < count; i += 1) {
      const n = i * Network.NODE_FLOATS;
      for (let k = 0; k < 4; k += 1) { a[i * 4 + k] = topology.nodes[n + k]; b[i * 4 + k] = topology.nodes[n + 4 + k]; c[i * 4 + k] = topology.nodes[n + 8 + k]; }
    }
    const edges = new Float32Array(AC_EDGE_W * AC_EDGE_H * 4);
    const straight = new Float32Array(AC_EDGE_W * AC_EDGE_H), curved = new Float32Array(AC_EDGE_W * AC_EDGE_H);
    const straightKinds = new Set(AC_STRAIGHT_KINDS);
    let ns = 0, nc = 0;
    for (let e = 0; e < topology.edgeCount; e += 1) {
      edges[e * 4] = Network.edgeA(topology, e); edges[e * 4 + 1] = Network.edgeB(topology, e);
      edges[e * 4 + 2] = Network.edgeFlags(topology, e); edges[e * 4 + 3] = topology.edgeRank[e * 4 + 3];
      if (straightKinds.has(Network.edgeKind(topology, e))) straight[ns++] = e; else curved[nc++] = e;
    }
    counts.straight = ns; counts.curved = nc;
    const upload = (texture, data, w, h, format) => {
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, w, h, format, gl.FLOAT, data);
    };
    gpu.nodeStatic.forEach((texture, k) => upload(texture, [a, b, c][k], AC_NODE_W, AC_NODE_H, gl.RGBA));
    upload(gpu.edges, edges, AC_EDGE_W, AC_EDGE_H, gl.RGBA);
    upload(gpu.listStraight, straight, AC_EDGE_W, AC_EDGE_H, gl.RED);
    upload(gpu.listCurved, curved, AC_EDGE_W, AC_EDGE_H, gl.RED);
    gpu.staticReady = true;
  }

  function ensureTargets(gl, width, height) {
    if (gpu.size[0] === width && gpu.size[1] === height) return;
    for (const texture of [gpu.overlay, ...gpu.glow]) if (texture) gl.deleteTexture(texture);
    for (const fbo of [gpu.overlayFbo, ...gpu.glowFbo]) if (fbo) gl.deleteFramebuffer(fbo);
    const half = { internal: gl.RGBA16F, format: gl.RGBA, type: gl.HALF_FLOAT, filter: gl.LINEAR };
    gpu.overlay = makeTexture(gl, width, height, half);
    gpu.overlayFbo = framebufferFor(gl, [gpu.overlay]);
    const gw = Math.max(2, Math.round(width / GLOW_DIVISOR)), gh = Math.max(2, Math.round(height / GLOW_DIVISOR));
    gpu.glow = [makeTexture(gl, gw, gh, half), makeTexture(gl, gw, gh, half)];
    gpu.glowFbo = gpu.glow.map((texture) => framebufferFor(gl, [texture]));
    for (const fbo of [gpu.overlayFbo, ...gpu.glowFbo]) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gpu.size = [width, height];
  }

  function stop() {
    if (!active) return;
    active = false; token += 1;
    if (video) {
      if (videoCallback && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(videoCallback);
      video.pause(); video.removeAttribute("src"); video.load(); video.remove(); video = null;
    }
    window.__artificialConsciousnessVideo = null; window.__artificialConsciousnessDiagnostics = null; window.__artificialConsciousnessControls = null;
    const gl = getGl();
    if (gl) {
      if (gpu) {
        const textures = [...gpu.nodeStatic, gpu.edges, gpu.listStraight, gpu.listCurved, ...gpu.nodeState, gpu.overlay, ...gpu.glow];
        for (const texture of textures) if (texture) gl.deleteTexture(texture);
        for (const fbo of [gpu.nodeFbo, gpu.overlayFbo, ...gpu.glowFbo]) if (fbo) gl.deleteFramebuffer(fbo);
        if (gpu.ubo) gl.deleteBuffer(gpu.ubo);
      }
      if (videoTexture) gl.deleteTexture(videoTexture);
      if (emptyVao) gl.deleteVertexArray(emptyVao);
      if (programs) for (const shader of Object.values(programs)) if (shader) gl.deleteProgram(shader);
    }
    programs = gpu = videoTexture = emptyVao = null;
    pkg = null; topology = null; timeline = null; hubs = null; lastFrameState = null;
    calibration.stop(); panel = null;
  }

  // ------------------------------------------------------------------ clock
  function updateTempo(tempo, dt) {
    const measured = controls.testBPM > 0 ? { bpm: controls.testBPM, confidence: 1 } : tempo || {};
    const bpm = Number(measured.bpm) || 0;
    const confidence = Number(measured.confidence ?? 1);
    if (!controls.bpmLock) { targetRate = 1; tempoBPM = 0; tempoAbsent = 0; }
    else if (bpm >= 70 && bpm <= 220 && confidence >= 0.35) {
      tempoAbsent = 0;
      if (!tempoBPM || Math.abs(bpm - tempoBPM) >= 0.8) {
        tempoBPM = bpm;
        targetRate = forgePlaybackTarget({ bpm, confidence }, pkg?.tempo.referenceBPM || asset.referenceBPM);
      }
    } else if ((tempoAbsent += dt) > 5) { targetRate = 1; tempoBPM = 0; }
    if (video) {
      const next = video.playbackRate + clamp(targetRate - video.playbackRate, -dt * 0.14, dt * 0.14);
      if (Math.abs(next - video.playbackRate) > 0.0002) video.playbackRate = next;
    }
  }

  function beatsPerSecond(tempo) {
    const bpm = controls.testBPM > 0 ? controls.testBPM : Number(tempo?.bpm) || 0;
    const confidence = controls.testBPM > 0 ? 1 : Number(tempo?.confidence ?? 1);
    if (bpm >= 70 && bpm <= 220 && confidence >= 0.35) return bpm / 60;
    return (pkg?.tempo.referenceBPM || asset.referenceBPM) * (video?.playbackRate || 1) / 60;
  }

  // The playing frame -> a texture (the accelerated path: unsized RGBA, no flip).
  function uploadVideo(gl, videoReady, exporting) {
    if (!videoReady || !programs) return;
    const fresh = exporting || !video.requestVideoFrameCallback || presentedFrames !== uploadedFrame || !videoTextureReady;
    if (!fresh) return;
    const stamp = performance.now();
    try {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, videoTexture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
      uploadedFrame = presentedFrames;
      videoTextureReady = true;
    } catch (error) { if (frames < 400) console.warn(`${LOG_PREFIX} video texture:`, error); return; }
    timings.video += performance.now() - stamp;
  }

  // ------------------------------------------------------------------ render
  // A failing frame must never take the player down: report it once and keep the video visible.
  let renderError = "";
  function render(frame) {
    try { renderFrame(frame); }
    catch (error) {
      if (!renderError) {
        renderError = String(error?.stack || error);
        console.error(`${LOG_PREFIX} render failed:`, renderError);
        if (trialMode()) window.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "error", text: `${LOG_PREFIX} render failed: ${renderError}` });
      }
      const gl = getGl();
      gl.bindVertexArray(null);
      gl.disable(gl.BLEND);
      gl.bindFramebuffer(gl.FRAMEBUFFER, frame.target.fb);
      gl.viewport(0, 0, frame.width, frame.height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
  }

  function renderFrame({ target, width, height, now, tempo, playing = true, music: musicState, audio, smooth, spectrum }) {
    if (!active) start();
    const gl = getGl();
    const dt = lastAt ? clamp((now - lastAt) / 1000, 0, 0.05) : 1 / 60;
    lastAt = now;
    const videoReady = video.readyState >= 2 && video.videoWidth === asset.videoWidth && video.videoHeight === asset.videoHeight;
    const exporting = document.body.classList.contains("exporting-video");
    const glVideo = Boolean(programs && gpu && !fatal);
    video.style.display = exporting ? "none" : "block";
    updateTempo(tempo, dt);
    if (!playing && !video.paused) video.pause();
    if (playing && videoReady && video.paused && !playingPending && !(fixtureHold && fixtureSeekDone)) {
      const beat = Number(musicState?.absoluteBeat);
      const canAlign = controls.bpmLock && tempo?.bpm > 0 && Number.isFinite(beat) && beat >= 0;
      const beatsPerBar = pkg?.tempo.beatsPerBar || asset.beatsPerBar;
      const phase = canAlign ? ((beat % beatsPerBar) + beatsPerBar) % beatsPerBar : 0;
      if (started || !canAlign || !waitingForBar || phase < 0.12 || phase > beatsPerBar - 0.10) {
        started = true; waitingForBar = false; playingPending = true;
        video.play().catch((error) => { if (frames < 400) console.warn(`${LOG_PREFIX} video playback:`, error); })
          .finally(() => { playingPending = false; });
      }
    }
    if (videoReady && Number.isFinite(fixtureSeek) && !fixtureSeekDone) {
      // Development fixtures: jump the real video to a chosen part of the story (ac-<mode>-t<seconds>).
      video.currentTime = fixtureSeek;
      fixtureSeekDone = true;
      if (fixtureHold) video.pause();
    }
    const mediaTime = Number.isFinite(presentedTime) ? presentedTime : (video.currentTime || 0);
    const step = classifyTimeStep(lastMediaTime, mediaTime, asset.durationSeconds, dt, video.playbackRate || 1);
    if (step === "loop") loops += 1;
    if (step === "seek") seeks += 1;
    lastMediaTime = mediaTime;
    frames += 1;
    const stamp0 = performance.now();

    const bps = beatsPerSecond(tempo);
    lastMusic = musicState;
    const events = audioModel.step(playing ? dt : 0, { audio, smooth, music: musicState }, { reactive: controls.reactive, beatsPerSecond: bps, leadSeconds: controls.beatOffsetMs / 1000 });

    if (!glVideo) {
      // No GPU path: leave the canvas transparent and let the <video> element show through.
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, width, height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      report(gl, { now, mediaTime, videoReady, ready: false, playing, glVideo });
      return;
    }
    uploadVideo(gl, videoReady, exporting);

    const ready = packageState === "ready" && gpu.staticReady;
    let story = null;
    if (ready) {
      currentFrame = frameIndexAt(mediaTime, asset.videoFps, asset.frameCount);
      story = storyAt(timeline, currentFrame * TIMELINE_FLOATS);
      const regionAngles = Array.from(timeline.subarray(currentFrame * TIMELINE_FLOATS + 15 * 4, currentFrame * TIMELINE_FLOATS + 15 * 4 + 4)).concat(Array.from(timeline.subarray(currentFrame * TIMELINE_FLOATS + 16 * 4, currentFrame * TIMELINE_FLOATS + 16 * 4 + 2)));
      music.setRegionAngles?.(regionAngles);
      music.step(playing ? dt : 0, {
        audio: audioModel.state, events, story, beatsPerBar: pkg.tempo.beatsPerBar, reactive: controls.reactive, spectrum,
        controls: { sparks: controls.sparks }
      });
      lastFrameState = null;
      drawNetwork(gl, { target, width, height, story });
    } else {
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, width, height);
      drawComposite(gl, { target, width, height, ready: false });
    }
    timings.frames += 1;
    timings.total += performance.now() - stamp0;
    report(gl, { now, mediaTime, videoReady, ready, playing, glVideo, story });
  }

  function viewRect(width, height) {
    const aspect = asset.videoWidth / asset.videoHeight;
    return width / Math.max(1, height) > aspect ? [Math.round(height * aspect), height] : [width, Math.round(width / aspect)];
  }

  function setNetworkUniforms(gl, prog) {
    u1ui(gl, prog, "uSeed", topology.seed);
    u4(gl, prog, "uLookC", pkg.timeline.look[0], pkg.timeline.look[1], pkg.timeline.look[2], pkg.timeline.look[3]);
    u1(gl, prog, "uNodeCount", topology.nodeCount);
  }

  function drawNetwork(gl, { target, width, height, story }) {
    gl.disable(gl.BLEND);
    // 1) the frame header, and the nodes when the frame changed
    let stamp = performance.now();
    gl.bindBuffer(gl.UNIFORM_BUFFER, gpu.ubo);
    gl.bufferSubData(gl.UNIFORM_BUFFER, 0, timeline, currentFrame * TIMELINE_FLOATS, TIMELINE_FLOATS);
    gl.bindBufferBase(gl.UNIFORM_BUFFER, UBO_BINDING, gpu.ubo);
    if (nodeFrame !== currentFrame) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.nodeFbo);
      gl.viewport(0, 0, AC_NODE_W, AC_NODE_H);
      const prog = programs.node;
      gl.useProgram(prog);
      setNetworkUniforms(gl, prog);
      tex(gl, prog, "uNodeA", 0, gpu.nodeStatic[0]); tex(gl, prog, "uNodeB", 1, gpu.nodeStatic[1]); tex(gl, prog, "uNodeC", 2, gpu.nodeStatic[2]);
      fullscreen(gl, prog);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      nodeFrame = currentFrame;
      timings.nodePasses += 1;
      checkGl(gl, "nodes");
    }
    timings.nodes += performance.now() - stamp;

    // 2) the light: ribbons along the connections, additively into the overlay target
    stamp = performance.now();
    const [viewW, viewH] = viewRect(width, height);
    ensureTargets(gl, viewW, viewH);
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.overlayFbo);
    gl.viewport(0, 0, viewW, viewH);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    {
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE);
      gl.bindVertexArray(emptyVao);
      for (const curved of [false, true]) {
        const prog = curved ? programs.curved : programs.straight;
        gl.useProgram(prog);
        setNetworkUniforms(gl, prog);
        tex(gl, prog, "uNodeA", 0, gpu.nodeStatic[0]); tex(gl, prog, "uNodeB", 1, gpu.nodeStatic[1]); tex(gl, prog, "uNodeC", 2, gpu.nodeStatic[2]);
        tex(gl, prog, "uPos", 3, gpu.nodeState[0]); tex(gl, prog, "uState", 4, gpu.nodeState[1]); tex(gl, prog, "uColour", 5, gpu.nodeState[2]);
        tex(gl, prog, "uEdges", 6, gpu.edges); tex(gl, prog, "uList", 7, curved ? gpu.listCurved : gpu.listStraight);
        u2(gl, prog, "uView", viewW, viewH);
        u1(gl, prog, "uPx", viewH / asset.videoHeight);
        u1i(gl, prog, "uCurved", curved ? 1 : 0);
        u1i(gl, prog, "uSegments", curved ? AC_CURVE_SEGMENTS : 1);
        u1(gl, prog, "uDebug", controls.debug === 1 || controls.debug === 3 ? 1 : 0);
        u1(gl, prog, "uGlow", clamp(music.state.energy * 0.5 + music.state.dropFlash * 0.5, 0, 1) * controls.glow);
        const U = music.uniforms;
        u4v(gl, prog, "uWaveA[0]", U.waveA); u4v(gl, prog, "uWaveB[0]", U.waveB); u4v(gl, prog, "uWaveC[0]", U.waveC);
        u4v(gl, prog, "uSpark[0]", U.spark);
        u4(gl, prog, "uMA", U.A[0], U.A[1], U.A[2], U.A[3]);
        u4(gl, prog, "uMB", U.B[0], U.B[1], U.B[2], U.B[3]);
        u4(gl, prog, "uMC", U.C[0], U.C[1], U.C[2], U.C[3] * controls.streams);
        u4(gl, prog, "uMD", U.D[0], U.D[1], U.D[2], U.D[3]);
        u4v(gl, prog, "uSpec[0]", U.spec);
        u1v(gl, prog, "uKindW[0]", U.kindWeights);
        const instances = curved ? counts.curved : counts.straight;
        const verts = curved ? (AC_CURVE_SEGMENTS + 1) * 2 : 4;
        gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, verts, instances);
      }
      if (controls.debug !== 1 && controls.debug !== 3) {
        const prog = programs.aperture;
        gl.useProgram(prog);
        setNetworkUniforms(gl, prog);
        u2(gl, prog, "uView", viewW, viewH);
        u1(gl, prog, "uPx", viewH / asset.videoHeight);
        const U = music.uniforms;
        u4(gl, prog, "uMA", U.A[0], U.A[1], U.A[2], U.A[3]);
        u4(gl, prog, "uMB", U.B[0], U.B[1], U.B[2], U.B[3]);
        u4(gl, prog, "uMC", U.C[0], U.C[1], U.C[2], U.C[3] * controls.streams);
        u4(gl, prog, "uMD", U.D[0], U.D[1], U.D[2], U.D[3]);
        u1i(gl, prog, "uMode", 1); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        u1i(gl, prog, "uMode", 2); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        u1i(gl, prog, "uMode", 0); gl.drawArrays(gl.TRIANGLE_STRIP, 0, (AC_APERTURE_RING_SEGMENTS + 1) * 2);
      }
      gl.bindVertexArray(null);
      gl.disable(gl.BLEND);
    }
    checkGl(gl, "edges");
    timings.edges += performance.now() - stamp;

    // 3) glow pyramid
    stamp = performance.now();
    const gw = Math.max(2, Math.round(viewW / GLOW_DIVISOR)), gh = Math.max(2, Math.round(viewH / GLOW_DIVISOR));
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.glowFbo[0]);
    gl.viewport(0, 0, gw, gh);
    gl.useProgram(programs.down);
    tex(gl, programs.down, "uSrc", 0, gpu.overlay);
    fullscreen(gl, programs.down);
    for (let pass = 0; pass < 2; pass += 1) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.glowFbo[1]);
      gl.useProgram(programs.blur);
      tex(gl, programs.blur, "uSrc", 0, gpu.glow[0]);
      u2(gl, programs.blur, "uDir", 1 / gw, 0);
      fullscreen(gl, programs.blur);
      gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.glowFbo[0]);
      tex(gl, programs.blur, "uSrc", 0, gpu.glow[1]);
      u2(gl, programs.blur, "uDir", 0, 1 / gh);
      fullscreen(gl, programs.blur);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    timings.glow += performance.now() - stamp;

    drawComposite(gl, { target, width, height, ready: true });
  }

  function drawComposite(gl, { target, width, height, ready }) {
    const stamp = performance.now();
    const state = audioModel.state;
    const grade = clamp(controls.grade, 0, 1.5);
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    gl.disable(gl.BLEND);
    const prog = programs.composite;
    gl.useProgram(prog);
    tex(gl, prog, "uVideo", 0, videoTexture);
    tex(gl, prog, "uOverlay", 1, ready ? gpu.overlay : videoTexture);
    tex(gl, prog, "uGlow", 2, ready ? gpu.glow[0] : videoTexture);
    u1(gl, prog, "uCanvasAspect", width / Math.max(1, height));
    u1(gl, prog, "uVideoAspect", asset.videoWidth / asset.videoHeight);
    const scaled = (value) => 1 + (value - 1) * grade;
    const stageDim = clamp(0.24 * music.state.stageDim * controls.overlay, 0, 0.4);
    u4(gl, prog, "uGrade", scaled(state.exposure), scaled(state.saturation), scaled(state.contrast), controls.debug >= 2 ? 1 : stageDim);
    const light = ready ? controls.overlay : 0;
    u4(gl, prog, "uOverlayGain", light, 0.9 * controls.glow * light, 1.0, 0);
    fullscreen(gl, prog);
    checkGl(gl, "composite");
    timings.composite += performance.now() - stamp;
  }

  // ---------------------------------------------------------------- report
  // Trial-only: read the GPU's node positions back and compare them with the JS reference.
  function verifyNodes(gl) {
    if (!topology || !gpu || nodeFrame < 0) return null;
    const count = topology.nodeCount;
    const buffer = new Float32Array(AC_NODE_W * AC_NODE_H * 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.nodeFbo);
    gl.readBuffer(gl.COLOR_ATTACHMENT0);
    gl.readPixels(0, 0, AC_NODE_W, AC_NODE_H, gl.RGBA, gl.FLOAT, buffer);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    const state = unpackFrame(timeline, pkg.timeline.look, topology.seed, nodeFrame * TIMELINE_FLOATS);
    let max = -1, sum = 0, worst = 0, n = 0;
    const byShell = {};
    const scratch = {};
    for (let i = 0; i < count; i += 7) {
      const ref = Network.placeNode(state, topology, i, scratch);
      const dx = buffer[i * 4] - ref.position[0], dy = buffer[i * 4 + 1] - ref.position[1], dz = buffer[i * 4 + 2] - ref.position[2];
      const err = Math.hypot(dx, dy, dz);
      const shell = Network.nodeShell(topology, i);
      const entry = byShell[shell] || (byShell[shell] = { n: 0, sum: 0, max: -1, worst: i });
      entry.n += 1; entry.sum += err;
      if (err > entry.max) { entry.max = err; entry.worst = i; }
      if (err > max) { max = err; worst = i; }
      sum += err; n += 1;
    }
    const shells = {};
    for (const [shell, e] of Object.entries(byShell)) {
      const w = e.worst, ref = Network.placeNode(state, topology, w, {});
      shells[shell] = { mean: Number((e.sum / e.n).toFixed(4)), max: Number(e.max.toFixed(3)), worst: w, gpu: [0, 1, 2, 3].map((k) => Number(buffer[w * 4 + k].toFixed(3))), ref: [...ref.position, ref.presence].map((v) => Number(v.toFixed(3))) };
    }
    return { frame: nodeFrame, nodes: n, meanError: sum / Math.max(1, n), maxError: max, worstNode: worst, shells };
  }

  function report(gl, { now, mediaTime, videoReady, ready, playing, glVideo, story }) {
    if (panel && now - lastLabelAt > 500) {
      panel.querySelector("summary").textContent = packageState === "failed" || fatal
        ? "Artificial Consciousness · video only"
        : `Artificial Consciousness · ${video.playbackRate.toFixed(3)}× · frame ${currentFrame}${ready ? "" : " (loading)"}`;
      lastLabelAt = now;
    }
    const trial = trialMode();
    if (now - reportAt < (trial ? 2000 : 5000)) return;
    fps = reportAt ? (frames - reportFrames) * 1000 / (now - reportAt) : 0;
    reportAt = now; reportFrames = frames;
    if (trial && ready && now - nodeCheckAt > 6000) { nodeCheckAt = now; try { nodeCheck = verifyNodes(gl); } catch (error) { nodeCheck = { error: String(error) }; } }
    const quality = video.getVideoPlaybackQuality?.();
    const per = (value) => value / Math.max(1, timings.frames);
    const a = audioModel.state, m = music.state;
    window.__artificialConsciousnessDiagnostics = {
      fps, videoTime: mediaTime, frame: currentFrame, ready, fieldReady: ready, videoReady, glVideo, playing, loops, seeks,
      playbackRate: video.playbackRate, targetRate, packageState, packageError, fatal,
      presentedFrames, callbackSkips,
      droppedVideoFrames: quality?.droppedVideoFrames ?? 0, totalVideoFrames: quality?.totalVideoFrames ?? 0,
      story: story ? { consciousness: Number(story.consciousness.toFixed(3)), phase: story.phase, aligned: Number(story.aligned.toFixed(3)), aperture: Number(story.aperture.toFixed(3)), transcendence: Number(story.transcendence.toFixed(3)) } : null,
      edges: { ...counts },
      music: {
        beat: a.beat, beatSource: a.beatSource, groove: a.groove, build: a.build, breakdown: a.breakdown,
        bassDrive: a.bassDrive, midDrive: a.midDrive, highDrive: a.highDrive, energyDrive: a.energyDrive,
        dropFlash: a.dropFlash, kickCount: a.kickCount, hatCount: a.hatCount, dropCount: a.dropCount, rollCount: a.rollCount, tideCount: a.tideCount
      },
      layer: {
        waves: m.waveCount, sparks: m.sparkCount, direction: m.direction, strobe: m.strobe, impact: m.impact, streamGain: m.streamGain,
        loopGain: m.loopGain, kicks: m.kicks, drops: m.drops, rolls: m.rolls, tides: m.tides, hats: m.hats, machine: m.machine, organic: m.organic
      },
      nodeCheck, startCostMs, glErrors: { ...glErrors }, renderError,
      musicAware: trial && lastMusic ? { role: lastMusic.role, buildUp: lastMusic.buildUp, breakdown: lastMusic.breakdown, calm: lastMusic.calm, drop: lastMusic.drop } : undefined,
      cpuMs: { video: per(timings.video), nodes: per(timings.nodes), edges: per(timings.edges), glow: per(timings.glow), composite: per(timings.composite), total: per(timings.total), nodePasses: timings.nodePasses }
    };
    if (trial) window.webkit?.messageHandlers?.nativeApp?.postMessage({
      command: "logConsole", type: "info", text: `${LOG_PREFIX} ${JSON.stringify(window.__artificialConsciousnessDiagnostics)}`
    });
  }

  return { render, stop, controls, isActive: () => active };
}
