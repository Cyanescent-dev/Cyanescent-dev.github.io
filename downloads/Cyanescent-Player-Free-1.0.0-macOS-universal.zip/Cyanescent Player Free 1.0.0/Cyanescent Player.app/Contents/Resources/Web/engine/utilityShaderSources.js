export const blitSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D frame;
void main() {
  outColor = texture(frame, vUv);
}`;

export const fernGeometryVertexSource = `#version 300 es
in vec2 position;
in vec4 color;
out vec4 vColor;
void main() {
  vColor = color;
  gl_Position = vec4(position, 0.0, 1.0);
}`;

export const fernGeometryFragmentSource = `#version 300 es
precision highp float;
in vec4 vColor;
out vec4 outColor;
void main() {
  outColor = vColor;
}`;

export const fernBackgroundSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D backgroundImage;
uniform vec2 resolution;
uniform float time;
uniform float bass;
uniform float level;
uniform float backgroundReady;

void main() {
  float imageAspect = 1.7777778;
  float screenAspect = resolution.x / max(resolution.y, 1.0);
  vec2 uv = vUv;
  if (screenAspect > imageAspect) {
    float scale = imageAspect / screenAspect;
    uv.y = (uv.y - 0.5) * scale + 0.5;
  } else {
    float scale = screenAspect / imageAspect;
    uv.x = (uv.x - 0.5) * scale + 0.5;
  }
  vec3 fallback = mix(vec3(0.010, 0.020, 0.010), vec3(0.070, 0.120, 0.055), smoothstep(0.0, 1.0, vUv.y));
  vec3 forest = texture(backgroundImage, clamp(uv, vec2(0.0), vec2(1.0))).rgb;
  float r = length((vUv * 2.0 - 1.0) * vec2(screenAspect, 1.0));
  float breath = 1.0 + sin(time * 0.18 + bass * 0.65) * (0.012 + level * 0.012);
  float vignette = smoothstep(1.28, 0.28, r);
  vec3 color = mix(fallback, forest, backgroundReady);
  color *= breath * (0.76 + vignette * 0.28);
  color += vec3(0.08, 0.12, 0.055) * smoothstep(0.10, 0.90, vUv.y) * (0.020 + level * 0.020);
  outColor = vec4(color, 1.0);
}`;
