import { createPresetCalibration } from "../ui/presetCalibration.js";
import { forgePlaybackTarget } from "./forgeHybridRuntime.js";
import { NEWTONS_LAW } from "./newtonLawAsset.js";
import { createNewtonAudioModel } from "./newtonBasinAudio.js";
import {
  LAW_FILTER, LAW_PLANES, cameraAt, classifyTimeStep, createFieldStore, interpolateLandmarks, locateSample, loopFade, morphAt,
  parseLandmarks, sampleTimes, unfilterRows
} from "./newtonLawField.js";
import { LIGHT_COUNT, createLightRig } from "./newtonLawLights.js";
import { LAW_LIGHTS, newtonLawCompositeSource, newtonLawDownsampleSource, newtonLawResolveSource, newtonLawShadowSource } from "./newtonLawShaders.js";

const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
// The small copy of the frame has exactly the field's grid, so it guides the joint bilateral upsampling.
const SMALL_WIDTH = 320, SMALL_HEIGHT = 180;
const LOG_PREFIX = "[NewtonsLaw]";

if (LIGHT_COUNT !== LAW_LIGHTS) throw new Error("Newtons Law light rig and shaders disagree on the number of lights");

// Newtons Law draws the beauty video itself (a WebGL texture of the playing <video>) and relights
// it: three lights over the cube roots of unity, shaded with the renderer's own surface normals
// and depth, with screen-space shadows. The <video> element stays in the page underneath as the
// decoder; if the GPU path is unavailable it is simply what the viewer sees.
export function createNewtonLawRuntime({ getGl, program, programFrom, setAttribs, asset = NEWTONS_LAW }) {
  const controls = {
    reactive: 1.0, lights: 1.0, glitter: 0.8, filaments: 0.8, shadows: 1.0, grade: 1.0, beatOffsetMs: 90,
    bpmLock: true, testBPM: 0, debug: 0
  };
  const calibration = createPresetCalibration({
    presetId: 393, presetName: "Newtons Law", controls, buildPanel: makePanel,
    clearPanel: () => { panel = null; }
  });
  const audioModel = createNewtonAudioModel();
  const rig = createLightRig();
  let active = false, token = 0, video = null, videoCallback = 0, playingPending = false;
  let presentedTime = NaN, lastPresented = NaN, presentedFrames = 0, callbackSkips = 0, uploadedFrame = -1;
  let lastAt = 0, lastMediaTime = NaN, loops = 0, seeks = 0, lastLabelAt = 0;
  let targetRate = 1, tempoBPM = 0, tempoAbsent = 0, started = false, waitingForBar = true;
  let pkg = null, packageError = "", packageState = "idle", fatal = "";
  let store = null, times = null, landmarkBytes = null;
  const landmarkCache = new Map();
  let programs = null, targets = null, videoTexture = null, videoTextureReady = false;
  let panel = null;
  const slotsTex = [{ index: -1, a: null, b: null }, { index: -1, a: null, b: null }];
  let presence = 0, reportAt = 0, reportFrames = 0, fps = 0, frames = 0;
  let seekFixture = "", seekFixtureDone = false, startCostMs = 0;
  const cam0 = {}, cam1 = {}, camN = {};
  const morph = { balance: 0, coexist: 0, lawPhase: 0 };
  const scene = { plane: { cx: -0.6, cy: 0, scale: 0.81, rotation: 0 }, reliefHeight: 0.5 };
  const uniformLocations = new WeakMap();
  const lightA = new Float32Array(LAW_LIGHTS * 4);
  const lightB = new Float32Array(LAW_LIGHTS * 4);
  const lightC = new Float32Array(LAW_LIGHTS * 4);
  const timings = { video: 0, resolve: 0, shadow: 0, composite: 0, upload: 0, frames: 0, total: 0 };
  let currentIndices = { i0: 0, i1: 0, mix: 0 };
  let lastMusic = null;
  const glErrors = {};
  const trialMode = () => document.body.classList.contains("preset-trial-role");
  // Trial-only GL error capture, on one frame in 120 (getError is a synchronous round trip).
  function checkGl(gl, stage) {
    if (!trialMode() || frames % 120 !== 0) return;
    const code = gl.getError();
    if (code) glErrors[stage] = `0x${code.toString(16)}`;
  }

  // ------------------------------------------------------------- GL helpers
  function loc(gl, shader, name) {
    let map = uniformLocations.get(shader);
    if (!map) { map = new Map(); uniformLocations.set(shader, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(shader, name));
    return map.get(name);
  }
  const u1 = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1f(l, v); };
  const u1i = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform1i(l, v); };
  const u2 = (gl, s, n, a, b) => { const l = loc(gl, s, n); if (l !== null) gl.uniform2f(l, a, b); };
  const u3v = (gl, s, n, v) => { const l = loc(gl, s, n); if (l !== null) gl.uniform3f(l, v[0], v[1], v[2]); };
  const u4 = (gl, s, n, a, b, c, d) => { const l = loc(gl, s, n); if (l !== null) gl.uniform4f(l, a, b, c, d); };
  const u4v = (gl, s, n, array) => { const l = loc(gl, s, n); if (l !== null) gl.uniform4fv(l, array); };
  function tex(gl, s, name, unit, texture) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    const l = loc(gl, s, name);
    if (l !== null) gl.uniform1i(l, unit);
  }
  function setCamera(gl, s, suffix, cam) {
    u3v(gl, s, `uPos${suffix}`, cam.position); u3v(gl, s, `uFwd${suffix}`, cam.forward);
    u3v(gl, s, `uRight${suffix}`, cam.right); u3v(gl, s, `uUp${suffix}`, cam.up);
    u1(gl, s, `uTan${suffix}`, cam.tanHalfFov);
  }
  function setCommon(gl, s) {
    u2(gl, s, "uSize", asset.fieldWidth, asset.fieldHeight);
    u1(gl, s, "uAspect", pkg ? pkg.camera.aspect : asset.videoWidth / asset.videoHeight);
  }
  function makeTexture(gl, width, height, { internal = gl.RGBA8, format = gl.RGBA, type = gl.UNSIGNED_BYTE, filter = gl.NEAREST } = {}) {
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, width, height, 0, format, type, null);
    return texture;
  }
  function framebufferFor(gl, textures) {
    const fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    textures.forEach((texture, i) => gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0 + i, gl.TEXTURE_2D, texture, 0));
    gl.drawBuffers(textures.map((_, i) => gl.COLOR_ATTACHMENT0 + i));
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error("Newtons Law framebuffer is incomplete");
    return fbo;
  }
  function fullscreen(gl, prog) { gl.useProgram(prog); setAttribs(prog); gl.drawArrays(gl.TRIANGLES, 0, 3); }

  // ------------------------------------------------------------------ panel
  function makePanel() {
    panel = document.createElement("details");
    panel.className = "forge-hybrid-controls";
    panel.innerHTML = `<summary>Newtons Law controls</summary>
      <label>Reactive amount <input type="range" data-key="reactive" min="0" max="1.5" step="0.01"></label>
      <label>Root lights <input type="range" data-key="lights" min="0" max="1.5" step="0.01"></label>
      <label>Glints <input type="range" data-key="glitter" min="0" max="1.5" step="0.01"></label>
      <label>Filament glow <input type="range" data-key="filaments" min="0" max="1.5" step="0.01"></label>
      <label>Shadows <input type="range" data-key="shadows" min="0" max="1" step="0.01"></label>
      <label>Grade and bloom <input type="range" data-key="grade" min="0" max="1.5" step="0.01"></label>
      <label>Beat offset (ms, + = earlier) <input type="range" data-key="beatOffsetMs" min="-100" max="250" step="5"></label>
      <label>BPM lock <input type="checkbox" data-key="bpmLock"></label>
      <label>Test BPM <select data-key="testBPM"><option value="0">Track</option><option value="140">140</option><option value="145">145</option><option value="150">150</option></select></label>
      <label>Field view <select data-key="debug"><option value="0">Beauty</option><option value="1">Regions</option><option value="2">Normals</option><option value="3">Depth</option><option value="4">Filaments</option><option value="5">Boundary proximity</option><option value="6">Shadows</option><option value="7">Lighting only</option><option value="8">Reactive light only</option><option value="9">Surface mask</option></select></label>`;
    for (const input of panel.querySelectorAll("[data-key]")) {
      const key = input.dataset.key;
      if (input.type === "checkbox") input.checked = controls[key]; else input.value = String(controls[key]);
      input.addEventListener("input", () => { controls[key] = input.type === "checkbox" ? input.checked : Number(input.value); });
    }
    document.body.appendChild(panel);
    return panel;
  }

  // ---------------------------------------------------------------- package
  async function fetchJson(name) {
    const response = await fetch(`${asset.assetRoot}/${name}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`${name}: HTTP ${response.status}`);
    return response.json();
  }
  async function fetchBytes(url) {
    const response = await fetch(url, { cache: "no-store" });
    if (!response.ok) throw new Error(`${url}: HTTP ${response.status}`);
    return new Uint8Array(await response.arrayBuffer());
  }
  async function loadPackage(generation) {
    packageState = "loading";
    try {
      const manifest = await fetchJson(asset.manifest);
      if (manifest.schema !== asset.schema || manifest.version !== asset.packageVersion) {
        throw new Error(`unrecognised runtime package (${manifest.schema} v${manifest.version}; this build reads v${asset.packageVersion}, recompile with scripts/compile-newton-law-runtime.mjs)`);
      }
      const fields = manifest.fields;
      if (fields.width !== asset.fieldWidth || fields.height !== asset.fieldHeight || fields.sampleCount !== asset.sampleCount || fields.rateHz !== asset.fieldRateHz) {
        throw new Error("runtime.json disagrees with newtonLawAsset.js (recompile the package or update the descriptor)");
      }
      if (fields.planes.join() !== LAW_PLANES.join() || fields.filter !== LAW_FILTER.name) throw new Error("runtime.json plane layout or filter differs from this build");
      if (typeof DecompressionStream !== "function" && fields.codec === "deflate") throw new Error("this WebKit has no DecompressionStream; recompile with --codec none");
      const [timeline, landmarks] = await Promise.all([
        fetchJson(manifest.files.timeline),
        manifest.files.landmarks ? fetchBytes(`${asset.assetRoot}/${manifest.files.landmarks}`) : Promise.resolve(null)
      ]);
      if (generation !== token) return;
      manifest.timelineData = timeline;
      landmarkBytes = landmarks;
      pkg = manifest;
      times = sampleTimes(manifest);
      store = createFieldStore({
        runtime: manifest, fetchBytes, urlFor: (name) => `${asset.assetRoot}/${name}`,
        now: () => performance.now(), behind: 3, ahead: 22,
        transformRaw: (raw) => unfilterRows(raw, fields.width, fields.height)
      });
      packageState = "ready";
    } catch (error) {
      if (generation !== token) return;
      packageError = String(error?.message || error);
      packageState = "failed";
      console.warn(`${LOG_PREFIX} runtime field package unavailable; showing the beauty video without its lights.`, packageError);
    }
  }

  // ------------------------------------------------------------- lifecycle
  function start() {
    if (active) return;
    const startedAt = performance.now();
    active = true; token += 1;
    presentedTime = NaN; lastPresented = NaN; presentedFrames = callbackSkips = 0; uploadedFrame = -1; videoTextureReady = false;
    lastAt = 0; lastMediaTime = NaN; loops = seeks = 0; started = false; waitingForBar = true;
    presence = 0; frames = 0;
    pkg = null; store = null; times = null; landmarkBytes = null; landmarkCache.clear();
    packageError = ""; packageState = "idle"; fatal = "";
    targetRate = 1; tempoBPM = 0; tempoAbsent = 0;
    audioModel.reset(); rig.reset();
    for (const key of Object.keys(timings)) timings[key] = 0;
    video = document.createElement("video");
    video.muted = true; video.playsInline = true; video.loop = true; video.preload = "auto";
    video.className = "forge-hybrid-video";
    document.body.appendChild(video);
    window.__newtonsLawVideo = video;
    video.src = encodeURI(`${asset.assetRoot}/${asset.video}`);
    video.load();
    if (video.requestVideoFrameCallback) {
      const generation = token;
      const callback = (_now, info) => {
        if (!active || generation !== token || !video) return;
        if (Number.isFinite(info.mediaTime)) {
          if (Number.isFinite(lastPresented) && info.mediaTime > lastPresented + 1.5 / asset.videoFps && info.mediaTime - lastPresented < 0.5) callbackSkips += 1;
          lastPresented = info.mediaTime;
          presentedTime = info.mediaTime;
          presentedFrames += 1;
        }
        videoCallback = video.requestVideoFrameCallback(callback);
      };
      videoCallback = video.requestVideoFrameCallback(callback);
    }
    const gl = getGl();
    const floatExtension = gl.getExtension("EXT_color_buffer_float") || gl.getExtension("EXT_color_buffer_half_float");
    if (!floatExtension) fatal = "float render targets are unavailable";
    else {
      try { buildGpuResources(gl); }
      catch (error) { fatal = String(error?.message || error); console.error(`${LOG_PREFIX} GPU setup failed:`, error); }
    }
    window.__newtonsLawControls = controls;
    calibration.start();
    const fixture = new URLSearchParams(window.location.search).get("fixture") || "";
    const debugFixtures = {
      "law-regions": 1, "law-normals": 2, "law-depth": 3, "law-filament": 4, "law-proximity": 5,
      "law-shadows": 6, "law-lights": 7, "law-emission": 8, "law-hit": 9
    };
    if (debugFixtures[fixture]) controls.debug = debugFixtures[fixture];
    if (fixture === "law-off") controls.reactive = 0;
    seekFixture = fixture === "law-loop" ? "loop" : fixture === "law-seek" || fixture === "law-off" || debugFixtures[fixture] ? "seek" : "";
    seekFixtureDone = false;
    loadPackage(token);
    startCostMs = performance.now() - startedAt;
  }

  function buildGpuResources(gl) {
    const width = asset.fieldWidth, height = asset.fieldHeight;
    programs = {
      down: program(newtonLawDownsampleSource),
      resolve: program(newtonLawResolveSource),
      shadow: program(newtonLawShadowSource),
      composite: program(newtonLawCompositeSource)
    };
    for (const name of Object.keys(programs)) if (!programs[name]) throw new Error(`Newtons Law ${name} program did not compile`);
    videoTexture = makeTexture(gl, 2, 2, { filter: gl.LINEAR });
    const half = { internal: gl.RGBA16F, format: gl.RGBA, type: gl.HALF_FLOAT };
    for (const slot of slotsTex) {
      slot.index = -1;
      slot.a = makeTexture(gl, width, height);
      slot.b = makeTexture(gl, width, height);
    }
    const resolved = [0, 1, 2].map(() => makeTexture(gl, width, height, { ...half, filter: gl.LINEAR }));
    const shading = [0, 1].map(() => makeTexture(gl, width, height, { ...half, filter: gl.LINEAR }));
    const small = makeTexture(gl, SMALL_WIDTH, SMALL_HEIGHT, { filter: gl.LINEAR });
    targets = {
      resolved, resolveFbo: framebufferFor(gl, resolved),
      shading, shadingFbo: framebufferFor(gl, shading),
      small, smallFbo: framebufferFor(gl, [small])
    };
    for (const fbo of [targets.resolveFbo, targets.shadingFbo, targets.smallFbo]) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  function stop() {
    if (!active) return;
    active = false; token += 1;
    if (video) {
      if (videoCallback && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(videoCallback);
      video.pause(); video.removeAttribute("src"); video.load(); video.remove(); video = null;
    }
    window.__newtonsLawVideo = null; window.__newtonsLawDiagnostics = null; window.__newtonsLawControls = null;
    store?.dispose();
    const gl = getGl();
    if (gl) {
      for (const slot of slotsTex) for (const key of ["a", "b"]) if (slot[key]) { gl.deleteTexture(slot[key]); slot[key] = null; }
      if (videoTexture) gl.deleteTexture(videoTexture);
      if (targets) {
        for (const texture of [...targets.resolved, ...targets.shading, targets.small]) gl.deleteTexture(texture);
        for (const fbo of [targets.resolveFbo, targets.shadingFbo, targets.smallFbo]) gl.deleteFramebuffer(fbo);
      }
      if (programs) for (const shader of Object.values(programs)) if (shader) gl.deleteProgram(shader);
    }
    programs = targets = videoTexture = null;
    store = null; pkg = null; times = null; landmarkBytes = null; landmarkCache.clear();
    calibration.stop(); panel = null;
  }

  // ------------------------------------------------------------------ clock
  function updateTempo(tempo, dt) {
    const measured = controls.testBPM > 0 ? { bpm: controls.testBPM, confidence: 1 } : tempo || {};
    const bpm = Number(measured.bpm) || 0;
    const confidence = Number(measured.confidence ?? 1);
    if (!controls.bpmLock) { targetRate = 1; tempoBPM = 0; tempoAbsent = 0; }
    else if (bpm >= 70 && bpm <= 220 && confidence >= 0.35) {
      tempoAbsent = 0;
      if (!tempoBPM || Math.abs(bpm - tempoBPM) >= 0.8) {
        tempoBPM = bpm;
        targetRate = forgePlaybackTarget({ bpm, confidence }, pkg?.tempo.referenceBPM || asset.referenceBPM);
      }
    } else if ((tempoAbsent += dt) > 5) { targetRate = 1; tempoBPM = 0; }
    if (video) {
      const next = video.playbackRate + clamp(targetRate - video.playbackRate, -dt * 0.14, dt * 0.14);
      if (Math.abs(next - video.playbackRate) > 0.0002) video.playbackRate = next;
    }
  }

  function beatsPerSecond(tempo) {
    const bpm = controls.testBPM > 0 ? controls.testBPM : Number(tempo?.bpm) || 0;
    const confidence = controls.testBPM > 0 ? 1 : Number(tempo?.confidence ?? 1);
    if (bpm >= 70 && bpm <= 220 && confidence >= 0.35) return bpm / 60;
    return (pkg?.tempo.referenceBPM || asset.referenceBPM) * (video?.playbackRate || 1) / 60;
  }

  // ---------------------------------------------------------------- samples
  function uploadSample(gl, slot, index, entry) {
    const stamp = performance.now();
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, slot.a);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, asset.fieldWidth, asset.fieldHeight, gl.RGBA, gl.UNSIGNED_BYTE, entry.a);
    gl.bindTexture(gl.TEXTURE_2D, slot.b);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, asset.fieldWidth, asset.fieldHeight, gl.RGBA, gl.UNSIGNED_BYTE, entry.b);
    slot.index = index;
    timings.upload += performance.now() - stamp;
  }

  function bindSamples(gl, i0, i1, e0, e1) {
    const need = [[i0, e0], [i1, e1]];
    const map = [null, null];
    for (let k = 0; k < 2; k += 1) {
      const found = slotsTex.find((slot) => slot.index === need[k][0]);
      if (found) map[k] = found;
    }
    for (let k = 0; k < 2; k += 1) {
      if (map[k]) continue;
      if (k === 1 && need[1][0] === need[0][0]) { map[1] = map[0]; continue; }
      const [index, entry] = need[k];
      const free = slotsTex.find((slot) => slot !== map[0] && slot !== map[1] && slot.index !== need[1 - k][0]) || slotsTex.find((slot) => slot !== map[1 - k]);
      uploadSample(gl, free, index, entry);
      map[k] = free;
    }
    return map;
  }

  // The playing frame -> a texture (the accelerated path: unsized RGBA, no flip), and its small copy.
  function uploadVideo(gl, videoReady, exporting) {
    if (!videoReady || !programs) return;
    const fresh = exporting || !video.requestVideoFrameCallback || presentedFrames !== uploadedFrame || !videoTextureReady;
    if (!fresh) return;
    const stamp = performance.now();
    try {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, videoTexture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
      uploadedFrame = presentedFrames;
      videoTextureReady = true;
    } catch (error) { if (frames < 400) console.warn(`${LOG_PREFIX} video texture:`, error); return; }
    gl.bindFramebuffer(gl.FRAMEBUFFER, targets.smallFbo);
    gl.viewport(0, 0, SMALL_WIDTH, SMALL_HEIGHT);
    gl.useProgram(programs.down);
    tex(gl, programs.down, "uVideo", 0, videoTexture);
    u2(gl, programs.down, "uSmallSize", SMALL_WIDTH, SMALL_HEIGHT);
    fullscreen(gl, programs.down);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    timings.video += performance.now() - stamp;
  }

  function landmarksFor(index) {
    let list = landmarkCache.get(index);
    if (!list) {
      list = parseLandmarks(landmarkBytes, index);
      landmarkCache.set(index, list);
      if (landmarkCache.size > 64) landmarkCache.delete(landmarkCache.keys().next().value);
    }
    return list;
  }

  function sceneAt(timeline, located) {
    const { i0, i1, mix } = located;
    const lerp = (array, stride, offset) => array[i0 * stride + offset] + (array[i1 * stride + offset] - array[i0 * stride + offset]) * mix;
    scene.plane.cx = lerp(timeline.plane, 4, 0);
    scene.plane.cy = lerp(timeline.plane, 4, 1);
    scene.plane.scale = lerp(timeline.plane, 4, 2);
    scene.plane.rotation = lerp(timeline.plane, 4, 3);
    scene.reliefHeight = lerp(timeline.reliefHeight, 1, 0);
    scene.landmarks = landmarkBytes ? interpolateLandmarks(landmarksFor(i0), landmarksFor(i1), mix) : null;
    return scene;
  }

  // ------------------------------------------------------------------ render
  // A failing frame must never take the player down: report it once and keep the video visible.
  let renderError = "";
  function render(frame) {
    try { renderFrame(frame); }
    catch (error) {
      if (!renderError) {
        renderError = String(error?.stack || error);
        console.error(`${LOG_PREFIX} render failed:`, renderError);
        if (trialMode()) window.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "error", text: `${LOG_PREFIX} render failed: ${renderError}` });
      }
      const gl = getGl();
      gl.bindFramebuffer(gl.FRAMEBUFFER, frame.target.fb);
      gl.viewport(0, 0, frame.width, frame.height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
  }

  function renderFrame({ target, width, height, now, tempo, playing = true, music, audio, smooth }) {
    if (!active) start();
    const gl = getGl();
    const dt = lastAt ? clamp((now - lastAt) / 1000, 0, 0.05) : 1 / 60;
    lastAt = now;
    const videoReady = video.readyState >= 2 && video.videoWidth === asset.videoWidth && video.videoHeight === asset.videoHeight;
    const exporting = document.body.classList.contains("exporting-video");
    const glVideo = Boolean(programs && targets && !fatal);
    video.style.display = exporting ? "none" : "block";
    updateTempo(tempo, dt);
    if (!playing && !video.paused) video.pause();
    if (playing && videoReady && video.paused && !playingPending) {
      const beat = Number(music?.absoluteBeat);
      const canAlign = controls.bpmLock && tempo?.bpm > 0 && Number.isFinite(beat) && beat >= 0;
      const beatsPerBar = pkg?.tempo.beatsPerBar || 4;
      const phase = canAlign ? ((beat % beatsPerBar) + beatsPerBar) % beatsPerBar : 0;
      if (started || !canAlign || !waitingForBar || phase < 0.12 || phase > beatsPerBar - 0.10) {
        started = true; waitingForBar = false; playingPending = true;
        video.play().catch((error) => { if (frames < 400) console.warn(`${LOG_PREFIX} video playback:`, error); })
          .finally(() => { playingPending = false; });
      }
    }
    if (videoReady && seekFixture && !seekFixtureDone) {
      // Development fixtures: jump the real video near the end (loop) or into the Newton phase (seek).
      video.currentTime = seekFixture === "loop" ? Math.max(0, asset.durationSeconds - 3) : 47;
      seekFixtureDone = true;
    }
    const mediaTime = Number.isFinite(presentedTime) ? presentedTime : (video.currentTime || 0);
    const step = classifyTimeStep(lastMediaTime, mediaTime, asset.durationSeconds, dt, video.playbackRate || 1);
    if (step === "loop") loops += 1;
    if (step === "seek") seeks += 1;
    lastMediaTime = mediaTime;
    frames += 1;
    const stamp0 = performance.now();

    const bps = beatsPerSecond(tempo);
    lastMusic = music;
    const events = audioModel.step(playing ? dt : 0, { audio, smooth, music }, { reactive: controls.reactive, beatsPerSecond: bps, leadSeconds: controls.beatOffsetMs / 1000 });

    if (!glVideo) {
      // No GPU path: leave the canvas transparent and let the <video> element show through.
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, width, height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      report(gl, { now, mediaTime, videoReady, fieldReady: false, playing, glVideo });
      return;
    }
    uploadVideo(gl, videoReady, exporting);

    let fieldReady = false;
    if (packageState === "ready") {
      const located = locateSample(times, clamp(mediaTime, 0, pkg.beauty.durationSeconds));
      currentIndices = located;
      store.prefetch(located.i0, located.i0 === located.i1 ? [located.i0] : [located.i0, located.i1]);
      const e0 = store.get(located.i0), e1 = store.get(located.i1);
      fieldReady = Boolean(e0 && e1);
      if (fieldReady) {
        const timeline = pkg.timelineData;
        cameraAt(timeline, located.i0, located.i0, 0, cam0);
        cameraAt(timeline, located.i1, located.i1, 0, cam1);
        cameraAt(timeline, located.i0, located.i1, located.mix, camN);
        morphAt(timeline, located.i0, located.i1, located.mix, morph);
        rig.step(playing ? dt : 0, events, audioModel.state, sceneAt(timeline, located), { reactive: controls.reactive * controls.lights });
        rig.writeUniforms(lightA, lightB, lightC);
        const [slot0, slot1] = bindSamples(gl, located.i0, located.i1, e0, e1);
        drawFields(gl, located, slot0, slot1);
      }
    }
    presence += ((fieldReady ? 1 : 0) - presence) * (1 - Math.exp(-dt * (fieldReady ? 7 : 9)));
    drawComposite(gl, { target, width, height, mediaTime, fieldReady });
    timings.frames += 1;
    timings.total += performance.now() - stamp0;
    report(gl, { now, mediaTime, videoReady, fieldReady, playing, glVideo });
  }

  function drawFields(gl, located, slot0, slot1) {
    gl.disable(gl.BLEND);
    let stamp = performance.now();
    gl.bindFramebuffer(gl.FRAMEBUFFER, targets.resolveFbo);
    gl.viewport(0, 0, asset.fieldWidth, asset.fieldHeight);
    const resolve = programs.resolve;
    gl.useProgram(resolve);
    setCommon(gl, resolve);
    tex(gl, resolve, "uA0", 0, slot0.a); tex(gl, resolve, "uB0", 1, slot0.b);
    tex(gl, resolve, "uA1", 2, slot1.a); tex(gl, resolve, "uB1", 3, slot1.b);
    u1(gl, resolve, "uMix", located.mix);
    setCamera(gl, resolve, "0", cam0); setCamera(gl, resolve, "1", cam1); setCamera(gl, resolve, "N", camN);
    fullscreen(gl, resolve);
    checkGl(gl, "resolve");
    timings.resolve += performance.now() - stamp;

    stamp = performance.now();
    gl.bindFramebuffer(gl.FRAMEBUFFER, targets.shadingFbo);
    const shadow = programs.shadow;
    gl.useProgram(shadow);
    setCommon(gl, shadow);
    tex(gl, shadow, "uN", 0, targets.resolved[0]);
    tex(gl, shadow, "uC", 1, targets.resolved[2]);
    u4v(gl, shadow, "uLightA[0]", lightA);
    u4v(gl, shadow, "uLightB[0]", lightB);
    u1(gl, shadow, "uShadowSteps", controls.shadows > 0 ? 12 : 0);
    setCamera(gl, shadow, "N", camN);
    fullscreen(gl, shadow);
    // Leave the field framebuffers before anything samples their textures.
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    checkGl(gl, "shadow");
    timings.shadow += performance.now() - stamp;
  }

  function viewRect(width, height) {
    const aspect = asset.videoWidth / asset.videoHeight;
    return width / Math.max(1, height) > aspect ? [height * aspect, height] : [width, width / aspect];
  }

  function drawComposite(gl, { target, width, height, mediaTime, fieldReady }) {
    const stamp = performance.now();
    const state = audioModel.state, look = rig.state;
    const grade = clamp(controls.grade, 0, 1.5);
    const [viewW, viewH] = viewRect(width, height);
    const fade = pkg ? presence * loopFade(mediaTime, pkg.beauty.durationSeconds, pkg.loop.fadeSeconds, loops > 0) : 0;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    gl.disable(gl.BLEND);
    const prog = programs.composite;
    gl.useProgram(prog);
    setCommon(gl, prog);
    tex(gl, prog, "uVideo", 0, videoTexture);
    tex(gl, prog, "uSmall", 1, targets.small);
    tex(gl, prog, "uN", 2, targets.resolved[0]);
    tex(gl, prog, "uS", 3, targets.resolved[1]);
    tex(gl, prog, "uC", 4, targets.resolved[2]);
    tex(gl, prog, "uShadow", 5, targets.shading[0]);
    tex(gl, prog, "uMask", 6, targets.shading[1]);
    u1(gl, prog, "uCanvasAspect", width / Math.max(1, height));
    u1(gl, prog, "uVideoAspect", asset.videoWidth / asset.videoHeight);
    u2(gl, prog, "uViewPx", viewW, viewH);
    u1i(gl, prog, "uDebug", fieldReady ? controls.debug : 0);
    u1(gl, prog, "uFade", fieldReady ? fade : 0);
    const scaled = (value) => 1 + (value - 1) * grade;
    u4(gl, prog, "uGrade", scaled(state.exposure), scaled(state.saturation), scaled(state.contrast), state.haze * grade);
    const lights = clamp(controls.lights, 0, 1.5);
    u4(gl, prog, "uLook", look.dim * lights, 2.4 * lights, look.glitter * controls.glitter, look.filamentGlow * controls.filaments);
    u4(gl, prog, "uLook2", state.bloom * grade, look.flow, clamp(controls.shadows, 0, 1), 0);
    u4v(gl, prog, "uLightA[0]", lightA);
    u4v(gl, prog, "uLightB[0]", lightB);
    u4v(gl, prog, "uLightC[0]", lightC);
    if (camN.position) setCamera(gl, prog, "N", camN);
    fullscreen(gl, prog);
    checkGl(gl, "composite");
    timings.composite += performance.now() - stamp;
  }

  // ---------------------------------------------------------------- report
  function lightScreenPositions() {
    if (!camN.position) return [];
    return rig.lights.slice(0, 3).map((light) => {
      const d = light.position.map((v, k) => v - camN.position[k]);
      const z = d[0] * camN.forward[0] + d[1] * camN.forward[1] + d[2] * camN.forward[2];
      if (z <= 0.001) return null;
      const sx = (d[0] * camN.right[0] + d[1] * camN.right[1] + d[2] * camN.right[2]) / (z * camN.tanHalfFov);
      const sy = (d[0] * camN.up[0] + d[1] * camN.up[1] + d[2] * camN.up[2]) / (z * camN.tanHalfFov);
      return [Number((0.5 + 0.5 * sx / camN.aspect).toFixed(3)), Number((0.5 - 0.5 * sy).toFixed(3))];
    });
  }

  function report(gl, { now, mediaTime, videoReady, fieldReady, playing, glVideo }) {
    if (panel && now - lastLabelAt > 500) {
      panel.querySelector("summary").textContent = packageState === "failed" || fatal
        ? "Newtons Law · video only"
        : `Newtons Law · ${video.playbackRate.toFixed(3)}× · sample ${currentIndices.i0}${fieldReady ? "" : " (loading)"}`;
      lastLabelAt = now;
    }
    const trial = trialMode();
    if (now - reportAt < (trial ? 2000 : 5000)) return;
    fps = reportAt ? (frames - reportFrames) * 1000 / (now - reportAt) : 0;
    reportAt = now; reportFrames = frames;
    const quality = video.getVideoPlaybackQuality?.();
    const per = (value) => value / Math.max(1, timings.frames);
    const state = audioModel.state, look = rig.state;
    window.__newtonsLawDiagnostics = {
      fps, videoTime: mediaTime, sampleIndices: [currentIndices.i0, currentIndices.i1], mix: currentIndices.mix,
      fieldReady, videoReady, glVideo, presence, playing, loops, seeks,
      playbackRate: video.playbackRate, targetRate, packageState, packageError, fatal,
      presentedFrames, callbackSkips,
      droppedVideoFrames: quality?.droppedVideoFrames ?? 0, totalVideoFrames: quality?.totalVideoFrames ?? 0,
      store: store ? { ...store.stats, resident: store.size() } : null,
      morph: { ...morph },
      music: {
        beat: state.beat, beatSource: state.beatSource, groove: state.groove, build: state.build, breakdown: state.breakdown,
        bassDrive: state.bassDrive, midDrive: state.midDrive, highDrive: state.highDrive, energyDrive: state.energyDrive,
        pump: state.pump, dropFlash: state.dropFlash, kickCount: state.kickCount, hatCount: state.hatCount, dropCount: state.dropCount,
        rollCount: state.rollCount, tideCount: state.tideCount
      },
      rig: {
        presence: look.presence,
        accents: look.accents.map((value) => Number(value.toFixed(3))), strobe: look.strobe, swell: look.swell, burst: look.burst,
        dim: look.dim, glitter: look.glitter, filamentGlow: look.filamentGlow,
        lights: rig.lights.map((light) => ({ position: light.position.map((v) => Number(v.toFixed(3))), intensity: Number(light.intensity.toFixed(3)), cone: Number(light.cone.toFixed(3)) })),
        slots: rig.slots.map((slot) => ({ id: slot.id, kind: slot.kind, region: slot.region, radius: Number(slot.radius.toFixed(3)), lostFor: Number(slot.lostFor.toFixed(2)), gliding: slot.gliding })),
        landmarks: scene.landmarks?.length || 0, sweepAzimuth: Number(look.sweepAzimuth.toFixed(3)),
        screen: lightScreenPositions()
      },
      startCostMs, glErrors: { ...glErrors }, renderError,
      musicAware: trial && lastMusic ? { role: lastMusic.role, buildUp: lastMusic.buildUp, breakdown: lastMusic.breakdown, calm: lastMusic.calm, drop: lastMusic.drop } : undefined,
      cpuMs: { video: per(timings.video), resolve: per(timings.resolve), shadow: per(timings.shadow), composite: per(timings.composite), upload: per(timings.upload), total: per(timings.total) },
      decodedWindowMB: store ? store.size() * (pkg?.fields.rawSampleBytes || 0) / 1048576 : 0
    };
    if (trial) window.webkit?.messageHandlers?.nativeApp?.postMessage({
      command: "logConsole", type: "info", text: `${LOG_PREFIX} ${JSON.stringify(window.__newtonsLawDiagnostics)}`
    });
  }

  return { render, stop, controls, isActive: () => active };
}
