const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const ease = (low, high, value) => { const t = clamp((value - low) / (high - low), 0, 1); return t * t * (3 - 2 * t); };
const MAX_TRACKS = 24;
const MAX_CANDIDATES = 128;
const SEGMENTS = 28;
const STRIDE = 10;
const MAX_STROKES = 16;

// A finite onset travelling down a wake is legible after the sound has passed.
// A sustained loud band must not re-trigger it on every render or every beat.
function makeOnsetState() {
  return { previous: 0, baseline: 0, range: 0.10, armed: true, lastAt: -1000 };
}

// The exported fields do not label spores and their flow excludes camera
// movement. Compact, detached, bright components are therefore measured in the
// current fields. Only their observed screen motion persists between scans.
// No release time, old screen position or invented spore explosion is used.
export function createForgeCalligraphy(width, height) {
  const vertices = new Float32Array(MAX_TRACKS * SEGMENTS * 2 * 6 * STRIDE);
  const visited = new Uint16Array(width * height);
  const queue = new Int32Array(width * height);
  const candidates = new Float32Array(MAX_CANDIDATES * 8);
  const tracks = Array.from({ length: MAX_TRACKS }, (_, id) => ({
    id, active: false, x: 0, y: 0, radius: 0, vx: 0, vy: 0, flowX: 0, flowY: 0,
    confidence: 0, age: 0, seen: 0, observations: 0, movement: 0, matched: false,
  }));
  const state = { energy: 0, mids: 0, highs: 0, anticipation: 0, breakdown: 0, release: 0, releaseAge: 0, phase: 0, phrase: 0,
    midAccent: 0, highAccent: 0, midStrokeCount: 0, highStrokeCount: 0,
    buildTension: 0, breath: 0, time: 0, strokeSpeed: 1.4, stitchDensity: 4 };
  const midOnset = makeOnsetState(), highOnset = makeOnsetState();
  const strokes = Array.from({ length: MAX_STROKES }, () => ({ active: false, type: 0, strength: 0, age: 0 }));
  let nextStroke = 0, lastBeat = -1;

  function launchStroke(type, strength) {
    const stroke = strokes[nextStroke];
    nextStroke = (nextStroke + 1) % MAX_STROKES;
    stroke.active = true; stroke.type = type; stroke.strength = strength; stroke.age = 0;
    if (type === 0) { state.midAccent = Math.max(state.midAccent, strength); state.midStrokeCount++; }
    else { state.highAccent = Math.max(state.highAccent, strength); state.highStrokeCount++; }
  }
  function followOnset(detector, value, delta, type) {
    if (delta <= 0) return;
    const previousBaseline = detector.baseline;
    const rise = Math.max(0, value - detector.previous);
    const deviation = Math.max(0, value - previousBaseline);
    detector.range = Math.max(0.07, deviation, detector.range * Math.exp(-delta / 6));
    const threshold = Math.max(type === 0 ? 0.028 : 0.023, detector.range * 0.18);
    // Re-arm only after the onset has subsided. Small mastering/analyser jitter
    // does not qualify; real successive hats/notes can still articulate a roll.
    if (rise < threshold * 0.2 || value < previousBaseline + threshold * 0.5) detector.armed = true;
    if (detector.armed && rise > threshold && deviation > threshold * 0.7 && state.time - detector.lastAt > (type === 0 ? 0.12 : 0.055)) {
      launchStroke(type, clamp(0.30 + rise / Math.max(0.09, detector.range) * 0.7, 0.30, 1));
      detector.armed = false; detector.lastAt = state.time;
    }
    detector.baseline += (value - detector.baseline) * (1 - Math.exp(-delta / 0.7));
    detector.previous = value;
  }
  function travellingInk(position, strandPhase) {
    let strength = 0;
    for (const stroke of strokes) {
      if (!stroke.active) continue;
      // The spore is the current source: musical strokes leave its head then
      // run into its measured wake. The finest hats take a quicker/narrower path.
      const speed = state.strokeSpeed * (stroke.type === 1 ? 1.6 : 1);
      const front = stroke.age * speed - (strandPhase % 1) * 0.035;
      const width = stroke.type === 1 ? 0.045 : 0.13;
      const distance = (position - front) / width;
      const peak = Math.exp(-distance * distance);
      strength += peak * stroke.strength * (stroke.type === 1 ? 0.92 : 1.10);
      // A quieter, dissipating stroke behind the front carries short memory.
      if (stroke.type === 0 && position < front) strength += Math.exp(-(front - position) * 12) * stroke.strength * 0.22;
    }
    return Math.min(1.65, strength);
  }
  const diagnostics = { scans: 0, scanMs: 0, candidates: 0, tracks: 0, visible: 0, vertices: 0,
    bufferBytes: vertices.byteLength + visited.byteLength + queue.byteLength + candidates.byteLength };
  const local = new Float32Array(4);
  let epoch = 0, lastScan = -1, lastScanTime = -1, lastVideoTime = -1;
  let pair = null, mix = 0, count = 0, used = 0;

  function sample(x, y, out = local) {
    const px = clamp(x - 0.5, 0, width - 1), py = clamp(y - 0.5, 0, height - 1);
    const ix = Math.floor(px), iy = Math.floor(py), fx = px - ix, fy = py - iy;
    const jx = Math.min(ix + 1, width - 1), jy = Math.min(iy + 1, height - 1);
    const i00 = (iy * width + ix) * 4, i10 = (iy * width + jx) * 4;
    const i01 = (jy * width + ix) * 4, i11 = (jy * width + jx) * 4;
    const a = (1 - fx) * (1 - fy), b = fx * (1 - fy), c = (1 - fx) * fy, d = fx * fy;
    for (let component = 0; component < 4; component++) {
      const channel = component === 0 ? 0 : component - 1;
      const p0 = component === 0 ? pair.a.densityPixels : pair.a.flowPixels;
      const p1 = component === 0 ? pair.b.densityPixels : pair.b.flowPixels;
      const v0 = p0[i00 + channel] * a + p0[i10 + channel] * b + p0[i01 + channel] * c + p0[i11 + channel] * d;
      const v1 = p1[i00 + channel] * a + p1[i10 + channel] * b + p1[i01 + channel] * c + p1[i11 + channel] * d;
      const value = v0 + (v1 - v0) * mix;
      out[component] = component === 1 || component === 2 ? (value - 128) / 127 : value / 255;
    }
    return out;
  }

  function detect() {
    const started = performance.now();
    const current = mix < 0.5 ? pair.a : pair.b;
    const density = current.densityPixels, flow = current.flowPixels;
    epoch = (epoch + 1) & 65535;
    if (!epoch) { visited.fill(0); epoch = 1; }
    count = 0;
    for (let seed = 0; seed < width * height; seed++) {
      if (visited[seed] === epoch || density[seed * 4] < 179) continue;
      queue[0] = seed; visited[seed] = epoch;
      let read = 0, size = 1, sumX = 0, sumY = 0, weight = 0, confidence = 0, flowX = 0, flowY = 0;
      let x0 = width, x1 = 0, y0 = height, y1 = 0;
      while (read < size) {
        const index = queue[read++], x = index % width, y = Math.floor(index / width), offset = index * 4;
        const w = density[offset] / 255;
        sumX += (x + 0.5) * w; sumY += (y + 0.5) * w; weight += w;
        confidence += flow[offset + 2] / 255;
        flowX += (flow[offset] - 128) / 127; flowY += (flow[offset + 1] - 128) / 127;
        x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y);
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx, ny = y + dy, next = ny * width + nx;
          if (nx < 0 || ny < 0 || nx >= width || ny >= height || visited[next] === epoch || density[next * 4] < 179) continue;
          visited[next] = epoch; queue[size++] = next;
        }
      }
      // Ordinary veins, hubs, partial silhouettes and tiny isolated noise fail
      // one or more of compactness, bounded size, confidence and empty moat.
      if (size < 3 || size > 160 || confidence / size < 0.54) continue;
      const bw = x1 - x0 + 1, bh = y1 - y0 + 1;
      if (Math.max(bw, bh) / Math.min(bw, bh) > 2 || size / (bw * bh) < 0.5) continue;
      if (x0 < 3 || y0 < 3 || x1 >= width - 3 || y1 >= height - 3) continue;
      let isolated = true;
      for (let y = y0 - 3; y <= y1 + 3 && isolated; y++) for (let x = x0 - 3; x <= x1 + 3; x++) {
        if (x >= x0 - 1 && x <= x1 + 1 && y >= y0 - 1 && y <= y1 + 1) continue;
        if (density[(y * width + x) * 4] > 20) { isolated = false; break; }
      }
      if (!isolated || count >= MAX_CANDIDATES) continue;
      const offset = count++ * 8;
      candidates[offset] = sumX / weight; candidates[offset + 1] = sumY / weight;
      candidates[offset + 2] = Math.sqrt(size / Math.PI);
      candidates[offset + 3] = confidence / size;
      candidates[offset + 4] = flowX / size; candidates[offset + 5] = flowY / size;
      candidates[offset + 6] = size; candidates[offset + 7] = 0;
    }
    diagnostics.scans++; diagnostics.scanMs = performance.now() - started; diagnostics.candidates = count;
  }

  function associate(videoTime) {
    const elapsed = lastScanTime < 0 ? 0.1 : clamp(videoTime - lastScanTime, 0.02, 0.2);
    const maxDistance = Math.max(12, width * 0.075);
    for (const track of tracks) track.matched = false;
    // Existing tracks get first choice so new candidates cannot steal their
    // identities. Prediction is only a nearest-component search aid.
    for (const track of tracks) {
      if (!track.active) continue;
      let best = -1, score = Infinity;
      const px = track.x + track.vx * elapsed, py = track.y + track.vy * elapsed;
      for (let index = 0; index < count; index++) {
        const offset = index * 8;
        if (candidates[offset + 7]) continue;
        const distance = Math.hypot(candidates[offset] - px, candidates[offset + 1] - py);
        const sizeDifference = Math.abs(Math.log(Math.max(0.1, candidates[offset + 2] / track.radius)));
        const candidateScore = distance + sizeDifference * 5;
        if (distance < maxDistance && sizeDifference < 0.8 && candidateScore < score) { score = candidateScore; best = index; }
      }
      if (best < 0) continue;
      const offset = best * 8, x = candidates[offset], y = candidates[offset + 1];
      const dx = x - track.x, dy = y - track.y;
      track.vx = track.vx * 0.35 + dx / elapsed * 0.65;
      track.vy = track.vy * 0.35 + dy / elapsed * 0.65;
      track.movement = track.movement * 0.5 + Math.hypot(dx, dy) / elapsed * 0.5;
      track.x = x; track.y = y; track.radius = candidates[offset + 2]; track.confidence = candidates[offset + 3];
      track.flowX = candidates[offset + 4]; track.flowY = candidates[offset + 5];
      track.seen = 0; track.matched = true; track.observations++; candidates[offset + 7] = 1;
    }
    for (let index = 0; index < count; index++) {
      const offset = index * 8;
      if (candidates[offset + 7]) continue;
      const track = tracks.find((item) => !item.active || item.seen > 0.24);
      if (!track) break;
      track.active = true; track.x = candidates[offset]; track.y = candidates[offset + 1];
      track.radius = candidates[offset + 2]; track.confidence = candidates[offset + 3];
      track.flowX = candidates[offset + 4]; track.flowY = candidates[offset + 5];
      track.age = track.seen = track.vx = track.vy = track.movement = 0;
      track.observations = 1; track.matched = true;
    }
    lastScanTime = videoTime;
  }

  function refine(track, videoTime) {
    // Centroids are remeasured against the displayed interpolated pair at every
    // render. This prevents a 10 Hz detector from visibly stepping the anchor.
    const elapsed = clamp(videoTime - lastScanTime, 0, 0.13);
    const px = track.x + track.vx * elapsed, py = track.y + track.vy * elapsed;
    const radius = Math.ceil(track.radius + 3);
    let sumX = 0, sumY = 0, weight = 0, pixels = 0;
    for (let y = Math.max(0, Math.floor(py - radius)); y <= Math.min(height - 1, Math.ceil(py + radius)); y++) {
      for (let x = Math.max(0, Math.floor(px - radius)); x <= Math.min(width - 1, Math.ceil(px + radius)); x++) {
        sample(x + 0.5, y + 0.5);
        if (local[0] < 0.65 || local[3] < 0.50) continue;
        const w = local[0] * local[3]; sumX += (x + 0.5) * w; sumY += (y + 0.5) * w; weight += w; pixels++;
      }
    }
    if (weight < 1.5 || pixels > 160 || pixels > Math.PI * track.radius * track.radius * 2.4) return false;
    const x = sumX / weight, y = sumY / weight;
    sample(x, y);
    if (local[0] < 0.65 || local[3] < 0.50) return false;
    local[0] = x; local[1] = y; local[2] = Math.sqrt(pixels / Math.PI);
    return true;
  }

  function emit(x, y, nx, ny, position, side, power, phase, sourceX, sourceY) {
    vertices[used++] = x; vertices[used++] = y; vertices[used++] = nx; vertices[used++] = ny;
    vertices[used++] = position; vertices[used++] = side; vertices[used++] = power; vertices[used++] = phase;
    vertices[used++] = sourceX / width; vertices[used++] = sourceY / height;
  }

  function update({ fields, fieldMix = 0, videoTime, dt, audio = {}, bands = {}, music = {}, cues = {}, amount = 1 }) {
    used = 0; diagnostics.visible = 0;
    if (!fields?.a?.densityPixels || !fields?.b?.densityPixels) { diagnostics.vertices = 0; return 0; }
    if (lastVideoTime >= 0 && (videoTime < lastVideoTime || videoTime - lastVideoTime > 0.35)) reset();
    lastVideoTime = videoTime; pair = fields; mix = clamp(fieldMix, 0, 1);
    const delta = clamp(Number(dt) || 0, 0, 0.10);
    for (const name of ["energy", "mids", "highs", "anticipation", "breakdown", "release"]) {
      const input = name === "energy" ? cues.energy ?? audio.globalEnergy ?? music.adaptiveIntensity :
        name === "mids" || name === "highs" ? cues[name] ?? bands[name] :
          cues[name] ?? music[name === "anticipation" ? "upcomingDrop" : name];
      const target = clamp(Number(input) || 0, 0, 1);
      state[name] += (target - state[name]) * (1 - Math.exp(-delta / (target > state[name] ? 0.16 : 0.8)));
    }
    state.time += delta;
    state.midAccent *= Math.exp(-delta / 0.32);
    state.highAccent *= Math.exp(-delta / 0.16);
    for (const stroke of strokes) {
      stroke.age += delta;
      if (stroke.age > 1.1) stroke.active = false;
    }
    followOnset(midOnset, clamp(Number(audio.midNow ?? bands.mids) || 0, 0, 1), delta, 0);
    followOnset(highOnset, clamp(Number(audio.trebleNow ?? bands.highs) || 0, 0, 1), delta, 1);
    const beat = Number(cues.beat ?? music.absoluteBeat);
    const beatDelta = Number.isFinite(beat) && lastBeat >= 0 ? beat - lastBeat : 0;
    const beatsPerSecond = beatDelta > 0 && beatDelta < 1 && delta > 0 ? clamp(beatDelta / delta, 1, 4) : 2.4;
    if (Number.isFinite(beat)) lastBeat = beat;
    const build = clamp(Math.max(Number(music.buildUp ?? music.build) || 0, state.anticipation), 0, 1);
    state.buildTension += (build - state.buildTension) * (1 - Math.exp(-delta / 0.40));
    state.strokeSpeed = beatsPerSecond * (0.50 + state.mids * 0.22 + state.buildTension * 0.12);
    state.stitchDensity = 3 + state.highs * 6 + state.buildTension * 4;
    state.phase += delta * (0.85 + state.mids * 2.4 + state.midAccent * 2.6) + state.highAccent * delta * 0.8;
    state.breath = Math.sin((Number(cues.phrase8) || 0) * Math.PI * 2) * (0.08 + state.mids * 0.10);
    state.phrase = Number(cues.phrase16 ?? music.phraseProgress) || 0;
    state.releaseAge = Number.isFinite(Number(cues.releaseAge)) ? Math.max(0, Number(cues.releaseAge)) : state.releaseAge + delta;
    for (const track of tracks) {
      if (!track.active) continue;
      track.age += delta; track.seen += delta;
      if (track.seen > 0.30) track.active = false;
    }
    const scan = Math.floor(videoTime * 10);
    if (scan !== lastScan) { detect(); associate(videoTime); lastScan = scan; }
    diagnostics.tracks = 0;
    for (const track of tracks) {
      if (!track.active) continue;
      diagnostics.tracks++;
      if (track.observations < 2 || track.movement < 2.2 || !refine(track, videoTime)) continue;
      const sx = local[0], sy = local[1], radius = local[2];
      let dx = track.vx, dy = track.vy, speed = Math.hypot(dx, dy);
      if (speed < 1) { dx = track.flowX; dy = track.flowY; speed = Math.hypot(dx, dy); }
      if (speed < 0.15) continue;
      dx /= speed; dy /= speed;
      const nx = -dy, ny = dx, phase = track.id * 1.714;
      const support = ease(0.52, 0.92, track.confidence);
      const fade = ease(0.06, 0.32, track.age) * (1 - ease(0.14, 0.30, track.seen));
      // Even quiet passages leave a readable hairline behind a real spore.
      // Musical energy changes the detail and travelling strokes, while the
      // sparse, bounded detector controls how much of the screen is occupied.
      const power = fade * support * clamp(amount, 0, 1.6) * (0.42 + state.energy * 0.38) * (1 - state.breakdown * 0.30);
      if (power < 0.015) continue;
      diagnostics.visible++;
      const length = clamp(10 + radius * 2.4 + Math.min(speed, 100) * 0.065 + state.mids * 8 + state.midAccent * 9 + state.release * 13, 10, 43) * (1 - state.buildTension * 0.34);
      const weave = (0.55 + state.mids * 0.60 + state.midAccent * 0.48 + state.breath) * (1 - state.buildTension * 0.42);
      // A short calligraphic wake, rebuilt from the actual displayed spore.
      // Opposite hairlines braid gently; no independent generated spores exist.
      for (let strand = 0; strand < 2; strand++) {
        const strandPhase = phase + strand * Math.PI;
        for (let segment = 0; segment < SEGMENTS; segment++) {
          const t0 = segment / SEGMENTS, t1 = (segment + 1) / SEGMENTS;
          const bend0 = Math.sin(t0 * (4.4 + state.mids * 1.5) - state.phase + strandPhase) * (0.3 + t0 * 2.2) * weave * ease(0, 0.25, t0);
          const bend1 = Math.sin(t1 * (4.4 + state.mids * 1.5) - state.phase + strandPhase) * (0.3 + t1 * 2.2) * weave * ease(0, 0.25, t1);
          const aX = sx - dx * (radius * 0.75 + length * t0) + nx * bend0;
          const aY = sy - dy * (radius * 0.75 + length * t0) + ny * bend0;
          const bX = sx - dx * (radius * 0.75 + length * t1) + nx * bend1;
          const bY = sy - dy * (radius * 0.75 + length * t1) + ny * bend1;
          const tx = bX - aX, ty = bY - aY, norm = Math.hypot(tx, ty);
          const normalX = -ty / norm, normalY = tx / norm;
          // Dark resting ink and moving accents expose the actual rhythm; an
          // ordinary sustained band changes shape but cannot manufacture beats.
          const accent0 = travellingInk(t0, strandPhase), accent1 = travellingInk(t1, strandPhase);
          const base = 0.30 + state.mids * 0.10 + state.release * 0.12;
          const power0 = power * (base + accent0), power1 = power * (base + accent1);
          emit(aX, aY, normalX, normalY, t0, -1, power0, strandPhase, sx, sy);
          emit(aX, aY, normalX, normalY, t0, 1, power0, strandPhase, sx, sy);
          emit(bX, bY, normalX, normalY, t1, -1, power1, strandPhase, sx, sy);
          emit(bX, bY, normalX, normalY, t1, -1, power1, strandPhase, sx, sy);
          emit(aX, aY, normalX, normalY, t0, 1, power0, strandPhase, sx, sy);
          emit(bX, bY, normalX, normalY, t1, 1, power1, strandPhase, sx, sy);
        }
      }
    }
    diagnostics.vertices = used / STRIDE;
    return diagnostics.vertices;
  }

  function reset() {
    for (const track of tracks) { track.active = false; track.age = track.seen = track.observations = track.movement = 0; }
    for (const key of Object.keys(state)) state[key] = 0;
    lastScan = lastScanTime = lastVideoTime = lastBeat = -1; used = 0; nextStroke = 0;
    Object.assign(midOnset, makeOnsetState()); Object.assign(highOnset, makeOnsetState());
    for (const stroke of strokes) { stroke.active = false; stroke.age = stroke.strength = 0; }
    diagnostics.scans = diagnostics.scanMs = diagnostics.candidates = diagnostics.tracks = diagnostics.visible = diagnostics.vertices = 0;
  }
  return { vertices, stride: STRIDE, state, diagnostics, tracks, update, reset };
}
