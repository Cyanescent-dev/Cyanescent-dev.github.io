import { LiveAdaptiveTransitionManager } from "./liveAdaptiveTransitionManager.js";
import { runtimeAllowsPreset, requireRuntimePreset } from "../config/runtimeCapabilities.js";
import { presetAnimationStartedAt } from "./presetAnimationClock.js";
import { AdaptiveTransitionManager } from "./adaptiveTransitionManager.js";
import {
  createPresetTransitionState,
  presetTransitionProgress,
  VisualTransitionMode
} from "./transitions.js";

export function createVisualTransitionController({
  presetSelection,
  getTransition,
  setTransition,
  getActivePreset,
  setActivePreset,
  getActivePresetStartedAt,
  setActivePresetStartedAt,
  getVisualTransitionMode,
  getNextShuffleAt,
  setNextShuffleAt,
  getPlayerMode,
  getPlayerAudio,
  getAnalysisTimeline,
  getMusicAwareState,
  getLookaheadState,
  getLiveInputState,
  getAdaptiveTimingPreset,
  getAdaptivePresetExactPlaySeconds,
  getAdaptivePresetMinimumPlaySeconds,
  presetMetadata,
  presetMetadataById,
  onPresetCandidate,
  onActivePresetChanged,
  getTransitionTiming,
  // Automatic preset changes only. Used to hold a shuffle/adaptive transition
  // off while an Alien Visit is on screen, so an encounter can never be cut
  // into by one. Manual preset changes deliberately ignore this: an explicit
  // user action should always win.
  shouldDeferAutoTransition = () => false,
  now = () => performance.now()
} = {}) {
  function normalizePresetId(value) {
    return presetSelection.normalizePresetId(value);
  }

  function shuffleIntervalMs() {
    return presetSelection.shuffleIntervalMs();
  }

  function activePresetAgeSeconds(nowValue = now()) {
    const startedAt = Number(getActivePresetStartedAt?.() || 0);
    return Math.max(0, (Number(nowValue) - startedAt) * 0.001);
  }

  function begin(nextPreset, source = "manual", options = {}) {
    if (Number(nextPreset) >= 0 && !runtimeAllowsPreset(nextPreset)) {
      if (["manual", "preview", "diagnostic"].includes(source)) {
        try { requireRuntimePreset(nextPreset); } catch (error) { console.warn(error.message); }
      }
      return false;
    }
    const transition = getTransition();
    const activePreset = getActivePreset();
    const next = normalizePresetId(nextPreset);
    if (!runtimeAllowsPreset(next)) return false;
    // Never let an automatically scheduled transition clobber one already in
    // flight. Replacing a live transition resets the covering transition video
    // and flips suppressShaderTransition, so the renderer jumps branches
    // between frames -- a hard cut, immediately followed by the replacement's
    // own transition to a third preset.
    //
    // The adaptive manager's canRun() already declines while a transition is
    // active, so in the primary document this is belt-and-braces; it matters
    // when the engine's view of "active" can lag, and it mirrors the check
    // onPlaylistEndApproaching makes for itself. The manager clears its pending
    // on a false return, so nothing gets stuck. Manual sources stay able to
    // interrupt: a user asking for the next preset should always win.
    const isAutomaticSource = source === "adaptive" || source === "playlist-end";
    if (transition.active && isAutomaticSource && !options.force) return false;
    if (next === activePreset && (!transition.active || !transition.suppressShaderTransition)) {
      if (!transition.active) return false;
      // Selecting the currently active participant cancels the replacement.
      // Keep its epoch; rendering it twice would also step its director twice.
      transition.active = false;
      transition.cancelled = true;
      return true;
    }
    const style = options.style ?? (source === "shuffle" ? 1 : 0);
    const timing = options.timing || getTransitionTiming?.({
      from: activePreset,
      to: next,
      source,
      style
    }) || {};
    const beganAt = now();
    const nextTransition = createPresetTransitionState({
      from: activePreset,
      to: next,
      now: beganAt - Math.max(0, Number(options.startOffsetMs) || 0),
      source,
      style,
      duration: timing.duration,
      swapAt: timing.swapAt,
      useVideoTransitions: timing.useVideoTransitions,
      videoTransitionId: options.videoTransitionId || "",
      forceVideoTransition: Boolean(options.forceVideoTransition),
      suppressVideoTransition: Boolean(options.suppressVideoTransition),
      suppressShaderTransition: options.allowShaderTransition
        ? false
        : Boolean(timing.suppressShaderTransition || options.forceVideoTransition || options.videoTransitionId)
    });
    nextTransition.fromPresetStartedAt = presetAnimationStartedAt(
      activePreset, transition, activePreset, getActivePresetStartedAt?.());
    nextTransition.fromActivatedAt = Number(getActivePresetStartedAt?.()) || 0;
    if (!nextTransition.suppressShaderTransition) {
      // An interrupted transition may already have been rendering this target.
      nextTransition.toPresetStartedAt = transition.active && !transition.suppressShaderTransition
        && [transition.from, transition.to].includes(next)
        ? presetAnimationStartedAt(next, transition, activePreset, getActivePresetStartedAt?.())
        : beganAt;
    }
    setTransition(nextTransition);
    return true;
  }

  function notePresetStartedForAdaptive(source) {
    if (source === "adaptive") return;
    adaptive.markPresetStarted(adaptive.currentTime());
  }

  function notePresetActivated(presetId) {
    presetSelection.recordPresetStarted?.(presetId);
    adaptive.notePresetActivated(presetId);
  }

  function updatePreset(nowValue) {
    const transition = getTransition();
    const progress = presetTransitionProgress(transition, nowValue, transition.swapAt ?? 0.48);
    if (!transition.active) return 0;
    if (!transition.suppressShaderTransition) {
      // Video preparation can fall back to rendering after begin(). Establish
      // the missing participant epoch once, when that path first takes over.
      transition.fromPresetStartedAt ??= Number(getActivePresetStartedAt?.()) || 0;
      transition.fromActivatedAt ??= Number(getActivePresetStartedAt?.()) || 0;
      transition.toPresetStartedAt ??= transition.swapped
        ? Number(getActivePresetStartedAt?.()) || 0 : nowValue;
      if (transition.swapped) transition.toActivatedAt ??= Number(getActivePresetStartedAt?.()) || 0;
    }
    if (progress.shouldSwap) {
      setActivePreset(transition.to);
      setActivePresetStartedAt(nowValue);
      transition.toActivatedAt = nowValue;
      notePresetActivated(transition.to);
      onActivePresetChanged?.(transition.to);
      notePresetStartedForAdaptive(transition.source);
      transition.swapped = true;
    }
    if (progress.complete) {
      const changedAtEnd = getActivePreset() !== transition.to;
      transition.active = false;
      setActivePreset(transition.to);
      if (changedAtEnd) {
        setActivePresetStartedAt(nowValue);
        notePresetActivated(transition.to);
      }
      onActivePresetChanged?.(transition.to);
      if (changedAtEnd) notePresetStartedForAdaptive(transition.source);
      if (getVisualTransitionMode() === VisualTransitionMode.SHUFFLE) {
        setNextShuffleAt(nowValue + shuffleIntervalMs());
      }
      return 0;
    }
    return progress.phase;
  }

  const adaptive = new AdaptiveTransitionManager({
    transitionMode: getVisualTransitionMode,
    canRun: () => {
      const playerAudio = getPlayerAudio?.();
      return getPlayerMode?.() && playerAudio && !playerAudio.paused && getAnalysisTimeline?.()
        && !getTransition().active && !shouldDeferAutoTransition();
    },
    currentTime: () => getPlayerAudio?.()?.currentTime || 0,
    analysisTimeline: getAnalysisTimeline,
    musicAwareState: getMusicAwareState,
    lookaheadState: getLookaheadState,
    adaptiveTimingPreset: getAdaptiveTimingPreset,
    activePresetAgeSeconds,
    presetExactPlaySeconds: getAdaptivePresetExactPlaySeconds,
    presetMinimumPlaySeconds: getAdaptivePresetMinimumPlaySeconds,
    activePreset: getActivePreset,
    eligiblePresetIds: () => presetSelection.adaptiveEligiblePresetIds(),
    presetMetadata: () => presetMetadata,
    presetMetadataById: () => presetMetadataById,
    onPendingPreset: onPresetCandidate,
    beginPresetTransition: (targetPreset, transitionStyle) => begin(targetPreset, "adaptive", { style: transitionStyle })
  });

  const liveAdaptive = new LiveAdaptiveTransitionManager({
    transitionMode: getVisualTransitionMode,
    timingPreset: getAdaptiveTimingPreset,
    activePreset: getActivePreset,
    activePresetStartedAt: getActivePresetStartedAt,
    activePresetAgeSeconds,
    minimumPlaySeconds: getAdaptivePresetMinimumPlaySeconds,
    exactPlaySeconds: getAdaptivePresetExactPlaySeconds,
    eligiblePresetIds: () => presetSelection.adaptiveEligiblePresetIds(),
    presetMetadata: () => presetMetadata,
    presetMetadataById: () => presetMetadataById,
    transitionTiming: getTransitionTiming,
    onPendingPreset: onPresetCandidate,
    begin: (target, style, timing) => begin(target, "adaptive", { style, timing })
  });

  function updateShuffle(nowValue) {
    if (getVisualTransitionMode() !== VisualTransitionMode.SHUFFLE || getTransition().active) return;
    if (nowValue >= getNextShuffleAt()) {
      begin(presetSelection.chooseNextPreset(), "shuffle");
    }
  }

  function updateVisual(nowValue) {
    const deferAutomatic = shouldDeferAutoTransition();
    liveAdaptive.update(nowValue, getLiveInputState?.(), deferAutomatic || getTransition().active);
    if (deferAutomatic) {
      // Push the shuffle deadline along with the hold rather than letting it
      // sit in the past, so the transition does not fire on the very frame the
      // encounter releases it.
      const earliest = Number(nowValue) + 1200;
      if (getNextShuffleAt() < earliest) setNextShuffleAt(earliest);
      return;
    }
    updateShuffle(nowValue);
    adaptive.update(nowValue);
  }

  return {
    normalizePresetId,
    presetIds: () => presetSelection.presetIds(),
    presetCount: () => presetSelection.presetCount(),
    adaptiveEligiblePresetIds: () => presetSelection.adaptiveEligiblePresetIds(),
    shuffleIntervalMs,
    chooseNextPreset: () => presetSelection.chooseNextPreset(),
    begin,
    updatePreset,
    updateVisual,
    resetAdaptive: () => { adaptive.reset(); liveAdaptive.reset(); },
    markAdaptivePresetStarted: (time) => adaptive.markPresetStarted(time),
    notePresetActivated,
    setAdaptiveTimingPreset: (value) => { adaptive.setTimingPreset(value); liveAdaptive.invalidate(); },
    getLiveAdaptiveStatus: () => ({ ...liveAdaptive.status }),
    handleSeek: (time) => adaptive.handleSeek(time)
  };
}
