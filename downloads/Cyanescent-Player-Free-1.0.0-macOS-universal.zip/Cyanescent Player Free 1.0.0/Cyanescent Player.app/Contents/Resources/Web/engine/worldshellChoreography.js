const DROP_ROLE = 2;

function clamp01(value) {
  return Math.max(0, Math.min(1, Number(value) || 0));
}

function finite(value, fallback = 0) {
  return Number.isFinite(Number(value)) ? Number(value) : fallback;
}

function fract(value) {
  return value - Math.floor(value);
}

function smoothstep(edge0, edge1, value) {
  if (edge0 === edge1) return value < edge0 ? 0 : 1;
  const amount = clamp01((value - edge0) / (edge1 - edge0));
  return amount * amount * (3 - 2 * amount);
}

function windowEnvelope(value, start, peak, end) {
  return smoothstep(start, peak, value) * (1 - smoothstep(peak, end, value));
}

function followEnvelope(current, target, elapsed, attackSeconds, releaseSeconds) {
  if (elapsed <= 0) return current;
  const timeConstant = target > current ? attackSeconds : releaseSeconds;
  const amount = 1 - Math.exp(-elapsed / Math.max(0.001, timeConstant));
  return current + (target - current) * amount;
}

function stableSeed(value) {
  const text = String(value ?? "worldshell");
  let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    hash = Math.imul(hash ^ text.charCodeAt(index), 16777619);
  }
  return 0.08 + ((hash >>> 0) / 4294967295) * 0.84;
}

function sectionKeyFor(section, analysis, musicAwareState) {
  const source = section || analysis?.section || null;
  if (source && typeof source === "object") {
    if (source.id != null) return `id:${source.id}`;
    if (source.index != null) return `index:${source.index}`;
    if (source.start != null) return `start:${finite(source.start).toFixed(3)}:${source.label || ""}`;
    if (source.label) return `label:${source.label}`;
  }
  if (typeof source === "string" && source) return `label:${source}`;
  if (analysis?.sectionIndex != null) return `index:${analysis.sectionIndex}`;
  if (analysis?.sectionLabel) return `label:${analysis.sectionLabel}`;
  return `role:${finite(musicAwareState?.role, 0)}`;
}

function sectionLabelFor(section, analysis) {
  const source = section || analysis?.section || null;
  if (typeof source === "string") return source;
  return source?.label || analysis?.sectionLabel || "";
}

function resolveAbsoluteBeat({ beatInfo, musicAwareState, previousState, currentTime, elapsed }) {
  const direct = beatInfo?.absoluteBeat ?? musicAwareState?.absoluteBeat;
  if (Number.isFinite(Number(direct))) return Math.max(0, Number(direct));
  if (Number.isFinite(Number(beatInfo?.beatIndex))) {
    return Math.max(0, Number(beatInfo.beatIndex) + clamp01(beatInfo.beatPhase));
  }
  const bpm = finite(beatInfo?.bpm, 0);
  if (bpm > 0) {
    const origin = finite(beatInfo?.phase, 0);
    return Math.max(0, (currentTime - origin) * bpm / 60);
  }
  const phase = beatInfo?.beatPhase ?? musicAwareState?.beatPhase;
  if (Number.isFinite(Number(phase)) && previousState) {
    const normalizedPhase = fract(Math.max(0, Number(phase)));
    const previousPhase = fract(previousState.absoluteBeat || 0);
    const wrapped = normalizedPhase + 0.5 < previousPhase ? 1 : 0;
    return Math.floor(previousState.absoluteBeat || 0) + wrapped + normalizedPhase;
  }
  return Math.max(0, finite(previousState?.absoluteBeat, 0) + elapsed * 2);
}

function resetState({ currentTime, trackProgress, entryToken, sectionKey, role, absoluteBeat, reason }) {
  const beatIndex = Math.floor(absoluteBeat);
  const sectionSeed = stableSeed(sectionKey);
  return {
    active: true,
    entryToken: entryToken ?? null,
    resetReason: reason,
    lastTime: currentTime,
    lastTrackProgress: trackProgress,
    buildCharge: 0,
    dropTime: null,
    dropAge: -1,
    dropStrength: 0,
    dropStrengthLatch: 0,
    lastDropSignal: 0,
    sectionKey,
    sectionSerial: 0,
    sectionStartTime: currentTime,
    sectionAge: 0,
    sectionSeedFrom: sectionSeed,
    sectionSeed,
    sectionMorph: 1,
    lastSectionSignal: 0,
    sectionSignalSince: null,
    sectionSignalArmed: false,
    lastRole: role,
    absoluteBeat,
    beatIndex,
    beatTime: null,
    beatAge: -1,
    beatEnvelope: 0,
    lastBeatSignal: 0,
    barPhase: fract(absoluteBeat / 4),
    breakdownInfluence: 0,
    geometryTime: 0,
    cameraImpulse: 0,
    cameraVelocity: 0,
    cameraTravel: 0,
    anticipation: 0,
    inhale: 0,
    impact: 0,
    propagation: 0,
    aftershock: 0,
    recovery: 0,
    worldturn: 0,
    pressure: 0,
    travelDrive: 0,
    eventPhase: "anticipation"
  };
}

/**
 * Creates an inert Worldshell state. The first active update is treated as a
 * preset entry so stale event memory can never leak between selections.
 */
export function createWorldshellChoreographyState() {
  return {
    ...resetState({
      currentTime: 0,
      trackProgress: 0,
      entryToken: null,
      sectionKey: "role:0",
      role: 0,
      absoluteBeat: 0,
      reason: "initial"
    }),
    active: false
  };
}

/**
 * Advances Worldshell's musical memory using track time only. The function is
 * side-effect free: callers retain the returned state and pass it to the next
 * live frame or sequential offline-export frame.
 */
export function computeWorldshellChoreographyState({
  previousState,
  currentTime: suppliedTime,
  trackTime,
  trackProgress: suppliedProgress = 0,
  presetActive = true,
  presetEntered = false,
  entryToken,
  beatInfo = null,
  phraseInfo = null,
  musicAwareState = null,
  musicAware = null,
  lookaheadState = null,
  lookahead = null,
  audioFeatures = null,
  analysis: suppliedAnalysis = null,
  audioAnalysis = null,
  bands = null,
  audioBands = null,
  section = null,
  reset = false
} = {}) {
  const prior = previousState || createWorldshellChoreographyState();
  const currentTime = Math.max(0, finite(suppliedTime ?? trackTime, 0));
  const trackProgress = clamp01(suppliedProgress);
  const music = musicAwareState || musicAware || {};
  const future = lookaheadState || lookahead || {};
  const analysis = suppliedAnalysis || audioAnalysis || future.current || {};
  const currentBands = bands || audioBands || {};
  const role = finite(music.role, 0);
  const sectionKey = sectionKeyFor(section, analysis, music);

  if (!presetActive) {
    return {
      ...prior,
      active: false,
      lastTime: currentTime,
      lastTrackProgress: trackProgress,
      resetReason: "inactive",
      anticipation: 0,
      inhale: 0,
      impact: 0,
      propagation: 0,
      aftershock: 0,
      recovery: 0,
      pressure: 0
    };
  }

  const elapsedBeforeReset = Math.max(0, currentTime - finite(prior.lastTime, currentTime));
  const absoluteBeatBeforeReset = resolveAbsoluteBeat({
    beatInfo,
    musicAwareState: music,
    previousState: prior,
    currentTime,
    elapsed: elapsedBeforeReset
  });
  const tokenChanged = entryToken !== undefined && prior.entryToken !== entryToken;
  const backwardTime = prior.active && currentTime < finite(prior.lastTime, 0) - 0.05;
  const backwardProgress = prior.active
    && trackProgress < finite(prior.lastTrackProgress, 0) - 0.01
    && finite(prior.lastTrackProgress, 0) > 0.02;
  const shouldReset = reset || presetEntered || !prior.active || tokenChanged || backwardTime || backwardProgress;
  let state = shouldReset
    ? resetState({
      currentTime,
      trackProgress,
      entryToken,
      sectionKey,
      role,
      absoluteBeat: absoluteBeatBeforeReset,
      reason: reset ? "explicit" : backwardTime || backwardProgress ? "backward-seek" : "preset-entry"
    })
    : { ...prior, resetReason: "none" };
  const elapsed = shouldReset ? 0 : Math.max(0, currentTime - state.lastTime);
  const absoluteBeat = shouldReset
    ? absoluteBeatBeforeReset
    : resolveAbsoluteBeat({ beatInfo, musicAwareState: music, previousState: state, currentTime, elapsed });

  const current = future.current || analysis;
  const short = future.short || current;
  const medium = future.medium || short;
  const long = future.long || medium;
  const currentEnergy = clamp01(Math.max(
    analysis.energy || 0,
    audioFeatures?.globalEnergy || 0,
    currentBands.level || 0
  ));
  const futureRise = clamp01(Math.max(
    finite(short.energyDelta, 0) * 2.2,
    finite(medium.energyDelta, 0) * 1.55,
    finite(long.energyDelta, 0) * 0.85,
    (finite(medium.maxEnergy, 0) - finite(current.energy, 0)) * 1.45
  ));
  const upcomingDrop = clamp01(music.upcomingDrop);
  const upcomingBuild = clamp01(Math.max(music.upcomingBuild || 0, music.buildUp || 0));
  const nextPhraseSeconds = finite(
    phraseInfo?.nextPhraseSeconds ?? phraseInfo?.nextLoopSeconds ?? music.nextPhraseSeconds,
    0
  );
  const phraseProgress = clamp01(
    phraseInfo?.progress ?? phraseInfo?.phrase32Progress ?? music.phraseProgress
  );
  const phrasePulse = clamp01(phraseInfo?.pulse ?? phraseInfo?.phrasePulse ?? music.phrasePulse);
  const phraseApproach = nextPhraseSeconds > 0
    ? smoothstep(4.0, 0.08, nextPhraseSeconds)
    : smoothstep(0.72, 0.995, phraseProgress) * (0.35 + phrasePulse * 0.65);
  let buildTarget = clamp01(
    upcomingDrop * 0.72
    + upcomingBuild * 0.34
    + clamp01(music.buildUp) * 0.28
    + futureRise * 0.54
    + phraseApproach * upcomingDrop * 0.24
  );

  const dropSignal = clamp01(Math.max(
    music.drop || 0,
    audioFeatures?.dropDetected || 0,
    analysis.dropStrength || 0,
    analysis.drop || 0
  ));
  const kickSignal = clamp01(Math.max(
    audioFeatures?.kickPulse || 0,
    currentBands.kick || 0,
    analysis.kickScore || 0
  ));
  const beatSignal = clamp01(Math.max(
    kickSignal,
    finite(analysis.beatStrength, 0) * 0.82,
    finite(current.beatStrength, 0) * 0.72
  ));
  const sectionLabel = sectionLabelFor(section, analysis);
  const sectionDrop = /drop/i.test(sectionLabel) && sectionKey !== state.sectionKey;
  const roleDrop = role === DROP_ROLE && state.lastRole !== DROP_ROLE && clamp01(music.roleConfidence) > 0.45;
  const dropRising = dropSignal >= 0.48 && state.lastDropSignal < 0.40;
  const dropReady = state.dropAge < 0 || state.dropAge > 1.35;
  const dropTriggered = dropReady && (dropRising || sectionDrop || roleDrop);

  if (dropTriggered) {
    const source = section || analysis.section;
    const declaredStart = source && typeof source === "object" ? finite(source.start, currentTime) : currentTime;
    state.dropTime = Math.max(0, Math.min(currentTime, declaredStart));
    if (currentTime - state.dropTime > 0.4) state.dropTime = currentTime;
    state.dropStrength = clamp01(
      0.30
      + dropSignal * 0.48
      + kickSignal * 0.24
      + clamp01(analysis.beatStrength) * 0.10
      + clamp01(music.highEnergy) * 0.12
      + currentEnergy * 0.12
    );
    state.dropStrengthLatch = state.dropStrength;
    buildTarget = 0;
  }

  state.dropAge = state.dropTime == null ? -1 : Math.max(0, currentTime - state.dropTime);
  if (state.dropAge >= 0 && state.dropAge < 1.8) buildTarget *= smoothstep(0.15, 1.8, state.dropAge) * 0.26;
  state.buildCharge = shouldReset
    ? buildTarget * 0.30
    : followEnvelope(state.buildCharge, buildTarget, elapsed, 1.35, 0.34);

  const sectionSignal = clamp01(Math.max(music.sectionChange || 0, analysis.sectionProbability || 0));
  const explicitSectionChanged = sectionKey !== state.sectionKey;
  // An authoritative section identity wins over a noisy confidence estimate.
  // Unlabelled analysis must rearm low, sustain high, and leave the previous
  // morph time to settle before it can infer another section.
  if (sectionSignal <= 0.42) {
    state.sectionSignalArmed = true;
    state.sectionSignalSince = null;
  } else if (sectionSignal > 0.58 && state.sectionSignalArmed) {
    state.sectionSignalSince ??= currentTime;
  } else {
    state.sectionSignalSince = null;
  }
  const inferredSectionChanged = !explicitSectionChanged
    && sectionKey.startsWith("role:")
    && state.sectionSignalArmed
    && state.sectionSignalSince != null
    && currentTime - state.sectionSignalSince >= 0.35
    && currentTime - state.sectionStartTime >= 8.0;
  if (explicitSectionChanged || inferredSectionChanged) {
    state.sectionSignalArmed = false;
    state.sectionSignalSince = null;
    const nextSerial = state.sectionSerial + 1;
    const inferredKey = `signal:${nextSerial}:role:${role}`;
    const nextKey = sectionKey;
    state.sectionSeedFrom = state.sectionSeed;
    state.sectionSeed = stableSeed(explicitSectionChanged ? nextKey : `${state.sectionSeed}:${inferredKey}`);
    state.sectionKey = nextKey;
    state.sectionSerial = nextSerial;
    state.sectionStartTime = currentTime;
    state.sectionAge = 0;
    state.sectionMorph = 0;
  } else {
    state.sectionAge = Math.max(0, currentTime - state.sectionStartTime);
    state.sectionMorph = 1 - Math.exp(-state.sectionAge / 1.15);
  }

  const beatIndex = Math.floor(absoluteBeat + 1e-6);
  const gridBeat = beatIndex > state.beatIndex;
  const transientBeat = beatSignal > 0.30 && state.lastBeatSignal <= 0.20;
  const beatTriggered = gridBeat || transientBeat;
  state.beatEnvelope *= Math.exp(-elapsed / 0.16);
  if (beatTriggered) {
    const beatDuration = finite(beatInfo?.beatDuration, finite(beatInfo?.bpm, 0) > 0 ? 60 / beatInfo.bpm : 0);
    const beatPhase = clamp01(beatInfo?.beatPhase ?? music.beatPhase ?? fract(absoluteBeat));
    const inferredBeatTime = gridBeat && beatDuration > 0
      ? Math.max(state.lastTime, currentTime - beatPhase * beatDuration)
      : currentTime;
    state.beatTime = inferredBeatTime;
    state.beatEnvelope = Math.max(state.beatEnvelope, clamp01(
      0.10 + beatSignal * 0.76 + currentEnergy * 0.20
    ) * Math.exp(-(currentTime - inferredBeatTime) / 0.16));
  }
  state.beatAge = state.beatTime == null ? -1 : Math.max(0, currentTime - state.beatTime);
  state.absoluteBeat = absoluteBeat;
  state.beatIndex = beatIndex;
  state.barPhase = fract(absoluteBeat / 4);

  const dropStrength = state.dropStrengthLatch;
  const age = state.dropAge;
  state.impact = age < 0 ? 0 : dropStrength * (1 - smoothstep(0.035, 0.38, age));
  state.propagation = age < 0 ? 0 : dropStrength * windowEnvelope(age, 0.06, 0.58, 2.15);
  state.aftershock = age < 0 ? 0 : dropStrength
    * windowEnvelope(age, 0.48, 1.75, 5.20)
    * (0.76 + 0.24 * Math.cos(age * 7.2) ** 2);
  state.recovery = age < 0 ? 0 : dropStrength * windowEnvelope(age, 2.15, 4.70, 9.0);
  state.inhale = clamp01(state.buildCharge * (0.30 + phraseApproach * 0.70) * (0.34 + upcomingDrop * 0.66));
  state.anticipation = clamp01((state.buildCharge * 0.78 + state.inhale * 0.42) * (1 - state.impact * 0.88));

  const highEnergy = clamp01(Math.max(music.highEnergy || 0, music.mainRiff || 0));
  const breakdown = clamp01(Math.max(music.breakdown || 0, music.upcomingBreakdown || 0));
  const breakdownTarget = breakdown * (1 - Math.max(highEnergy, upcomingBuild, upcomingDrop, dropSignal));
  state.breakdownInfluence = followEnvelope(state.breakdownInfluence, breakdownTarget, elapsed, 1.8, 0.65);
  const quiet = state.breakdownInfluence;
  // Integrate speed, never multiply absolute time by a changing classifier.
  state.geometryTime += elapsed * (1 - quiet * 0.42);
  const worldturnTarget = clamp01(
    highEnergy * 0.72
    + state.impact * 0.58
    + state.propagation * 0.52
    + state.aftershock * 0.28
    - breakdown * 0.48
  );
  state.worldturn = followEnvelope(state.worldturn, worldturnTarget, elapsed, 0.42, 2.6);

  let cameraImpulse = state.cameraImpulse * Math.exp(-elapsed / 0.24);
  if (beatTriggered) cameraImpulse += state.beatEnvelope * 0.22 * (1 - quiet * 0.72);
  if (dropTriggered) cameraImpulse += state.dropStrengthLatch * 0.92;
  state.cameraImpulse = Math.max(0, Math.min(1.6, cameraImpulse));
  const baseTravel = 0.10
    + currentEnergy * 0.42
    + highEnergy * 0.34
    + state.buildCharge * 0.18;
  const inhaleBrake = 1 - state.inhale * 0.58;
  const velocityTarget = baseTravel * (1 - quiet * 0.38) * inhaleBrake
    + state.cameraImpulse * 1.18
    + state.propagation * 0.24;
  const previousVelocity = state.cameraVelocity;
  state.cameraVelocity = followEnvelope(state.cameraVelocity, velocityTarget, elapsed, 0.15 + quiet * 0.65, 0.72 + quiet * 0.35);
  state.cameraTravel += (previousVelocity + state.cameraVelocity) * 0.5 * elapsed;
  state.pressure = clamp01(
    state.anticipation * 0.45
    + state.beatEnvelope * 0.32 * (1 - quiet * 0.55)
    + state.impact
    + state.propagation * 0.62
    + state.aftershock * 0.28
  );
  state.travelDrive = clamp01(state.cameraVelocity / 1.35);

  if (state.dropAge < 0) state.eventPhase = "anticipation";
  else if (state.dropAge < 0.38) state.eventPhase = "impact";
  else if (state.dropAge < 1.75) state.eventPhase = "propagation";
  else if (state.dropAge < 5.2) state.eventPhase = "aftershock";
  else if (state.dropAge < 9.0) state.eventPhase = "recovery";
  else state.eventPhase = "settled";

  if (state.dropAge > 9.0) {
    state.dropStrengthLatch *= Math.exp(-elapsed / 2.4);
    state.dropStrength = state.dropStrengthLatch;
  }
  state.lastDropSignal = dropSignal;
  state.lastSectionSignal = sectionSignal;
  state.lastBeatSignal = beatSignal;
  state.lastRole = role;
  state.lastTime = currentTime;
  state.lastTrackProgress = trackProgress;
  state.entryToken = entryToken ?? state.entryToken;
  return state;
}

export const updateWorldshellChoreographyState = computeWorldshellChoreographyState;
