import { createForgeVideoDecoder } from './forgeVideoDecoder.js';
import { HELIX_TUNNEL } from './helixTunnelAsset.js';
import { createFieldStore } from './newtonBasinField.js';
import { HELIX_PLANES, helixSampleAt, helixSceneAt, corridorRadius } from './helixTunnelField.js';
import { createHelixMusic } from './helixTunnelMusic.js';
import { createForgeVideoHistory, createForgePresentationClock, unwrapMediaTime, wrappedMediaTime } from './forgeVideoHistory.js';
import { helixCopySource, helixCompositeSource } from './helixTunnelShaders.js';
const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
const PRESENTATION = 24;
const HISTORY = 20, HISTORY_W = 960, HISTORY_H = 540;

export function createHelixTunnelRuntime({ getGl, program, setAttribs, asset = HELIX_TUNNEL }) {
  const controls = { reactive: 1, propulsion: 1, anticipation: 1, recoil: 1,
    pulses: 1, glow: 1, waves: 1, circuits: 1, compression: 1, bloom: 1, debug: 0 };
  const musicModel = createHelixMusic(), history = createForgeVideoHistory(HISTORY);
  const presentation = createForgeVideoHistory(PRESENTATION), presentationClock = createForgePresentationClock(asset.fps);
  const packets = Array.from({ length: 16 }, () => ({ age: -1, turn: 0, strength: 0, strand: 0, width: .065 }));
  const waves = Array.from({ length: 2 }, () => ({ age: -1, ahead: 0, strength: 0 }));
  const packetUniforms = new Float32Array(64), waveUniforms = new Float32Array(8);
  const scene = { camera: new Float64Array(12), corridor: new Float32Array(64), turn: 0, pitch: 34 };
  const reference = [0, 1].map(() => ({ camera: new Float64Array(12), corridor: new Float32Array(64), turn: 0 }));
  let decoder = null, decoderFallback = '';
  let recoilAnchor = 0, decoderBuffered = false, callbackEpoch = 0, rearmAt = 0, callbackRearms = 0;
  let active = false, generation = 0, video = null, callback = 0;
  let pkg = null, store = null, error = '', fatal = '', prog = null, copy = null, videoTex = null;
  let historyTex = [], historyFb = [], slots = [], presentationTex = [], presentationFb = [];
  let presentedTime = NaN, pixelTime = NaN, unwrapped = NaN, uploadedSerial = 0, savedSerial = -1;
  let presentationStarted = false;
  let videoReady = false, lastAt = 0, presence = 0, mode = 'native', cursor = 0, handoffTime = 0;
  let pendingPlay = false, handoffAt = 0, handoffRetries = 0, lastCircuit = 0;
  let reportAt = 0, frames = 0, reportFrames = 0, loops = 0, seeks = 0;
  let previousWrapped = NaN, fixtureSeeked = false, presentationDiscontinuities = 0, forwardJumpMax = 0;
  let previousPixelTime = NaN, frameAt = 0, frameInterval = 1 / 60, startup = 0, lastRateAt = 0;
  let uploadMs = 0, uploadCount = 0, maxUploadMs = 0;
  let cpuTotal = 0, cpuCount = 0, blendedFrames = 0, presentationFrames = 0, previousDisplay = NaN, backwardsFrames = 0, bufferUnderflows = 0;
  const locations = new WeakMap();
  const fixture = () => new URLSearchParams(window.location.search).get('fixture') || '';
  const trial = () => document.body.classList.contains('preset-trial-role');
  function loc(gl, p, name) {
    let map = locations.get(p); if (!map) { map = new Map(); locations.set(p, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(p, name)); return map.get(name);
  }
  const u1 = (gl, n, x) => gl.uniform1f(loc(gl, prog, n), x);
  const ui = (gl, n, x) => gl.uniform1i(loc(gl, prog, n), x);
  const u2 = (gl, n, x, y) => gl.uniform2f(loc(gl, prog, n), x, y);
  const u3 = (gl, n, a, o) => gl.uniform3f(loc(gl, prog, n), a[o], a[o + 1], a[o + 2]);
  function texture(gl, width, height, linear = false, half = false) {
    const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, linear ? gl.LINEAR : gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, linear ? gl.LINEAR : gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, half ? gl.RG16F : gl.RGBA, width, height, 0, half ? gl.RG : gl.RGBA, half ? gl.HALF_FLOAT : gl.UNSIGNED_BYTE, null);
    return t;
  }
  function bind(gl, p, name, unit, t) {
    gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.uniform1i(loc(gl, p, name), unit);
  }
  function draw(gl, p) { gl.useProgram(p); setAttribs(p); gl.drawArrays(gl.TRIANGLES, 0, 3); }
  async function fetchBytes(url) {
    const res = await fetch(url); if (!res.ok) throw new Error(`${url}: HTTP ${res.status}`);
    return new Uint8Array(await res.arrayBuffer());
  }
  async function load(token) {
    try {
      const json = async (name) => {
        const res = await fetch(`${asset.assetRoot}/${name}`); if (!res.ok) throw new Error(`${name}: HTTP ${res.status}`); return res.json();
      };
      const p = await json('runtime.json');
      if (p.schema !== 'cyanescent-helix-tunnel-runtime' || p.version !== 1 || p.fields.planes.join() !== HELIX_PLANES.join()) throw new Error('Helix field package schema/layout differs');
      if (p.source.frames !== asset.frames || p.source.fps !== asset.fps || p.fields.width !== asset.fieldWidth || p.fields.height !== asset.fieldHeight) throw new Error('Helix field package timing/size differs');
      p.timeline = await json(p.files.timeline);
      if (token !== generation) return;
      pkg = p;
      store = createFieldStore({ runtime: p, fetchBytes, urlFor: (name) => `${asset.assetRoot}/${name}`, behind: 28, ahead: 50, concurrency: 3 });
      store.prefetch(0, [0, 1]);
      if (p.files.decodeIndex) {
        try {
          const index = await json(p.files.decodeIndex);
          const decoded = await createForgeVideoDecoder({ url: encodeURI(`${asset.assetRoot}/${asset.video}`), index,
            onFrame: (time, pixels) => { if (token === generation) latchFrame(wrappedMediaTime(time, asset.durationSeconds), performance.now(), pixels, time); },
            onError: e => { if (token === generation) fatal = `Frame decoder: ${e.message || e}`; } });
          if (token !== generation) { decoded.stop(); return; }
          decoder = decoded;
          // Preflight may render only once beneath a transition video. Decode
          // the opening reservoir here, rather than waiting for the reveal.
          decoder.pump(0);
        } catch (e) { decoderFallback = String(e.message || e); }
      }
      if (token !== generation) return;
      if (!decoder) startNativeVideo();
    } catch (e) { if (token === generation) { error = String(e.message || e); console.error('[HelixTunnel] Field package:', error); } }
  }
  function latchFrame(time, displayAt = performance.now(), pixels = video, exactTime = NaN) {
    if (!active || !prog || (!Number.isFinite(exactTime) && (!video || video.seeking || video.readyState < 2))) return;
    if (mode === 'cache') return;
    if (mode === 'handoff') {
      // Ignore the old decoded surface while a single seek is in flight.
      const after = unwrapMediaTime(handoffTime, time, asset.durationSeconds) - handoffTime;
      if (after < -2 / asset.fps || after > .40) return;
      unwrapped = handoffTime; videoReady = false; history.clear(); presentation.clear(); presentationClock.reset(handoffTime); decoderBuffered = false; savedSerial = -1; previousPixelTime = previousDisplay = NaN; mode = 'native';
    }
    const nextTime = Number.isFinite(exactTime) ? exactTime : unwrapMediaTime(unwrapped, time, asset.durationSeconds);
    if (videoReady && Math.abs(nextTime - pixelTime) < .000001) return;
    const continuous = videoReady && Number.isFinite(previousPixelTime) && nextTime > pixelTime && nextTime - pixelTime < .40;
    if (videoReady && !continuous) { presentationDiscontinuities++; presentation.clear(); presentationClock.reset(nextTime); }
    const frame = presentation.push(nextTime);
    if (!frame) return;
    const destination = presentationFb[frame.slot];
    previousPixelTime = continuous ? pixelTime : nextTime;
    frameInterval = frameAt && continuous ? clamp((displayAt - frameAt) / 1000, 1 / 120, .05) : 1 / 60;
    frameAt = displayAt;
    const uploadAt = performance.now();
    const gl = getGl();
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, videoTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    try {
      // Upload and stamp in the same decoded-frame callback. Render-time
      // currentTime never gets used to date a previously uploaded video texture.
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
      // Store an owned GPU copy so the borrowed decoder VideoFrame can be
      // closed immediately; the bounded history never pins decoder surfaces.
      gl.bindFramebuffer(gl.FRAMEBUFFER, destination); gl.viewport(0, 0, asset.width, asset.height);
      gl.disable(gl.BLEND); gl.disable(gl.DEPTH_TEST); gl.useProgram(copy);
      bind(gl, copy, 'uVideo', 0, videoTex); draw(gl, copy);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      const cost = performance.now() - uploadAt; uploadMs += cost; uploadCount++; maxUploadMs = Math.max(maxUploadMs, cost);
      unwrapped = nextTime;
      pixelTime = unwrapped; presentedTime = time; uploadedSerial++; videoReady = true;
    } catch (e) { fatal = `Video upload: ${e.message || e}`; }
  }
  function start() {
    active = true; generation++;
    lastAt = reportAt = frames = reportFrames = loops = seeks = cpuTotal = cpuCount = 0;
    error = fatal = ''; pkg = store = null; presence = 0; mode = 'native'; cursor = 0;
    pixelTime = presentedTime = unwrapped = previousWrapped = NaN; uploadedSerial = 0; savedSerial = -1;
    presentationStarted = videoReady = pendingPlay = fixtureSeeked = false; previousPixelTime = NaN; frameAt = startup = lastRateAt = 0; handoffRetries = 0;
    callbackRearms = 0; decoderBuffered = false; musicModel.reset(); history.clear(); presentation.clear(); presentationClock.reset(0); clearEffects(); lastCircuit = 0; uploadMs = uploadCount = maxUploadMs = 0; blendedFrames = presentationFrames = backwardsFrames = bufferUnderflows = 0; previousDisplay = NaN; presentationDiscontinuities = forwardJumpMax = 0;
    video = document.createElement('video'); video.muted = true; video.loop = true; video.playsInline = true; video.preload = 'auto';
    video.className = 'forge-hybrid-video';
    document.body.appendChild(video);
    window.__helixTunnelVideo = video;
    const gl = getGl();
    try {
      prog = program(helixCompositeSource); copy = program(helixCopySource);
      if (!prog || !copy) throw new Error('Helix shader compile failed');
      videoTex = texture(gl, asset.width, asset.height, true);
      presentationTex = Array.from({ length: PRESENTATION }, () => texture(gl, asset.width, asset.height, true));
      presentationFb = presentationTex.map(t => {
        const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
        if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('Helix presentation framebuffer incomplete');
        return fb;
      });
      historyTex = Array.from({ length: HISTORY }, () => texture(gl, HISTORY_W, HISTORY_H, true));
      historyFb = historyTex.map(t => {
        const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
        if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('Helix history framebuffer incomplete');
        return fb;
      });
      slots = [0, 1].map(() => ({ index: -1, a: texture(gl, asset.fieldWidth, asset.fieldHeight), b: texture(gl, asset.fieldWidth, asset.fieldHeight, false, true) }));
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    } catch (e) { fatal = String(e.message || e); console.error('[HelixTunnel]', fatal); }
    video.addEventListener('playing', () => { if (active) armFrameCallback(); });
    // Browsers without RVFC get a seek-complete latch as well as a quantised
    // render-time fallback. The supported native WKWebView uses RVFC.
    video.addEventListener('seeked', () => { if (active && !video.requestVideoFrameCallback) latchFrame(Math.floor(video.currentTime * asset.fps) / asset.fps); });
    window.__helixTunnelControls = controls; load(generation);
    if (fixture().startsWith('helix-align')) controls.debug = 4;
    if (fixture().startsWith('helix-fields')) controls.debug = 1;
    if (fixture().startsWith('helix-flow')) controls.debug = 2;
  }
  function startNativeVideo() {
    video.src = encodeURI(`${asset.assetRoot}/${asset.video}`); video.load(); armFrameCallback();
  }
  function armFrameCallback() {
    if (!video?.requestVideoFrameCallback) return;
    callbackEpoch++; callbackRearms++; rearmAt = performance.now();
    if (callback) video.cancelVideoFrameCallback?.(callback);
    const token = generation, epoch = callbackEpoch, owner = video;
    const tick = (_now, info) => {
      if (!active || token !== generation || epoch !== callbackEpoch || owner !== video) return;
      latchFrame(Math.round(info.mediaTime * asset.fps) / asset.fps, performance.now());
      callback = owner.requestVideoFrameCallback(tick);
    };
    callback = owner.requestVideoFrameCallback(tick);
  }
  function clearEffects() { for (const p of packets) p.age = -1; for (const w of waves) w.age = -1; }
  function spawnPacket(strand, strength, offset = 0) {
    const p = packets.find(p => p.age < 0) || packets.reduce((a, b) => a.age > b.age ? a : b);
    Object.assign(p, { age: 0, turn: scene.turn + .20 + offset, strength, strand, width: strength > 1 ? .18 : .14 });
  }
  function spawnWave(strength, offset = 0) {
    const w = waves.find(w => w.age < 0) || waves.reduce((a, b) => a.age > b.age ? a : b);
    Object.assign(w, { age: 0, ahead: 7 + offset, strength });
  }
  function stepEffects(dt, events, quality) {
    const s = musicModel.state;
    for (const p of packets) if (p.age >= 0) {
      p.age += dt;
      // Keep the packet visible on the foreground before it travels into depth.
      const cameraTurnsPerSecond = pkg.source.worldPeriodTurns / pkg.source.durationSeconds;
      const speed = s.phase === 'recoil' ? -.35 : Math.max(.01, s.velocity) * (cameraTurnsPerSecond + .22 + .38 * s.mids + s.impulse * .8);
      p.turn += dt * speed;
      if (p.age > 4 || p.turn - scene.turn > 5 || p.turn - scene.turn < -.4) p.age = -1;
    }
    for (const w of waves) if (w.age >= 0) {
      w.age += dt; w.ahead += dt * 105 * Math.max(.04, s.velocity + s.impulse * .25);
      if (w.age > 3.5 || w.ahead > 220) w.age = -1;
    }
    if (events.drop) {
      spawnWave(1.05); spawnWave(.80, 12);
      for (let k = 0; k < 4; k++) spawnPacket(k % 2, 1.4, k * .12);
    } else if (events.kick) {
      spawnPacket(s.kickCount % 2, .55 + .65 * s.energy);
      spawnPacket((s.kickCount + 1) % 2, .30 + .35 * s.energy, .06);

    }
    // Mid-led travelling current between kicks; sparse sustained material still
    // breathes without a fabricated kick or a cloud of unrelated particles.
    if (s.time - lastCircuit > (quality > .5 ? 1.1 : 1.5) / (.25 + s.mids + .4 * s.energy) && s.mids > .18) {
      spawnPacket((s.kickCount + Math.floor(s.time)) % 2, .18 + .34 * s.mids); lastCircuit = s.time;
    }
    packetUniforms.fill(0); waveUniforms.fill(0);
    for (let i = 0; i < packets.length; i++) {
      const p = packets[i]; if (p.age < 0) continue;
      const birth = clamp(p.age / .06, 0, 1), death = clamp((4 - p.age) / .7, 0, 1);
      packetUniforms.set([p.turn - scene.turn, p.width, p.strength * birth * death, p.strand], i * 4);
    }
    for (let i = 0; i < waves.length; i++) {
      const w = waves[i]; if (w.age < 0) continue;
      const strength = w.strength * clamp(w.age / .045, 0, 1) * Math.exp(-w.age / 1.65);
      waveUniforms.set([w.ahead, corridorRadius(scene.corridor, w.ahead), strength, .12], i * 4);
    }
  }
  function play() {
    if (pendingPlay || !video?.paused) return;
    pendingPlay = true; const token = generation;
    video.play().catch(e => { if (active && token === generation && e.name !== 'AbortError') error = `Playback: ${e.message || e}`; })
      .finally(() => { if (token === generation) pendingPlay = false; });
  }
  function transport(dt, playing, now) {
    const velocity = musicModel.state.velocity;
    if (decoder) {
      // A held-camera lighting fixture must also bypass musical recoil/handoff.
      if (fixture().startsWith('helix-still')) {
        decoder.pump(Number.isFinite(presentationClock.time) ? presentationClock.time : 0); return;
      }
      if (!playing) { if (!videoReady) decoder.pump(0); return; }
      if (mode === 'native' && velocity < .06 && history.count > 3) {
        mode = 'cache'; cursor = Number.isFinite(previousDisplay) ? previousDisplay : history.newest; recoilAnchor = cursor;
      }
      if (mode === 'cache') {
        cursor = clamp(cursor + velocity * dt, recoilAnchor - .16 * clamp(controls.recoil, 0, 1.5), recoilAnchor);
        cursor = history.pair(cursor)?.time ?? cursor;
        if (velocity > .08) {
          mode = 'handoff'; handoffTime = cursor; decoder.seek(cursor); seeks++;
        }
      }
      if (mode === 'handoff') decoder.pump(handoffTime);
      else if (mode === 'native') decoder.pump(Number.isFinite(presentationClock.time) ? presentationClock.time : (Number.isFinite(pixelTime) ? pixelTime : 0));
      return;
    }
    if (!playing) { video.pause(); return; }
    if (mode === 'native' && velocity < .06 && history.count > 3) {
      mode = 'cache'; cursor = Number.isFinite(previousDisplay) ? previousDisplay : history.newest; recoilAnchor = cursor; video.pause();
    }
    if (mode === 'cache') {
      // At zero the true displayed frame remains still. Reverse is limited to
      // the cached span and 160ms of source time, with subframe crossfades.
      cursor = clamp(cursor + velocity * dt, recoilAnchor - .16 * clamp(controls.recoil, 0, 1.5), recoilAnchor);
      cursor = history.pair(cursor)?.time ?? cursor;
      if (velocity > .08) {
        if (Math.abs(cursor - history.newest) < .5 / asset.fps) { mode = 'native'; presentationClock.reset(cursor); decoderBuffered = false; play(); }
        else {
          mode = 'handoff'; handoffTime = cursor; handoffAt = now; handoffRetries = 0;
          video.currentTime = wrappedMediaTime(cursor, asset.durationSeconds); seeks++; play();
        }
      }
    }
    if (mode === 'handoff' && now - handoffAt > 1200) {
      // One recovery retry, then a visible diagnostic. Never silently display
      // stale fields on a moving decoder or issue an unbounded seek loop.
      if (handoffRetries++ === 0) { video.currentTime = wrappedMediaTime(handoffTime, asset.durationSeconds); handoffAt = now; play(); }
      else error = 'Recoil decoder handoff timed out';
    }
    if (mode !== 'native') return;
    // Reliable forward decoding into a bounded reservoir: never ask WebKit to
    // emit a frame every half-second at 0.05x. Presentation consumes stored
    // frames at musical velocity, including almost-still anticipation.
    const shown = presentationClock.time;
    const lead = Number.isFinite(shown) ? presentation.newest - shown : 0;
    if (lead > .20) decoderBuffered = true;
    else if (lead < .08) decoderBuffered = false;
    const rate = clamp(Math.ceil(Math.max(.85, velocity + .35) * 2) / 2, 1, 3.5);
    // Coarse, infrequent decoder changes are hidden by the reservoir. The
    // presentation clock still follows every smooth kick/energy acceleration.
    if (Math.abs(video.playbackRate - rate) > .4 && now - lastRateAt > 1500) { video.playbackRate = rate; lastRateAt = now; }
    if (decoderBuffered) video.pause(); else play();
  }

  function bindFields(gl, at) {
    const entries = [store.get(at.i0), store.get(at.i1)];
    if (!entries[0] || !entries[1]) return false;
    const needs = [at.i0, at.i1]; const maps = needs.map(index => slots.find(slot => slot.index === index) || null);
    for (let k = 0; k < 2; k++) if (!maps[k]) {
      if (k === 1 && needs[1] === needs[0]) { maps[1] = maps[0]; continue; }
      const slot = slots.find(slot => !maps.includes(slot) && !needs.includes(slot.index)) || slots.find(slot => !maps.includes(slot));
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      for (const key of ['a', 'b']) {
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, slot[key]);
        // Packed B already consists of native little-endian half turn/depth.
        // Upload those bytes directly as RG16F: no CPU conversion, and the
        // shader avoids unpacking IEEE half values at every pixel/sample.
        const data = entries[k][key];
        gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, asset.fieldWidth, asset.fieldHeight,
          key === 'b' ? gl.RG : gl.RGBA, key === 'b' ? gl.HALF_FLOAT : gl.UNSIGNED_BYTE,
          key === 'b' ? new Uint16Array(data.buffer, data.byteOffset, data.byteLength / 2) : data);
      }
      slot.index = needs[k]; maps[k] = slot;
    }
    bind(gl, prog, 'uFieldA0', 3, maps[0].a); bind(gl, prog, 'uFieldB0', 4, maps[0].b);
    bind(gl, prog, 'uFieldA1', 5, maps[1].a); bind(gl, prog, 'uFieldB1', 6, maps[1].b);
    return true;
  }
  function prepare() {
    if (!active) start();
    // Keep preparing the opening reservoir while the transition covers us.
    // Preparation never advances the music or presentation clock.
    if (decoder && !presentationStarted) decoder.pump(0);
  }
  function render({ target, width, height, now, playing = true, quality = 0, audio = {}, smooth = {}, music = {}, lookahead = {}, tempo = {} }) {
    if (!active) start();
    const stamp = performance.now(), gl = getGl();
    const wallDt = lastAt ? clamp((now - lastAt) / 1000, 0, .05) : 1 / 60; lastAt = now; frames++;
    const dt = playing ? wallDt : 0;
    const events = musicModel.step(dt, { audio, smooth, music, lookahead, tempo }, controls);
    const f = fixture();
    if (!fixtureSeeked && (decoder || video.readyState >= 2)) {
      const seek = f.match(/-t([\d.]+)$/);
      if (seek || f === 'helix-loop') { const at = seek ? Number(seek[1]) : asset.durationSeconds - 3; if (decoder) { decoder.seek(at); presentationClock.reset(at); } else video.currentTime = at; history.clear(); }
      fixtureSeeked = true;
    }
    if (!video.requestVideoFrameCallback && video.readyState >= 2) {
      const t = Math.floor(video.currentTime * asset.fps) / asset.fps;
      if (t !== presentedTime || !videoReady) latchFrame(t);
    }
    if (pkg && (decoder || video.getAttribute('src'))) transport(dt, playing, now);
    // Same stalled-callback recovery used by the Forge hybrid infrastructure.
    // Cancel/rearm the callback, without seeking or guessing metadata time.
    if (!decoder && mode === 'native' && playing && !video.paused && videoReady
      && now - Math.max(frameAt, rearmAt) > 150) armFrameCallback();
    if (prog && videoReady && mode === 'native' && savedSerial !== uploadedSerial) {
      const saved = history.push(pixelTime);
      if (saved) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, historyFb[saved.slot]); gl.viewport(0, 0, HISTORY_W, HISTORY_H);
        gl.disable(gl.BLEND); gl.disable(gl.DEPTH_TEST); gl.useProgram(copy);
        bind(gl, copy, 'uVideo', 0, videoTex); draw(gl, copy);
      }
      savedSerial = uploadedSerial;
    }
    const cached = mode !== 'native' ? history.pair(cursor) : null;
    // The bounded full-resolution reservoir supplies continuous musical
    // motion without dating pixels by currentTime or decoder callback cadence.
    const wasStarted = presentationStarted;
    if (!presentationStarted && videoReady && pkg) {
      const opening = presentation.pair(presentationClock.time);
      const indexFor = time => ((Math.round(time * asset.fps) % asset.frames) + asset.frames) % asset.frames;
      // Reveal a coherent beauty/metadata pair atomically. Never begin on the
      // latest asynchronous decode timestamp, or switch projection on later.
      presentationStarted = Boolean(opening && presentation.count >= 3
        && store?.get(indexFor(opening.a.time)) && store?.get(indexFor(opening.b.time))
        && store?.get(indexFor(opening.time + 2 / asset.fps)));
    }
    const nativePair = presentationClock.step(presentation, wallDt, musicModel.state.velocity,
      Math.max(0, (now - frameAt) / 1000), playing && wasStarted && !f.startsWith('helix-still'));
    const frameMix = nativePair?.mix || 0;
    const displayedTime = cached?.time ?? nativePair?.time ?? pixelTime;
    if (Number.isFinite(displayedTime)) {
      presentationFrames++;
      if (mode === 'native' && frameMix > .001 && frameMix < .999) blendedFrames++;
      if (mode === 'native' && Number.isFinite(previousDisplay) && displayedTime < previousDisplay - 1e-6 && !video.seeking) backwardsFrames++;
      if (mode === 'native' && playing && startup === 1 && Number.isFinite(previousDisplay)
        && !f.startsWith('helix-still') && displayedTime - previousDisplay < Math.max(0, musicModel.state.velocity) * wallDt * .5) bufferUnderflows++;
      if (mode === 'native' && Number.isFinite(previousDisplay) && presentationStarted)
        forwardJumpMax = Math.max(forwardJumpMax, displayedTime - previousDisplay - Math.max(0, musicModel.state.velocity) * dt);
      previousDisplay = displayedTime;
    }
    const mediaTime = Number.isFinite(displayedTime) ? wrappedMediaTime(displayedTime, asset.durationSeconds) : 0;
    if (mode === 'native' && Number.isFinite(previousWrapped) && mediaTime < previousWrapped - asset.durationSeconds / 2) loops++;
    previousWrapped = mediaTime;
    if (pkg) helixSceneAt(pkg, Number.isFinite(displayedTime) ? displayedTime : 0, scene);
    const at = helixSampleAt(mediaTime, asset.fps, pkg?.source.frames || asset.frames);
    const imagePair = cached || nativePair;
    const sourceTimes = imagePair ? [imagePair.a.time, imagePair.b.time] : [displayedTime, displayedTime];
    const fieldAt = { i0: 0, i1: 0, mix: imagePair?.mix || 0 };
    // Decoder stamps are exact frame times; round avoids floating point
    // underflow selecting the preceding metadata sample after a loop.
    fieldAt.i0 = ((Math.round((sourceTimes[0] || 0) * asset.fps) % asset.frames) + asset.frames) % asset.frames;
    fieldAt.i1 = ((Math.round((sourceTimes[1] || 0) * asset.fps) % asset.frames) + asset.frames) % asset.frames;
    if (store) {
      const needed = [at.i0, at.i1, fieldAt.i0, fieldAt.i1];
      // Recoil can cross the seam in either direction. Retain the tail at the
      // head as well as the existing store's head-at-tail warm window.
      if (at.i0 < 28) for (let k = pkg.source.frames - 28; k < pkg.source.frames; k++) needed.push(k);
      store.prefetch(at.i0, needed);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb); gl.viewport(0, 0, width, height);
    gl.disable(gl.BLEND); gl.disable(gl.DEPTH_TEST);
    if (!prog || fatal || !videoReady || !pkg || !presentationStarted) {
      video.style.display = decoder ? 'none' : 'block';
      gl.clearColor(0, 0, 0, fatal ? 0 : 1); gl.clear(gl.COLOR_BUFFER_BIT); publish(now, displayedTime, false, stamp); return;
    }
    // Keep the decoder renderable beneath the opaque WebGL canvas. WebKit
    // abandons frame callbacks for display:none media, even while time advances.
    video.style.display = decoder ? 'none' : 'block'; gl.useProgram(prog);
    const fieldReady = Boolean(store && bindFields(gl, fieldAt));
    presence += ((fieldReady ? 1 : 0) - presence) * (1 - Math.exp(-wallDt / (fieldReady ? .18 : .08)));
    // Stale field textures never light an unmatched video, even during IO.
    const visible = fieldReady ? presence * controls.reactive : 0;
    if (pkg) stepEffects(dt, events, quality);
    bind(gl, prog, 'uVideo', 0, videoTex);
    bind(gl, prog, 'uHistoryA', 1, cached ? historyTex[cached.a.slot] : nativePair ? presentationTex[nativePair.a.slot] : videoTex);
    bind(gl, prog, 'uHistoryB', 2, cached ? historyTex[cached.b.slot] : nativePair ? presentationTex[nativePair.b.slot] : videoTex);
    if (!fieldReady) { // all sampler bindings must still be complete before data arrives
      for (let k = 3; k < 7; k++) bind(gl, prog, ['uFieldA0','uFieldB0','uFieldA1','uFieldB1'][k-3], k, slots[(k-3)>>1][(k-3)%2?'b':'a']);
    }
    u1(gl, 'uHistory', 1); u1(gl, 'uHistoryMix', cached?.mix ?? frameMix); u1(gl, 'uFieldMix', fieldAt.mix);
    startup = Math.min(1, startup + wallDt / .20); u1(gl, 'uStartup', startup * startup * (3 - 2 * startup));
    u1(gl, 'uPresence', visible); u2(gl, 'uResolution', width, height); u2(gl, 'uVideoSize', asset.width, asset.height);
    u1(gl, 'uAspect', pkg?.camera.aspect || 16/9); u1(gl, 'uTan', pkg?.camera.tanHalfFov || .60086);
    // Float uniforms use a local axial origin, preserving precision after
    // prolonged loops. All three cameras come from actual source timestamps.
    for (let k = 0; k < 2; k++) helixSceneAt(pkg, sourceTimes[k] || 0, reference[k]);
    const originZ = reference[0].camera[2];
    scene.camera[2] -= originZ;
    for (let k = 0; k < 2; k++) {
      reference[k].camera[2] -= originZ;
      for (const [name, offset] of [['Position',0],['Forward',3],['Right',6],['Up',9]]) u3(gl, `uRef${name}${k}`, reference[k].camera, offset);
    }
    u2(gl, 'uRefTurns', reference[0].turn - scene.turn, reference[1].turn - scene.turn);
    u1(gl, 'uReproject', fieldReady ? 1 : 0);
    u3(gl, 'uPosition', scene.camera, 0); u3(gl, 'uForward', scene.camera, 3); u3(gl, 'uRight', scene.camera, 6); u3(gl, 'uUp', scene.camera, 9);
    const s = musicModel.state;
    for (const [name, value] of Object.entries({ Time: s.time, Energy: s.energy, Tension: s.tension, Flash: s.flash, Kick: s.kick, Bass: s.bass, Mids: s.mids, Highs: s.highs, Hat: s.hat })) u1(gl, `u${name}`, value);
    gl.uniform4f(loc(gl, prog, 'uAmounts'), controls.pulses, controls.glow, controls.waves, controls.circuits);
    u2(gl, 'uPolish', controls.compression, controls.bloom); ui(gl, 'uQuality', quality > .5 ? 1 : 0); ui(gl, 'uDebug', fieldReady ? controls.debug : 0);
    gl.uniform4fv(loc(gl, prog, 'uPackets[0]'), packetUniforms); gl.uniform4fv(loc(gl, prog, 'uWaves[0]'), waveUniforms);
    draw(gl, prog);
    publish(now, displayedTime, fieldReady, stamp);
  }
  function publish(now, displayedTime, fieldReady, stamp) {
    cpuTotal += performance.now() - stamp; cpuCount++;
    if (now - reportAt < (trial() ? 1000 : 3000)) return;
    const fps = reportAt ? (frames - reportFrames) * 1000 / (now - reportAt) : 0; reportAt = now; reportFrames = frames;
    const q = video?.getVideoPlaybackQuality?.();
    window.__helixTunnelDiagnostics = { videoTime: presentedTime, displayedVideoTime: wrappedMediaTime(displayedTime || 0, asset.durationSeconds),
      fieldTime: wrappedMediaTime(displayedTime || 0, asset.durationSeconds), fieldReady, videoReady, presentationStarted, generation, startup, mode, loops, seeks, fps,
      music: { ...musicModel.state }, targetRate: musicModel.state.target, decoderTime: video?.currentTime, decoderPaused: video?.paused, playbackRate: video?.playbackRate,
      packets: packets.filter(p => p.age >= 0).length, waves: waves.filter(w => w.age >= 0).length,
      decoder: decoder ? 'webcodecs' : 'html-video', decoderStats: decoder?.stats(), decoderFallback, callbackRearms, bufferLead: presentation.newest - (presentationClock.time || 0), decoderBuffered, historyFrames: history.count, historyMB: HISTORY * HISTORY_W * HISTORY_H * 4 / 1048576,
      decodedWindowMB: (store?.size() || 0) * asset.fieldWidth * asset.fieldHeight * 8 / 1048576,
      store: store ? { ...store.stats } : null, cpuMs: cpuTotal / Math.max(1, cpuCount),
      documentFocus: document.hasFocus(), documentVisibility: document.visibilityState,
      videoUploadMs: uploadMs / Math.max(1, uploadCount), maxUploadMs,
      callbackAgeMs: performance.now() - frameAt, frameIntervalMs: frameInterval * 1000, totalVideoFrames: q?.totalVideoFrames || 0,
      droppedVideoFrames: q?.droppedVideoFrames || 0, error, fatal, rvfc: Boolean(video?.requestVideoFrameCallback),
      blendedFrames, presentationFrames, backwardsFrames, bufferUnderflows, presentationDiscontinuities, forwardJumpMax, presentationTextureMB: PRESENTATION * asset.width * asset.height * 4 / 1048576,
      sample: helixSampleAt(wrappedMediaTime(displayedTime || 0, asset.durationSeconds), asset.fps, asset.frames) };
    if (trial()) window.webkit?.messageHandlers?.nativeApp?.postMessage({ command: 'logConsole', type: 'info', text: `[HelixTunnel] ${JSON.stringify(window.__helixTunnelDiagnostics)}` });
    cpuTotal = cpuCount = 0;
  }
  function stop() {
    if (!active) return; active = false; generation++;
    if (callback && video?.cancelVideoFrameCallback) video.cancelVideoFrameCallback(callback); callback = 0;
    video?.pause(); video?.removeAttribute('src'); video?.load(); video?.remove(); video = null;
    decoder?.stop(); decoder = null; decoderFallback = '';
    store?.dispose(); store = pkg = null;
    const gl = getGl();
    for (const t of [videoTex, ...presentationTex, ...historyTex, ...slots.flatMap(s => [s.a, s.b])]) if (t) gl.deleteTexture(t);
    for (const fb of [...historyFb, ...presentationFb]) gl.deleteFramebuffer(fb);
    for (const p of [prog, copy]) if (p) gl.deleteProgram(p);
    videoTex = prog = copy = null; presentationTex = []; presentationFb = []; presentation.clear(); presentationClock.reset(); historyTex = historyFb = slots = []; history.clear(); clearEffects();
    window.__helixTunnelVideo = window.__helixTunnelControls = window.__helixTunnelDiagnostics = null;
  }
  return { prepare, render, stop, controls, isActive: () => active };
}
