export class PresetShaderModuleCache {
  constructor({
    modules,
    compileModule,
    shouldDeferCompile,
    isActive,
    activeDeferDelay = 6000,
    idleDeferDelay = 1200,
    onModuleReady,
    onModuleError
  }) {
    this.modules = modules || new Map();
    this.compileModule = compileModule;
    this.shouldDeferCompile = shouldDeferCompile;
    this.isActive = isActive;
    this.activeDeferDelay = activeDeferDelay;
    this.idleDeferDelay = idleDeferDelay;
    this.onModuleReady = onModuleReady;
    this.onModuleError = onModuleError;
    this.programs = new Map();
    this.errors = new Map();
    this.primeTimers = new Map();
  }

  moduleId(presetValue) {
    const id = Math.round(Number(presetValue) || 0);
    return this.modules.has(id) ? id : null;
  }

  ids() {
    return Array.from(this.modules.keys());
  }

  variantFor(module, qualityValue = 0) {
    if (!module?.qualitySources) {
      return { key: "default", source: module?.source || "" };
    }
    const key = Number(qualityValue) > 0.5 ? "high" : "standard";
    return { key, source: module.qualitySources[key] || module.source || "" };
  }

  cacheKey(moduleId, variant) {
    return `${moduleId}:${variant.key}`;
  }

  programFor(presetValue, qualityValue = 0) {
    const moduleId = this.moduleId(presetValue);
    if (moduleId === null) return null;
    const variant = this.variantFor(this.modules.get(moduleId), qualityValue);
    return this.programs.get(this.cacheKey(moduleId, variant)) || null;
  }

  hasError(presetValue, qualityValue = 0) {
    const moduleId = this.moduleId(presetValue);
    if (moduleId === null) return false;
    const variant = this.variantFor(this.modules.get(moduleId), qualityValue);
    return this.errors.has(this.cacheKey(moduleId, variant));
  }

  errorFor(presetValue, qualityValue = 0) {
    const moduleId = this.moduleId(presetValue);
    if (moduleId === null) return "";
    const variant = this.variantFor(this.modules.get(moduleId), qualityValue);
    return this.errors.get(this.cacheKey(moduleId, variant)) || "";
  }

  diagnosticState(presetValue, qualityValue = 0) {
    const moduleId = this.moduleId(presetValue);
    if (moduleId === null) return { moduleId: null, state: "not-modular" };
    const variant = this.variantFor(this.modules.get(moduleId), qualityValue);
    const key = this.cacheKey(moduleId, variant);
    if (this.programs.has(key)) return { moduleId, variant: variant.key, state: "ready" };
    if (this.errors.has(key)) return { moduleId, variant: variant.key, state: "error", error: this.errors.get(key) || "" };
    if (this.primeTimers.has(key)) return { moduleId, variant: variant.key, state: "queued" };
    return { moduleId, variant: variant.key, state: "unprepared" };
  }

  queuePrime(presetValue, delay = 1200, active = false, qualityValue = 0) {
    const moduleId = this.moduleId(presetValue);
    if (moduleId === null) return;
    const variant = this.variantFor(this.modules.get(moduleId), qualityValue);
    const key = this.cacheKey(moduleId, variant);
    if (this.programs.has(key) || this.errors.has(key)) return;
    window.clearTimeout(this.primeTimers.get(key));
    this.primeTimers.set(key, window.setTimeout(() => {
      if (this.shouldDeferCompile?.()) {
        const nowActive = this.isActive?.() ?? active;
        this.queuePrime(moduleId, nowActive ? this.activeDeferDelay : this.idleDeferDelay, nowActive, qualityValue);
        return;
      }
      this.ensure(moduleId, { allowCompile: true, qualityValue });
    }, delay));
  }

  ensure(presetValue, options = {}) {
    const moduleId = this.moduleId(presetValue);
    if (moduleId === null) return null;
    const module = this.modules.get(moduleId);
    const variant = this.variantFor(module, options.qualityValue);
    const key = this.cacheKey(moduleId, variant);
    if (this.programs.has(key)) return this.programs.get(key);
    if (this.errors.has(key)) return null;
    if (options.force !== true && (options.allowCompile === false || this.shouldDeferCompile?.())) {
      this.queuePrime(moduleId, 1600, Boolean(options.active), options.qualityValue);
      return null;
    }
    try {
      const compiledModule = variant.source === module.source
        ? module
        : { ...module, source: variant.source, qualityVariant: variant.key };
      const compiled = this.compileModule(compiledModule);
      this.programs.set(key, compiled);
      this.onModuleReady?.(moduleId, compiledModule, compiled);
      return compiled;
    } catch (error) {
      const message = error?.message || "Preset shader module failed";
      this.errors.set(key, message);
      this.onModuleError?.(moduleId, module, message, error);
      return null;
    }
  }

  prime(presetValue, delay = 0, active = false, qualityValue = 0) {
    if (this.moduleId(presetValue) === null) return;
    this.queuePrime(presetValue, delay, active, qualityValue);
  }
}
