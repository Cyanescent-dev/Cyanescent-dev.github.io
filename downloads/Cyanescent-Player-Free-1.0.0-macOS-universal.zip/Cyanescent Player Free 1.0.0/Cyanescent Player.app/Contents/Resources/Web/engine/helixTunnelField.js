import { halfBitsToFloat } from './newtonBasinField.js';
export const HELIX_PLANES = ['classCoverage', 'luminousMask', 'flowX', 'flowY', 'turnLo', 'turnHi', 'depthLo', 'depthHi'];
export function helixSampleAt(time, fps, count) {
  const t = ((time * fps) % count + count) % count;
  const i0 = Math.floor(t), mix = t - i0;
  return { i0, i1: (i0 + 1) % count, mix };
}
export function helixTexel(a, b, o) {
  return { class: a[o] & 7, coverage: (a[o] >> 3) / 31, lit: a[o + 1] / 255,
    flow: [a[o + 2] / 255 * 2 - 1, a[o + 3] / 255 * 2 - 1],
    turn: halfBitsToFloat(b[o] | b[o + 1] << 8), depth: halfBitsToFloat(b[o + 2] | b[o + 3] << 8) };
}
export function helixSceneAt(pkg, time, out) {
  const at = helixSampleAt(time, pkg.source.fps, pkg.source.frames), tl = pkg.timeline;
  const lerp = (array, stride, k) => array[at.i0 * stride + k] + (array[at.i1 * stride + k] - array[at.i0 * stride + k]) * at.mix;
  for (let k = 0; k < 12; k++) out.camera[k] = lerp(tl.camera, 12, k);
  // Unwrapped axial position is needed for depth-based frame reprojection.
  // The local origin is recentered on the CPU before uploading uniforms.
  const cycle = Math.floor(time / pkg.source.durationSeconds);
  const periodZ = tl.cameraPeriodZ || 0;
  if (at.i1 === 0) out.camera[2] += periodZ * at.mix;
  out.camera[2] += cycle * periodZ;
  const a = tl.helix[at.i0 * 2], b = tl.helix[at.i1 * 2];
  // Global turns advance by a world period at the authored seamless closure.
  let delta = b - a;
  if (delta < -pkg.source.worldPeriodTurns * .5) delta += pkg.source.worldPeriodTurns;
  out.turn = a + delta * at.mix + Math.floor(time / pkg.source.durationSeconds) * pkg.source.worldPeriodTurns;
  out.pitch = lerp(tl.helix, 2, 1);
  for (let k = 0; k < tl.corridorCount * 2; k++) out.corridor[k] = lerp(tl.corridor, tl.corridorCount * 2, k);
  return at;
}
export function corridorRadius(corridor, ahead) {
  for (let i = 2; i < corridor.length; i += 2) {
    if (ahead <= corridor[i]) {
      const t = Math.max(0, Math.min(1, (ahead - corridor[i - 2]) / (corridor[i] - corridor[i - 2])));
      return corridor[i - 1] + (corridor[i + 1] - corridor[i - 1]) * t;
    }
  }
  return corridor[corridor.length - 1];
}
