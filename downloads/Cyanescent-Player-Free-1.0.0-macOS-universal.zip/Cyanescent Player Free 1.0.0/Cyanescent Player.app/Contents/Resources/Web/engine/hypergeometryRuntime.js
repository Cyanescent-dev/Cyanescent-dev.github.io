// Hypergeometry Engine: Dimensional Emergence — the live renderer (preset 398; the original
// Hypergeometry Engine is preset 11, unchanged).
//
// Rasterised 4D polytopes: static buffers carry 4D positions and cell centres; vertex shaders do
// the cell separation, the SO(4) rotation and the 4D -> 3D projection; a perspective camera views
// the projected 3D structure. Passes, into a private HDR target with depth:
//   1 Dimensional Aether: the procedural environment (sliced 4D hypersurfaces and their
//     interference, hypergeometryAether.js), sharing the polytope's SO(4) generators
//   2 the cross-section (exact slice of the polytope by the hyperplane w = h): opaque solid
//   3 cell facets: weighted blended order-independent transparency (accumulate + revealage),
//     composited over 1-2
//   4 edges and vertex nodes, additive, depth-tested against the cross-section, plus echoes of the
//     polytope at large scale around the viewer
//   5 grade into the frame target (normal preset transitions and blits work unchanged)
// Programs and polytope buffers are built once (warm()) and kept across stop/start.
import { createHypergeometryDirector, WORLDS } from "./hypergeometryDirector.js";
import { cellPositionFn, crossSection, rotationMatrix } from "./hypergeometryMath.js";
import { AETHER_SCALE, aetherFragment, aetherFrame, aetherUpsampleFragment } from "./hypergeometryAether.js";
import {
  edgeFragment, edgeVertex, faceFragment, faceVertex, gradeFragment,
  nodeFragment, nodeVertex, oitCompositeFragment, sliceFragment, sliceVertex
} from "./hypergeometryShaders.js";

export const HYPERGEOMETRY_ID = 398;
export const HYPERGEOMETRY_NAME = "Hypergeometry Engine: Dimensional Emergence";
const LOG_PREFIX = "[Hypergeometry]";
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, x));
// Large-scale echoes of the polytope around the viewer: tried and judged distracting (they read
// as scratches across the frame); the Dimensional Aether carries the environment instead.
const ECHOES = false;

// Fixture tokens: hg-w3 (world), -shot-interior, -section, -critical, -freeze, -high, -h50 (slice
// height 0.50, m for minus), -k80 (shrink 0.80), -drop12, -off, -nodrops.
export function parseHypergeometryFixture(fixture) {
  const controls = {};
  if (!/^hg-/.test(fixture || "")) return controls;
  const tokens = fixture.slice(3).split("-");
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    let m;
    if ((m = /^w(\d)$/.exec(token))) controls.world = Number(m[1]);
    else if (token === "shot" && tokens[i + 1]) { controls.shot = tokens[i + 1]; i += 1; }
    else if (token === "section") controls.section = 1;
    else if (token === "critical") controls.critical = true;
    else if (token === "freeze") controls.freeze = true;
    else if (token === "high") controls.quality = 1;
    else if ((m = /^h(m?)(\d+)$/.exec(token))) controls.h = (m[1] ? -1 : 1) * Number(m[2]) / 100;
    else if ((m = /^k(\d+)$/.exec(token))) controls.shrink = Number(m[1]) / 100;
    else if ((m = /^drop(\d+)$/.exec(token))) controls.dropAt = Number(m[1]);
    else if (token === "off") controls.reactive = 0;
    else if (token === "nodrops") controls.drops = 0;
    else if (token === "nofaces") controls.faces = 0;     // diagnostics: edges and nodes only
    else if (token === "noedges") controls.edges = 0;     // diagnostics: facets only
    else if (token === "noaether") controls.aether = 0;   // diagnostics: foreground on plain black
    else if (token === "aetheronly") controls.polytope = 0;   // diagnostics: environment alone
  }
  return controls;
}

// ---- static buffers for one polytope -------------------------------------------------------------
export function buildPolytopeMeshes(poly) {
  const hash = (i) => { const x = Math.sin(i * 12.9898) * 43758.5453; return x - Math.floor(x); };
  // Facets: every cell's faces, fanned from the face centre (border parameter 0 on the rim).
  const faces = [];
  poly.cells.forEach((cell, ci) => {
    for (const fi of cell.faces) {
      const f = poly.faces[fi].vertices;
      const centre = f.reduce((acc, i) => acc.map((x, k) => x + poly.vertices[i][k]), [0, 0, 0, 0]).map((x) => x / f.length);
      for (let k = 0; k < f.length; k += 1) {
        const a = poly.vertices[f[k]], b = poly.vertices[f[(k + 1) % f.length]];
        for (const [p, border] of [[centre, 1], [a, 0], [b, 0]]) faces.push(...p, ...cell.centre, ci, border, fi, hash(ci));
      }
    }
  });
  // Edges: per cell, so separated cells keep their own edges; at shrink 1 the copies coincide and
  // are weighted by 1 / multiplicity.
  const edges = [];
  const quad = [[0, -1], [0, 1], [1, -1], [1, -1], [0, 1], [1, 1]];
  poly.cells.forEach((cell, ci) => {
    for (const ei of cell.edges) {
      const [i, j] = poly.edges[ei], A = poly.vertices[i], B = poly.vertices[j];
      for (const [along, side] of quad) edges.push(...A, ...B, ...cell.centre, i, j, side, along, 1 / poly.edgeCells[ei], ci);
    }
  });
  // Nodes: per cell vertex.
  const vertexCells = poly.vertices.map(() => 0);
  poly.cells.forEach((c) => c.vertices.forEach((v) => { vertexCells[v] += 1; }));
  const nodes = [];
  const corners = [[-1, -1], [1, -1], [1, 1], [-1, -1], [1, 1], [-1, 1]];
  poly.cells.forEach((cell) => {
    for (const vi of cell.vertices) for (const [cx, cy] of corners) nodes.push(...poly.vertices[vi], ...cell.centre, vi, cx, cy, 1 / vertexCells[vi]);
  });
  // Unique facets (each 2D face once) for the joined state, where the per-cell copies coincide:
  // half the transparent layers to shade.
  const unique = [];
  poly.faces.forEach((face, fi) => {
    const f = face.vertices, cell = poly.cells[face.cells[0]], ci = face.cells[0];
    const centre = f.reduce((acc, i) => acc.map((x, k) => x + poly.vertices[i][k]), [0, 0, 0, 0]).map((x) => x / f.length);
    for (let k = 0; k < f.length; k += 1) {
      const a = poly.vertices[f[k]], b = poly.vertices[f[(k + 1) % f.length]];
      for (const [p, border] of [[centre, 1], [a, 0], [b, 0]]) unique.push(...p, ...cell.centre, ci, border, fi, hash(ci));
    }
  });
  return { faces: new Float32Array(faces), uniqueFaces: new Float32Array(unique), edges: new Float32Array(edges), nodes: new Float32Array(nodes) };
}

export function createHypergeometryRuntime({ getGl, program, programFrom, setAttribs }) {
  const director = createHypergeometryDirector();
  let active = false, fatal = "", gpu = null, lastAt = 0, frame = 0, controls = {}, startMs = 0;
  let reportAt = 0, reportFrames = 0, cpuMs = 0, cpuCount = 0;
  const locations = new WeakMap();
  const trial = () => typeof document !== "undefined" && document.body?.classList.contains("preset-trial-role");
  const loc = (gl, p, name) => {
    let map = locations.get(p);
    if (!map) { map = new Map(); locations.set(p, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(p, name));
    return map.get(name);
  };

  function ensureGpu() {
    const gl = getGl();
    if (gpu && gpu.gl === gl && !gl.isContextLost?.()) return gpu;
    gpu = null;
    if (!gl.getExtension("EXT_color_buffer_float")) throw new Error("float render targets are unavailable");
    const programs = {
      face: programFrom(faceVertex, faceFragment, [[0, "aPos"], [1, "aCell"], [2, "aMeta"]]),
      edge: programFrom(edgeVertex, edgeFragment, [[0, "aA"], [1, "aB"], [2, "aCell"], [3, "aMeta"], [4, "aMeta2"]]),
      node: programFrom(nodeVertex, nodeFragment, [[0, "aPos"], [1, "aCell"], [2, "aMeta"]]),
      slice: programFrom(sliceVertex, sliceFragment, [[0, "aPos"], [1, "aMeta"]]),
      oit: program(oitCompositeFragment), aether: program(aetherFragment), aetherUp: program(aetherUpsampleFragment), grade: program(gradeFragment)
    };
    for (const [name, value] of Object.entries(programs)) if (!value) throw new Error(`${name} program did not compile`);
    gpu = { gl, programs, meshes: new Map(), targets: null, slice: { vao: gl.createVertexArray(), vbo: gl.createBuffer(), count: 0 } };
    return gpu;
  }

  // GPU buffers for a polytope, built on first use.
  function meshFor(gl, name) {
    if (gpu.meshes.has(name)) return gpu.meshes.get(name);
    const P = director.polytope(name);
    const m = buildPolytopeMeshes(P.poly);
    const make = (data, layout) => {
      const vao = gl.createVertexArray(), vbo = gl.createBuffer();
      gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
      gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      const stride = layout.reduce((s, n) => s + n, 0) * 4;
      let offset = 0;
      layout.forEach((n, i) => { gl.enableVertexAttribArray(i); gl.vertexAttribPointer(i, n, gl.FLOAT, false, stride, offset); offset += n * 4; });
      gl.bindVertexArray(null);
      return { vao, vbo, count: data.length / layout.reduce((s, n) => s + n, 0) };
    };
    const n = P.poly.vertices.length;
    const dist = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, dist);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8UI, n, n, 0, gl.RED_INTEGER, gl.UNSIGNED_BYTE, P.dist);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    const mesh = { faces: make(m.faces, [4, 4, 4]), uniqueFaces: make(m.uniqueFaces, [4, 4, 4]), edges: make(m.edges, [4, 4, 4, 4, 2]), nodes: make(m.nodes, [4, 4, 4]), dist, poly: P.poly };
    gpu.meshes.set(name, mesh);
    return mesh;
  }

  function ensureTargets(gl, width, height) {
    if (gpu.targets && gpu.targets.w === width && gpu.targets.h === height) return gpu.targets;
    if (gpu.targets) for (const t of [gpu.targets.scene, gpu.targets.accum, gpu.targets.reveal]) { gl.deleteTexture(t.tex); gl.deleteFramebuffer(t.fb); }
    if (gpu.targets) { gl.deleteRenderbuffer(gpu.targets.depth); gl.deleteFramebuffer(gpu.targets.oit); }
    const depth = gl.createRenderbuffer();
    gl.bindRenderbuffer(gl.RENDERBUFFER, depth);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, width, height);
    const make = (internal, format, type) => {
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, internal, width, height, 0, format, type, null);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      const fb = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depth);
      const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
      if (status !== gl.FRAMEBUFFER_COMPLETE) throw new Error(`target incomplete (${status})`);
      return { tex, fb };
    };
    gpu.targets = { w: width, h: height, depth, scene: make(gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT), accum: make(gl.RGBA16F, gl.RGBA, gl.HALF_FLOAT), reveal: make(gl.R16F, gl.RED, gl.HALF_FLOAT) };
    // Both transparency targets in one framebuffer (multiple render targets, one pass).
    const oit = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, oit);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, gpu.targets.accum.tex, 0);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT1, gl.TEXTURE_2D, gpu.targets.reveal.tex, 0);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depth);
    gl.drawBuffers([gl.COLOR_ATTACHMENT0, gl.COLOR_ATTACHMENT1]);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error("transparency target incomplete");
    gpu.targets.oit = oit;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return gpu.targets;
  }

  // The environment's own (smaller) target; its size depends on the quality setting.
  function ensureAetherTarget(gl, width, height, quality) {
    const w = Math.max(1, Math.round(width * AETHER_SCALE[quality])), h = Math.max(1, Math.round(height * AETHER_SCALE[quality]));
    const old = gpu.aetherTarget;
    if (old && old.w === w && old.h === h) return old;
    if (old) { gl.deleteTexture(old.tex); gl.deleteFramebuffer(old.fb); }
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error("environment target incomplete");
    gpu.aetherTarget = { tex, fb, w, h };
    return gpu.aetherTarget;
  }

  // Compile and draw every program once into a 1x1 corner of target, and build the first world's
  // buffers, so the first live frame never compiles.
  function warm(target) {
    const gl = getGl();
    try {
      const g = ensureGpu();
      // Build every world now (the 120-cell and 600-cell take tens of milliseconds).
      for (const world of WORLDS) meshFor(gl, world.polytope);
      gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
      gl.viewport(0, 0, 1, 1);
      gl.disable(gl.BLEND); gl.disable(gl.DEPTH_TEST);
      for (const name of ["oit", "aether", "aetherUp", "grade"]) { gl.bindVertexArray(null); gl.useProgram(g.programs[name]); setAttribs(g.programs[name]); gl.drawArrays(gl.TRIANGLES, 0, 3); }
      const mesh = meshFor(gl, WORLDS[0].polytope);
      for (const [name, part] of [["face", "faces"], ["edge", "edges"], ["node", "nodes"]]) {
        gl.useProgram(g.programs[name]); gl.bindVertexArray(mesh[part].vao); gl.drawArrays(gl.TRIANGLES, 0, 3);
      }
      gl.useProgram(g.programs.slice); gl.bindVertexArray(g.slice.vao); gl.drawArrays(gl.TRIANGLES, 0, 0);
      gl.bindVertexArray(null);
    } catch (error) {
      fatal = String(error?.message || error);
      console.error(`${LOG_PREFIX} warm-up failed:`, error);
    }
  }

  function start() {
    active = true; fatal = ""; frame = 0; lastAt = 0;
    director.reset();
    const query = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("fixture") || "" : "";
    controls = { ...parseHypergeometryFixture(query), ...(controls.external || {}) };
    if (Number.isFinite(controls.world)) director.state.world = controls.world;
    const begin = performance.now();
    try { ensureGpu(); } catch (error) { fatal = String(error?.message || error); console.error(`${LOG_PREFIX} GPU setup failed:`, error); }
    startMs = performance.now() - begin;
  }

  // ---- camera --------------------------------------------------------------------------------------
  function cameraMatrices(s, aspect) {
    const { dist, pitch, yaw, fov } = s.cam;
    const eye = [dist * Math.cos(pitch) * Math.sin(yaw), dist * Math.sin(pitch), dist * Math.cos(pitch) * Math.cos(yaw)];
    // Inside the structure the camera looks outwards along its orbit rather than at the centre.
    // Always look at the centre: from inside the projection the nested shells surround the camera
    // (the view the original background image echoes), from outside the whole object is framed.
    const target = [0, 0, 0];
    let f = [target[0] - eye[0], target[1] - eye[1], target[2] - eye[2]];
    const fl = Math.hypot(...f) || 1; f = f.map((x) => x / fl);
    let r = [-f[2], 0, f[0]];
    const rl = Math.hypot(...r) || 1; r = r.map((x) => x / rl);
    const u = [r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]];
    const view = [r[0], u[0], -f[0], 0, r[1], u[1], -f[1], 0, r[2], u[2], -f[2], 0,
      -(r[0] * eye[0] + r[1] * eye[1] + r[2] * eye[2]), -(u[0] * eye[0] + u[1] * eye[1] + u[2] * eye[2]), f[0] * eye[0] + f[1] * eye[1] + f[2] * eye[2], 1];
    const near = 0.02, far = 200, k = 1 / Math.tan(fov / 2);
    const proj = [k / aspect, 0, 0, 0, 0, k, 0, 0, 0, 0, (far + near) / (near - far), -1, 0, 0, (2 * far * near) / (near - far), 0];
    const vp = new Float32Array(16);
    for (let c = 0; c < 4; c += 1) for (let rr = 0; rr < 4; rr += 1) {
      let sum = 0;
      for (let q = 0; q < 4; q += 1) sum += proj[q * 4 + rr] * view[c * 4 + q];
      vp[c * 4 + rr] = sum;
    }
    return { vp, eye, basis: { eye, r, u, f } };
  }

  // ---- uniforms shared by the geometry programs --------------------------------------------------
  function setCommon(gl, p, u) {
    gl.uniformMatrix4fv(loc(gl, p, "uRot"), false, u.rot);
    gl.uniform1f(loc(gl, p, "uShrink"), u.shrink);
    gl.uniform1f(loc(gl, p, "uProjD"), u.projD);
    gl.uniform1f(loc(gl, p, "uPersp"), u.persp);
    gl.uniform1f(loc(gl, p, "uScale"), u.scale);
    gl.uniformMatrix4fv(loc(gl, p, "uViewProj"), false, u.vp);
    gl.uniform3fv(loc(gl, p, "uCamPos"), u.eye);
    gl.uniform4f(loc(gl, p, "uHue"), u.hue, u.saturation, 0, 0);
    gl.uniform2f(loc(gl, p, "uClip"), u.clip[0], u.clip[1]);
    gl.uniform2f(loc(gl, p, "uViewport"), u.width / 2, u.height / 2);
    gl.uniform1f(loc(gl, p, "uFlash"), u.flash);
  }
  function setPulses(gl, p, mesh, pulses, dist, density = 1) {
    const data = new Float32Array(32);
    let count = 0;
    for (const pulse of pulses) {
      if (count >= 8 || pulse.age < 0 || pulse.source >= mesh.poly.vertices.length) continue;
      const fade = clamp(1 - pulse.age * pulse.speed / (dist + 3));
      data.set([pulse.source, pulse.age * pulse.speed, pulse.strength * fade * (0.35 + 0.65 * density), 0.24], count * 4);
      count += 1;
    }
    gl.uniform4fv(loc(gl, p, "uPulse[0]"), data);
    gl.uniform1i(loc(gl, p, "uPulseCount"), count);
    gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, mesh.dist);
    gl.uniform1i(loc(gl, p, "uDist"), 3);
    gl.activeTexture(gl.TEXTURE0);
  }

  function drawPolytope(gl, mesh, u, s, quality, clip, kind) {
    const P = gpu.programs, T = gpu.targets;
    const uu = { ...u, clip };
    const diameter = director.polytope(mesh.poly.name).diameter;
    const dupWeight = clamp((1 - s.shrink) / 0.04);
    const density = WORLDS.find((w) => w.polytope === mesh.poly.name)?.density ?? 1;
    if (kind === "faces") {
      gl.useProgram(P.face); setCommon(gl, P.face, uu);
      // Joined: each face once (unique buffer); separated: every cell's own faces, more glass each.
      const joined = dupWeight < 0.01;
      gl.uniform4f(loc(gl, P.face, "uFace"), s.faceOpacity * density * (joined ? 1.1 : 0.55 + 0.9 * dupWeight), 2.2, 0.14, s.energy);
      gl.uniform4f(loc(gl, P.face, "uLightA"), 0.4, 0.8, 0.45, 1.0);
      gl.uniform1f(loc(gl, P.face, "uCellTint"), 0.25 + 0.6 * dupWeight);
      gl.uniform1f(loc(gl, P.face, "uDetail"), quality ? 1 : 0);
      const faces = joined ? mesh.uniqueFaces : mesh.faces;
      gl.bindVertexArray(faces.vao);
      gl.bindFramebuffer(gl.FRAMEBUFFER, T.oit);
      gl.blendFunc(gl.ONE, gl.ONE);
      gl.drawArrays(gl.TRIANGLES, 0, faces.count);
      return;
    }
    if (kind === "edges") {
      gl.useProgram(P.edge); setCommon(gl, P.edge, uu);
      setPulses(gl, P.edge, mesh, director.pulses, diameter, density);
      gl.uniform1f(loc(gl, P.edge, "uWidth"), (quality ? 5.4 : 4.6) * (u.height / 1080) * 1.4);
      gl.uniform1f(loc(gl, P.edge, "uEnvScale"), 1);
      gl.uniform4f(loc(gl, P.edge, "uEdge"), s.edgeIntensity * (0.2 + 0.8 * density), dupWeight, 0.06, s.highs);
      gl.bindVertexArray(mesh.edges.vao);
      gl.drawArrays(gl.TRIANGLES, 0, mesh.edges.count);
      // Echoes: the same polytope, same 4D rotation, at large scale around the viewer.
      if (ECHOES && s.echo > 0.01 && clip[1] === 0) {
        gl.uniform4f(loc(gl, P.edge, "uEdge"), s.edgeIntensity * 0.01 * s.echo * density, dupWeight, 0.1, s.highs);
        gl.uniform1f(loc(gl, P.edge, "uWidth"), 0.6 * (u.height / 1080));
        for (const scale of [14]) {
          gl.uniform1f(loc(gl, P.edge, "uEnvScale"), scale);
          gl.drawArrays(gl.TRIANGLES, 0, mesh.edges.count);
        }
      }
      gl.useProgram(P.node); setCommon(gl, P.node, uu);
      setPulses(gl, P.node, mesh, director.pulses, diameter, density);
      gl.uniform1f(loc(gl, P.node, "uNodeSize"), (quality ? 3.6 : 3.0) * (u.height / 1080) * 1.4);
      gl.uniform4f(loc(gl, P.node, "uNode"), s.edgeIntensity * 0.9 * density, dupWeight, (s.highs * 0.6 + s.hatGlint) * density, s.time);
      gl.bindVertexArray(mesh.nodes.vao);
      gl.drawArrays(gl.TRIANGLES, 0, mesh.nodes.count);
    }
  }

  // Cross-section polygons -> dynamic triangle buffer (fans with a border parameter).
  function uploadSection(gl, polys) {
    const data = [];
    for (const poly of polys) {
      const c = [...poly.centre, poly.points[0][3]];
      const n = poly.points.length;
      for (let k = 0; k < n; k += 1) {
        const a = poly.points[k], b = poly.points[(k + 1) % n];
        data.push(...c, poly.cell, 1, 0, 0, ...a, poly.cell, 0, 0, 0, ...b, poly.cell, 0, 0, 0);
      }
    }
    const arr = new Float32Array(data);
    const sl = gpu.slice;
    gl.bindVertexArray(sl.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, sl.vbo);
    gl.bufferData(gl.ARRAY_BUFFER, arr, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 32, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 32, 16);
    gl.bindVertexArray(null);
    sl.count = arr.length / 8;
  }

  // The environment: one full-screen pass. The polytope's screen footprint (its circumsphere seen
  // from the camera) is passed so interference detail softens behind the glass.
  function drawAether(gl, s, basis, width, height, quality, world) {
    const P = gpu.programs.aether;
    const aspect = width / height, fov = s.cam.fov;
    const dist = Math.hypot(...basis.eye);
    const radius = world.scale * 1.15;
    const angular = dist > radius ? Math.asin(radius / dist) : Math.PI / 2;
    const focus = [0, 0, Math.min(4, Math.tan(angular) / Math.tan(fov / 2)), controls.polytope === 0 ? 0 : 0.75];
    const a = aetherFrame(s, basis, { quality, aspect, fov, focus });
    const A = ensureAetherTarget(gl, width, height, quality);
    gl.bindFramebuffer(gl.FRAMEBUFFER, A.fb);
    gl.viewport(0, 0, A.w, A.h);
    gl.useProgram(P); setAttribs(P);
    gl.uniform1i(loc(gl, P, "uCount"), a.count);
    gl.uniformMatrix3x4fv(loc(gl, P, "uG[0]"), false, a.G);
    gl.uniform4fv(loc(gl, P, "uY0[0]"), a.Y0);
    gl.uniform4fv(loc(gl, P, "uD[0]"), a.D);
    gl.uniform4fv(loc(gl, P, "uLin[0]"), a.lin);
    gl.uniform4fv(loc(gl, P, "uMem[0]"), a.mem);
    gl.uniform4fv(loc(gl, P, "uMem2[0]"), a.mem2);
    gl.uniform3fv(loc(gl, P, "uCamR"), a.cam.R);
    gl.uniform3fv(loc(gl, P, "uCamU"), a.cam.U);
    gl.uniform3fv(loc(gl, P, "uCamF"), a.cam.F);
    gl.uniform2fv(loc(gl, P, "uTan"), a.tan);
    gl.uniform2f(loc(gl, P, "uRes"), A.w, A.h);
    gl.uniform4fv(loc(gl, P, "uMusic"), a.music);
    gl.uniform4fv(loc(gl, P, "uSweep"), a.sweep);
    gl.uniform4fv(loc(gl, P, "uFocus"), a.focus);
    gl.uniform4fv(loc(gl, P, "uAxis"), a.axis);
    gl.uniform4fv(loc(gl, P, "uParams"), a.params);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    // Upsample into the scene as its first layer.
    gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.targets.scene.fb);
    gl.viewport(0, 0, width, height);
    const U = gpu.programs.aetherUp;
    gl.useProgram(U); setAttribs(U);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, A.tex);
    gl.uniform1i(loc(gl, U, "uAether"), 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  function render({ target, width, height, now, quality = 0, playing = true, audio = {}, smooth = {}, music = {}, lookahead = {}, tempo = {} }) {
    if (!active) start();
    const stamp = performance.now();
    const gl = getGl();
    const dt = lastAt ? clamp((now - lastAt) / 1000, 0, 0.1) : 1 / 60;
    lastAt = now; frame += 1;
    if (!fatal) { try { ensureGpu(); ensureTargets(gl, width, height); } catch (error) { fatal = String(error?.message || error); } }
    if (fatal || !gpu) { gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb); gl.viewport(0, 0, width, height); gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); publish(now); return; }

    director.step(playing ? dt : 0, { audio, smooth, music, lookahead, tempo }, controls);
    const s = director.state;
    const q = (controls.quality ?? quality) > 0.5 ? 1 : 0;
    const rot = rotationMatrix(s.qL, s.qR);
    const { vp, eye, basis } = cameraMatrices(s, width / height);
    const world = WORLDS[s.world];
    const u = { rot, shrink: s.shrink, projD: s.projD, persp: s.persp, vp, eye, hue: world.hue + s.hue, saturation: s.saturation, width, height, flash: s.flash, scale: world.scale };
    const current = meshFor(gl, WORLDS[s.world].polytope);
    // Vertex nearest the 4D viewpoint (downbeat pulses start there).
    let front = 0, best = -Infinity;
    current.poly.vertices.forEach((v, i) => { const w = rot[3] * v[0] + rot[7] * v[1] + rot[11] * v[2] + rot[15] * v[3]; if (w > best) { best = w; front = i; } });
    s.frontVertex = front;

    const T = gpu.targets, P = gpu.programs;
    gl.disable(gl.CULL_FACE); gl.disable(gl.SCISSOR_TEST);
    // 1 Dimensional Aether
    gl.bindFramebuffer(gl.FRAMEBUFFER, T.scene.fb);
    gl.viewport(0, 0, width, height);
    // Other renderers can leave the write masks off between frames; a depth clear with
    // depthMask(false) silently does nothing, and the previous frame's cross-section would then
    // hide the polytope.
    gl.depthMask(true); gl.colorMask(true, true, true, true);
    gl.clearColor(0, 0, 0, 1); gl.clearDepth(1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.BLEND);
    gl.bindVertexArray(null);
    if (controls.aether !== 0) drawAether(gl, s, basis, width, height, q, world);

    // Which polytopes are on screen, and with what clipping (the sweep between worlds).
    const layers = [];
    if (s.sweep) {
      layers.push({ mesh: meshFor(gl, WORLDS[s.sweep.from].polytope), clip: [s.sweep.h, -1] });   // old: w < h
      layers.push({ mesh: meshFor(gl, WORLDS[s.sweep.to].polytope), clip: [s.sweep.h, 1] });     // new: w > h
    } else layers.push({ mesh: current, clip: [0, 0] });

    // 2 cross-sections: the interface of a sweep, or the moving section in breakdowns
    const sections = [];
    const showPolytope = controls.polytope !== 0;
    if (!showPolytope) { /* environment alone */ }
    else if (s.sweep) for (const layer of layers) sections.push(...crossSection(layer.mesh.poly, cellPositionFn(layer.mesh.poly, rot, s.shrink), s.sweep.h));
    else if (s.sectionMix > 0.02) sections.push(...crossSection(current.poly, cellPositionFn(current.poly, rot, s.shrink), s.sectionH));
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.depthMask(true);
    if (sections.length) {
      uploadSection(gl, sections);
      gl.useProgram(P.slice);
      gl.uniform1f(loc(gl, P.slice, "uProjD"), u.projD);
      gl.uniform1f(loc(gl, P.slice, "uPersp"), u.persp);
      gl.uniform1f(loc(gl, P.slice, "uScale"), u.scale);
      gl.uniformMatrix4fv(loc(gl, P.slice, "uViewProj"), false, vp);
      gl.uniform3fv(loc(gl, P.slice, "uCamPos"), eye);
      gl.uniform4f(loc(gl, P.slice, "uHue"), u.hue, u.saturation, 0, 0);
      gl.uniform4f(loc(gl, P.slice, "uLightA"), 0.4, 0.8, 0.45, 1);
      const h = s.sweep ? s.sweep.h : s.sectionH;
      gl.uniform4f(loc(gl, P.slice, "uSlice"), s.sweep ? 1.2 : Math.min(1, s.sectionMix * 1.4), h, s.energy, s.kickPulse);
      gl.bindVertexArray(gpu.slice.vao);
      gl.drawArrays(gl.TRIANGLES, 0, gpu.slice.count);
    }

    // 3 facets: weighted blended OIT
    gl.depthMask(false);
    gl.enable(gl.BLEND);
    gl.bindFramebuffer(gl.FRAMEBUFFER, T.oit); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    if (controls.faces !== 0 && showPolytope) for (const layer of layers) drawPolytope(gl, layer.mesh, u, s, q, layer.clip, "faces");
    gl.bindFramebuffer(gl.FRAMEBUFFER, T.scene.fb);
    gl.disable(gl.DEPTH_TEST);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.bindVertexArray(null);
    gl.useProgram(P.oit); setAttribs(P.oit);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.accum.tex);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, T.reveal.tex);
    gl.uniform1i(loc(gl, P.oit, "uAccum"), 0); gl.uniform1i(loc(gl, P.oit, "uReveal"), 1);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.activeTexture(gl.TEXTURE0);

    // 4 edges and nodes (additive, depth-tested against the cross-section)
    gl.enable(gl.DEPTH_TEST);
    gl.blendFunc(gl.ONE, gl.ONE);
    if (controls.edges !== 0 && showPolytope) for (const layer of layers) drawPolytope(gl, layer.mesh, u, s, q, layer.clip, "edges");
    gl.disable(gl.BLEND); gl.disable(gl.DEPTH_TEST); gl.depthMask(true);
    gl.bindVertexArray(null);

    // 5 grade into the frame target
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    gl.useProgram(P.grade); setAttribs(P.grade);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.scene.tex);
    gl.uniform1i(loc(gl, P.grade, "uScene"), 0);
    gl.uniform4f(loc(gl, P.grade, "uGrade"), s.exposure, 0.35, s.saturation, s.flash * 0.25);
    gl.uniform2f(loc(gl, P.grade, "uRes"), width, height);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    cpuMs += performance.now() - stamp; cpuCount += 1;
    publish(now, { width, height, quality: q ? "high" : "standard", sections: sections.length });
  }

  function publish(now, extra = {}) {
    if (now - reportAt < (trial() ? 1000 : 3000)) return;
    const fps = reportAt ? (frame - reportFrames) * 1000 / (now - reportAt) : 0;
    reportAt = now; reportFrames = frame;
    const s = director.state;
    const diagnostics = {
      fatal, fps, cpuMs: +(cpuMs / Math.max(1, cpuCount)).toFixed(2), startMs: +startMs.toFixed(1), ...extra,
      t: +s.time.toFixed(1), world: WORLDS[s.world].polytope, sweep: s.sweep ? +s.sweep.h.toFixed(2) : null, shot: s.shot,
      phase: s.phase, energy: +s.energy.toFixed(2), groove: +s.groove.toFixed(2), breakdown: +s.breakdown.toFixed(2),
      tension: +s.tension.toFixed(2), section: +s.sectionMix.toFixed(2), shrink: +s.shrink.toFixed(2), kicks: s.kicks, drops: s.drops,
      pulses: director.pulses.length, beatSource: director.audioState?.beatSource, controls
    };
    if (typeof window !== "undefined") window.__hypergeometryDiagnostics = diagnostics;
    cpuMs = 0; cpuCount = 0;
    if (trial()) window.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "info", text: `${LOG_PREFIX} ${JSON.stringify(diagnostics)}` });
  }

  function stop() {
    if (!active) return;
    active = false;
    if (typeof window !== "undefined") window.__hypergeometryDiagnostics = null;
  }
  function setControls(next) { controls = { ...controls, ...next, external: next }; }

  return { render, stop, warm, director, controls: () => controls, setControls, isActive: () => active };
}
