const fieldSampling = `
uniform sampler2D uDensity0;
uniform sampler2D uDensity1;
uniform sampler2D uFlow0;
uniform sampler2D uFlow1;
uniform float uFieldMix;
float densityAt(vec2 uv) {
  return mix(texture(uDensity0, uv).r, texture(uDensity1, uv).r, uFieldMix);
}
vec3 flowAt(vec2 uv) {
  vec3 raw = mix(texture(uFlow0, uv).rgb, texture(uFlow1, uv).rgb, uFieldMix);
  return vec3((raw.rg * 255.0 - 128.0) / 127.0, raw.b);
}
`;

export const forgeExcitationSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uPrevious;
uniform vec2 uTexel;
uniform float uDelta;
uniform float uDecay;
uniform float uPropagation;
uniform float uTransport;
uniform vec4 uDeposits[8];
${fieldSampling}
void main() {
  float d = densityAt(vUv);
  vec3 flow = flowAt(vUv);
  // Forge +Y is down; texture +Y is up. Confidence gates advection.
  vec2 velocity = vec2(flow.x, -flow.y) * flow.z * uTransport;
  vec2 sourceUv = clamp(vUv - velocity * uTexel * uDelta * 14.0, vec2(0.0), vec2(1.0));
  float old = texture(uPrevious, sourceUv).r;
  float neighbors = (
    texture(uPrevious, vUv + vec2(uTexel.x, 0.0)).r +
    texture(uPrevious, vUv - vec2(uTexel.x, 0.0)).r +
    texture(uPrevious, vUv + vec2(0.0, uTexel.y)).r +
    texture(uPrevious, vUv - vec2(0.0, uTexel.y)).r) * 0.25;
  float retained = mix(old, neighbors, min(0.20, uDelta * (0.25 + uPropagation * 2.0)));
  float highNeighbor = max(max(
    texture(uPrevious, vUv + vec2(uTexel.x, 0.0)).r,
    texture(uPrevious, vUv - vec2(uTexel.x, 0.0)).r), max(
    texture(uPrevious, vUv + vec2(0.0, uTexel.y)).r,
    texture(uPrevious, vUv - vec2(0.0, uTexel.y)).r));
  float pathway = smoothstep(0.035, 0.30, d);
  retained = max(retained, highNeighbor * mix(0.12, 0.94, pathway) * (0.55 + 0.45 * uPropagation));
  // Survival must be expressed per second. A per-frame multiplier made even
  // dense tubes lose their excitation before a signal could propagate.
  retained *= exp(-uDelta * (uDecay * mix(2.5, 0.48, pathway) + 1.1 * (1.0 - pathway)));
  for (int i = 0; i < 8; ++i) {
    vec4 event = uDeposits[i];
    if (event.z <= 0.0) continue;
    vec2 delta = (vUv - event.xy) * vec2(1.7777778, 1.0);
    retained += event.z * exp(-dot(delta, delta) / max(0.00001, event.w * event.w)) * (0.25 + 0.75 * d);
  }
  outColor = vec4(clamp(retained, 0.0, 1.0), 0.0, 0.0, 1.0);
}`;

export const forgeCompositeSource = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uVideo;
uniform sampler2D uExcitation;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform float uMaster;
uniform float uAugmentationOpacity;
uniform float uVideoReady;
uniform float uLoopFade;
uniform int uDomVideo;
uniform int uDebug;
${fieldSampling}
void main() {
  vec2 uv = vUv;
  if (uCanvasAspect > uVideoAspect) uv.x = (uv.x - 0.5) * (uCanvasAspect / uVideoAspect) + 0.5;
  else uv.y = (uv.y - 0.5) * (uVideoAspect / uCanvasAspect) + 0.5;
  if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) {
    outColor = vec4(0.004, 0.005, 0.011, 1.0);
    return;
  }
  vec3 beauty = texture(uVideo, vec2(uv.x, 1.0 - uv.y)).rgb * uVideoReady;
  float d = densityAt(uv);
  vec3 flow = flowAt(uv);
  float excitation = texture(uExcitation, uv).r;
  if (uDebug == 6) {
    float alpha = smoothstep(0.08, 0.58, d) * 0.58;
    outColor = uDomVideo == 1 ? vec4(vec3(0.88, 0.04, 0.12) * alpha, alpha) : vec4(mix(beauty, vec3(0.88, 0.04, 0.12), alpha), 1.0);
    return;
  }
  if (uDebug == 1) { outColor = vec4(vec3(d), 1.0); return; }
  if (uDebug == 2) { outColor = vec4(0.5 + flow.x * 0.5, 0.5 - flow.y * 0.5, flow.z, 1.0); return; }
  if (uDebug == 3) { outColor = vec4(excitation, excitation * 0.65, excitation * 0.24, 1.0); return; }
  if (uDebug == 5 || uDebug == 7) { outColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
  if (uDebug == 9) { outColor = uDomVideo == 1 ? vec4(0.0, 0.0, 0.0, 0.45) : vec4(beauty * 0.55, 1.0); return; }
  if (uDebug == 4 && vUv.x < 0.5) { outColor = uDomVideo == 1 ? vec4(0.0) : vec4(beauty * uLoopFade, 1.0); return; }
  // Borrow hue from the Forge pixel. Dark substrate receives almost nothing.
  float sourceLight = max(beauty.r, max(beauty.g, beauty.b));
  vec3 localHue = mix(beauty / max(sourceLight, 0.12), vec3(1.0), 0.27);
  float signal = pow(excitation, 0.72) * smoothstep(0.10, 0.30, d) * smoothstep(0.24, 0.50, flow.z) *
    smoothstep(0.028, 0.20, sourceLight) * uMaster * uAugmentationOpacity;
  if (uDomVideo == 1) {
    float alpha = clamp(signal * 0.72, 0.0, 0.75);
    vec3 target = localHue * (0.72 + sourceLight * 0.28);
    if (uDebug == 4 && abs(vUv.x - 0.5) < 0.0015) { outColor = vec4(vec3(0.62), 1.0); return; }
    outColor = vec4(target * alpha, alpha);
    return;
  }
  vec3 color = beauty + (vec3(1.0) - beauty) * localHue * signal * 0.88;
  if (uDebug == 4 && abs(vUv.x - 0.5) < 0.0015) color = vec3(0.62);
  outColor = vec4(min(color * uLoopFade, vec3(1.0)), 1.0);
}`;

export const forgeBraidVertexSource = `#version 300 es
precision highp float;
layout(location = 0) in vec4 aPath;
layout(location = 1) in vec4 aSignal;
layout(location = 2) in vec2 aTube;
uniform vec2 uFieldSize;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform float uWeave;
uniform float uMids;
uniform float uAnticipation;
out vec2 vSourceUv;
out vec2 vTangent;
out vec4 vSignal;
out float vAcross;
void main() {
  float separation = aTube.x * (0.65 + 0.35 * uMids) * (1.0 - 0.40 * uAnticipation);
  float weave = sin(aSignal.x * 0.29 + uWeave + aSignal.w);
  // Both sides receive the same displacement. The measured strip radius is
  // part of contiguous density/confidence support, never a fixed outer halo.
  vec2 pixel = aPath.xy + aPath.zw * (separation * weave + aSignal.y * aTube.y);
  vec2 uv = pixel / uFieldSize;
  vec2 point = vec2(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
  if (uCanvasAspect > uVideoAspect) point.x *= uVideoAspect / uCanvasAspect;
  else point.y *= uCanvasAspect / uVideoAspect;
  gl_Position = vec4(point, 0.0, 1.0);
  vSourceUv = vec2(uv.x, 1.0 - uv.y);
  vTangent = vec2(aPath.w, -aPath.z);
  vSignal = vec4(aSignal.x, aSignal.z, aSignal.w, aTube.y);
  vAcross = aSignal.y;
}`;

export const forgeBraidFragmentSource = `#version 300 es
precision highp float;
in vec2 vSourceUv;
in vec2 vTangent;
in vec4 vSignal;
in float vAcross;
out vec4 outColor;
uniform sampler2D uVideo;
uniform float uPhase;
uniform float uBass;
uniform float uHighs;
uniform float uEnergy;
uniform float uAnticipation;
uniform float uRelease;
uniform float uReleaseAge;
uniform float uPhrase;
uniform float uBreakdown;
uniform float uKick;
uniform float uPhrase8;
uniform float uPhrase16;
uniform float uPhrase32;
uniform float uMaster;
uniform float uOpacity;
uniform float uOutputWidth;
uniform int uCompare;
${fieldSampling}
void main() {
  if (uCompare == 1 && gl_FragCoord.x < uOutputWidth * 0.5) discard;
  float d = densityAt(vSourceUv);
  vec3 flow = flowAt(vSourceUv);
  // Sample at each actual displaced fragment, rather than accepting a centre
  // and painting its whole strip. This trims antialiased field halos as well.
  if (d < 0.10 || flow.z < 0.24) discard;
  float support = smoothstep(0.10, 0.24, d) * smoothstep(0.24, 0.65, flow.z);
  float direction = dot(flow.xy, vTangent) >= 0.0 ? 1.0 : -1.0;
  float arc = vSignal.x * direction;
  float spacing = mix(54.0, 17.0, uBass) * (1.0 - 0.48 * uAnticipation);
  spacing *= 1.0 + 0.16 * sin(uPhrase16 * 6.2831853);
  float pathSelector = fract(vSignal.z * 0.6180339);
  float inward = smoothstep(0.42, 0.88, uBreakdown) * step(0.45, pathSelector) *
    (1.0 - smoothstep(0.10, 0.50, uRelease));
  float travel = mod(arc - uPhase * mix(1.0, -0.45, inward) + vSignal.z * 4.3, spacing);
  float lengthening = 1.4 + uBass * 3.4 + uRelease * 2.4;
  lengthening *= 0.94 + 0.06 * sin(uPhrase32 * 6.2831853);
  float head = exp(-pow((travel - lengthening) / lengthening, 2.0));
  float tail = exp(-travel / (2.2 + uBass * 7.5 + uRelease * 7.0));
  float stitch = exp(-pow((mod(arc - uPhase * 1.7 + vSignal.z, 9.0) - 1.0) / 0.48, 2.0)) * uHighs;
  // A drop releases a travelling front, staggered between paths. It does not
  // multiply all filaments' brightness at the instant of the musical event.
  float releasePosition = -31.0 + uReleaseAge * 20.0 - pathSelector * 12.0;
  float release = exp(-pow((arc - releasePosition) / 4.8, 2.0)) * uRelease;
  // Eight-beat cadence passes along the strand, while the slower hierarchy
  // changes stroke length. Neither creates a whole-network on-beat flash.
  float cadence = exp(-pow((arc - (uPhrase8 * 70.0 - 35.0) + pathSelector * 8.0) / 4.0, 2.0));
  float core = exp(-vAcross * vAcross * 8.0);
  float feather = exp(-vAcross * vAcross * 4.0) * 0.16;
  float gathered = (0.10 + 0.18 * uAnticipation) * exp(-pow((travel - lengthening) / 1.8, 2.0));
  float activity = (0.025 + (0.22 + 0.85 * uEnergy) * (head * 0.9 + tail * 0.38) + gathered +
    stitch * 0.20 + release * 1.25 + cadence * uBass * 0.22) *
    (1.0 - uBreakdown * 0.50 * (1.0 - uRelease));
  activity *= 1.0 + uKick * head * 0.55;
  vec3 beauty = texture(uVideo, vec2(vSourceUv.x, 1.0 - vSourceUv.y)).rgb;
  float light = max(beauty.r, max(beauty.g, beauty.b));
  vec3 hue = mix(beauty / max(light, 0.10), vec3(1.0), 0.30);
  float alpha = min(0.88, (core + feather) * activity * (1.4 + 1.2 * uEnergy) *
    vSignal.y * support * uMaster * uOpacity);
  outColor = vec4(hue * (0.9 + 0.25 * light), alpha);
}`;

export const forgeParticleVertexSource = `#version 300 es
precision highp float;
layout(location = 0) in vec4 aPacket;
layout(location = 1) in vec2 aDirection;
out vec2 vSourceUv;
out float vLife;
out float vPower;
out vec2 vDirection;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform float uPixelScale;
void main() {
  vec2 point = vec2(aPacket.x * 2.0 - 1.0, 1.0 - aPacket.y * 2.0);
  if (uCanvasAspect > uVideoAspect) point.x *= uVideoAspect / uCanvasAspect;
  else point.y *= uCanvasAspect / uVideoAspect;
  gl_Position = vec4(point, 0.0, 1.0);
  gl_PointSize = (3.0 + aPacket.w * 4.0) * uPixelScale;
  vSourceUv = vec2(aPacket.x, 1.0 - aPacket.y);
  vLife = aPacket.z;
  vPower = aPacket.w;
  vec2 direction = aDirection;
  vDirection = length(direction) > 0.01 ? normalize(direction) : vec2(1.0, 0.0);
}`;

export const forgeParticleFragmentSource = `#version 300 es
precision highp float;
in vec2 vSourceUv;
in float vLife;
in float vPower;
in vec2 vDirection;
out vec4 outColor;
uniform sampler2D uVideo;
uniform sampler2D uExcitation;
uniform float uMaster;
uniform float uOpacity;
uniform float uOutputWidth;
uniform vec2 uOutputSize;
uniform float uCanvasAspect;
uniform float uVideoAspect;
uniform int uCompare;
${fieldSampling}
void main() {
  if (uCompare == 1 && gl_FragCoord.x < uOutputWidth * 0.5) discard;
  vec2 p = gl_PointCoord * 2.0 - 1.0;
  float along = dot(p, vDirection);
  float across = dot(p, vec2(-vDirection.y, vDirection.x));
  float halo = exp(-along * along * 3.0 - across * across * 14.0);
  float core = exp(-along * along * 12.0 - across * across * 29.0);
  // Mask every point-sprite fragment, not just its centre. A supported centre
  // must not allow a wide luminous sprite to spill onto the adjacent terrain.
  vec2 fieldUv = gl_FragCoord.xy / uOutputSize;
  if (uCanvasAspect > uVideoAspect) fieldUv.x = (fieldUv.x - 0.5) * uCanvasAspect / uVideoAspect + 0.5;
  else fieldUv.y = (fieldUv.y - 0.5) * uVideoAspect / uCanvasAspect + 0.5;
  if (any(lessThan(fieldUv, vec2(0.0))) || any(greaterThan(fieldUv, vec2(1.0)))) discard;
  float d = densityAt(fieldUv);
  float support = smoothstep(0.10, 0.23, d) * smoothstep(0.24, 0.48, flowAt(fieldUv).z);
  if (support < 0.01) discard;
  float excited = texture(uExcitation, vSourceUv).r;
  vec3 beauty = texture(uVideo, vec2(vSourceUv.x, 1.0 - vSourceUv.y)).rgb;
  float light = max(beauty.r, max(beauty.g, beauty.b));
  vec3 hue = mix(beauty / max(light, 0.12), vec3(1.0), 0.34);
  float alpha = (halo * 0.58 + core * 0.54) * vLife * (0.48 + 0.55 * vPower + 0.30 * excited) *
    support * uMaster * uOpacity;
  outColor = vec4(hue * (0.72 + light * 0.60), alpha);
}`;
