// Advances a stateful director in output-time steps, independently of wall time,
// playback state, or how many times a preview asks for the same frame.
export function createOfflineAnimationClock({ reset, step }) {
  let time = null, epoch = 0;
  const normalize = (target) => Math.max(0, Number(target) || 0);
  const begin = (target) => { if (time === null || target < time - 1e-7) { reset(); time = 0; } };
  return {
    advance(target, { fps = 30, inputsAt = () => ({}) } = {}) {
      target = normalize(target);
      begin(target);
      const interval = 1 / Math.max(1, fps);
      while (time < target - 1e-7) {
        const next = Math.min(target, time + interval);
        step(next - time, inputsAt(next));
        time = next;
      }
      return time;
    },
    async advanceAsync(target, options = {}) {
      target = normalize(target);
      begin(target);
      const token = epoch;
      // Long source-range seeks replay director state without monopolising the
      // UI thread. Yielding changes scheduling, never the animation timestamps.
      const batch = 120 / Math.max(1, options.fps || 30);
      while (time < target - 1e-7) {
        if (epoch !== token) throw new Error("Offline animation replay cancelled");
        this.advance(Math.min(target, time + batch), options);
        if (time < target - 1e-7) await new Promise((resolve) => setTimeout(resolve, 0));
      }
      return time;
    },
    end() { time = null; epoch++; }
  };
}
