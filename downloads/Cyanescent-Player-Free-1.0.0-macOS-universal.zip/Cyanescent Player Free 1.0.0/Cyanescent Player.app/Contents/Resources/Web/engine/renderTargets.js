function configureColorTexture(gl, width, height) {
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  return texture;
}

export function createRenderTarget(gl, width, height) {
  const tex = configureColorTexture(gl, width, height);
  const fb = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
  if (status !== gl.FRAMEBUFFER_COMPLETE) {
    throw new Error(`Could not create ${width}x${height} render target; WebGL framebuffer status ${status}`);
  }
  return { tex, fb, width, height };
}

export function createRenderTargetWithDepth(gl, width, height) {
  const target = createRenderTarget(gl, width, height);
  const depth = gl.createRenderbuffer();
  gl.bindRenderbuffer(gl.RENDERBUFFER, depth);
  gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, width, height);
  gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depth);
  const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
  if (status !== gl.FRAMEBUFFER_COMPLETE) {
    throw new Error(`Could not create ${width}x${height} depth render target; WebGL framebuffer status ${status}`);
  }
  return { ...target, depth };
}

export function deleteRenderTarget(gl, target) {
  if (!gl || !target) return;
  if (target.tex) gl.deleteTexture(target.tex);
  if (target.depth) gl.deleteRenderbuffer(target.depth);
  if (target.fb) gl.deleteFramebuffer(target.fb);
}

export function clearRenderTarget(gl, target, width, height) {
  if (!gl || !target) return;
  gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
  gl.viewport(0, 0, width, height);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);
}

export function createClearedRenderTargetPair(gl, width, height) {
  const targets = [createRenderTarget(gl, width, height), createRenderTarget(gl, width, height)];
  for (const target of targets) {
    clearRenderTarget(gl, target, width, height);
  }
  return targets;
}

export function ensureSizedRenderTargetWithDepth(gl, target, width, height) {
  if (target && target.width === width && target.height === height) return target;
  const allocationStartedAt = performance.now();
  deleteRenderTarget(gl, target);
  const resizedTarget = {
    ...createRenderTargetWithDepth(gl, width, height),
    width,
    height
  };
  const allocationMs = performance.now() - allocationStartedAt;
  if (allocationMs >= 8) {
    console.warn(`WebGL depth target timing: ${width}x${height} allocation_ms=${allocationMs.toFixed(1)}`);
  }
  return resizedTarget;
}
