// Exact source-frame decoding for variable-speed Forge video presets. The
// derived index describes MP4 sample byte ranges/PTS, never scene geometry.
// Frames are borrowed during onFrame only and always closed immediately.
export async function createForgeVideoDecoder({ url, index, onFrame, onError }) {
  if (typeof VideoDecoder !== 'function') throw new Error('WebCodecs unavailable');
  const config = { codec: index.codec, codedWidth: index.width, codedHeight: index.height,
    description: Uint8Array.from(index.description), hardwareAcceleration: 'prefer-hardware', optimizeForLatency: true };
  const support = await VideoDecoder.isConfigSupported(config);
  if (!support.supported) throw new Error(`Unsupported Forge video codec ${index.codec}`);
  const response = await fetch(url); if (!response.ok) throw new Error(`Forge video: HTTP ${response.status}`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.length !== index.fileBytes) throw new Error('Forge decode index/video size mismatch');
  const duration = (index.durationSeconds ?? index.durationUs / 1e6) * 1e6, samples = index.samples;
  let next = 0, cycle = 0, stopped = false, flushing = false, epoch = 0, cutoff = -Infinity;
  let frames = 0, skipped = 0, resets = 0;
  const decoder = new VideoDecoder({
    output(frame) {
      try {
        if (stopped || frame.timestamp < cutoff) { skipped++; return; }
        frames++; onFrame(frame.timestamp / 1e6, frame);
      } catch (e) { onError(e); } finally { frame.close(); }
    },
    error(e) { if (!stopped) onError(e); }
  });
  decoder.configure(config);
  function pump(time, ahead = .32) {
    if (stopped || flushing || decoder.state !== 'configured') return;
    const target = (time + ahead) * 1e6;
    // Decode in DTS/file order; output timestamps restore display order for
    // H.264 B-frames. A bounded queue avoids monopolising the render thread.
    let submitted = 0;
    while (next < samples.length && decoder.decodeQueueSize < 12 && submitted++ < 18) {
      const s = samples[next], timestamp = Math.round(s[0] + cycle * duration);
      if (timestamp > target + 50000) break; // bounded codec reorder allowance
      decoder.decode(new EncodedVideoChunk({ type: s[4] ? 'key' : 'delta', timestamp,
        duration: s[1], data: bytes.subarray(s[2], s[2] + s[3]) }));
      next++;
    }
    if (next === samples.length) {
      flushing = true; const token = epoch;
      decoder.flush().then(() => {
        if (stopped || token !== epoch) return;
        next = 0; cycle++; flushing = false;
        // Drain the tail before feeding the first keyframe of the next loop.
      }).catch(e => { if (!stopped && token === epoch) { flushing = false; onError(e); } });
    }
  }
  function seek(time) {
    if (stopped) return;
    epoch++; flushing = false; decoder.reset(); decoder.configure(config); resets++;
    cycle = Math.floor(time * 1e6 / duration);
    const local = time * 1e6 - cycle * duration;
    next = 0;
    for (let k = 0; k < samples.length; k++) if (samples[k][4] && samples[k][0] <= local) next = k;
    cutoff = time * 1e6 - 35000;
  }
  function stop() { stopped = true; epoch++; if (decoder.state !== 'closed') decoder.close(); }
  return { pump, seek, stop, stats: () => ({ frames, skipped, resets, queue: decoder.decodeQueueSize, encodedBytes: bytes.length }) };
}
