// Hypergeometry Engine: Dimensional Emergence — GLSL (preset 398).
//
// All 4D work happens in vertex shaders from static buffers: each vertex carries its 4D position
// and the 4D centre of its cell. The shader shrinks the cell towards its centre in 4D (separating
// the cells), rotates by the SO(4) matrix, and projects from the point (0, 0, 0, d) onto w = 0:
// k = d / (d - w). With circumradius 1 and d >= 2 the denominator stays >= 1, so the projection
// has no singularity and needs no clamping. The rotated w (the fourth coordinate) is passed on as
// a depth-in-the-fourth-dimension cue and for the slicing hyperplane w = h.

const PROJECT = `
uniform mat4 uRot;
uniform float uShrink;
uniform float uProjD;
uniform float uPersp;
uniform float uScale;
uniform mat4 uViewProj;
uniform vec3 uCamPos;
vec4 rot4(vec4 v, vec4 c) { return uRot * (c + (v - c) * uShrink); }
vec3 proj3(vec4 r) { return r.xyz * mix(1.0, uProjD / (uProjD - r.w), uPersp) * uScale; }
`;

// Shared colour language: the fourth coordinate runs from violet (far side, w = -1) through
// pearl to cyan (near side, w = +1); a world hue rotates the whole harmony.
const PALETTE = `
uniform vec4 uHue;          // x hue shift, y saturation, z warmth, w unused
vec3 hgPalette(float t) {
  t = fract(t + uHue.x);
  vec3 c = 0.5 + 0.5 * cos(6.28318 * (t + vec3(0.0, 0.33, 0.67)));
  return mix(vec3(dot(c, vec3(0.33))), c, uHue.y);
}
vec3 depthColour(float w) {
  // far side deep violet-magenta, middle pearl, near side cyan; each world tints the harmony
  vec3 farC = vec3(0.50, 0.14, 1.00), midC = vec3(0.78, 0.72, 1.00), nearC = vec3(0.16, 0.86, 1.00);
  vec3 c = w < 0.0 ? mix(midC, farC, smoothstep(0.0, 1.0, -w)) : mix(midC, nearC, smoothstep(0.0, 1.0, w));
  return mix(c, c * (0.6 + 0.8 * hgPalette(w * 0.15 + 0.5)), 0.25);
}
`;

const PULSES = `
uniform highp usampler2D uDist;   // graph distances: row = source vertex
uniform vec4 uPulse[8];           // x source vertex, y front (edges travelled), z strength, w width
uniform int uPulseCount;
float pulseAt(float vertexA, float vertexB, float along) {
  float acc = 0.0;
  for (int i = 0; i < 8; i++) {
    if (i >= uPulseCount) break;
    vec4 p = uPulse[i];
    if (p.z <= 0.0) continue;
    float da = float(texelFetch(uDist, ivec2(int(vertexA + 0.5), int(p.x + 0.5)), 0).r);
    float db = float(texelFetch(uDist, ivec2(int(vertexB + 0.5), int(p.x + 0.5)), 0).r);
    float d = mix(da, db, along);
    float x = (d - p.y) / p.w;          // explicit square: pow() of a negative base is undefined
    acc += p.z * exp(-x * x);
  }
  return acc;
}
`;

// ---- faces: translucent pearl glass, weighted blended order-independent transparency ----------
export const faceVertex = `#version 300 es
precision highp float;
in vec4 aPos;
in vec4 aCell;
in vec4 aMeta;     // x cell index, y border parameter (0 rim, 1 face centre), z face index, w cell tone
${PROJECT}
${PALETTE}
uniform float uCellTint;   // 0 = colour by 4D depth only, 1 = strong per-cell identity
out vec3 vTone;
out vec3 vWorld;
out float vW;
out vec4 vMeta;
out float vClip;
out float vCellHue;
uniform vec2 uClip;   // keep fragments with sign * (w - h) > 0 (sign 0 = no clipping)
void main() {
  vec4 r = rot4(aPos, aCell);
  vec3 p = proj3(r);
  vWorld = p;
  vW = r.w;
  vMeta = aMeta;
  // A cell's identity colour comes from its own (unrotated) 4D direction, so it keeps its hue as
  // it travels through the fourth dimension and neighbouring cells differ.
  vec4 dir = normalize(aCell + vec4(1e-5));
  vCellHue = fract(atan(dir.y, dir.x) / 6.28318 + 0.5 * dir.z + 0.35 * dir.w);
  // Colour is constant across a face: computed here once per vertex, not per fragment.
  vec3 cellC = 0.5 + 0.5 * cos(6.28318 * (vCellHue + uHue.x + vec3(0.0, 0.33, 0.67)));
  cellC = mix(vec3(dot(cellC, vec3(0.33))), cellC, 0.75);
  vTone = mix(depthColour(r.w), cellC * (0.7 + 0.5 * (r.w * 0.5 + 0.5)), uCellTint);
  vClip = uClip.y * (r.w - uClip.x);
  gl_Position = uViewProj * vec4(p, 1.0);
}`;

export const faceFragment = `#version 300 es
precision highp float;
in vec3 vWorld;
in float vW;
in vec4 vMeta;
in float vClip;
in float vCellHue;
in vec3 vTone;
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outReveal;   // 0 = colour by 4D depth only, 1 = strong per-cell identity
uniform vec3 uCamPos;
uniform vec4 uFace;     // x opacity, y fresnel boost, z inset line, w energy
uniform vec4 uLightA;   // xyz direction, w intensity
uniform vec2 uClip;
uniform float uFlash;
uniform float uDetail;   // High quality: a second, finer facet frame
${PALETTE}
void main() {
  if (uClip.y != 0.0 && vClip < 0.0) discard;
  vec3 n = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
  vec3 v = normalize(uCamPos - vWorld);
  if (dot(n, v) < 0.0) n = -n;
  float ndv = clamp(dot(n, v), 0.0, 1.0);
  float fres = pow(1.0 - ndv, 3.0);
  // Thin-film pearl: the tint shifts with the angle and with the fourth coordinate.
  vec3 film = 0.82 + 0.18 * cos(6.28318 * (ndv * 1.1 + vW * 0.3 + vec3(0.0, 0.33, 0.67) + uHue.x));
  vec3 tone = vTone;
  // Darker glass: the volumes read as deep violet-cyan crystal and the light lives in the edges,
  // rims and specular highlights.
  vec3 base = tone * film * 0.32;
  float diff = 0.35 + 0.65 * abs(dot(n, normalize(uLightA.xyz)));
  vec3 h = normalize(normalize(uLightA.xyz) + v);
  float spec = pow(max(abs(dot(n, h)), 0.0), 60.0);
  // Facet frame: a bright rim at the face boundary and a fine inset line, so every projected
  // face reads as a cut crystal facet even where many overlap.
  float b = vMeta.y;
  float fw = fwidth(b) * 1.5 + 1e-4;
  float rim = 1.0 - smoothstep(0.0, fw * 1.6 + 0.02, b);
  float inset = (1.0 - smoothstep(0.0, fw, abs(b - uFace.z))) * 0.6;
  inset += uDetail * (1.0 - smoothstep(0.0, fw, abs(b - uFace.z * 2.4))) * 0.35;
  vec3 col = base * diff * (0.55 + 0.6 * uFace.w) + vec3(1.0, 0.97, 0.92) * spec * 0.8 * uLightA.w;
  col += tone * (rim * 0.3 + inset * 0.35) * (0.5 + 0.6 * uFace.w);
  col += vec3(1.0, 0.85, 0.6) * uFlash * 0.12;
  float alpha = clamp(uFace.x * (0.35 + uFace.y * fres) + rim * 0.1 + inset * 0.08, 0.0, 0.95);
  // A facet sweeping right past the camera (inside the structure) is seen edge-on, where the
  // Fresnel term would turn it into a bright streak: fade facets within a unit of the eye.
  alpha *= smoothstep(0.25, 1.0, length(vWorld - uCamPos));
  // One pass, two targets, both additively blended: weighted colour (McGuire-Bavoil), and
  // -ln(1 - alpha), whose sum gives the revealage prod(1 - alpha) = exp(-sum) exactly.
  float z = gl_FragCoord.z;
  float weight = alpha * clamp(0.03 / (1e-5 + pow(z * 0.9, 12.0)), 1e-2, 3e3);
  outColor = vec4(col * alpha * weight, alpha * weight);
  outReveal = vec4(-log(max(1.0 - alpha, 1e-4)), 0.0, 0.0, 0.0);
}`;

// Composite of the accumulated transparency over the opaque scene (blend SRC_ALPHA, 1 - SRC_ALPHA).
export const oitCompositeFragment = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uAccum;
uniform sampler2D uReveal;
void main() {
  vec4 a = texture(uAccum, vUv);
  float reveal = exp(-texture(uReveal, vUv).r);
  vec3 avg = a.rgb / max(a.a, 1e-5);
  outColor = vec4(avg, 1.0 - reveal);
}`;

// ---- edges: anti-aliased screen-space quads, energy along the real graph ------------------------
export const edgeVertex = `#version 300 es
precision highp float;
in vec4 aA;
in vec4 aB;
in vec4 aCell;
in vec4 aMeta;     // x vertex A, y vertex B, z side (-1, 1), w along (0, 1)
in vec2 aMeta2;    // x 1 / cells sharing this edge, y cell index
${PROJECT}
uniform vec2 uViewport;
uniform float uWidth;        // pixels
uniform float uEnvScale;     // 1 = the polytope itself, > 1 = an environment echo
uniform vec2 uClip;
out float vSide;
out float vAlong;
out float vW;
out float vDepth;
out vec4 vMeta;
out float vMult;
out float vClip;
out float vWidthPx;
void main() {
  vec4 ra = rot4(aA, aCell), rb = rot4(aB, aCell);
  vec3 pa = proj3(ra) * uEnvScale, pb = proj3(rb) * uEnvScale;
  vec4 ca = uViewProj * vec4(pa, 1.0), cb = uViewProj * vec4(pb, 1.0);
  // Clip the segment against the near plane before the perspective divide.
  float nearW = 0.02;
  if (ca.w < nearW && cb.w < nearW) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  if (ca.w < nearW) ca = mix(ca, cb, (nearW - ca.w) / (cb.w - ca.w));
  if (cb.w < nearW) cb = mix(cb, ca, (nearW - cb.w) / (ca.w - cb.w));
  vec2 sa = ca.xy / ca.w * uViewport, sb = cb.xy / cb.w * uViewport;
  vec2 dir = normalize(sb - sa + vec2(1e-5, 0.0));
  vec2 nrm = vec2(-dir.y, dir.x);
  vec4 c = aMeta.w < 0.5 ? ca : cb;
  float depth = c.w;
  float width = uWidth * clamp(3.0 / depth, 0.6, 1.6) + 1.0;
  c.xy += nrm * aMeta.z * width / uViewport * c.w;
  // extend a little past the ends so joints close
  c.xy += dir * (aMeta.w < 0.5 ? -1.0 : 1.0) * width * 0.5 / uViewport * c.w;
  gl_Position = c;
  vSide = aMeta.z;
  vAlong = aMeta.w;
  vW = mix(ra.w, rb.w, aMeta.w);
  vDepth = depth;
  vMeta = aMeta;
  vMult = aMeta2.x;
  vClip = uClip.y * (vW - uClip.x);
  vWidthPx = width;
}`;

export const edgeFragment = `#version 300 es
precision highp float;
in float vSide;
in float vAlong;
in float vW;
in float vDepth;
in vec4 vMeta;
in float vMult;
in float vClip;
in float vWidthPx;
out vec4 outColor;
uniform vec4 uEdge;      // x intensity, y shrink duplicate weight (0 at shrink 1), z fog, w highs
uniform vec2 uClip;
uniform float uFlash;
${PALETTE}
${PULSES}
void main() {
  if (uClip.y != 0.0 && vClip < 0.0) discard;
  // The quad is three times the line width: the line fills the central third with a ~1.5 px
  // anti-aliased edge; a passing pulse blooms across the whole quad as a soft bead of light.
  float sd = abs(vSide) * 3.0;
  float aa = 1.5 / max(vWidthPx / 3.0, 1.0);
  float core = (1.0 - smoothstep(1.0 - aa, 1.0, sd)) * (0.6 + 0.4 * (1.0 - min(sd, 1.0)));
  float halo = exp(-vSide * vSide * 4.0);
  // At shrink 1 the per-cell copies of an edge coincide: weight each by 1 / multiplicity. When the
  // cells separate, the copies together carry 2.2x one edge whatever the multiplicity (the 600-cell
  // shares each edge between 5 cells, the tesseract between 3).
  float dup = mix(vMult, min(1.0, vMult * 2.2), uEdge.y);
  float pulse = pulseAt(vMeta.x, vMeta.y, vAlong);
  vec3 tint = depthColour(vW);
  tint = max(mix(vec3(dot(tint, vec3(0.33))), tint, 1.35), 0.0);
  vec3 col = tint * (0.35 + 0.65 * (vW * 0.5 + 0.5)) * uEdge.x * 0.5 * core;
  // Pulses: saturated amber beads with a soft halo (bright enough to read, not so bright that the
  // tone curve bleaches them to white).
  col += (vec3(1.0, 0.5, 0.1) * 1.6 + depthColour(-vW) * 0.2) * pulse * (core * 1.4 + halo * 0.7);
  // Fade with distance, and fade out edges sweeping right past the camera (inside the structure).
  float fog = exp(-max(vDepth - 2.0, 0.0) * uEdge.z) * smoothstep(0.25, 1.0, vDepth);
  outColor = vec4(col * dup * fog * (1.0 + uFlash * 0.6), 1.0);
}`;

// ---- vertices: small luminous nodes (accents on the hi-hats and pulses) --------------------------
export const nodeVertex = `#version 300 es
precision highp float;
in vec4 aPos;
in vec4 aCell;
in vec4 aMeta;   // x vertex index, y corner x, z corner y, w 1 / multiplicity
${PROJECT}
uniform vec2 uViewport;
uniform float uNodeSize;
uniform vec2 uClip;
out vec2 vCorner;
out float vW;
out float vIndex;
out float vMult;
out float vClip;
void main() {
  vec4 r = rot4(aPos, aCell);
  vec4 c = uViewProj * vec4(proj3(r), 1.0);
  if (c.w < 0.05) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  float size = uNodeSize * clamp(3.0 / c.w, 0.5, 2.5);
  c.xy += aMeta.yz * size / uViewport * c.w;
  gl_Position = c;
  vCorner = aMeta.yz;
  vW = r.w;
  vIndex = aMeta.x;
  vMult = aMeta.w;
  vClip = uClip.y * (r.w - uClip.x);
}`;

export const nodeFragment = `#version 300 es
precision highp float;
in vec2 vCorner;
in float vW;
in float vIndex;
in float vMult;
in float vClip;
out vec4 outColor;
uniform vec4 uNode;   // x intensity, y shrink duplicate weight, z highs sparkle, w time
uniform vec2 uClip;
${PALETTE}
${PULSES}
void main() {
  if (uClip.y != 0.0 && vClip < 0.0) discard;
  float r = length(vCorner);
  float core = exp(-r * r * 7.0);
  float sparkle = uNode.z * step(0.82, fract(sin(vIndex * 12.9898 + floor(uNode.w * 8.0)) * 43758.5453));
  float pulse = pulseAt(vIndex, vIndex, 0.0);
  float dup = mix(vMult, min(1.0, vMult * 2.2), uNode.y);
  vec3 col = depthColour(vW) * uNode.x * 0.4 + vec3(1.0, 0.9, 0.7) * sparkle * 0.8 + vec3(1.0, 0.6, 0.18) * pulse * 2.2;
  outColor = vec4(col * core * dup, 1.0);
}`;

// ---- the cross-section: a genuine 3D polyhedron (slice of the polytope by w = h) ---------------
export const sliceVertex = `#version 300 es
precision highp float;
in vec4 aPos;      // rotated 4D point on the hyperplane (no further rotation)
in vec4 aMeta;     // x cell index, y border parameter
uniform float uProjD;
uniform float uPersp;
uniform float uScale;
uniform mat4 uViewProj;
out vec3 vWorld;
out vec4 vMeta;
void main() {
  vec3 p = aPos.xyz * mix(1.0, uProjD / (uProjD - aPos.w), uPersp) * uScale;
  vWorld = p;
  vMeta = aMeta;
  gl_Position = uViewProj * vec4(p, 1.0);
}`;

export const sliceFragment = `#version 300 es
precision highp float;
in vec3 vWorld;
in vec4 vMeta;
out vec4 outColor;
uniform vec3 uCamPos;
uniform vec4 uSlice;   // x intensity, y h (the hyperplane), z energy, w kick
uniform vec4 uLightA;
${PALETTE}
void main() {
  vec3 n = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
  vec3 v = normalize(uCamPos - vWorld);
  if (dot(n, v) < 0.0) n = -n;
  float ndv = clamp(dot(n, v), 0.0, 1.0);
  float b = vMeta.y;
  float fw = fwidth(b) * 1.5 + 1e-4;
  float rim = 1.0 - smoothstep(0.0, fw * 2.0 + 0.03, b);
  // The dimensional interface: a dark polished solid with a molten-gold core where the light
  // of the fourth dimension shows through, rimmed in the colour of its w position.
  vec3 l = normalize(uLightA.xyz);
  float diff = 0.25 + 0.75 * max(dot(n, l), 0.0);
  float spec = pow(max(dot(n, normalize(l + v)), 0.0), 80.0);
  // Concentric inset frames on every section face: the cut through the fourth dimension reads as
  // a faceted gem of molten light inside a dark polished body.
  float bands = 1.0 - smoothstep(0.0, fw * 1.5, abs(fract(b * 4.0 + 0.5) - 0.5) * 0.25 - 0.0);
  vec3 body = vec3(0.025, 0.018, 0.05) * diff;
  vec3 glow = mix(vec3(0.9, 0.38, 0.08), vec3(1.0, 0.72, 0.32), b) * (0.08 + 0.32 * b * b) * (0.6 + 0.6 * uSlice.z);
  vec3 col = body + glow * (0.35 + 0.65 * ndv) + vec3(1.0, 0.95, 0.85) * spec * 0.7;
  col += vec3(1.0, 0.75, 0.4) * bands * 0.18 * (0.5 + uSlice.w);
  col += depthColour(uSlice.y) * rim * (1.1 + 0.9 * uSlice.w);
  // Match the glass's near-eye protection without turning the solid pass translucent.
  // Stable screen-space coverage fades colour AND depth: discarded fragments must not hide
  // the OIT facets, edges and nodes behind a section sweeping past the camera.
  float coverage = smoothstep(0.25, 1.0, length(vWorld - uCamPos));
  float threshold = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
  if (coverage <= threshold) discard;
  outColor = vec4(col * uSlice.x, 1.0);
}`;

// ---- final grade (the environment is hypergeometryAether.js) ------------------------------------
export const gradeFragment = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uScene;
uniform vec4 uGrade;     // x exposure, y vignette, z saturation, w flash
uniform vec2 uRes;
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
void main() {
  vec3 col = texture(uScene, vUv).rgb * uGrade.x;
  col += vec3(1.0, 0.85, 0.65) * uGrade.w * 0.12;
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = max(mix(vec3(l), col, uGrade.z), 0.0);
  col = clamp((col * (2.51 * col + 0.03)) / (col * (2.43 * col + 0.59) + 0.14), 0.0, 1.0);
  col = pow(col, vec3(1.0 / 2.2));
  vec2 p = (vUv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  col *= 1.0 - uGrade.y * pow(length(p) * 1.1, 2.4);
  col += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
  outColor = vec4(col, 1.0);
}`;
