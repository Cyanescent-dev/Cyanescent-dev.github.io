import { createImageTexture } from "./textures.js";
import { editionAllowsPreset, editionIncludesAsset } from "../generated/editionConfig.js";
export class VisualTextureAssets {
  constructor(gl) {
    this.gl = gl;
    this.omTexture = null;
    this.omTextureReady = 0;
    this.flowerTexture = null;
    this.flowerTextureReady = 0;
    this.astrolabeOuterRingTexture = null;
    this.astrolabeOuterRingTextureReady = 0;
    this.astrolabeInnerRingTexture = null;
    this.astrolabeInnerRingTextureReady = 0;
    this.astrolabeReteTexture = null;
    this.astrolabeReteTextureReady = 0;
    this.astrolabeAlidadeTexture = null;
    this.astrolabeAlidadeTextureReady = 0;
    this.geodeLeftWallTexture = null;
    this.geodeLeftWallTextureReady = 0;
    this.geodeRightWallTexture = null;
    this.geodeRightWallTextureReady = 0;
    this.geodeMidgroundTexture = null;
    this.geodeMidgroundTextureReady = 0;
    this.geodeAgateVeinTexture = null;
    this.geodeAgateVeinTextureReady = 0;
    this.geodeRefractionTexture = null;
    this.geodeRefractionTextureReady = 0;
    this.presetBackgroundTextures = new Map();
    this.presetBackgroundReadyMap = new Map();
    this.presetBackgroundUrls = new Map([
      [61, "assets/mayan_temple_backdrop.png"],
      [150, "assets/penrose_crystal_nebula.png"],
      [80, "assets/cathedral-of-attractors-bg.jpg"],
      [90, "assets/caldera-bg.png"],
      [120, "assets/astrolabe-starfield-bg.png"],
      [130, "assets/geode_bg.png"],
    ].filter(([presetId, path]) => editionAllowsPreset(presetId) && editionIncludesAsset(path)));
    // These images are sampled by their preset shaders as data. They must not
    // be exposed to the display-background compositor.
    this.presetShaderTextureUrls = new Map([
      ...this.presetBackgroundUrls,
      [180, "assets/cymatic_mandala_modes.png"],
      [181, "assets/crystal_resonance_modes.png"],
      [182, "assets/harmonic_bloom_modes.png"]
    ].filter(([presetId, path]) => editionAllowsPreset(presetId) && editionIncludesAsset(path)));
    // Mode sheets are texture inputs for their own shaders, not display
    // backgrounds. Keep this allow-list separate from the asset map so they
    // can never be accidentally sent through the shared background compositor.
    this.presetBackgroundCompositeIds = new Set([80, 83, 90, 120, 130, 150]);
  }
  makeImageTexture(url, options = {}) {
    return createImageTexture(this.gl, url, {
      ...options,
      onLoad: () => {
        if (url.includes("om-symbol.png")) {
          this.omTextureReady = 1.0;
        }
        if (url.includes("flower-of-life.png")) {
          this.flowerTextureReady = 1.0;
        }
        if (url.includes("astrolabe-outer-ring.png")) {
          this.astrolabeOuterRingTextureReady = 1.0;
        }
        if (url.includes("astrolabe-inner-ring.png")) {
          this.astrolabeInnerRingTextureReady = 1.0;
        }
        if (url.includes("astrolabe-rete-overlay.png")) {
          this.astrolabeReteTextureReady = 1.0;
        }
        if (url.includes("astrolabe-alidade-arm.png")) {
          this.astrolabeAlidadeTextureReady = 1.0;
        }
        if (url.includes("geode_left_wall.png")) {
          this.geodeLeftWallTextureReady = 1.0;
        }
        if (url.includes("geode_right_wall.png")) {
          this.geodeRightWallTextureReady = 1.0;
        }
        if (url.includes("geode_midground.png")) {
          this.geodeMidgroundTextureReady = 1.0;
        }
        if (url.includes("geode_agate_vein.png")) {
          this.geodeAgateVeinTextureReady = 1.0;
        }
        if (url.includes("geode_refraction.png")) {
          this.geodeRefractionTextureReady = 1.0;
        }
        for (const [presetId, backgroundUrl] of this.presetBackgroundUrls.entries()) {
          if (url === backgroundUrl) this.presetBackgroundReadyMap.set(presetId, 1.0);
        }
        options.onLoad?.();
      }
    });
  }
  ensureOmTexture() {
    if (!this.omTexture) {
      this.omTexture = this.makeImageTexture("assets/om-symbol.png", { flipY: false });
    }
    return this.omTexture;
  }
  ensureFlowerTexture() {
    if (!editionIncludesAsset("assets/flower-of-life.png")) return null;
    if (!this.flowerTexture) {
      this.flowerTexture = this.makeImageTexture("assets/flower-of-life.png", { flipY: false });
    }
    return this.flowerTexture;
  }
  ensureCoreTextures() {
    if (editionIncludesAsset("assets/om-symbol.png")) this.ensureOmTexture();
    if (editionIncludesAsset("assets/flower-of-life.png")) this.ensureFlowerTexture();
    for (const presetId of this.presetShaderTextureUrls.keys()) {
      this.ensurePresetShaderTexture(presetId);
    }
  }
  omReady() {
    return this.omTextureReady;
  }
  flowerReady() {
    return this.flowerTextureReady;
  }
  ensurePresetTexture(presetId, urls) {
    const id = Math.round(Number(presetId) || 0);
    const url = urls.get(id);
    if (!url) return null;
    if (!this.presetBackgroundTextures.has(id)) {
      this.presetBackgroundReadyMap.set(id, 0.0);
      this.presetBackgroundTextures.set(id, this.makeImageTexture(url, {
        flipY: true,
        wrapS: this.gl.CLAMP_TO_EDGE,
        wrapT: this.gl.CLAMP_TO_EDGE
      }));
    }
    return this.presetBackgroundTextures.get(id);
  }
  ensurePresetBackgroundTexture(presetId) {
    return this.ensurePresetTexture(presetId, this.presetBackgroundUrls);
  }
  ensurePresetShaderTexture(presetId) {
    return this.ensurePresetTexture(presetId, this.presetShaderTextureUrls);
  }
  presetBackgroundReady(presetId) {
    const id = Math.floor(Number(presetId) || 0);
    return this.presetBackgroundUrls.has(id) ? 1.0 : 0.0;
  }
  presetBackgroundCompositeReady(presetId) {
    const id = Math.floor(Number(presetId) || 0);
    return this.presetBackgroundCompositeIds.has(id) ? this.presetBackgroundReady(id) : 0.0;
  }
  presetShaderTextureReady(presetId) {
    const id = Math.floor(Number(presetId) || 0);
    return this.presetShaderTextureUrls.has(id) ? 1.0 : 0.0;
  }
}
export function createVisualTextureAssetProvider({ getGl } = {}) {
  let assets = null;
  return function textureAssets() {
    const gl = getGl?.();
    if (!gl) throw new Error("WebGL is not ready for visual texture assets");
    if (!assets) assets = new VisualTextureAssets(gl);
    return assets;
  };
}
