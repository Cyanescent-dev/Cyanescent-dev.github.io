export const ARTIFICIAL_CONSCIOUSNESS_ID = 394;

// Paths and the few numbers the runtime cross-checks against runtime.json (the self-describing
// manifest written by scripts/compile-artificial-consciousness-runtime.mjs, which is authoritative
// for everything else). tools/test-artificial-consciousness.mjs verifies this descriptor against
// the package.
export const ARTIFICIAL_CONSCIOUSNESS = Object.freeze({
  id: ARTIFICIAL_CONSCIOUSNESS_ID,
  name: "Artificial Consciousness",
  assetRoot: "assets/forge/artificial-consciousness",
  manifest: "runtime.json",
  video: "artificial-consciousness.mp4",
  schema: "cyanescent-artificial-consciousness-runtime",
  packageVersion: 1,
  referenceBPM: 145,
  beatsPerBar: 4,
  videoWidth: 2560,
  videoHeight: 1440,
  videoFps: 30,
  frameCount: 2185,
  durationSeconds: 72.83333333333333,
  nodeCount: 27703,
  edgeCount: 57647,
  seed: 20260908,
  seamlessLoop: true
});
