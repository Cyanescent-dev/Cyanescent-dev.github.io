export class FullShaderCompiler {
  constructor({
    gl,
    vertexSource,
    fragmentSource,
    bindings = [[0, "position"]],
    isBusy,
    isScheduleBusy,
    busyDelay,
    onUnsupported,
    onCompiling,
    onReady,
    onFailed
  }) {
    this.gl = gl;
    this.vertexSource = vertexSource;
    this.fragmentSource = fragmentSource;
    this.bindings = bindings;
    this.isBusy = isBusy;
    this.isScheduleBusy = isScheduleBusy || isBusy;
    this.busyDelay = busyDelay;
    this.onUnsupported = onUnsupported;
    this.onCompiling = onCompiling;
    this.onReady = onReady;
    this.onFailed = onFailed;
    this.extension = null;
    this.compile = null;
    this.timer = 0;
  }

  status() {
    return this.compile?.status || "idle";
  }

  isReady() {
    return this.status() === "ready";
  }

  isTerminal() {
    const status = this.status();
    return status === "ready" || status === "failed" || status === "unsupported";
  }

  canStart() {
    const status = this.status();
    return status !== "compiling" && status !== "failed" && status !== "unsupported" && status !== "ready";
  }

  compileShader(type, source) {
    const shader = this.gl.createShader(type);
    this.gl.shaderSource(shader, source);
    this.gl.compileShader(shader);
    return shader;
  }

  createAsyncProgram() {
    this.extension = this.extension || this.gl.getExtension("KHR_parallel_shader_compile");
    if (!this.extension) return null;
    const program = this.gl.createProgram();
    const vertexShader = this.compileShader(this.gl.VERTEX_SHADER, this.vertexSource);
    const fragmentShader = this.compileShader(this.gl.FRAGMENT_SHADER, this.fragmentSource);
    this.gl.attachShader(program, vertexShader);
    this.gl.attachShader(program, fragmentShader);
    for (const [location, name] of this.bindings) {
      this.gl.bindAttribLocation(program, location, name);
    }
    this.gl.linkProgram(program);
    return {
      program,
      vertexShader,
      fragmentShader,
      extension: this.extension,
      startedAt: performance.now(),
      status: "compiling"
    };
  }

  start() {
    if (!this.canStart()) return;
    if (this.isBusy?.()) {
      this.schedule(this.busyDelay?.() || 6000);
      return;
    }
    window.clearTimeout(this.timer);
    const asyncCompile = this.createAsyncProgram();
    if (!asyncCompile) {
      this.compile = { status: "unsupported" };
      this.onUnsupported?.();
      return;
    }
    this.compile = asyncCompile;
    this.onCompiling?.();
    window.setTimeout(() => this.poll(), 120);
  }

  schedule(delay = 1200) {
    if (!this.canStart()) return;
    window.clearTimeout(this.timer);
    this.timer = window.setTimeout(() => {
      if (this.isScheduleBusy?.()) {
        this.schedule(this.busyDelay?.() || 1500);
        return;
      }
      this.start();
    }, delay);
  }

  poll() {
    if (!this.compile || this.compile.status !== "compiling") return;
    const { program, vertexShader, fragmentShader, extension } = this.compile;
    if (!this.gl.getProgramParameter(program, extension.COMPLETION_STATUS_KHR)) {
      window.setTimeout(() => this.poll(), 140);
      return;
    }
    const linked = this.gl.getProgramParameter(program, this.gl.LINK_STATUS);
    if (!linked) {
      const programError = this.gl.getProgramInfoLog(program) || "Full shader link failed";
      const vertexError = this.gl.getShaderInfoLog(vertexShader) || "";
      const fragmentError = this.gl.getShaderInfoLog(fragmentShader) || "";
      const message = `${programError} ${vertexError} ${fragmentError}`.trim();
      this.compile.status = "failed";
      this.gl.deleteShader(vertexShader);
      this.gl.deleteShader(fragmentShader);
      this.gl.deleteProgram(program);
      this.onFailed?.(message);
      return;
    }
    this.compile.status = "ready";
    this.gl.deleteShader(vertexShader);
    this.gl.deleteShader(fragmentShader);
    this.onReady?.(program);
  }

  markSynchronousReady(program) {
    window.clearTimeout(this.timer);
    this.compile = { status: "ready" };
    this.onReady?.(program);
  }

  waitUntilReady(timeoutMs = 90000, errorText = "") {
    if (this.isReady()) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const started = performance.now();
      const poll = () => {
        if (this.isReady()) {
          resolve();
          return;
        }
        const status = this.status();
        if (status === "failed") {
          const message = typeof errorText === "function" ? errorText() : errorText;
          reject(new Error(message || "Full visual shader failed"));
          return;
        }
        if (status === "unsupported") {
          reject(new Error("Parallel visual shader compile is unavailable"));
          return;
        }
        if (performance.now() - started > timeoutMs) {
          reject(new Error("Visual shader warmup timed out"));
          return;
        }
        window.setTimeout(poll, 120);
      };
      poll();
    });
  }
}

export function fullShaderIsBusy({ renderMode, offlineRenderMode, isPlaying }) {
  return renderMode === offlineRenderMode || Boolean(isPlaying?.());
}

export function fullShaderScheduleIsBusy({ renderMode, offlineRenderMode, isPlaying, lastUserInteractionAt, idleGraceMs }) {
  return fullShaderIsBusy({ renderMode, offlineRenderMode, isPlaying }) ||
    performance.now() - lastUserInteractionAt < idleGraceMs;
}

export function fullShaderBusyDelay(isPlaying) {
  return isPlaying?.() ? 6000 : 1500;
}
