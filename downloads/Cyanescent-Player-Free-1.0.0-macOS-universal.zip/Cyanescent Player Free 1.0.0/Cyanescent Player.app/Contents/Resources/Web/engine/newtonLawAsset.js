export const NEWTONS_LAW_ID = 393;

// Paths and the few numbers the runtime cross-checks against runtime.json (the self-describing
// manifest written by scripts/compile-newton-law-runtime.mjs, which is authoritative for
// everything else). tools/test-newton-law.mjs verifies this descriptor against the package.
export const NEWTONS_LAW = Object.freeze({
  id: NEWTONS_LAW_ID,
  name: "Newtons Law",
  assetRoot: "assets/forge/newtons-law",
  manifest: "runtime.json",
  video: "newtons-law-1080p.mp4",
  schema: "cyanescent-newtons-law-runtime",
  packageVersion: 1,
  referenceBPM: 145,
  videoWidth: 1920,
  videoHeight: 1080,
  videoFps: 30,
  sourceFps: 30,
  durationSeconds: 105.93333333333334,
  fieldWidth: 320,
  fieldHeight: 180,
  fieldRateHz: 15,
  sampleCount: 1590,
  seamlessLoop: false
});
