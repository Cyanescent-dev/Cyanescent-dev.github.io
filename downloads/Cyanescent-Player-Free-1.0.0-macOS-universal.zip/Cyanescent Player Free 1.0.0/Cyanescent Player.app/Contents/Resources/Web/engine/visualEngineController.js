export function createVisualEngineController({
  windowRef = window,
  performanceNow = () => performance.now(),
  isPlaybackStarting = () => false,
  initializeRenderer,
  initializeFallbackRenderer,
  finishBoot,
  revealVisuals,
  startRenderLoop,
  stopRenderLoop,
  requestRenderLoop,
  renderFrame,
  setStatus,
  setDiagnostic,
  setErrorText,
  logError = console.error
} = {}) {
  let ready = false;
  let bootStarted = false;
  let bootInProgress = false;
  let bootAttempts = 0;
  let bootTimer = 0;
  let fallbackActive = false;
  let revealAfterBoot = false;
  let lastUserInteractionAt = performanceNow();

  function isReady() {
    return ready;
  }

  function isBootInProgress() {
    return bootInProgress;
  }

  function isFallbackActive() {
    return fallbackActive;
  }

  function shouldReveal(reveal) {
    return Boolean(reveal || revealAfterBoot);
  }

  function markUserInteraction() {
    lastUserInteractionAt = performanceNow();
  }

  function markReady({ reveal = false, fallback = false, errorText = "" } = {}) {
    ready = true;
    fallbackActive = Boolean(fallback);
    bootStarted = true;
    bootInProgress = false;
    setErrorText?.(errorText);
    finishBoot?.({ reveal: shouldReveal(reveal), fallback: fallbackActive, errorText });
  }

  function resetAfterFailedBoot(errorText) {
    ready = false;
    fallbackActive = false;
    bootStarted = false;
    bootInProgress = false;
    setErrorText?.(errorText);
  }

  function initialize(options = {}) {
    const reveal = shouldReveal(options.reveal);
    const compileFull = options.compileFull !== false;
    if (ready) {
      if (reveal) {
        revealAfterBoot = true;
        revealVisuals?.();
        startRenderLoop?.();
      }
      return;
    }
    if (bootInProgress) {
      if (reveal) revealAfterBoot = true;
      return;
    }
    if (reveal) revealAfterBoot = true;
    bootInProgress = true;
    bootAttempts += 1;
    try {
      initializeRenderer?.({ reveal, compileFull });
      markReady({ reveal });
    } catch (error) {
      const mainShaderError = error?.message || "Visual engine failed to start";
      logError(error);
      try {
        initializeFallbackRenderer?.({ error: mainShaderError });
        markReady({ reveal, fallback: true, errorText: mainShaderError });
        setStatus?.("visual fallback");
        setDiagnostic?.(`Main shader failed: ${mainShaderError}`);
      } catch (fallbackError) {
        const fallbackMessage = fallbackError?.message || mainShaderError;
        resetAfterFailedBoot(fallbackMessage);
        setStatus?.(bootAttempts < 3 ? "visual retry" : "shader error");
        setDiagnostic?.(fallbackMessage);
        logError(fallbackError);
        if (bootAttempts < 3) {
          windowRef.setTimeout(() => initialize({ reveal: revealAfterBoot }), 850);
        }
      }
    }
  }

  function schedule(delay = 650, options = {}) {
    const reveal = Boolean(options.reveal);
    if (reveal) revealAfterBoot = true;
    if (ready) {
      if (reveal || revealAfterBoot) {
        revealVisuals?.();
        startRenderLoop?.();
      }
      return;
    }
    windowRef.clearTimeout(bootTimer);
    const boot = () => {
      const recentInput = performanceNow() - lastUserInteractionAt < 900;
      const earlyPlayback = isPlaybackStarting?.();
      if (!reveal && !options.force && (recentInput || earlyPlayback)) {
        bootTimer = windowRef.setTimeout(boot, recentInput ? 650 : 900);
        return;
      }
      const run = () => initialize({ reveal, compileFull: options.compileFull });
      if (reveal) {
        run();
      } else if ("requestIdleCallback" in windowRef) {
        windowRef.requestIdleCallback((deadline) => {
          if (!options.force && !deadline.didTimeout && deadline.timeRemaining && deadline.timeRemaining() < 10) {
            bootTimer = windowRef.setTimeout(boot, 350);
            return;
          }
          run();
        }, { timeout: options.timeout || 1800 });
      } else {
        run();
      }
    };
    bootTimer = windowRef.setTimeout(boot, delay);
  }

  function activate(delay = 0) {
    schedule(delay, { reveal: true, compileFull: false, timeout: delay > 0 ? 2200 : 900 });
  }

  function prewarm(delay = 2200) {
    if (ready || bootInProgress) return;
    schedule(delay, { reveal: false, compileFull: false, timeout: 4500 });
  }

  function render(now) {
    if (!ready) return;
    try {
      renderFrame?.(now);
    } catch (error) {
      stopRenderLoop?.();
      const message = error?.message || "Render frame failed";
      setErrorText?.(message);
      setStatus?.("render error");
      setDiagnostic?.(`Render failed: ${message}`);
      logError(error);
    }
  }

  return {
    isReady,
    isBootInProgress,
    isFallbackActive,
    initialize,
    schedule,
    activate,
    prewarm,
    render,
    requestRenderLoop,
    startRenderLoop,
    markUserInteraction,
    setReady(value) {
      ready = Boolean(value);
    },
    setFallbackActive(value) {
      fallbackActive = Boolean(value);
    }
  };
}
