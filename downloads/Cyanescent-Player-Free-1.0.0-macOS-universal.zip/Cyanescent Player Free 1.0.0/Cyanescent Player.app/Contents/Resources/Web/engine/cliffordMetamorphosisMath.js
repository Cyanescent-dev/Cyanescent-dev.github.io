// Clifford Phase Space: Metamorphosis — the mathematics, in plain JS (no GL) so the route builder,
// the runtime and the tests share one implementation.
//
//   x' = sin(a y) + c cos(a x)
//   y' = sin(b x) + d cos(b y)
//
// A parameter set p = [a, b, c, d]. The preset travels a closed route through parameter space whose
// every point is chaotic (positive Lyapunov exponent), apart from vanishingly narrow periodic windows
// that the runtime crosses quickly (see ROUTE_SAMPLES / routeLyapunov in the itinerary).

export function cliffordStep(p, x, y) {
  return [Math.sin(p[0] * y) + p[2] * Math.cos(p[0] * x), Math.sin(p[1] * x) + p[3] * Math.cos(p[1] * y)];
}

export function cliffordJacobian(p, x, y) {
  const [a, b, c, d] = p;
  return [-a * c * Math.sin(a * x), a * Math.cos(a * y), b * Math.cos(b * x), -b * d * Math.sin(b * y)];
}

// Largest Lyapunov exponent along one orbit (natural log per iteration).
export function lyapunov(p, iterations = 6000, start = [0.1, 0.1]) {
  let [x, y] = start, vx = 1, vy = 0, sum = 0, counted = 0;
  for (let i = 0; i < iterations; i += 1) {
    const [j11, j12, j21, j22] = cliffordJacobian(p, x, y);
    const wx = j11 * vx + j12 * vy, wy = j21 * vx + j22 * vy;
    const length = Math.hypot(wx, wy) || 1e-300;
    vx = wx / length; vy = wy / length;
    [x, y] = cliffordStep(p, x, y);
    if (i >= 300) { sum += Math.log(length); counted += 1; }
  }
  return sum / Math.max(1, counted);
}

// Robust framing of the attractor: centre and half extents from the 0.5%/99.5% orbit percentiles.
export function attractorFrame(p, iterations = 16000) {
  const xs = new Float64Array(iterations), ys = new Float64Array(iterations);
  let x = 0.1, y = 0.1;
  for (let i = 0; i < 400; i += 1) [x, y] = cliffordStep(p, x, y);
  for (let i = 0; i < iterations; i += 1) { [x, y] = cliffordStep(p, x, y); xs[i] = x; ys[i] = y; }
  xs.sort(); ys.sort();
  const lo = Math.floor(iterations * 0.005), hi = Math.ceil(iterations * 0.995) - 1;
  return { cx: (xs[lo] + xs[hi]) / 2, cy: (ys[lo] + ys[hi]) / 2, ex: (xs[hi] - xs[lo]) / 2, ey: (ys[hi] - ys[lo]) / 2 };
}

// Newton iteration for a fixed point of the map, continued from a guess. Returns null if it fails.
export function fixedPoint(p, guess = [0, 0], steps = 30) {
  let [x, y] = guess;
  for (let k = 0; k < steps; k += 1) {
    const [fx, fy] = cliffordStep(p, x, y);
    const gx = fx - x, gy = fy - y;
    if (Math.abs(gx) + Math.abs(gy) < 1e-12) break;
    const [j11, j12, j21, j22] = cliffordJacobian(p, x, y);
    const m11 = j11 - 1, m22 = j22 - 1, det = m11 * m22 - j12 * j21;
    if (Math.abs(det) < 1e-10) return null;
    x -= (m22 * gx - j12 * gy) / det;
    y -= (-j21 * gx + m11 * gy) / det;
    if (!Number.isFinite(x) || !Number.isFinite(y) || Math.abs(x) > 6 || Math.abs(y) > 6) return null;
  }
  const [fx, fy] = cliffordStep(p, x, y);
  if (Math.hypot(fx - x, fy - y) > 1e-7) return null;
  const [j11, j12, j21, j22] = cliffordJacobian(p, x, y);
  const trace = j11 + j22, det = j11 * j22 - j12 * j21, disc = trace * trace / 4 - det;
  // Largest eigenvalue modulus: the eruption needs at least one expanding direction.
  const expansion = disc >= 0 ? Math.max(Math.abs(trace / 2 + Math.sqrt(disc)), Math.abs(trace / 2 - Math.sqrt(disc))) : Math.sqrt(Math.abs(det));
  return { x, y, expansion };
}

// The repelling fixed point the eruption grows from: continued from `previous` when possible,
// otherwise the most expanding of a grid search. null if the map has no expanding fixed point.
export function eruptionOrigin(p, previous = null) {
  if (previous) {
    const continued = fixedPoint(p, [previous.x, previous.y], 12);
    if (continued && continued.expansion > 1.15 && Math.hypot(continued.x - previous.x, continued.y - previous.y) < 0.25) return continued;
  }
  let best = null;
  for (let gx = -2.4; gx <= 2.4; gx += 0.6) for (let gy = -2.4; gy <= 2.4; gy += 0.6) {
    const found = fixedPoint(p, [gx, gy]);
    if (found && found.expansion > 1.15 && (!best || found.expansion > best.expansion)) best = found;
  }
  return best;
}

// ---- the route: a closed uniform Catmull-Rom loop through control points, resampled by arc length ----

export function loopPoint(ctrl, s) {
  const n = ctrl.length, k = Math.floor(s), t = s - k;
  const at = (i) => ctrl[((i % n) + n) % n];
  const p0 = at(k - 1), p1 = at(k), p2 = at(k + 1), p3 = at(k + 2);
  const t2 = t * t, t3 = t2 * t;
  return p1.map((_, i) => 0.5 * (2 * p1[i] + (-p0[i] + p2[i]) * t + (2 * p0[i] - 5 * p1[i] + 4 * p2[i] - p3[i]) * t2 + (-p0[i] + 3 * p1[i] - 3 * p2[i] + p3[i]) * t3));
}

// Arc-length resampling: `samples` parameter sets equally spaced along the loop, the loop length,
// and the arc-length fraction of every control point (so authored worlds can be located on it).
export function resampleLoop(ctrl, samples, subdivisions = 64) {
  const n = ctrl.length, total = n * subdivisions;
  const fine = [], arc = new Float64Array(total + 1);
  for (let j = 0; j <= total; j += 1) fine.push(loopPoint(ctrl, j / subdivisions));
  for (let j = 1; j <= total; j += 1) {
    const a = fine[j], b = fine[j - 1];
    arc[j] = arc[j - 1] + Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2], a[3] - b[3]);
  }
  const length = arc[total];
  const params = new Float32Array(samples * 4);
  let j = 0;
  for (let k = 0; k < samples; k += 1) {
    const target = length * k / samples;
    while (arc[j + 1] < target) j += 1;
    const t = (target - arc[j]) / Math.max(1e-12, arc[j + 1] - arc[j]);
    for (let i = 0; i < 4; i += 1) params[k * 4 + i] = fine[j][i] + (fine[j + 1][i] - fine[j][i]) * t;
  }
  const controlFractions = ctrl.map((_, c) => arc[c * subdivisions] / length);
  return { params, length, controlFractions };
}

// Linear interpolation into a resampled table at a fractional (wrapping) sample position.
export function routeAt(table, stride, samples, position, out = new Array(stride).fill(0)) {
  const wrapped = ((position % samples) + samples) % samples;
  const k = Math.floor(wrapped), t = wrapped - k, k1 = (k + 1) % samples;
  for (let i = 0; i < stride; i += 1) out[i] = table[k * stride + i] + (table[k1 * stride + i] - table[k * stride + i]) * t;
  return out;
}

// Growth of a tiny disc around the fixed point o: entry k is the largest stretch reached after k
// steps by orbits started on a circle of radius r0 (the linearisation, so independent of r0). The
// orbits run in exact difference form (o = F(o)), so r0 can be far below the precision of o.
export function discGrowthProfile(p, o, iterations, r0 = 1e-30, directions = 16) {
  const [a, b, c, d] = p;
  const profile = new Float64Array(iterations + 1);
  for (let k = 0; k < directions; k += 1) {
    const angle = (k + 0.5) * Math.PI * 2 / directions;
    let dx = r0 * Math.cos(angle), dy = r0 * Math.sin(angle);
    profile[0] = 1;
    for (let i = 1; i <= iterations; i += 1) {
      const hx = a * dx / 2, hy = a * dy / 2, gx = b * dx / 2, gy = b * dy / 2;
      const nx = 2 * Math.cos(a * o.y + hy) * Math.sin(hy) - 2 * c * Math.sin(a * o.x + hx) * Math.sin(hx);
      const ny = 2 * Math.cos(b * o.x + gx) * Math.sin(gx) - 2 * d * Math.sin(b * o.y + gy) * Math.sin(gy);
      dx = nx; dy = ny;
      profile[i] = Math.max(profile[i], Math.hypot(dx, dy) / r0);
    }
  }
  return profile;
}

// Length of the forward image of a disc of radius r after `iterations` steps. While it is small it
// stretches like the linearisation at o; once it reaches the attractor's scale (delta) it is a
// piece of unstable manifold that stretches at the attractor's Lyapunov rate.
export function discImageLength(profile, r, lyapunovRate, delta = 0.05) {
  const n = profile.length - 1;
  for (let k = 0; k <= n; k += 1) {
    if (r * profile[k] > delta) return delta * Math.exp(Math.max(0.05, lyapunovRate) * (n - k)) * (r * profile[k] / delta);
  }
  return r * profile[n];
}

// The disc radius whose image has the given length (bisection in log radius; length is monotone).
export function discRadiusForLength(profile, length, lyapunovRate) {
  let lo = -40, hi = 1;
  for (let i = 0; i < 60; i += 1) {
    const mid = (lo + hi) / 2;
    if (discImageLength(profile, Math.pow(10, mid), lyapunovRate) < length) lo = mid; else hi = mid;
  }
  return Math.pow(10, (lo + hi) / 2);
}
