// Newtons Law: the light rig. Pure JS (no GL) so the choreography is testable.
//
// Where the lights belong changes as the journey morphs from the Mandelbrot set through the hybrid
// laws to Newton's method, so it is not assumed: the compiler finds the landmarks of every sample
// in the export (see findLandmarks: the set's cardioid and bulbs, the centres of ringed craters,
// the basins' eyes) and the rig hangs a spot light over the three most salient ones. The lights
// relight the video with the renderer's own surface normals and depth (the shaders), so every mark
// is light falling on the terrain.
//
//   spots (3)   one per landmark, sized to it (the pool covers the crater or the bulb), coloured
//               by its basin's root in the Newton phase; re-ranked on every downbeat and gliding
//               to a new landmark over about a beat when the scene changes
//   sweep (1)   a low raking light that circles once every two bars and pulses on every beat,
//               lighting every slope that faces it: no part of the landscape is dead. It becomes
//               the white sun, straight overhead, when a drop lands.
//
// The music moves the light, never the geometry:
//   beat + groove   the bar rotates an accent through the three spots (beat 1 lights all three);
//                   the sweep pulses on every beat
//   bass, sub       pools widen; the sub breathes the spots' height once a bar
//   build-up        spots come down, narrow and strobe on the roll; the sweep speeds up
//   breakdown       spots rise, widen, cool and soften; tides swell them once a bar
//   drop            a short white hit from the sun, then the spots burst open in colour
// The music model itself is Newton Basin Descent's (newtonBasinAudio.js).

const clamp = (value, low, high) => Math.min(high, Math.max(low, value));
const clamp01 = (value) => clamp(Number.isFinite(value) ? value : 0, 0, 1);

export const LIGHT_COUNT = 4;   // three landmark spots and the sweep / sun
export const SWEEP = 3;
export const ROOT_COLORS = Object.freeze([
  Object.freeze([1.00, 0.70, 0.34]),   // root 0 (z = 1): warm gold
  Object.freeze([0.28, 0.92, 0.86]),   // root 1: turquoise
  Object.freeze([0.70, 0.46, 1.00])    // root 2: violet
]);
export const SUN_COLOR = Object.freeze([1.00, 0.95, 0.86]);
export const ROOT_ANGLES = Object.freeze([0, 2 * Math.PI / 3, -2 * Math.PI / 3]);

export const RIG_TIMING = Object.freeze({
  accent: 0.24,      // seconds: decay of a beat accent
  pulse: 0.16,       // decay of the sweep's beat pulse
  strobe: 0.07,      // roll-wave strobe
  swell: 1.2,        // breakdown tide swell
  burst: 1.0,        // drop burst (the coloured part)
  flash: 0.18,       // drop flash (the white hit)
  glide: 0.30,       // a spot gliding to a new landmark
  follow: 0.08       // a spot following its moving landmark
});

export const LANDMARK_RULES = Object.freeze({
  minSalience: 0.0006,   // on-screen area (fraction of height squared): ~2.5% of the frame height in radius
  keepBonus: 1.35,       // a landmark already lit ranks this much higher (no flicker between equals)
  replaceRatio: 1.6,     // a lit landmark is only replaced at a downbeat by one this much more salient
  lostSeconds: 0.25      // a spot whose landmark has left the data goes dark (or moves on at once)
});

// Which spots a beat accents: the downbeat all three, beats 2, 3, 4 one spot each.
export function accentGains(beatInBar) {
  if (beatInBar >= 1 && beatInBar <= 3) {
    const gains = [0.2, 0.2, 0.2];
    gains[beatInBar - 1] = 1;
    return gains;
  }
  return [1, 1, 1];
}

// Inverse Forge plane mapping: complex-plane point p -> world (x, z).
export function planeToWorld(p, plane) {
  const dx = (p[0] - plane.cx) / plane.scale, dy = (p[1] - plane.cy) / plane.scale;
  const c = Math.cos(-plane.rotation), s = Math.sin(-plane.rotation);
  return [dx * c - dy * s, dx * s + dy * c];
}

// Choose up to three landmarks: most salient first, the ones already lit favoured, never two that
// overlap. `current` holds the ids that are lit now.
export function chooseLandmarks(landmarks, current = [], rules = LANDMARK_RULES) {
  const ranked = landmarks
    .filter((landmark) => landmark.salience >= rules.minSalience)
    .map((landmark) => ({ landmark, score: landmark.salience * (current.includes(landmark.id) ? rules.keepBonus : 1) }))
    .sort((a, b) => b.score - a.score);
  const chosen = [];
  for (const { landmark } of ranked) {
    const overlaps = chosen.some((other) => Math.hypot(other.position[0] - landmark.position[0], other.position[2] - landmark.position[2]) < 0.5 * (other.radius + landmark.radius));
    if (overlaps) continue;
    chosen.push(landmark);
    if (chosen.length === 3) break;
  }
  return chosen;
}

const approach = (value, target, dt, tau) => value + (target - value) * (1 - Math.exp(-dt / Math.max(1e-3, tau)));

export function createLightRig() {
  const state = {
    accents: [0, 0, 0], pulse: 0, strobe: 0, swell: 0, burst: 0, flash: 0,
    dim: 0, glitter: 0, filamentGlow: 0, flow: 0, presence: 0, sweepAzimuth: 0, sweepExtra: 0, lastBar: null, lastBeat: null
  };
  const slots = Array.from({ length: 3 }, (_, k) => ({ id: 0, kind: -1, region: 1, target: null, position: null, radius: 0.4, lostFor: 0, fade: 0, colour: [...ROOT_COLORS[k]], gliding: false }));
  const lights = Array.from({ length: LIGHT_COUNT }, () => ({ position: [0, 0, 0], color: [0, 0, 0], intensity: 0, reach: 1.3, spec: 0, aim: [0, -1, 0], cone: 0.8, directional: false }));

  function reset() {
    Object.assign(state, { accents: [0, 0, 0], pulse: 0, strobe: 0, swell: 0, burst: 0, flash: 0, dim: 0, glitter: 0, filamentGlow: 0, flow: 0, presence: 0, sweepAzimuth: 0, sweepExtra: 0, lastBar: null, lastBeat: null });
    slots.forEach((slot, k) => Object.assign(slot, { id: 0, kind: -1, region: 1, target: null, position: null, radius: 0.4, lostFor: 0, fade: 0, colour: [...ROOT_COLORS[k]], gliding: false }));
    for (const light of lights) { light.intensity = 0; light.color = [0, 0, 0]; }
  }

  // The fallback when the package has no landmarks: the cube roots of unity.
  function rootTargets(plane, relief) {
    return ROOT_ANGLES.map((angle, k) => {
      const [x, z] = planeToWorld([Math.cos(angle), Math.sin(angle)], plane);
      return { id: 60000 + k, kind: -1, region: 1, position: [x, relief * 0.6, z], radius: 0.5, salience: 1 };
    });
  }

  function assign(landmarks, downbeat, dt) {
    const byId = new Map(landmarks.map((landmark) => [landmark.id, landmark]));
    for (const slot of slots) {
      const landmark = byId.get(slot.id);
      if (landmark) { slot.target = landmark.position; slot.radius = approach(slot.radius, landmark.radius, dt, 0.4); slot.lostFor = 0; }
      else slot.lostFor += dt;
    }
    const empty = slots.some((slot) => !slot.id);
    const lost = slots.some((slot) => slot.id && slot.lostFor > LANDMARK_RULES.lostSeconds);
    if (!empty && !downbeat && !lost) return;
    const current = slots.map((slot) => slot.id).filter(Boolean);
    const chosen = chooseLandmarks(landmarks, current);
    const chosenIds = new Set(chosen.map((landmark) => landmark.id));
    // Keep a slot on its landmark if it is still chosen; otherwise hand it a new one.
    const free = chosen.filter((landmark) => !slots.some((slot) => slot.id === landmark.id));
    for (const slot of slots) {
      const stillChosen = slot.id && chosenIds.has(slot.id);
      if (stillChosen) continue;
      const lit = byId.get(slot.id);
      const replaceable = !slot.id || slot.lostFor > LANDMARK_RULES.lostSeconds
        || (downbeat && (!lit || (free[0] && free[0].salience > lit.salience * LANDMARK_RULES.replaceRatio)));
      if (!replaceable || !free.length) continue;
      const next = free.shift();
      // A lit spot glides to its new landmark over about a beat; a dark one simply appears there.
      const glide = Boolean(slot.position) && slot.fade > 0.3;
      Object.assign(slot, { id: next.id, kind: next.kind, region: next.region, target: next.position, lostFor: 0, gliding: glide });
      if (!glide) { slot.position = [...next.position]; slot.radius = next.radius; }
    }
  }

  // events / music: from createNewtonAudioModel().step() and its state. scene: { plane, reliefHeight,
  // landmarks (interpolated, world units) }.
  function step(dt, events, music, scene, { reactive = 1 } = {}) {
    dt = clamp(dt, 0, 0.1);
    const r = clamp(reactive, 0, 1.5);
    for (const wave of events?.waves || []) {
      if (wave.kind === "kick") {
        const gains = accentGains(wave.beatInBar ?? -1);
        for (let k = 0; k < 3; k += 1) state.accents[k] = Math.max(state.accents[k], gains[k] * clamp(wave.strength, 0, 1.5));
        state.pulse = Math.max(state.pulse, clamp(wave.strength, 0, 1.5));
      } else if (wave.kind === "roll") state.strobe = Math.max(state.strobe, clamp(wave.strength, 0, 1));
      else if (wave.kind === "tide") state.swell = Math.max(state.swell, clamp(wave.strength, 0, 1));
      else if (wave.kind === "drop") { state.burst = 1; state.flash = 1; }
    }
    for (let k = 0; k < 3; k += 1) state.accents[k] *= Math.exp(-dt / RIG_TIMING.accent);
    state.pulse *= Math.exp(-dt / RIG_TIMING.pulse);
    state.strobe *= Math.exp(-dt / RIG_TIMING.strobe);
    state.swell *= Math.exp(-dt / RIG_TIMING.swell);
    state.burst *= Math.exp(-dt / RIG_TIMING.burst);
    state.flash *= Math.exp(-dt / RIG_TIMING.flash);

    const energy = clamp01(music.energyDrive), bass = clamp01(music.bassDrive), sub = clamp01(music.subDrive);
    const build = clamp01(music.build), calm = clamp01(music.breakdown), pads = clamp01(music.midDrive);
    // How much music there is at all: silence leaves the Forge frame exactly as rendered. A
    // breakdown with pads keeps soft lights on; only real silence turns them off.
    const activity = clamp01(energy * 4 + pads * 2);
    state.presence = clamp01(Math.max(energy * 1.4, clamp01(music.groove) * 0.8, state.swell * activity, calm * (0.25 + 0.75 * pads) * clamp01(energy * 4)));

    // Landmarks: re-ranked on each downbeat (bar start), or at once when a slot is empty or lost.
    const beat = Number(music.beat) || 0;
    const bar = Math.floor(beat / 4);
    const downbeat = state.lastBar !== null && bar !== state.lastBar;
    state.lastBar = bar;
    const relief = Number.isFinite(scene?.reliefHeight) ? scene.reliefHeight : 0.5;
    const plane = scene?.plane || { cx: -0.6, cy: 0, scale: 0.81, rotation: 0 };
    // With landmark data, an empty list means the frame has nothing to light (the spots go dark and
    // the sweep carries the beat); only a package without landmarks falls back to the cube roots.
    const landmarks = Array.isArray(scene?.landmarks) ? scene.landmarks : rootTargets(plane, relief);
    assign(landmarks, downbeat, dt);

    const breath = Math.sin(2 * Math.PI * (Number(music.breathPhase) || 0));
    const base = ((0.45 + 0.55 * energy) * (1 - calm) + (0.40 + 0.35 * pads) * calm) * state.presence;
    const cool = 0.45 * calm, white = 0.6 * state.flash;
    slots.forEach((slot, k) => {
      const light = lights[k];
      if (!slot.position || !slot.target) { light.intensity = 0; return; }
      if (slot.lostFor > LANDMARK_RULES.lostSeconds && slot.fade < 0.02) { slot.id = 0; slot.target = null; slot.position = null; light.intensity = 0; return; }
      const tau = slot.gliding ? RIG_TIMING.glide : RIG_TIMING.follow;
      for (let c = 0; c < 3; c += 1) slot.position[c] = approach(slot.position[c], slot.target[c], dt, tau);
      if (slot.gliding && Math.hypot(slot.position[0] - slot.target[0], slot.position[2] - slot.target[2]) < 0.03) slot.gliding = false;
      // A spot whose landmark has gone (morphed away, left the frame) fades out: a light never
      // hangs over a place where the video no longer shows anything.
      slot.fade = approach(slot.fade, slot.lostFor > LANDMARK_RULES.lostSeconds ? 0 : 1, dt, 0.2);
      // The spot hangs over its landmark at a height that lets its pool cover it.
      const radius = clamp(slot.radius, 0.15, 1.4);
      const height = clamp(0.25 + 1.0 * radius, 0.35, 1.5) * (1 + 0.35 * calm - 0.25 * build) + 0.05 * breath * sub;
      light.position[0] = slot.position[0];
      light.position[1] = Math.max(slot.position[1], relief * 0.5) + height;
      light.position[2] = slot.position[2];
      // The pool covers the landmark: wider washes in a breakdown, tighter beams in a build.
      const pool = 0.85 * radius * (1 + 0.6 * calm - 0.2 * build);
      const coneDegrees = Math.atan2(pool, height) * 180 / Math.PI + 6 * state.accents[k] + 12 * state.burst;
      light.cone = Math.cos(clamp(coneDegrees, 14, 58) * Math.PI / 180);
      light.aim = [0, -1, 0];
      light.reach = 1.2 + height;
      light.intensity = r * slot.fade * (base * (0.8 + 0.2 * breath * sub) + 1.3 * state.accents[k] + 0.65 * state.strobe + 0.55 * state.swell * activity + 0.8 * state.burst);
      // Colour: in a Newton basin the root's own colour; elsewhere the spot's colour.
      const own = slot.region >= 2 && slot.region <= 4 ? ROOT_COLORS[slot.region - 2] : ROOT_COLORS[k];
      for (let c = 0; c < 3; c += 1) {
        slot.colour[c] = approach(slot.colour[c], own[c], dt, 0.5);
        const moon = [0.62, 0.72, 1.0][c];
        light.color[c] = (slot.colour[c] * (1 - cool) + moon * cool) * (1 - white) + white;
      }
      light.spec = 0.5 + 0.8 * clamp01(music.highDrive) + 1.2 * clamp01(music.hat);
      light.directional = false;
    });

    // The sweep: a low raking light that circles the scene once every two bars (tempo-locked) and
    // pulses on every beat; the drop turns it into the sun straight overhead.
    // Locked to the beat grid; a build adds speed on top (integrated, so the phase never jumps).
    const bps = clamp(Number(music.beatsPerSecond) || 145 / 60, 1, 4);
    state.sweepExtra = (state.sweepExtra + dt * 2 * Math.PI * build * bps / 8) % (2 * Math.PI);
    state.sweepAzimuth = 2 * Math.PI * ((beat / 8) % 1) + state.sweepExtra;
    const elevation = (16 + 10 * calm) * Math.PI / 180;
    const sweep = lights[SWEEP];
    const overhead = clamp01(state.flash * 1.5);
    const dir = [Math.cos(state.sweepAzimuth) * Math.cos(elevation), Math.sin(elevation), Math.sin(state.sweepAzimuth) * Math.cos(elevation)];
    const d = [dir[0] * (1 - overhead), dir[1] * (1 - overhead) + overhead, dir[2] * (1 - overhead)];
    const length = Math.hypot(d[0], d[1], d[2]) || 1;
    sweep.position = d.map((v) => v / length);   // for a directional light: the direction towards it
    sweep.directional = true;
    const accentColour = [0, 1, 2].map((c) => (state.accents[0] * ROOT_COLORS[0][c] + state.accents[1] * ROOT_COLORS[1][c] + state.accents[2] * ROOT_COLORS[2][c]) / Math.max(1e-3, state.accents[0] + state.accents[1] + state.accents[2]));
    const tint = clamp01(state.pulse);
    for (let c = 0; c < 3; c += 1) {
      const warm = [1.0, 0.9, 0.78][c];
      const coloured = warm * (1 - 0.5 * tint) + accentColour[c] * 0.5 * tint;
      sweep.color[c] = (coloured * (1 - cool) + [0.62, 0.72, 1.0][c] * cool) * (1 - overhead) + SUN_COLOR[c] * overhead;
    }
    sweep.intensity = r * (state.presence * (0.04 + 0.06 * energy) * (1 - 0.5 * calm) + 0.38 * state.pulse * (1 - calm) + 0.2 * state.strobe + 0.55 * state.flash + 0.15 * state.burst);
    sweep.spec = 0.8 + 1.2 * clamp01(music.hat);
    sweep.reach = 0;
    sweep.cone = -1;

    state.dim = Math.min(0.4, r * state.presence * (0.2 + 0.18 * energy + 0.06 * calm));
    state.glitter = r * (0.25 * clamp01(music.highDrive) + 0.9 * clamp01(music.hat));
    state.filamentGlow = r * state.presence * (0.18 + 0.55 * pads * (0.4 + 0.6 * calm) + 0.35 * clamp01(music.surge) + 0.6 * state.burst + 0.5 * clamp01(music.hat));
    // Filament flow: bands of light running along the render's own orbit-depth bands, one band
    // per beat.
    state.flow = beat * 0.5;
    return lights;
  }

  // Uniform layout: A = position.xyz (or the direction towards a directional light), reach (0 for
  // directional); B = colour * intensity, specular strength; C = spot aim (unit), cos(cone) (-1 = all).
  function writeUniforms(A, B, C) {
    lights.forEach((light, i) => {
      A[i * 4] = light.position[0]; A[i * 4 + 1] = light.position[1]; A[i * 4 + 2] = light.position[2]; A[i * 4 + 3] = light.directional ? 0 : light.reach;
      for (let c = 0; c < 3; c += 1) B[i * 4 + c] = light.color[c] * light.intensity;
      B[i * 4 + 3] = light.spec;
      if (C) { C[i * 4] = light.aim[0]; C[i * 4 + 1] = light.aim[1]; C[i * 4 + 2] = light.aim[2]; C[i * 4 + 3] = light.cone; }
    });
  }

  return { state, slots, lights, step, reset, writeUniforms };
}
