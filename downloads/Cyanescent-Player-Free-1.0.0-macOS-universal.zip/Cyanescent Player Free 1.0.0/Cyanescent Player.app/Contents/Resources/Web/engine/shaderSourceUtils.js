export function shaderBlockBetween(source, startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start);
  if (start < 0 || end < 0 || end <= start) {
    throw new Error(`Shader block not found: ${startMarker}`);
  }
  return source.slice(start, end);
}

export function removePreprocessorBlock(source, startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  if (start < 0) return source;
  const end = source.indexOf(endMarker, start);
  if (end < 0) return source;
  return `${source.slice(0, start)}${source.slice(end + endMarker.length)}`;
}

export function removeShaderBlockBetween(source, startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start);
  if (start < 0 || end < 0 || end <= start) return source;
  return `${source.slice(0, start)}${source.slice(end)}`;
}

export function removeBalancedShaderBlock(source, marker) {
  const start = source.indexOf(marker);
  if (start < 0) return source;
  const openBrace = source.indexOf("{", start);
  if (openBrace < 0) return source;
  let depth = 0;
  for (let i = openBrace; i < source.length; i += 1) {
    if (source[i] === "{") depth += 1;
    if (source[i] === "}") {
      depth -= 1;
      if (depth === 0) {
        return `${source.slice(0, start)}${source.slice(i + 1)}`;
      }
    }
  }
  return source;
}

export function removeAllBalancedShaderBlocks(source, marker) {
  let output = source;
  for (let i = 0; i < 8; i += 1) {
    const next = removeBalancedShaderBlock(output, marker);
    if (next === output) return output;
    output = next;
  }
  return output;
}
