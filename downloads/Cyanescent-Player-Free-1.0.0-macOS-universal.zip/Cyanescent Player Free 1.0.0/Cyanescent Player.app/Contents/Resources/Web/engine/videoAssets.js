import { capabilityEnabled } from "../config/runtimeCapabilities.js";
export const DEFAULT_CYANESCENT_TRANSITION_MANIFEST = "assets/bg/cyanescent_transitions/manifest.json";
export const DEFAULT_CUSTOM_TRANSITION_MANIFEST = "assets/bg/transitions/manifest.json";

function resolveAssetPath(basePath, file) {
  if (!file) return "";
  if (/^(blob:|data:|https?:|file:)/i.test(file)) return file;
  return `${basePath.replace(/\/+$/, "")}/${file}`;
}

function normalizeTransitionEntry(entry, basePath) {
  if (!entry?.id || !entry?.file) return null;
  return {
    ...entry,
    resolvedPath: resolveAssetPath(basePath, entry.file)
  };
}

async function fetchJson(url) {
  const response = await fetch(url, { cache: "no-cache" });
  if (!response.ok) throw new Error(`${url} returned ${response.status}`);
  return response.json();
}

export function createVideoAssetManager({
  cyanescentManifest = DEFAULT_CYANESCENT_TRANSITION_MANIFEST,
  customManifest = DEFAULT_CUSTOM_TRANSITION_MANIFEST,
  cyanescentBasePath = "assets/bg/cyanescent_transitions",
  customBasePath = "assets/bg/transitions",
  logger = console
} = {}) {
  let cyanescentTransitions = [];
  let customTransitions = [];
  let manifestLoadPromise = null;
  const videoObjectUrls = new Map();

  async function loadManifest(url, basePath) {
    const data = await fetchJson(url);
    if (!Array.isArray(data)) return [];
    return data
      .map((entry) => normalizeTransitionEntry(entry, basePath))
      .filter(Boolean);
  }

  async function loadTransitionManifests() {
    if (!capabilityEnabled("videoTransitions")) return { cyanescentTransitions: [], customTransitions: [] };
    if (manifestLoadPromise) return manifestLoadPromise;
    manifestLoadPromise = Promise.allSettled([
      loadManifest(cyanescentManifest, cyanescentBasePath),
      loadManifest(customManifest, customBasePath)
    ]).then(([cyanescent, custom]) => {
      if (cyanescent.status === "fulfilled") {
        cyanescentTransitions = cyanescent.value;
      } else {
        logger.warn?.("Could not load Cyanescent transition manifest:", cyanescent.reason);
      }
      if (custom.status === "fulfilled") {
        customTransitions = custom.value;
      } else {
        logger.warn?.("Could not load custom transition manifest:", custom.reason);
      }
      return {
        cyanescentTransitions,
        customTransitions
      };
    });
    return manifestLoadPromise;
  }

  function transitionsForMode(mode = "auto", selectedIds = []) {
    if (!capabilityEnabled("videoTransitions")) return [];
    if (mode === "manual") {
      const enabled = new Set(Array.isArray(selectedIds) ? selectedIds : []);
      const manual = customTransitions.filter((entry) => enabled.has(entry.id));
      if (manual.length) return manual;
    }
    if (mode === "custom") {
      return customTransitions.length ? customTransitions : cyanescentTransitions;
    }
    return cyanescentTransitions.length ? cyanescentTransitions : customTransitions;
  }

  function selectTransitionVideo({
    mode = "auto",
    energyType = "high-high",
    selectedTransitionIds = [],
    candidateIds = [],
    recentTransitionIds = [],
    random = Math.random
  } = {}) {
    const all = transitionsForMode(mode, selectedTransitionIds);
    if (!all.length) return null;

    const candidateSet = new Set(Array.isArray(candidateIds) ? candidateIds.map(String) : []);
    let candidates = candidateSet.size
      ? all.filter((entry) => candidateSet.has(String(entry.id)))
      : all;
    const energyMatches = candidates.filter((entry) => Array.isArray(entry.energy) && entry.energy.includes(energyType));
    if (energyMatches.length) candidates = energyMatches;

    // Older callers still get the previous short-history behaviour. The live
    // and offline transition paths pass candidateIds from the full cycle.
    if (!candidateSet.size) {
      const recent = new Set(Array.isArray(recentTransitionIds) ? recentTransitionIds : []);
      const lessRecent = candidates.filter((entry) => !recent.has(entry.id));
      if (lessRecent.length) candidates = lessRecent;
    }

    const totalWeight = candidates.reduce((sum, entry) => sum + Math.max(0.01, Number(entry.weight) || Number(entry.intensity) || 1), 0);
    let pick = random() * totalWeight;
    for (const entry of candidates) {
      pick -= Math.max(0.01, Number(entry.weight) || Number(entry.intensity) || 1);
      if (pick <= 0) return entry;
    }
    return candidates[candidates.length - 1] || null;
  }

  function transitionById(id) {
    if (!capabilityEnabled("videoTransitions")) return null;
    const key = String(id || "");
    if (!key) return null;
    return [...cyanescentTransitions, ...customTransitions].find((entry) => entry.id === key) || null;
  }

  async function objectUrlForVideo(path) {
    if (!path) return "";
    if (videoObjectUrls.has(path)) return videoObjectUrls.get(path);
    const response = await fetch(path);
    if (!response.ok) throw new Error(`${path} returned ${response.status}`);
    const url = URL.createObjectURL(await response.blob());
    videoObjectUrls.set(path, url);
    return url;
  }

  function releaseObjectUrls() {
    for (const url of videoObjectUrls.values()) URL.revokeObjectURL(url);
    videoObjectUrls.clear();
  }

  return {
    loadTransitionManifests,
    cyanescentTransitions: () => cyanescentTransitions,
    customTransitions: () => customTransitions,
    transitionsForMode,
    selectTransitionVideo,
    transitionById,
    objectUrlForVideo,
    releaseObjectUrls
  };
}
