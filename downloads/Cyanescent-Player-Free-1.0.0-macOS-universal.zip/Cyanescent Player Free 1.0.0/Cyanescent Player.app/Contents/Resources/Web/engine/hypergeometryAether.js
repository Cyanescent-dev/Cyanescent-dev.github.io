// Hypergeometry Engine: Dimensional Emergence — "Dimensional Aether", the procedural environment
// of preset 398 (replaces the original preset's filament image, which preset 11 keeps).
//
// The environment is a handful of quadric HYPERSURFACES of four-dimensional space,
//     Q(Y) = Y^T D Y + g . Y + c = 0,     Y = M (Renv X) - C,     X = (p / L, w0),
// seen through our 3-space: a world point p is lifted to 4D at the slice height w0, rotated by the
// environment's SO(4) orientation Renv and by the membrane's own fixed frame M. Restricted to the
// slice, every hypersurface is an ordinary 3D quadric (saddle, hyperboloid, ellipsoid), so a view
// ray meets it in closed form: Q(eye + t d) is a quadratic in t. Rotations through W and changes of
// w0 change the coefficients, so the slices change shape and even topology (a hyperboloid of one
// sheet pinches through a cone into two sheets; a shell appears from nothing and grows), which is
// exactly what the sliced polytope does in the foreground.
//
//   membranes      thin translucent sheets: emission cos / (cos^2 + k^2) of the view angle (light
//                  through a thin sheet, brightest towards its folds, continuous at the silhouette)
//   strata         contour lines of the membrane's hidden fourth coordinate Yw across the sheet
//   interference   on membrane i, the other membranes' signed distances d_j = Q_j / |grad Q_j| act
//                  as wave sources: fringes Re(sum_j a_j exp(i(2 pi d_j / lambda + phi_j)))^2 run
//                  parallel to the exact intersection curves and beat where two sources overlap;
//                  the curves themselves are fine filaments, their crossings amber points
//   4D link        Renv integrates the SAME generators as the polytope's rotation (W-plane axis and
//                  3D axis, bass, mids, energy, tension), at a fraction of the rate; w0 follows the
//                  foreground's slicing hyperplane in breakdowns; the drop's sweeping hyperplane
//                  crosses the membranes as a travelling line of light while Renv turns a quarter
//                  of the way through the W plane (the reorganisation of the field)
//   music          energy reveals membranes one by one, kicks send a wave of light outwards along
//                  the intersections, highs sharpen them, bass bends the sheets
// Cost: one full-screen pass, no textures, no marching (a few hundred FLOPs per pixel).
import { quat, rotationMatrix } from "./hypergeometryMath.js";

export const AETHER_MAX = 6;

// Membrane definitions in their own 4D frame (units of L world units). The camera sits near the
// origin of X; every membrane keeps at least ~0.4 L from it so none sweeps through the foreground.
// hue: 0 violet .. 1 turquoise; reveal: environment energy at which it appears; hq: High only.
// Every form has an indefinite signature, so no slice can close into a floating blob: the slices
// are saddles, hyperboloids of one or two sheets and the cones between them.
const MEMBRANES = Object.freeze([
  // a vast saddle that arches over the whole scene
  { D: [0.55, -0.55, 0, 0], g: [0, 0, -1.0, 0.45], c: 0.55, C: [0, 0, 0, 0], q: [0.2, -0.4, 0.1, 0.88], r: [0.05, 0.3, -0.2, 0.93], L: 34, hue: 0.1, reveal: 0, w: 0.0 },
  // a hyperboloid whose slice changes topology as the space turns through W
  { D: [1, 1, -1, -1], g: [0, 0, 0, 0], c: -0.18, C: [0.65, -0.35, 0.2, 0], q: [-0.3, 0.1, 0.5, 0.8], r: [0.4, -0.2, 0.1, 0.89], L: 42, hue: 0.85, reveal: 0, w: 0.1 },
  // a skewed hyperboloid far off to one side
  { D: [0.8, -0.6, 0.9, -1.2], g: [0, 0, 0, 0], c: -0.35, C: [1.2, 0.4, -0.8, 0], q: [0.6, 0.2, -0.1, 0.77], r: [0.1, 0.1, 0.6, 0.79], L: 30, hue: 0.3, reveal: 0.12, w: -0.2 },
  // a second saddle, crossing the first at a strange angle
  { D: [-0.45, 0, 0.6, 0], g: [0, 0.9, 0, -0.5], c: -0.6, C: [0, 0.3, 0, 0], q: [0.1, 0.7, 0.3, 0.64], r: [-0.5, 0.2, 0.3, 0.79], L: 52, hue: 0.65, reveal: 0.3, w: 0.25 },
  // a hyperboloid of the other orientation, folded through the depth of the scene
  { D: [-1, 0.6, 1, -0.4], g: [0, 0.3, 0, 0], c: 0.32, C: [-0.4, 0, 0.6, 0.1], q: [-0.2, -0.6, 0.2, 0.75], r: [0.3, 0.5, -0.4, 0.71], L: 64, hue: 0.05, reveal: 0.5, w: -0.15 },
  // High: a very distant saddle as the deepest layer
  { D: [0.3, 0, -0.3, 0], g: [0, -1, 0, 0.4], c: 0.9, C: [0, 0, 0, 0], q: [0.5, -0.5, -0.5, 0.5], r: [0.2, 0.6, 0.1, 0.77], L: 140, hue: 0.5, reveal: 0.15, hq: true, w: 0.3 }
].map((m) => ({ ...m, M: rotationMatrix(quat.norm(m.q), quat.norm(m.r)) })));

// Each world gives the environment its own slice height (part of the reorganisation at a drop).
export const AETHER_WORLD_SLICE = Object.freeze([0.0, 0.32, -0.28, 0.5, -0.45]);

const mul4 = (a, b) => {   // column-major 4x4 product a * b
  const o = new Float32Array(16);
  for (let c = 0; c < 4; c += 1) for (let r = 0; r < 4; r += 1) {
    let s = 0;
    for (let k = 0; k < 4; k += 1) s += a[k * 4 + r] * b[c * 4 + k];
    o[c * 4 + r] = s;
  }
  return o;
};

// Uniform data for one frame. cam: { eye, r, u, f } in world space; s: director state.
export function aetherFrame(s, cam, { quality = 0, aspect = 16 / 9, fov = 0.85, focus = [0, 0, 0] } = {}) {
  const renv = rotationMatrix(s.qeL, s.qeR);
  // The environment turns with a fraction of the camera's orbit, so the far field drifts slowly
  // instead of wheeling past at the orbit rate; translation (parallax) is untouched.
  const k = -0.55 * s.cam.yaw, cy = Math.cos(k), sy = Math.sin(k);
  const ry = (v) => [cy * v[0] + sy * v[2], v[1], -sy * v[0] + cy * v[2]];
  const eye = ry(cam.eye), R = ry(cam.r), U = ry(cam.u), F = ry(cam.f);
  const count = quality ? AETHER_MAX : AETHER_MAX - 1;
  const G = new Float32Array(12 * AETHER_MAX), Y0 = new Float32Array(4 * AETHER_MAX), D = new Float32Array(4 * AETHER_MAX);
  const lin = new Float32Array(4 * AETHER_MAX), mem = new Float32Array(4 * AETHER_MAX), mem2 = new Float32Array(4 * AETHER_MAX);
  const bend = 1 + 0.22 * (s.envBass - 0.3);
  const reveal = s.envReveal;
  let n = 0;
  for (const m of MEMBRANES) {
    if (m.hq && !quality) continue;
    const g4 = mul4(m.M, renv);
    for (let c = 0; c < 3; c += 1) for (let r = 0; r < 4; r += 1) G[n * 12 + c * 4 + r] = g4[c * 4 + r] / m.L;
    const x = [eye[0] / m.L, eye[1] / m.L, eye[2] / m.L, s.envSlice + m.w];
    for (let r = 0; r < 4; r += 1) Y0[n * 4 + r] = g4[r] * x[0] + g4[4 + r] * x[1] + g4[8 + r] * x[2] + g4[12 + r] * x[3] - m.C[r];
    // Bass bends the sheets: the quadratic part breathes against the linear part.
    D.set(m.D.map((v) => v * bend), n * 4);
    lin.set(m.g, n * 4);
    const visible = Math.min(1, Math.max(0, (reveal - m.reveal) / 0.22 + (m.reveal === 0 ? 1 : 0)));
    mem.set([m.c, visible, m.hue, n * 1.7], n * 4);
    mem2.set([m.L, m.L * 5.5, 1.6 + 0.04 * m.L, 0], n * 4);
    n += 1;
  }
  // The fourth axis of the environment seen from our 3-space: the direction in which w increases
  // fastest, and how far the space is tilted into it.
  const wx = renv[3], wy = renv[7], wz = renv[11];
  const wl = Math.hypot(wx, wy, wz) || 1;
  const axis = ry([wx / wl, wy / wl, wz / wl]);
  const kickR = 10 + 150 * s.envKickAge;
  return {
    count, G, Y0, D, lin, mem, mem2,
    cam: { R, U, F }, tan: [Math.tan(fov / 2) * aspect, Math.tan(fov / 2)],
    music: [s.envEnergy, Math.min(1, s.highs * 0.6 + s.hatGlint), kickR, s.envKick * Math.exp(-s.envKickAge / 0.75)],
    sweep: s.sweep ? [1, s.sweep.h * 1.4, 1, 0] : [0, 0, 0, 0],
    focus,
    axis: [...axis, Math.min(1, wl)],
    params: [quality ? 1 : 0, s.time, s.breakdown * (1 - s.groove), s.envMaster]
  };
}

export const aetherFragment = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
#define N ${AETHER_MAX}
uniform int uCount;
uniform mat3x4 uG[N];     // 4D frame of each membrane, x, y, z columns per world unit
uniform vec4 uY0[N];      // the eye in each membrane's frame
uniform vec4 uD[N];       // quadratic part (diagonal)
uniform vec4 uLin[N];     // linear part
uniform vec4 uMem[N];     // x constant, y visibility, z hue, w phase
uniform vec4 uMem2[N];    // x L, y fog length, z fringe wavelength (world units)
uniform vec3 uCamR, uCamU, uCamF;
uniform vec2 uTan;
uniform vec2 uRes;
uniform vec4 uMusic;      // x energy, y highs, z kick wave radius, w kick strength
uniform vec4 uSweep;      // x active, y hyperplane height in membrane w
uniform vec4 uFocus;      // xy centre of the polytope (aspect-corrected ndc), z radius, w attenuation
uniform vec4 uAxis;       // xyz the environment's fourth axis in 3-space, w its tilt
uniform vec4 uParams;     // x quality, y time, z breakdown, w master

const float TAU = 6.2831853;
float pow2(float x) { return x * x; }
// transpose(G) * v, written as the three column dot products
vec3 gradOf(mat3x4 G, vec4 v) { return vec3(dot(G[0], v), dot(G[1], v), dot(G[2], v)); }

// The hidden coordinate's colour, in the polytope's own convention (violet far side, turquoise
// near side), muted for the environment.
vec3 membraneTint(float hue, float w) {
  vec3 violet = vec3(0.38, 0.13, 0.80), teal = vec3(0.05, 0.50, 0.56), indigo = vec3(0.20, 0.12, 0.60);
  vec3 c = mix(violet, teal, smoothstep(0.0, 1.0, hue));
  // opalescence: the hidden coordinate turns the tint towards indigo or blue-green
  return mix(c, mix(indigo, vec3(0.08, 0.46, 0.42), smoothstep(-1.0, 1.0, w)), 0.3);
}

void main() {
  vec2 ndc = vUv * 2.0 - 1.0;
  vec3 d = normalize(uCamF + ndc.x * uTan.x * uCamR + ndc.y * uTan.y * uCamU);
  float pixAng = 2.0 * uTan.y / uRes.y;
  float hq = uParams.x;

  // Deep space: indigo to near black, a faint lean of light along the fourth axis.
  float up = d.y * 0.5 + 0.5;
  vec3 col = mix(vec3(0.0035, 0.004, 0.011), vec3(0.010, 0.008, 0.026), smoothstep(0.1, 0.9, up));
  float lobe = max(dot(d, uAxis.xyz), 0.0);
  col += vec3(0.020, 0.010, 0.040) * lobe * lobe * uAxis.w * (0.6 + 0.6 * uMusic.x);


  // Detail is softened behind the polytope (its glass stays readable).
  vec2 fp = (ndc - uFocus.xy) * vec2(uTan.x / uTan.y, 1.0);
  float behind = smoothstep(uFocus.z * 1.15, uFocus.z * 0.55, length(fp)) * uFocus.w;
  float detail = 1.0 - behind;
  float energy = uMusic.x, calm = uParams.z;

  // Along the ray every membrane is two quadratics in t: its field Q(t) = A t^2 + B t + C and the
  // squared length of its gradient |grad Q(t)|^2 (the gradient is linear in t). The signed
  // distance to membrane j anywhere on the ray is then Q_j / |grad Q_j| at the cost of a few
  // multiply-adds. Constant loop bounds let the compiler unroll and keep these in registers.
  vec3 Qc[N], Gc[N];
  vec2 Wc[N];
  for (int j = 0; j < N; j++) {
    vec4 y1 = uG[j] * d, y0 = uY0[j], dy = uD[j] * y1;
    Qc[j] = vec3(dot(y1, dy), 2.0 * dot(y0, dy) + dot(uLin[j], y1), dot(y0, uD[j] * y0) + dot(uLin[j], y0) + uMem[j].x);
    vec3 ga = gradOf(uG[j], 2.0 * uD[j] * y0 + uLin[j]), gb = gradOf(uG[j], 2.0 * dy);
    Gc[j] = vec3(dot(gb, gb), 2.0 * dot(ga, gb), dot(ga, ga));
    Wc[j] = vec2(y0.w, y1.w);
  }

  vec3 acc = vec3(0.0);
  for (int i = 0; i < N; i++) {
    float vis = uMem[i].y;
    if (i >= uCount || vis <= 0.001) continue;
    vec3 q = Qc[i];
    float disc = q.y * q.y - 4.0 * q.x * q.z;
    if (disc < 0.0) continue;
    float sq = sqrt(disc);
    vec2 roots = abs(q.x) > 1e-7 ? vec2(-q.y - sq, -q.y + sq) / (2.0 * q.x) : vec2(-q.z / q.y, -1.0);
    float L = uMem2[i].x;
    for (int k = 0; k < 2; k++) {
      float t = k == 0 ? roots.x : roots.y;
      if (t < 6.0 || t > L * 14.0) continue;
      float Yw = Wc[i].x + t * Wc[i].y;          // the membrane's hidden fourth coordinate here
      float gl = sqrt(max((Gc[i].x * t + Gc[i].y) * t + Gc[i].z, 1e-12));
      float cosT = abs(2.0 * q.x * t + q.y) / gl;
      float pf = t * pixAng;                          // pixel footprint (world units)
      float pfs = pf / max(cosT, 0.06);                // ... across the sheet
      float fade = smoothstep(6.0, 22.0, t) * exp(-t / uMem2[i].y);
      if (fade * vis < 0.003) continue;

      // The sheet: light through a thin membrane, brightest towards its folds (peak at cos = k,
      // falling smoothly to zero at the silhouette, so the fold never aliases).
      float kk = 0.065;
      float sheet = cosT / (cosT * cosT + kk * kk) * kk * 2.0;
      sheet = 0.4 * sheet + 0.6 * sheet * sheet * sheet;   // translucent body, luminous folds
      // Light lives in a broad band of the hidden coordinate, which drifts as the space turns
      // through W: regions of the sheet are lit and fall dark again.
      float band = sin(uParams.y * 0.045 + uMem[i].w * 2.1) * 0.7;
      float lit = 0.07 + 0.93 * exp(-pow2((Yw - band) / 0.42));
      // Strata: contours of the hidden fourth coordinate across the sheet.
      vec3 wRow = vec3(uG[i][0].w, uG[i][1].w, uG[i][2].w);
      float dw = length(wRow) * pfs * 7.0;
      float strata = (0.5 + 0.5 * cos(TAU * (Yw * 3.5 + uMem[i].w + uParams.y * 0.01))) * smoothstep(0.6, 0.15, dw);
      vec3 tint = membraneTint(uMem[i].z, Yw);
      vec3 c = tint * sheet * lit * (0.32 + 0.12 * energy) * (0.84 + 0.16 * strata * lit * (0.6 + 0.4 * hq));

      // Interference with every other membrane at this point.
      float lambda = uMem2[i].z * (1.0 - 0.25 * hq);
      float fringeAA = smoothstep(0.55, 0.2, pfs / lambda);
      float re = 0.0, im = 0.0, power = 0.0, fil = 0.0, cross2 = 0.0;
      for (int j = 0; j < N; j++) {
        if (j == i || j >= uCount || uMem[j].y <= 0.001) continue;
        float qj = (Qc[j].x * t + Qc[j].y) * t + Qc[j].z;
        float dj = qj * inversesqrt(max((Gc[j].x * t + Gc[j].y) * t + Gc[j].z, 1e-12));   // signed distance to membrane j (world)
        float wf = max(pfs * 1.15, 0.05 + 0.002 * t) * (1.0 - 0.2 * hq);
        // Most of the sheet is far from every intersection: nothing to add there.
        if (abs(dj) > max(lambda * 6.0, wf * 3.0)) continue;
        float a = exp(-abs(dj) / (lambda * 1.6)) * uMem[j].y;
        float ph = TAU * dj / lambda - uParams.y * (0.35 + 0.1 * float(j)) + uMem[j].w;
        re += a * cos(ph); im += a * sin(ph); power += a * a;
        float f = exp(-(dj * dj) / (wf * wf)) * uMem[j].y * min(1.0, pfs * 1.2 / wf + 0.4);
        cross2 += fil * f;                             // two intersection curves meeting
        fil += f;
      }
      // Interference proper: |sum a e^(i phi)|^2 - sum a^2 keeps only the cross terms, which exist
      // only where two fields overlap (near crossings of intersection curves); at peaks the single
      // fields' own fringes show too.
      float fringe = (max(re * re + im * im - power, 0.0) + re * re * smoothstep(0.65, 0.95, energy) * 0.6) * fringeAA;
      // Kick: a wave of light running outwards along the intersections.
      float kr = uMusic.z, kw = 6.0 + 0.12 * kr;
      float wave = uMusic.w * exp(-(t - kr) * (t - kr) / (kw * kw));
      // The drop's sweeping hyperplane crossing the sheet.
      float sw = uSweep.x * exp(-pow2(Yw - uSweep.y) / 0.004);
      vec3 pale = mix(vec3(0.55, 0.85, 1.0), vec3(0.74, 0.62, 1.0), 0.5 + 0.5 * sin(Yw * 3.0));
      vec3 filC = mix(tint * 1.8, pale, 0.45);
      c += pale * fringe * (0.012 + 0.03 * energy) * (1.0 - 0.6 * calm) * detail;
      c += filC * fil * (0.025 + 0.035 * energy + 0.12 * uMusic.y + 0.9 * wave) * (0.3 + 0.7 * detail) * (0.35 + 0.65 * lit);
      c += vec3(1.0, 0.62, 0.25) * min(cross2, 1.0) * (0.35 + 0.8 * wave + 0.3 * uMusic.y) * detail;
      c += vec3(0.95, 0.75, 0.40) * sw * 0.35 * sheet;
      c += tint * wave * sheet * 0.025;
      acc += c * vis * fade;
    }
  }
  col += acc * uParams.w;
  outColor = vec4(col, 1.0);
}`;

// The environment is rendered at a fraction of the frame size into its own target (it is soft,
// distant detail; filament widths follow that target's pixel size) and upsampled bilinearly as the
// first layer of the scene. Standard: half the frame; High: 0.4 of its larger frame (more pixels
// than Standard, and the sixth membrane, finer fringes and filaments).
export const AETHER_SCALE = Object.freeze([0.5, 0.4]);
export const aetherUpsampleFragment = `#version 300 es
precision highp float;
in vec2 vUv;
out vec4 outColor;
uniform sampler2D uAether;
void main() { outColor = vec4(texture(uAether, vUv).rgb, 1.0); }`;
