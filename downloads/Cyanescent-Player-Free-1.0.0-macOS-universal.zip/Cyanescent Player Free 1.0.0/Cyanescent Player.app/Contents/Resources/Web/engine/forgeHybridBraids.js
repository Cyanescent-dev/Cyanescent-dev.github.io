const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const smooth = (lo, hi, x) => { const t = clamp((x - lo) / (hi - lo), 0, 1); return t * t * (3 - 2 * t); };
const PATHS = 48;
const STEPS = 28;
const POINTS = STEPS * 2 + 1;
const STRIDE = 10;
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

// Screen-space flow excludes camera movement. Only musical memory persists:
// every rendered centreline is traced again against the current video fields.
export function createForgeBraids(width, height) {
  const vertices = new Float32Array(PATHS * (POINTS - 1) * 2 * 6 * STRIDE);
  const anchors = new Float32Array(PATHS * 4); // x, y, attachment fade, phase
  const points = new Float32Array(POINTS * 6); // x, y, tangent x/y, supported radius, confidence
  const field = new Float32Array(4);
  const midpoint = new Float32Array(4);
  const state = { bass: 0, mids: 0, highs: 0, energy: 0, anticipation: 0, release: 0, releaseAge: 0,
    phase: 0, weave: 0, phrase: 0, breakdown: 0, kick: 0, phrase8: 0, phrase16: 0, phrase32: 0 };
  const diagnostics = { paths: 0, centreSamples: 0, supportedSamples: 0, maxCorrection: 0, vertices: 0,
    traffic: 0, travelSpeed: 0, maximumStripRadius: 0 };
  let lastVideoTime = -1;
  let wasDrop = false;
  let used = 0;
  let pair = null;
  let mix = 0;

  function sample(x, y, out = field) {
    const px = clamp(x - 0.5, 0, width - 1), py = clamp(y - 0.5, 0, height - 1);
    const ix = Math.floor(px), iy = Math.floor(py), fx = px - ix, fy = py - iy;
    const jx = Math.min(ix + 1, width - 1), jy = Math.min(iy + 1, height - 1);
    const i00 = (iy * width + ix) * 4, i10 = (iy * width + jx) * 4;
    const i01 = (jy * width + ix) * 4, i11 = (jy * width + jx) * 4;
    const a = (1 - fx) * (1 - fy), b = fx * (1 - fy), c = (1 - fx) * fy, d = fx * fy;
    for (let component = 0; component < 4; component++) {
      const channel = component === 0 ? 0 : component - 1;
      const p0 = component === 0 ? pair.a.densityPixels : pair.a.flowPixels;
      const p1 = component === 0 ? pair.b.densityPixels : pair.b.flowPixels;
      const v0 = p0[i00 + channel] * a + p0[i10 + channel] * b + p0[i01 + channel] * c + p0[i11 + channel] * d;
      const v1 = p1[i00 + channel] * a + p1[i10 + channel] * b + p1[i01 + channel] * c + p1[i11 + channel] * d;
      const value = v0 + (v1 - v0) * mix;
      out[component] = component === 1 || component === 2 ? (value - 128) / 127 : value / 255;
    }
    return out;
  }

  function findAnchor(id, dt) {
    const offset = id * 4;
    let x = anchors[offset], y = anchors[offset + 1];
    let score = -Infinity, bx = x, by = y;
    const attached = anchors[offset + 2] > 0;
    // A local search follows the moving visible support, without integrating
    // cytoplasmic flow as if it were optical flow. Lost support reseeds a cell.
    const targetX = attached ? x : (id % 8 + 0.25 + hash(id + 1) * 0.5) * width / 8;
    const targetY = attached ? y : (Math.floor(id / 8) + 0.25 + hash(id + 81) * 0.5) * height / 6;
    const radius = attached ? 5 : Math.min(width / 16, height / 12);
    const step = attached ? 0.5 : 3;
    for (let dy = -radius; dy <= radius; dy += step) {
      for (let dx = -radius; dx <= radius; dx += step) {
        const sx = targetX + dx, sy = targetY + dy;
        if (sx < 2 || sy < 2 || sx >= width - 2 || sy >= height - 2) continue;
        sample(sx, sy);
        if (field[0] < 0.14 || field[3] < 0.28 || Math.hypot(field[1], field[2]) < 0.2) continue;
        const candidate = Math.min(field[0], 0.42) * 0.24 + field[3] * 0.045 -
          (dx * dx + dy * dy) / (radius * radius) * (attached ? 0.24 : 0.045);
        if (candidate > score) { score = candidate; bx = sx; by = sy; }
      }
    }
    if (!Number.isFinite(score)) { anchors[offset + 2] = 0; return false; }
    anchors[offset] = bx;
    anchors[offset + 1] = by;
    anchors[offset + 2] = Math.min(1, anchors[offset + 2] + dt * 2.2);
    anchors[offset + 3] = hash(id + 401) * Math.PI * 2;
    return true;
  }

  function trace(id, direction) {
    const anchor = id * 4;
    let x = anchors[anchor], y = anchors[anchor + 1];
    sample(x, y);
    let norm = Math.hypot(field[1], field[2]);
    let tx = field[1] / norm * direction, ty = field[2] / norm * direction;
    let count = 0;
    for (let step = 0; step <= STEPS; step++) {
      if (x < 2 || y < 2 || x >= width - 2 || y >= height - 2) break;
      sample(x, y);
      if (field[0] < 0.12 || field[3] < 0.26) break;
      norm = Math.hypot(field[1], field[2]);
      if (norm < 0.20) break;
      let fx = field[1] / norm * direction, fy = field[2] / norm * direction;
      // Geometry follows a continuous strand axis. Travelling phase retains the
      // actual oriented flow sign in the shader, including a reversing stream.
      if (fx * tx + fy * ty < 0) { fx = -fx; fy = -fy; }
      if (fx * tx + fy * ty < 0.68) break;
      tx = tx * 0.25 + fx * 0.75; ty = ty * 0.25 + fy * 0.75;
      norm = Math.hypot(tx, ty); tx /= norm; ty /= norm;
      const nx = -ty, ny = tx;
      let left = 0, right = 0;
      for (let distance = 0.25; distance <= 3; distance += 0.25) {
        sample(x - nx * distance, y - ny * distance);
        if (field[0] < 0.10 || field[3] < 0.24) break;
        left = distance;
      }
      for (let distance = 0.25; distance <= 3; distance += 0.25) {
        sample(x + nx * distance, y + ny * distance);
        if (field[0] < 0.10 || field[3] < 0.24) break;
        right = distance;
      }
      // Contiguous support, rather than the strongest density value, determines
      // the tube centre. This avoids jumping sideways into a brighter junction.
      const correction = clamp((right - left) * 0.40, -0.85, 0.85);
      x += nx * correction; y += ny * correction;
      sample(x, y);
      if (field[0] < 0.12 || field[3] < 0.26) break;
      const confidence = field[3];
      // Measure contiguous support again after recentering. A fixed feather
      // wider than a narrow tube can look like a second, detached network.
      let radius = 0;
      for (let distance = 0.2; distance <= 1.6; distance += 0.2) {
        sample(x - nx * distance, y - ny * distance);
        if (field[0] < 0.10 || field[3] < 0.24) break;
        sample(x + nx * distance, y + ny * distance);
        if (field[0] < 0.10 || field[3] < 0.24) break;
        radius = distance;
      }
      if (radius < 0.2) break;
      const p = (STEPS + step * direction) * 6;
      points[p] = x; points[p + 1] = y;
      points[p + 2] = tx * direction; points[p + 3] = ty * direction;
      points[p + 4] = Math.max(0, radius - 0.08);
      points[p + 5] = confidence;
      diagnostics.centreSamples++;
      diagnostics.supportedSamples++;
      diagnostics.maxCorrection = Math.max(diagnostics.maxCorrection, Math.abs(correction));
      count++;
      // Midpoint integration traces curvature without long straight shortcuts.
      sample(x + tx * 0.5, y + ty * 0.5, midpoint);
      norm = Math.hypot(midpoint[1], midpoint[2]);
      if (midpoint[0] < 0.12 || midpoint[3] < 0.26 || norm < 0.2) break;
      let mx = midpoint[1] / norm * direction, my = midpoint[2] / norm * direction;
      if (mx * tx + my * ty < 0) { mx = -mx; my = -my; }
      x += mx * 1.1; y += my * 1.1;
    }
    return count;
  }

  function vertex(p, arc, side, strand, power, phase, endFade) {
    vertices[used++] = points[p]; vertices[used++] = points[p + 1];
    vertices[used++] = -points[p + 3]; vertices[used++] = points[p + 2];
    vertices[used++] = arc; vertices[used++] = side;
    vertices[used++] = power * endFade * smooth(0.24, 0.65, points[p + 5]);
    vertices[used++] = phase + strand * Math.PI;
    const stripRadius = Math.min(0.30, points[p + 4] * 0.45);
    vertices[used++] = Math.min(0.60, Math.max(0, points[p + 4] - stripRadius));
    vertices[used++] = stripRadius;
    diagnostics.maximumStripRadius = Math.max(diagnostics.maximumStripRadius, stripRadius);
  }

  function update({ fields, fieldMix, videoTime, dt, audio = {}, bands = {}, music = {}, cues = null, amount = 0.7, speed = 0.7 }) {
    pair = fields; mix = fieldMix; used = 0;
    if (lastVideoTime >= 0 && Math.abs(videoTime - lastVideoTime) > 0.30) anchors.fill(0);
    lastVideoTime = videoTime;
    for (const [name, input] of [["bass", bands.bass], ["mids", bands.mids], ["highs", bands.highs],
      ["energy", audio.globalEnergy ?? music.adaptiveIntensity]]) {
      const target = clamp(Number(input) || 0, 0, 1);
      state[name] += (target - state[name]) * (1 - Math.exp(-dt / (target > state[name] ? 0.16 : 0.75)));
    }
    const upcoming = clamp(Number(cues?.anticipation ?? music.upcomingDrop) || 0, 0, 1);
    state.anticipation += (upcoming - state.anticipation) * (1 - Math.exp(-dt / 0.7));
    if (cues) {
      state.release = cues.release || 0;
      state.releaseAge = cues.releaseAge || 0;
      for (const key of ["breakdown", "kick", "phrase8", "phrase16", "phrase32"]) state[key] = Number(cues[key]) || 0;
    } else {
      const drop = (Number(music.drop) || 0) > 0.35;
      if (drop && !wasDrop) { state.release = 1; state.releaseAge = 0; }
      wasDrop = drop;
      state.releaseAge += dt;
      state.release *= Math.exp(-dt / 3.4);
      const breakdown = clamp(Number(music.breakdown) || 0, 0, 1);
      state.breakdown += (breakdown - state.breakdown) * (1 - Math.exp(-dt / 1.2));
      state.kick += (clamp(Number(audio.kickPulse) || 0, 0, 1) - state.kick) * (1 - Math.exp(-dt / 0.16));
    }
    // Lookahead gathers traffic into slower, tighter trains. The release then
    // moves through those same strands; it does not light every path at once.
    const travelSpeed = (2 + state.bass * 17 + state.kick * 9 + state.release * 20) * speed *
      (1 - 0.64 * state.anticipation * (1 - state.release * 0.90)) *
      (1 - 0.68 * state.breakdown * (1 - state.release * 0.90));
    state.phase += dt * travelSpeed;
    state.weave += dt * (0.3 + state.mids * 2.0) * (1 - 0.7 * state.anticipation);
    state.phrase = Number(music.phraseProgress) || 0;
    diagnostics.paths = diagnostics.centreSamples = diagnostics.supportedSamples = diagnostics.maxCorrection = diagnostics.maximumStripRadius = 0;
    const hierarchy = 0.94 + 0.06 * Math.sin(state.phrase32 * Math.PI * 2);
    const activity = clamp((0.09 + state.energy * 0.98 * (1 - 0.38 * state.anticipation) + state.release * 0.20) *
      (1 - state.breakdown * 0.77 * (1 - state.release * 0.90)) * hierarchy * amount, 0, 1.5);
    diagnostics.traffic = activity; diagnostics.travelSpeed = travelSpeed;
    for (let id = 0; id < PATHS; id++) {
      const selection = 1 - smooth(activity - 0.10, activity + 0.12, hash(id + 210));
      if (selection < 0.01 || !findAnchor(id, dt)) continue;
      const backward = trace(id, -1), forward = trace(id, 1);
      if (backward + forward < 12) continue;
      diagnostics.paths++;
      const first = STEPS - backward + 1, last = STEPS + forward - 1;
      const power = selection * anchors[id * 4 + 2];
      const phase = anchors[id * 4 + 3];
      // Anchor-relative arc preserves travelling phase if a traced endpoint
      // shortens at an occlusion, rather than restarting the whole light train.
      let arc = 0;
      for (let i = first; i < STEPS; i++) {
        const a = i * 6, b = (i + 1) * 6;
        arc -= Math.hypot(points[b] - points[a], points[b + 1] - points[a + 1]);
      }
      for (let i = first; i < last; i++) {
        const a = i * 6, b = (i + 1) * 6;
        const nextArc = arc + Math.hypot(points[b] - points[a], points[b + 1] - points[a + 1]);
        const fa = smooth(0, 5, i - first) * smooth(0, 5, last - i);
        const fb = smooth(0, 5, i + 1 - first) * smooth(0, 5, last - i - 1);
        for (let strand = 0; strand < 2; strand++) {
          vertex(a, arc, -1, strand, power, phase, fa);
          vertex(a, arc, 1, strand, power, phase, fa);
          vertex(b, nextArc, -1, strand, power, phase, fb);
          vertex(b, nextArc, -1, strand, power, phase, fb);
          vertex(a, arc, 1, strand, power, phase, fa);
          vertex(b, nextArc, 1, strand, power, phase, fb);
        }
        arc = nextArc;
      }
    }
    diagnostics.vertices = used / STRIDE;
    return used / STRIDE;
  }
  function reset() {
    anchors.fill(0); lastVideoTime = -1; wasDrop = false;
    for (const key of Object.keys(state)) state[key] = 0;
    for (const key of Object.keys(diagnostics)) diagnostics[key] = 0;
  }
  return { vertices, state, diagnostics, update, reset, stride: STRIDE };
}
