import { clamp01, fractJs } from "../utils/math.js";
import { MusicalEventType } from "./transitions.js";

export function eventTypeForSectionLabel(label) {
  if (label === "Drop") return MusicalEventType.DROP;
  if (label === "Buildup") return MusicalEventType.BUILD_UP;
  if (label === "Breakdown") return MusicalEventType.BREAKDOWN;
  if (label === "Main riff") return MusicalEventType.HIGH_ENERGY;
  if (label === "Intro" || label === "Wind down") return MusicalEventType.CALM_SECTION;
  return MusicalEventType.SECTION_CHANGE;
}

export function transitionStyleForMusicalEvent(type) {
  if (type === MusicalEventType.DROP || type === MusicalEventType.HIGH_ENERGY) return 2;
  if (type === MusicalEventType.BUILD_UP) return 1;
  if (type === MusicalEventType.BREAKDOWN || type === MusicalEventType.CALM_SECTION) return 3;
  return 0;
}

export function selectAdaptiveLandingTime({
  event,
  currentTime,
  earliest,
  latest,
  transitionLead,
  loopBoundaries
}) {
  const eventTime = event?.time || earliest;
  const desired = Math.max(earliest, Math.min(latest, eventTime || earliest));
  const candidates = Array.isArray(loopBoundaries) ? loopBoundaries : [];

  if (!candidates.length) {
    return { time: desired, beats: null };
  }

  let best = candidates[0];
  let bestScore = Infinity;
  const structuralEvent = event?.type === MusicalEventType.DROP || event?.type === MusicalEventType.BREAKDOWN || event?.type === MusicalEventType.BUILD_UP;
  const eventConfidence = clamp01(event?.confidence ?? 0.5);
  const distanceWeight = 0.86 + eventConfidence * 0.24 + (structuralEvent ? 0.22 : 0);
  for (const candidate of candidates) {
    const distance = Math.abs(candidate.time - desired);
    const distanceScore = distance * distanceWeight;
    const loopPreference = candidate.beats === 32 ? -6.0 : candidate.beats === 16 ? -2.25 : 0.18;
    const farFromEventPenalty = candidate.beats === 32 ? Math.max(0, distance - 8.0) * 0.82 : candidate.beats === 16 ? Math.max(0, distance - 5.0) * 0.55 : 0;
    const urgencyPenalty = candidate.time < currentTime + transitionLead ? 10 : 0;
    const score = distanceScore + loopPreference + farFromEventPenalty + urgencyPenalty;
    if (score < bestScore) {
      bestScore = score;
      best = candidate;
    }
  }
  return best;
}

export function chooseAdaptivePreset({
  event,
  activePreset,
  presetMetadata,
  presetMetadataById,
  recentPresets = [],
  candidatePresetIds = null,
  usedPresetIds = null,
  currentTime = 0
}) {
  let best = null;
  let bestScore = -Infinity;
  const activeMetadata = presetMetadataById.get(activePreset);
  const adaptivePresets = presetMetadata.filter((metadata) => metadata.adaptive !== false && metadata.id !== activePreset);
  const unusedPresets = Array.isArray(candidatePresetIds)
    ? adaptivePresets.filter((metadata) => candidatePresetIds.includes(metadata.id))
    : usedPresetIds instanceof Set
    ? adaptivePresets.filter((metadata) => !usedPresetIds.has(metadata.id))
    : adaptivePresets;
  const candidatePresets = unusedPresets.length ? unusedPresets : adaptivePresets;
  for (const metadata of candidatePresets) {
    if (metadata.adaptive === false) continue;
    if (metadata.id === activePreset) continue;
    let score = 0;
    const recentIndex = recentPresets.indexOf(metadata.id);
    if (recentIndex >= 0) score -= 1.6 - recentIndex * 0.22;
    if (activeMetadata) {
      if (metadata.category === activeMetadata.category) score -= 0.28;
      if (metadata.motionIntensity === activeMetadata.motionIntensity && metadata.visualDensity === activeMetadata.visualDensity) score -= 0.18;
    }
    for (const recentId of recentPresets.slice(0, 3)) {
      const recent = presetMetadataById.get(recentId);
      if (recent?.category === metadata.category) score -= 0.18;
    }
    if (event.type === MusicalEventType.DROP) {
      score += metadata.goodForDrops ? 3.0 : -0.4;
      score += metadata.energyLevel === "high" ? 1.2 : metadata.energyLevel === "medium" ? 0.2 : -1.0;
      score += metadata.motionIntensity === "high" ? 0.8 : 0;
      score += metadata.visualDensity === "dense" ? 0.45 : 0;
    } else if (event.type === MusicalEventType.HIGH_ENERGY) {
      score += metadata.energyLevel === "high" ? 2.0 : metadata.energyLevel === "medium" ? 0.8 : -0.8;
      score += metadata.goodForDrops ? 0.8 : 0;
    } else if (event.type === MusicalEventType.BREAKDOWN || event.type === MusicalEventType.CALM_SECTION) {
      score += metadata.goodForBreakdowns ? 2.8 : -0.8;
      score += metadata.energyLevel === "low" ? 1.2 : metadata.energyLevel === "medium" ? 0.3 : -1.0;
      score += metadata.motionIntensity === "low" ? 0.7 : 0;
      score += metadata.visualDensity === "sparse" ? 0.5 : 0;
    } else if (event.type === MusicalEventType.BUILD_UP) {
      score += metadata.goodForBuildUps ? 2.4 : -0.2;
      score += metadata.motionIntensity === "medium" || metadata.motionIntensity === "high" ? 0.7 : 0;
      score += metadata.energyLevel === "medium" ? 0.45 : metadata.energyLevel === "high" ? 0.35 : -0.3;
    } else {
      score += metadata.energyLevel === "medium" ? 0.8 : 0.2;
    }
    score += fractJs(Math.sin(metadata.id * 13.17 + Math.floor(currentTime / 30) * 91.7) * 43758.5453) * 0.24;
    if (score > bestScore) {
      bestScore = score;
      best = metadata.id;
    }
  }
  return best;
}

export function detectAdaptiveMusicalEvent({
  currentTime,
  current,
  near,
  medium,
  long,
  upcomingSection,
  musicAwareState
}) {
  if (!current || !near || !medium || !long) return { best: null, events: [] };
  const events = [];
  const brain = musicAwareState || {};

  if (upcomingSection) {
    const eventType = eventTypeForSectionLabel(upcomingSection.label);
    if (eventType) {
      const secondsAway = upcomingSection.start - currentTime;
      const distanceScore = 1 - Math.abs(secondsAway - 7.0) / 14.0;
      events.push({
        type: eventType,
        time: upcomingSection.start,
        confidence: clamp01(0.54 + Math.max(0, distanceScore) * 0.22 + (upcomingSection.label === "Drop" ? 0.12 : 0)),
        reason: `section:${upcomingSection.label}`
      });
    }
  }

  const phraseTarget = currentTime + Math.max(3.0, Math.min(12.0, brain.nextPhraseSeconds || 6.0));
  if (brain.upcomingDrop > 0.42) {
    events.push({
      type: MusicalEventType.DROP,
      time: phraseTarget,
      confidence: clamp01(0.50 + brain.upcomingDrop * 0.34 + brain.buildUp * 0.16),
      reason: "visual brain: upcoming drop"
    });
  }
  if (brain.upcomingBreakdown > 0.45) {
    events.push({
      type: MusicalEventType.BREAKDOWN,
      time: phraseTarget,
      confidence: clamp01(0.50 + brain.upcomingBreakdown * 0.32 + brain.calm * 0.12),
      reason: "visual brain: upcoming breakdown"
    });
  }
  if (brain.upcomingBuild > 0.42 || brain.buildUp > 0.56) {
    events.push({
      type: MusicalEventType.BUILD_UP,
      time: phraseTarget,
      confidence: clamp01(0.46 + Math.max(brain.upcomingBuild || 0, brain.buildUp || 0) * 0.32),
      reason: "visual brain: build pressure"
    });
  }

  const energyRise = medium.maxEnergy - current.energy;
  const energyFall = current.energy - medium.energy;
  const bassRise = medium.bass - current.bass;
  const densityRise = medium.density - current.density;
  const brightnessRise = medium.brightness - current.brightness;
  const sectionProbability = Math.max(medium.maxSectionProbability || 0, long.maxSectionProbability || 0);

  if (energyRise > 0.20 && bassRise > 0.08 && densityRise > 0.05) {
    events.push({
      type: MusicalEventType.DROP,
      time: currentTime + 6.5,
      confidence: clamp01(energyRise * 1.8 + bassRise * 1.0 + densityRise * 0.8),
      reason: "energy+bass rise"
    });
  }

  if (energyRise > 0.11 && brightnessRise > 0.03 && long.energyDelta > 0.05) {
    events.push({
      type: MusicalEventType.BUILD_UP,
      time: currentTime + 8.0,
      confidence: clamp01(energyRise * 1.2 + brightnessRise * 1.3 + sectionProbability * 0.35),
      reason: "gradual rise"
    });
  }

  if (energyFall > 0.18 && medium.bass < current.bass * 0.72 && medium.density < current.density * 0.76) {
    events.push({
      type: MusicalEventType.BREAKDOWN,
      time: currentTime + 5.5,
      confidence: clamp01(energyFall * 1.8 + (current.bass - medium.bass) * 0.9),
      reason: "energy+bass fall"
    });
  }

  if (current.energy < 0.22 && medium.energy < 0.26 && medium.density < 0.24) {
    events.push({
      type: MusicalEventType.CALM_SECTION,
      time: currentTime + 4.0,
      confidence: 0.60,
      reason: "sustained calm"
    });
  }

  if (current.energy > 0.45 && near.beatStrength > 0.34 && near.density > 0.35) {
    events.push({
      type: MusicalEventType.HIGH_ENERGY,
      time: currentTime + 4.0,
      confidence: clamp01(current.energy * 0.75 + near.density * 0.45),
      reason: "current drive"
    });
  }

  events.sort((a, b) => b.confidence - a.confidence);
  return { best: events[0] || null, events };
}
