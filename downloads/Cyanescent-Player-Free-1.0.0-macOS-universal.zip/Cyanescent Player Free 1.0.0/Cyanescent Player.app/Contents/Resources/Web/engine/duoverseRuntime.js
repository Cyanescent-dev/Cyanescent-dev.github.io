import { createPresetCalibration } from "../ui/presetCalibration.js";
import {
  duoverseOverlaySource, duoverseUpdateSource,
  duoverseParticleVertexSource, duoverseParticleFragmentSource
} from "./duoverseShaders.js";

const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const PARTICLES = 4096;

export function duoverseFrameForMediaTime(time, fps, count) {
  return ((Math.floor(Math.max(0, time) * fps + 0.00001) % count) + count) % count;
}

export function createDuoverseRuntime({ getGl, program, programFrom, setAttribs, asset }) {
  const controls = { particleAmount: 0.40, flowSpeed: 0.86, trailStrength: 0.76,
    junctionActivity: 0.65, metadataGlow: 0.55, musicResponse: 0.84,
    bpmLock: true, testBPM: 0, debug: 0 };
  const calibration = createPresetCalibration({
    presetId: 391, presetName: "HD Duoverse", controls, buildPanel: makePanel,
    clearPanel: () => { panel = null; }
  });
  let active = false, token = 0, video = null, videoCallback = 0;
  let presentedTime = NaN, presentedFrames = 0, callbackSkips = 0, lastPresented = NaN;
  let videoFrame = -1, lastFrame = -1, loops = 0, videoReady = false;
  let loopTrial = false, loopTrialSeeked = false;
  let lastAt = 0, targetRate = 1, tempoBPM = 0, tempoAbsent = 0, playingPending = false;
  let overlayProgram = null, particleProgram = null, updateProgram = null, transformFeedback = null;
  let stateBuffers = [], updateVaos = [], drawVaos = [], stateRead = 0;
  let colorTexture = null, colorCanvas = null, colorContext = null, lastColorAt = 0;
  let surfaceTexture = null, flowTexture = null, loadedFrame = -1;
  let cache = new Map(), panel = null;
  let loadErrors = 0, fieldMisses = 0, uploadMax = 0, gpuUpdates = 0, maxKick = 0;
  let smoothEnergy = 0.2, smoothBass = 0.1, smoothMids = 0.1, smoothHighs = 0.1;
  let kickPrevious = 0, kickImpulse = 0, lastKickAt = -Infinity, junctionPulse = 0;
  let lowSeconds = 0, reverse = 0, recovery = 0, breath = 0, phraseAt = -Infinity;
  let reportAt = 0, drawCount = 0, cpuUpload = 0, cpuUpdate = 0, cpuDraw = 0;
  const diagnosticStates = new Float32Array(PARTICLES * 8);
  let gpuTimer = null, gpuQueries = [];
  const gpuStats = { updateMs: 0, updateCount: 0, drawMs: 0, drawCount: 0 };

  function beginGpu(gl, stage) {
    if (!gpuTimer) return null;
    try {
      const query = gl.createQuery();
      gl.beginQuery(gpuTimer.TIME_ELAPSED_EXT, query);
      return { query, stage };
    } catch { gpuTimer = null; return null; }
  }
  function endGpu(gl, item) {
    if (!item) return;
    gl.endQuery(gpuTimer.TIME_ELAPSED_EXT);
    gpuQueries.push(item);
    if (gpuQueries.length > 48) {
      const stale = gpuQueries.shift();
      gl.deleteQuery(stale.query);
    }
  }
  function pollGpu(gl) {
    if (!gpuTimer || !gpuQueries.length) return;
    if (gl.getParameter(gpuTimer.GPU_DISJOINT_EXT)) {
      for (const item of gpuQueries) gl.deleteQuery(item.query);
      gpuQueries = [];
      return;
    }
    for (let index = gpuQueries.length - 1; index >= 0; index--) {
      const item = gpuQueries[index];
      if (!gl.getQueryParameter(item.query, gl.QUERY_RESULT_AVAILABLE)) continue;
      const milliseconds = gl.getQueryParameter(item.query, gl.QUERY_RESULT) / 1e6;
      gpuStats[`${item.stage}Ms`] += milliseconds;
      gpuStats[`${item.stage}Count`] += 1;
      gl.deleteQuery(item.query);
      gpuQueries.splice(index, 1);
    }
  }
  const locations = new WeakMap();

  function loc(gl, shader, name) {
    let map = locations.get(shader);
    if (!map) { map = new Map(); locations.set(shader, map); }
    if (!map.has(name)) map.set(name, gl.getUniformLocation(shader, name));
    return map.get(name);
  }
  function uniform(gl, shader, name, value) {
    const place = loc(gl, shader, name);
    if (place !== null) gl.uniform1f(place, value);
  }
  function sample(gl, shader, name, slot, texture) {
    gl.activeTexture(gl.TEXTURE0 + slot);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(loc(gl, shader, name), slot);
  }
  function makeTexture(gl, width, height) {
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    return texture;
  }
  function makeUpdateProgram(gl) {
    const vertex = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vertex, duoverseUpdateSource);
    gl.compileShader(vertex);
    if (!gl.getShaderParameter(vertex, gl.COMPILE_STATUS)) throw new Error(`Duoverse update vertex: ${gl.getShaderInfoLog(vertex)}`);
    const fragment = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fragment, "#version 300 es\nprecision highp float; out vec4 color; void main() { color=vec4(0); }");
    gl.compileShader(fragment);
    if (!gl.getShaderParameter(fragment, gl.COMPILE_STATUS)) throw new Error(`Duoverse update fragment: ${gl.getShaderInfoLog(fragment)}`);
    const result = gl.createProgram();
    gl.attachShader(result, vertex); gl.attachShader(result, fragment);
    gl.bindAttribLocation(result, 0, "aState0");
    gl.bindAttribLocation(result, 1, "aState1");
    gl.transformFeedbackVaryings(result, ["vState0", "vState1"], gl.INTERLEAVED_ATTRIBS);
    gl.linkProgram(result);
    gl.deleteShader(vertex); gl.deleteShader(fragment);
    if (!gl.getProgramParameter(result, gl.LINK_STATUS)) {
      const reason = gl.getProgramInfoLog(result); gl.deleteProgram(result);
      throw new Error(`Duoverse update link: ${reason}`);
    }
    return result;
  }
  function makePanel() {
    panel = document.createElement("details");
    panel.className = "forge-hybrid-controls";
    panel.innerHTML = `<summary>Duoverse controls</summary>
      <label>Particles <input type="range" data-key="particleAmount" min="0" max="1" step="0.01"></label>
      <label>Flow speed <input type="range" data-key="flowSpeed" min="0" max="1.5" step="0.01"></label>
      <label>Trails <input type="range" data-key="trailStrength" min="0" max="1.5" step="0.01"></label>
      <label>Junctions <input type="range" data-key="junctionActivity" min="0" max="1.5" step="0.01"></label>
      <label>Metadata glow <input type="range" data-key="metadataGlow" min="0" max="1.5" step="0.01"></label>
      <label>Music response <input type="range" data-key="musicResponse" min="0" max="1.5" step="0.01"></label>
      <label>BPM lock <input type="checkbox" data-key="bpmLock"></label>
      <label>Test BPM <select data-key="testBPM"><option value="0">Track</option><option value="140">140</option><option value="145">145</option><option value="150">150</option></select></label>
      <label>Field view <select data-key="debug"><option value="0">Beauty</option><option value="8">Packets only</option><option value="7">Alignment</option><option value="1">Proximity</option><option value="2">Generation</option><option value="3">Glass / metal</option><option value="4">Flow</option><option value="5">Junctions</option><option value="6">Confidence</option></select></label>`;
    for (const input of panel.querySelectorAll("[data-key]")) {
      const key = input.dataset.key;
      if (input.type === "checkbox") input.checked = controls[key];
      else input.value = String(controls[key]);
      input.addEventListener("input", () => { controls[key] = input.type === "checkbox" ? input.checked : Number(input.value); });
    }
    document.body.appendChild(panel);
    return panel;
  }
  function source(kind, frame) {
    return `${asset.assetRoot}/${kind === "surface" ? asset.surfacePattern : asset.flowPattern}${String(frame).padStart(6, "0")}.webp`;
  }
  function request(frame) {
    frame = ((frame % asset.frameCount) + asset.frameCount) % asset.frameCount;
    if (cache.has(frame)) return;
    const entry = { frame, surface: null, flow: null, ready: false, failed: false };
    cache.set(frame, entry);
    const currentToken = token;
    for (const kind of ["surface", "flow"]) {
      const image = new Image();
      image.onload = () => {
        if (!active || currentToken !== token) return;
        if (image.naturalWidth !== asset.fieldWidth || image.naturalHeight !== asset.fieldHeight) {
          entry.failed = true; loadErrors += 1; return;
        }
        entry[kind] = image;
        entry.ready = Boolean(entry.surface && entry.flow);
      };
      image.onerror = () => { if (active && currentToken === token) { entry.failed = true; loadErrors += 1; } };
      image.src = source(kind, frame);
    }
  }
  function prefetch(frame) {
    for (let offset = -1; offset <= 4; offset++) request(frame + offset);
    for (const [index, entry] of cache) {
      const ahead = (index - frame + asset.frameCount) % asset.frameCount;
      const behind = (frame - index + asset.frameCount) % asset.frameCount;
      if (ahead > 5 && behind > 2) {
        for (const image of [entry.surface, entry.flow]) if (image) { image.onload = null; image.onerror = null; }
        cache.delete(index);
      }
    }
  }
  function upload(frame) {
    if (loadedFrame === frame) return true;
    const entry = cache.get(frame);
    if (!entry?.ready) { fieldMisses += 1; return false; }
    const gl = getGl(), started = performance.now();
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE);
    for (const [image, texture] of [[entry.surface, surfaceTexture], [entry.flow, flowTexture]]) {
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, image);
    }
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    loadedFrame = frame;
    const cost = performance.now() - started;
    cpuUpload += cost; uploadMax = Math.max(uploadMax, cost);
    return true;
  }
  function start() {
    if (active) return;
    active = true; token += 1;
    presentedTime = NaN; lastPresented = NaN; presentedFrames = callbackSkips = 0;
    videoFrame = lastFrame = loadedFrame = -1; loops = 0; lastAt = 0;
    cache = new Map(); loadErrors = fieldMisses = uploadMax = gpuUpdates = 0;
    drawCount = cpuUpload = cpuUpdate = cpuDraw = 0;
    video = document.createElement("video");
    video.muted = true; video.playsInline = true; video.loop = true; video.preload = "auto";
    video.className = "forge-hybrid-video";
    document.body.appendChild(video);
    window.__duoverseVideo = video;
    video.src = encodeURI(`${asset.assetRoot}/${asset.video}`);
    video.load();
    if (video.requestVideoFrameCallback) {
      const generation = token;
      const callback = (_timestamp, info) => {
        if (!active || generation !== token || !video) return;
        if (Number.isFinite(info.mediaTime)) {
          if (Number.isFinite(lastPresented) && info.mediaTime > lastPresented + 1.5 / asset.fps) callbackSkips += 1;
          lastPresented = info.mediaTime;
          presentedTime = info.mediaTime;
          presentedFrames += 1;
        }
        videoCallback = video.requestVideoFrameCallback(callback);
      };
      videoCallback = video.requestVideoFrameCallback(callback);
    }
    const gl = getGl();
    gpuTimer = document.body.classList.contains("preset-trial-role")
      ? gl.getExtension("EXT_disjoint_timer_query_webgl2") : null;
    gpuQueries = [];
    gpuStats.updateMs = gpuStats.updateCount = gpuStats.drawMs = gpuStats.drawCount = 0;
    overlayProgram = program(duoverseOverlaySource);
    particleProgram = programFrom(duoverseParticleVertexSource, duoverseParticleFragmentSource,
      [[0, "aState0"], [1, "aState1"]]);
    updateProgram = makeUpdateProgram(gl);
    transformFeedback = gl.createTransformFeedback();
    surfaceTexture = makeTexture(gl, asset.fieldWidth, asset.fieldHeight);
    flowTexture = makeTexture(gl, asset.fieldWidth, asset.fieldHeight);
    colorTexture = makeTexture(gl, 320, 180);
    colorCanvas = document.createElement("canvas"); colorCanvas.width = 320; colorCanvas.height = 180;
    colorContext = colorCanvas.getContext("2d", { alpha: false });
    const initial = new Float32Array(PARTICLES * 8);
    for (let i = 0; i < PARTICLES; i++) initial[i * 8 + 2] = -1;
    for (let i = 0; i < 2; i++) {
      const buffer = gl.createBuffer(); stateBuffers.push(buffer);
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, i === 0 ? initial : initial.byteLength, gl.DYNAMIC_COPY);
      const vao = gl.createVertexArray(); updateVaos.push(vao); drawVaos.push(vao);
      gl.bindVertexArray(vao);
      gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 32, 0);
      gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 32, 16);
    }
    gl.bindVertexArray(null);
    stateRead = 0;
    window.__duoverseControls = controls;
    calibration.start();
    const fixture = new URLSearchParams(window.location.search).get("fixture");
    loopTrial = fixture === "duo-loop";
    loopTrialSeeked = false;
    if (fixture === "duo-align") controls.debug = 7;
    if (fixture === "duo-generation") controls.debug = 2;
    if (fixture === "duo-material") controls.debug = 3;
    if (fixture === "duo-flow") controls.debug = 4;
    if (fixture === "duo-junction") controls.debug = 5;
    if (fixture === "duo-confidence") controls.debug = 6;
    if (fixture === "duo-particles") controls.debug = 8;
    if (fixture === "duo-off") controls.particleAmount = controls.metadataGlow = 0;
    request(0); request(1); request(2);
  }
  function stop() {
    if (!active) return;
    active = false; token += 1;
    if (video) {
      if (videoCallback && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(videoCallback);
      video.pause(); video.removeAttribute("src"); video.load(); video.remove(); video = null;
    }
    window.__duoverseVideo = null; window.__duoverseDiagnostics = null;
    for (const entry of cache.values()) for (const image of [entry.surface, entry.flow]) {
      if (image) { image.onload = null; image.onerror = null; image.src = ""; }
    }
    cache.clear();
    const gl = getGl();
    for (const texture of [surfaceTexture, flowTexture, colorTexture]) if (texture) gl.deleteTexture(texture);
    for (const buffer of stateBuffers) gl.deleteBuffer(buffer);
    for (const vao of updateVaos) gl.deleteVertexArray(vao);
    if (transformFeedback) gl.deleteTransformFeedback(transformFeedback);
    for (const item of gpuQueries) gl.deleteQuery(item.query);
    gpuQueries = []; gpuTimer = null;
    for (const shader of [overlayProgram, particleProgram, updateProgram]) if (shader) gl.deleteProgram(shader);
    stateBuffers = []; updateVaos = []; drawVaos = [];
    surfaceTexture = flowTexture = colorTexture = null;
    transformFeedback = overlayProgram = particleProgram = updateProgram = null;
    colorCanvas = colorContext = null; calibration.stop(); panel = null;
    window.__duoverseControls = null;
  }
  function updateTempo(tempo, dt) {
    const source = controls.testBPM > 0 ? { bpm: controls.testBPM, confidence: 1 } : tempo || {};
    const bpm = Number(source.bpm) || 0, confidence = Number(source.confidence ?? 1);
    if (!controls.bpmLock) { targetRate = 1; tempoBPM = 0; tempoAbsent = 0; }
    else if (bpm >= 70 && bpm <= 220 && confidence >= 0.35) {
      tempoAbsent = 0;
      if (!tempoBPM || Math.abs(bpm - tempoBPM) >= 0.8) {
        tempoBPM = bpm;
        targetRate = clamp(bpm / asset.authoredBPM, 0.65, 1.5);
      }
    } else if ((tempoAbsent += dt) > 5) { targetRate = 1; tempoBPM = 0; }
    if (video) {
      const next = video.playbackRate + clamp(targetRate - video.playbackRate, -dt * 0.14, dt * 0.14);
      if (Math.abs(next - video.playbackRate) > 0.0002) video.playbackRate = next;
    }
  }
  function animateAudio(dt, audio, smooth, music, now) {
    const response = controls.musicResponse;
    const rise = 1 - Math.exp(-dt * 7), slow = 1 - Math.exp(-dt * 1.1);
    const bass = clamp(Number(smooth?.bass) || 0, 0, 1);
    const mids = clamp(Number(smooth?.mids) || 0, 0, 1);
    const highs = clamp(Number(smooth?.highs) || 0, 0, 1);
    const energy = clamp(Number(audio?.globalEnergy ?? music?.adaptiveIntensity ?? 0.2), 0, 1);
    smoothBass += (bass - smoothBass) * rise;
    smoothMids += (mids - smoothMids) * rise;
    smoothHighs += (highs - smoothHighs) * rise;
    smoothEnergy += (energy - smoothEnergy) * slow;
    const kick = clamp(Number(audio?.kickPulse) || 0, 0, 1);
    maxKick = Math.max(maxKick, kick);
    if (kick > 0.52 && kickPrevious <= 0.52 && now - lastKickAt > 250) {
      kickImpulse = Math.max(kickImpulse, kick * response);
      junctionPulse = Math.max(junctionPulse, 0.25 + kick * 0.5);
      lastKickAt = now;
    }
    kickPrevious = kick;
    kickImpulse *= Math.exp(-dt * 3.3);
    junctionPulse *= Math.exp(-dt * 1.6);
    if ((music?.sectionChange || 0) > 0.6 && now - phraseAt > 2500) {
      phraseAt = now;
      junctionPulse = Math.max(junctionPulse, 0.75);
    }
    lowSeconds = energy < 0.22 ? lowSeconds + dt : Math.max(0, lowSeconds - dt * 2.5);
    const nextReverse = lowSeconds > 3.5 ? 0.36 : 0;
    if (reverse > 0.18 && nextReverse === 0 && energy > 0.42) recovery = 1;
    reverse += (nextReverse - reverse) * (1 - Math.exp(-dt * 0.75));
    recovery *= Math.exp(-dt * 1.1);
    breath += ((0.3 + smoothEnergy * 0.7) - breath) * (1 - Math.exp(-dt * 0.38));
  }
  function drawFields(gl, shader) {
    sample(gl, shader, "uSurface", 1, surfaceTexture);
    sample(gl, shader, "uFlow", 2, flowTexture);
  }
  function simulate(gl, dt, now) {
    const started = performance.now();
    const gpuQuery = beginGpu(gl, "update");
    const output = 1 - stateRead;
    gl.useProgram(updateProgram);
    gl.bindVertexArray(updateVaos[stateRead]);
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, transformFeedback);
    gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, stateBuffers[output]);
    sample(gl, updateProgram, "uColor", 0, colorTexture);
    drawFields(gl, updateProgram);
    uniform(gl, updateProgram, "uDelta", dt);
    uniform(gl, updateProgram, "uClock", now / 1000);
    uniform(gl, updateProgram, "uAmount", controls.particleAmount);
    uniform(gl, updateProgram, "uSpeed", controls.flowSpeed);
    uniform(gl, updateProgram, "uBass", smoothBass);
    uniform(gl, updateProgram, "uMids", smoothMids);
    uniform(gl, updateProgram, "uHighs", smoothHighs);
    uniform(gl, updateProgram, "uEnergy", smoothEnergy);
    uniform(gl, updateProgram, "uKick", kickImpulse);
    uniform(gl, updateProgram, "uReverse", reverse);
    uniform(gl, updateProgram, "uRecovery", recovery);
    gl.enable(gl.RASTERIZER_DISCARD);
    gl.beginTransformFeedback(gl.POINTS);
    gl.drawArrays(gl.POINTS, 0, PARTICLES);
    gl.endTransformFeedback();
    gl.disable(gl.RASTERIZER_DISCARD);
    gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, null);
    gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, null);
    gl.bindVertexArray(null);
    endGpu(gl, gpuQuery);
    stateRead = output;
    gpuUpdates += 1;
    cpuUpdate += performance.now() - started;
  }
  function render({ target, width, height, now, tempo, playing = true, music, audio, smooth }) {
    if (!active) start();
    const gl = getGl();
    const dt = lastAt ? clamp((now - lastAt) / 1000, 0, 0.05) : 1 / 60;
    lastAt = now;
    videoReady = video.readyState >= 2 && video.videoWidth === asset.videoWidth && video.videoHeight === asset.videoHeight;
    if (videoReady && loopTrial && !loopTrialSeeked) {
      // Trial-only seek to exercise the actual seamless MP4 loop without a
      // minute-long test. Production sync never seeks to chase the beat.
      video.currentTime = Math.max(0, asset.frameCount / asset.fps - 2.2);
      loopTrialSeeked = true;
    }
    video.style.display = document.body.classList.contains("exporting-video") ? "none" : "block";
    updateTempo(tempo, dt);
    if (!playing && !video.paused) video.pause();
    if (playing && videoReady && video.paused && !playingPending) {
      playingPending = true;
      video.play().catch((error) => { if (loadErrors++ < 3) console.warn("Duoverse video:", error); })
        .finally(() => { playingPending = false; });
    }
    // requestVideoFrameCallback mediaTime describes the presented frame. The
    // currentTime fallback is used only on WebKit versions without callbacks.
    const mediaTime = Number.isFinite(presentedTime) ? presentedTime : (video.currentTime || 0);
    videoFrame = duoverseFrameForMediaTime(mediaTime, asset.fps, asset.frameCount);
    if (lastFrame >= asset.frameCount - asset.fps && videoFrame < asset.fps) loops += 1;
    lastFrame = videoFrame;
    prefetch(videoFrame);
    const fieldReady = upload(videoFrame);
    if (videoReady && now - lastColorAt > 240) {
      try {
        colorContext.drawImage(video, 0, 0, 320, 180);
        gl.bindTexture(gl.TEXTURE_2D, colorTexture);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, colorCanvas);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
        lastColorAt = now;
      } catch (error) { if (loadErrors++ < 3) console.warn("Duoverse color sample:", error); }
    }
    animateAudio(dt, audio, smooth, music, now);
    if (fieldReady && playing && dt > 0) simulate(gl, dt, now);
    const drawStart = performance.now();
    const gpuQuery = beginGpu(gl, "draw");
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
    gl.viewport(0, 0, width, height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    if (fieldReady) {
      setAttribs(overlayProgram);
      sample(gl, overlayProgram, "uColor", 0, colorTexture);
      drawFields(gl, overlayProgram);
      uniform(gl, overlayProgram, "uCanvasAspect", width / Math.max(1, height));
      uniform(gl, overlayProgram, "uVideoAspect", asset.videoWidth / asset.videoHeight);
      uniform(gl, overlayProgram, "uIntensity", controls.musicResponse);
      uniform(gl, overlayProgram, "uGlow", controls.metadataGlow);
      uniform(gl, overlayProgram, "uEnergy", smoothEnergy);
      uniform(gl, overlayProgram, "uBass", smoothBass);
      uniform(gl, overlayProgram, "uMids", smoothMids);
      uniform(gl, overlayProgram, "uHighs", smoothHighs);
      uniform(gl, overlayProgram, "uBreath", breath);
      uniform(gl, overlayProgram, "uJunctionPulse", junctionPulse * controls.junctionActivity);
      gl.uniform1i(loc(gl, overlayProgram, "uDebug"), controls.debug);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      if ((controls.debug === 0 || controls.debug === 8) && controls.particleAmount > 0 && videoReady) {
        gl.useProgram(particleProgram);
        gl.bindVertexArray(drawVaos[stateRead]);
        sample(gl, particleProgram, "uColor", 0, colorTexture);
        drawFields(gl, particleProgram);
        gl.uniform1i(loc(gl, particleProgram, "uParticleDebug"), controls.debug === 8 ? 1 : 0);
        uniform(gl, particleProgram, "uCanvasAspect", width / Math.max(1, height));
        uniform(gl, particleProgram, "uVideoAspect", asset.videoWidth / asset.videoHeight);
        uniform(gl, particleProgram, "uScale", Math.max(0.7, height / 720));
        uniform(gl, particleProgram, "uIntensity", controls.musicResponse);
        uniform(gl, particleProgram, "uTrail", controls.trailStrength);
        uniform(gl, particleProgram, "uBass", smoothBass);
        uniform(gl, particleProgram, "uMids", smoothMids);
        uniform(gl, particleProgram, "uHighs", smoothHighs);
        uniform(gl, particleProgram, "uKick", kickImpulse);
        uniform(gl, particleProgram, "uJunctionPulse", junctionPulse * controls.junctionActivity);
        uniform(gl, particleProgram, "uBreath", breath);
        gl.enable(gl.BLEND);
        gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE, gl.ONE, gl.ONE);
        gl.drawArrays(gl.POINTS, 0, PARTICLES);
        gl.disable(gl.BLEND);
        gl.bindVertexArray(null);
      }
    }
    cpuDraw += performance.now() - drawStart;
    endGpu(gl, gpuQuery);
    pollGpu(gl);
    drawCount += 1;
    if (panel && now - reportAt > 1000) panel.querySelector("summary").textContent =
      `Duoverse · ${video.playbackRate.toFixed(3)}× · frame ${fieldReady ? videoFrame : "loading"}`;
    if (now - reportAt > (document.body.classList.contains("preset-trial-role") ? 2000 : 5000)) {
      const quality = video.getVideoPlaybackQuality?.();
      let liveParticles = null;
      if (document.body.classList.contains("preset-trial-role")) {
        gl.bindBuffer(gl.COPY_READ_BUFFER, stateBuffers[stateRead]);
        gl.getBufferSubData(gl.COPY_READ_BUFFER, 0, diagnosticStates);
        liveParticles = 0;
        for (let index = 0; index < PARTICLES; index++) {
          const age = diagnosticStates[index * 8 + 2], lifetime = diagnosticStates[index * 8 + 3];
          if (age >= 0 && age < lifetime) liveParticles += 1;
        }
        gl.bindBuffer(gl.COPY_READ_BUFFER, null);
      }
      window.__duoverseDiagnostics = {
        videoTime: mediaTime, frame: videoFrame, loadedFrame, fieldReady,
        fps: asset.fps, frameCount: asset.frameCount, loops,
        playbackRate: video.playbackRate, targetRate, videoReady,
        presentedFrames, callbackSkips, loadErrors, fieldMisses, uploadMaxMs: uploadMax,
        particleCapacity: PARTICLES, liveParticles, gpuUpdates, reverse, kickImpulse, maxKick,
        droppedVideoFrames: quality?.droppedVideoFrames ?? 0,
        totalVideoFrames: quality?.totalVideoFrames ?? 0,
        cacheFrames: cache.size, estimatedDecodedCacheMB: cache.size * asset.fieldWidth * asset.fieldHeight * 8 / 1048576,
        cpuUploadMs: cpuUpload / Math.max(1, drawCount), cpuUpdateSubmitMs: cpuUpdate / Math.max(1, drawCount),
        cpuDrawSubmitMs: cpuDraw / Math.max(1, drawCount),
        gpuTimerSupported: Boolean(gpuTimer),
        gpuUpdateMs: gpuStats.updateCount ? gpuStats.updateMs / gpuStats.updateCount : null,
        gpuDrawMs: gpuStats.drawCount ? gpuStats.drawMs / gpuStats.drawCount : null
      };
      if (document.body.classList.contains("preset-trial-role")) window.webkit?.messageHandlers?.nativeApp?.postMessage({
        command: "logConsole", type: "info", text: `[Duoverse] ${JSON.stringify(window.__duoverseDiagnostics)}`
      });
      reportAt = now;
    }
  }
  return { render, stop, controls, isActive: () => active };
}
