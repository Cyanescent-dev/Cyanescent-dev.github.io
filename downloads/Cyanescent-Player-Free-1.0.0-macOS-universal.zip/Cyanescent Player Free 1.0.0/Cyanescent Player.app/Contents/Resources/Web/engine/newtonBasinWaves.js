// Newton Basin Descent: ripple waves through the iteration field.
//
// The smooth iteration count A of the Newton / hybrid iteration is what the Forge relief is built
// on: its integer contours are the ripple grooves in the basins, and the attractor wells (the
// eyes and craters) are where A is lowest. A wave is a front at a given value of A:
//
//   front(t) = WAVE_START + speed * age          (counts; speed = countsPerBeat * beats/s)
//
// Every surface point whose A equals the front lights up, so a wave is born inside every
// attractor well at once and expands outward through the basins along the render's own grooves,
// slowing and compressing where the contours crowd towards the fractal seams, where it breaks
// (and throws glints). Because A is a property of the landscape, a wave stays locked to the
// terrain however the camera moves.
//
// Kinds:
//   kick   one per kick; the bar decides which basin carries it (see regionGains)
//   roll   short, fast subdivisions during a build-up
//   tide   slow, broad swells once a bar while the kick is absent (breakdowns)
//   drop   one large, slow shockwave through everything when the drop lands
//
// The shader mirrors `waveAmplitude` and `crestProfile`.

const smoothstep = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

export const WAVE_SLOTS = 12;
export const WAVE_START = -0.8;          // counts: fronts are born just inside the attractor wells
export const WAVE_BASE_WIDTH_PX = 2.4;   // crest half-width at 720p, before the per-kind scale

export const WAVE_KINDS = Object.freeze({
  kick: Object.freeze({ code: 0, countsPerBeat: 6.5, width: 1.0, tail: 2.2, fadeStart: 11, fadeEnd: 24, lens: 1.0 }),
  roll: Object.freeze({ code: 1, countsPerBeat: 9.0, width: 0.7, tail: 1.2, fadeStart: 7, fadeEnd: 15, lens: 0.35 }),
  tide: Object.freeze({ code: 2, countsPerBeat: 2.2, width: 2.4, tail: 4.5, fadeStart: 8, fadeEnd: 18, lens: 0.25 }),
  drop: Object.freeze({ code: 3, countsPerBeat: 4.2, width: 2.6, tail: 5.0, fadeStart: 18, fadeEnd: 40, lens: 2.4 })
});

// Which basins carry a wave: [escaped, root 0, root 1, root 2]. The downbeat moves everything;
// beats 2, 3 and 4 of the bar each accent one of the three Newton basins in turn (warm gold,
// turquoise, violet), with the escape region following at a lower level. So a 4/4 groove is seen
// as a rotating chase through the three roots of the polynomial, resolving on the one.
export function regionGains(kind, beatInBar) {
  if (kind === "kick" && beatInBar >= 1 && beatInBar <= 3) {
    const gains = [0.6, 0.3, 0.3, 0.3];
    gains[beatInBar] = 1.0;
    return gains;
  }
  if (kind === "roll") return [0.75, 0.75, 0.75, 0.75];
  return [1, 1, 1, 1];
}

export const waveFront = (wave) => WAVE_START + wave.speed * wave.age;

// Envelope over the wave's journey: it swells as it leaves the wells and fades as it reaches the
// dense fractal seams, where it has broken.
export function waveAmplitude(wave) {
  const def = WAVE_KINDS[wave.kind];
  const front = waveFront(wave);
  return wave.strength * smoothstep(WAVE_START, WAVE_START + 1.2, front) * (1 - smoothstep(def.fadeStart, def.fadeEnd, front));
}

// Brightness of a crest `dPx` screen pixels from the front (negative = already passed).
export function crestProfile(dPx, widthPx) {
  const x = dPx / Math.max(1e-3, widthPx);
  return Math.exp(-x * x);
}

export function createWavePool(slots = WAVE_SLOTS) {
  const pool = Array.from({ length: slots }, () => ({ active: false, kind: "kick", age: 0, speed: 0, strength: 0, widthPx: 0, tail: 0, lens: 0, gains: [1, 1, 1, 1], serial: 0 }));
  let serial = 0;

  // desc: { kind, strength, beatInBar }; env: { beatsPerSecond, bassDrive }
  function spawn(desc, env = {}) {
    const def = WAVE_KINDS[desc.kind];
    if (!def || !(desc.strength > 0.01)) return null;
    const bps = Math.min(4, Math.max(1, Number(env.beatsPerSecond) || 145 / 60));
    let slot = pool.find((wave) => !wave.active);
    if (!slot) slot = pool.reduce((oldest, wave) => (wave.serial < oldest.serial ? wave : oldest), pool[0]);
    serial += 1;
    Object.assign(slot, {
      active: true, kind: desc.kind, age: 0, serial,
      speed: def.countsPerBeat * bps,
      strength: Math.min(2, desc.strength),
      widthPx: WAVE_BASE_WIDTH_PX * def.width * (0.8 + 0.6 * Math.min(1, Math.max(0, env.bassDrive || 0))),
      tail: def.tail,
      lens: def.lens,
      gains: regionGains(desc.kind, desc.beatInBar ?? -1)
    });
    return slot;
  }

  function step(dt) {
    for (const wave of pool) {
      if (!wave.active) continue;
      wave.age += dt;
      if (waveFront(wave) > WAVE_KINDS[wave.kind].fadeEnd || wave.age > 8) wave.active = false;
    }
  }

  // A: front (counts), amplitude, crest half-width (px at 720p), wake tail (counts)
  // B: region gains (escaped, root 0, root 1, root 2)
  // C: lens strength, kind code
  function writeUniforms(A, B, C) {
    A.fill(0); B.fill(0); C.fill(0);
    pool.forEach((wave, i) => {
      if (!wave.active) return;
      const amp = waveAmplitude(wave);
      A[i * 4] = waveFront(wave); A[i * 4 + 1] = amp; A[i * 4 + 2] = wave.widthPx; A[i * 4 + 3] = wave.tail;
      for (let k = 0; k < 4; k += 1) B[i * 4 + k] = wave.gains[k];
      C[i * 4] = wave.lens; C[i * 4 + 1] = WAVE_KINDS[wave.kind].code;
    });
  }

  const clear = () => { for (const wave of pool) wave.active = false; };
  const activeCount = () => pool.filter((wave) => wave.active).length;
  return { slots: pool, spawn, step, writeUniforms, clear, activeCount };
}
