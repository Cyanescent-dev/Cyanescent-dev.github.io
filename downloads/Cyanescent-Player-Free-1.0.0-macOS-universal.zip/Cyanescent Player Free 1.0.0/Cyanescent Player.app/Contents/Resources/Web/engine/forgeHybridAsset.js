export const APOLLONIAN_PHYSARUM_GENESIS_ID = 390;

// Metadata belongs to the Forge asset, not the Player's global tempo system.
export const APOLLONIAN_PHYSARUM_GENESIS = Object.freeze({
  id: APOLLONIAN_PHYSARUM_GENESIS_ID,
  assetRoot: "assets/forge/apollonian-physarum-genesis",
  video: "physarum1080p.mp4",
  seed: 20260908,
  authoredBPM: 145,
  durationBeats: 200.01944444444445,
  beatsPerBar: 4,
  fps: 30,
  frameCount: 2483,
  videoWidth: 1920,
  videoHeight: 1080,
  fieldWidth: 480,
  fieldHeight: 270,
  densityPattern: "density/density_",
  flowPattern: "flow/flow_",
  fieldOrigin: "top-left",
  seamlessLoop: true
});
