/**
 * Apollonian Drift — splash screen animation for Cyanescent Player.
 *
 * Generates an Apollonian gasket (circle-packing fractal) and draws it
 * with staggered fade-in. The animation runs for ~2.5s, then stops
 * completely — no ongoing loop, zero idle GPU cost.
 */
(() => {
  'use strict';

  /* ── colour palette (matches Cyanescent brand) ────────────────────── */
  const PALETTE = [
    { r: 138, g: 244, b: 251, a: 0.85 },   // #8af4fb — bright cyan
    { r: 103, g: 208, b: 204, a: 0.72 },    // #67d0cc — teal
    { r: 125, g: 217, b: 213, a: 0.65 },    // #7dd9d5 — mid teal
    { r: 157, g: 244, b: 255, a: 0.55 },    // #9df4ff — pale cyan
    { r: 215, g: 184, b: 111, a: 0.80 },    // #d7b86f — gold (for outer)
  ];
  const GOLD = PALETTE[4];

  /* ── Descartes circle theorem ─────────────────────────────────────── */
  // A circle is stored as { x, y, r, k } where k = 1/r (curvature).
  // Negative r/k for the outer bounding circle (contains the others).

  function descartesK(k1, k2, k3) {
    // k4 = k1 + k2 + k3 + 2*sqrt(k1*k2 + k2*k3 + k1*k3)
    const sum = k1 + k2 + k3;
    const root = Math.sqrt(Math.abs(k1 * k2 + k2 * k3 + k1 * k3));
    return [sum + 2 * root, sum - 2 * root];
  }

  function descartesComplex(c1, c2, c3) {
    // Complex Descartes: z4*k4 = z1*k1 + z2*k2 + z3*k3
    //   + 2*sqrt(z1*k1*z2*k2 + z2*k2*z3*k3 + z1*k1*z3*k3)
    const k1 = c1.k, k2 = c2.k, k3 = c3.k;
    const [k4a, k4b] = descartesK(k1, k2, k3);
    const results = [];

    for (const k4 of [k4a, k4b]) {
      if (Math.abs(k4) < 1e-10) continue;
      // Weighted centre positions
      const zk1x = c1.x * k1, zk1y = c1.y * k1;
      const zk2x = c2.x * k2, zk2y = c2.y * k2;
      const zk3x = c3.x * k3, zk3y = c3.y * k3;

      // Sum
      const sx = zk1x + zk2x + zk3x;
      const sy = zk1y + zk2y + zk3y;

      // Products for sqrt term (complex multiply)
      const p12x = zk1x * zk2x - zk1y * zk2y;
      const p12y = zk1x * zk2y + zk1y * zk2x;
      const p23x = zk2x * zk3x - zk2y * zk3y;
      const p23y = zk2x * zk3y + zk2y * zk3x;
      const p13x = zk1x * zk3x - zk1y * zk3y;
      const p13y = zk1x * zk3y + zk1y * zk3x;

      const innerX = p12x + p23x + p13x;
      const innerY = p12y + p23y + p13y;

      // Complex sqrt
      const mag = Math.sqrt(innerX * innerX + innerY * innerY);
      const angle = Math.atan2(innerY, innerX);
      const sqrtMag = Math.sqrt(mag);
      const sqrtX = sqrtMag * Math.cos(angle / 2);
      const sqrtY = sqrtMag * Math.sin(angle / 2);

      // Two solutions (±sqrt)
      for (const sign of [1, -1]) {
        const nx = (sx + 2 * sign * sqrtX) / k4;
        const ny = (sy + 2 * sign * sqrtY) / k4;
        const nr = 1 / k4;
        if (Math.abs(nr) > 0.5) {
          results.push({ x: nx, y: ny, r: Math.abs(nr), k: k4 });
        }
      }
    }
    return results;
  }

  function isDuplicate(circle, existing, tolerance) {
    for (let i = 0; i < existing.length; i++) {
      const e = existing[i];
      const dx = circle.x - e.x;
      const dy = circle.y - e.y;
      if (dx * dx + dy * dy < tolerance * tolerance && Math.abs(circle.r - e.r) < tolerance) {
        return true;
      }
    }
    return false;
  }

  function generateGasket(cx, cy, outerR, maxDepth, minRadius) {
    const circles = [];
    const tol = 0.8;

    // Start with the outer circle (negative curvature) and two inner tangent circles.
    // Classic symmetric seed: three mutually tangent circles inside a bounding circle.
    const outer = { x: cx, y: cy, r: outerR, k: -1 / outerR, gen: 0 };

    // Inner seed: two circles of equal radius tangent to each other and to the outer
    const ir = outerR / 2;
    const c1 = { x: cx, y: cy - ir, r: ir, k: 1 / ir, gen: 0 };
    const c2 = { x: cx, y: cy + ir, r: ir, k: 1 / ir, gen: 0 };

    // Third circle tangent to c1, c2 and outer
    // For this symmetric seed, the third is computed via Descartes
    const seeds = descartesComplex(outer, c1, c2);
    // Pick the valid inner circle
    let c3 = null;
    for (const s of seeds) {
      if (s.r > 0 && s.r < outerR && !isDuplicate(s, [c1, c2], tol)) {
        c3 = { ...s, gen: 0 };
        break;
      }
    }
    if (!c3) {
      // Fallback: place a smaller circle
      const r3 = outerR / 3;
      c3 = { x: cx + r3, y: cy, r: r3, k: 1 / r3, gen: 0 };
    }

    circles.push(c1, c2, c3);

    // Recursive fill
    const triplets = [
      [outer, c1, c2],
      [outer, c1, c3],
      [outer, c2, c3],
      [c1, c2, c3],
    ];

    function recurse(a, b, c, depth) {
      if (depth >= maxDepth) return;
      const newCircles = descartesComplex(a, b, c);
      for (const nc of newCircles) {
        if (nc.r < minRadius || nc.r >= outerR * 0.99) continue;
        // Check it's inside the bounding circle
        const dx = nc.x - cx;
        const dy = nc.y - cy;
        if (Math.sqrt(dx * dx + dy * dy) + nc.r > outerR + tol) continue;
        if (isDuplicate(nc, circles, tol)) continue;
        nc.gen = depth + 1;
        circles.push(nc);
        // Recurse into 3 new triplets
        recurse(a, b, nc, depth + 1);
        recurse(a, c, nc, depth + 1);
        recurse(b, c, nc, depth + 1);
      }
    }

    for (const [a, b, c] of triplets) {
      recurse(a, b, c, 0);
    }

    // Add the outer bounding circle for drawing
    circles.unshift(outer);
    return circles;
  }

  /* ── drawing ──────────────────────────────────────────────────────── */

  function colourForCircle(circle, outerR) {
    // Outer bounding ring → gold; inner → teal palette by depth
    if (circle.r >= outerR * 0.98) {
      return GOLD;
    }
    const ratio = circle.r / outerR;
    if (ratio > 0.35) return PALETTE[0];      // large inner → bright cyan
    if (ratio > 0.15) return PALETTE[1];      // mid → teal
    if (ratio > 0.06) return PALETTE[2];      // small → mid teal
    return PALETTE[3];                         // tiny → pale cyan
  }

  function startApollinianSplash() {
    const canvas = document.getElementById('apollonianCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Size to fill viewport at device pixel ratio
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = window.innerWidth;
    const h = window.innerHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Generate gasket
    const cx = w / 2;
    const cy = h * 0.45;
    const outerR = Math.min(w, h) * 0.38;
    const minRadius = outerR * 0.012;
    const maxDepth = 4;

    const circles = generateGasket(cx, cy, outerR, maxDepth, minRadius);

    // Sort by generation then by radius (largest first) for draw order
    circles.sort((a, b) => {
      if (a.gen !== b.gen) return a.gen - b.gen;
      return b.r - a.r;
    });

    // Stagger timing: each circle fades in over 400ms, staggered by 35ms
    const staggerMs = 35;
    const fadeDurationMs = 500;
    const totalAnimMs = circles.length * staggerMs + fadeDurationMs + 200;
    const startTime = performance.now();

    let animId = 0;
    let done = false;

    function draw(now) {
      const elapsed = now - startTime;
      ctx.clearRect(0, 0, w, h);

      let allDone = true;

      for (let i = 0; i < circles.length; i++) {
        const c = circles[i];
        const circleStart = i * staggerMs;
        const t = Math.max(0, elapsed - circleStart);
        if (t <= 0) { allDone = false; continue; }

        const progress = Math.min(1, t / fadeDurationMs);
        if (progress < 1) allDone = false;

        // Ease-out cubic
        const ease = 1 - Math.pow(1 - progress, 3);
        const scale = 0.5 + 0.5 * ease;
        const alpha = ease;

        const col = colourForCircle(c, outerR);
        const isOuter = c.r >= outerR * 0.98;
        const lineW = isOuter ? 1.5 : Math.max(0.5, Math.min(1.2, c.r * 0.06));

        ctx.save();
        ctx.globalAlpha = alpha * col.a;
        ctx.strokeStyle = `rgb(${col.r}, ${col.g}, ${col.b})`;
        ctx.lineWidth = lineW;

        // Glow
        if (c.r > outerR * 0.05) {
          ctx.shadowColor = `rgba(${col.r}, ${col.g}, ${col.b}, ${0.35 * alpha})`;
          ctx.shadowBlur = isOuter ? 18 : Math.min(14, c.r * 0.15);
        }

        ctx.beginPath();
        const drawR = isOuter ? c.r : c.r * scale;
        ctx.arc(c.x, c.y, Math.max(0.5, drawR), 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      if (!allDone && !done) {
        animId = requestAnimationFrame(draw);
      } else {
        done = true;
        // One final settled frame
        drawSettled();
      }
    }

    function drawSettled() {
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < circles.length; i++) {
        const c = circles[i];
        const col = colourForCircle(c, outerR);
        const isOuter = c.r >= outerR * 0.98;
        const lineW = isOuter ? 1.5 : Math.max(0.5, Math.min(1.2, c.r * 0.06));

        ctx.save();
        ctx.globalAlpha = col.a;
        ctx.strokeStyle = `rgb(${col.r}, ${col.g}, ${col.b})`;
        ctx.lineWidth = lineW;

        if (c.r > outerR * 0.05) {
          ctx.shadowColor = `rgba(${col.r}, ${col.g}, ${col.b}, 0.35)`;
          ctx.shadowBlur = isOuter ? 18 : Math.min(14, c.r * 0.15);
        }

        ctx.beginPath();
        ctx.arc(c.x, c.y, Math.max(0.5, c.r), 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    animId = requestAnimationFrame(draw);

    // Expose cleanup for when splash hides
    window.__apollonianCleanup = () => {
      done = true;
      if (animId) cancelAnimationFrame(animId);
      const el = document.getElementById('apollonianCanvas');
      if (el) el.remove();
      delete window.__apollonianCleanup;
    };

    // Safety: stop after max time even if something goes wrong
    setTimeout(() => {
      done = true;
    }, totalAnimMs + 500);
  }

  // Auto-start immediately
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApollinianSplash);
  } else {
    startApollinianSplash();
  }
})();
