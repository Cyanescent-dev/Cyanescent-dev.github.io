import { capabilityEnabled, enforceTransitionCapabilities, enforceRuntimeOptions } from "../config/runtimeCapabilities.js";
import { clamp01, fractJs, smoothstepJs } from "../utils/math.js";
import { createDiversityCycle } from "../engine/diversityCycle.js";

function seededRandom(seed) {
  let state = fractJs(Math.sin(Number(seed) * 91.719 + 0.137) * 104729.37);
  return () => {
    state = fractJs(Math.sin(state * 1297.13 + 17.77) * 43758.5453);
    return state;
  };
}

function waitForVideoEvent(video, eventNames, timeoutMs = 4000) {
  return new Promise((resolve) => {
    let done = false;
    const cleanup = () => {
      for (const name of eventNames) video.removeEventListener(name, onEvent);
      window.clearTimeout(timer);
    };
    const finish = () => {
      if (done) return;
      done = true;
      cleanup();
      resolve();
    };
    const onEvent = () => finish();
    for (const name of eventNames) video.addEventListener(name, onEvent, { once: true });
    const timer = window.setTimeout(finish, timeoutMs);
  });
}

async function waitForSeekToSettle(video, target, timeoutMs = 3500) {
  const started = performance.now();
  while (performance.now() - started < timeoutMs) {
    if (!video.seeking && video.readyState >= 2 && Math.abs((video.currentTime || 0) - target) < 0.08) {
      return;
    }
    await new Promise((resolve) => window.setTimeout(resolve, 12));
  }
}

function transitionOpacityForTime(localTime, duration, options = {}) {
  const p = clamp01(localTime / Math.max(0.001, duration));
  const fadeSeconds = Math.max(0.25, (Number(options.videoTransitionFadeMs) || 4300) / 1000);
  const fadeRatio = Math.max(0.05, Math.min(0.45, fadeSeconds / Math.max(0.001, duration)));
  const fadeIn = smoothstepJs(0, fadeRatio, p);
  const fadeOut = 1 - smoothstepJs(1 - fadeRatio, 1, p);
  return clamp01(fadeIn * fadeOut);
}

function drawVideoCover(ctx, video, width, height, alpha) {
  if (!video.videoWidth || !video.videoHeight || alpha <= 0) return;
  const targetAspect = width / Math.max(1, height);
  const videoAspect = video.videoWidth / Math.max(1, video.videoHeight);
  let drawWidth = width;
  let drawHeight = height;
  let drawX = 0;
  let drawY = 0;
  if (videoAspect > targetAspect) {
    drawHeight = height;
    drawWidth = height * videoAspect;
    drawX = (width - drawWidth) * 0.5;
  } else {
    drawWidth = width;
    drawHeight = width / videoAspect;
    drawY = (height - drawHeight) * 0.5;
  }

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.globalCompositeOperation = "source-over";
  ctx.drawImage(video, drawX, drawY, drawWidth, drawHeight);
  ctx.restore();
}

export function createOfflineVideoTransitionCompositor({
  assetManager,
  classifyEnergy,
  getOptions,
  logger = console
} = {}) {
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.controls = false;
  video.loop = false;
  video.preload = "auto";
  video.style.display = "none";
  let loadedPath = "";
  let recentTransitionIds = [];
  const transitionDiversity = createDiversityCycle({ recentLimit: 3 });

  function effectiveOptions(renderOptions = {}) {
    return {
      ...(getOptions?.() || {}),
      ...(renderOptions || {})
    };
  }

  async function prepareTimeline(timeline = [], renderOptions = {}) {
    if (!capabilityEnabled("videoTransitions")) { timeline.forEach((t) => enforceTransitionCapabilities(t)); return timeline; }
    const options = enforceRuntimeOptions(effectiveOptions(renderOptions));
    const hasManualVideo = Array.isArray(timeline) && timeline.some((transition) => transition?.videoTransitionId || transition?.forceVideoTransition);
    if ((!options.useVideoTransitions && !hasManualVideo) || !assetManager || !Array.isArray(timeline)) return timeline;
    await assetManager.loadTransitionManifests();
    recentTransitionIds = [];
    transitionDiversity.reset();
    for (const transition of timeline) {
      const entry = await ensureTransitionVideo(transition, options);
      if (!entry) {
        transition.suppressShaderTransition = false;
        continue;
      }
    }
    return timeline;
  }

  async function ensureTransitionVideo(transition, options = effectiveOptions()) {
    enforceTransitionCapabilities(transition);
    if (!capabilityEnabled("videoTransitions")) return null;
    if (transition?.suppressVideoTransition) return null;
    if (transition?.videoTransition) return transition.videoTransition;
    const forcedId = transition?.videoTransitionId;
    const wantsVideo = options.useVideoTransitions || transition?.forceVideoTransition || forcedId;
    if (!wantsVideo || !assetManager || !transition) return null;
    await assetManager.loadTransitionManifests();
    if (forcedId) {
      const forcedEntry = assetManager.transitionById?.(forcedId);
      if (forcedEntry) {
        transition.videoTransition = forcedEntry;
        const forcedIds = assetManager.transitionsForMode?.(
          options.videoTransitionMode || "auto",
          options.selectedTransitionIds || []
        ).map((candidate) => candidate.id) || [];
        transitionDiversity.record(forcedEntry.id, forcedIds);
        return forcedEntry;
      }
    }
    const energyType = classifyEnergy?.(transition) || "high-high";
    const mode = options.videoTransitionMode || "auto";
    const selectedTransitionIds = options.selectedTransitionIds || [];
    const eligibleIds = assetManager.transitionsForMode?.(mode, selectedTransitionIds).map((candidate) => candidate.id) || [];
    const entry = assetManager.selectTransitionVideo({
      mode,
      energyType,
      selectedTransitionIds,
      candidateIds: transitionDiversity.candidates(eligibleIds),
      recentTransitionIds,
      random: seededRandom((transition.seed || 0.5) + transition.startTime * 0.071)
    });
    if (!entry) return null;
    transition.videoTransition = entry;
    transitionDiversity.record(entry.id, eligibleIds);
    recentTransitionIds.unshift(entry.id);
    recentTransitionIds.length = Math.min(recentTransitionIds.length, 3);
    return entry;
  }

  async function loadVideo(path) {
    if (!path) return false;
    if (loadedPath !== path) {
      video.pause();
      video.src = path;
      loadedPath = path;
      video.load();
      await waitForVideoEvent(video, ["loadedmetadata", "loadeddata", "canplay"]);
    }
    return video.readyState >= 1;
  }

  async function seekVideo(timeSeconds) {
    const safeDuration = Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 10;
    const target = Math.max(0, Math.min(safeDuration - 0.04, Number(timeSeconds) || 0));
    if (Math.abs((video.currentTime || 0) - target) < 0.004 && video.readyState >= 2) return;
    const wait = waitForVideoEvent(video, ["seeked"], 3000);
    try {
      video.currentTime = target;
    } catch (error) {
      logger.warn?.("Could not seek offline transition video:", error);
      return;
    }
    await wait;
    await waitForSeekToSettle(video, target);
  }

  async function composite(ctx, width, height, transition, timeSeconds, renderOptions = {}) {
    const options = enforceRuntimeOptions(effectiveOptions(renderOptions));
    if (transition?.suppressVideoTransition) return;
    const entry = await ensureTransitionVideo(transition, options);
    if (!(options.useVideoTransitions || transition?.forceVideoTransition || transition?.videoTransitionId) || !entry?.resolvedPath || !transition) return;
    const duration = Math.max(0.001, Number(transition.duration) || 10);
    const localTime = Math.max(0, Number(timeSeconds) - Number(transition.startTime || 0));
    const alpha = transitionOpacityForTime(localTime, duration, options);
    if (alpha <= 0.001) return;
    const ready = await loadVideo(entry.resolvedPath);
    if (!ready) return;
    await seekVideo(localTime);
    if (video.readyState < 2) await waitForVideoEvent(video, ["loadeddata", "canplay"], 2000);
    drawVideoCover(ctx, video, width, height, alpha);
  }

  async function overlayPayload(transition, timeSeconds, renderOptions = {}) {
    const options = enforceRuntimeOptions(effectiveOptions(renderOptions));
    if (transition?.suppressVideoTransition) return null;
    const entry = await ensureTransitionVideo(transition, options);
    if (!(options.useVideoTransitions || transition?.forceVideoTransition || transition?.videoTransitionId) || !entry?.resolvedPath || !transition) return null;
    const duration = Math.max(0.001, Number(transition.duration) || 10);
    const localTime = Math.max(0, Number(timeSeconds) - Number(transition.startTime || 0));
    const alpha = transitionOpacityForTime(localTime, duration, options);
    if (alpha <= 0.001) return null;
    return {
      path: entry.resolvedPath,
      time: Math.max(0, localTime),
      alpha,
      id: entry.id || ""
    };
  }

  function activeTransitionAt(timeline = [], timeSeconds = 0) {
    if (!capabilityEnabled("videoTransitions")) return null;
    const options = effectiveOptions();
    return timeline.find((transition) => (
      !transition?.suppressVideoTransition &&
      (options.useVideoTransitions || transition?.forceVideoTransition || transition?.videoTransitionId) &&
      timeSeconds >= transition.startTime &&
      timeSeconds <= transition.endTime
    )) || null;
  }

  function reset() {
    loadedPath = "";
    recentTransitionIds = [];
    transitionDiversity.reset();
    video.pause();
    video.removeAttribute("src");
    video.load?.();
  }

  return {
    prepareTimeline,
    composite,
    overlayPayload,
    activeTransitionAt,
    reset
  };
}
