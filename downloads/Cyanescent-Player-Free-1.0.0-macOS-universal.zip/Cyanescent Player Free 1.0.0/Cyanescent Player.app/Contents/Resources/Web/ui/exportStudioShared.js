// Shared helpers for the Export Studio: time formatting, the waveform drawn from
// the track analysis, and musical-marker drawing. Both the Automatic clip editor
// and the Custom Timeline journey editor use these so they read the same data.

export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function formatStudioTime(seconds, { tenths = false, hours = false } = {}) {
  const t = Math.max(0, Number(seconds) || 0);
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = t % 60;
  const ss = tenths ? s.toFixed(1).padStart(4, "0") : String(Math.floor(s)).padStart(2, "0");
  if (hours || h > 0) return `${h}:${String(m).padStart(2, "0")}:${ss}`;
  return `${m}:${ss}`;
}

export function formatStudioDuration(seconds) {
  const t = Math.max(0, Number(seconds) || 0);
  if (t < 60) return `${t < 10 ? t.toFixed(1).replace(/\.0$/, "") : Math.round(t)} sec`;
  return formatStudioTime(t);
}

// Accepts h:mm:ss.s, m:ss.s or plain seconds.
export function parseStudioTime(text) {
  const parts = String(text ?? "").trim().split(":").map((part) => part.trim());
  if (!parts.length || parts.some((part) => part === "" || !/^\d+(\.\d+)?$/.test(part))) return Number.NaN;
  return parts.reduce((total, part) => total * 60 + Number(part), 0);
}

export function hashUnit(n) {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

// A stable, distinct hue per preset id for segment tints.
export function presetHue(id) {
  return Math.round(hashUnit(Number(id) * 1.618 + 0.37) * 360);
}
export const presetColor = (id, alpha = 1) => `hsla(${presetHue(id)}, 68%, 60%, ${alpha})`;

// Per-frame loudness from the analysis (20 frames per second), mapped from dB so
// loud masters still show their structure instead of a flat block.
const waveCache = new WeakMap();
export function studioWaveData(analysisTimeline) {
  const frames = analysisTimeline?.frames;
  if (!frames?.length) return null;
  const cached = waveCache.get(analysisTimeline);
  if (cached && cached.length === frames.length) return cached;
  const n = frames.length;
  const db = new Float32Array(n);
  for (let i = 0; i < n; i += 1) {
    const frame = frames[i];
    db[i] = Number.isFinite(frame.fullDb) ? frame.fullDb : 20 * Math.log10(Math.max(1e-5, (frame.energy || 0) / 3.2));
  }
  const sorted = Array.from(db).sort((a, b) => a - b);
  const top = sorted[Math.floor(sorted.length * 0.99)] ?? 0;
  const floor = top - 36;
  const amp = new Float32Array(n);
  for (let i = 0; i < n; i += 1) amp[i] = clamp((db[i] - floor) / (top - floor), 0.02, 1);
  const data = {
    amp,
    length: n,
    rate: 1 / Math.max(0.001, Number(analysisTimeline.frameDuration) || 0.05)
  };
  waveCache.set(analysisTimeline, data);
  return data;
}

export function sizeCanvas(canvas) {
  const rect = canvas.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  const width = Math.max(1, Math.round(rect.width * ratio));
  const height = Math.max(1, Math.round(rect.height * ratio));
  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  return { ctx, w: rect.width, h: rect.height };
}

// Peak waveform for [view.start, view.start + view.dur], mirrored on the centre line.
export function drawStudioWave(ctx, data, x, y, w, h, view, colorAt) {
  if (!data || !(view.dur > 0)) return;
  const mid = y + h / 2;
  const step = 2;
  const spp = view.dur / w;
  for (let px = 0; px < w; px += step) {
    const t0 = view.start + px * spp;
    const t1 = t0 + spp * step;
    let i0 = Math.floor(t0 * data.rate);
    let i1 = Math.ceil(t1 * data.rate);
    if (i0 >= data.length) break;
    i0 = Math.max(0, i0);
    i1 = Math.min(data.length - 1, Math.max(i0, i1));
    let a = 0;
    for (let i = i0; i <= i1; i += 1) if (data.amp[i] > a) a = data.amp[i];
    const bh = Math.max(1, a * 0.9 * (h / 2 - 2));
    ctx.fillStyle = colorAt(t0);
    ctx.fillRect(x + px, mid - bh, step - 0.6, bh * 2);
  }
}

export function niceTick(viewDur, width, spacing = 90) {
  const target = viewDur / Math.max(1, width / spacing);
  const steps = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600];
  return steps.find((s) => s >= target) || 3600;
}

export function drawStudioRuler(ctx, x, y, w, h, view, { hours = false } = {}) {
  const tick = niceTick(view.dur, w);
  ctx.font = "11px ui-monospace, SF Mono, Menlo, monospace";
  ctx.textBaseline = "middle";
  for (let t = Math.ceil(view.start / tick) * tick; t <= view.start + view.dur; t += tick) {
    const px = x + ((t - view.start) / view.dur) * w;
    ctx.fillStyle = "rgba(139,184,208,.35)";
    ctx.fillRect(px, y + h - 6, 1, 6);
    const label = formatStudioTime(t, { tenths: tick < 1, hours });
    if (px + 4 + ctx.measureText(label).width < x + w) {
      ctx.fillStyle = "rgba(200,220,232,.7)";
      ctx.fillText(label, px + 4, y + h / 2 - 1);
    }
  }
}

// Musical markers from the player-wide Drop Map, thinned so majors win when crowded.
export function visibleStudioDrops(drops, view, width, visibility = "major") {
  if (visibility === "hidden" || !drops?.length) return [];
  const list = drops.filter((drop) => drop.kind !== "none"
    && drop.time >= view.start && drop.time <= view.start + view.dur
    && (visibility === "all" || drop.kind === "major"));
  const sorted = [...list].sort((a, b) => (a.kind === b.kind ? a.time - b.time : a.kind === "major" ? -1 : 1));
  const out = [];
  for (const drop of sorted) {
    const x = ((drop.time - view.start) / view.dur) * width;
    if (out.every((other) => Math.abs(other.x - x) >= 9)) out.push({ ...drop, x });
  }
  return out;
}

export function drawStudioDrops(ctx, drops, x0, top, bottom, { labels = false } = {}) {
  for (const drop of drops) {
    const x = x0 + drop.x;
    const major = drop.kind === "major";
    ctx.strokeStyle = major ? "rgba(242,180,92,.55)" : "rgba(242,180,92,.22)";
    ctx.lineWidth = 1;
    ctx.setLineDash(major ? [] : [2, 3]);
    ctx.beginPath(); ctx.moveTo(x + 0.5, top + 6); ctx.lineTo(x + 0.5, bottom); ctx.stroke();
    ctx.setLineDash([]);
    const s = major ? 5.5 : 3.5;
    ctx.fillStyle = major ? "#f2b45c" : "rgba(242,180,92,.7)";
    ctx.beginPath(); ctx.moveTo(x - s, top); ctx.lineTo(x + s, top); ctx.lineTo(x, top + s * 1.3); ctx.closePath(); ctx.fill();
    if (labels && major) {
      ctx.font = "600 10.5px system-ui, sans-serif";
      ctx.fillStyle = "rgba(242,180,92,.9)";
      ctx.textBaseline = "top";
      ctx.fillText("Drop", x + 7, top);
    }
  }
}

export function strongestMajorDrop(analysisTimeline) {
  const drops = (analysisTimeline?.drops || []).filter((drop) => drop.kind === "major");
  if (!drops.length) return null;
  return drops.reduce((best, drop) => ((drop.strength || 0) > (best.strength || 0) ? drop : best), drops[0]);
}
