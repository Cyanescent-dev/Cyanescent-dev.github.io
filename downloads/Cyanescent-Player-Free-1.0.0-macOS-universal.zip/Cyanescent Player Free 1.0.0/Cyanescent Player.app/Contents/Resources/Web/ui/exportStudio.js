import { automaticRenderedTransitionDuration, RENDERED_TRANSITION_CHOICES } from "./offlineTimeline.js";
import { capabilityEnabled } from "../config/runtimeCapabilities.js";
// Export Studio controller: the approved V2 interface on top of the existing
// export pipeline. One authoritative configuration object lives here; the export
// runtime reads it through exportOptionsFromUi(). Ranges always go through the
// shared export range model, and visuals keep using the player's own settings.

import { editionConfig } from "../generated/editionConfig.js";
import {
  CUSTOM_DESTINATION_ID,
  SAFE_AREA_GUIDES,
  destinationIsAvailable,
  destinationPresetById,
  exportDimensionError,
  exportEditionId,
  outputAspectRatioLabel,
  validateExportCapabilities
} from "./exportCapabilities.js";
import { validateExportRange } from "./exportRange.js";
import { exportOptionsFromUi } from "./export.js";
import {
  clamp,
  drawStudioDrops,
  drawStudioRuler,
  drawStudioWave,
  formatStudioDuration,
  formatStudioTime,
  parseStudioTime,
  sizeCanvas,
  strongestMajorDrop,
  studioWaveData,
  visibleStudioDrops
} from "./exportStudioShared.js";

/* ───────────────────────── Destinations ───────────────────────── */

const ICONS = {
  youtube: '<svg viewBox="0 0 28 28" aria-hidden="true"><rect x="2.5" y="6" width="23" height="16" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 10.5v7l6-3.5z" fill="currentColor"/></svg>',
  instagram: '<svg viewBox="0 0 28 28" aria-hidden="true"><rect x="4" y="4" width="20" height="20" rx="6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="14" cy="14" r="4.6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="19.6" cy="8.4" r="1.4" fill="currentColor"/></svg>',
  tiktok: '<svg viewBox="0 0 28 28" aria-hidden="true"><rect x="8" y="2.5" width="12" height="23" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M15.5 9v7.2a2.3 2.3 0 1 1-1.6-2.2M15.5 9c.4 1.4 1.4 2.2 2.6 2.4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  other: '<svg viewBox="0 0 28 28" aria-hidden="true"><rect x="4" y="4" width="8.5" height="8.5" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><rect x="15.5" y="4" width="8.5" height="8.5" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><rect x="4" y="15.5" width="8.5" height="8.5" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="19.75" cy="19.75" r="4.4" fill="none" stroke="currentColor" stroke-width="2"/></svg>'
};

export const STUDIO_PLATFORMS = Object.freeze({
  youtube: { label: "YouTube", sub: "Music video or Shorts", formats: ["yt-video", "yt-shorts"] },
  instagram: { label: "Instagram", sub: "Reel or feed post", formats: ["ig-reel", "ig-feed"] },
  tiktok: { label: "TikTok / Shorts", sub: "Vertical video", formats: ["tiktok", "shorts"] },
  other: { label: "Other", sub: "Square, Canvas, custom", formats: ["landscape", "square", "canvas", "custom"] }
});

// kind: landscape (resolution choice), vertical (1080×1920), feed, square, canvas, custom.
export const STUDIO_FORMATS = Object.freeze({
  "yt-video": { name: "Music video", tag: "16:9", short: "YouTube", kind: "landscape", fps: 60 },
  "yt-shorts": { name: "Shorts", tag: "9:16", short: "YouTube Shorts", kind: "vertical", fps: 30, guide: "youtubeShorts", note: "Shorts can be up to 3 minutes.", maxHint: 180 },
  "ig-reel": { name: "Reel", tag: "9:16 vertical", short: "Instagram Reel", kind: "vertical", fps: 30, guide: "instagramReels", note: "Reels can be up to 3 minutes.", maxHint: 180 },
  "ig-feed": { name: "Feed post", tag: "4:5 portrait", short: "Instagram Feed Post", kind: "feed", fps: 30 },
  "tiktok": { name: "TikTok", tag: "9:16", short: "TikTok", kind: "vertical", fps: 30, guide: "tiktok", maxHint: 600 },
  "shorts": { name: "YouTube Shorts", tag: "9:16", short: "YouTube Shorts", kind: "vertical", fps: 30, guide: "youtubeShorts", note: "Shorts can be up to 3 minutes.", maxHint: 180 },
  "landscape": { name: "Landscape", tag: "16:9 general", short: "Landscape video", kind: "landscape", fps: 30 },
  "square": { name: "Square", tag: "1:1", short: "Square video", kind: "square", fps: 30 },
  "canvas": { name: "Spotify Canvas", tag: "Silent 3–8 s loop", short: "Spotify Canvas", kind: "canvas", fps: 30, silent: true },
  "custom": { name: "Custom size", tag: "Any dimensions", short: "Custom", kind: "custom", fps: 30 }
});

const FIXED_SIZES = { vertical: [1080, 1920], feed: [1080, 1350], square: [1080, 1080], canvas: [1080, 1920] };
const FIXED_PRESETS = { vertical: "vertical-social", feed: "instagram-feed-portrait", square: "square-social", canvas: "spotify-canvas" };
export const STUDIO_RESOLUTIONS = Object.freeze([
  { value: 720, label: "720p", width: 1280, height: 720 },
  { value: 1080, label: "1080p", width: 1920, height: 1080 },
  { value: 1440, label: "1440p", width: 2560, height: 1440, pro: true },
  { value: 2160, label: "4K", width: 3840, height: 2160, pro: true }
]);
const LANDSCAPE_STEMS = { 1080: "youtube-hd", 1440: "youtube-1440p", 2160: "youtube-4k" };
export const STUDIO_FRAME_RATES = Object.freeze([24, 25, 30, 50, 60]);

export function recommendedBitrate(width, height, fps) {
  const pixels = Math.max(1, width * height);
  const base = pixels >= 3840 * 2160 * 0.9 ? 42 : pixels >= 2560 * 1440 * 0.9 ? 24 : pixels >= 1920 * 1080 * 0.9 ? 12 : 8;
  return Math.round(fps > 30 ? base * (pixels >= 3840 * 2160 * 0.9 ? 1.62 : 1.45) : base);
}

export function defaultStudioConfig(format = "yt-video") {
  const f = STUDIO_FORMATS[format] || STUDIO_FORMATS["yt-video"];
  const platform = Object.keys(STUDIO_PLATFORMS).find((key) => STUDIO_PLATFORMS[key].formats.includes(format)) || "youtube";
  return {
    platform,
    format,
    resolution: 1080,
    fps: f.fps,
    codec: "h264",
    bitrateMbps: null, // null: follow the recommended rate for the output
    audioFormat: "aac",
    audioBitrateKbps: 256,
    supersampling: 1,
    customWidth: 1920,
    customHeight: 1080,
    framingMode: "adaptive",
    framingX: 0,
    framingY: 0,
    framingZoom: 1,
    safeAreaGuide: "auto",
    autoClipBehaviour: "standalone",
    renderedTransitionDuration: 2.6,
    canvasLoopBehaviour: "restart"
  };
}

// Maps the studio configuration onto the existing destination presets. Anything
// the presets do not cover (720p, 24/25/50 fps, custom sizes) uses the existing
// "custom" path, which the runtime validates exactly like before.
export function resolveStudioOutput(config, edition = editionConfig) {
  const f = STUDIO_FORMATS[config.format] || STUDIO_FORMATS["yt-video"];
  const fps = f.kind === "canvas" ? 30 : Math.round(Number(config.fps) || f.fps);
  let width;
  let height;
  let destinationId = CUSTOM_DESTINATION_ID;
  if (f.kind === "custom") {
    width = Math.round(Number(config.customWidth) || 1920);
    height = Math.round(Number(config.customHeight) || 1080);
  } else if (f.kind === "landscape") {
    const res = STUDIO_RESOLUTIONS.find((r) => r.value === Number(config.resolution)) || STUDIO_RESOLUTIONS[1];
    width = res.width;
    height = res.height;
    const stem = LANDSCAPE_STEMS[res.value];
    const id = stem && (fps === 30 || fps === 60) ? `${stem}-${fps}` : "";
    if (id && destinationIsAvailable(id, edition)) destinationId = id;
  } else {
    [width, height] = FIXED_SIZES[f.kind];
    const stem = FIXED_PRESETS[f.kind];
    const id = f.kind === "vertical" ? `${stem}-${fps}` : stem;
    const preset = destinationPresetById(id);
    if (preset && preset.fps === fps && destinationIsAvailable(id, edition)) destinationId = id;
    if (f.kind === "canvas") destinationId = "spotify-canvas";
  }
  const preset = destinationPresetById(destinationId);
  const recommended = preset?.bitrateMbps || recommendedBitrate(width, height, fps);
  return {
    destinationId,
    width,
    height,
    fps,
    recommendedBitrateMbps: recommended,
    bitrateMbps: Number(config.bitrateMbps) > 0 ? Number(config.bitrateMbps) : recommended,
    canvas: f.kind === "canvas",
    silent: Boolean(f.silent),
    landscape: f.kind === "landscape",
    guide: f.guide || (height > width ? "vertical" : "none")
  };
}

// The fields exportOptionsFromUi() needs from the studio. Everything else in the
// export options (range, render size, JPEG quality) is derived there as before.
export function studioOutputFields(config, edition = editionConfig, { showGuides = false } = {}) {
  const out = resolveStudioOutput(config, edition);
  const guide = config.safeAreaGuide === "auto" ? (showGuides ? out.guide : "none") : config.safeAreaGuide;
  return {
    destinationId: out.destinationId,
    width: out.width,
    height: out.height,
    fps: out.fps,
    bitrateMbps: out.bitrateMbps,
    includeAudio: !out.silent,
    codec: config.codec === "h265" ? "h265" : "h264",
    audioFormat: config.audioFormat === "original" ? "original" : "aac",
    audioBitrateKbps: [128, 192, 256, 320].includes(Number(config.audioBitrateKbps)) ? Number(config.audioBitrateKbps) : 256,
    supersampling: clamp(Number(config.supersampling) || 1, 1, 4),
    framingMode: config.framingMode || "adaptive",
    framingPositionX: clamp(Number(config.framingX) || 0, -1, 1),
    framingPositionY: clamp(Number(config.framingY) || 0, -1, 1),
    framingZoom: clamp(Number(config.framingZoom) || 1, 0.5, 3),
    safeAreaGuide: SAFE_AREA_GUIDES[guide] ? guide : "none",
    autoClipBehaviour: config.autoClipBehaviour === "match-full" ? "match-full" : "standalone",
    renderedTransitionDuration: automaticRenderedTransitionDuration(config.renderedTransitionDuration),
    canvasLoopBehaviour: config.canvasLoopBehaviour || "restart"
  };
}

// Restores saved preferences, falling back to valid choices for this edition.
export function restoreStudioConfig(saved, edition = editionConfig) {
  const base = defaultStudioConfig();
  if (!saved || typeof saved !== "object" || saved.version !== 2) return { config: base, notice: "" };
  const format = STUDIO_FORMATS[saved.format] ? saved.format : base.format;
  const config = { ...defaultStudioConfig(format) };
  for (const key of Object.keys(base)) {
    if (key in saved && saved[key] !== undefined) config[key] = saved[key];
  }
  config.renderedTransitionDuration = automaticRenderedTransitionDuration(config.renderedTransitionDuration);
  config.format = format;
  config.platform = Object.keys(STUDIO_PLATFORMS).find((key) => STUDIO_PLATFORMS[key].formats.includes(format)) || "youtube";
  if (!STUDIO_FRAME_RATES.includes(Number(config.fps))) config.fps = STUDIO_FORMATS[format].fps;
  const out = resolveStudioOutput(config, edition);
  if (exportDimensionError(out, edition)) {
    config.resolution = 1080;
    if (STUDIO_FORMATS[format].kind === "custom") { config.customWidth = 1920; config.customHeight = 1080; }
    return { config, notice: "A saved Pro export setting was replaced with a 1080p setting for this edition." };
  }
  return { config, notice: "" };
}

/* ───────────────────────── Controller ───────────────────────── */

export function createExportStudio(deps) {
  const {
    ui,
    exportState,
    exportRangeModel,
    getTrackName,
    getTrackDuration,
    getAnalysisTimeline,
    getPlaybackAudio,
    playAudio,
    pauseAudio,
    seekAudio,
    previewSelection,
    stopSelectionPreview,
    preview,
    getPresetOptions,
    getActivePreset,
    selectPreset,
    nativeAppBridge,
    loadPreferences,
    savePreferences,
    startExport,
    cancelExport,
    revealExportedVideo,
    holdVisualiserHidden,
    edition = editionConfig
  } = deps;

  const root = document.getElementById("exportWindow");
  const $ = (id) => document.getElementById(id);
  let { config, notice: restoreNotice } = restoreStudioConfig(loadPreferences?.()?.studio, edition);
  let outputDirectory = String(loadPreferences?.()?.studio?.outputDirectory || "");
  let mode = "auto";
  let journey = null;
  let lastSelection = null;
  let clipView = { start: 0, dur: 0 };
  let clipTouched = false;
  let drawerTab = "output";
  let showGuides = false;
  let fileNameEdited = false;
  let pendingExportAfterLocation = false;
  let previewLive = false;
  let toastTimer = 0;

  const duration = () => Math.max(0, Number(getTrackDuration?.()) || 0);
  const hoursFormat = () => duration() >= 3600;
  const fmt = (t, opts = {}) => formatStudioTime(t, { hours: hoursFormat(), ...opts });
  const range = () => exportRangeModel.get();
  const format = () => STUDIO_FORMATS[config.format];
  const output = () => resolveStudioOutput(config, edition);
  const isFree = () => exportEditionId(edition) === "free";

  /* ── Preferences ── */
  let saveTimer = 0;
  function persist() {
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => {
      savePreferences?.({ studio: { version: 2, ...config, outputDirectory } });
    }, 250);
  }

  /* ── Destination ── */
  function renderDestCards(container, compact = false) {
    container.replaceChildren(...Object.entries(STUDIO_PLATFORMS).map(([id, platform]) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "dest-card";
      button.setAttribute("role", "radio");
      button.setAttribute("aria-checked", String(config.platform === id));
      button.dataset.platform = id;
      button.innerHTML = `${ICONS[id]}<strong>${platform.label}</strong>${compact ? "" : `<span>${platform.sub}</span>`}`;
      return button;
    }));
  }
  function aspectIcon(width, height) {
    const max = 22;
    const w = width >= height ? max : Math.round(max * width / height);
    const h = height >= width ? max : Math.round(max * height / width);
    return `<i class="ar" style="width:${w}px;height:${h}px"></i>`;
  }
  function formatSize(id) {
    const f = STUDIO_FORMATS[id];
    if (f.kind === "custom") return null;
    if (f.kind === "landscape") return [1920, 1080];
    return FIXED_SIZES[f.kind];
  }
  function renderFormatRow(container) {
    container.replaceChildren(...STUDIO_PLATFORMS[config.platform].formats.map((id) => {
      const f = STUDIO_FORMATS[id];
      const size = formatSize(id);
      const button = document.createElement("button");
      button.type = "button";
      button.className = "format-opt";
      button.setAttribute("role", "radio");
      button.setAttribute("aria-checked", String(config.format === id));
      button.dataset.format = id;
      button.innerHTML = `${size ? aspectIcon(size[0], size[1]) : aspectIcon(16, 10)}<span><b>${f.name} <span style="font-weight:500;color:var(--muted)">· ${f.tag}</span></b><small>${size ? `${size[0]}×${size[1]}` : "Set in Advanced"}</small></span>`;
      return button;
    }));
  }
  function setDestination(platform, formatId = null) {
    const previous = config.format;
    const nextFormat = formatId || (STUDIO_PLATFORMS[platform].formats.includes(config.format) ? config.format : STUDIO_PLATFORMS[platform].formats[0]);
    config.platform = platform;
    if (nextFormat !== previous) applyFormatDefaults(nextFormat);
    persist();
    render();
  }
  // A destination sets its own output defaults. The codec is kept (a personal
  // preference), and the music range and timeline are never touched — except
  // Canvas, whose 3–8 s clip is part of the format itself.
  function applyFormatDefaults(nextFormat) {
    const keep = { codec: config.codec, framingMode: config.framingMode, framingX: config.framingX, framingY: config.framingY, framingZoom: config.framingZoom, autoClipBehaviour: config.autoClipBehaviour, customWidth: config.customWidth, customHeight: config.customHeight };
    config = { ...defaultStudioConfig(nextFormat), ...keep, platform: config.platform, format: nextFormat };
    const f = STUDIO_FORMATS[nextFormat];
    if (f.kind === "canvas") enforceCanvasClip();
    if (f.kind === "custom") openDrawer("output");
    if (!fileNameEdited) setDefaultFileName();
    const out = output();
    toast(`Output set for <b>${f.short}</b> · ${resolutionLabel()} · ${out.fps} fps`);
  }
  function enforceCanvasClip() {
    const r = range();
    if (!r.trackDuration) return;
    const len = r.end - r.start;
    if (r.mode === "selected" && len >= 3 && len <= 8) return;
    const drop = strongestMajorDrop(getAnalysisTimeline?.());
    const start = clamp(drop ? drop.time : r.mode === "selected" ? r.start : 0, 0, Math.max(0, r.trackDuration - 8));
    exportRangeModel.setRange(start, Math.min(r.trackDuration, start + 8), { reason: "spotify-canvas" });
    fitClipView();
  }
  function resolutionLabel() {
    const out = output();
    if (out.landscape) return STUDIO_RESOLUTIONS.find((r) => r.width === out.width)?.label || `${out.height}p`;
    return `${out.width}×${out.height}`;
  }

  /* ── Music range (Automatic) ── */
  function setRangeMode(next) {
    if (format().kind === "canvas" && next === "full") return;
    const r = range();
    if (next === "full") {
      if (r.mode === "selected") lastSelection = { start: r.start, end: r.end };
      exportRangeModel.fullTrack();
    } else if (r.mode !== "selected") {
      if (lastSelection) {
        exportRangeModel.setRange(lastSelection.start, lastSelection.end, { reason: "restore-selection" });
      } else {
        const drop = strongestMajorDrop(getAnalysisTimeline?.());
        const len = format().kind === "canvas" ? 8 : 30;
        const start = clamp((drop ? drop.time : r.trackDuration * 0.25) - (format().kind === "canvas" ? 0 : 4), 0, Math.max(0, r.trackDuration - len));
        exportRangeModel.setRange(start, Math.min(r.trackDuration, start + len), { reason: "suggested-clip" });
        clipTouched = false;
      }
      fitClipView();
    }
    render();
  }
  function fitClipView() {
    const r = range();
    const total = duration();
    if (!total) return;
    const len = Math.max(1, r.end - r.start);
    const dur = clamp(len * 3, Math.min(20, total), total);
    clipView = { start: clamp(r.start + len / 2 - dur / 2, 0, Math.max(0, total - dur)), dur };
  }
  function setClip(start, end) {
    const total = duration();
    const canvas = format().kind === "canvas";
    const minLen = canvas ? 3 : 1;
    const maxLen = canvas ? 8 : total;
    start = clamp(start, 0, Math.max(0, total - minLen));
    end = clamp(end, start + minLen, Math.min(total, start + maxLen));
    exportRangeModel.setRange(start, end, { reason: "clip-editor" });
    clipTouched = true;
  }
  const clipVisible = () => { const r = range(); return r.start >= clipView.start && r.end <= clipView.start + clipView.dur; };

  function renderClipFields() {
    const r = range();
    const len = Math.max(0, r.end - r.start);
    for (const [id, value] of [["xsClipStart", r.start], ["xsClipEnd", r.end]]) {
      const el = $(id);
      if (document.activeElement !== el) { el.value = fmt(value, { tenths: true }); el.classList.remove("invalid"); }
    }
    const lengthEl = $("xsClipLength");
    if (document.activeElement !== lengthEl) { lengthEl.value = formatStudioTime(len, { tenths: true, hours: len >= 3600 }); lengthEl.classList.remove("invalid"); }
    const pills = format().kind === "canvas" ? [3, 5, 8] : [15, 30, 60, 90];
    $("xsDurPills").replaceChildren(...pills.map((s) => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = `${s} sec`;
      button.dataset.len = String(s);
      button.setAttribute("aria-pressed", String(Math.abs(len - s) < 0.05));
      return button;
    }));
    $("xsClipDur").textContent = r.mode === "selected" ? formatStudioDuration(len) : "";
  }
  function clipHintText() {
    if (!studioWaveData(getAnalysisTimeline?.())) return "Analysing the track…";
    if (clipView.dur >= duration() - 1) return "Whole track · drag across the waveform to choose a clip";
    return clipTouched ? `Viewing ${fmt(clipView.start)}–${fmt(clipView.start + clipView.dur)}` : "Suggested: starts just before the biggest drop";
  }
  function clipGeom() {
    const rect = $("xsClipWave").getBoundingClientRect();
    return { rect, x: (t) => ((t - clipView.start) / clipView.dur) * rect.width, t: (px) => clipView.start + (px / rect.width) * clipView.dur };
  }
  function drawClip() {
    if (mode !== "auto" || !isOpen()) return;
    const analysis = getAnalysisTimeline?.();
    const data = studioWaveData(analysis);
    const total = duration();
    const r = range();
    if (r.mode !== "selected") {
      const strip = $("xsFullStrip");
      const { ctx, w, h } = sizeCanvas(strip);
      ctx.clearRect(0, 0, w, h);
      if (data && total) drawStudioWave(ctx, data, 0, 0, w, h, { start: 0, dur: total }, () => "rgba(83,220,230,.55)");
      return;
    }
    if (!clipView.dur || !total) { clipView = { start: 0, dur: total || 1 }; }
    {
      const { ctx, w, h } = sizeCanvas($("xsClipOverview"));
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = "rgba(4,12,20,.9)"; ctx.fillRect(0, 0, w, h);
      if (data && total) drawStudioWave(ctx, data, 0, 0, w, h, { start: 0, dur: total }, (t) => (t >= r.start && t <= r.end ? "#53dce6" : "rgba(98,140,165,.5)"));
      if (total) {
        const vx = (clipView.start / total) * w;
        const vw = Math.max(4, (clipView.dur / total) * w);
        ctx.strokeStyle = "rgba(237,247,251,.75)"; ctx.lineWidth = 1.5;
        ctx.strokeRect(vx + 0.75, 0.75, vw - 1.5, h - 1.5);
        ctx.fillStyle = "rgba(237,247,251,.06)"; ctx.fillRect(vx, 0, vw, h);
        ctx.fillStyle = "#53dce6"; ctx.fillRect((r.start / total) * w - 1, 0, Math.max(2, ((r.end - r.start) / total) * w + 2), 3);
      }
    }
    const { ctx, w, h } = sizeCanvas($("xsClipWave"));
    const view = clipView;
    const rulerH = 20;
    const waveH = h - rulerH;
    const band = 18;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(4,12,20,.95)"; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "rgba(255,255,255,.03)"; ctx.fillRect(0, 0, w, band);
    const xs = ((r.start - view.start) / view.dur) * w;
    const xe = ((r.end - view.start) / view.dur) * w;
    ctx.fillStyle = "rgba(83,220,230,.10)"; ctx.fillRect(xs, band, xe - xs, waveH - band);
    if (data) drawStudioWave(ctx, data, 0, band + 2, w, waveH - band - 4, view, (t) => (t >= r.start && t <= r.end ? "#53dce6" : "rgba(98,140,165,.55)"));
    drawStudioDrops(ctx, visibleStudioDrops(analysis?.drops, view, w, "major"), 0, 3, waveH, { labels: true });
    ctx.font = "11.5px system-ui, sans-serif"; ctx.textBaseline = "middle"; ctx.textAlign = "right";
    ctx.fillStyle = "rgba(147,168,185,.95)";
    ctx.fillText(clipHintText(), w - 8, band / 2 + 1);
    ctx.textAlign = "left";
    for (const x of [xs, xe]) {
      if (x < -10 || x > w + 10) continue;
      ctx.fillStyle = "#53dce6";
      ctx.fillRect(x - 1.5, 0, 3, waveH);
      const cy = (waveH + band) / 2;
      ctx.beginPath(); ctx.roundRect(x - 7, cy - 18, 14, 36, 4); ctx.fill();
      ctx.strokeStyle = "rgba(4,22,28,.7)"; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x - 2, cy - 8); ctx.lineTo(x - 2, cy + 8); ctx.moveTo(x + 2, cy - 8); ctx.lineTo(x + 2, cy + 8); ctx.stroke();
    }
    if (xe - xs > 70) {
      ctx.font = "700 12px system-ui, sans-serif";
      const label = formatStudioDuration(r.end - r.start);
      const tw = ctx.measureText(label).width + 12;
      const cx = clamp((xs + xe) / 2, tw / 2 + 4, w - tw / 2 - 4);
      ctx.fillStyle = "rgba(4,22,28,.85)"; ctx.beginPath(); ctx.roundRect(cx - tw / 2, waveH - 24, tw, 19, 5); ctx.fill();
      ctx.fillStyle = "#cff7fa"; ctx.textBaseline = "middle"; ctx.textAlign = "center"; ctx.fillText(label, cx, waveH - 14.5); ctx.textAlign = "left";
    }
    const playhead = Number(getPlaybackAudio?.()?.currentTime) || 0;
    const px = ((playhead - view.start) / view.dur) * w;
    if (px >= 0 && px <= w) { ctx.fillStyle = "#fff"; ctx.fillRect(px - 0.75, 0, 1.5, waveH); }
    ctx.fillStyle = "rgba(255,255,255,.04)"; ctx.fillRect(0, waveH, w, rulerH);
    drawStudioRuler(ctx, 0, waveH, w, rulerH, view, { hours: hoursFormat() });
  }
  function zoomClip(factor, anchor) {
    const total = duration();
    if (!total) return;
    const dur = clamp(clipView.dur * factor, Math.min(6, total), total);
    const f = (anchor - clipView.start) / clipView.dur;
    clipView = { dur, start: clamp(anchor - f * dur, 0, total - dur) };
    renderClipFields(); drawClip();
  }
  function panClip(dt) {
    clipView.start = clamp(clipView.start + dt, 0, Math.max(0, duration() - clipView.dur));
    drawClip();
  }

  function bindClipEditor() {
    const canvas = $("xsClipWave");
    let drag = null;
    const snap = (t, event) => {
      if (event.altKey) return t;
      const g = clipGeom();
      for (const drop of getAnalysisTimeline?.()?.drops || []) {
        if (drop.kind === "major" && Math.abs(g.x(drop.time) - g.x(t)) < 8) return drop.time;
      }
      return t;
    };
    canvas.addEventListener("pointermove", (event) => {
      if (drag) return;
      const g = clipGeom();
      const r = range();
      const x = event.clientX - g.rect.left;
      const xs = g.x(r.start);
      const xe = g.x(r.end);
      canvas.style.cursor = Math.abs(x - xs) < 9 || Math.abs(x - xe) < 9 ? "ew-resize" : x > xs && x < xe ? "grab" : "crosshair";
    });
    canvas.addEventListener("pointerdown", (event) => {
      if (!duration()) return;
      const g = clipGeom();
      const r = range();
      const x = event.clientX - g.rect.left;
      const t = g.t(x);
      const xs = g.x(r.start);
      const xe = g.x(r.end);
      try { canvas.setPointerCapture(event.pointerId); } catch {}
      if (Math.abs(x - xs) < 9) drag = { kind: "start" };
      else if (Math.abs(x - xe) < 9) drag = { kind: "end" };
      else if (x > xs && x < xe) drag = { kind: "move", offset: t - r.start, len: r.end - r.start, x0: x, moved: false };
      else drag = { kind: "new", anchor: t, x0: x, moved: false };
    });
    canvas.addEventListener("pointermove", (event) => {
      if (!drag) return;
      const g = clipGeom();
      const x = event.clientX - g.rect.left;
      const t = clamp(g.t(x), 0, duration());
      const r = range();
      if (drag.kind === "start") setClip(snap(t, event), r.end);
      else if (drag.kind === "end") setClip(r.start, snap(t, event));
      else if (drag.kind === "move") {
        if (Math.abs(x - drag.x0) > 2) drag.moved = true;
        const s = snap(t - drag.offset, event);
        setClip(s, s + drag.len);
      } else if (drag.kind === "new" && Math.abs(x - drag.x0) > 4) {
        drag.moved = true;
        const a = snap(drag.anchor, event);
        const b = snap(t, event);
        setClip(Math.min(a, b), Math.max(a, b));
      }
    });
    const end = (event) => {
      if (!drag) return;
      if ((drag.kind === "new" || drag.kind === "move") && !drag.moved) {
        const g = clipGeom();
        seekAudio?.(clamp(g.t(event.clientX - g.rect.left), 0, duration()));
      }
      drag = null;
      drawClip();
    };
    canvas.addEventListener("pointerup", end);
    canvas.addEventListener("pointercancel", end);
    canvas.addEventListener("wheel", (event) => {
      event.preventDefault();
      const g = clipGeom();
      if (event.ctrlKey || event.metaKey) zoomClip(Math.exp(event.deltaY * 0.01), g.t(event.clientX - g.rect.left));
      else panClip(((event.deltaX || event.deltaY) / g.rect.width) * clipView.dur);
    }, { passive: false });

    const overview = $("xsClipOverview");
    let overviewDrag = false;
    const overviewMove = (event) => {
      const rect = overview.getBoundingClientRect();
      const t = ((event.clientX - rect.left) / rect.width) * duration();
      clipView.start = clamp(t - clipView.dur / 2, 0, Math.max(0, duration() - clipView.dur));
      drawClip();
    };
    overview.addEventListener("pointerdown", (event) => { overviewDrag = true; try { overview.setPointerCapture(event.pointerId); } catch {} overviewMove(event); });
    overview.addEventListener("pointermove", (event) => overviewDrag && overviewMove(event));
    overview.addEventListener("pointerup", () => { overviewDrag = false; });

    // Typing a start moves the clip and keeps its length; End and Length change the length.
    const applyField = (id) => {
      const el = $(id);
      const value = parseStudioTime(el.value);
      if (!Number.isFinite(value)) { el.classList.add("invalid"); return; }
      const r = range();
      if (id === "xsClipStart") setClip(value, value + (r.end - r.start));
      if (id === "xsClipEnd") setClip(r.start, value);
      if (id === "xsClipLength") setClip(r.start, r.start + value);
      if (!clipVisible()) fitClipView();
      el.blur();
      render();
    };
    for (const id of ["xsClipStart", "xsClipEnd", "xsClipLength"]) {
      $(id).addEventListener("keydown", (event) => {
        if (event.key === "Enter") applyField(id);
        if (event.key === "Escape") { event.stopPropagation(); event.target.blur(); renderClipFields(); }
      });
      $(id).addEventListener("change", () => applyField(id));
    }
    $("xsDurPills").addEventListener("click", (event) => {
      const button = event.target.closest("button[data-len]");
      if (!button) return;
      const r = range();
      setClip(r.start, r.start + Number(button.dataset.len));
      if (!clipVisible()) fitClipView();
      render();
    });
    $("xsClipZoomIn").onclick = () => { const r = range(); zoomClip(0.5, (r.start + r.end) / 2); };
    $("xsClipZoomOut").onclick = () => { const r = range(); zoomClip(2, (r.start + r.end) / 2); };
    $("xsClipZoomFit").onclick = () => { fitClipView(); render(); };
    $("xsClipZoomAll").onclick = () => { clipView = { start: 0, dur: duration() }; render(); };
    $("xsClipPlay").onclick = () => toggleClipPlayback();
  }

  /* ── Playback and preview ── */
  function audioPlaying() {
    const audio = getPlaybackAudio?.();
    return Boolean(audio && !audio.paused && !audio.ended);
  }
  async function toggleClipPlayback() {
    if (audioPlaying()) { pauseAudio?.(); stopSelectionPreview?.(); stopLivePreview(); syncPlayButtons(); return; }
    startLivePreview();
    try { await previewSelection?.({ loop: true }); } catch (error) { console.error(error); }
    syncPlayButtons();
  }
  async function togglePreviewPlayback() {
    if (audioPlaying()) { pauseAudio?.(); stopSelectionPreview?.(); stopLivePreview(); syncPlayButtons(); return; }
    startLivePreview();
    if (range().mode === "selected" && mode === "auto") await toggleClipPlayback();
    else { try { await playAudio?.(); } catch (error) { console.error(error); } }
    syncPlayButtons();
  }
  function syncPlayButtons() {
    const playing = audioPlaying();
    for (const id of ["xsClipPlay", "xsPreviewPlay", "xsTlPlay"]) $(id)?.setAttribute("aria-pressed", String(playing));
    const label = $("xsClipPlay")?.querySelector(".lbl");
    if (label) label.textContent = playing ? "Pause" : "Play clip";
    // Custom Timeline: one labelled control plays the music, the playhead and the preview.
    if (bigOpen) updateBigTransport();
    const tlPlay = $("xsTlPlay");
    if (tlPlay) {
      tlPlay.querySelector(".lbl").textContent = playing ? "Pause" : "Play";
      tlPlay.classList.toggle("is-playing", playing);
    }
  }
  function currentPreviewCanvas() {
    if (bigOpen) return $("xsBigCanvas");
    return mode === "custom" ? $("xsPreviewCanvasCustom") : $("xsPreviewCanvasAuto");
  }

  // Preview frames are rendered here with the export renderer and plan (not
  // copied from the visualiser window), one job at a time because a frame
  // temporarily owns the renderer state. A still is drawn when idle; while the
  // music plays, frames follow the playhead.
  let previewQueue = Promise.resolve();
  let bigOpen = false;
  // Preview state for the small tag: loading (a session is starting), unavailable.
  let previewLoading = false;
  let previewUnavailable = "";
  let liveSession = null;
  let liveTimer = 0;
  let stillTimer = 0;
  let stillToken = 0;
  let exportStarting = false;
  const backgroundVideos = new Map();
  const enqueue = (job) => { previewQueue = previewQueue.then(job, job).catch((error) => console.error("Export preview:", error)); return previewQueue; };
  function previewMaxWidth() {
    const rect = currentPreviewCanvas()?.getBoundingClientRect();
    // The large preview renders bigger, but still well below export resolution.
    const cap = bigOpen ? 1280 : 960;
    const longest = Math.max(rect?.width || 480, rect?.height || 270);
    return Math.round(Math.min(cap, Math.max(320, longest * Math.min(window.devicePixelRatio || 1, 2))));
  }
  function backgroundVideo(path) {
    let video = backgroundVideos.get(path);
    if (!video) {
      video = document.createElement("video");
      video.muted = true;
      video.playsInline = true;
      video.preload = "auto";
      video.src = path;
      backgroundVideos.set(path, video);
    }
    return video;
  }
  function seekVideo(video, time) {
    return new Promise((resolve) => {
      const done = () => { video.removeEventListener("seeked", done); resolve(); };
      const ready = () => {
        if (Math.abs((video.currentTime || 0) - time) < 0.04) return resolve();
        video.addEventListener("seeked", done);
        video.currentTime = Math.max(0, time);
      };
      if (video.readyState >= 1) ready();
      else video.addEventListener("loadedmetadata", ready, { once: true });
      window.setTimeout(resolve, 500);
    });
  }
  async function drawFrame(frame) {
    const target = currentPreviewCanvas();
    if (!target || !frame?.image) return;
    const rect = target.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(2, Math.round(rect.width * ratio));
    const height = Math.max(2, Math.round(rect.height * ratio));
    // Video-background presets: the export composites these clips under the frame.
    const layers = [];
    for (const key of ["primary", "secondary"]) {
      const layer = frame.videoBackground?.[key];
      if (layer?.path && layer.alpha > 0.001) {
        const video = backgroundVideo(layer.path);
        await seekVideo(video, Number(layer.time) || 0);
        layers.push({ video, alpha: layer.alpha });
      }
    }
    // Video-clip transitions: drawn over the frame, as the encoder does in an export.
    let overlay = null;
    const t = frame.transitionOverlay;
    if (t?.path && t.alpha > 0.001) {
      const video = backgroundVideo(t.path);
      await seekVideo(video, Number(t.time) || 0);
      overlay = { video, alpha: t.alpha };
    }
    window.__xsPreviewOverlay = overlay ? t.path : ""; // read by the UI-preview harness
    if (target.width !== width || target.height !== height) { target.width = width; target.height = height; }
    const ctx = target.getContext("2d");
    ctx.fillStyle = "#02050a";
    ctx.fillRect(0, 0, width, height);
    for (const { video, alpha } of layers) {
      if (!video.videoWidth) continue;
      const scale = Math.max(width / video.videoWidth, height / video.videoHeight);
      ctx.globalAlpha = Math.min(1, alpha);
      ctx.drawImage(video, (width - video.videoWidth * scale) / 2, (height - video.videoHeight * scale) / 2, video.videoWidth * scale, video.videoHeight * scale);
      ctx.globalAlpha = 1;
    }
    ctx.drawImage(frame.image, 0, 0, width, height);
    if (overlay?.video.videoWidth) {
      const { video, alpha } = overlay;
      const scale = Math.max(width / video.videoWidth, height / video.videoHeight);
      ctx.globalAlpha = Math.min(1, alpha);
      ctx.drawImage(video, (width - video.videoWidth * scale) / 2, (height - video.videoHeight * scale) / 2, video.videoWidth * scale, video.videoHeight * scale);
      ctx.globalAlpha = 1;
    }
    if (previewLoading) { previewLoading = false; updatePreviewState(); }
  }
  function blankFrame(frame) {
    if (!frame?.image || frame.videoBackground) return false;
    try {
      const { width, height } = frame.image;
      const data = frame.image.getContext("2d").getImageData(0, 0, width, height).data;
      let sum = 0;
      let count = 0;
      for (let i = 0; i < data.length; i += 4 * 61) { sum += data[i] + data[i + 1] + data[i + 2]; count += 1; }
      return sum / Math.max(1, count * 3) < 2;
    } catch { return false; }
  }
  // attempt > 0: presets that load assets or fade in can give an empty first frame;
  // try again shortly instead of leaving a black still.
  function capturePoster(attempt = 0) {
    if (!Number.isInteger(attempt)) attempt = 0;
    if (previewLive && !exportStarting && !exportState?.active) {
      // Playing: settings changed (clip, format, framing); restart with them shortly.
      window.clearTimeout(restartTimer);
      restartTimer = window.setTimeout(() => { if (previewLive) restartLivePreview(); }, 250);
      return;
    }
    if (previewLive || exportStarting || exportState?.active || !isOpen()) return;
    window.clearTimeout(stillTimer);
    const token = ++stillToken;
    stillTimer = window.setTimeout(() => enqueue(async () => {
      if (token !== stillToken || previewLive || exportState?.active || !isOpen()) return;
      previewLoading = true; updatePreviewState();
      const session = await preview?.begin?.({ maxWidth: previewMaxWidth() });
      if (!session) { previewLoading = false; previewUnavailable = duration() ? "" : "Load a track to preview"; updatePreviewState(); return; }
      previewUnavailable = "";
      let blank = false;
      try {
        // A short run-up so feedback and fade-in presets look as they do mid-video.
        const time = currentTime();
        for (let i = 6; i >= 1; i -= 1) await session.renderAt(time - i / 15);
        const frame = await session.renderAt(time);
        if (token === stillToken && !previewLive) {
          await drawFrame(frame);
          blank = blankFrame(frame);
        }
      } finally {
        session.end();
      }
      if (blank && attempt < 6 && token === stillToken) capturePoster(attempt + 1);
    }), attempt ? 700 : 300);
  }
  // Each start gets a generation so a stale frame loop never keeps running.
  let liveGeneration = 0;
  let restartTimer = 0;
  async function openLiveSession() {
    previewLoading = true; updatePreviewState();
    liveSession = await preview?.begin?.({ maxWidth: previewMaxWidth() });
    if (!liveSession) { previewLive = false; previewLoading = false; updatePreviewMeta(); }
  }
  // Re-render with the current settings and sequence: restart a playing preview, or start one.
  function refreshLivePreview() {
    if (previewLive) restartLivePreview();
    else startLivePreview();
  }
  function startLivePreview() {
    if (previewLive || exportStarting || exportState?.active) return;
    if (mode === "custom" && root.dataset.tlPreview === "off") return;
    previewLive = true;
    stillToken += 1;
    const generation = ++liveGeneration;
    updatePreviewMeta();
    const step = () => enqueue(async () => {
      if (!previewLive || generation !== liveGeneration) return;
      if (liveSession) {
        const frame = await liveSession.renderAt(currentTime());
        if (previewLive && generation === liveGeneration) await drawFrame(frame);
        updatePreviewFootTime();
      }
      if (previewLive && generation === liveGeneration) liveTimer = window.setTimeout(step, 30);
    });
    enqueue(async () => {
      if (!previewLive || generation !== liveGeneration) return;
      await openLiveSession();
      step();
    });
  }
  // A session renders with the settings it started with (preset, clip, format), so a
  // playing preview restarts when they change.
  function restartLivePreview() {
    window.clearTimeout(restartTimer);
    enqueue(async () => {
      liveSession?.end();
      liveSession = null;
      if (previewLive) await openLiveSession();
    });
  }
  function stopLivePreview() {
    if (!previewLive) return;
    previewLive = false;
    liveGeneration += 1;
    window.clearTimeout(liveTimer);
    window.clearTimeout(restartTimer);
    enqueue(async () => {
      liveSession?.end();
      liveSession = null;
    });
    updatePreviewMeta();
    capturePoster();
  }
  function whenPreviewIdle() {
    return previewQueue;
  }
  function updatePreviewFootTime() {
    $("xsPreviewTime").textContent = fmt(currentTime());
    if (mode === "custom") journey?.redraw?.();
    if (bigOpen) updateBigTransport();
  }
  // Still, live, loading, auditioning or unavailable: one small tag per preview.
  function previewStateLabel() {
    if (previewUnavailable) return ["Unavailable", previewUnavailable];
    if (journey?.auditioning?.()) return ["Auditioning", `Previewing ${journey.auditionLabel()} without applying it`];
    if (previewLoading) return ["Loading…", "Preparing the preset for the preview"];
    if (previewLive) return ["Live", "Live visuals following the music"];
    return ["Still", "A still frame at the playhead. Press Play to preview live."];
  }
  function updatePreviewState() {
    const [label, title] = previewStateLabel();
    for (const id of ["xsPreviewState", "xsPreviewStateTl", "xsBigState"]) {
      const el = $(id);
      if (!el) continue;
      el.textContent = label;
      el.title = title;
      el.dataset.state = label.replace(/\W/g, "").toLowerCase();
    }
    if (bigOpen) updateBigTransport();
  }

  /* ── Large preview ── */
  function seekSpan() {
    const r = range();
    // Automatic clips preview their clip; the timeline previews the whole track.
    if (mode === "auto" && r.mode === "selected") return { a: r.start, b: r.end };
    return { a: 0, b: duration() };
  }
  function layoutBig() {
    const stage = $("xsBigStage");
    const frame = $("xsBigFrame");
    const out = output();
    const style = window.getComputedStyle(stage);
    const width = stage.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
    const height = stage.clientHeight - parseFloat(style.paddingTop) - parseFloat(style.paddingBottom);
    if (width < 10 || height < 10) return;
    const scale = Math.min(width / out.width, height / out.height);
    frame.style.width = `${Math.floor(out.width * scale)}px`;
    frame.style.height = `${Math.floor(out.height * scale)}px`;
    $("xsBigAspect").textContent = outputAspectRatioLabel(out.width, out.height);
  }
  function updateBigTransport() {
    const t = currentTime();
    const span = seekSpan();
    $("xsBigTime").textContent = `${fmt(t)} / ${fmt(mode === "auto" && range().mode === "selected" ? span.b : duration())}`;
    const seek = $("xsBigSeek");
    if (document.activeElement !== seek) seek.value = String(Math.round(clamp((t - span.a) / Math.max(0.001, span.b - span.a), 0, 1) * 1000));
    const presetId = mode === "custom" ? journey?.presetAt?.(t) : getActivePreset?.();
    $("xsBigPreset").textContent = presetName(presetId);
    const playing = audioPlaying();
    $("xsBigPlay").setAttribute("aria-pressed", String(playing));
    $("xsBigPlay").querySelector(".lbl").textContent = playing ? "Pause" : "Play";
    const audition = $("xsBigAudition");
    audition.hidden = !(mode === "custom" && (journey?.auditioning?.() || journey?.canAudition?.()));
    audition.textContent = journey?.auditioning?.() ? "■ Stop preview" : "▶ Preview transition";
  }
  function openBigPreview() {
    if (bigOpen || !isOpen()) return;
    bigOpen = true;
    $("xsBig").hidden = false;
    root.dataset.big = "on";
    layoutBig();
    updateBigTransport();
    $("xsBigClose").focus();
    capturePoster();
  }
  function closeBigPreview() {
    if (!bigOpen) return;
    bigOpen = false;
    $("xsBig").hidden = true;
    delete root.dataset.big;
    // Back to the embedded preview at its own size; edits, range and playhead are untouched.
    capturePoster();
    (mode === "custom" ? $("xsTlPreviewBig") : $("xsPreviewBigAuto"))?.focus();
  }
  function togglePlaybackForMode() {
    if (mode === "custom") journey?.togglePlay?.();
    else togglePreviewPlayback();
  }
  function updatePreviewMeta() {
    const out = output();
    const ar = outputAspectRatioLabel(out.width, out.height);
    for (const id of ["xsPreviewAspect", "xsPreviewAspectTl"]) $(id).textContent = ar;
    updatePreviewState();
    root.dataset.outShape = out.height > out.width * 1.05 ? "portrait" : out.width > out.height * 1.05 ? "landscape" : "square";
    if (bigOpen) layoutBig();
    for (const box of [$("xsPreviewAuto"), $("xsPreviewCustom")]) layoutPreviewBox(box, out);
    const presetId = mode === "custom" ? journey?.presetAt?.(currentTime()) : getActivePreset?.();
    const name = presetName(presetId);
    $("xsPreviewPreset").textContent = name;
    $("xsPreviewTime").textContent = fmt(currentTime());
    $("xsGuidesToggleWrap").hidden = !(out.height > out.width);
  }
  function layoutPreviewBox(box, out) {
    if (!box) return;
    const frame = box.querySelector(".preview-frame");
    const foot = box.querySelector(".preview-foot");
    const rect = box.getBoundingClientRect();
    if (rect.width < 10 || rect.height < 10) return;
    const scale = Math.min(rect.width / out.width, (rect.height - (foot ? 38 : 0)) / out.height);
    const fw = Math.max(40, Math.floor(out.width * scale));
    const fh = Math.max(40, Math.floor(out.height * scale));
    if (frame.style.width !== `${fw}px` || frame.style.height !== `${fh}px`) {
      frame.style.width = `${fw}px`;
      frame.style.height = `${fh}px`;
      window.requestAnimationFrame(() => capturePoster());
    }
    if (foot) foot.style.width = `${Math.max(220, fw)}px`;
    frame.querySelector(".pv-label").textContent = `${resolutionLabel()} · ${outputAspectRatioLabel(out.width, out.height)}`;
    frame.querySelector(".pv-silent").hidden = !out.silent;
    const fields = studioOutputFields(config, edition, { showGuides });
    const guide = SAFE_AREA_GUIDES[fields.safeAreaGuide] || SAFE_AREA_GUIDES.none;
    frame.querySelector(".pv-guides").replaceChildren(...guide.boxes.map((b) => {
      const el = document.createElement("div");
      Object.assign(el.style, { left: `${b.x * 100}%`, top: `${b.y * 100}%`, width: `${b.width * 100}%`, height: `${b.height * 100}%` });
      el.title = b.label;
      return el;
    }));
  }
  const currentTime = () => Number(getPlaybackAudio?.()?.currentTime) || 0;
  function presetName(id) {
    const match = (getPresetOptions?.() || []).find((p) => Number(p.id) === Number(id));
    return match?.name || "";
  }

  /* ── Visuals (Automatic) ── */
  function renderVisuals() {
    const behaviour = ui.transitionMode?.value || "adaptive";
    const value = ["adaptive", "shuffle", "static"].includes(behaviour) ? behaviour : "adaptive";
    $("xsVisualBehaviour").value = value;
    const single = value === "static";
    $("xsSinglePresetWrap").hidden = !single;
    if (single) {
      const select = $("xsSinglePreset");
      const options = getPresetOptions?.() || [];
      if (select.options.length !== options.length) select.replaceChildren(...options.map((p) => new Option(p.name, String(p.id))));
      select.value = String(getActivePreset?.());
    }
    $("xsVisualTitle").textContent = single ? "One preset" : "Automatic";
    $("xsVisualDesc").textContent = ({ adaptive: "Visuals change with your music", shuffle: "Presets shuffle at musical moments", static: "The same preset for the whole video" })[value];
  }
  function setPlayerControl(control, value) {
    if (!control) return;
    if (control.type === "checkbox") control.checked = Boolean(value);
    else control.value = String(value);
    control.dispatchEvent(new Event("change", { bubbles: true }));
  }

  /* ── Advanced drawer ── */
  function openDrawer(tab) {
    if (tab) drawerTab = tab;
    $("xsDrawer").hidden = false;
    root.dataset.drawer = "open";
    $("xsAdvancedBtn").setAttribute("aria-expanded", "true");
    renderDrawer();
    layout();
  }
  function closeDrawer() {
    $("xsDrawer").hidden = true;
    root.dataset.drawer = "closed";
    $("xsAdvancedBtn").setAttribute("aria-expanded", "false");
    layout();
  }
  function advancedChanges() {
    const d = defaultStudioConfig(config.format);
    const list = [];
    for (const key of ["resolution", "fps", "codec", "audioFormat", "audioBitrateKbps", "supersampling", "framingMode", "safeAreaGuide", "autoClipBehaviour", "renderedTransitionDuration"]) {
      if (key === "resolution" && format().kind !== "landscape") continue;
      if (config[key] !== d[key]) list.push(key);
    }
    if (config.bitrateMbps) list.push("bitrateMbps");
    if (ui.useVideoTransitions?.checked) list.push("style");
    if ((ui.adaptiveTransitionTime?.value || "medium") !== "medium") list.push("frequency");
    return list;
  }
  function segField(label, key, options, current, { help = "", changed = false, stacked = false } = {}) {
    return `<div class="field"><div class="field-label">${label}${changed ? ' <i class="changed-dot" title="Changed from the destination default"></i>' : ""}</div>
      <div class="seg${stacked ? " seg-stack" : ""}${key === "resolution" ? " seg-resolution" : ""}" role="radiogroup" aria-label="${label}">${options.map((o) => `<button type="button" role="radio" data-set="${key}" data-val="${o.value}" ${o.pro ? 'data-pro="1"' : ""} aria-checked="${String(o.value) === String(current)}" ${o.disabled ? "disabled" : ""}>${o.label}${o.pro && isFree() ? '<span class="pro-tag">PRO</span>' : ""}</button>`).join("")}</div>
      ${help ? `<p class="field-help">${help}</p>` : ""}</div>`;
  }
  function frequencyValue() {
    const timing = ui.adaptiveTransitionTime?.value || "medium";
    return timing === "long" ? "relaxed" : timing === "short" ? "energetic" : "balanced";
  }
  function renderDrawer() {
    if ($("xsDrawer").hidden) return;
    for (const button of root.querySelectorAll(".drawer-tabs button")) button.setAttribute("aria-selected", String(button.dataset.tab === drawerTab));
    $("xsDrawerResetDest").textContent = format().short;
    const f = format();
    const out = output();
    const changes = advancedChanges();
    let html = "";
    if (drawerTab === "output") {
      if (f.kind === "landscape") {
        html += segField("Resolution", "resolution", STUDIO_RESOLUTIONS.map((r) => ({ value: r.value, label: r.label, pro: r.pro && isFree() })), config.resolution, { changed: changes.includes("resolution"), help: `${out.width}×${out.height}` });
      } else if (f.kind === "custom") {
        html += `<div class="field"><div class="field-label">Custom size</div><div class="field-row"><label class="field"><span class="field-help">Width</span><input type="number" min="2" step="2" value="${config.customWidth}" data-bind="customWidth" id="xsCustomWidth"></label><label class="field"><span class="field-help">Height</span><input type="number" min="2" step="2" value="${config.customHeight}" data-bind="customHeight" id="xsCustomHeight"></label></div><p class="field-help">${isFree() ? "The Free edition exports up to 1920×1080 or 1080×1920." : "Up to 3840×2160 or 2160×3840. Even numbers only."}</p></div>`;
      } else {
        html += `<div class="field"><div class="field-label">Resolution <span class="hint">${out.width}×${out.height}</span></div><p class="field-help">${f.short} uses the platform's standard size. Choose Other → Custom size for anything else.</p></div>`;
      }
      html += `<div id="xsProNote"></div>`;
      if (f.kind === "canvas") html += `<div class="field"><div class="field-label">Frame rate <span class="hint">30 fps</span></div><p class="field-help">Spotify Canvas uses 30 fps.</p></div>`;
      else html += segField("Frame rate", "fps", STUDIO_FRAME_RATES.map((v) => ({ value: v, label: `${v}` })), config.fps, { changed: changes.includes("fps"), help: "fps · 30 suits social platforms; 60 looks smoother on YouTube." });
      html += segField("Codec", "codec", [{ value: "h264", label: "H.264" }, { value: "h265", label: "H.265 (HEVC)" }], config.codec, { changed: changes.includes("codec"), help: config.codec === "h264" ? "Plays everywhere. Best for uploads." : "Smaller files at the same quality; some older devices cannot play it." });
      html += `<div class="field"><div class="field-label">Video quality${config.bitrateMbps ? ' <i class="changed-dot"></i>' : ""}<output>${out.bitrateMbps} Mbps</output></div>
        <input type="range" min="4" max="80" step="1" value="${out.bitrateMbps}" data-bind="bitrateMbps" aria-label="Video bitrate" id="xsBitrate">
        <p class="field-help">${config.bitrateMbps ? `Recommended for this output: ${out.recommendedBitrateMbps} Mbps. <button type="button" class="link-btn" data-act="bitrate-auto">Use recommended</button>` : `Recommended for ${resolutionLabel()} at ${out.fps} fps.`}</p></div>`;
      if (out.silent) {
        html += `<div class="field"><div class="field-label">Audio <span class="hint">None</span></div><p class="field-help">Spotify Canvas clips are silent.</p></div>`;
      } else {
        html += segField("Audio", "audioFormat", [{ value: "aac", label: "AAC" }, { value: "original", label: "Original audio" }], config.audioFormat, { changed: changes.includes("audioFormat") });
        if (config.audioFormat === "aac") html += `<div class="field"><div class="field-label">Audio quality${changes.includes("audioBitrateKbps") ? ' <i class="changed-dot"></i>' : ""}</div><select data-bind="audioBitrateKbps" id="xsAudioBitrate">${[[128, "Compact · 128 kbps"], [192, "Standard · 192 kbps"], [256, "High · 256 kbps"], [320, "Maximum · 320 kbps"]].map(([v, l]) => `<option value="${v}" ${v === Number(config.audioBitrateKbps) ? "selected" : ""}>${l}</option>`).join("")}</select></div>`;
      }
      html += segField("Supersampling", "supersampling", [{ value: 1, label: "Off" }, { value: 2, label: "2×" }, { value: 4, label: "4× · very slow" }], config.supersampling, { changed: changes.includes("supersampling"), help: "Smoother edges, longer render." });
    }
    if (drawerTab === "visuals") {
      if (mode === "custom") html += `<p class="field-help">In Custom Timeline each visual change has its own transition, set when you add or edit it. The settings below shape Automatic exports and new automatic sequences.</p>`;
      else html += `<p class="field-help">Visual behaviour (${$("xsVisualBehaviour").selectedOptions[0]?.textContent || "Adaptive to music"}) is set in step 3.</p>`;
      html += segField("Transition style", "style", [{ value: "rendered", label: "Rendered" }, ...(capabilityEnabled("videoTransitions") ? [{ value: "video", label: "Video transitions" }] : [])], ui.useVideoTransitions?.checked ? "video" : "rendered", { changed: changes.includes("style"), help: "Rendered transitions blend the presets live; video transitions use the transition clip library." });
      html += segField("How often visuals change", "frequency", [{ value: "relaxed", label: "Relaxed" }, { value: "balanced", label: "Balanced" }, { value: "energetic", label: "Energetic" }], frequencyValue(), { changed: changes.includes("frequency"), help: "How often the automatic sequence changes between musical moments." });
      if (mode === "auto" && !ui.useVideoTransitions?.checked && ui.transitionMode?.value !== "static") html += segField("Rendered transition duration", "renderedTransitionDuration", RENDERED_TRANSITION_CHOICES.map(o => ({ value: o.value, label: `${o.label} — ${o.value} seconds` })), config.renderedTransitionDuration, { stacked: true, changed: changes.includes("renderedTransitionDuration"), help: "The blend length; musical change times stay the same. Shortened around the same musical landing when a track boundary requires it." });
      if (mode === "auto" && range().mode === "selected" && format().kind !== "canvas") html += segField("Clip visual timing", "autoClipBehaviour", [{ value: "standalone", label: "Standalone clip" }, { value: "match-full", label: "Match full video" }], config.autoClipBehaviour, { changed: changes.includes("autoClipBehaviour"), help: config.autoClipBehaviour === "standalone" ? "The clip opens with its own visual sequence." : "The clip shows what the full-length video shows at these times." });
      if (format().kind === "canvas") html += `<div class="field"><div class="field-label">Loop treatment <span class="hint">Hard restart</span></div><p class="field-help">The clip restarts cleanly when Spotify loops it.</p></div>`;
    }
    if (drawerTab === "framing") {
      if (window.getComputedStyle($("xsDrawer")).position === "absolute") {
        html += `<div class="drawer-preview"><p class="field-help">The preview beside this panel is covered on smaller windows; framing changes show there when you close the panel.</p></div>`;
      }
      html += segField("Framing", "framingMode", [{ value: "adaptive", label: "Adaptive" }, { value: "fill", label: "Fill" }, { value: "fit", label: "Fit" }, { value: "manual", label: "Manual" }], config.framingMode, { changed: changes.includes("framingMode"), help: ({ adaptive: "Renders each preset natively at this aspect ratio.", fill: "Fills the frame, cropping the edges.", fit: "Shows the whole picture with bars where needed.", manual: "Position and zoom the picture yourself." })[config.framingMode] });
      if (config.framingMode === "manual") {
        for (const [key, label, min, max, unit] of [["framingX", "Horizontal", -1, 1, ""], ["framingY", "Vertical", -1, 1, ""], ["framingZoom", "Zoom", 0.5, 2, "×"]]) {
          html += `<div class="field"><div class="field-label">${label}<output>${Number(config[key]).toFixed(2)}${unit}</output></div><input type="range" min="${min}" max="${max}" step="0.01" value="${config[key]}" data-bind="${key}" id="xs-${key}"></div>`;
        }
        html += `<button class="text-btn" type="button" data-act="framing-reset" style="justify-self:start">Reset position</button>`;
      }
      html += `<div class="field"><div class="field-label">Safe-area guide${changes.includes("safeAreaGuide") ? ' <i class="changed-dot"></i>' : ""}</div>
        <select data-bind="safeAreaGuide" id="xsSafeArea">${[["auto", "Match destination"], ["none", "Off"], ["vertical", "Generic vertical video"], ["tiktok", "TikTok"], ["instagramReels", "Instagram Reels"], ["youtubeShorts", "YouTube Shorts"]].map(([v, l]) => `<option value="${v}" ${v === config.safeAreaGuide ? "selected" : ""}>${l}</option>`).join("")}</select>
        <p class="field-help">Guides appear in the preview only, never in the exported video.${config.safeAreaGuide === "auto" ? " With “Match destination”, use the Safe area switch under the preview." : ""}</p></div>`;
    }
    $("xsDrawerBody").innerHTML = html;
    // The diagnostic batch belongs at the end of the Output settings, inside the scrolling list.
    const diagnostics = $("presetTestBatchSection");
    if (diagnostics) {
      if (drawerTab === "output") $("xsDrawerBody").append(diagnostics);
      else $("xsDrawer").append(diagnostics);
      diagnostics.style.display = drawerTab === "output" ? "" : "none";
    }
  }
  function bindDrawer() {
    const drawer = $("xsDrawer");
    drawer.addEventListener("click", (event) => {
      const tab = event.target.closest(".drawer-tabs button");
      if (tab) { drawerTab = tab.dataset.tab; renderDrawer(); return; }
      const button = event.target.closest("[data-set]");
      if (button) {
        if (button.dataset.pro && isFree()) {
          $("xsProNote").innerHTML = `<p class="pro-note">${button.textContent.replace("PRO", "").trim()} export is part of Cyanescent Player Pro. The Free edition exports up to 1080p.</p>`;
          return;
        }
        const key = button.dataset.set;
        const raw = button.dataset.val;
        const value = /^-?\d+(\.\d+)?$/.test(raw) ? Number(raw) : raw;
        if (key === "style") setPlayerControl(ui.useVideoTransitions, value === "video");
        else if (key === "frequency") {
          setPlayerControl(ui.adaptiveTransitionTime, value === "relaxed" ? "long" : value === "energetic" ? "short" : "medium");
          setPlayerControl(ui.shuffleSeconds, value === "relaxed" ? "75" : value === "energetic" ? "25" : "45");
        } else config[key] = value;
        afterSettingChange();
        return;
      }
      const act = event.target.closest("[data-act]")?.dataset.act;
      if (act === "bitrate-auto") { config.bitrateMbps = null; afterSettingChange(); }
      if (act === "framing-reset") { Object.assign(config, { framingX: 0, framingY: 0, framingZoom: 1 }); afterSettingChange(); }
    });
    drawer.addEventListener("input", (event) => {
      const el = event.target;
      const key = el.dataset?.bind;
      if (!key) return;
      const value = el.type === "range" || el.type === "number" || /^\d+$/.test(el.value) ? Number(el.value) : el.value;
      config[key] = value;
      if (el.type === "range") {
        const outputEl = el.closest(".field").querySelector("output");
        if (outputEl) outputEl.textContent = key === "bitrateMbps" ? `${value} Mbps` : `${Number(value).toFixed(2)}${key === "framingZoom" ? "×" : ""}`;
        persist(); renderSummary(); updatePreviewMeta(); renderAdvancedBadge(); capturePoster();
        return;
      }
      if (el.type === "number") { persist(); renderSummary(); updatePreviewMeta(); return; }
      afterSettingChange();
    });
    drawer.addEventListener("change", (event) => { if (event.target.type === "range" || event.target.type === "number") renderDrawer(); });
    $("xsDrawerClose").onclick = closeDrawer;
    $("xsDrawerDone").onclick = closeDrawer;
    $("xsDrawerReset").onclick = () => {
      config = { ...defaultStudioConfig(config.format), platform: config.platform, format: config.format, customWidth: config.customWidth, customHeight: config.customHeight };
      setPlayerControl(ui.useVideoTransitions, false);
      setPlayerControl(ui.adaptiveTransitionTime, "medium");
      setPlayerControl(ui.shuffleSeconds, "45");
      afterSettingChange();
      toast("Advanced settings reset. Your music range and timeline are unchanged.");
    };
  }
  function afterSettingChange() {
    persist();
    renderDrawer(); renderSummary(); updatePreviewMeta(); renderAdvancedBadge(); capturePoster();
    journey?.redraw?.();
  }
  function renderAdvancedBadge() {
    const n = advancedChanges().length;
    $("xsAdvancedCount").hidden = n === 0;
    $("xsAdvancedCount").textContent = String(n);
  }

  /* ── Validation, summary, save ── */
  function fallbackTrackName() {
    return String(getTrackName?.() || "").replace(/\.[^.]+$/, "") || "Cyanescent Music Video";
  }
  function setDefaultFileName() {
    $("exportFileName").value = `${fallbackTrackName()} – ${format().short}`;
  }
  function sanitizedFileName() {
    const raw = String($("exportFileName").value || "").trim().replace(/\.(mp4|mov|webm)$/i, "");
    const clean = raw.replace(/[/:\\]/g, "-") || fallbackTrackName();
    return `${clean}.mp4`;
  }
  function selectedPath() {
    const dir = currentDirectory();
    return dir ? `${dir}/${sanitizedFileName()}` : "";
  }
  function currentDirectory() {
    const path = String(exportState?.outputPath || "");
    if (path) return path.replace(/\/[^/]*$/, "");
    return outputDirectory;
  }
  function folderLabel(dir) {
    if (!dir) return "Choose…";
    const parts = dir.replace(/^\/Users\/[^/]+/, "~").split("/").filter(Boolean);
    return parts.slice(-2).join(" › ") || dir;
  }
  function validation() {
    const r = range();
    const rangeCheck = validateExportRange(r);
    if (!duration()) return { valid: false, error: "Load a track to export a music video." };
    if (!rangeCheck.valid) return { valid: false, error: rangeCheck.error };
    if (!String($("exportFileName").value || "").trim()) return { valid: false, error: "Enter a file name." };
    try {
      validateExportCapabilities({ ...studioOutputFields(config, edition), duration: r.mode === "selected" ? r.end - r.start : r.trackDuration }, edition);
    } catch (error) {
      return { valid: false, error: error?.message || String(error) };
    }
    return { valid: true, error: "" };
  }
  function estimateSize(len) {
    const out = output();
    const audio = out.silent ? 0 : config.audioFormat === "aac" ? Number(config.audioBitrateKbps) / 1000 : 1.4;
    const codec = config.codec === "h265" ? 0.65 : 1;
    const bytes = ((out.bitrateMbps * codec + audio) * 1e6 / 8) * len;
    return bytes > 1e9 ? `${(bytes / 1e9).toFixed(1)} GB` : `${Math.max(1, Math.round(bytes / 1e6))} MB`;
  }
  function renderSummary() {
    const f = format();
    const out = output();
    const r = range();
    const len = r.mode === "selected" ? Math.max(0, r.end - r.start) : duration();
    const codec = config.codec === "h265" ? "H.265" : "H.264";
    $("xsSumLine1").innerHTML = `${f.short} · ${resolutionLabel()} · ${out.fps} fps · ${codec}${mode === "custom" ? ' <span style="color:var(--muted);font-weight:500">▾</span>' : ""}`;
    let what;
    if (mode === "custom") {
      what = `${r.mode === "selected" ? `Range ${fmt(r.start)}–${fmt(r.end)} (${formatStudioDuration(len)})` : `Entire track ${fmt(len)}`} · ${journey?.summary?.() || "Custom timeline"}`;
    } else if (r.mode === "selected") {
      what = `Selected clip · ${formatStudioDuration(len)} (${fmt(r.start)}–${fmt(r.end)}) · ${$("xsVisualBehaviour").value === "static" ? presetName(getActivePreset?.()) : $("xsVisualBehaviour").value === "shuffle" ? "Shuffled visuals" : "Automatic visuals"}`;
    } else {
      what = `Entire track · ${fmt(len)} · ${$("xsVisualBehaviour").value === "static" ? presetName(getActivePreset?.()) : $("xsVisualBehaviour").value === "shuffle" ? "Shuffled visuals" : "Automatic visuals"}`;
    }
    $("xsSumLine2").textContent = `${what} · ≈ ${estimateSize(len)}${out.silent ? " · silent" : ""}`;
    const result = validation();
    $("xsExportBlocker").hidden = result.valid;
    $("xsExportBlocker").textContent = result.error;
    $("startExportVideo").disabled = !result.valid || Boolean(exportState?.active);
    const dir = currentDirectory();
    $("xsFolderName").textContent = folderLabel(dir);
    $("chooseExportLocation").title = dir ? `${dir} · click to choose another location` : "Choose where to save";
    renderAdvancedBadge();
    return result;
  }

  function chooseLocation({ thenExport = false } = {}) {
    pendingExportAfterLocation = thenExport;
    const nativeApp = nativeAppBridge?.();
    if (!nativeApp) {
      setProgress(0, "Music video export requires the macOS app.");
      return;
    }
    nativeApp.postMessage({ command: "chooseExportLocation", fileName: sanitizedFileName(), format: config.codec });
  }
  window.__exportLocationChosen = (payload) => {
    if (!payload?.path) { pendingExportAfterLocation = false; return; }
    exportState.outputPath = payload.path.replace(/\.[^/.]+$/, ".mp4");
    outputDirectory = exportState.outputPath.replace(/\/[^/]*$/, "");
    if (payload.fileName) { $("exportFileName").value = payload.fileName.replace(/\.[^/.]+$/, ""); fileNameEdited = true; }
    persist();
    renderSummary();
    if (pendingExportAfterLocation) { pendingExportAfterLocation = false; beginExport(); }
  };

  /* ── Export, progress, completion ── */
  function setFooter(state) {
    $("xsFootReady").hidden = state !== "ready";
    $("xsFootProgress").hidden = state !== "progress";
    $("xsFootDone").hidden = state !== "done";
  }
  // The runtime's progress line is long and technical; show a short readable
  // version and keep the full text (render size, supersampling) as a tooltip.
  function friendlyStatus(status) {
    const text = String(status || "");
    const m = text.match(/Rendering frame (\d+)\/(\d+) at ([\d:]+) \/ ([\d:]+)\. Elapsed ([\d:]+), ETA ([\d:]+)/);
    if (m) {
      const n = (v) => Number(v).toLocaleString();
      return `Frame ${n(m[1])} of ${n(m[2])} · ${m[3]} of ${m[4]} · about ${m[6]} left`;
    }
    return text.replace(/\s*Rendering \d+x\d+ -> [^.]*\.?(\s*Canvas[^.]*\.?)?(\s*framebuffer[^.]*\.?)?/i, "").trim() || text;
  }
  function setProgress(value, status) {
    const percent = clamp(Number(value) || 0, 0, 100);
    $("exportProgress").value = percent;
    $("exportProgressText").textContent = `${percent.toFixed(percent < 10 && percent > 0 ? 1 : 0)}%`;
    if (status) {
      $("exportStatus").textContent = friendlyStatus(status);
      $("exportStatus").title = status;
    }
    if (exportState?.active) {
      setFooter("progress");
      $("xsProgTitle").textContent = `Rendering ${sanitizedFileName()}`;
    } else if (status && !/^Ready/.test(status)) {
      // Messages outside an export (a missing track, a validation problem) appear by the button.
      $("xsExportBlocker").hidden = false;
      $("xsExportBlocker").textContent = status;
    }
  }
  async function beginExport() {
    if (exportState?.active || exportStarting) return;
    const check = renderSummary();
    if (!check.valid) return;
    if (!currentDirectory()) { chooseLocation({ thenExport: true }); return; }
    exportState.outputPath = selectedPath();
    exportStarting = true;
    journey?.endAudition?.();
    closeBigPreview();
    // Show progress straight away: a preview frame that is still rendering finishes first.
    setFooter("progress");
    $("xsProgTitle").textContent = `Rendering ${sanitizedFileName()}`;
    $("exportStatus").textContent = "Preparing…";
    $("exportProgress").value = 0;
    $("exportProgressText").textContent = "0%";
    let result = null;
    try {
      stopLivePreview();
      window.clearTimeout(stillTimer);
      stillToken += 1;
      await whenPreviewIdle();
      result = await startExport?.();
    } catch (error) {
      result = { success: false, error };
    } finally {
      exportStarting = false;
    }
    notifyExportResult(result);
  }
  function notifyExportResult(result) {
    if (result?.success) {
      setFooter("done");
      const path = result.path || exportState.savedPath || exportState.outputPath;
      $("xsDoneTitle").textContent = "Video saved";
      $("xsDoneDetail").textContent = `${path.split("/").pop()} · ${folderLabel(path.replace(/\/[^/]*$/, ""))}`;
      return;
    }
    setFooter("ready");
    renderSummary();
    if (result?.cancelled) toast("Export cancelled. Your settings are unchanged.");
    else if (result?.error) {
      $("xsExportBlocker").hidden = false;
      $("xsExportBlocker").textContent = `Export failed: ${result.error?.message || result.error}`;
    } else {
      const status = $("exportStatus").textContent;
      if (status && !/complete|Ready/i.test(status)) { $("xsExportBlocker").hidden = false; $("xsExportBlocker").textContent = status; }
    }
  }

  /* ── Popovers, toast ── */
  function placePopover(pop, anchor, { above = true } = {}) {
    const rootRect = root.getBoundingClientRect();
    const anchorRect = anchor.getBoundingClientRect();
    pop.hidden = false;
    const popRect = pop.getBoundingClientRect();
    const left = clamp(anchorRect.left - rootRect.left, 8, root.offsetWidth - popRect.width - 8);
    pop.style.left = `${left}px`;
    pop.style.top = above ? `${anchorRect.top - rootRect.top - popRect.height - 8}px` : `${anchorRect.bottom - rootRect.top + 8}px`;
  }
  function openDestPopover() {
    const pop = $("xsDestPop");
    pop.innerHTML = `<div class="dest-cards"></div><div class="format-row"></div>`;
    renderDestCards(pop.querySelector(".dest-cards"), true);
    renderFormatRow(pop.querySelector(".format-row"));
    placePopover(pop, $("xsSumLine1"));
  }
  function toast(html) {
    const el = $("xsToast");
    el.innerHTML = html;
    el.hidden = false;
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => { el.hidden = true; }, 2600);
  }
  function closePopovers() {
    $("xsDestPop").hidden = true;
    journey?.closeMenus?.();
  }

  /* ── Mode, layout, render ── */
  function isOpen() {
    return !ui.exportOverlay?.classList.contains("hidden");
  }
  function setMode(next) {
    if (next === mode) return;
    stopLivePreview();
    mode = next;
    root.dataset.mode = mode;
    for (const button of root.querySelectorAll(".seg-mode button")) button.setAttribute("aria-selected", String(button.dataset.mode === mode));
    closePopovers();
    journey?.setActive?.(mode === "custom");
    render();
  }
  function renderAuto() {
    renderDestCards($("xsDestCards"));
    renderFormatRow($("xsFormatRow"));
    const f = format();
    const r = range();
    for (const button of $("xsRangeSeg").children) {
      const active = button.dataset.range === (r.mode === "selected" ? "clip" : "full");
      button.setAttribute("aria-checked", String(active));
      button.disabled = button.dataset.range === "full" && f.kind === "canvas";
    }
    $("xsFullDur").textContent = fmt(duration());
    $("xsCanvasNote").hidden = f.kind !== "canvas";
    $("xsClipEditor").hidden = r.mode !== "selected";
    $("xsFullInfo").hidden = r.mode === "selected";
    const longHint = r.mode !== "selected" && f.maxHint && duration() > f.maxHint;
    $("xsFullInfoText").innerHTML = !duration()
      ? "Load a track in the player to export it."
      : longHint
        ? `${fmt(duration())} · ${f.note || `${f.short} works best with shorter videos.`} <button type="button" class="link-btn" data-act="to-clip">Choose a clip</button>`
        : `The whole track, ${fmt(duration())}, from start to finish.`;
    renderVisuals();
    renderClipFields();
  }
  function render() {
    if (!isOpen()) return;
    $("exportTrackName").textContent = fallbackTrackName();
    $("exportTrackDuration").textContent = fmt(duration());
    if (mode === "auto") renderAuto();
    renderSummary();
    renderDrawer();
    window.requestAnimationFrame(() => {
      layout();
      if (mode === "custom") journey?.render?.();
    });
  }
  function layout() {
    const h = root.offsetHeight;
    root.style.setProperty("--clip-wave-h", `${Math.round(clamp(h * 0.18, 116, 160))}px`);
    journey?.layout?.(h);
    window.requestAnimationFrame(() => {
      if (mode === "auto") drawClip(); else journey?.redraw?.();
      updatePreviewMeta();
    });
  }

  /* ── Wiring ── */
  function bind() {
    for (const button of root.querySelectorAll(".seg-mode button")) button.addEventListener("click", () => setMode(button.dataset.mode));
    const destinationClick = (event) => {
      const card = event.target.closest("[data-platform]");
      const fmtButton = event.target.closest("[data-format]");
      if (card) setDestination(card.dataset.platform);
      if (fmtButton) setDestination(config.platform, fmtButton.dataset.format);
      if ((card || fmtButton) && !$("xsDestPop").hidden) openDestPopover();
    };
    $("xsDestCards").addEventListener("click", destinationClick);
    $("xsFormatRow").addEventListener("click", destinationClick);
    $("xsDestPop").addEventListener("click", destinationClick);
    $("xsRangeSeg").addEventListener("click", (event) => {
      const button = event.target.closest("[data-range]");
      if (button && !button.disabled) setRangeMode(button.dataset.range);
    });
    root.addEventListener("click", (event) => {
      if (event.target.closest("[data-act='to-clip']")) setRangeMode("clip");
      const advanced = event.target.closest("[data-open-advanced]");
      if (advanced) openDrawer(advanced.dataset.openAdvanced);
      // Clicks inside a popover that re-rendered itself land on detached nodes; keep it open.
      if (event.target.isConnected && !event.target.closest(".popover, #xsSumLine1, #xsSeqBtn")) closePopovers();
    });
    $("xsVisualBehaviour").addEventListener("change", (event) => {
      const value = event.target.value;
      setPlayerControl(ui.transitionMode, value);
      render();
      capturePoster();
    });
    $("xsSinglePreset").addEventListener("change", (event) => {
      const id = Number(event.target.value);
      // Applied at once; open preview sessions adopt it, and a playing preview restarts with it.
      selectPreset?.(id);
      renderSummary();
      capturePoster();
    });
    $("xsPreviewPlay").onclick = () => togglePreviewPlayback();
    $("xsPreviewBigAuto").onclick = () => openBigPreview();
    $("xsBigClose").onclick = () => closeBigPreview();
    $("xsBigPlay").onclick = () => togglePlaybackForMode();
    $("xsBigAudition").onclick = () => (journey?.auditioning?.() ? journey.stopAudition() : journey?.previewCandidate?.());
    $("xsBigSeek").addEventListener("input", (event) => {
      const span = seekSpan();
      const t = span.a + (Number(event.target.value) / 1000) * (span.b - span.a);
      if (journey?.auditioning?.()) journey.endAudition();
      seekAudio?.(clamp(t, 0, duration()));
      updateBigTransport();
      if (mode === "custom") journey?.redraw?.();
      if (!previewLive) capturePoster();
    });
    $("xsGuidesToggle").onchange = (event) => { showGuides = event.target.checked; updatePreviewMeta(); };
    $("xsAdvancedBtn").onclick = () => ($("xsDrawer").hidden ? openDrawer() : closeDrawer());
    $("xsSumLine1").onclick = () => {
      if (mode === "custom") { $("xsDestPop").hidden ? openDestPopover() : closePopovers(); return; }
      $("xsStepDest").scrollIntoView({ behavior: "smooth", block: "start" });
    };
    $("chooseExportLocation").onclick = () => chooseLocation();
    $("exportFileName").addEventListener("input", () => { fileNameEdited = true; renderSummary(); });
    $("startExportVideo").onclick = () => beginExport();
    $("cancelExportVideo").onclick = () => cancelExport?.();
    $("xsRevealVideo").onclick = () => revealExportedVideo?.(exportState.savedPath || exportState.outputPath);
    $("xsDoneBack").onclick = () => { setFooter("ready"); renderSummary(); };

    root.addEventListener("keydown", (event) => {
      const typing = event.target.closest?.("input, select, textarea");
      if (event.key === "Escape") {
        event.stopPropagation();
        if (bigOpen) return closeBigPreview();
        if (!$("xsDestPop").hidden || journey?.menusOpen?.()) return closePopovers();
        if (!$("xsDrawer").hidden) return closeDrawer();
        if (mode === "custom" && journey?.escape?.()) return;
        return;
      }
      if (typing) return;
      if (event.key === " ") { event.preventDefault(); event.stopPropagation(); togglePlaybackForMode(); return; }
      if (!event.metaKey && !event.ctrlKey && !event.altKey && event.key.toLowerCase() === "f") { event.preventDefault(); event.stopPropagation(); bigOpen ? closeBigPreview() : openBigPreview(); return; }
      if (bigOpen) return;
      if (mode === "custom") { if (journey?.handleKey?.(event)) { event.preventDefault(); event.stopPropagation(); } return; }
      if (range().mode === "selected" && (event.key.toLowerCase() === "i" || event.key.toLowerCase() === "o")) {
        const r = range();
        const t = currentTime();
        if (event.key.toLowerCase() === "i") setClip(t, Math.max(r.end, t + 1)); else setClip(r.start, t);
        event.stopPropagation();
      }
    });

    exportRangeModel.subscribe(() => {
      if (!isOpen()) return;
      if (mode === "auto") { renderAuto(); drawClip(); } else journey?.rangeChanged?.();
      renderSummary();
      // The preview renders the selected range: refresh the still, or the playing session.
      capturePoster();
    }, { immediate: false });
    const audio = getPlaybackAudio?.();
    if (audio) {
      for (const name of ["play", "pause", "ended"]) audio.addEventListener(name, () => syncPlayButtons());
      // Live preview ends when the music actually stops, not on intermediate button refreshes.
      // The event arrives after the fact: ignore it if playback has already resumed
      // (an audition or a transition replay pauses and restarts the music).
      for (const name of ["pause", "ended"]) audio.addEventListener(name, () => {
        window.setTimeout(() => { if (previewLive && (audio.paused || audio.ended)) stopLivePreview(); }, 250);
      });
    }
    new ResizeObserver(() => { if (isOpen()) layout(); }).observe(root);
    new ResizeObserver(() => { if (bigOpen) { layoutBig(); capturePoster(); } }).observe($("xsBigStage"));
    bindClipEditor();
    bindDrawer();
  }

  function openDialog() {
    // The preview is drawn here; keep the separate visualiser window out of the way.
    holdVisualiserHidden?.(true);
    ui.exportOverlay?.classList.remove("hidden");
    exportRangeModel.setTrackDuration(duration(), { preserveSelection: true });
    if (format().kind === "canvas") enforceCanvasClip();
    if (!fileNameEdited) setDefaultFileName();
    if (!exportState.outputPath && outputDirectory) exportState.outputPath = `${outputDirectory}/${sanitizedFileName()}`;
    if (!clipView.dur || clipView.dur > duration()) fitClipView();
    setFooter("ready");
    render();
    journey?.setActive?.(mode === "custom");
    window.setTimeout(capturePoster, 60);
    if (restoreNotice) { toast(restoreNotice); restoreNotice = ""; }
    if (!nativeAppBridge?.()) setProgress(0, "Music video export requires the macOS app.");
  }
  function closeDialog() {
    if (exportState?.active) return;
    journey?.endAudition?.();
    closeBigPreview();
    stopLivePreview();
    closeDrawer();
    closePopovers();
    ui.exportOverlay?.classList.add("hidden");
    holdVisualiserHidden?.(false);
  }

  bind();

  const api = {
    // Contract used by app.js and the export runtime.
    selectedPath,
    updateFileNameExtension: () => {},
    setProgress,
    updateSummary: () => renderSummary(),
    exportOptionsFields: () => studioOutputFields(config, edition, { showGuides }),
    exportOptions: () => exportOptionsFromUi(ui),
    redrawCanvases: () => { if (mode === "auto") drawClip(); else journey?.redraw?.(); },
    exportRange: () => range(),
    validate: () => validation(),
    openDialog,
    closeDialog,
    chooseLocation: () => chooseLocation(),
    notifyExportResult,
    whenPreviewIdle,
    // Studio state.
    mode: () => mode,
    isCustom: () => mode === "custom",
    setMode,
    config: () => ({ ...config }),
    setDestination,
    setRangeMode,
    openDrawer,
    closeDrawer,
    render,
    layout,
    toast,
    capturePoster,
    startLivePreview,
    refreshLivePreview,
    updatePreviewMeta: () => updatePreviewState(),
    openBigPreview,
    closeBigPreview,
    bigPreviewOpen: () => bigOpen,
    stopLivePreview,
    syncPlayButtons,
    attachJourney(editor) { journey = editor; },
    fmt,
    hoursFormat,
    presetName,
    placePopover,
    currentTime,
    isOpen
  };
  ui.__exportStudio = api;
  return api;
}
