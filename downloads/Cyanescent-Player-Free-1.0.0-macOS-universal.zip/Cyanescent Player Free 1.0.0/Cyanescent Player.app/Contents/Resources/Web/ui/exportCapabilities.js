import { editionConfig } from "../generated/editionConfig.js";

// One registry drives the Export Studio, quick export and the runtime gate.
// Keep the encoder settings deliberately conservative: they are the settings
// already exposed by the native AVFoundation exporter, not a second encoder.
export const EXPORT_DESTINATION_PRESETS = Object.freeze([
  Object.freeze({
    id: "youtube-hd-30",
    label: "YouTube HD 30",
    description: "Landscape YouTube and general video",
    width: 1920,
    height: 1080,
    fps: 30,
    bitrateMbps: 12,
    editions: ["free", "pro"]
  }),
  Object.freeze({
    id: "youtube-hd-60",
    label: "YouTube HD 60",
    description: "Landscape YouTube and general video",
    width: 1920,
    height: 1080,
    fps: 60,
    bitrateMbps: 18,
    editions: ["free", "pro"]
  }),
  Object.freeze({
    id: "vertical-social-30",
    label: "Vertical Social 30",
    description: "TikTok, Shorts, Reels and Facebook Reels",
    width: 1080,
    height: 1920,
    fps: 30,
    bitrateMbps: 12,
    editions: ["free", "pro"]
  }),
  Object.freeze({
    id: "vertical-social-60",
    label: "Vertical Social 60",
    description: "TikTok, Shorts, Reels and Facebook Reels",
    width: 1080,
    height: 1920,
    fps: 60,
    bitrateMbps: 18,
    editions: ["free", "pro"]
  }),
  Object.freeze({
    id: "instagram-feed-portrait",
    label: "Instagram Feed Portrait",
    description: "4:5 Instagram feed post",
    width: 1080,
    height: 1350,
    fps: 30,
    bitrateMbps: 12,
    editions: ["free", "pro"]
  }),
  Object.freeze({
    id: "square-social",
    label: "Square Social",
    description: "Square social post",
    width: 1080,
    height: 1080,
    fps: 30,
    bitrateMbps: 12,
    editions: ["free", "pro"]
  }),
  Object.freeze({
    id: "spotify-canvas",
    label: "Spotify Canvas",
    description: "Silent vertical loop, 3–8 seconds",
    width: 1080,
    height: 1920,
    fps: 30,
    bitrateMbps: 12,
    includeAudio: false,
    canvas: true,
    editions: ["free", "pro"]
  }),
  Object.freeze({
    id: "youtube-1440p-30",
    label: "YouTube 1440p 30",
    description: "1440p landscape YouTube",
    width: 2560,
    height: 1440,
    fps: 30,
    bitrateMbps: 24,
    editions: ["pro"]
  }),
  Object.freeze({
    id: "youtube-1440p-60",
    label: "YouTube 1440p 60",
    description: "1440p landscape YouTube",
    width: 2560,
    height: 1440,
    fps: 60,
    bitrateMbps: 32,
    editions: ["pro"]
  }),
  Object.freeze({
    id: "youtube-4k-30",
    label: "YouTube 4K 30",
    description: "4K landscape YouTube",
    width: 3840,
    height: 2160,
    fps: 30,
    bitrateMbps: 42,
    editions: ["pro"]
  }),
  Object.freeze({
    id: "youtube-4k-60",
    label: "YouTube 4K 60",
    description: "4K landscape YouTube",
    width: 3840,
    height: 2160,
    fps: 60,
    bitrateMbps: 68,
    editions: ["pro"]
  })
]);

export const CUSTOM_DESTINATION_ID = "custom";
export const DEFAULT_DESTINATION_ID = "youtube-hd-60";
export const SUPPORTED_EXPORT_FPS = Object.freeze([24, 25, 30, 50, 60]);

export const QUICK_EXPORT_DESTINATION_IDS = Object.freeze({
  free: Object.freeze(["youtube-hd-30", "youtube-hd-60"]),
  pro: Object.freeze([
    "youtube-hd-30",
    "youtube-hd-60",
    "youtube-1440p-30",
    "youtube-1440p-60",
    "youtube-4k-30",
    "youtube-4k-60"
  ])
});

// Preview-only safe areas. Ratios are expressed in output-frame coordinates;
// no guide is ever passed to frame capture.
export const SAFE_AREA_GUIDES = Object.freeze({
  none: Object.freeze({ id: "none", label: "No guide", boxes: [] }),
  off: Object.freeze({ id: "off", label: "No guide", boxes: [] }),
  vertical: Object.freeze({
    id: "vertical",
    label: "Generic vertical (approximate)",
    boxes: [Object.freeze({ x: 0.08, y: 0.06, width: 0.84, height: 0.88, label: "Keep key visuals here" })]
  }),
  tiktok: Object.freeze({
    id: "tiktok",
    label: "TikTok (approximate)",
    boxes: [Object.freeze({ x: 0.08, y: 0.10, width: 0.70, height: 0.74, label: "Avoid UI zones" })]
  }),
  instagramReels: Object.freeze({
    id: "instagramReels",
    label: "Instagram Reels (approximate)",
    boxes: [Object.freeze({ x: 0.08, y: 0.10, width: 0.78, height: 0.77, label: "Keep text visible" })]
  }),
  "instagram-reels": Object.freeze({
    id: "instagram-reels",
    label: "Instagram Reels (approximate)",
    boxes: [Object.freeze({ x: 0.08, y: 0.10, width: 0.78, height: 0.77, label: "Keep text visible" })]
  }),
  youtubeShorts: Object.freeze({
    id: "youtubeShorts",
    label: "YouTube Shorts (approximate)",
    boxes: [Object.freeze({ x: 0.08, y: 0.08, width: 0.84, height: 0.80, label: "Keep key visuals here" })]
  }),
  "youtube-shorts": Object.freeze({
    id: "youtube-shorts",
    label: "YouTube Shorts (approximate)",
    boxes: [Object.freeze({ x: 0.08, y: 0.08, width: 0.84, height: 0.80, label: "Keep key visuals here" })]
  })
});

export function exportEditionId(config = editionConfig) {
  return config?.videoExport?.allow4K === false ? "free" : "pro";
}

export function destinationPresetById(id) {
  return EXPORT_DESTINATION_PRESETS.find((preset) => preset.id === id) || null;
}

export function destinationsForEdition(config = editionConfig) {
  const edition = exportEditionId(config);
  return EXPORT_DESTINATION_PRESETS.filter((preset) => preset.editions.includes(edition));
}

export function firstValidDestination(config = editionConfig) {
  return destinationsForEdition(config).find((preset) => preset.id === DEFAULT_DESTINATION_ID)
    || destinationsForEdition(config)[0]
    || null;
}

export function destinationIsAvailable(id, config = editionConfig) {
  return Boolean(destinationsForEdition(config).find((preset) => preset.id === id));
}

export function outputDimensions(width, height) {
  return {
    width: Math.round(Number(width) || 0),
    height: Math.round(Number(height) || 0)
  };
}

export function outputAspectRatio(width, height) {
  const size = outputDimensions(width, height);
  return size.height > 0 ? size.width / size.height : 0;
}

export function outputAspectRatioLabel(width, height) {
  const ratio = outputAspectRatio(width, height);
  if (!ratio) return "—";
  const common = [
    [16 / 9, "16:9"],
    [9 / 16, "9:16"],
    [4 / 5, "4:5"],
    [1, "1:1"]
  ];
  const match = common.find(([value]) => Math.abs(value - ratio) < 0.012);
  return match ? match[1] : `${ratio.toFixed(2)}:1`;
}

export function isSpotifyCanvasDestination(destination) {
  return Boolean(destination?.canvas || destination?.id === "spotify-canvas");
}

export function normaliseExportOutput(options = {}, config = editionConfig) {
  const destination = destinationPresetById(options.destinationId || options.presetId);
  const defaultDestination = firstValidDestination(config);
  const selected = destination && destinationIsAvailable(destination.id, config)
    ? destination
    : defaultDestination;
  const custom = (options.destinationId || options.presetId) === CUSTOM_DESTINATION_ID;
  // Runtime validation must honour explicit dimensions even when a stale or
  // altered destination id is present. The UI writes preset dimensions, but
  // this makes the real export path authoritative.
  const width = Number.isFinite(Number(options.width)) && Number(options.width) > 0
    ? Number(options.width)
    : selected?.width;
  const height = Number.isFinite(Number(options.height)) && Number(options.height) > 0
    ? Number(options.height)
    : selected?.height;
  const fps = Number.isFinite(Number(options.fps)) && Number(options.fps) > 0
    ? Number(options.fps)
    : selected?.fps;
  return {
    ...options,
    destinationId: custom ? CUSTOM_DESTINATION_ID : (selected?.id || DEFAULT_DESTINATION_ID),
    width: Math.round(width || 0),
    height: Math.round(height || 0),
    fps: Math.round(fps || 0),
    bitrateMbps: Number(options.bitrateMbps) || selected?.bitrateMbps || 18,
    includeAudio: isSpotifyCanvasDestination(selected) ? false : options.includeAudio !== false,
    spotifyCanvas: isSpotifyCanvasDestination(selected)
  };
}

export function exportDimensionError(options = {}, config = editionConfig) {
  const { width, height } = outputDimensions(options.width, options.height);
  if (!Number.isFinite(width) || !Number.isFinite(height) || width < 2 || height < 2) {
    return "Choose valid output dimensions.";
  }
  if (width % 2 || height % 2) {
    return "Output dimensions must be even for the native MP4 encoder.";
  }
  const shortSide = Math.min(width, height);
  const longSide = Math.max(width, height);
  if (exportEditionId(config) === "free") {
    if (shortSide > 1080 || longSide > 1920) {
      return "The Free edition supports video export up to 1920×1080 or 1080×1920. Choose a 1080p-class export preset.";
    }
    return "";
  }
  const limits = config?.videoExport || {};
  const maxShort = Math.min(Number(limits.maxLandscapeHeight) || 2160, Number(limits.maxPortraitWidth) || 2160);
  const maxLong = Math.max(Number(limits.maxLandscapeWidth) || 3840, Number(limits.maxPortraitHeight) || 3840);
  const maxPixels = Number(limits.maxPixels) || 3840 * 2160;
  if (shortSide > maxShort || longSide > maxLong || width * height > maxPixels) {
    return "This exporter supports custom output up to its tested 4K envelope (3840×2160 landscape or 2160×3840 portrait).";
  }
  return "";
}

export function exportFrameRateError(fps) {
  const value = Math.round(Number(fps) || 0);
  return SUPPORTED_EXPORT_FPS.includes(value)
    ? ""
    : `Choose one of the supported frame rates: ${SUPPORTED_EXPORT_FPS.join(", ")} fps.`;
}

export function validateExportCapabilities(options = {}, config = editionConfig) {
  const normalized = normaliseExportOutput(options, config);
  const dimensionError = exportDimensionError(normalized, config);
  if (dimensionError) throw new Error(dimensionError);
  const rateError = exportFrameRateError(normalized.fps);
  if (rateError) throw new Error(rateError);
  if (normalized.spotifyCanvas) {
    if (normalized.width !== 1080 || normalized.height !== 1920 || normalized.fps !== 30) {
      throw new Error("Spotify Canvas exports use 1080×1920 at 30 fps.");
    }
    const duration = Number(options.duration);
    if (!Number.isFinite(duration) || duration < 3 - 0.0001 || duration > 8 + 0.0001) {
      throw new Error("Spotify Canvas requires a selected section between 3 and 8 seconds.");
    }
    normalized.includeAudio = false;
  }
  return normalized;
}

export function quickExportDestinations(config = editionConfig) {
  const edition = exportEditionId(config);
  return QUICK_EXPORT_DESTINATION_IDS[edition]
    .map(destinationPresetById)
    .filter(Boolean);
}
