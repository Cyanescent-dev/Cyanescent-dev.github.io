export function createPerformanceMeterState() {
  return {
    lastFrameAt: 0,
    frameMs: 16.7,
    fps: 60,
    lastUiAt: 0
  };
}

export function updatePerformanceMeterView({
  element,
  state,
  now,
  renderMs,
  width,
  height,
  onSample
}) {
  if (!element || !state) return;
  if (state.lastFrameAt > 0) {
    const frameDelta = Math.max(1, now - state.lastFrameAt);
    const instantFps = 1000 / frameDelta;
    state.fps = state.fps * 0.88 + instantFps * 0.12;
  }
  state.lastFrameAt = now;
  state.frameMs = state.frameMs * 0.86 + renderMs * 0.14;
  if (now - state.lastUiAt < 450) return;
  state.lastUiAt = now;
  const frameBudget = 1000 / 60;
  const load = Math.min(199, Math.round(state.frameMs / frameBudget * 100));
  const fps = Math.round(state.fps);
  onSample?.(fps, load, state.frameMs);
  element.textContent = `FPS ${fps} | Render ${load}% | ${width}x${height}`;
  element.classList.toggle("hot", load >= 85 || fps < 50);
}

export function createPerfTestState(search = window.location.search) {
  return {
    enabled: new URLSearchParams(search).get("perfTest") === "1",
    running: false,
    presetIds: [],
    index: 0,
    startedAt: 0,
    current: null
  };
}

export function resetPerfSample({
  state,
  presetId,
  metadata,
  width,
  height
}) {
  if (!state) return null;
  const preset = metadata?.find?.((item) => item.id === Number(presetId));
  state.current = {
    id: Number(presetId),
    name: preset?.name || `Preset ${presetId}`,
    samples: 0,
    fpsSum: 0,
    fpsMin: Infinity,
    fpsMax: 0,
    loadSum: 0,
    loadMax: 0,
    renderMsSum: 0,
    renderMsMax: 0,
    width,
    height
  };
  return state.current;
}

export function recordPerfSample({
  state,
  fps,
  load,
  renderMs,
  width,
  height,
  now = performance.now()
}) {
  if (!state?.running || !state.current) return;
  const elapsed = (now - state.startedAt) / 1000;
  if (elapsed < 3) return;
  const sample = state.current;
  sample.samples += 1;
  sample.fpsSum += fps;
  sample.fpsMin = Math.min(sample.fpsMin, fps);
  sample.fpsMax = Math.max(sample.fpsMax, fps);
  sample.loadSum += load;
  sample.loadMax = Math.max(sample.loadMax, load);
  sample.renderMsSum += renderMs;
  sample.renderMsMax = Math.max(sample.renderMsMax, renderMs);
  sample.width = width;
  sample.height = height;
}

export function perfSampleLogLine(sample) {
  if (!sample?.samples) return "";
  const avgFps = sample.fpsSum / sample.samples;
  const avgLoad = sample.loadSum / sample.samples;
  const avgRenderMs = sample.renderMsSum / sample.samples;
  return [
    `preset=${sample.id}`,
    `name="${sample.name}"`,
    `avg_fps=${avgFps.toFixed(1)}`,
    `min_fps=${sample.fpsMin.toFixed(0)}`,
    `max_fps=${sample.fpsMax.toFixed(0)}`,
    `avg_render_load=${avgLoad.toFixed(1)}%`,
    `peak_render_load=${sample.loadMax.toFixed(0)}%`,
    `avg_render_ms=${avgRenderMs.toFixed(2)}`,
    `peak_render_ms=${sample.renderMsMax.toFixed(2)}`,
    `render_resolution=${sample.width}x${sample.height}`
  ].join("\t");
}

export function appendPerfLogLine(line, nativeApp = null) {
  if (nativeApp) {
    nativeApp.postMessage({ command: "appendPerfLog", line });
  }
  console.log(line);
}

export function flushPerfSampleLog({ state, nativeApp = null }) {
  const line = perfSampleLogLine(state?.current);
  if (line) appendPerfLogLine(line, nativeApp);
  return line;
}

export function createPerformanceController({
  ui,
  nativeApp,
  metadata,
  presetIds,
  getRenderSize,
  setStaticTransitionMode,
  setRepeatOne,
  setPlayerQueue,
  activateVisuals,
  visualsReady,
  setPreset,
  clearFeedbackBuffers,
  primePreset,
  sampleDurationMs = 30000,
  waitIntervalMs = 250,
  maxWaitAttempts = 120
} = {}) {
  const meterState = createPerformanceMeterState();
  const perfTestState = createPerfTestState();

  function renderSize() {
    return getRenderSize?.() || { width: 0, height: 0 };
  }

  function resetPerfSampleForPreset(presetId) {
    const { width, height } = renderSize();
    return resetPerfSample({
      state: perfTestState,
      presetId,
      metadata,
      width,
      height
    });
  }

  function recordPerfSamplePoint(fps, load, renderMs) {
    const { width, height } = renderSize();
    recordPerfSample({
      state: perfTestState,
      fps,
      load,
      renderMs,
      width,
      height
    });
  }

  function updateMeter(now, renderMs) {
    const { width, height } = renderSize();
    updatePerformanceMeterView({
      element: ui.performanceMeter,
      state: meterState,
      now,
      renderMs,
      width,
      height,
      onSample: recordPerfSamplePoint
    });
  }

  function appendLog(line) {
    appendPerfLogLine(line, nativeApp?.());
  }

  function flushSample() {
    flushPerfSampleLog({ state: perfTestState, nativeApp: nativeApp?.() });
  }

  async function waitForVisuals() {
    activateVisuals?.(0);
    for (let i = 0; i < maxWaitAttempts; i += 1) {
      if (visualsReady?.()) return true;
      await new Promise((resolve) => window.setTimeout(resolve, waitIntervalMs));
    }
    return false;
  }

  function setPresetForPerfTest(presetId) {
    const activePreset = Number(presetId);
    setPreset?.(activePreset);
    primePreset?.(activePreset, 0);
    resetPerfSampleForPreset(activePreset);
    clearFeedbackBuffers?.();
    appendLog(`start_preset=${activePreset}\tname="${perfTestState.current?.name || ""}"`);
  }

  function runNextPreset() {
    flushSample();
    if (perfTestState.index >= perfTestState.presetIds.length) {
      perfTestState.running = false;
      appendLog(`end\t${new Date().toISOString()}`);
      ui.audioStatus.textContent = "perf complete";
      ui.audioDiagnostic.textContent = "Perf log written to Desktop/cyanescent-perfmon.log";
      return;
    }
    const presetId = perfTestState.presetIds[perfTestState.index];
    perfTestState.index += 1;
    perfTestState.startedAt = performance.now();
    setPresetForPerfTest(presetId);
    window.setTimeout(runNextPreset, sampleDurationMs);
  }

  async function start() {
    if (!perfTestState.enabled || perfTestState.running) return;
    ui.audioStatus.textContent = "perf test";
    ui.audioDiagnostic.textContent = "Loading Joyride.wav and testing every preset";
    appendLog("");
    appendLog(`start\t${new Date().toISOString()}`);
    appendLog("track=/Users/soulscientist/Desktop/Joyride.wav");
    appendLog("sample_window=30s_per_preset warmup=first_3s_excluded");
    try {
      setStaticTransitionMode?.();
      setRepeatOne?.();
      perfTestState.presetIds = presetIds?.() || [];
      await setPlayerQueue?.([{
        id: "joyride-perf-test",
        name: "Joyride.wav",
        url: `/perf-test-track?t=${Date.now()}`
      }], 0, true);
      const ready = await waitForVisuals();
      if (!ready) {
        appendLog("error=visual_engine_timeout");
        return;
      }
      perfTestState.running = true;
      perfTestState.index = 0;
      runNextPreset();
    } catch (error) {
      appendLog(`error=${error?.message || "unknown perf test error"}`);
      ui.audioStatus.textContent = "perf error";
      ui.audioDiagnostic.textContent = error?.message || "Perf test failed";
      console.error(error);
    }
  }

  return {
    state: perfTestState,
    enabled: () => perfTestState.enabled,
    updateMeter,
    start
  };
}
