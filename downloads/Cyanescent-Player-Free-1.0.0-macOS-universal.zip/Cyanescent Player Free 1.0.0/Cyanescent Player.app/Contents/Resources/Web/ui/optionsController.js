import { bindDefaultPlaylist } from "./defaultPlaylist.js";
import {
  adaptiveTransitionTimingPreset,
  applyOptionsToUi as applyOptionsToUiView,
  closeOptionsDialog as closeOptionsDialogView,
  debugModeEnabled as debugModeControlEnabled,
  loadAppOptions,
  openOptionsDialog as openOptionsDialogView,
  persistAppOptions,
  registerOptionsDialogHandlers,
  registerVisualSettingsHandlers,
  updateTransitionTimingControlVisibility,
  updateScionModeControlVisibility,
  updateAppOption
} from "./options.js";

export function createOptionsController({
  ui,
  defaultTransitionMode,
  ignorePersisted = false,
  playlistStore,
  onDebugModeApplied,
  onInputMeterChanged,
  onAlienVisitsChanged,
  refreshDevices,
  onAudioSourceSelected,
  onPresetSelected,
  onTransitionModeChanged,
  onShuffleSecondsChanged,
  onAdaptiveTransitionTimeChanged,
  onStandardQuality,
  onHighQuality
} = {}) {
  const options = loadAppOptions(defaultTransitionMode, { ignorePersisted });

  const refreshDefaultPlaylists = bindDefaultPlaylist({
    select: ui.defaultPlaylist, store: playlistStore, options,
    save: () => persistAppOptions(options)
  });

  function debugModeEnabled() {
    return debugModeControlEnabled(ui.debugMode);
  }

  function applyDebugMode() {
    onDebugModeApplied?.(debugModeEnabled());
  }

  function applyOptionsToUi() {
    applyOptionsToUiView({
      ui,
      options,
      defaultTransitionMode,
      onDebugModeApplied: applyDebugMode
    });
    updateScionModeControlVisibility(ui);
  }

  function openOptionsDialog() {
    refreshDefaultPlaylists();
    openOptionsDialogView(ui.optionsOverlay);
  }

  function closeOptionsDialog() {
    closeOptionsDialogView(ui.optionsOverlay);
  }

  function registerOptionHandlers() {
    registerOptionsDialogHandlers({
      ui,
      openDialog: openOptionsDialog,
      closeDialog: closeOptionsDialog,
      updateDebugMode: () => {
        updateAppOption(options, "debugMode", debugModeEnabled(), persistAppOptions);
        applyDebugMode();
      },
      updateInputMeter: () => {
        updateAppOption(options, "showInputMeter", ui.showInputMeter.checked, persistAppOptions);
        ui.inputMeter.classList.toggle("hidden", !ui.showInputMeter.checked);
        onInputMeterChanged?.();
      },
      updateVideoTransitions: () => {
        updateAppOption(options, "useVideoTransitions", Boolean(ui.useVideoTransitions?.checked), persistAppOptions);
        updateAppOption(options, "videoTransitionMode", ui.videoTransitionMode?.value || "auto", persistAppOptions);
        if (ui.useVideoTransitions) ui.useVideoTransitions.checked = Boolean(options.useVideoTransitions);
      },
      updateAlienVisits: () => {
        const active = ui.alienVisits?.checked !== false;
        updateAppOption(options, "alienVisits", active, persistAppOptions);
        if (ui.alienVisits) ui.alienVisits.checked = Boolean(options.alienVisits);
        onAlienVisitsChanged?.(options.alienVisits);
      }
    });
  }

  function registerVisualSettings() {
    registerVisualSettingsHandlers({
      ui,
      refreshDevices,
      selectAudioSource: onAudioSourceSelected,
      selectPreset: onPresetSelected,
      updateTransitionMode: (value) => {
        const transitionMode = value || defaultTransitionMode;
        updateAppOption(options, "transitionMode", transitionMode, persistAppOptions);
        updateTransitionTimingControlVisibility(ui, transitionMode);
        onTransitionModeChanged?.(transitionMode);
      },
      updateAdaptiveTransitionTime: (value) => {
        const preset = adaptiveTransitionTimingPreset(value);
        updateAppOption(options, "adaptiveTransitionTime", preset, persistAppOptions);
        if (ui.adaptiveTransitionTime) ui.adaptiveTransitionTime.value = preset;
        onAdaptiveTransitionTimeChanged?.(preset);
      },
      updateShuffleSeconds: (value) => {
        const seconds = Math.max(5, Math.min(600, Number(value) || 45));
        updateAppOption(options, "shuffleSeconds", seconds, persistAppOptions);
        if (ui.shuffleSeconds) ui.shuffleSeconds.value = String(options.shuffleSeconds);
        onShuffleSecondsChanged?.(seconds);
      },
      setStandardQuality: onStandardQuality,
      setHighQuality: onHighQuality
    });
  }

  return {
    options,
    refreshDefaultPlaylists,
    debugModeEnabled,
    applyOptionsToUi,
    registerOptionHandlers,
    registerVisualSettings,
    transitionMode: () => options.transitionMode || defaultTransitionMode,
    shuffleSeconds: () => Math.max(5, Math.min(600, Number(options.shuffleSeconds) || 45)),
    adaptiveTransitionTime: () => adaptiveTransitionTimingPreset(options.adaptiveTransitionTime)
  };
}
