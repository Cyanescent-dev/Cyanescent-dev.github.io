export function registerResizeHandler({ target = window, resize }) {
  if (!target || typeof resize !== "function") return;
  target.addEventListener("resize", resize);
}

export function registerUserInteractionTracker({
  target = window,
  onInteraction,
  eventNames = ["pointerdown", "keydown", "wheel", "touchstart"]
}) {
  if (!target || typeof onInteraction !== "function") return;
  for (const eventName of eventNames) {
    target.addEventListener(eventName, onInteraction, { capture: true, passive: true });
  }
}

function dragHasFiles(event) {
  return Array.from(event?.dataTransfer?.types || []).includes("Files");
}

export function registerAudioFileDropHandler({
  target = window,
  documentElement = globalThis.document?.body,
  isAudioFileName,
  loadFiles,
  setStatus,
  setDiagnostic
} = {}) {
  if (!target || typeof loadFiles !== "function") return;
  let dragDepth = 0;

  function audioFilesFromTransfer(dataTransfer) {
    return Array.from(dataTransfer?.files || []).filter((file) => {
      return isAudioFileName?.(file.name) || /^audio\//i.test(file.type || "");
    });
  }

  function setActive(active) {
    documentElement?.classList?.toggle("audio-drop-active", Boolean(active));
  }

  function clearDragState() {
    dragDepth = 0;
    setActive(false);
  }

  target.addEventListener("dragenter", (event) => {
    if (!dragHasFiles(event)) return;
    dragDepth += 1;
    setActive(true);
  });

  target.addEventListener("dragover", (event) => {
    if (!dragHasFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
    setActive(true);
  });

  target.addEventListener("dragleave", (event) => {
    if (!dragHasFiles(event)) return;
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) setActive(false);
  });

  target.addEventListener("drop", (event) => {
    if (!dragHasFiles(event)) return;
    event.preventDefault();
    clearDragState();
    const files = audioFilesFromTransfer(event.dataTransfer);
    if (!files.length) {
      setStatus?.("player ready");
      setDiagnostic?.("Drop an audio file to load it");
      return;
    }
    setStatus?.("loading drop");
    setDiagnostic?.(`Loading ${files.length === 1 ? files[0].name : `${files.length} audio files`}...`);
    loadFiles(files, true).catch((error) => {
      setStatus?.("player error");
      setDiagnostic?.(`Could not load dropped audio: ${error.message || "unknown error"}`);
      console.error(error);
    });
  });
}
