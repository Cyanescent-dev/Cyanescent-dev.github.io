import { VISUAL_AUDIO_SENSITIVITY } from "../config/visualSettings.js";
import { SCION_VISUAL_BPM } from "../audio/scionBiofeedback.js";

// How recently an accent must have fired to still show "| Accent!" in the
// status line - long enough for a human to actually notice it flash by.
const ACCENT_DISPLAY_WINDOW_MS = 450;

export function scionStatusDiagnostic(scionBiofeedback = {}, globalEnergy = 0, now = performance.now()) {
  const activityPct = Math.round(Math.max(0, Math.min(1, Number(scionBiofeedback.activity) || 0)) * 100);
  const beatPct = Math.round(Math.max(0, Math.min(1, Number(scionBiofeedback.beatStrength) || 0)) * 100);
  const energyOnFive = 1 + Math.max(0, Math.min(1, Number(globalEnergy) || 0)) * 4;
  const accentRecently = Number.isFinite(scionBiofeedback.lastAccentAt)
    && now - scionBiofeedback.lastAccentAt <= ACCENT_DISPLAY_WINDOW_MS;
  return `Scion visual clock: ${SCION_VISUAL_BPM} BPM | Activity ${activityPct}% | Beat ${beatPct}% | Energy ${energyOnFive.toFixed(1)}/5${accentRecently ? " | Accent!" : ""}`;
}

export function renderInputMeter({
  ui,
  smooth,
  visible
}) {
  if (!visible) return;
  const meterValue = (value, scale = 1) => {
    const compressed = Math.sqrt(Math.max(0, Number(value) || 0));
    return Math.min(1, compressed * scale);
  };
  const level = Math.min(1, (smooth.level || 0) * VISUAL_AUDIO_SENSITIVITY);
  ui.levelMeter.style.width = `${Math.round(level * 100)}%`;
  ui.levelReadout.textContent = `${Math.round(level * 100)}%`;
  ui.kickMeter.style.width = `${Math.round(meterValue(smooth.kick, 0.72) * 100)}%`;
  ui.bassMeter.style.width = `${Math.round(meterValue(smooth.bass, 0.78) * 100)}%`;
  ui.midMeter.style.width = `${Math.round(meterValue(smooth.mids, 0.72) * 100)}%`;
  ui.highMeter.style.width = `${Math.round(meterValue(smooth.highs, 1.15) * 100)}%`;
}

export function setStatusText(ui, status, diagnostic, blocked = false) {
  if (blocked) return;
  if (status && ui.audioStatus.textContent !== status) ui.audioStatus.textContent = status;
  if (diagnostic && ui.audioDiagnostic.textContent !== diagnostic) ui.audioDiagnostic.textContent = diagnostic;
}

export function visualFallbackDiagnostic(errorText) {
  return errorText ? `Main shader failed: ${errorText}` : "Main shader failed; using backup visual";
}

export function musicRoleName(role) {
  if (role === 1 || role === "build") return "building";
  if (role === 2 || role === "drop") return "drop ready";
  if (role === 3 || role === "high") return "high energy";
  if (role === 4 || role === "breakdown") return "breakdown";
  if (role === 5 || role === "wind-down") return "wind down";
  if (role === 6 || role === "shift") return "section shift";
  return "calm";
}

export function updateAudioStatusPanel({
  ui,
  updateWaveformProgress,
  updateTrackTimeDisplay,
  visualFallbackActive,
  visualErrorText,
  meterBands,
  playerMode,
  playerAudio,
  analysisPending,
  analysisTimeline,
  lookaheadState,
  musicAwareState,
  monitoringInput,
  liveTempoTracker = null,
  liveStructureTracker = null,
  webStreamActive = false,
  nativeAudio = window.__nativeAudio || {},
  inputNotice = null,
  liveAdaptive = null,
  scionLive = false,
  scionBiofeedback = null,
  globalEnergy = 0
} = {}) {
  updateWaveformProgress?.();
  updateTrackTimeDisplay?.();
  if (visualFallbackActive) {
    setStatusText(ui, "visual fallback", visualFallbackDiagnostic(visualErrorText));
  }
  renderInputMeter({
    ui,
    smooth: meterBands,
    visible: ui.showInputMeter?.checked
  });
  const liveHint = liveAdaptive?.enabled
    ? !liveAdaptive.audible ? "Live Adaptive: waiting for audio"
      : liveAdaptive.bpm > 0
        ? `Live Adaptive: ${Number(liveAdaptive.bpm).toFixed(1)} BPM · ${liveAdaptive.phraseLocked ? "phrase tracking" : "beat tracking"} · ${musicRoleName(musicAwareState?.role)}`
        : `Live Adaptive: estimating tempo · ${musicRoleName(musicAwareState?.role)}`
    : "";
  if (inputNotice?.status || inputNotice?.diagnostic) {
    const failed = /unavailable|denied|blocked|error|starting/i.test(inputNotice.status || "");
    setStatusText(ui, inputNotice.status, liveHint && !failed
      ? `${inputNotice.diagnostic || "Live audio input"} | ${liveHint}` : inputNotice.diagnostic);
    return;
  }
  if (monitoringInput && nativeAudio.source === "scion") {
    const fresh = nativeAudio.timestamp && Date.now() / 1000 - nativeAudio.timestamp < 2;
    const status = fresh || !nativeAudio.active
      ? nativeAudio.error || nativeAudio.status || "Connecting to Pocket Scion"
      : "Connection interrupted — waiting for Pocket Scion";
    const diagnostic = scionLive && scionBiofeedback
      ? scionStatusDiagnostic(scionBiofeedback, globalEnergy)
      : "Check USB connection and electrodes; close other MIDI apps if input is unavailable.";
    setStatusText(ui, status, diagnostic, visualFallbackActive);
    return;
  }
  const nativeFresh = nativeAudio.timestamp && Date.now() / 1000 - nativeAudio.timestamp < 1.2;
  const useNativeInput = monitoringInput && nativeFresh;
  if (playerMode && playerAudio) {
    const status = playerAudio.paused ? "player ready" : "player audio";
    let diagnostic = "";
    if (analysisPending) {
      diagnostic = "Analyzing track timeline...";
    } else if (analysisTimeline) {
      const upcoming = lookaheadState.long?.energyDelta || 0;
      const direction = upcoming > 0.04 ? "building" : upcoming < -0.04 ? "settling" : "steady";
      const brainHint = musicRoleName(musicAwareState.role);
      const sceneHint = musicAwareState.roleConfidence > 0.38
        ? brainHint
        : musicAwareState.sectionChange > 0.35 ? "section shift" : direction;
      diagnostic = `Music-aware visuals: ${sceneHint}`;
    } else {
      diagnostic = playerAudio.paused ? "Local track loaded" : "Analyzing local track";
    }
    if (!visualFallbackActive) {
      setStatusText(ui, status, diagnostic);
    }
    return;
  }
  if (useNativeInput) {
    if (!webStreamActive || nativeAudio.active) {
      const status = nativeAudio.active ? "native input" : "native ready";
      setStatusText(ui, status, "", visualFallbackActive);
    }
    // Scion never reaches the live-tempo-tracker branch below (this native
    // branch already returns), so this is where its synthetic-clock and
    // biofeedback metrics get surfaced instead - see section 8 of the Scion
    // visual-responsiveness work: activity/beat-strength/energy/BPM/accent.
    if (scionLive && scionBiofeedback) {
      setStatusText(ui, "", scionStatusDiagnostic(scionBiofeedback, globalEnergy), visualFallbackActive);
    }
    if (nativeAudio.error || nativeAudio.status) {
      const webStatus = webStreamActive ? " | web active" : "";
      const diagnostic = `${nativeAudio.error || nativeAudio.status}${webStatus}`;
      setStatusText(ui, "", diagnostic, visualFallbackActive);
    }
    if (liveHint && !nativeAudio.error) setStatusText(ui, "", liveHint, visualFallbackActive);
    return;
  }
  if (monitoringInput && liveTempoTracker && !visualFallbackActive) {
    let diagnostic;
    if (!liveTempoTracker.locked) {
      diagnostic = "Live beat tracking: estimating tempo...";
    } else if (!liveStructureTracker?.phraseLocked) {
      diagnostic = `Live beat tracking: ${liveTempoTracker.bpm.toFixed(1)} BPM locked | finding phrase...`;
    } else {
      const hint = musicRoleName(musicAwareState?.role);
      diagnostic = `Live beat tracking: ${liveTempoTracker.bpm.toFixed(1)} BPM, phrase locked | ${hint}`;
    }
    setStatusText(ui, "", liveHint || diagnostic);
  }
}

export function registerStartAudioHandler({
  button,
  startAudio,
  nativeAudioState = () => window.__nativeAudio || {},
  setStatus,
  setDiagnostic
} = {}) {
  if (!button || typeof startAudio !== "function") return;
  button.addEventListener("click", () => {
    startAudio().catch((error) => {
      const nativeAudio = nativeAudioState() || {};
      const nativeFresh = nativeAudio.timestamp && Date.now() / 1000 - nativeAudio.timestamp < 1.2;
      setStatus?.(nativeFresh ? "native fallback" : "audio blocked");
      setDiagnostic?.(`Web audio blocked: ${error.name || "Error"} ${error.message || ""}`.trim());
      console.error(error);
    });
  });
}
