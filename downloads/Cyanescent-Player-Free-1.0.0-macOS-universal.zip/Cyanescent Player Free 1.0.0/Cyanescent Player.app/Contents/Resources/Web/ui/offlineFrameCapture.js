import { canvasFrameToBase64 } from "./export.js";

export function createOfflineFrameCapture({ getGl, canvas } = {}) {
  let captureCanvas = null;

  async function captureBase64(options, overlay) {
    const gl = getGl?.();
    if (!gl) throw new Error("WebGL is not ready for export capture");
    gl.finish();
    const encoded = await canvasFrameToBase64({
      canvas,
      captureCanvas,
      options,
      overlay
    });
    captureCanvas = encoded.captureCanvas;
    return encoded.base64;
  }

  async function captureEncoded(options, overlay, imageType = "jpeg") {
    const gl = getGl?.();
    if (!gl) throw new Error("WebGL is not ready for export capture");
    gl.finish();
    const encoded = await canvasFrameToBase64({
      canvas,
      captureCanvas,
      options,
      overlay,
      imageType
    });
    captureCanvas = encoded.captureCanvas;
    return {
      base64: encoded.base64,
      imageType: encoded.imageType || imageType
    };
  }

  function reset() {
    captureCanvas = null;
  }

  return { captureBase64, captureEncoded, reset };
}
