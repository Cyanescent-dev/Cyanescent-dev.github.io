import { editionConfig } from "../generated/editionConfig.js";
import { capabilityEnabled, requireRuntimePreset } from "../config/runtimeCapabilities.js";
// Custom Timeline: direct the visual journey Automatic creates.
//
// The sequence is stored as authored markers (the same model the previous
// timeline editor used), and manualTimeline() turns them into the transition
// objects the offline renderer consumes. The automatic starting sequence comes
// from the existing offline generator (buildOfflinePresetTimeline) and is then
// stored, so the export always renders exactly what the editor shows.

import { fractJs } from "../utils/math.js";
import {
  MusicalEventType,
  TransitionEnergyStyle,
} from "../engine/transitions.js";
import {
  RENDERED_TRANSITION_CHOICES,
  renderedTransitionTiming,
  fitRenderedTransitionWindow,
  offlineEnergyLevelAt,
  offlineEventTypeForLevels,
  timelineRangeBoundaryWarnings,
  videoTransitionDurationSeconds
} from "./offlineTimeline.js";
import {
  clamp,
  drawStudioDrops,
  drawStudioWave,
  formatStudioDuration,
  formatStudioTime,
  hashUnit,
  niceTick,
  parseStudioTime,
  presetColor,
  presetHue,
  sizeCanvas,
  studioWaveData,
  visibleStudioDrops
} from "./exportStudioShared.js";

// Automatic inherits Advanced's duration; alignment still follows musical energy.
export const CHANGE_STYLES = Object.freeze([
  ["auto", "Automatic — use Advanced duration"],
  ...RENDERED_TRANSITION_CHOICES.map(o => [o.key, `${o.label} — ${o.value} s`])
]);
const TRANSITION_MANIFESTS = [
  "assets/bg/cyanescent_transitions/manifest.json",
  "assets/bg/transitions/manifest.json"
];

function styleFromValue(value, fromLevel, toLevel) {
  if (value === "quick") return TransitionEnergyStyle.RISING;
  if (value === "extended") return TransitionEnergyStyle.FALLING;
  if (toLevel > fromLevel) return TransitionEnergyStyle.RISING;
  if (toLevel < fromLevel) return TransitionEnergyStyle.FALLING;
  return TransitionEnergyStyle.STEADY;
}
function eventTypeFromStyle(style, fromLevel, toLevel) {
  if (style === TransitionEnergyStyle.RISING) return toLevel >= 5 ? MusicalEventType.DROP : MusicalEventType.BUILD_UP;
  if (style === TransitionEnergyStyle.FALLING) return toLevel <= 2 ? MusicalEventType.BREAKDOWN : MusicalEventType.CALM_SECTION;
  return offlineEventTypeForLevels(fromLevel, toLevel);
}

// Converts a generated automatic plan into authored markers. Pure, for tests.
export function markersFromAutomaticPlan(plan, { videoTransitionIds = [], seed = 0, startId = 1 } = {}) {
  let id = startId;
  return (plan?.timeline || []).map((item, index) => {
    const video = capabilityEnabled("videoTransitions") && Boolean(item.suppressShaderTransition) && videoTransitionIds.length > 0;
    return {
      id: id++,
      time: Math.round(Number(item.landingTime) * 100) / 100,
      presetId: Number(item.to),
      style: "auto",
      transitionKind: video ? "video" : "rendered",
      videoTransitionId: video ? videoTransitionIds[Math.floor(hashUnit(seed * 31 + index * 7.3) * videoTransitionIds.length)] : ""
    };
  });
}

// The authored markers as renderer transitions — identical for preview and export.
export function authoredTimelineFromMarkers({ markers, startPreset, analysisTimeline, totalDuration, normalizePresetId = (v) => Number(v), videoTransitionOptions = {}, renderedTransitionDuration = 2.6 }) {
  for (const id of [startPreset, ...markers.map(m => m.presetId)]) { if ((editionConfig.optionalPresetIds || []).includes(Number(id))) requireRuntimePreset(id); }
  const sorted = [...markers].filter((m) => Number.isFinite(m.time)).sort((a, b) => a.time - b.time)
    .filter((marker) => marker.time > 0.5 && marker.time < totalDuration - 0.2);
  const timeline = [];
  let fromPreset = normalizePresetId(startPreset) ?? Number(startPreset);
  let fromEnergy = offlineEnergyLevelAt(analysisTimeline, 0);
  let previousEnd = 0;
  for (const marker of sorted) {
    const toPreset = normalizePresetId(marker.presetId) ?? Number(marker.presetId);
    if (!Number.isFinite(toPreset) || toPreset === fromPreset) continue;
    const landing = Math.max(0, Math.min(totalDuration - 0.1, marker.time));
    if (landing <= previousEnd + 0.3) continue;
    const toEnergy = offlineEnergyLevelAt(analysisTimeline, landing);
    const style = styleFromValue(marker.style, fromEnergy, toEnergy);
    const type = eventTypeFromStyle(style, fromEnergy, toEnergy);
    const manualVideoTransition = capabilityEnabled("videoTransitions") && marker.transitionKind === "video" && marker.videoTransitionId;
    const selectedDuration = RENDERED_TRANSITION_CHOICES.find(o => o.key === marker.style)?.value ?? renderedTransitionDuration;
    const timing = renderedTransitionTiming(selectedDuration, style);
    const durationSeconds = manualVideoTransition ? videoTransitionDurationSeconds(videoTransitionOptions) : timing.duration;
    const swapAt = manualVideoTransition ? 0.5 : timing.swapAt;
    const window = manualVideoTransition ? null : fitRenderedTransitionWindow(landing, durationSeconds, swapAt, previousEnd, totalDuration);
    const startTime = window ? window.startTime : Math.max(previousEnd, landing - durationSeconds * swapAt);
    const endTime = window ? window.endTime : Math.min(totalDuration, startTime + durationSeconds);
    const item = {
      from: fromPreset, to: toPreset, fromEnergy, toEnergy, type, style,
      seed: fractJs(Math.sin(landing * 41.19 + toPreset * 10.71) * 9173.13),
      startTime, landingTime: landing, endTime, duration: Math.max(0.001, endTime - startTime),
      suppressShaderTransition: Boolean(manualVideoTransition), swapAt, source: "manual", markerId: marker.id
    };
    if (manualVideoTransition) { item.videoTransitionId = marker.videoTransitionId; item.forceVideoTransition = true; } else item.suppressVideoTransition = true;
    timeline.push(item);
    fromPreset = toPreset; fromEnergy = toEnergy; previousEnd = endTime;
  }
  return { startPreset: normalizePresetId(startPreset) ?? Number(startPreset), timeline };
}

export function createExportJourneyEditor(deps) {
  const {
    studio,
    ui,
    exportRangeModel,
    getAnalysisTimeline,
    getDuration,
    getTrackKey,
    getPlaybackAudio,
    playAudio,
    pauseAudio,
    seekAudio,
    getPresetOptions,
    normalizePresetId = (value) => Number(value),
    buildAutomaticSequence,
    getVideoTransitionOptions = () => ({}),
    addWaveformTransitionMarker
  } = deps;

  const $ = (id) => document.getElementById(id);
  const root = document.getElementById("exportWindow");
  let active = false;
  let markers = [];
  let nextId = 1;
  let startPreset = null;
  let seqMode = "auto";
  let seed = 0;
  let edits = 0;
  let trackKey = "";
  let ctx = null;
  let view = { start: 0, dur: 0 };
  let markerVisibility = "major";
  let undoStack = [];
  let redoStack = [];
  let dismissedWarn = "";
  let chipRects = [];
  let segmentCache = [];
  let dragInfo = null;
  let baseHeight = 260;
  let hiddenNames = 0;
  let videoTransitionOptions = [];
  let videoTransitionLoadStarted = false;
  let frameRequest = 0;
  let lastSelection = null;
  // Transition audition plays the committed sequence without changing its history.
  let audition = null;
  const TL = { band: 30, foot: 22 };

  const duration = () => Math.max(0, Number(getDuration?.()) || Number(getAnalysisTimeline?.()?.duration) || 0);
  const fmt = (t, opts = {}) => formatStudioTime(t, { hours: duration() >= 3600, ...opts });
  const playhead = () => clamp(Number(getPlaybackAudio?.()?.currentTime) || 0, 0, duration());
  const range = () => exportRangeModel.get();
  const presetOptions = () => getPresetOptions?.() || [];
  const presetName = (id) => presetOptions().find((p) => Number(p.id) === Number(id))?.name || `Preset ${id}`;
  const sorted = () => [...markers].sort((a, b) => a.time - b.time);
  const markerById = (id) => markers.find((m) => m.id === id) || null;
  const isZoomed = () => view.dur < duration() * 0.98;

  /* ── Sequence generation ── */
  async function loadVideoTransitionOptions() {
    if (!capabilityEnabled("videoTransitions") || videoTransitionLoadStarted) return;
    videoTransitionLoadStarted = true;
    const loaded = [];
    const results = await Promise.allSettled(TRANSITION_MANIFESTS.map(async (url) => {
      const response = await fetch(url, { cache: "no-cache" });
      if (!response.ok) return [];
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    }));
    for (const result of results) {
      if (result.status !== "fulfilled") continue;
      for (const entry of result.value) {
        if (!entry?.id || loaded.some((item) => item.id === entry.id)) continue;
        loaded.push({ id: entry.id, label: String(entry.id).replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase()) });
      }
    }
    videoTransitionOptions = loaded;
    if (ctx) renderCard();
  }
  function generate(nextSeed, previous = null) {
    const plan = buildAutomaticSequence?.({ seed: nextSeed });
    if (!plan) return null;
    const result = {
      startPreset: Number(plan.startPreset),
      markers: markersFromAutomaticPlan(plan, { videoTransitionIds: videoTransitionOptions.map((o) => o.id), seed: nextSeed, startId: nextId })
    };
    nextId += result.markers.length + 1;
    if (previous) {
      // Regenerate must visibly change: move on to the next seed if a run repeats the presets.
      const same = previous.startPreset === result.startPreset
        && previous.markers.length === result.markers.length
        && previous.markers.every((m, i) => m.presetId === result.markers[i].presetId);
      if (same && nextSeed - seed < 6) return generate(nextSeed + 1, previous);
    }
    return { ...result, seed: nextSeed };
  }
  function ensureSequence() {
    const key = getTrackKey?.() || "";
    if (!getAnalysisTimeline?.() || !duration()) return false;
    if (key && key === trackKey && startPreset !== null) return true;
    const changedTrack = trackKey && key !== trackKey;
    trackKey = key;
    seqMode = "auto";
    seed = 0;
    const seq = generate(0);
    if (!seq) return false;
    startPreset = seq.startPreset;
    markers = seq.markers;
    edits = 0;
    undoStack = []; redoStack = [];
    ctx = null;
    view = duration() > 900 ? { start: 0, dur: 720 } : { start: 0, dur: duration() };
    if (changedTrack) studio.toast("New track: a fresh automatic sequence was created.");
    return true;
  }

  /* ── Undo / redo (markers, start preset, sequence mode and the export range) ── */
  function snapshot() {
    const r = range();
    return JSON.stringify({ markers, startPreset, seqMode, seed, edits, range: { mode: r.mode, start: r.start, end: r.end } });
  }
  function pushUndo() { undoStack.push(snapshot()); if (undoStack.length > 100) undoStack.shift(); redoStack = []; }
  function restore(json) {
    const s = JSON.parse(json);
    markers = s.markers; startPreset = s.startPreset; seqMode = s.seqMode; seed = s.seed; edits = s.edits;
    if (s.range.mode === "selected") exportRangeModel.setRange(s.range.start, s.range.end, { reason: "undo" });
    else exportRangeModel.fullTrack("undo");
    if (ctx?.owner !== "open" && !markerById(ctx?.owner)) ctx = null;
  }
  function undo() { if (!undoStack.length) return; redoStack.push(snapshot()); restore(undoStack.pop()); changed(); }
  function redo() { if (!redoStack.length) return; undoStack.push(snapshot()); restore(redoStack.pop()); changed(); }
  const markEdited = () => { edits += 1; };
  function changed() { render(); studio.render(); studio.capturePoster(); }

  /* ── Segments ── */
  // Segments come from the same authored plan the exporter renders, so a change
  // the renderer would skip (inside the previous transition, or to the preset
  // already playing) never appears as a segment.
  function segmentsList() {
    const plan = authoredPlan();
    const segs = [];
    let a = 0;
    let p = plan.startPreset;
    let owner = "open";
    for (const item of plan.timeline) { segs.push({ a, b: item.landingTime, p, owner }); a = item.landingTime; p = item.to; owner = item.markerId; }
    segs.push({ a, b: duration(), p, owner });
    return segs;
  }
  function presetAt(t) {
    const plan = authoredPlan();
    let p = plan.startPreset;
    for (const item of plan.timeline) if (item.landingTime <= t) p = item.to;
    return p;
  }
  function segmentOwnerAt(t) {
    let owner = "open";
    for (const item of authoredPlan().timeline) if (item.landingTime <= t) owner = item.markerId;
    return owner;
  }
  function skippedMarkerIds() {
    const kept = new Set(authoredPlan().timeline.map((item) => item.markerId));
    return new Set(markers.filter((m) => !kept.has(m.id)).map((m) => m.id));
  }
  function skipReason(marker) {
    if (!marker) return "";
    const before = presetAt(marker.time - 0.05);
    if (Number(marker.presetId) === Number(before)) return `${presetName(marker.presetId)} is already playing here, so nothing changes.`;
    return "This change falls inside the previous transition, so the renderer skips it. Move it later, or give the previous change a quicker transition.";
  }
  function nearMajorDrop(t, within = 4) {
    let best = null;
    for (const drop of getAnalysisTimeline?.()?.drops || []) {
      if (drop.kind === "major" && Math.abs(drop.time - t) <= within && (!best || Math.abs(drop.time - t) < Math.abs(best.time - t))) best = drop;
    }
    return best && Math.abs(best.time - t) > 0.05 ? best : null;
  }

  /* ── Export contract ── */
  function manualTimeline({ startPreset: fallbackStart, analysisTimeline, totalDuration, videoTransitionOptions: vto = {}, addWaveformTransitionMarker: addMarker } = {}) {
    if (!active && !studio.isCustom()) return null;
    if (!studio.isCustom()) return null;
    ensureSequence();
    const plan = authoredTimelineFromMarkers({
      markers,
      startPreset: startPreset ?? fallbackStart,
      analysisTimeline: analysisTimeline || getAnalysisTimeline?.(),
      totalDuration: totalDuration || duration(),
      normalizePresetId,
      renderedTransitionDuration: studio.exportOptions().renderedTransitionDuration,
      videoTransitionOptions: vto
    });
    for (const item of plan.timeline) {
      addMarker?.({ source: "manual", eventType: item.type, nextPreset: item.to, style: item.style, transitionKind: item.videoTransitionId ? "video" : "rendered", videoTransitionId: item.videoTransitionId || "", startTime: item.startTime, landingTime: item.landingTime, endTime: item.endTime, status: "export" });
    }
    return plan;
  }
  let planCache = { key: "", plan: null };
  function authoredPlan() {
    const key = `${JSON.stringify(markers)}|${startPreset}|${duration()}|${getAnalysisTimeline?.() ? 1 : 0}|${studio.exportOptions().renderedTransitionDuration}`;
    if (planCache.key !== key) {
      try {
        planCache = { key, plan: authoredTimelineFromMarkers({ markers, startPreset, analysisTimeline: getAnalysisTimeline?.(), totalDuration: duration(), normalizePresetId, renderedTransitionDuration: studio.exportOptions().renderedTransitionDuration, videoTransitionOptions: getVideoTransitionOptions?.() || {} }) };
      } catch (error) {
        // Keep authored references editable; execution still rejects the unavailable world.
        planCache = { key, plan: { startPreset: normalizePresetId(startPreset), timeline: [], availabilityError: error.message } };
      }
    }
    return planCache.plan;
  }
  function previewPlan() {
    const plan = authoredPlan();
    if (plan.availabilityError) throw new Error(plan.availabilityError);
    return {
      custom: studio.isCustom(),
      startPreset: plan.startPreset,
      transitions: plan.timeline.map((item) => ({
        id: item.markerId,
        landingTime: item.landingTime,
        fromPreset: item.from,
        toPreset: item.to,
        style: item.style,
        transitionKind: item.videoTransitionId ? "video" : "rendered",
        videoTransitionId: item.videoTransitionId || "",
        forceVideoTransition: Boolean(item.forceVideoTransition),
        suppressVideoTransition: Boolean(item.suppressVideoTransition),
        suppressShaderTransition: Boolean(item.suppressShaderTransition),
        durationSeconds: item.duration,
        swapAt: item.swapAt,
        triggerTime: item.startTime
      }))
    };
  }
  function changeWindow(markerId) {
    return authoredPlan().timeline.find((item) => item.markerId === markerId) || null;
  }

  /* ── Drawing ── */
  function tlGeom() {
    const rect = $("xsTlMain").getBoundingClientRect();
    return { rect, x: (t) => ((t - view.start) / view.dur) * rect.width, t: (px) => view.start + (px / rect.width) * view.dur };
  }
  function draw() {
    if (!active || !studio.isOpen()) return;
    const total = duration();
    const analysis = getAnalysisTimeline?.();
    const data = studioWaveData(analysis);
    const ov = $("xsTlOverview");
    ov.hidden = !isZoomed();
    if (!total || startPreset === null) {
      $("xsTlSegments").replaceChildren();
      delete $("xsTlSegments").dataset.segments;
      const { ctx: c, w, h } = sizeCanvas($("xsTlMain"));
      c.clearRect(0, 0, w, h);
      c.fillStyle = "rgba(4,12,20,.96)"; c.fillRect(0, 0, w, h);
      c.fillStyle = "rgba(147,168,185,.9)"; c.font = "13px system-ui, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle";
      c.fillText(total ? "Analysing the track to build the visual journey…" : "Load a track in the player to direct its visual journey.", w / 2, h / 2);
      c.textAlign = "left";
      return;
    }
    if (!view.dur) view = { start: 0, dur: total };
    if (isZoomed()) {
      const { ctx: c, w, h } = sizeCanvas(ov);
      c.clearRect(0, 0, w, h);
      c.fillStyle = "rgba(255,255,255,.04)"; c.fillRect(0, 0, w, h);
      for (const s of segmentsList()) { c.fillStyle = presetColor(s.p, .35); c.fillRect((s.a / total) * w, h - 4, Math.max(1, ((s.b - s.a) / total) * w - 1), 4); }
      const vx = (view.start / total) * w;
      const vw = Math.max(6, (view.dur / total) * w);
      c.fillStyle = "rgba(237,247,251,.14)"; c.fillRect(vx, 0, vw, h);
      c.strokeStyle = "rgba(237,247,251,.55)"; c.lineWidth = 1; c.strokeRect(vx + .5, .5, vw - 1, h - 1);
      c.fillStyle = "#fff"; c.fillRect((playhead() / total) * w, 0, 1, h);
    }
    const { ctx: c, w, h } = sizeCanvas($("xsTlMain"));
    const g = tlGeom();
    const waveTop = TL.band + 4;
    const waveBottom = h - TL.foot;
    const r = range();
    const R = r.mode === "selected" ? r : null;
    const ctxOwner = ctx?.kind === "seg" ? ctx.owner : null;
    c.clearRect(0, 0, w, h);
    c.fillStyle = "rgba(4,12,20,.96)"; c.fillRect(0, 0, w, h);

    // Preset segments: tints behind their part of the waveform, names only where they fit.
    chipRects = [];
    segmentCache = [];
    const segs = segmentsList();
    c.font = "600 12.5px system-ui, sans-serif";
    for (const s of segs) {
      const xa = g.x(s.a);
      const xb = g.x(s.b);
      if (xb < 0 || xa > w) continue;
      const sel = ctxOwner === s.owner;
      const left = Math.max(xa, 0);
      const right = Math.min(xb, w);
      segmentCache.push({ ...s, left, right });
      c.fillStyle = presetColor(s.p, sel ? .2 : .085);
      c.fillRect(left, 0, right - left, waveBottom);
      c.fillStyle = presetColor(s.p, sel ? .9 : .55);
      c.fillRect(left, 0, right - left, 26);
      const avail = right - left - 12;
      const name = presetName(s.p);
      const fullFits = c.measureText(name).width + 34 <= avail;
      if (fullFits || avail >= 110) {
        let text = name;
        if (!fullFits) {
          const maxText = avail - 30;
          while (text.length > 1 && c.measureText(`${text}…`).width > maxText) text = text.slice(0, -1);
          text = `${text.trimEnd()}…`;
        }
        const cw = Math.min(avail, c.measureText(text).width + 34);
        const cx = left + 6;
        const cy = 3;
        c.fillStyle = sel ? presetColor(s.p, .5) : "rgba(8,20,32,.75)";
        c.beginPath(); c.roundRect(cx, cy, cw, 20, 6); c.fill();
        c.fillStyle = presetColor(s.p, 1);
        c.beginPath(); c.arc(cx + 10, cy + 10, 3.5, 0, Math.PI * 2); c.fill();
        c.fillStyle = "#eef8fb"; c.textBaseline = "middle";
        c.fillText(text, cx + 19, cy + 10.5);
        c.fillStyle = "rgba(238,248,251,.55)"; c.fillText("▾", cx + cw - 13, cy + 10.5);
        chipRects.push({ owner: s.owner, x: cx, y: cy, w: cw, h: 20 });
      }
    }
    syncSegmentControls(ctxOwner);
    const hiddenBefore = hiddenNames;
    hiddenNames = segmentCache.length - chipRects.length;
    if ((hiddenBefore > 0) !== (hiddenNames > 0)) window.setTimeout(renderHint, 0);
    // Waveform, tinted by the visual that plays over it.
    if (data) {
      drawStudioWave(c, data, 0, waveTop, w, waveBottom - waveTop - 2, view, (t) => {
        const dim = R && (t < R.start || t > R.end);
        return `hsla(${presetHue(presetAt(t))}, 45%, 80%, ${dim ? .22 : .82})`;
      });
    }
    drawStudioDrops(c, visibleStudioDrops(analysis?.drops, view, w, markerVisibility), 0, waveTop, waveBottom, { labels: view.dur < 600 });

    // Time band: change times laid out first (never overlapping), ruler only where free.
    c.fillStyle = "rgba(255,255,255,.03)"; c.fillRect(0, waveBottom, w, TL.foot);
    const detailed = view.dur < 120;
    c.font = "600 10.5px ui-monospace, SF Mono, Menlo, monospace";
    const visibleChanges = sorted().filter((m) => { const x = g.x(m.time); return x > -40 && x < w + 40; });
    const isSel = (m) => ctxOwner === m.id || dragInfo?.id === m.id;
    const pills = [];
    for (const m of [...visibleChanges.filter(isSel), ...visibleChanges.filter((m) => !isSel(m))]) {
      const x = g.x(m.time);
      const label = fmt(m.time, { tenths: detailed });
      const pw = c.measureText(label).width + 12;
      // Keep edge pills fully inside the timeline.
      const a = clamp(x - pw / 2, 1, w - pw - 1);
      const rect = { m, x: a + pw / 2, label, a, b: a + pw, pw };
      if (pills.every((p) => rect.b + 4 < p.a || rect.a - 4 > p.b)) pills.push(rect);
    }
    if (R) for (const t of [R.start, R.end]) { const x = g.x(t); pills.push({ range: true, a: x - 34, b: x + 34 }); }
    c.font = "10.5px ui-monospace, SF Mono, Menlo, monospace"; c.textBaseline = "middle";
    const tick = niceTick(view.dur, w, view.dur > 1800 ? 160 : 135);
    for (let t = Math.ceil(view.start / tick) * tick; t <= view.start + view.dur; t += tick) {
      const px = g.x(t);
      const label = fmt(t, { tenths: tick < 1 });
      const lw = c.measureText(label).width + 6;
      if (pills.some((p) => px + lw > p.a - 4 && px < p.b + 4)) continue;
      c.fillStyle = "rgba(139,184,208,.3)"; c.fillRect(px, waveBottom, 1, 4);
      c.fillStyle = "rgba(147,168,185,.6)"; c.fillText(label, px + 3, waveBottom + TL.foot / 2 + 1);
    }
    const skipped = skippedMarkerIds();
    for (const m of visibleChanges) {
      const x = g.x(m.time);
      const sel = isSel(m);
      if (skipped.has(m.id)) {
        c.strokeStyle = sel ? "#f2b45c" : "rgba(242,180,92,.75)";
        c.setLineDash([4, 4]); c.lineWidth = sel ? 2 : 1.25;
        c.beginPath(); c.moveTo(x, 0); c.lineTo(x, waveBottom); c.stroke(); c.setLineDash([]);
        continue;
      }
      c.save();
      if (sel) { c.shadowColor = "rgba(255,255,255,.8)"; c.shadowBlur = 8; }
      c.fillStyle = sel ? "#ffffff" : "rgba(255,255,255,.7)";
      c.fillRect(x - (sel ? 1.25 : .5), 0, sel ? 2.5 : 1, waveBottom);
      c.restore();
    }
    c.font = "600 10.5px ui-monospace, SF Mono, Menlo, monospace";
    for (const p of pills) {
      if (p.range) continue;
      const sel = isSel(p.m);
      c.fillStyle = skipped.has(p.m.id) ? "#f2b45c" : sel ? presetColor(p.m.presetId, 1) : "#e9f4f8";
      c.beginPath(); c.roundRect(p.a, waveBottom + 3, p.pw, 16, 8); c.fill();
      c.fillStyle = "#06121c"; c.textAlign = "center"; c.fillText(p.label, p.x, waveBottom + 11.5); c.textAlign = "left";
    }
    if (dragInfo?.snapped) {
      const x = g.x(markerById(dragInfo.id).time);
      c.font = "600 11px system-ui, sans-serif"; c.fillStyle = "#f2b45c"; c.textBaseline = "middle";
      c.fillText("Snapped to drop · hold ⌥ to place freely", Math.min(x + 8, w - 230), waveTop + 18);
    }
    // Export range: cyan is reserved for it; everything outside is dimmed.
    if (R) {
      const xa = g.x(R.start);
      const xb = g.x(R.end);
      c.fillStyle = "rgba(2,6,10,.55)";
      if (xa > 0) c.fillRect(0, 0, Math.min(xa, w), h);
      if (xb < w) c.fillRect(Math.max(xb, 0), 0, w - Math.max(xb, 0), h);
      const ca = clamp(xa, 0, w);
      const cb = clamp(xb, 0, w);
      c.fillStyle = "rgba(83,220,230,.07)"; c.fillRect(ca, 0, cb - ca, waveBottom);
      c.fillStyle = "#53dce6"; c.fillRect(ca, 0, cb - ca, 3); c.fillRect(ca, h - 3, cb - ca, 3);
      for (const [x, edge, t] of [[xa, "start", R.start], [xb, "end", R.end]]) {
        if (x < -8 || x > w + 8) continue;
        c.fillStyle = "#53dce6";
        c.fillRect(x - 1.5, 0, 3, h);
        const cy = (waveTop + waveBottom) / 2;
        c.beginPath(); c.roundRect(x - 8, cy - 22, 16, 44, 5); c.fill();
        c.strokeStyle = "rgba(4,22,28,.75)"; c.lineWidth = 1.5;
        c.beginPath(); c.moveTo(x - 2.5, cy - 10); c.lineTo(x - 2.5, cy + 10); c.moveTo(x + 2.5, cy - 10); c.lineTo(x + 2.5, cy + 10); c.stroke();
        c.font = "700 11px system-ui, sans-serif";
        const text = `${edge === "start" ? "Start" : "End"} ${fmt(t)}`;
        const tw = c.measureText(text).width + 14;
        const tx = edge === "start" ? x : x - tw;
        c.beginPath(); c.roundRect(tx, waveTop + 2, tw, 19, edge === "start" ? [0, 6, 6, 0] : [6, 0, 0, 6]); c.fill();
        c.fillStyle = "#04161c"; c.textBaseline = "middle"; c.fillText(text, tx + 7, waveTop + 12);
      }
    }
    $("xsTlTime").innerHTML = `${fmt(playhead(), { tenths: true })} <span>/ ${fmt(duration())}</span>`;
    updatePreviewFoot();
    const px = g.x(playhead());
    if (px >= 0 && px <= w) {
      c.fillStyle = "#fff";
      c.fillRect(px - .75, TL.band, 1.5, waveBottom - TL.band);
      c.beginPath(); c.moveTo(px - 6, TL.band - 2); c.lineTo(px + 6, TL.band - 2); c.lineTo(px, TL.band + 6); c.closePath(); c.fill();
    }
  }

  function syncSegmentControls(selected) {
    const host = $("xsTlSegments");
    const signature = JSON.stringify(segmentCache.map(s => [s.owner, s.p, s.left, s.right]));
    if (host.dataset.segments !== signature) {
      host.dataset.segments = signature;
      host.replaceChildren(...segmentCache.map(s => {
        const button = document.createElement("button");
        button.type = "button"; button.dataset.owner = String(s.owner);
        button.title = presetName(s.p);
        button.setAttribute("aria-label", `Edit ${presetName(s.p)}, ${fmt(s.a)} to ${fmt(s.b)}`);
        button.style.left = `${s.left}px`; button.style.width = `${Math.max(1, s.right - s.left)}px`;
        return button;
      }));
    }
    for (const button of host.children) button.setAttribute("aria-pressed", String(button.dataset.owner === String(selected)));
  }

  /* ── Hit testing: range handles, change lines, preset names/band, waveform ── */
  function hitTest(event) {
    const g = tlGeom();
    const x = event.clientX - g.rect.left;
    const y = event.clientY - g.rect.top;
    if (y >= 0 && y < 26) return { kind: "chip", owner: segmentOwnerAt(clamp(g.t(x), 0, duration())) };
    const r = range();
    if (r.mode === "selected") {
      if (Math.abs(g.x(r.start) - x) < 10) return { kind: "range", edge: "start" };
      if (Math.abs(g.x(r.end) - x) < 10) return { kind: "range", edge: "end" };
    }
    let best = null;
    let bestD = 7;
    for (const m of markers) {
      const d = Math.abs(g.x(m.time) - x);
      if (d < bestD) { bestD = d; best = m; }
    }
    if (best) return { kind: "marker", marker: best };
    const chip = chipRects.find((cr) => x >= cr.x && x <= cr.x + cr.w && y >= cr.y - 4 && y <= cr.y + cr.h + 4);
    if (chip) return { kind: "chip", owner: chip.owner };
    if (y < TL.band) return { kind: "chip", owner: segmentOwnerAt(clamp(g.t(x), 0, duration())) };
    return { kind: "wave", t: clamp(g.t(x), 0, duration()) };
  }
  function showTip(event) {
    const tip = $("xsTlTip");
    if (dragInfo) { tip.hidden = true; return; }
    const g = tlGeom();
    const x = event.clientX - g.rect.left;
    const y = event.clientY - g.rect.top;
    const hit = hitTest(event);
    let html = "";
    if (hit.kind === "marker") {
      const label = CHANGE_STYLES.find(([v]) => v === hit.marker.style)?.[1] || "Automatic";
      html = skippedMarkerIds().has(hit.marker.id)
        ? `<b>Skipped change · ${presetName(hit.marker.presetId)}</b><span>${skipReason(hit.marker)}</span>`
        : `<b>${presetName(hit.marker.presetId)}</b><span>Changes at ${fmt(hit.marker.time, { tenths: true })} · ${hit.marker.transitionKind === "video" ? "Video clip" : label}</span>`;
    } else if (hit.kind === "chip" || (hit.kind === "wave" && y < TL.band + 40)) {
      const owner = hit.kind === "chip" ? hit.owner : segmentOwnerAt(hit.t);
      const seg = segmentsList().find((s) => s.owner === owner);
      if (seg) html = `<b>${presetName(seg.p)}</b><span>${fmt(seg.a)} – ${fmt(seg.b)} · ${formatStudioDuration(seg.b - seg.a)}</span>`;
    }
    if (!html) { tip.hidden = true; return; }
    tip.innerHTML = html;
    tip.hidden = false;
    const tw = tip.offsetWidth;
    tip.style.left = `${clamp(x + 12, 4, g.rect.width - tw - 4)}px`;
    tip.style.top = `${Math.max(4, y + 16)}px`;
  }

  function bindTimeline() {
    const canvas = $("xsTlMain");
    const controls = $("xsTlSegments");
    controls.addEventListener("pointerdown", event => event.stopPropagation());
    controls.addEventListener("click", event => {
      const button = event.target.closest("button[data-owner]");
      if (!button) return;
      event.stopPropagation();
      const owner = button.dataset.owner;
      openSegCard(owner === "open" ? owner : Number(owner));
    });
    canvas.addEventListener("pointermove", (event) => {
      if (dragInfo) return;
      const hit = hitTest(event);
      canvas.style.cursor = hit.kind === "range" || hit.kind === "marker" ? "ew-resize" : hit.kind === "chip" ? "pointer" : "text";
      showTip(event);
    });
    canvas.addEventListener("pointerleave", () => { $("xsTlTip").hidden = true; });
    canvas.addEventListener("pointerdown", (event) => {
      if (startPreset === null) return;
      const hit = hitTest(event);
      $("xsTlTip").hidden = true;
      try { canvas.setPointerCapture(event.pointerId); } catch {}
      if (hit.kind === "range") { pushUndo(); dragInfo = { kind: "range", edge: hit.edge }; return; }
      if (hit.kind === "marker") { dragInfo = { kind: "marker", id: hit.marker.id, x0: event.clientX, moved: false }; return; }
      if (hit.kind === "chip") { openSegCard(hit.owner); return; }
      if (ctx) closeCard();
      dragInfo = { kind: "scrub" };
      seekAudio?.(hit.t);
      draw();
    });
    canvas.addEventListener("pointermove", (event) => {
      if (!dragInfo) return;
      const g = tlGeom();
      let t = clamp(g.t(event.clientX - g.rect.left), 0.1, duration() - 0.1);
      if (dragInfo.kind === "scrub") { seekAudio?.(t); draw(); }
      if (dragInfo.kind === "range") {
        const r = range();
        if (dragInfo.edge === "start") exportRangeModel.setRange(Math.min(t, r.end - 1), r.end, { reason: "timeline-handle" });
        else exportRangeModel.setRange(r.start, Math.max(t, r.start + 1), { reason: "timeline-handle" });
        dismissedWarn = "";
      }
      if (dragInfo.kind === "marker" && (dragInfo.moved || Math.abs(event.clientX - dragInfo.x0) > 3)) {
        if (!dragInfo.moved) { pushUndo(); markEdited(); dragInfo.moved = true; closeCard(false); }
        const drop = !event.altKey && (getAnalysisTimeline?.()?.drops || []).find((d) => d.kind === "major" && Math.abs(g.x(d.time) - g.x(t)) < 7);
        dragInfo.snapped = Boolean(drop);
        if (drop) t = drop.time;
        markerById(dragInfo.id).time = Math.round(t * 100) / 100;
        draw();
      }
    });
    const end = () => {
      if (dragInfo?.kind === "scrub") studio.capturePoster();
      if (dragInfo?.kind === "marker") {
        if (!dragInfo.moved) openSegCard(dragInfo.id, { options: true });
        else changed();
      }
      dragInfo = null;
      draw();
    };
    canvas.addEventListener("pointerup", end);
    canvas.addEventListener("pointercancel", end);
    canvas.addEventListener("dblclick", (event) => {
      const hit = hitTest(event);
      if (hit.kind === "marker") playTransitionFrom(hit.marker.id);
    });
    canvas.addEventListener("wheel", (event) => {
      event.preventDefault();
      const g = tlGeom();
      if (event.ctrlKey || event.metaKey) zoom(Math.exp(event.deltaY * 0.01), g.t(event.clientX - g.rect.left));
      else pan(((event.deltaX || event.deltaY) / g.rect.width) * view.dur);
    }, { passive: false });

    const ov = $("xsTlOverview");
    let ovDrag = false;
    const ovMove = (event) => {
      const rect = ov.getBoundingClientRect();
      const t = ((event.clientX - rect.left) / rect.width) * duration();
      view.start = clamp(t - view.dur / 2, 0, Math.max(0, duration() - view.dur));
      draw(); positionCard();
    };
    ov.addEventListener("pointerdown", (event) => { ovDrag = true; try { ov.setPointerCapture(event.pointerId); } catch {} ovMove(event); });
    ov.addEventListener("pointermove", (event) => ovDrag && ovMove(event));
    ov.addEventListener("pointerup", () => { ovDrag = false; });

    $("xsTlPlay").onclick = () => togglePlay();
    $("xsTlAdd").onclick = () => openAddCard();
    $("xsTlUndo").onclick = undo;
    $("xsTlRedo").onclick = redo;
    $("xsTlZoomIn").onclick = () => zoom(0.5, playhead());
    $("xsTlZoomOut").onclick = () => zoom(2, playhead());
    $("xsTlFit").onclick = () => { view = { start: 0, dur: duration() }; syncZoom(); draw(); positionCard(); };
    $("xsMarkerSeg").onclick = (event) => {
      const button = event.target.closest("button[data-markers]");
      if (!button) return;
      markerVisibility = button.dataset.markers;
      for (const b of $("xsMarkerSeg").children) b.setAttribute("aria-checked", String(b === button));
      draw();
    };
    $("xsTlPreviewToggle").onclick = () => {
      const on = root.dataset.tlPreview !== "on";
      root.dataset.tlPreview = on ? "on" : "off";
      $("xsTlPreviewToggle").setAttribute("aria-pressed", String(on));
      $("xsTlPreviewToggleText").textContent = on ? "Hide preview" : "Show preview";
      if (!on) studio.stopLivePreview();
      studio.layout();
    };
    $("xsTlPreviewBig").onclick = () => studio.openBigPreview();
    $("xsTlWarnKeep").onclick = () => { dismissedWarn = warnKey(); renderRange(); };
    $("xsTlWarnSnap").onclick = () => {
      const warnings = rangeWarnings();
      const r = range();
      let start = r.start;
      let endT = r.end;
      if (Number.isFinite(warnings?.start?.nearestCut)) start = warnings.start.nearestCut;
      if (Number.isFinite(warnings?.end?.nearestCut)) endT = warnings.end.nearestCut;
      if (endT > start) { pushUndo(); exportRangeModel.setRange(start, endT, { reason: "timeline-transition-cut" }); }
    };
    $("xsSeqBtn").onclick = () => {
      const menu = $("xsSeqMenu");
      if (!menu.hidden) { closeMenus(); return; }
      for (const b of menu.querySelectorAll("[data-seq]")) b.setAttribute("aria-checked", String(b.dataset.seq === seqMode));
      $("xsRegenerate").hidden = seqMode !== "auto";
      studio.placePopover(menu, $("xsSeqBtn"), { above: false });
      const rootRect = root.getBoundingClientRect();
      const btnRect = $("xsSeqBtn").getBoundingClientRect();
      menu.style.left = `${clamp(btnRect.right - rootRect.left - menu.offsetWidth, 8, root.offsetWidth - menu.offsetWidth - 8)}px`;
      $("xsSeqBtn").setAttribute("aria-expanded", "true");
    };
    $("xsSeqMenu").addEventListener("click", (event) => {
      const choice = event.target.closest("[data-seq]");
      if (choice) { closeMenus(); if (choice.dataset.seq !== seqMode) switchSeqMode(choice.dataset.seq); return; }
      if (event.target.closest("[data-seq-act='regenerate']")) { closeMenus(); regenerate(); }
    });
    // Export range: Entire track | Select range, with exact fields beside it.
    $("xsRangeScope").addEventListener("click", (event) => {
      const button = event.target.closest("[data-scope]");
      if (!button) return;
      const r = range();
      if (button.dataset.scope === "entire" && r.mode === "selected") { pushUndo(); lastSelection = { start: r.start, end: r.end }; exportRangeModel.fullTrack(); }
      if (button.dataset.scope === "section" && r.mode !== "selected") {
        pushUndo();
        const sel = lastSelection || (isZoomed()
          ? { start: view.start + view.dur * 0.25, end: view.start + view.dur * 0.75 }
          : { start: clamp(playhead(), 0, Math.max(0, duration() - 60)), end: Math.min(duration(), clamp(playhead(), 0, Math.max(0, duration() - 60)) + Math.min(60, duration() * 0.3)) });
        exportRangeModel.setRange(sel.start, sel.end, { reason: "select-range" });
        const nr = range();
        if (nr.start < view.start || nr.end > view.start + view.dur) zoomToRange();
      }
    });
    const applyRangeField = (id) => {
      const el = $(id);
      const value = parseStudioTime(el.value);
      if (!Number.isFinite(value)) { el.classList.add("invalid"); return; }
      pushUndo();
      const r = range();
      let result;
      if (id === "xsRangeStart") result = exportRangeModel.setRange(value, Math.max(r.end, value + 1), { reason: "field-start" });
      if (id === "xsRangeEnd") result = exportRangeModel.setEnd(value);
      if (id === "xsRangeDur") result = exportRangeModel.setDuration(value);
      if (result && !result.ok) { undoStack.pop(); el.classList.add("invalid"); studio.toast(result.error); return; }
      el.blur();
      const nr = range();
      if (nr.start < view.start || nr.end > view.start + view.dur) zoomToRange();
    };
    for (const id of ["xsRangeStart", "xsRangeEnd", "xsRangeDur"]) {
      $(id).addEventListener("keydown", (event) => {
        if (event.key === "Enter") applyRangeField(id);
        if (event.key === "Escape") { event.stopPropagation(); event.target.blur(); renderRange(); }
      });
      $(id).addEventListener("change", () => applyRangeField(id));
    }
    $("xsRangeSetStart").onclick = () => setRangeEdgeAtPlayhead("start");
    $("xsRangeSetEnd").onclick = () => setRangeEdgeAtPlayhead("end");
    $("xsRangeZoom").onclick = zoomToRange;
    bindCard();
  }
  function setRangeEdgeAtPlayhead(edge) {
    const t = playhead();
    const r = range();
    pushUndo();
    if (edge === "start") exportRangeModel.setRange(Math.min(t, (r.mode === "selected" ? r.end : duration()) - 1), r.mode === "selected" ? Math.max(r.end, t + 1) : duration(), { reason: "start-at-playhead" });
    else exportRangeModel.setRange(r.mode === "selected" ? Math.min(r.start, t - 1) : 0, Math.max(t, 1), { reason: "end-at-playhead" });
  }
  function zoomToRange() {
    const r = range();
    if (r.mode !== "selected") return;
    const len = r.end - r.start;
    const dur = clamp(len * 1.3, Math.min(10, duration()), duration());
    view = { dur, start: clamp(r.start - (dur - len) / 2, 0, Math.max(0, duration() - dur)) };
    syncZoom(); draw(); positionCard();
  }
  function zoom(factor, anchor) {
    const total = duration();
    if (!total) return;
    const dur = clamp(view.dur * factor, Math.min(10, total), total);
    const f = clamp((anchor - view.start) / view.dur, 0, 1);
    view = { dur, start: clamp(anchor - f * dur, 0, total - dur) };
    syncZoom(); draw(); positionCard();
  }
  function pan(dt) {
    view.start = clamp(view.start + dt, 0, Math.max(0, duration() - view.dur));
    draw(); positionCard();
  }
  function syncZoom() {
    const d = view.dur;
    $("xsTlZoomReadout").textContent = !isZoomed() ? "Whole track" : d >= 90 ? `${Math.round(d / 60)} min` : `${Math.round(d)} sec`;
  }
  function ensureVisible(t) {
    if (t < view.start + view.dur * 0.05 || t > view.start + view.dur * 0.95) view.start = clamp(t - view.dur / 2, 0, Math.max(0, duration() - view.dur));
  }

  /* ── Sequence modes, regenerate, edit protection ── */
  function confirmReplace({ title, text, ok = "Replace" }, onOk) {
    $("xsConfirmTitle").textContent = title;
    $("xsConfirmText").textContent = text;
    $("xsConfirmOk").textContent = ok;
    $("xsConfirm").hidden = false;
    $("xsConfirmCancel").focus();
    $("xsConfirmOk").onclick = () => { $("xsConfirm").hidden = true; onOk(); };
    $("xsConfirmCancel").onclick = () => { $("xsConfirm").hidden = true; studio.toast("Your edits are unchanged."); };
  }
  const editsText = () => `You have made ${edits} change${edits === 1 ? "" : "s"} to this sequence. Replacing it removes them. You can still undo afterwards.`;
  function regenerate() {
    const run = () => {
      const before = { startPreset, markers: markers.map((m) => ({ ...m })) };
      const seq = generate(seed + 1, before);
      if (!seq) return;
      pushUndo();
      seed = seq.seed;
      startPreset = seq.startPreset;
      markers = seq.markers;
      edits = 0;
      ctx = null;
      const prevList = [before.startPreset, ...before.markers.map((m) => m.presetId)];
      const nextList = [startPreset, ...markers.map((m) => m.presetId)];
      const differing = nextList.filter((p, i) => p !== prevList[i]).length;
      changed(); flash();
      studio.toast(`New arrangement · <b>${differing} of ${nextList.length}</b> visuals changed`);
    };
    if (edits > 0) confirmReplace({ title: "Replace your edited sequence?", text: editsText(), ok: "Regenerate" }, run);
    else run();
  }
  function switchSeqMode(next) {
    const run = () => {
      pushUndo();
      ctx = null;
      if (next === "single") {
        const keep = presetAt(playhead());
        seqMode = "single"; startPreset = keep; markers = [];
        studio.toast(`<b>${presetName(keep)}</b> now plays for the whole track. Add changes wherever you like.`);
      } else {
        const seq = generate(seed);
        if (!seq) return;
        seqMode = "auto"; startPreset = seq.startPreset; markers = seq.markers;
        studio.toast(`Automatic sequence · <b>${markers.length} visual changes</b> placed on the music`);
      }
      edits = 0;
      changed(); flash();
    };
    if (edits > 0) confirmReplace({ title: next === "single" ? "Start again from a single preset?" : "Replace with an automatic sequence?", text: editsText() }, run);
    else run();
  }
  function flash() {
    const stack = $("xsTlStack");
    stack.classList.remove("flash"); void stack.offsetWidth; stack.classList.add("flash");
  }

  /* ── Range warnings (existing transition-boundary handling) ── */
  function rangeWarnings() {
    const r = range();
    if (r.mode !== "selected") return null;
    const plan = authoredPlan();
    return timelineRangeBoundaryWarnings({ timeline: plan.timeline, startPreset: plan.startPreset, sourceStart: r.start, sourceEnd: r.end, sourceDuration: duration() });
  }
  const warnKey = () => { const r = range(); return `${r.start.toFixed(2)}-${r.end.toFixed(2)}`; };
  function renderRange() {
    const r = range();
    for (const b of $("xsRangeScope").children) b.setAttribute("aria-checked", String(b.dataset.scope === (r.mode === "selected" ? "section" : "entire")));
    const on = r.mode === "selected";
    if ($("xsRangeInline").hidden === on) { $("xsRangeInline").hidden = !on; window.requestAnimationFrame(() => studio.layout()); }
    if (on) {
      for (const [id, value] of [["xsRangeStart", r.start], ["xsRangeEnd", r.end], ["xsRangeDur", r.end - r.start]]) {
        const el = $(id);
        if (document.activeElement !== el) { el.value = formatStudioTime(value, { tenths: true, hours: id === "xsRangeDur" ? value >= 3600 : duration() >= 3600 }); el.classList.remove("invalid"); }
      }
    }
    const warnings = rangeWarnings();
    const edges = warnings ? ["start", "end"].filter((edge) => warnings[edge]) : [];
    const show = edges.length && warnKey() !== dismissedWarn;
    $("xsTlWarning").hidden = !show;
    if (show) $("xsTlWarningText").textContent = `The range ${edges.join(" and ")} falls in the middle of a visual change.`;
  }

  /* ── Contextual card ── */
  function suggestPreset(t) {
    const current = presetAt(t);
    const ids = presetOptions().map((p) => Number(p.id)).filter((id) => id !== current);
    if (!ids.length) return current;
    return ids[Math.floor(hashUnit(t * 1.7 + markers.length) * ids.length)];
  }
  function openAddCard() {
    if (!ensureSequence()) return;
    const time = playhead();
    const existing = markers.find(m => Math.abs(m.time - time) < 0.6);
    if (existing) return openSegCard(existing.id, { options: true });
    const marker = { id: nextId, time: Math.round(time * 100) / 100,
      presetId: suggestPreset(time), style: "auto", transitionKind: "rendered", videoTransitionId: "" };
    const trial = authoredTimelineFromMarkers({ markers: [...markers, marker], startPreset,
      analysisTimeline: getAnalysisTimeline?.(), totalDuration: duration(), normalizePresetId,
      renderedTransitionDuration: studio.exportOptions().renderedTransitionDuration });
    if (!trial.timeline.some(item => item.markerId === marker.id)) {
      studio.toast("Choose a musical moment after the previous transition to add a visual change.");
      return;
    }
    pushUndo(); markEdited(); nextId++; markers.push(marker);
    openSegCard(marker.id, { options: true }); changed(); flash();
  }
  function openSegCard(owner, { options = false } = {}) {
    if (audition) stopAudition({ seekBack: false });
    ctx = { kind: "seg", owner, options, error: "" };
    render();
  }
  function closeCard(rerender = true) {
    if (audition) stopAudition();
    ctx = null;
    if (rerender) render();
  }

  /* ── Transition audition ── */
  // Audition an immutable snapshot of the current committed edit, never a draft.
  function candidate() {
    return ctx?.kind === "seg" && ctx.owner !== "open"
      ? { markers: markers.map(m => ({ ...m })), id: ctx.owner } : null;
  }
  const PRE_ROLL = 3;
  const POST_ROLL = 5;
  function auditionWindow(item) {
    const start = Math.max(0, Math.min(item.startTime, item.landingTime) - PRE_ROLL);
    const end = Math.min(duration(), Math.max(item.endTime || 0, item.landingTime) + POST_ROLL);
    return { start, end };
  }
  async function previewCandidate() {
    const cand = candidate();
    if (!cand) return;
    const plan = authoredTimelineFromMarkers({ markers: cand.markers, startPreset, analysisTimeline: getAnalysisTimeline?.(), totalDuration: duration(), normalizePresetId, renderedTransitionDuration: studio.exportOptions().renderedTransitionDuration, videoTransitionOptions: getVideoTransitionOptions?.() || {} });
    const item = plan.timeline.find((entry) => entry.markerId === cand.id);
    if (!item) {
      ctx.error = "This change would be skipped (it starts inside the previous transition), so there is nothing to preview. Move it later, or give the previous change a quicker transition.";
      renderCard();
      return;
    }
    if (playing()) { pauseAudio?.(); studio.stopLivePreview(); }
    const win = auditionWindow(item);
    audition = { end: win.end, returnTo: item.landingTime, label: `${presetName(item.from)} → ${presetName(item.to)}` };
    ctx.error = "";
    renderCard();
    seekAudio?.(win.start);
    ensureVisible(win.start);
    studio.refreshLivePreview();
    try { await playAudio?.(); } catch (error) { console.error(error); }
    studio.syncPlayButtons();
    studio.updatePreviewMeta?.();
    tick();
  }
  // Ends an audition: playback stops and the playhead
  // returns to the change being edited.
  function stopAudition({ seekBack = true } = {}) {
    if (!audition) return;
    const returnTo = audition.returnTo;
    audition = null;
    if (playing()) pauseAudio?.();
    studio.stopLivePreview();
    if (seekBack && Number.isFinite(returnTo)) seekAudio?.(returnTo);
    studio.syncPlayButtons();
    studio.updatePreviewMeta?.();
    studio.capturePoster();
    if (ctx) renderCard();
    draw();
  }
  // Double-clicking a change line plays the authored transition from a few seconds before.
  async function playTransitionFrom(markerId) {
    const item = authoredPlan().timeline.find((entry) => entry.markerId === markerId);
    if (!item || startPreset === null) return;
    if (audition) stopAudition({ seekBack: false });
    if (playing()) { pauseAudio?.(); studio.stopLivePreview(); }
    const win = auditionWindow(item);
    seekAudio?.(win.start);
    ensureVisible(win.start);
    studio.startLivePreview();
    try { await playAudio?.(); } catch (error) { console.error(error); }
    studio.syncPlayButtons();
    tick();
  }
  const presetSelectHtml = (field, value) => `<select data-field="${field}">${presetOptions().map((p) => `<option value="${p.id}" ${Number(p.id) === Number(value) ? "selected" : ""}>${p.name}</option>`).join("")}</select>`;
  const optionSelectHtml = (field, options, value) => `<select data-field="${field}">${options.map(([v, l]) => `<option value="${v}" ${v === value ? "selected" : ""}>${l}</option>`).join("")}</select>`;
  function typeBlock(type, video, prefix = "") {
    if (!capabilityEnabled("videoTransitions")) return `<div class="ctx-row"><span>Type</span><span>Rendered blend</span></div>`;
    const clips = videoTransitionOptions.map((o) => [o.id, o.label]);
    return `<div class="ctx-row"><span>Type</span><div class="seg"><button type="button" data-act="${prefix}type" data-v="rendered" aria-checked="${type !== "video"}">Blend</button><button type="button" data-act="${prefix}type" data-v="video" aria-checked="${type === "video"}" ${clips.length ? "" : "disabled title='Video transitions are still loading'"}>Video clip</button></div></div>
      ${type === "video" && clips.length ? `<label class="ctx-row"><span>Clip</span>${optionSelectHtml(`${prefix}video`, clips, video)}</label>` : ""}`;
  }
  function renderCard() {
    const card = $("xsCtxCard");
    $("xsTlHint").hidden = Boolean(ctx);
    if (!ctx) { card.hidden = true; fitCard(); return; }
    card.hidden = false;
    const seg = segmentsList().find((s) => s.owner === ctx.owner);
    const skippedMarker = !seg && ctx.owner !== "open" ? markerById(ctx.owner) : null;
    if (skippedMarker) {
      card.innerHTML = `
        <div class="ctx-head"><div class="ctx-thumb" style="background:repeating-linear-gradient(45deg, rgba(242,180,92,.5) 0 6px, transparent 6px 12px)"></div>
          <div class="ctx-title"><strong>Skipped change · ${presetName(skippedMarker.presetId)}</strong><span>At ${fmt(skippedMarker.time, { tenths: true })}</span></div>
          <span class="spacer"></span><button type="button" class="icon-btn sm" data-act="close" aria-label="Close">×</button></div>
        <div class="ctx-snap"><span>${skipReason(skippedMarker)}</span></div>
        <div class="ctx-fields">
          <label class="ctx-row"><span>Starts at</span><input data-field="trTime" value="${fmt(skippedMarker.time, { tenths: true })}" spellcheck="false" autocomplete="off"></label>
          <label class="ctx-row"><span>Visual</span>${presetSelectHtml("segPreset", skippedMarker.presetId)}</label>
          <label class="ctx-row"><span>Transition</span>${optionSelectHtml("trStyle", CHANGE_STYLES, skippedMarker.style || "auto")}</label>
        </div>
        <div class="ctx-actions"><span class="spacer"></span><button type="button" class="danger-btn" data-act="remove">Remove change</button><button type="button" class="primary-sm" data-act="close">Done</button></div>`;
      positionCard();
      return;
    }
    if (!seg) { ctx = null; renderCard(); return; }
    const marker = ctx.owner === "open" ? null : markerById(ctx.owner);
    const shownPreset = marker ? marker.presetId : seg.p;
    const sub = marker ? `Starts at ${fmt(marker.time, { tenths: true })} · plays for ${formatStudioDuration(seg.b - seg.a)}` : `Opening visual · plays for ${formatStudioDuration(seg.b - seg.a)}`;
    const drop = marker && nearMajorDrop(marker.time);
    card.innerHTML = `
      <div class="ctx-head"><div class="ctx-thumb" style="background:${presetColor(shownPreset, .85)}"></div>
        <div class="ctx-title"><strong>${presetName(shownPreset)}</strong><span>${sub}</span></div>
        <span class="spacer"></span><button type="button" class="icon-btn sm" data-act="close" aria-label="Close">×</button></div>
      <div class="ctx-fields">
        <label class="ctx-row"><span>Visual</span>${presetSelectHtml("segPreset", shownPreset)}</label>
        ${marker ? `<label class="ctx-row"><span>Transition</span>${optionSelectHtml("trStyle", CHANGE_STYLES, marker.style || "auto")}</label>${marker.style === "auto" ? `<p class="field-help">Uses the Advanced rendered duration (${studio.exportOptions().renderedTransitionDuration} s), aligned to the music.</p>` : ""}` : ""}
      </div>
      ${marker ? `<p class="field-help">The musical marker stays fixed. Blends shorten only to fit track or neighbouring transition boundaries.</p>` : ""}
      ${marker && ctx.options ? `
        ${drop ? `<div class="ctx-snap"><span>Major drop nearby at <b>${fmt(drop.time, { tenths: true })}</b></span><button type="button" data-act="snapExisting" data-t="${drop.time}">Snap to drop</button></div>` : ""}
        <div class="ctx-fields ctx-options">
          <label class="ctx-row"><span>Starts at</span><input data-field="trTime" value="${fmt(marker.time, { tenths: true })}" spellcheck="false" autocomplete="off"></label>
          ${typeBlock(marker.transitionKind, marker.videoTransitionId, "tr")}
        </div>` : ""}
      ${ctx.error ? `<p class="ctx-error">${ctx.error}</p>` : ""}
      <div class="ctx-actions">
        ${marker ? `<button type="button" class="ctx-more" data-act="more" aria-expanded="${ctx.options}">Transition options</button><span class="spacer"></span><button type="button" class="danger-btn" data-act="remove">Remove change</button>${auditionButton()}` : `<span class="field-help">The first visual has no transition.</span><span class="spacer"></span>`}
        <button type="button" class="primary-sm" data-act="close">Done</button></div>`;
    positionCard();
  }
  function auditionButton() {
    return audition
      ? `<button type="button" class="ghost-btn audition-btn is-on" data-act="audition" title="Stop the transition preview">■ Stop preview</button>`
      : `<button type="button" class="ghost-btn audition-btn" data-act="audition" title="Play a few seconds either side of this transition, using the current settings">▶ Preview transition</button>`;
  }
  function positionCard() {
    const card = $("xsCtxCard");
    if (!ctx || card.hidden) return;
    const g = tlGeom();
    const context = $("xsTlContext");
    const ctxRect = context.getBoundingClientRect();
    const chip = chipRects.find((r) => r.owner === ctx.owner);
    const marker = ctx.owner === "open" ? null : markerById(ctx.owner);
    const anchor = chip ? g.rect.left - ctxRect.left + chip.x + 30 : marker ? g.rect.left + g.x(marker.time) - ctxRect.left : 40;
    const cw = card.offsetWidth;
    const avail = context.offsetWidth;
    const left = clamp(anchor - 70, 0, Math.max(0, avail - cw));
    card.style.marginLeft = `${left}px`;
    card.style.setProperty("--arrow-x", `${clamp(anchor - left, 16, cw - 16)}px`);
    fitCard();
  }
  // On short windows an expanded card borrows height from the timeline instead of being cut off.
  function fitCard() {
    const card = $("xsCtxCard");
    let target = baseHeight;
    if (ctx && !card.hidden) {
      const lower = $("xsTlLower");
      const current = parseFloat(root.style.getPropertyValue("--tl-main-h")) || baseHeight;
      // The export range row sits above the card in the same column.
      const lowerFree = lower.clientHeight - 14 - card.offsetTop + (current - baseHeight);
      const need = card.offsetHeight + 12;
      if (need > lowerFree) target = Math.max(190, baseHeight - (need - lowerFree));
    }
    if (root.style.getPropertyValue("--tl-main-h") !== `${target}px`) {
      root.style.setProperty("--tl-main-h", `${target}px`);
      window.requestAnimationFrame(() => draw());
    }
  }
  function commitEdit(patch) {
    if (!ctx) return;
    if (audition) stopAudition({ seekBack: false });
    const marker = ctx.owner === "open" ? null : markerById(ctx.owner);
    const old = marker || { presetId: startPreset };
    if (Object.keys(patch).every(key => old[key] === patch[key])) return;
    pushUndo(); markEdited();
    if (marker) Object.assign(marker, patch);
    else if (patch.presetId != null) startPreset = patch.presetId;
    ctx.error = "";
    changed();
    // changed() uses Studio's debounced, generation-guarded preview refresh.
  }
  function bindCard() {
    const card = $("xsCtxCard");
    card.addEventListener("click", event => {
      const button = event.target.closest("[data-act]");
      if (!button || button.disabled || !ctx) return;
      const act = button.dataset.act;
      if (act === "close") return closeCard();
      if (act === "more") { ctx.options = !ctx.options; return renderCard(); }
      if (act === "audition") { if (audition) stopAudition(); else previewCandidate(); return; }
      const marker = markerById(ctx.owner);
      if (!marker) return;
      if (act === "remove") {
        if (audition) stopAudition({ seekBack: false });
        pushUndo(); markEdited(); markers = markers.filter(m => m.id !== marker.id);
        ctx = null; changed(); return;
      }
      if (act === "snapExisting") return commitEdit({ time: Number(button.dataset.t) });
      if (act === "trtype") return commitEdit({ transitionKind: button.dataset.v,
        videoTransitionId: button.dataset.v === "video" ? marker.videoTransitionId || videoTransitionOptions[0]?.id || "" : "" });
    });
    card.addEventListener("change", event => {
      const el = event.target, field = el.dataset.field;
      if (!field || !ctx) return;
      if (field === "segPreset") return commitEdit({ presetId: Number(el.value) });
      if (field === "trStyle") return commitEdit({ style: el.value });
      if (field === "trvideo") return commitEdit({ videoTransitionId: el.value });
      if (field === "trTime") {
        const value = parseStudioTime(el.value);
        if (!Number.isFinite(value)) { el.classList.add("invalid"); return; }
        commitEdit({ time: clamp(value, 0.6, duration() - 0.3) });
      }
    });
  }

  function renderHint() {
    const n = markers.length;
    const hint = $("xsTlHint");
    const unavailable = startPreset !== null && authoredPlan().availabilityError;
    if (unavailable) { hint.textContent = unavailable; return; }
    if (startPreset === null) { hint.innerHTML = duration() ? `<span class="analysing">Analysing the track…</span> The automatic sequence appears as soon as the analysis is ready.` : "Load a track in the player to direct its visual journey."; return; }
    if (range().mode === "selected") {
      hint.innerHTML = `Exporting the <b>selected range</b>. Drag the cyan <b>Start</b> and <b>End</b> handles on the waveform, or type exact times below it. Choose <b>Entire track</b> to export everything.`;
      return;
    }
    hint.innerHTML = seqMode === "single" && n === 0
      ? `<b>${presetName(startPreset)}</b> plays for the whole track. Play the music and press <b>Change visual here</b> wherever you want something new.`
      : `<b>${n + 1} visuals</b>, changing at ${n} musical moments. Click a coloured segment to edit it, drag a change to retime it, or press <b>Change visual here</b> to add one at the playhead.${hiddenNames > 0 ? " Some names are hidden at this zoom; hover a segment or zoom in to see them." : ""}`;
  }

  /* ── Playback ── */
  function playing() {
    const audio = getPlaybackAudio?.();
    return Boolean(audio && !audio.paused && !audio.ended);
  }
  async function togglePlay() {
    const unavailable = authoredPlan().availabilityError;
    if (unavailable) { studio.toast(unavailable); return; }
    if (audition) { stopAudition(); return; }
    if (playing()) { pauseAudio?.(); studio.stopLivePreview(); studio.syncPlayButtons(); return; }
    studio.startLivePreview();
    try { await playAudio?.(); } catch (error) { console.error(error); }
    studio.syncPlayButtons();
    tick();
  }
  function tick() {
    window.cancelAnimationFrame(frameRequest);
    const step = () => {
      if (!active || !studio.isOpen()) return;
      $("xsTlTime").innerHTML = `${fmt(playhead(), { tenths: true })} <span>/ ${fmt(duration())}</span>`;
      if (audition && playhead() >= audition.end - 0.02) { stopAudition(); return; }
      if (playing()) {
        const t = playhead();
        if (t > view.start + view.dur * 0.92 || t < view.start) view.start = clamp(t - view.dur * 0.1, 0, Math.max(0, duration() - view.dur));
        draw();
        updatePreviewFoot();
        frameRequest = window.requestAnimationFrame(step);
      }
    };
    frameRequest = window.requestAnimationFrame(step);
  }
  function updatePreviewFoot() {
    const p = presetAt(playhead());
    $("xsPreviewPresetTl").textContent = presetName(p);
    $("xsPreviewSwatchTl").style.background = presetColor(p);
    $("xsPreviewTimeTl").textContent = fmt(playhead());
  }

  /* ── Studio hooks ── */
  function render() {
    if (!active || !studio.isOpen()) return;
    const ready = ensureSequence();
    loadVideoTransitionOptions();
    $("xsTlTime").innerHTML = `${fmt(playhead(), { tenths: true })} <span>/ ${fmt(duration())}</span>`;
    $("xsTlUndo").disabled = !undoStack.length;
    $("xsTlRedo").disabled = !redoStack.length;
    $("xsTlAdd").disabled = !ready;
    $("xsSeqLabel").textContent = seqMode === "single" ? "Single preset" : "Automatic";
    $("xsEditedDot").hidden = !edits;
    syncZoom();
    renderRange();
    draw();
    renderHint();
    renderCard();
    updatePreviewFoot();
  }
  function layout(height) {
    // The waveform stays usable; on laptop-height windows the preview gets the rest.
    baseHeight = Math.round(clamp(height * 0.285 + Math.max(0, height - 900) * 0.35, 200, 440));
    root.style.setProperty("--tl-main-h", `${baseHeight}px`);
    window.requestAnimationFrame(() => { draw(); positionCard(); });
  }
  function closeMenus() {
    $("xsSeqMenu").hidden = true;
    $("xsSeqBtn").setAttribute("aria-expanded", "false");
  }
  function handleKey(event) {
    const key = event.key.toLowerCase();
    if ((event.metaKey || event.ctrlKey) && key === "z") { event.shiftKey ? redo() : undo(); return true; }
    if (event.metaKey || event.ctrlKey || event.altKey) return false;
    if (key === "c" || key === "t") { openAddCard(); return true; }
    if ((event.key === "Delete" || event.key === "Backspace") && ctx?.kind === "seg" && ctx.owner !== "open") { $("xsCtxCard").querySelector('[data-act="remove"]')?.click(); return true; }
    if (event.key === "+" || event.key === "=") { zoom(0.5, playhead()); return true; }
    if (event.key === "-") { zoom(2, playhead()); return true; }
    if (key === "i") { setRangeEdgeAtPlayhead("start"); return true; }
    if (key === "o") { setRangeEdgeAtPlayhead("end"); return true; }
    return false;
  }

  bindTimeline();

  return {
    // Contract used by app.js, the export controller and the preview.
    enabled: () => studio.isCustom(),
    sync: () => render(),
    draw,
    registerHandlers: () => {},
    manualTimeline,
    previewPlan,
    setPreviewEnabled: (value) => { if (!value) studio.stopLivePreview(); },
    // Studio hooks.
    setActive(value) { active = Boolean(value); if (active) { render(); tick(); } else { window.cancelAnimationFrame(frameRequest); closeMenus(); } },
    render,
    redraw: () => { draw(); positionCard(); },
    layout,
    rangeChanged: () => { renderRange(); draw(); renderHint(); },
    summary: () => (startPreset === null ? "Custom timeline" : `${markers.length + 1} visual${markers.length ? "s" : ""}${seqMode === "single" ? "" : edits ? " · edited" : ""}`),
    presetAt,
    closeMenus,
    menusOpen: () => !$("xsSeqMenu").hidden,
    escape: () => { if (!$("xsConfirm").hidden) { $("xsConfirm").hidden = true; return true; } if (ctx) { closeCard(); return true; } return false; },
    togglePlay,
    handleKey,
    state: () => ({ markers: markers.map((m) => ({ ...m })), startPreset, seqMode, seed, edits }),
    openAddCard,
    openSegCard,
    // Transition audition (also offered by the large preview).
    auditioning: () => Boolean(audition),
    auditionLabel: () => audition?.label || "",
    canAudition: () => Boolean(candidate()),
    previewCandidate,
    stopAudition,
    endAudition: () => stopAudition({ seekBack: false }),
    playTransitionFrom,
    zoomAround: (t, dur) => { const total = duration(); const d = clamp(dur, Math.min(10, total), total); view = { dur: d, start: clamp(t - d / 2, 0, Math.max(0, total - d)) }; syncZoom(); draw(); }
  };
}
