const STYLE_ID = "preset-curator-style";
const ROOT_ID = "preset-curator-overlay";

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

export function createPresetCurator({ getPresets, previewPreset, removePresets, onRemoved } = {}) {
  const selected = new Set();
  let records = [];
  let visible = [];
  let removing = false;
  let lastPreviewedId = null;
  let root;
  let list;
  let search;
  let count;
  let selectionCount;
  let log;
  let result;
  let removeButton;
  let previousButton;
  let nextButton;

  function ensureView() {
    if (root) return;
    const style = element("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${ROOT_ID}{position:fixed;z-index:10000;inset:4vh 5vw;background:rgba(13,17,24,.97);color:#eef3fa;border:1px solid #526174;border-radius:12px;box-shadow:0 24px 90px #000b;display:none;flex-direction:column;font:13px -apple-system,BlinkMacSystemFont,sans-serif}
      #${ROOT_ID}.open{display:flex} #${ROOT_ID} *{box-sizing:border-box}
      #${ROOT_ID} header,#${ROOT_ID} footer{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid #34404d;margin:0}
      #${ROOT_ID} header h2{margin:0 auto 0 0;font-size:18px} #${ROOT_ID} button{font:inherit;color:inherit;background:#253140;border:1px solid #455568;border-radius:6px;padding:7px 11px;cursor:pointer}
      #${ROOT_ID} button{width:auto;min-height:32px;flex:0 0 auto}
      #${ROOT_ID} button:hover:not(:disabled){background:#35465a} #${ROOT_ID} button:disabled{opacity:.45;cursor:default}
      #${ROOT_ID} .curator-toolbar{padding:12px 18px;display:flex;align-items:center;gap:10px;border-bottom:1px solid #34404d}
      #${ROOT_ID} input[type=search]{width:auto;min-height:34px;flex:1;min-width:140px;background:#171f29;color:inherit;border:1px solid #465363;border-radius:6px;padding:8px 10px;font:inherit}
      #${ROOT_ID} .curator-list{overflow:auto;flex:1} #${ROOT_ID} .curator-row{display:grid;grid-template-columns:28px minmax(180px,1fr) minmax(90px,150px) 84px;gap:12px;align-items:center;padding:8px 18px;border-bottom:1px solid #29333f;min-height:42px}
      #${ROOT_ID} .curator-row:hover{background:#202a36} #${ROOT_ID} .curator-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer} #${ROOT_ID} .curator-category,#${ROOT_ID} .curator-status{color:#a5b1c0;font-size:12px}
      #${ROOT_ID} .curator-status{grid-column:2/4;margin-top:-5px} #${ROOT_ID} .curator-row:has(.curator-status){padding-bottom:10px}
      #${ROOT_ID} .curator-remove{background:#8c2c35!important;border-color:#b24b55!important;font-weight:600} #${ROOT_ID} .curator-remove:hover:not(:disabled){background:#a2343f!important}
      #${ROOT_ID} footer{border-top:1px solid #34404d;border-bottom:0;flex-wrap:wrap} #${ROOT_ID} .curator-log{max-height:95px;overflow:auto;white-space:pre-wrap;color:#b7c4d3;background:#10151c;padding:8px 10px;border-radius:6px;flex-basis:100%;font:11px ui-monospace,SFMono-Regular,monospace}
      #${ROOT_ID} .curator-result{color:#cfdae7;margin-right:auto} #${ROOT_ID} .curator-result.error{color:#ff9ca3}
      #${ROOT_ID} .curator-confirm-backdrop{position:fixed;z-index:10001;inset:0;background:#0009;display:grid;place-items:center;padding:24px}
      #${ROOT_ID} .curator-confirm{width:min(560px,90vw);max-height:80vh;display:flex;flex-direction:column;gap:12px;background:#151c26;border:1px solid #68788d;border-radius:10px;padding:20px;box-shadow:0 24px 90px #000c}
      #${ROOT_ID} .curator-confirm h3{margin:0;font-size:17px} #${ROOT_ID} .curator-confirm p{margin:0;color:#b7c4d3;line-height:1.4}
      #${ROOT_ID} .curator-confirm-list{max-height:42vh;overflow:auto;margin:0;padding-left:24px;line-height:1.65}
      #${ROOT_ID} .curator-confirm-actions{display:flex;justify-content:flex-end;gap:8px}
      #${ROOT_ID} .curator-confirm-actions .danger{background:#8c2c35;border-color:#b24b55;font-weight:600}
    `;
    document.head.append(style);
    root = element("section");
    root.id = ROOT_ID;
    root.setAttribute("aria-label", "Preset Curator");
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    const header = element("header");
    header.append(element("h2", "", "Preset Curator"));
    const close = element("button", "", "Close");
    close.addEventListener("click", hide);
    header.append(close);
    root.append(header);

    const toolbar = element("div", "curator-toolbar");
    search = element("input");
    search.type = "search";
    search.placeholder = "Search presets…";
    search.setAttribute("aria-label", "Search presets");
    search.setAttribute("autocorrect", "off");
    search.setAttribute("autocomplete", "off");
    search.setAttribute("autocapitalize", "off");
    search.spellcheck = false;
    search.addEventListener("input", render);
    toolbar.append(search);
    const selectAll = element("button", "", "Select All");
    selectAll.addEventListener("click", () => {
      visible.filter((preset) => preset.removable).forEach((preset) => selected.add(preset.id));
      render();
    });
    const selectNone = element("button", "", "Select None");
    selectNone.addEventListener("click", () => { selected.clear(); render(); });
    toolbar.append(selectAll, selectNone);
    count = element("span", "curator-result");
    toolbar.append(count);
    root.append(toolbar);

    list = element("div", "curator-list");
    root.append(list);
    const footer = element("footer");
    previousButton = element("button", "", "Previous");
    previousButton.addEventListener("click", () => previewRelative(-1));
    nextButton = element("button", "", "Next");
    nextButton.addEventListener("click", () => previewRelative(1));
    selectionCount = element("span", "curator-result");
    result = element("span", "curator-result");
    log = element("pre", "curator-log");
    log.hidden = true;
    removeButton = element("button", "curator-remove", "Remove Selected Presets…");
    removeButton.addEventListener("click", confirmRemoval);
    footer.append(previousButton, nextButton, selectionCount, result, removeButton, log);
    root.append(footer);
    document.body.append(root);
    window.__presetCuratorRemovalProgress = handleRemovalProgress;
    window.__presetCuratorRemovalFinished = handleRemovalFinished;
  }

  function hide() { root?.classList.remove("open"); }

  function open() {
    ensureView();
    records = getPresets().slice().sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
    root.classList.add("open");
    result.textContent = "";
    render();
  }

  function render() {
    if (!list) return;
    const query = search.value.trim().toLocaleLowerCase();
    visible = records.filter((preset) => !query || `${preset.name} ${preset.category}`.toLocaleLowerCase().includes(query));
    count.textContent = `${visible.length} shown / ${records.length} presets`;
    selectionCount.textContent = `Selected for removal: ${selected.size}`;
    list.replaceChildren();
    for (const preset of visible) {
      const row = element("div", "curator-row");
      const checkbox = element("input");
      checkbox.type = "checkbox";
      checkbox.checked = selected.has(preset.id);
      checkbox.disabled = removing || !preset.removable;
      checkbox.setAttribute("aria-label", `Select ${preset.name} for removal`);
      checkbox.addEventListener("change", () => {
        checkbox.checked ? selected.add(preset.id) : selected.delete(preset.id);
        render();
      });
      const name = element("span", "curator-name", preset.name);
      name.title = `${preset.name} · ${preset.id}`;
      name.addEventListener("dblclick", () => preview(preset));
      const category = element("span", "curator-category", preset.category || "Uncategorised");
      const previewButton = element("button", "", "Preview");
      previewButton.disabled = removing;
      previewButton.addEventListener("click", () => preview(preset));
      row.append(checkbox, name, category, previewButton);
      if (!preset.removable) {
        const status = element("span", "curator-status", "Geometry renderer: current removal CLI does not support this preset");
        row.append(status);
      }
      list.append(row);
    }
    previousButton.disabled = !visible.length || lastPreviewedId == null;
    nextButton.disabled = !visible.length || lastPreviewedId == null;
    removeButton.disabled = removing || selected.size === 0;
  }

  function preview(preset) {
    lastPreviewedId = preset.id;
    previewPreset(preset.id);
    result.classList.remove("error");
    result.textContent = `Previewing ${preset.name}`;
    const index = visible.findIndex((item) => item.id === preset.id);
    previousButton.disabled = index <= 0;
    nextButton.disabled = index < 0 || index >= visible.length - 1;
  }

  function previewRelative(direction) {
    const index = visible.findIndex((item) => item.id === lastPreviewedId);
    const nextIndex = index < 0 ? (direction > 0 ? 0 : visible.length - 1) : index + direction;
    if (visible[nextIndex]) preview(visible[nextIndex]);
  }

  function confirmRemoval() {
    const selectedRecords = records.filter((preset) => selected.has(preset.id) && preset.removable);
    if (!selectedRecords.length || removing) return;
    const backdrop = element("div", "curator-confirm-backdrop");
    backdrop.setAttribute("role", "presentation");
    const dialog = element("section", "curator-confirm");
    dialog.setAttribute("role", "alertdialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-label", "Confirm preset removal");
    dialog.append(element("h3", "", `Remove ${selectedRecords.length} presets?`));
    dialog.append(element("p", "", "The following presets will be removed from this project:"));
    const names = element("ul", "curator-confirm-list");
    for (const preset of selectedRecords) names.append(element("li", "", preset.name));
    dialog.append(names, element("p", "", "This updates the preset manifest and registry."));
    const actions = element("div", "curator-confirm-actions");
    const cancel = element("button", "", "Cancel");
    cancel.addEventListener("click", () => backdrop.remove());
    const confirm = element("button", "danger", "Remove Presets");
    confirm.addEventListener("click", () => { backdrop.remove(); beginRemoval(selectedRecords); });
    actions.append(cancel, confirm);
    dialog.append(actions);
    backdrop.append(dialog);
    root.append(backdrop);
    cancel.focus();
  }

  function beginRemoval(selectedRecords) {
    if (removing) return;
    removing = true;
    result.classList.remove("error");
    result.textContent = `Removing 1 / ${selectedRecords.length} — ${selectedRecords[0].name}`;
    log.hidden = false;
    log.textContent = "Running scripts/remove-preset.mjs…";
    render();
    removePresets(selectedRecords.map((preset) => preset.id));
  }

  function handleRemovalFinished(payload = {}) {
    removing = false;
    const stdout = String(payload.stdout || "").trim();
    const stderr = String(payload.stderr || "").trim();
    log.textContent = [stdout, stderr && `stderr:\n${stderr}`].filter(Boolean).join("\n\n") || "The removal command returned no output.";
    const removedIds = Array.isArray(payload.ids) ? payload.ids.map(Number) : [];
    if (payload.ok && removedIds.length) {
      const removedSet = new Set(removedIds);
      selectedRecordsRemove(removedSet);
      onRemoved(removedIds);
      result.classList.remove("error");
      result.textContent = `Removed successfully: ${removedIds.length} · Failed: 0`;
    } else {
      result.classList.add("error");
      result.textContent = `Removed successfully: 0 · Failed: ${selected.size}`;
    }
    records = getPresets().slice().sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
    render();
  }

  function handleRemovalProgress(payload = {}) {
    const line = String(payload.line || "").trim();
    if (!line) return;
    result.textContent = line;
    log.hidden = false;
    log.textContent = `${log.textContent === "Running scripts/remove-preset.mjs…" ? "" : `${log.textContent}\n`}${line}`;
    log.scrollTop = log.scrollHeight;
  }

  function selectedRecordsRemove(ids) {
    ids.forEach((id) => selected.delete(id));
  }

  return { open };
}
