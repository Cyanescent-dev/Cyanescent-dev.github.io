export function createPanelVisibilityController({
  body = document.body,
  revealMs = 1600,
  fullscreenRevealMs = 2600
} = {}) {
  let hidden = false;
  let revealTimer = 0;

  function hide() {
    window.clearTimeout(revealTimer);
    hidden = true;
    body.classList.add("panel-hidden");
    body.classList.remove("panel-visible");
  }

  function show() {
    if (!hidden) return;
    window.clearTimeout(revealTimer);
    hidden = false;
    body.classList.remove("panel-hidden");
    body.classList.add("panel-visible");
    if (body.classList.contains("fullscreen-ui")) {
      revealTimer = window.setTimeout(hide, fullscreenRevealMs);
    } else {
      revealTimer = window.setTimeout(() => body.classList.remove("panel-visible"), revealMs);
    }
  }

  function reset() {
    window.clearTimeout(revealTimer);
    hidden = false;
    body.classList.remove("panel-hidden", "panel-visible");
  }

  function isHidden() {
    return hidden;
  }

  return { hide, show, reset, isHidden };
}

export function registerPanelVisibilityHandlers({
  ui,
  controller,
  activateVisuals,
  nativeApp,
  requestBrowserFullscreen,
  onFullscreenChange
} = {}) {
  ui.hidePanel?.addEventListener("click", (event) => {
    event.stopPropagation();
    controller?.hide();
  });

  document.addEventListener("click", (event) => {
    if (controller?.isHidden()) {
      event.preventDefault();
      controller.show();
    }
  }, true);

  document.addEventListener("keydown", () => {
    controller?.show();
  });

  ui.fullscreen?.addEventListener("click", async () => {
    activateVisuals?.();
    const nativeHandler = nativeApp?.();
    if (nativeHandler) {
      nativeHandler.postMessage("toggleFullscreen");
      document.body.classList.add("fullscreen-ui");
      controller?.hide();
      return;
    }
    try {
      await requestBrowserFullscreen?.();
      document.body.classList.add("fullscreen-ui");
      controller?.hide();
    } catch (error) {
      console.error(error);
    }
  });

  document.addEventListener("fullscreenchange", () => {
    const isFullscreen = Boolean(document.fullscreenElement);
    document.body.classList.toggle("fullscreen-ui", isFullscreen);
    if (isFullscreen) controller?.hide();
    else controller?.reset();
    onFullscreenChange?.(isFullscreen);
  });
}
