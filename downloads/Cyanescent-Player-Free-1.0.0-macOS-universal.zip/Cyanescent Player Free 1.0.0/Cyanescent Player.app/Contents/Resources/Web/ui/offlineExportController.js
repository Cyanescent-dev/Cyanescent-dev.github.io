export function createOfflineExportController({
  buildOfflinePresetTimelinePlan,
  computeOfflineAudioState,
  renderOfflineFrameView,
  prepareOfflinePresetFrame,
  getAnalysisTimeline,
  getAnalysisPending,
  getVisualsReady,
  getVisualEngineWarmupPromise,
  getVisualEngineBootComplete,
  warmVisualEngineAtStartup,
  getSlowLevel,
  getSlowBass,
  resetScionBiofeedback,
  setLookaheadState,
  setBands,
  assignAudioFeatures,
  setSmooth,
  setSlowAudio,
  setWaveformProgress,
  setMusicAwareState,
  setVisualRuntimeOfflineState,
  setOfflineVideoBackgroundState,
  videoBackgroundStateAt,
  getTransitionMode,
  getShuffleSeconds,
  getVideoTransitionOptions,
  getRenderedTransitionDuration,
  getManualExportTimeline,
  getActivePreset,
  normalizePresetId,
  adaptiveEligiblePresetIds,
  presetMetadataById,
  addWaveformTransitionMarker,
  resize,
  setExportResolutionOverride,
  setActivePreset,
  setActivePresetStartedAt,
  setPresetSelectValue,
  setOfflineRenderClock,
  getTransition,
  setTransition,
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  renderShaderOrSpecialTransitionFrame,
  getPreviousFrameWasPine3D,
  setPreviousFrameWasPine3D,
  clearFeedbackBuffers
} = {}) {
  function waitForVisualsReady() {
    if (getVisualEngineWarmupPromise?.() && !getVisualEngineBootComplete?.()) {
      return getVisualEngineWarmupPromise().then(() => {
        if (!getVisualsReady?.()) throw new Error("Visual engine did not become ready");
      });
    }
    // The main window renders only for previews and exports: warm it without the splash.
    if (!getVisualsReady?.()) return warmVisualEngineAtStartup?.({ quiet: true });
    return new Promise((resolve, reject) => {
      const started = performance.now();
      const poll = () => {
        if (getVisualsReady?.()) {
          resolve();
          return;
        }
        if (performance.now() - started > 90000) {
          reject(new Error("Visual engine did not become ready"));
          return;
        }
        window.setTimeout(poll, 80);
      };
      poll();
    });
  }

  function waitForAnalysisReady(timeoutMs = 30000) {
    if (getAnalysisTimeline?.()) return Promise.resolve();
    if (!getAnalysisPending?.()) return Promise.resolve();
    return new Promise((resolve) => {
      const started = performance.now();
      const poll = () => {
        if (getAnalysisTimeline?.() || !getAnalysisPending?.() || performance.now() - started > timeoutMs) {
          resolve();
          return;
        }
        window.setTimeout(poll, 120);
      };
      poll();
    });
  }

  function buildOfflinePresetTimeline(duration, {
    analysisTimeline: requestedAnalysisTimeline = getAnalysisTimeline?.(),
    allowManual = true
  } = {}) {
    const manualTimeline = allowManual ? getManualExportTimeline?.({
      startPreset: getActivePreset?.(),
      analysisTimeline: requestedAnalysisTimeline,
      totalDuration: duration,
      videoTransitionOptions: getVideoTransitionOptions?.() || {},
      addWaveformTransitionMarker
    }) : null;
    if (manualTimeline) {
      return Array.isArray(manualTimeline)
        ? { timeline: manualTimeline, startPreset: normalizePresetId?.(getActivePreset?.()) ?? getActivePreset?.() }
        : {
          timeline: Array.isArray(manualTimeline.timeline) ? manualTimeline.timeline : [],
          startPreset: normalizePresetId?.(manualTimeline.startPreset) ?? manualTimeline.startPreset
        };
    }
    const automaticTimeline = buildOfflinePresetTimelinePlan?.({
      analysisTimeline: requestedAnalysisTimeline,
      duration,
      mode: getTransitionMode?.(),
      shuffleSeconds: getShuffleSeconds?.(),
      renderedTransitionDuration: getRenderedTransitionDuration?.(),
      activePreset: getActivePreset?.(),
      normalizePresetId,
      adaptiveEligiblePresetIds,
      presetMetadataById,
      addWaveformTransitionMarker,
      videoTransitionOptions: getVideoTransitionOptions?.() || {}
    }) || [];
    return {
      timeline: automaticTimeline,
      startPreset: normalizePresetId?.(getActivePreset?.()) ?? getActivePreset?.()
    };
  }

  function applyOfflineAudioState(time, duration, requestedAnalysisTimeline = getAnalysisTimeline?.()) {
    const state = computeOfflineAudioState?.({
      analysisTimeline: requestedAnalysisTimeline,
      time,
      duration,
      previousSlowLevel: getSlowLevel?.(),
      previousSlowBass: getSlowBass?.()
    });
    if (!state) return;
    // Offline export renders a loaded track, never live biofeedback: a preset
    // must not inherit a Scion reading from the live session.
    resetScionBiofeedback?.();
    setLookaheadState?.(state.lookaheadState);
    setBands?.(state.bands);
    assignAudioFeatures?.(state.audioFeatures);
    setSmooth?.(state.smooth);
    setSlowAudio?.(state.slowLevel, state.slowBass);
    setWaveformProgress?.(state.waveformProgress);
    setMusicAwareState?.(state.musicAwareState);
    setVisualRuntimeOfflineState?.({
      knotOrbitPhase: state.knotOrbitPhase,
      wavePhaseAccum: state.wavePhaseAccum
    });
  }

  // Audio responses now replay their own fixed audio-time history. Prime the
  // requested timestamp once, without advancing envelopes at the export FPS
  // or inheriting state from live playback. No hidden WebGL frames are needed.
  function prepareOfflineAudioState({
    analysisTimeline: requestedAnalysisTimeline = getAnalysisTimeline?.(),
    startTime = 0,
    duration = 0
  } = {}) {
    const start = Math.max(0, Number(startTime) || 0);
    const state = computeOfflineAudioState?.({ analysisTimeline: requestedAnalysisTimeline, time: start, duration });
    setSlowAudio?.(Number(state?.slowLevel) || 0, Number(state?.slowBass) || 0);
  }

  function renderOfflineFrameAt(time, duration, options, timeline, startPreset, { analysisTimeline: requestedAnalysisTimeline = getAnalysisTimeline?.(), presetStart = 0, sourceTime } = {}) {
    return renderOfflineFrameView?.({
      time,
      duration,
      options,
      timeline,
      startPreset,
      presetStart,
      sourceTime,
      sampleInputsAt: (sampleTime) => {
        // Replaying a stateful director can reach before a selected clip. The
        // clip adapter clamps negative local time, so use the full analysis and
        // an explicit source offset for those history samples.
        const sourceAnalysis = getAnalysisTimeline?.() || requestedAnalysisTimeline;
        const offset = Number.isFinite(sourceTime) ? sourceTime - time : 0;
        const sampled = computeOfflineAudioState({ analysisTimeline: sourceAnalysis,
          time: Math.max(0, sampleTime + offset), duration: sourceAnalysis?.duration || duration,
          previousSlowLevel: 0, previousSlowBass: 0 });
        return { audio: sampled.audioFeatures, smooth: sampled.smooth, music: sampled.musicAwareState,
          lookahead: sampled.lookaheadState, tempo: sourceAnalysis?.tempo };
      },
      resize,
      prepareOfflinePresetFrame,
      applyOfflineAudioState: (frameTime, frameDuration) => applyOfflineAudioState(
        frameTime,
        frameDuration,
        requestedAnalysisTimeline
      ),
      setExportResolutionOverride,
      setActivePreset,
      setActivePresetStartedAt,
      setPresetSelectValue,
      setOfflineRenderClock,
      setFeedbackStep: (value) => setVisualRuntimeOfflineState?.({ feedbackStep: value }),
      setOfflineVideoBackgroundState,
      videoBackgroundStateAt,
      getTransition,
      setTransition,
      isFiddleheadPreset,
      isPineconePreset,
      isQuantumFluidPreset,
      isKleinianCoralCathedralPreset,
      isBloodCellNebulaPreset,
      renderFiddleheadGeometry,
      renderPinecone3D,
      renderQuantumFluid3D,
      renderKleinianCoralCathedral,
      renderBloodCellNebula,
      renderShaderOrSpecialTransitionFrame,
      getPreviousFrameWasPine3D,
      setPreviousFrameWasPine3D,
      clearFeedbackBuffers
    });
  }

  return {
    waitForVisualsReady,
    waitForAnalysisReady,
    buildOfflinePresetTimeline,
    renderOfflineFrameAt,
    prepareOfflineAudioState
  };
}
