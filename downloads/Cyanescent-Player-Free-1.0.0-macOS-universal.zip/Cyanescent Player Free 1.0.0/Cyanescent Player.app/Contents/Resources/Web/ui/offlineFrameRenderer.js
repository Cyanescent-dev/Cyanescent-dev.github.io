import { requireRuntimePreset, enforceTransitionCapabilities } from "../config/runtimeCapabilities.js";
import { exportRenderDimensions } from "./export.js";
import { offlineTransitionStateAt } from "./offlineTimeline.js";

export async function renderOfflineFrame({
  time,
  duration,
  options,
  timeline,
  startPreset,
  presetStart = 0,
  sourceTime = time,
  sampleInputsAt,
  resize,
  applyOfflineAudioState,
  prepareOfflinePresetFrame,
  setExportResolutionOverride,
  setActivePreset,
  setActivePresetStartedAt,
  setPresetSelectValue,
  setOfflineRenderClock,
  setFeedbackStep,
  setOfflineVideoBackgroundState,
  videoBackgroundStateAt,
  getTransition,
  setTransition,
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  renderShaderOrSpecialTransitionFrame,
  getPreviousFrameWasPine3D,
  setPreviousFrameWasPine3D,
  clearFeedbackBuffers
} = {}) {
  requireRuntimePreset(startPreset);
  for (const item of timeline || []) {
    requireRuntimePreset(item.from); requireRuntimePreset(item.to);
  }
  // Work on execution copies so stale authored video choices survive an edition upgrade.
  timeline = (timeline || []).map((item) => enforceTransitionCapabilities({ ...item }));
  const renderSize = exportRenderDimensions(options);
  setExportResolutionOverride(renderSize);
  resize();
  applyOfflineAudioState(time, duration);

  const state = offlineTransitionStateAt(time, timeline, startPreset, presetStart);
  setActivePreset(state.preset);
  setActivePresetStartedAt(state.presetStart * 1000);
  setPresetSelectValue(String(state.preset));

  const now = time * 1000;
  const offlineClock = {
    videoTimeSeconds: time,
    sourceTimeSeconds: sourceTime,
    fps: Number(options.fps) || 30,
    presetTime: Math.max(0, time - state.presetStart),
    presetTimes: state.transition ? { [state.transition.from]: Math.max(0, time - state.transition.fromPresetStart),
      [state.transition.to]: Math.max(0, time - state.transition.toPresetStart) } : { [state.preset]: Math.max(0, time - state.presetStart) },
    feedbackStep: 30 / Math.max(1, Number(options.fps) || 30)
  };
  const videoBackgroundState = videoBackgroundStateAt?.(state.preset, offlineClock.presetTime) || null;
  const resources = await prepareOfflinePresetFrame?.({state,clock:offlineClock,timeline,startPreset,time,sampleInputsAt});
  setOfflineRenderClock(offlineClock);
  setOfflineVideoBackgroundState?.(videoBackgroundState);
  setFeedbackStep(offlineClock.feedbackStep);

  if (state.transition) {
    setTransition({
      active: true,
      from: state.transition.from,
      fromPresetStart: state.transition.fromPresetStart,
      fromPresetStartedAt: state.transition.fromPresetStart * 1000,
      toPresetStartedAt: state.transition.toPresetStart * 1000,
      toPresetStart: state.transition.toPresetStart,
      to: state.transition.to,
      start: state.transition.startTime * 1000,
      duration: state.transition.duration * 1000,
      swapped: state.transition.swapped,
      swapAt: state.transition.swapAt,
      seed: state.transition.seed,
      source: "export",
      style: state.transition.style,
      fromEnergy: state.transition.fromEnergy,
      toEnergy: state.transition.toEnergy,
      suppressShaderTransition: Boolean(state.transition.suppressShaderTransition || state.transition.forceVideoTransition || state.transition.videoTransitionId || state.transition.videoTransition)
    });
  } else {
    setTransition({ ...(getTransition?.() || {}), active: false });
  }

  const frameResult = () => ({ videoBackgroundState, diagnostics: {
    preset: state.preset, presetTime: offlineClock.presetTime, transition: state.transition, resources,
    newton: globalThis.window?.__newtonBasinDiagnostics, apertures: globalThis.window?.__impossibleAperturesDiagnostics
  } });
  const transition = getTransition?.() || {};
  if (!transition.active && isFiddleheadPreset?.(state.preset)) {
    renderFiddleheadGeometry?.(now);
    return frameResult();
  }
  if (!transition.active && isPineconePreset?.(state.preset)) {
    renderPinecone3D?.(now, null, undefined, undefined, state.preset);
    return frameResult();
  }
  if (!transition.active && isQuantumFluidPreset?.(state.preset)) {
    renderQuantumFluid3D?.(now, null, undefined, undefined, state.preset);
    return frameResult();
  }
  if (!transition.active && isKleinianCoralCathedralPreset?.(state.preset)) {
    renderKleinianCoralCathedral?.(now);
    return frameResult();
  }
  if (!transition.active && isBloodCellNebulaPreset?.(state.preset)) {
    renderBloodCellNebula?.(now);
    return frameResult();
  }
  if (getPreviousFrameWasPine3D?.()) {
    clearFeedbackBuffers();
    setPreviousFrameWasPine3D(false);
  }
  renderShaderOrSpecialTransitionFrame(now, time, state.transition?.phase || 0);
  return frameResult();
}
