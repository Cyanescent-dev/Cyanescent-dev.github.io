// Presentation only: no extraction, source changes or authored-name mutation.
export function musicTrackPresentation(track = {}) {
  const originalName = String(track.name || "Untitled track");
  const text = value => typeof value === "string" ? value.trim() : "";
  const metadataTitle = text(track.title) || text(track.metadata?.title);
  const metadataArtist = text(track.artist) || text(track.metadata?.artist);
  if (metadataTitle) return { title: metadataTitle, artist: metadataArtist, originalName };
  const filename = originalName.split(/[\\/]/).pop();
  const stem = filename.replace(/\.(mp3|wav|aiff?|aac|m4a|flac|ogg)$/i, "");
  const bracketed = stem.match(/^\[([^\[\]]+)\]\s+(.+)$/);
  const separated = stem.split(" - ");
  const parts = bracketed ? [bracketed[1], bracketed[2]]
    : separated.length === 2 ? separated : null;
  // Multiple separators or numeric prefixes are ambiguous (often track numbers).
  if (parts && parts.every(part => part.trim()) && !/^\d+$/.test(parts[0].trim())) {
    return { title: parts[1].trim(), artist: metadataArtist || parts[0].trim(), originalName };
  }
  return { title: originalName, artist: metadataArtist, originalName };
}

export function currentTrackFromQueue(queue, currentIndex) {
  return queue[currentIndex] || null;
}

export function repeatModeLabel(repeatMode) {
  if (repeatMode === "one") return "Repeat One";
  if (repeatMode === "all") return "Repeat All";
  return "Repeat Off";
}

export function updateRepeatButton(button, repeatMode) {
  if (!button) return;
  button.textContent = repeatModeLabel(repeatMode);
  button.classList.toggle("active", repeatMode !== "off");
}

export function renderQueueList({
  queueList, queueSummary, prevButton, nextButton, playButton, queue,
  currentEntryId, selectedEntryId, playbackState = "paused", transportCount = queue.length,
  hasPlayerSource, playingElsewhere, onTrackClick, onSelect, onRemove, onMove, onLocate
}) {
  if (!queueList) return;
  const scrollTop = queueList.scrollTop;
  const previousCurrentId = queueList.querySelector('.music-track-row.active [data-action="select"]')?.dataset.entryId;
  const focused = queueList.contains(document.activeElement) ? document.activeElement : null;
  const focusId = focused?.dataset.entryId;
  const focusAction = focused?.dataset.action;
  queueList.replaceChildren();
  const count = queue.length;
  if (queueSummary) queueSummary.textContent = `${count} track${count === 1 ? "" : "s"}${playingElsewhere ? ` · ${playbackState}: ${playingElsewhere} (outside this list)` : ""}`;
  if (prevButton) prevButton.disabled = transportCount === 0;
  if (nextButton) nextButton.disabled = transportCount === 0;
  if (playButton) playButton.disabled = count === 0 && !hasPlayerSource;
  let draggedId = null;
  queue.forEach((track, index) => {
    const current = track.entryId === currentEntryId;
    const selected = track.entryId === selectedEntryId;
    const row = document.createElement("div");
    row.className = `music-track-row${current ? " active" : ""}${selected ? " selected" : ""}`;
    row.setAttribute("role", "listitem");
    row.draggable = true;
    const button = (text, action, label, handler) => {
      const item = document.createElement("button");
      item.type = "button";
      item.textContent = text;
      item.dataset.entryId = track.entryId;
      item.dataset.action = action;
      item.setAttribute("aria-label", label);
      item.title = label;
      item.addEventListener("click", handler);
      row.append(item);
      return item;
    };
    const name = track.name || "Untitled track";
    const presentation = musicTrackPresentation(track);
    const select = button("", "select", `Select ${presentation.title}${presentation.artist ? `, ${presentation.artist}` : ""}${current ? `, current track, ${playbackState}` : ""}`, () => onSelect?.(track.entryId));
    select.title = presentation.originalName;
    const title = document.createElement("span");
    title.className = "music-track-title";
    title.textContent = presentation.title;
    select.append(title);
    if (presentation.artist) {
      const artist = document.createElement("span");
      artist.className = "music-track-artist";
      artist.textContent = presentation.artist;
      select.append(artist);
    }
    if (current) {
      const state = document.createElement("span");
      state.className = "music-track-state";
      state.textContent = playbackState;
      select.append(state);
    }
    select.addEventListener("keydown", event => {
      const destination = ({ ArrowUp: index - 1, ArrowDown: index + 1, Home: 0, End: count - 1 })[event.key];
      if (destination === undefined || event.altKey || event.ctrlKey || event.metaKey) return;
      event.preventDefault();
      const bounded = Math.max(0, Math.min(count - 1, destination));
      onSelect?.(queue[bounded].entryId);
      queueList.querySelectorAll('[data-action="select"]')[bounded]?.focus();
    });
    select.className = "queue-item";
    select.setAttribute("aria-pressed", String(selected));
    if (current) select.setAttribute("aria-current", "true");
    select.addEventListener("dblclick", () => { if (!track.unavailable) onTrackClick?.(index); });
    if (track.unavailable) {
      row.classList.add('unavailable');
      const missing = document.createElement('span');
      missing.className = 'music-track-state';
      missing.textContent = 'File unavailable';
      missing.title = track.error || 'Connect its disk or use Locate File.';
      select.append(missing);
      button('Locate', 'locate', `Locate file for ${name}`, () => onLocate?.(track.entryId));
    } else button("▶", "play", `Play ${name}`, () => onTrackClick?.(index));
    button("↑", "up", `Move ${name} up`, () => onMove?.(track.entryId, index - 1)).disabled = index === 0;
    button("↓", "down", `Move ${name} down`, () => onMove?.(track.entryId, index + 1)).disabled = index === count - 1;
    button("×", "remove", `Remove ${name} from playlist`, () => onRemove?.(track.entryId));
    row.addEventListener("dragstart", event => {
      draggedId = track.entryId;
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("application/x-cyanescent-music-entry", track.entryId);
    });
    row.addEventListener("dragover", event => {
      if (draggedId) { event.preventDefault(); event.dataTransfer.dropEffect = "move"; }
    });
    row.addEventListener("drop", event => {
      if (!draggedId) return;
      event.preventDefault();
      onMove?.(draggedId, index);
      draggedId = null;
    });
    row.addEventListener("dragend", () => { draggedId = null; });
    queueList.appendChild(row);
  });
  queueList.scrollTop = scrollTop;
  // Reveal a newly current track without scrolling the panel header or stealing focus.
  if (currentEntryId && currentEntryId !== previousCurrentId) {
    const activeRow = queueList.querySelector('.music-track-row.active');
    if (activeRow) {
      const listBounds = queueList.getBoundingClientRect();
      const rowBounds = activeRow.getBoundingClientRect();
      if (rowBounds.top < listBounds.top) queueList.scrollTop += rowBounds.top - listBounds.top;
      else if (rowBounds.bottom > listBounds.bottom) queueList.scrollTop += rowBounds.bottom - listBounds.bottom;
    }
  }
  if (focusId) {
    const candidates = Array.from(queueList.querySelectorAll("button"));
    const nextFocus = candidates.find(item => item.dataset.entryId === focusId && item.dataset.action === focusAction && !item.disabled)
      || candidates.find(item => item.dataset.entryId === selectedEntryId);
    nextFocus?.focus({ preventScroll: true });
  }
}

export function renderEmptyQueueState({
  trackName,
  queueSummary,
  updateTrackTime
}) {
  if (trackName) trackName.textContent = "No track loaded";
  updateTrackTime?.();
  if (queueSummary) queueSummary.textContent = "Queue empty";
}

export function registerPlayerControlHandlers({
  ui,
  isReady,
  openTrack,
  openFolder,
  loadFiles,
  togglePlayer,
  playPrevious,
  playNext,
  toggleShuffle,
  cycleRepeatMode,
  applyVolume,
  setStatus,
  setDiagnostic
} = {}) {
  ui.chooseTrack?.addEventListener("click", () => {
    if (!isReady?.()) return;
    openTrack?.();
  });

  ui.importFolder?.addEventListener("click", () => {
    if (!isReady?.()) return;
    openFolder?.();
  });

  ui.audioFile?.addEventListener("change", () => {
    const files = Array.from(ui.audioFile.files || []);
    ui.audioFile.value = ""; // Selecting the same file again creates another distinct entry.
    loadFiles?.(files).catch((error) => {
      setStatus?.("player error");
      setDiagnostic?.(`Could not load track: ${error.message || "unknown error"}`);
      console.error(error);
    });
  });

  ui.playPause?.addEventListener("click", () => {
    if (!isReady?.()) return;
    togglePlayer?.().catch((error) => {
      setStatus?.("player blocked");
      setDiagnostic?.(`Playback blocked: ${error.message || "unknown error"}`);
      console.error(error);
    });
  });

  ui.prevTrack?.addEventListener("click", () => {
    playPrevious?.().catch((error) => {
      setStatus?.("player error");
      setDiagnostic?.(`Could not play previous track: ${error.message || "unknown error"}`);
      console.error(error);
    });
  });

  ui.nextTrack?.addEventListener("click", () => {
    playNext?.().catch((error) => {
      setStatus?.("player error");
      setDiagnostic?.(`Could not play next track: ${error.message || "unknown error"}`);
      console.error(error);
    });
  });

  ui.playerShuffle?.addEventListener("click", () => toggleShuffle?.());
  ui.repeatMode?.addEventListener("click", () => cycleRepeatMode?.());
  ui.playerVolume?.addEventListener("input", () => applyVolume?.());
}

export function formatTrackClock(seconds = 0) {
  const safe = Math.max(0, Number(seconds) || 0);
  const minutes = Math.floor(safe / 60);
  const remaining = Math.floor(safe % 60);
  const hours = Math.floor(minutes / 60);
  const displayMinutes = hours ? minutes % 60 : minutes;
  if (hours) return `${hours}.${String(displayMinutes).padStart(2, "0")}.${String(remaining).padStart(2, "0")}`;
  return `${displayMinutes}.${String(remaining).padStart(2, "0")}`;
}

export function mediaDuration(audio) {
  return audio?.duration && Number.isFinite(audio.duration) ? audio.duration : 0;
}

export function timelineDuration(timeline, audio) {
  return timeline?.duration && Number.isFinite(timeline.duration) ? timeline.duration : mediaDuration(audio);
}

export function clampTrackTime(time, duration) {
  if (!duration) return Math.max(0, time || 0);
  return Math.max(0, Math.min(duration, time || 0));
}

export function updateTrackTimeDisplay({ element, audio, timeline }) {
  if (!element) return;
  const duration = timelineDuration(timeline, audio);
  const current = clampTrackTime(audio?.currentTime || 0, duration);
  element.textContent = `${formatTrackClock(current)}/${formatTrackClock(duration)}`;
}

// The panel is one browsing surface, even when the pointer is over its fixed controls.
export function registerMusicPanelScrolling(panel, list) {
  panel?.addEventListener("wheel", event => {
    if (!list || list.contains(event.target) || event.ctrlKey || !event.deltaY || Math.abs(event.deltaX) > Math.abs(event.deltaY)) return;
    if (list.scrollHeight <= list.clientHeight) return;
    event.preventDefault();
    const unit = event.deltaMode === 1 ? 20 : event.deltaMode === 2 ? list.clientHeight : 1;
    list.scrollTop += event.deltaY * unit;
  }, { passive: false });
}
