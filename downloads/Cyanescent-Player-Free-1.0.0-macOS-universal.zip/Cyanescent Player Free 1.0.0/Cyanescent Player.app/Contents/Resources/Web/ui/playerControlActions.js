export function createPlayerControlActions({
  ui,
  nativeAppBridge,
  loadPlayerFiles,
  togglePlayer,
  playerQueueController,
  getPlayerTime,
  loadTrackAt,
  applyPlayerVolume,
  setStatus,
  setDiagnostic
} = {}) {
  async function navigate(direction) {
    const limit = playerQueueController?.store?.tracks(playerQueueController.playbackPlaylistId?.()).length || 1;
    for (let attempt = 0; attempt < limit; attempt++) {
      const index = direction === 'next' ? playerQueueController?.nextTrackIndex(true)
        : playerQueueController?.previousTrackIndex(getPlayerTime?.() || 0);
      if (!(index >= 0)) return;
      try { await loadTrackAt?.(index, true, playerQueueController?.playbackPlaylistId?.()); return; }
      catch (error) { if (attempt === limit - 1) throw error; }
    }
  }
  return {
    openTrack: () => {
      const nativeApp = nativeAppBridge?.();
      if (nativeApp) nativeApp.postMessage("openAudioFile");
      else ui?.audioFile?.click();
    },
    openFolder: () => {
      const nativeApp = nativeAppBridge?.();
      if (nativeApp) nativeApp.postMessage("openAudioFolder");
      else ui?.audioFile?.click();
    },
    loadFiles: (files) => loadPlayerFiles?.(files, false),
    togglePlayer,
    playPrevious: () => navigate('previous'),
    playNext: () => navigate('next'),
    toggleShuffle: playerQueueController?.toggleShuffle,
    cycleRepeatMode: playerQueueController?.cycleRepeatMode,
    applyVolume: applyPlayerVolume,
    setStatus,
    setDiagnostic
  };
}
