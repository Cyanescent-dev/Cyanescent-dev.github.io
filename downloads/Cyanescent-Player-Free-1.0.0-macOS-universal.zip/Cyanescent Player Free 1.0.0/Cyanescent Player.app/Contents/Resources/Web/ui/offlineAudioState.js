import { clamp01, smoothstepJs } from "../utils/math.js";
import { DROP_STATE_DEFAULTS, dropMapEnabled, dropStateFields } from "../audio/dropMap.js";
import { sampleOfflineAudioResponse } from "./offlineAudioResponse.js";

const offlineEnergyIntegralCache = new WeakMap();

function buildOfflineEnergyIntegral(analysisTimeline) {
  const frames = Array.isArray(analysisTimeline?.frames) ? analysisTimeline.frames : [];
  if (!frames.length) return null;
  const times = frames.map((frame, index) => Math.max(
    0,
    Number(frame?.time) || index * (Number(analysisTimeline.frameDuration) || 0.05)
  ));
  const energies = frames.map((frame) => clamp01(Number(frame?.energy) || 0));
  const prefix = new Float64Array(frames.length);
  prefix[0] = times[0] * energies[0];
  for (let index = 1; index < frames.length; index += 1) {
    const elapsed = Math.max(0, times[index] - times[index - 1]);
    prefix[index] = prefix[index - 1]
      + elapsed * (energies[index - 1] + energies[index]) * 0.5;
  }
  return { frames, times, energies, prefix };
}

export function integratedOfflineEnergyAt(analysisTimeline, time, fallbackEnergy = 0) {
  const targetTime = Math.max(0, Number(time) || 0);
  if (!analysisTimeline || !Array.isArray(analysisTimeline.frames) || !analysisTimeline.frames.length) {
    return targetTime * clamp01(Number(fallbackEnergy) || 0);
  }
  let cached = offlineEnergyIntegralCache.get(analysisTimeline);
  if (!cached || cached.frames !== analysisTimeline.frames || cached.times.length !== analysisTimeline.frames.length) {
    cached = buildOfflineEnergyIntegral(analysisTimeline);
    offlineEnergyIntegralCache.set(analysisTimeline, cached);
  }
  const { times, energies, prefix } = cached;
  if (targetTime <= times[0]) return targetTime * energies[0];
  const lastIndex = times.length - 1;
  if (targetTime >= times[lastIndex]) {
    return prefix[lastIndex] + (targetTime - times[lastIndex]) * energies[lastIndex];
  }
  let low = 0;
  let high = lastIndex;
  while (low + 1 < high) {
    const middle = Math.floor((low + high) / 2);
    if (times[middle] <= targetTime) low = middle;
    else high = middle;
  }
  const interval = Math.max(0.000001, times[high] - times[low]);
  const fraction = clamp01((targetTime - times[low]) / interval);
  const targetEnergy = energies[low] + (energies[high] - energies[low]) * fraction;
  const elapsed = targetTime - times[low];
  return prefix[low] + elapsed * (energies[low] + targetEnergy) * 0.5;
}

function parseOfflineEnergyLevel(label) {
  const match = String(label || "").match(/Energy\s*([1-5])|E([1-5])/i);
  if (!match) return 0;
  return Number(match[1] || match[2] || 0) || 0;
}

export function offlineKickTransientAt(analysisTimeline, time, current = null) {
  const frameDuration = Math.max(0.001, Number(analysisTimeline?.frameDuration) || 0.05);
  const scoreAt = (sampleTime) => {
    const storedScore = analysisTimeline?.getKickScoreAt?.(Math.max(0, sampleTime));
    if (Number.isFinite(storedScore)) return clamp01(storedScore);
    // Compatibility for synthetic/older timelines that do not carry the new
    // detector output. beatStrength is analysis-derived, not tempo-grid-derived.
    const features = sampleTime === time && current
      ? current
      : analysisTimeline?.getFeatures?.(Math.max(0, sampleTime));
    return clamp01(Number(features?.kickScore ?? features?.beatStrength) || 0);
  };
  const shape = (score) => smoothstepJs(0.16, 0.72, score);
  const attack = shape(scoreAt(time));
  const release1 = shape(scoreAt(time - frameDuration)) * 0.56;
  const release2 = shape(scoreAt(time - frameDuration * 2)) * 0.22;
  return clamp01(Math.max(attack, release1, release2));
}

export function relativeOfflineBandEnergy(current, longAverage) {
  const baseline = Math.max(0.025, Number(longAverage) || 0);
  return Math.max(0, Math.min(2.8, (Number(current) || 0) / baseline));
}

export function computeOfflineAudioState({
  analysisTimeline,
  time,
  duration
} = {}) {
  const current = analysisTimeline?.getFeatures(time) || {
    energy: 0.18,
    bass: 0.16,
    mid: 0.14,
    treble: 0.12,
    brightness: 0.18,
    density: 0.18,
    beatStrength: 0.2,
    sectionProbability: 0
  };
  const short = analysisTimeline?.getLookaheadFeatures(time, 0.5) || current;
  const medium = analysisTimeline?.getLookaheadFeatures(time, 5) || current;
  const long = analysisTimeline?.getLookaheadFeatures(time, 20) || medium;
  const beatInfo = analysisTimeline?.getBeatInfo(time) || null;
  const beatDistance = beatInfo ? Math.min(beatInfo.beatPhase, 1 - beatInfo.beatPhase) : 1;
  const gridPulse = beatInfo ? smoothstepJs(0.16, 0.0, beatDistance) : 0;
  const transientKick = offlineKickTransientAt(analysisTimeline, time, current);
  // The detected transient owns timing. A correctly aligned beat grid may
  // reinforce it slightly, but a phase error can never create a late kick.
  const beatPulse = clamp01(transientKick * (0.94 + gridPulse * 0.12));
  const dropWindow = analysisTimeline?.sections?.some((section, index) => {
    if (index === 0 || Math.abs(section.start - time) > 0.28) return false;
    const previous = analysisTimeline.sections[index - 1];
    const previousLevel = previous.level || parseOfflineEnergyLevel(previous.label) || 0;
    const sectionLevel = section.level || parseOfflineEnergyLevel(section.label) || 0;
    return sectionLevel >= 5 && sectionLevel > previousLevel;
  }) ? 1 : 0;

  // the track's drop map (as in live playback, musicAware.js) when there is one
  const dropFields = dropMapEnabled() ? dropStateFields(analysisTimeline?.getDropInfo?.(time)) : null;

  const bands = {
    kick: clamp01(beatPulse),
    bass: clamp01(current.bass * 1.28 + beatPulse * 0.18),
    mids: clamp01(current.mid * 1.18),
    highs: clamp01(current.treble * 1.08),
    brightness: clamp01(current.brightness * 1.16),
    level: clamp01(current.energy * 1.12)
  };
  const response = sampleOfflineAudioResponse(analysisTimeline, time, (sampleTime) => {
    const frame = analysisTimeline?.getFeatures(sampleTime) || current;
    const beat = analysisTimeline?.getBeatInfo(sampleTime);
    const distance = beat ? Math.min(beat.beatPhase, 1 - beat.beatPhase) : 1;
    const pulse = clamp01(offlineKickTransientAt(analysisTimeline, sampleTime, frame)
      * (0.94 + (beat ? smoothstepJs(0.16, 0.0, distance) : 0) * 0.12));
    const lookaheadAt = (seconds) => ({ maxEnergy: frame.energy,
      maxSectionProbability: frame.sectionProbability || 0,
      ...(analysisTimeline?.getLookaheadFeatures(sampleTime, seconds) || frame) });
    return { bands: {
      kick: pulse, bass: clamp01(frame.bass * 1.28 + pulse * 0.18),
      mids: clamp01(frame.mid * 1.18), highs: clamp01(frame.treble * 1.08),
      brightness: clamp01(frame.brightness * 1.16), level: clamp01(frame.energy * 1.12)
    }, lookahead: { ready: true, current: frame,
      short: lookaheadAt(0.5), medium: lookaheadAt(5), long: lookaheadAt(20) } };
  });
  const audioFeatures = {
    bassNow: bands.bass, midNow: bands.mids, trebleNow: bands.highs,
    ...Object.fromEntries(["bassFast", "midFast", "trebleFast", "bassSlow", "midSlow", "trebleSlow",
      "bassRel", "midRel", "trebleRel", "globalEnergy", "globalEnergyFast", "globalEnergySlow"]
      .map((key) => [key, response.features[key]])),
    kickPulse: beatPulse,
    dropDetected: dropFields ? (dropFields.dropAge < 0.32 ? 1 : 0) : dropWindow
  };

  return {
    lookaheadState: { ready: true, current, short, medium, long },
    bands,
    audioFeatures,
    smooth: response.smooth,
    slowLevel: response.slowLevel,
    slowBass: response.slowBass,
    waveformProgress: duration ? clamp01(time / duration) : 0,
    musicAwareState: {
      ...response.music,
      // An analysed drop is an exact musical accent, like the detected kick.
      // Preserve its immediate attack while structural levels use live envelopes.
      drop: dropFields ? dropFields.dropPulse : dropWindow,
      phraseProgress: beatInfo?.phrase32Progress || 0,
      beatPhase: beatInfo?.beatPhase || 0,
      absoluteBeat: beatInfo ? (beatInfo.beatIndex + beatInfo.beatPhase) : (time * 2.4),
      nextPhraseSeconds: beatInfo?.nextLoopSeconds || 0,
      ...(dropFields || DROP_STATE_DEFAULTS)
    },
    knotOrbitPhase: response.orbitPhase,
    wavePhaseAccum: response.wavePhase
  };
}
