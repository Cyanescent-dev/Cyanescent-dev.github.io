// Native WebKit does not reliably support window.prompt/confirm. Use a real modal.
export function requestMusicPlaylistAction({ title, name, confirmLabel = 'Save', message = '' }) {
  return new Promise(resolve => {
    const dialog = document.createElement('dialog');
    dialog.className = 'music-playlist-dialog';
    const form = document.createElement('form');
    form.method = 'dialog';
    const heading = document.createElement('h3');
    heading.id = 'musicPlaylistDialogTitle';
    heading.textContent = title;
    dialog.setAttribute('aria-labelledby', heading.id);
    form.append(heading);
    let input;
    if (name !== undefined) {
      const label = document.createElement('label');
      label.textContent = 'Playlist name';
      input = document.createElement('input');
      input.value = name;
      input.required = true;
      input.maxLength = 80;
      label.append(input);
      form.append(label);
    }
    if (message) {
      const text = document.createElement('p');
      text.textContent = message;
      form.append(text);
    }
    const actions = document.createElement('div');
    actions.className = 'music-playlist-actions';
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.textContent = 'Cancel';
    cancel.addEventListener('click', () => dialog.close());
    const confirm = document.createElement('button');
    confirm.type = 'submit';
    confirm.className = 'primary';
    confirm.textContent = confirmLabel;
    actions.append(cancel, confirm);
    form.append(actions);
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (input && !input.value.trim()) { input.focus(); return; }
      dialog.close('confirm');
    });
    dialog.append(form);
    dialog.addEventListener('close', () => {
      const result = dialog.returnValue === 'confirm' ? (input ? input.value.trim() : true) : null;
      dialog.remove();
      resolve(result);
    }, { once: true });
    document.body.append(dialog);
    dialog.showModal();
    if (input) { input.focus(); input.select(); } else cancel.focus();
  });
}
