import { capabilityEnabled, enforceRuntimeOptions } from "../config/runtimeCapabilities.js";
export const APP_OPTIONS_KEY = "cyanescent.player.options.v1";

export function defaultAppOptions(defaultTransitionMode) {
  return {
    defaultPlaylistId: "",
    transitionMode: defaultTransitionMode,
    shuffleSeconds: 45,
    adaptiveTransitionTime: "medium",
    useVideoTransitions: false,
    videoTransitionMode: "auto",
    videoTransitionDurationMs: 10000,
    videoTransitionFadeMs: 4300,
    debugMode: false,
    showInputMeter: false,
    alienVisits: capabilityEnabled("alienVisits"),
    exportStudio: {
      destinationId: "youtube-hd-60",
      customWidth: 1920,
      customHeight: 1080,
      customFps: 60,
      bitrateMbps: 18,
      framingMode: "adaptive",
      safeAreaGuide: "none",
      autoClipBehaviour: "standalone",
      audioFormat: "aac",
      audioBitrateKbps: 256,
      loopPreview: false,
      canvasLoopBehaviour: "restart"
    }
  };
}

export function loadAppOptions(defaultTransitionMode, { ignorePersisted = false } = {}) {
  const defaults = defaultAppOptions(defaultTransitionMode);
  if (ignorePersisted) return defaults;
  try {
    const parsed = JSON.parse(localStorage.getItem(APP_OPTIONS_KEY) || "{}");
    return enforceRuntimeOptions({
      ...defaults,
      ...parsed,
      exportStudio: {
        ...defaults.exportStudio,
        ...(parsed?.exportStudio && typeof parsed.exportStudio === "object" ? parsed.exportStudio : {})
      },
      videoTransitionDurationMs: 10000,
      videoTransitionFadeMs: 4300
    });
  } catch (error) {
    return defaults;
  }
}

export function persistAppOptions(options) {
  try {
    localStorage.setItem(APP_OPTIONS_KEY, JSON.stringify(options));
  } catch (error) {
    console.warn("Could not save options", error);
  }
}

export function updateAppOption(options, key, value, persist = persistAppOptions) {
  if (!options || !key) return options;
  options[key] = value;
  enforceRuntimeOptions(options);
  persist?.(options);
  return options;
}

export function debugModeEnabled(debugControl) {
  return debugControl?.checked !== false;
}

export function displayDefaultFolderPath(input, path) {
  if (!input) return;
  input.value = path || "Music folder";
}

export function applyOptionsToUi({
  ui,
  options,
  defaultTransitionMode,
  onDebugModeApplied
}) {
  enforceRuntimeOptions(options);
  for (const [key, capability] of [["useVideoTransitions", "videoTransitions"], ["videoTransitionMode", "videoTransitions"], ["alienVisits", "alienVisits"]]) {
    if (ui[key]) {
      ui[key].disabled = !capabilityEnabled(capability);
      ui[key].title = capabilityEnabled(capability) ? "" : "Available in Pro Video";
    }
  }
  if (ui.transitionMode) ui.transitionMode.value = options.transitionMode || defaultTransitionMode;
  if (ui.shuffleSeconds) ui.shuffleSeconds.value = String(Math.max(5, Math.min(600, Number(options.shuffleSeconds) || 45)));
  if (ui.adaptiveTransitionTime) ui.adaptiveTransitionTime.value = options.adaptiveTransitionTime || "medium";
  updateTransitionTimingControlVisibility(ui, options.transitionMode || defaultTransitionMode);
  if (ui.useVideoTransitions) ui.useVideoTransitions.checked = Boolean(options.useVideoTransitions);
  if (ui.videoTransitionMode) ui.videoTransitionMode.value = options.videoTransitionMode || "auto";
  if (ui.debugMode) ui.debugMode.checked = options.debugMode !== false;
  if (ui.alienVisits) ui.alienVisits.checked = options.alienVisits !== false;
  if (ui.showInputMeter) ui.showInputMeter.checked = Boolean(options.showInputMeter);
  if (ui.inputMeter) ui.inputMeter.classList.toggle("hidden", !ui.showInputMeter?.checked);
  onDebugModeApplied?.();
}


export function adaptiveTransitionTimingPreset(value) {
  return ["short", "medium", "long"].includes(value) ? value : "medium";
}

export function updateTransitionTimingControlVisibility(ui, transitionMode) {
  const isAdaptive = transitionMode === "adaptive";
  const isShuffle = transitionMode === "shuffle";
  ui.adaptiveTimeControl?.classList.toggle("hidden", !isAdaptive);
  ui.shuffleTimeControl?.classList.toggle("hidden", !isShuffle);
}

export function updateScionModeControlVisibility(ui, audioSource = ui?.deviceSelect?.value) {
  ui?.scionModeControl?.classList.toggle("hidden", audioSource !== "scion");
}

export function openOptionsDialog(overlay) {
  overlay?.classList.remove("hidden");
}

export function closeOptionsDialog(overlay) {
  overlay?.classList.add("hidden");
}

export function requestDefaultFolderPath(nativeApp) {
  nativeApp?.postMessage({ command: "requestDefaultFolder" });
}

export function chooseDefaultFolder(nativeApp, path = "") {
  nativeApp?.postMessage({ command: "chooseDefaultFolder", path });
}

export function loadDefaultFolder(nativeApp, path = "", reason = "manual") {
  nativeApp?.postMessage({
    command: "loadDefaultFolder",
    path,
    reason
  });
}

export function createDefaultFolderStartupLoader({
  isReady,
  hasQueue,
  loadDefaultFolder
} = {}) {
  let requested = false;
  return function maybeLoadDefaultFolderOnStartup() {
    if (requested || !isReady?.() || hasQueue?.()) return;
    requested = true;
    loadDefaultFolder?.("startup");
  };
}

export function registerDefaultFolderCallbacks({
  target = window,
  hasConfiguredPath,
  setPath,
  displayPath,
  setDiagnostic
} = {}) {
  target.__defaultFolderPath = (payload) => {
    const path = payload?.path || "";
    if (!hasConfiguredPath?.()) setPath?.(path, false);
    else displayPath?.();
  };

  target.__defaultFolderChosen = (payload) => {
    const path = payload?.path || "";
    setPath?.(path, true);
    setDiagnostic?.(path ? "Default folder updated" : "Default folder unchanged");
  };

  target.__defaultFolderLoaded = (payload) => {
    if (payload?.path) setPath?.(payload.path, !hasConfiguredPath?.());
    const count = Number(payload?.count) || 0;
    setDiagnostic?.(count
      ? `Loaded ${count} track${count === 1 ? "" : "s"} from default folder`
      : "Default folder contains no supported audio files");
  };

  target.__defaultFolderLoadFailed = (payload) => {
    setDiagnostic?.(`Default folder unavailable: ${payload?.error || "unknown error"}`);
  };
}

export function registerOptionsDialogHandlers({
  ui,
  openDialog,
  closeDialog,
  updateDebugMode,
  updateInputMeter,
  updateVideoTransitions,
  updateAlienVisits
} = {}) {
  ui.optionsButton?.addEventListener("click", () => openDialog?.());
  ui.closeOptions?.addEventListener("click", () => closeDialog?.());
  ui.optionsOverlay?.addEventListener("click", (event) => {
    if (event.target === ui.optionsOverlay) closeDialog?.();
  });
  ui.debugMode?.addEventListener("change", () => updateDebugMode?.());
  ui.showInputMeter?.addEventListener("change", () => updateInputMeter?.());
  ui.alienVisits?.addEventListener("change", () => updateAlienVisits?.());
  ui.useVideoTransitions?.addEventListener("change", () => updateVideoTransitions?.());
  ui.videoTransitionMode?.addEventListener("change", () => updateVideoTransitions?.());
}

export function registerVisualSettingsHandlers({
  ui,
  refreshDevices,
  selectAudioSource,
  selectPreset,
  updateTransitionMode,
  updateShuffleSeconds,
  updateAdaptiveTransitionTime,
  setStandardQuality,
  setHighQuality
} = {}) {
  ui.deviceSelect?.addEventListener("pointerdown", () => refreshDevices?.());
  ui.deviceSelect?.addEventListener("focus", () => refreshDevices?.());
  ui.deviceSelect?.addEventListener("change", () => {
    updateScionModeControlVisibility(ui);
    selectAudioSource?.(ui.deviceSelect.value);
  });
  ui.presetSelect?.addEventListener("change", () => selectPreset?.(Number(ui.presetSelect.value)));
  ui.transitionMode?.addEventListener("change", () => updateTransitionMode?.(ui.transitionMode.value));
  ui.shuffleSeconds?.addEventListener("change", () => updateShuffleSeconds?.(ui.shuffleSeconds.value));
  ui.adaptiveTransitionTime?.addEventListener("change", () => updateAdaptiveTransitionTime?.(ui.adaptiveTransitionTime.value));
  ui.standardMode?.addEventListener("click", () => setStandardQuality?.());
  ui.highMode?.addEventListener("click", () => setHighQuality?.());
}
