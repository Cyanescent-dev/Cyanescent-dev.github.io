import { capabilityEnabled, runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
import { fractJs, clamp01 } from "../utils/math.js";
import { createDiversityCycle } from "../engine/diversityCycle.js";
import {
  MusicalEventType,
  transitionDurationForStyle,
  TransitionEnergyStyle,
  transitionSwapPointForStyle,
  VisualTransitionMode
} from "../engine/transitions.js";
function parseOfflineEnergyLevel(label) {
  const match = String(label || "").match(/Energy\s*([1-5])|E([1-5])/i);
  if (!match) return 0;
  return Number(match[1] || match[2] || 0) || 0;
}

export function offlineEnergyLevelAt(analysisTimeline, time) {
  const sectionLevel = parseOfflineEnergyLevel(analysisTimeline?.getSectionAt(time)?.label);
  if (sectionLevel) return sectionLevel;
  const current = analysisTimeline?.getFeatures(time);
  const energy = current?.energy ?? 0;
  if (energy < 0.12) return 1;
  if (energy < 0.28) return 2;
  if (energy < 0.48) return 3;
  if (energy < 0.68) return 4;
  return 5;
}

export function offlineEventTypeForLevels(fromLevel, toLevel) {
  if (toLevel > fromLevel && toLevel >= 5) return MusicalEventType.DROP;
  if (toLevel > fromLevel) return MusicalEventType.BUILD_UP;
  if (toLevel < fromLevel && toLevel <= 2) return MusicalEventType.BREAKDOWN;
  if (toLevel < fromLevel) return MusicalEventType.CALM_SECTION;
  return toLevel >= 5 ? MusicalEventType.HIGH_ENERGY : MusicalEventType.SECTION_CHANGE;
}

export function chooseOfflinePreset({
  event,
  fromPreset,
  diversity,
  adaptiveEligiblePresetIds,
  presetMetadataById
}) {
  const ids = (adaptiveEligiblePresetIds?.() || []).filter((id) => runtimeAllowsPreset(id));
  if (ids.length <= 1) return fromPreset;
  const candidates = diversity?.candidates(ids, { activeId: fromPreset }) || [];
  if (!candidates.length) return fromPreset;
  const recentPresets = diversity?.recentIds().map(Number) || [];
  const scored = [];
  const targetLevel = event.energyLevel || 3;
  for (const id of candidates) {
    const metadata = presetMetadataById.get(id);
    let score = 0;
    if (recentPresets.includes(id)) score -= 0.45;
    if (targetLevel >= 5) score += metadata?.energyLevel === "high" ? 2.2 : metadata?.energyLevel === "medium" ? 0.6 : -1.0;
    else if (targetLevel <= 2) score += metadata?.goodForBreakdowns ? 2.0 : metadata?.energyLevel === "low" ? 1.4 : -0.8;
    else score += metadata?.energyLevel === "medium" ? 1.3 : 0.1;
    if (event.type === MusicalEventType.DROP && metadata?.goodForDrops) score += 1.4;
    if (event.type === MusicalEventType.BUILD_UP && metadata?.goodForBuildUps) score += 1.0;
    if ((event.type === MusicalEventType.BREAKDOWN || event.type === MusicalEventType.CALM_SECTION) && metadata?.goodForBreakdowns) score += 1.2;
    score += fractJs(Math.sin(id * 19.19 + event.time * 0.731 + recentPresets.length * 4.77) * 10313.13) * 0.90;
    scored.push({ id, score });
  }
  if (!scored.length) return fromPreset;
  scored.sort((a, b) => b.score - a.score);
  const bestScore = scored[0].score;
  const pool = scored.filter((item, index) => index < 5 && item.score >= bestScore - 1.05);
  const pickIndex = Math.floor(fractJs(Math.sin(event.time * 31.57 + fromPreset * 8.21 + recentPresets.length * 13.11) * 6237.23) * pool.length);
  return pool[Math.max(0, Math.min(pool.length - 1, pickIndex))].id;
}

export function bestOfflineLandingTime(analysisTimeline, start, end, preferred = null) {
  if (!analysisTimeline) return preferred ?? start;
  const candidates = analysisTimeline.getLoopBoundariesBetween(start, end, [8, 16, 32]);
  if (preferred !== null) candidates.push({ time: preferred, beats: null });
  if (!candidates.length) return preferred ?? start;
  let best = candidates[0];
  let bestScore = Infinity;
  for (const candidate of candidates) {
    const distance = preferred === null ? 0 : Math.abs(candidate.time - preferred);
    const score = distance + (candidate.beats === 32 ? -0.18 : candidate.beats === 16 ? -0.10 : 0);
    if (score < bestScore) {
      bestScore = score;
      best = candidate;
    }
  }
  return best.time;
}

export function videoTransitionDurationSeconds(options = {}) {
  return 10;
}

// Shared with Custom Timeline's Quick on the Beat style; never changes style
// or landing selection, only the length of Automatic rendered overlap.
export function automaticRenderedTransitionDuration(value) {
  const seconds = Number(value);
  return [2.6, 6, 12].includes(seconds) ? seconds : transitionDurationForStyle(TransitionEnergyStyle.RISING) / 1000;
}

export const RENDERED_TRANSITION_CHOICES = Object.freeze([
  { key: "quick", value: 2.6, label: "Quick on the beat" },
  { key: "smooth", value: 6, label: "Smooth" },
  { key: "extended", value: 12, label: "Extended fade" }
]);

export function renderedTransitionTiming(seconds, style) {
  return { duration: automaticRenderedTransitionDuration(seconds), swapAt: transitionSwapPointForStyle(style) };
}

export function fitRenderedTransitionWindow(landing, seconds, swapAt, earliest, latest) {
  const duration = Math.max(0.001, Math.min(seconds, (landing - earliest) / swapAt, (latest - landing) / (1 - swapAt)));
  return { startTime: landing - duration * swapAt, endTime: landing + duration * (1 - swapAt), duration };
}

function presetAnimationStart(item) {
  return item.suppressShaderTransition || item.forceVideoTransition || item.videoTransitionId || item.videoTransition
    ? item.landingTime : item.startTime;
}

export function buildOfflinePresetTimeline({
  analysisTimeline,
  duration,
  mode,
  shuffleSeconds,
  activePreset,
  normalizePresetId,
  adaptiveEligiblePresetIds,
  presetMetadataById,
  addWaveformTransitionMarker,
  videoTransitionOptions = {},
  renderedTransitionDuration = 2.6
}) {
  const timeline = [];
  let fromPreset = normalizePresetId(activePreset);
  let fromEnergy = offlineEnergyLevelAt(analysisTimeline, 0);
  let lastLanding = 0;
  const presetDiversity = createDiversityCycle();
  presetDiversity.record(fromPreset, adaptiveEligiblePresetIds?.() || []);
  if (mode === VisualTransitionMode.STATIC || duration < 8) return timeline;

  const candidates = [];
  if (mode === VisualTransitionMode.SHUFFLE) {
    const interval = Math.max(5, Number(shuffleSeconds) || 45);
    for (let time = interval; time < duration - 2; time += interval) {
      candidates.push({ time, level: offlineEnergyLevelAt(analysisTimeline, time), forced: true });
    }
  } else if (analysisTimeline?.sections?.length) {
    for (let i = 1; i < analysisTimeline.sections.length; i += 1) {
      const previous = analysisTimeline.sections[i - 1];
      const section = analysisTimeline.sections[i];
      const previousLevel = previous.level || parseOfflineEnergyLevel(previous.label) || offlineEnergyLevelAt(analysisTimeline, previous.start);
      const level = section.level || parseOfflineEnergyLevel(section.label) || offlineEnergyLevelAt(analysisTimeline, section.start);
      if (previousLevel !== level && section.start > 4 && section.start < duration - 2) {
        candidates.push({ time: section.start, level, previousLevel });
      }
    }
  }

  for (let forced = 45; forced < duration - 2; forced += 45) {
    candidates.push({ time: forced, level: offlineEnergyLevelAt(analysisTimeline, forced), soft: true });
  }
  candidates.sort((a, b) => a.time - b.time);

  for (const originalCandidate of candidates) {
    const earliest = lastLanding === 0 ? 35 : lastLanding + 20;
    const latest = lastLanding === 0 ? Math.min(120, duration - 2) : Math.min(duration - 2, lastLanding + 50);
    let candidate = originalCandidate;
    if (candidate.time < earliest && !candidate.soft) continue;
    if (candidate.time > latest && !candidate.soft) {
      const forcedTime = bestOfflineLandingTime(analysisTimeline, earliest, latest, null);
      candidate = { time: forcedTime, level: offlineEnergyLevelAt(analysisTimeline, forcedTime), forced: true };
    }
    if (candidate.time < earliest || candidate.time > latest || candidate.time <= lastLanding + 0.5) continue;
    const toEnergy = candidate.level || offlineEnergyLevelAt(analysisTimeline, candidate.time);
    const type = offlineEventTypeForLevels(fromEnergy, toEnergy);
    const style = toEnergy > fromEnergy ? TransitionEnergyStyle.RISING : toEnergy < fromEnergy ? TransitionEnergyStyle.FALLING : TransitionEnergyStyle.STEADY;
    const useVideoTransitionTiming = Boolean(capabilityEnabled("videoTransitions") && videoTransitionOptions.useVideoTransitions);
    const renderedTiming = renderedTransitionTiming(renderedTransitionDuration, style);
    const durationSeconds = useVideoTransitionTiming ? videoTransitionDurationSeconds(videoTransitionOptions) : renderedTiming.duration;
    const landing = bestOfflineLandingTime(
      analysisTimeline,
      Math.max(0, candidate.time - 2.0),
      Math.min(duration - 0.5, candidate.time + 2.0),
      candidate.time
    );
    const swapAt = useVideoTransitionTiming ? 0.5 : renderedTiming.swapAt;
    const previousEnd = timeline.at(-1)?.endTime || 0;
    const window = useVideoTransitionTiming
      ? { startTime: Math.max(previousEnd, landing - durationSeconds * swapAt) }
      : fitRenderedTransitionWindow(landing, durationSeconds, swapAt, previousEnd, duration);
    const startTime = window.startTime;
    const endTime = useVideoTransitionTiming ? Math.min(duration, startTime + durationSeconds) : window.endTime;
    const toPreset = chooseOfflinePreset({
      event: { type, time: landing, energyLevel: toEnergy },
      fromPreset,
      diversity: presetDiversity,
      adaptiveEligiblePresetIds,
      presetMetadataById
    });
    if (toPreset === fromPreset) continue;
    timeline.push({
      from: fromPreset,
      to: toPreset,
      fromEnergy,
      toEnergy,
      type,
      style,
      seed: fractJs(Math.sin(landing * 43.12 + toPreset * 9.71) * 9173.13),
      startTime,
      landingTime: landing,
      endTime,
      duration: Math.max(0.001, endTime - startTime),
      suppressShaderTransition: useVideoTransitionTiming,
      swapAt
    });
    addWaveformTransitionMarker?.({
      source: "export",
      eventType: type,
      nextPreset: toPreset,
      style,
      startTime,
      landingTime: landing,
      endTime,
      status: "export"
    });
    lastLanding = landing;
    fromPreset = toPreset;
    fromEnergy = toEnergy;
    presetDiversity.record(toPreset, adaptiveEligiblePresetIds?.() || []);
  }
  return timeline;
}

export function offlineTransitionStateAt(time, timeline, startPreset, startPresetTime = 0) {
  let preset = startPreset;
  let presetStart = startPresetTime;
  let currentTransition = null;
  for (const item of timeline) {
    if (time < item.startTime) break;
    if (time <= item.endTime) {
      const phase = clamp01((time - item.startTime) / Math.max(0.001, item.duration));
      const swapped = phase >= item.swapAt;
      currentTransition = { ...item, phase, swapped,
        fromPresetStart: item.fromPresetStart ?? presetStart, toPresetStart: presetAnimationStart(item) };
      preset = swapped ? item.to : item.from;
      presetStart = swapped ? presetAnimationStart(item) : currentTransition.fromPresetStart;
      break;
    }
    preset = item.to;
    presetStart = presetAnimationStart(item);
  }
  return { preset, presetStart, transition: currentTransition };
}

// Range-export helpers intentionally live beside the offline timeline builder so
// the runtime can choose between two distinct, deterministic clocks:
//
// - A full-video match keeps the authored/generated timeline in source time and
//   maps output frame zero to the requested source time.
// - A standalone clip receives a source-offset view of analysis data, but all
//   visual/timeline time starts at zero.
//
// Keeping these helpers pure makes it possible to test range behaviour without
// WebGL, a media element, or the native encoder.
const RANGE_EPSILON = 0.000001;

function finiteNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function inferredSourceDuration({ sourceDuration, fullDuration, analysisTimeline } = {}) {
  const candidates = [sourceDuration, fullDuration, analysisTimeline?.duration];
  for (const candidate of candidates) {
    const value = Number(candidate);
    if (Number.isFinite(value) && value > 0) return value;
  }
  return 0;
}

function clampToRange(value, start, end) {
  return Math.max(start, Math.min(end, value));
}

function planParts(result, fallbackStartPreset = undefined) {
  if (Array.isArray(result)) {
    return { timeline: result, startPreset: fallbackStartPreset };
  }
  if (result && typeof result === "object") {
    return {
      timeline: Array.isArray(result.timeline) ? result.timeline : [],
      startPreset: result.startPreset ?? fallbackStartPreset
    };
  }
  return { timeline: [], startPreset: fallbackStartPreset };
}

function transitionIntersectsRange(transition, start, end) {
  const transitionStart = Number(transition?.startTime);
  const transitionEnd = Number(transition?.endTime);
  if (!Number.isFinite(transitionStart) || !Number.isFinite(transitionEnd)) return false;
  // An item ending exactly at the in boundary still determines the visual at
  // output frame zero (offlineTransitionStateAt treats endTime as inclusive).
  return transitionEnd >= start - RANGE_EPSILON && transitionStart < end - RANGE_EPSILON;
}

function shiftedTransition(transition, sourceStart) {
  const shift = (value) => Number.isFinite(Number(value)) ? Number(value) - sourceStart : value;
  return {
    ...transition,
    startTime: shift(transition.startTime),
    landingTime: shift(transition.landingTime),
    endTime: shift(transition.endTime),
    sourceStartTime: transition.startTime,
    sourceLandingTime: transition.landingTime,
    sourceEndTime: transition.endTime
  };
}

function transitionCutCandidates(transition) {
  const landingTime = Number(transition?.landingTime);
  if (Number.isFinite(landingTime)) {
    return [{ time: landingTime, kind: "landing", transition }];
  }
  const candidates = [];
  const startTime = Number(transition?.startTime);
  const endTime = Number(transition?.endTime);
  if (Number.isFinite(startTime)) candidates.push({ time: startTime, kind: "transition-start", transition });
  if (Number.isFinite(endTime)) candidates.push({ time: endTime, kind: "transition-end", transition });
  return candidates;
}

/**
 * Normalise a selected source interval. The returned start/end are always
 * absolute source-track seconds; duration is the output clip length.
 */
export function normalizeOfflineSourceRange({
  sourceStart,
  sourceEnd,
  start,
  end,
  sourceDuration,
  fullDuration,
  analysisTimeline
} = {}) {
  const total = inferredSourceDuration({ sourceDuration, fullDuration, analysisTimeline });
  const requestedStart = finiteNumber(sourceStart ?? start, 0);
  const requestedEnd = sourceEnd ?? end ?? total;
  const boundedStart = total > 0
    ? clampToRange(requestedStart, 0, total)
    : Math.max(0, requestedStart);
  const boundedEnd = total > 0
    ? clampToRange(finiteNumber(requestedEnd, total), 0, total)
    : Math.max(0, finiteNumber(requestedEnd, boundedStart));
  if (!(boundedEnd > boundedStart + RANGE_EPSILON)) {
    throw new RangeError("The export range must end after it starts.");
  }
  return {
    sourceStart: boundedStart,
    sourceEnd: boundedEnd,
    sourceDuration: total,
    duration: boundedEnd - boundedStart
  };
}

/**
 * Presents a selected source interval as a local analysis timeline. It is
 * deliberately a lightweight adapter rather than a copied PCM/analysis pass:
 * Auto generation and offline audio state can query local time while receiving
 * the existing track's analysis at sourceStart + localTime.
 */
export function createOffsetAnalysisTimeline(analysisTimeline, {
  sourceStart = 0,
  sourceEnd,
  sourceDuration,
  clampToSelection = true
} = {}) {
  const range = normalizeOfflineSourceRange({
    sourceStart,
    sourceEnd,
    sourceDuration,
    analysisTimeline
  });
  const localDuration = range.duration;
  const toSourceTime = (localTime) => {
    const requested = range.sourceStart + Math.max(0, finiteNumber(localTime, 0));
    return clampToSelection ? clampToRange(requested, range.sourceStart, range.sourceEnd) : requested;
  };
  const toLocalTime = (sourceTime) => finiteNumber(sourceTime, range.sourceStart) - range.sourceStart;
  const sourceSections = Array.isArray(analysisTimeline?.sections) ? analysisTimeline.sections : [];
  const sections = sourceSections.flatMap((section) => {
    const sectionStart = finiteNumber(section?.start, 0);
    const sectionEnd = finiteNumber(section?.end, sectionStart);
    if (sectionEnd <= range.sourceStart || sectionStart >= range.sourceEnd) return [];
    return [{
      ...section,
      start: Math.max(range.sourceStart, sectionStart) - range.sourceStart,
      end: Math.min(range.sourceEnd, sectionEnd) - range.sourceStart,
      sourceStart: sectionStart,
      sourceEnd: sectionEnd
    }];
  });

  function getSectionAt(localTime) {
    const sourceTime = toSourceTime(localTime);
    const sourceSection = analysisTimeline?.getSectionAt?.(sourceTime);
    if (sourceSection) {
      const sectionStart = finiteNumber(sourceSection.start, range.sourceStart);
      const sectionEnd = finiteNumber(sourceSection.end, range.sourceEnd);
      return {
        ...sourceSection,
        start: Math.max(range.sourceStart, sectionStart) - range.sourceStart,
        end: Math.min(range.sourceEnd, sectionEnd) - range.sourceStart,
        sourceStart: sectionStart,
        sourceEnd: sectionEnd
      };
    }
    return sections.find((section) => localTime >= section.start && localTime < section.end) || sections.at(-1) || null;
  }

  function getLookaheadFeatures(localTime, seconds) {
    if (!analysisTimeline?.getLookaheadFeatures) return null;
    const sourceTime = toSourceTime(localTime);
    const requestedSeconds = Math.max(0, finiteNumber(seconds, 0));
    const availableSeconds = clampToSelection ? Math.max(0, range.sourceEnd - sourceTime) : requestedSeconds;
    return analysisTimeline.getLookaheadFeatures(sourceTime, Math.min(requestedSeconds, availableSeconds));
  }

  function getLoopBoundariesBetween(localStart, localEnd, loopBeats = [8, 16, 32]) {
    if (!analysisTimeline?.getLoopBoundariesBetween) return [];
    const start = Math.max(0, finiteNumber(localStart, 0));
    const end = Math.min(localDuration, Math.max(start, finiteNumber(localEnd, localDuration)));
    if (!(end > start)) return [];
    return analysisTimeline
      .getLoopBoundariesBetween(toSourceTime(start), toSourceTime(end), loopBeats)
      .map((boundary) => ({ ...boundary, time: toLocalTime(boundary.time), sourceTime: boundary.time }))
      .filter((boundary) => boundary.time >= start - RANGE_EPSILON && boundary.time <= end + RANGE_EPSILON);
  }

  function getBeatInfo(localTime) {
    const sourceTime = toSourceTime(localTime);
    const info = analysisTimeline?.getBeatInfo?.(sourceTime);
    if (!info) return info || null;
    const sourceNextLoop = Number(info.nextLoopTime);
    const nextLoopTime = Number.isFinite(sourceNextLoop) ? toLocalTime(sourceNextLoop) : null;
    const hasNextLoop = Number.isFinite(nextLoopTime)
      && nextLoopTime >= 0
      && (!clampToSelection || nextLoopTime <= localDuration + RANGE_EPSILON);
    return {
      ...info,
      nextLoopTime: hasNextLoop ? nextLoopTime : null,
      nextLoopSeconds: hasNextLoop ? Math.max(0, nextLoopTime - Math.max(0, finiteNumber(localTime, 0))) : 0
    };
  }

  // the drop map in local time (the info's intervals are relative, so only the drops move)
  const toLocalDrop = (drop) => (drop ? { ...drop, time: toLocalTime(drop.time), leadIn: toLocalTime(drop.leadIn) } : null);
  function getDropInfo(localTime) {
    const info = analysisTimeline?.getDropInfo?.(toSourceTime(localTime));
    return info ? { ...info, next: toLocalDrop(info.next), last: toLocalDrop(info.last) } : null;
  }

  return {
    duration: localDuration,
    frameDuration: analysisTimeline?.frameDuration,
    tempo: analysisTimeline?.tempo || null,
    sections,
    drops: (analysisTimeline?.drops || []).map(toLocalDrop),
    getDropInfo,
    sourceStart: range.sourceStart,
    sourceEnd: range.sourceEnd,
    sourceDuration: range.sourceDuration,
    sourceTimeAt: toSourceTime,
    localTimeAt: toLocalTime,
    getFeatures: (localTime) => analysisTimeline?.getFeatures?.(toSourceTime(localTime)) || null,
    getKickScoreAt: (localTime) => analysisTimeline?.getKickScoreAt?.(toSourceTime(localTime)) ?? null,
    getLookaheadFeatures,
    getSectionAt,
    getLoopBoundariesBetween,
    getBeatInfo
  };
}

/**
 * Build an Auto plan for a full track, then expose only a selected source
 * interval. The timeline remains in absolute source time so a clip beginning
 * mid-transition exactly matches the corresponding full-video frame.
 */
export function buildFullTrackAutoClipPlan({
  analysisTimeline,
  sourceStart = 0,
  sourceEnd,
  sourceDuration,
  fullDuration,
  buildPlan = buildOfflinePresetTimeline,
  planOptions = {}
} = {}) {
  const duration = inferredSourceDuration({ sourceDuration, fullDuration, analysisTimeline });
  const range = normalizeOfflineSourceRange({ sourceStart, sourceEnd, sourceDuration: duration });
  const result = buildPlan({
    ...planOptions,
    analysisTimeline,
    duration
  });
  const parts = planParts(result, planOptions.startPreset ?? planOptions.activePreset);
  const initialState = offlineTransitionStateAt(range.sourceStart, parts.timeline, parts.startPreset);
  const sourceTimeAt = (outputTime) => clampToRange(
    range.sourceStart + Math.max(0, finiteNumber(outputTime, 0)),
    range.sourceStart,
    range.sourceEnd
  );
  return {
    clipBehaviour: "match-full-video",
    ...range,
    outputDuration: range.duration,
    // This is intentionally full-track duration: renderer transition lookup
    // and audio-state analysis both receive absolute source timestamps.
    renderDuration: duration,
    analysisTimeline,
    timeline: parts.timeline,
    startPreset: parts.startPreset,
    initialState,
    sourceTimeAt,
    renderTimeAt: sourceTimeAt,
    timelineTimeAtOutputTime: sourceTimeAt,
    outputTimeAt: (sourceTime) => clampToRange(
      finiteNumber(sourceTime, range.sourceStart) - range.sourceStart,
      0,
      range.duration
    )
  };
}

/**
 * Drops generated transitions that would finish against the last moments of a
 * standalone clip. This leaves its end in a settled preset instead of adding
 * an abbreviated visual transition just before output stops.
 */
export function trimStandaloneTimelineEnd(timeline, duration, { tailSeconds = 1.5 } = {}) {
  const safeDuration = Math.max(0, finiteNumber(duration, 0));
  const tail = Math.max(0, Math.min(safeDuration, finiteNumber(tailSeconds, 1.5)));
  const deadline = safeDuration - tail;
  const result = [];
  for (const transition of Array.isArray(timeline) ? timeline : []) {
    const endTime = Number(transition?.endTime);
    if (Number.isFinite(endTime) && endTime > deadline + RANGE_EPSILON) break;
    result.push(transition);
  }
  return result;
}

/**
 * Build a fresh Auto plan for a selected source interval. Its analysis is
 * offset to sourceStart, but all exported visual clocks begin at local zero.
 */
export function buildStandaloneAutoClipPlan({
  analysisTimeline,
  sourceStart = 0,
  sourceEnd,
  sourceDuration,
  buildPlan = buildOfflinePresetTimeline,
  planOptions = {},
  trailingTransitionTailSeconds = 1.5
} = {}) {
  const range = normalizeOfflineSourceRange({ sourceStart, sourceEnd, sourceDuration, analysisTimeline });
  const localAnalysisTimeline = createOffsetAnalysisTimeline(analysisTimeline, range);
  const result = buildPlan({
    ...planOptions,
    analysisTimeline: localAnalysisTimeline,
    duration: range.duration
  });
  const parts = planParts(result, planOptions.startPreset ?? planOptions.activePreset);
  const timeline = trimStandaloneTimelineEnd(parts.timeline, range.duration, {
    tailSeconds: trailingTransitionTailSeconds
  });
  const localTimeAt = (outputTime) => clampToRange(
    Math.max(0, finiteNumber(outputTime, 0)),
    0,
    range.duration
  );
  return {
    clipBehaviour: "standalone",
    ...range,
    outputDuration: range.duration,
    renderDuration: range.duration,
    analysisTimeline: localAnalysisTimeline,
    timeline,
    startPreset: parts.startPreset,
    initialState: offlineTransitionStateAt(0, timeline, parts.startPreset),
    sourceTimeAt: (outputTime) => range.sourceStart + localTimeAt(outputTime),
    renderTimeAt: localTimeAt,
    timelineTimeAtOutputTime: localTimeAt,
    outputTimeAt: (sourceTime) => clampToRange(
      finiteNumber(sourceTime, range.sourceStart) - range.sourceStart,
      0,
      range.duration
    )
  };
}

/**
 * Find the nearest authored cut. landingTime is the real preset swap/cut for
 * normal and video transitions; start/end are a safe fallback for older plans.
 */
export function nearestTimelineCut(time, timeline = []) {
  const target = finiteNumber(time, 0);
  let nearest = null;
  for (const transition of Array.isArray(timeline) ? timeline : []) {
    for (const candidate of transitionCutCandidates(transition)) {
      const distance = Math.abs(candidate.time - target);
      if (!nearest || distance < nearest.distance - RANGE_EPSILON
          || (Math.abs(distance - nearest.distance) <= RANGE_EPSILON && candidate.time < nearest.time)) {
        nearest = { ...candidate, distance };
      }
    }
  }
  return nearest;
}

/**
 * Describe non-blocking warnings for selected timeline boundaries that fall
 * inside authored transitions. Exact transition starts/ends are not warnings.
 */
export function timelineRangeBoundaryWarnings({
  timeline = [],
  sourceStart = 0,
  sourceEnd,
  sourceDuration,
  startPreset
} = {}) {
  const range = normalizeOfflineSourceRange({ sourceStart, sourceEnd, sourceDuration });
  const items = Array.isArray(timeline) ? timeline : [];
  const warningAt = (boundary, time) => {
    const transition = items.find((item) => {
      const start = Number(item?.startTime);
      const end = Number(item?.endTime);
      const landing = Number(item?.landingTime);
      // `landingTime` is the authored cut/swap. A boundary placed exactly on
      // that cut is deliberate and does not need the transition warning.
      if (Number.isFinite(landing) && Math.abs(time - landing) <= RANGE_EPSILON) return false;
      return Number.isFinite(start) && Number.isFinite(end)
        && time > start + RANGE_EPSILON
        && time < end - RANGE_EPSILON;
    });
    if (!transition) return null;
    const cut = nearestTimelineCut(time, [transition]);
    return {
      boundary,
      time,
      transition,
      state: offlineTransitionStateAt(time, items, startPreset),
      nearestCut: cut?.time ?? null,
      nearestCutKind: cut?.kind ?? null,
      moveBySeconds: cut ? cut.time - time : 0,
      action: "move-to-nearest-transition-cut"
    };
  };
  const start = warningAt("start", range.sourceStart);
  const end = warningAt("end", range.sourceEnd);
  return {
    ...range,
    start,
    end,
    warnings: [start, end].filter(Boolean)
  };
}

/**
 * Shift the relevant authored timeline interval onto output time. Any
 * transition already in progress receives a negative local start time so frame
 * zero retains its original phase. The caller can render this with an offset
 * analysis timeline and a local offline clock.
 */
export function clipAuthoredTimelineToRange({
  timeline = [],
  startPreset,
  sourceStart = 0,
  sourceEnd,
  sourceDuration
} = {}) {
  const range = normalizeOfflineSourceRange({ sourceStart, sourceEnd, sourceDuration });
  const sourceTimeline = Array.isArray(timeline) ? timeline : [];
  const initialState = offlineTransitionStateAt(range.sourceStart, sourceTimeline, startPreset);
  const clippedTimeline = sourceTimeline
    .filter((transition) => transitionIntersectsRange(transition, range.sourceStart, range.sourceEnd))
    .map((transition) => ({ ...shiftedTransition(transition, range.sourceStart),
      fromPresetStart: offlineTransitionStateAt(transition.startTime - RANGE_EPSILON, sourceTimeline, startPreset).presetStart - range.sourceStart
    }));
  return {
    ...range,
    outputDuration: range.duration,
    renderDuration: range.duration,
    sourceTimeline,
    timeline: clippedTimeline,
    startPreset: initialState.preset ?? startPreset,
    presetStart: initialState.presetStart - range.sourceStart,
    initialState,
    boundaryWarnings: timelineRangeBoundaryWarnings({
      timeline: sourceTimeline,
      startPreset,
      sourceStart: range.sourceStart,
      sourceEnd: range.sourceEnd,
      sourceDuration: range.sourceDuration
    })
  };
}

/**
 * Convenience plan for timeline-mode range export: authored transition times
 * are local to output while analysis still resolves the selected source audio.
 */
export function buildAuthoredTimelineClipPlan({
  analysisTimeline,
  timeline = [],
  startPreset,
  sourceStart = 0,
  sourceEnd,
  sourceDuration
} = {}) {
  const clipped = clipAuthoredTimelineToRange({
    timeline,
    startPreset,
    sourceStart,
    sourceEnd,
    sourceDuration: inferredSourceDuration({ sourceDuration, analysisTimeline })
  });
  const localAnalysisTimeline = createOffsetAnalysisTimeline(analysisTimeline, clipped);
  const localTimeAt = (outputTime) => clampToRange(
    Math.max(0, finiteNumber(outputTime, 0)),
    0,
    clipped.duration
  );
  return {
    clipBehaviour: "authored-timeline",
    ...clipped,
    analysisTimeline: localAnalysisTimeline,
    renderTimeAt: localTimeAt,
    timelineTimeAtOutputTime: localTimeAt,
    sourceTimeAt: (outputTime) => clipped.sourceStart + localTimeAt(outputTime),
    outputTimeAt: (sourceTime) => clampToRange(
      finiteNumber(sourceTime, clipped.sourceStart) - clipped.sourceStart,
      0,
      clipped.duration
    )
  };
}
