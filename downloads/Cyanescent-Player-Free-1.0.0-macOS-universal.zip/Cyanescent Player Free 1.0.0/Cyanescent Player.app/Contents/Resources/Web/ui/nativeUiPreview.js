function visible(element) {
  if (!element) return false;
  const style = window.getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return style.display !== "none"
    && style.visibility !== "hidden"
    && Number(style.opacity) !== 0
    && rect.width > 0
    && rect.height > 0;
}

function labelFor(element) {
  return element?.getAttribute("aria-label")
    || element?.getAttribute("title")
    || element?.textContent?.replace(/\s+/g, " ").trim()
    || element?.id
    || "";
}

function boundsFor(element) {
  const rect = element.getBoundingClientRect();
  return {
    x: Number(rect.x.toFixed(2)),
    y: Number(rect.y.toFixed(2)),
    width: Number(rect.width.toFixed(2)),
    height: Number(rect.height.toFixed(2))
  };
}

function viewport() {
  return { width: window.innerWidth, height: window.innerHeight };
}

function finding(severity, code, element, message = "") {
  return {
    severity,
    code,
    element: element?.id ? `#${element.id}` : element?.tagName?.toLowerCase() || "document",
    label: labelFor(element),
    bounds: element ? boundsFor(element) : { x: 0, y: 0, width: 0, height: 0 },
    viewport: viewport(),
    ...(message ? { message } : {})
  };
}

function intersects(a, b) {
  const left = Math.max(a.left, b.left);
  const top = Math.max(a.top, b.top);
  const right = Math.min(a.right, b.right);
  const bottom = Math.min(a.bottom, b.bottom);
  return right - left > 2 && bottom - top > 2;
}

function isContained(a, b) {
  return a.contains(b) || b.contains(a);
}

function isRelevantImportantControl(element, previewId) {
  const insideExport = Boolean(element.closest("#exportOverlay, #exportWindow"));
  return previewId.startsWith("export-") ? insideExport : !insideExport;
}

export function collectNativeUiLayoutDiagnostics(previewId) {
  const result = [];
  const view = viewport();
  const important = [...document.querySelectorAll('[data-diagnostic-important="true"]')]
    .filter((element) => isRelevantImportantControl(element, previewId));
  const visibleImportant = [];

  for (const element of important) {
    const rect = element.getBoundingClientRect();
    if (!visible(element)) {
      result.push(finding("error", "IMPORTANT_CONTROL_HIDDEN", element, "Important control is hidden or has no visible area."));
      continue;
    }
    visibleImportant.push(element);
    if (rect.left < -1 || rect.top < -1 || rect.right > view.width + 1 || rect.bottom > view.height + 1) {
      result.push(finding("error", "CONTROL_OUTSIDE_VIEWPORT", element, "Important control extends beyond the WKWebView viewport."));
    }
    if (element instanceof HTMLElement && (element.scrollWidth > element.clientWidth + 2 || element.scrollHeight > element.clientHeight + 2)) {
      result.push(finding("warning", "CONTROL_TEXT_CLIPPED", element, "The control's rendered content is larger than its content box."));
    }
  }

  for (let left = 0; left < visibleImportant.length; left += 1) {
    const first = visibleImportant[left];
    const firstRect = first.getBoundingClientRect();
    for (let right = left + 1; right < visibleImportant.length; right += 1) {
      const second = visibleImportant[right];
      if (isContained(first, second) || intersects(firstRect, second.getBoundingClientRect())) {
        if (isContained(first, second)) continue;
        result.push(finding(
          "error",
          "IMPORTANT_CONTROLS_OVERLAP",
          first,
          `Overlaps ${second.id ? `#${second.id}` : labelFor(second)}.`
        ));
      }
    }
  }

  if (document.documentElement.scrollWidth > window.innerWidth + 2 || document.body.scrollWidth > window.innerWidth + 2) {
    result.push(finding("error", "DOCUMENT_HORIZONTAL_OVERFLOW", document.documentElement, "The document is wider than the viewport."));
  }

  const requiredRoots = previewId.startsWith("export-")
    ? ["exportOverlay", "exportWindow"]
    : ["panel", "libraryPanel", "visualPanel"];
  for (const id of requiredRoots) {
    const root = document.getElementById(id);
    if (!root) {
      result.push(finding("fatal", "REQUIRED_PREVIEW_ROOT_MISSING", null, `Required preview root #${id} is missing.`));
    } else if (!visible(root)) {
      result.push(finding("fatal", "REQUIRED_PREVIEW_ROOT_HIDDEN", root, `Required preview root #${id} is hidden.`));
    }
  }

  const allowedDialogs = previewId.startsWith("export-") ? new Set(["exportWindow"]) : new Set();
  for (const dialog of document.querySelectorAll('[role="dialog"]')) {
    if (!visible(dialog) || allowedDialogs.has(dialog.id)) continue;
    result.push(finding("warning", "UNEXPECTED_MODAL_OVERLAY", dialog, "An unrelated modal or overlay is visible."));
  }

  return result;
}

export function collectNativeUiRuntimeInfo(previewId, fixtureId) {
  return {
    previewId,
    fixtureId,
    documentReadyState: document.readyState,
    viewport: viewport(),
    devicePixelRatio: window.devicePixelRatio || 1,
    documentScrollSize: {
      width: document.documentElement.scrollWidth,
      height: document.documentElement.scrollHeight
    },
    visibleDialogs: [...document.querySelectorAll('[role="dialog"]')]
      .filter(visible)
      .map((element) => element.id || labelFor(element)),
    bodyClasses: document.body.className
  };
}

function nextPaint() {
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      resolve();
    };
    requestAnimationFrame(() => requestAnimationFrame(finish));
    window.setTimeout(finish, 100);
  });
}

export function installNativeUiPreviewBridge({
  previewId,
  fixtureId,
  applyFixture,
  nativeApp = () => null
} = {}) {
  if (!previewId) return null;

  let applied = false;

  function reportStage(stage, details = {}) {
    console.info(`[NativeUiPreview] ${stage}`, details);
    nativeApp()?.postMessage({ command: "uiPreviewStage", stage, details });
  }

  function reportReady(extra = {}) {
    const details = {
      ...collectNativeUiRuntimeInfo(previewId, fixtureId),
      findings: collectNativeUiLayoutDiagnostics(previewId),
      ...extra
    };
    reportStage("readiness-sending");
    nativeApp()?.postMessage({ command: "uiPreviewReady", ...details });
    return details;
  }

  async function setPreviewState(nextPreviewId = previewId, nextFixtureId = fixtureId) {
    if (applied) return;
    applied = true;
    try {
      reportStage("fixture-apply-started", { previewId: nextPreviewId, fixtureId: nextFixtureId });
      await applyFixture?.({ previewId: nextPreviewId, fixtureId: nextFixtureId });
      reportStage("fixture-applied", { previewId: nextPreviewId, fixtureId: nextFixtureId });
      await nextPaint();
      await new Promise((resolve) => window.setTimeout(resolve, 120));
      return reportReady();
    } catch (error) {
      return reportReady({
        runtimeError: String(error?.stack || error),
        findings: [{
          severity: "fatal",
          code: "PREVIEW_FIXTURE_FAILED",
          element: "document",
          label: "Native UI preview",
          bounds: { x: 0, y: 0, width: 0, height: 0 },
          viewport: viewport(),
          message: String(error?.message || error)
        }]
      });
    }
  }

  const bridge = {
    setPreviewState,
    reportReady,
    reportStage,
    collectLayoutDiagnostics: () => collectNativeUiLayoutDiagnostics(previewId),
    collectRuntimeInfo: () => collectNativeUiRuntimeInfo(previewId, fixtureId),
    collect: () => ({
      ...collectNativeUiRuntimeInfo(previewId, fixtureId),
      findings: collectNativeUiLayoutDiagnostics(previewId)
    })
  };
  window.CyanescentDiagnostics = bridge;
  reportStage("diagnostic-js-loaded", { previewId, fixtureId });
  window.addEventListener("cyanescent-ui-ready", () => {
    reportStage("ui-ready-event-received");
    setPreviewState().catch((error) => reportReady({ runtimeError: String(error) }));
  }, { once: true });
  window.addEventListener("cyanescent-app-ready", () => {
    reportStage("app-ready-event-received");
    setPreviewState().catch((error) => reportReady({ runtimeError: String(error) }));
  }, { once: true });
  return bridge;
}
