const RANGE_EPSILON = 0.001;

function finiteSeconds(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, number) : fallback;
}

function rounded(seconds) {
  return Math.round(Math.max(0, seconds) * 1000) / 1000;
}

export function formatExportRangeTime(seconds) {
  const safe = rounded(finiteSeconds(seconds));
  const minutes = Math.floor(safe / 60);
  const remaining = safe - minutes * 60;
  const wholeSeconds = Math.floor(remaining).toString().padStart(2, "0");
  const milliseconds = Math.round((remaining - Math.floor(remaining)) * 1000)
    .toString()
    .padStart(3, "0");
  return `${minutes.toString().padStart(2, "0")}:${wholeSeconds}.${milliseconds}`;
}

export function parseExportRangeTime(value) {
  if (typeof value === "number") return finiteSeconds(value, Number.NaN);
  const text = String(value || "").trim();
  if (!text) return Number.NaN;
  if (/^\d+(?:\.\d+)?$/.test(text)) return finiteSeconds(Number(text), Number.NaN);
  const match = text.match(/^(\d+):(\d{1,2})(?:\.(\d{1,3}))?$/);
  if (!match) return Number.NaN;
  const minutes = Number(match[1]);
  const seconds = Number(match[2]);
  const milliseconds = Number((match[3] || "").padEnd(3, "0"));
  if (!Number.isFinite(minutes) || !Number.isFinite(seconds) || !Number.isFinite(milliseconds) || seconds >= 60) {
    return Number.NaN;
  }
  return minutes * 60 + seconds + milliseconds / 1000;
}

export function validateExportRange(range = {}) {
  const trackDuration = finiteSeconds(range.trackDuration, 0);
  const start = finiteSeconds(range.start, Number.NaN);
  const end = finiteSeconds(range.end, Number.NaN);
  if (!trackDuration) return { valid: false, error: "Load a track before selecting an export range." };
  if (!Number.isFinite(start) || !Number.isFinite(end)) return { valid: false, error: "Export range times must be valid." };
  if (start < 0 || end > trackDuration + RANGE_EPSILON) return { valid: false, error: "The export range must stay inside the loaded track." };
  if (end - start < RANGE_EPSILON) return { valid: false, error: "The export end must be later than the start." };
  return {
    valid: true,
    start: rounded(Math.max(0, start)),
    end: rounded(Math.min(trackDuration, end)),
    duration: rounded(Math.min(trackDuration, end) - Math.max(0, start))
  };
}

// The model is intentionally independent of a particular view. The player,
// timeline, Export Studio and offline renderer all observe the same instance.
export function createExportRangeModel({ duration = 0, onChange = null } = {}) {
  let trackDuration = finiteSeconds(duration, 0);
  let start = 0;
  let end = trackDuration;
  let mode = "full";
  const listeners = new Set();
  if (typeof onChange === "function") listeners.add(onChange);

  function snapshot() {
    const checked = validateExportRange({ trackDuration, start, end });
    return Object.freeze({
      mode,
      trackDuration: rounded(trackDuration),
      start: rounded(start),
      end: rounded(end),
      duration: checked.valid ? checked.duration : 0,
      valid: checked.valid,
      error: checked.error || ""
    });
  }

  function publish(reason = "change") {
    const next = snapshot();
    for (const listener of listeners) listener(next, reason);
    return next;
  }

  function fullTrack(reason = "full-track") {
    mode = "full";
    start = 0;
    end = trackDuration;
    return publish(reason);
  }

  function setTrackDuration(nextDuration, { preserveSelection = false } = {}) {
    trackDuration = finiteSeconds(nextDuration, 0);
    if (!trackDuration) {
      mode = "full";
      start = 0;
      end = 0;
      return publish("track-cleared");
    }
    if (!preserveSelection || mode === "full") return fullTrack("track-loaded");
    start = Math.min(Math.max(0, start), Math.max(0, trackDuration - RANGE_EPSILON));
    end = Math.min(trackDuration, Math.max(start + RANGE_EPSILON, end));
    if (end - start < RANGE_EPSILON) return fullTrack("range-reset-for-track");
    return publish("track-duration-changed");
  }

  function setRange(nextStart, nextEnd, { nextMode = "selected", reason = "range" } = {}) {
    if (!trackDuration) return { ok: false, error: "Load a track before selecting an export range.", range: snapshot() };
    const candidate = validateExportRange({
      trackDuration,
      start: finiteSeconds(nextStart, Number.NaN),
      end: finiteSeconds(nextEnd, Number.NaN)
    });
    if (!candidate.valid) return { ok: false, error: candidate.error, range: snapshot() };
    start = candidate.start;
    end = candidate.end;
    mode = nextMode === "full" && start <= RANGE_EPSILON && Math.abs(end - trackDuration) <= RANGE_EPSILON
      ? "full"
      : "selected";
    return { ok: true, range: publish(reason) };
  }

  function setStart(nextStart) {
    const value = finiteSeconds(nextStart, Number.NaN);
    if (!Number.isFinite(value)) return { ok: false, error: "Enter a valid start time.", range: snapshot() };
    const bounded = Math.max(0, Math.min(value, Math.max(0, end - RANGE_EPSILON)));
    return setRange(bounded, end, { reason: "start" });
  }

  function setEnd(nextEnd) {
    const value = finiteSeconds(nextEnd, Number.NaN);
    if (!Number.isFinite(value)) return { ok: false, error: "Enter a valid end time.", range: snapshot() };
    const bounded = Math.min(trackDuration, Math.max(value, start + RANGE_EPSILON));
    return setRange(start, bounded, { reason: "end" });
  }

  function setDuration(nextDuration, { preserveStart = true } = {}) {
    const requested = finiteSeconds(nextDuration, Number.NaN);
    if (!Number.isFinite(requested) || requested < RANGE_EPSILON) {
      return { ok: false, error: "Choose a duration longer than zero.", range: snapshot() };
    }
    if (!trackDuration) return { ok: false, error: "Load a track before selecting an export range.", range: snapshot() };
    if (preserveStart) {
      // Keep the current source start by default. At the end of a shorter
      // track the range simply finishes at the track end.
      return setRange(start, Math.min(trackDuration, start + requested), { reason: "duration" });
    }
    const nextEnd = Math.min(trackDuration, end);
    return setRange(Math.max(0, nextEnd - requested), nextEnd, { reason: "duration" });
  }

  function setMode(nextMode) {
    if (nextMode === "full") return fullTrack("mode-full");
    mode = "selected";
    if (end - start < RANGE_EPSILON) {
      start = 0;
      end = trackDuration;
    }
    return publish("mode-selected");
  }

  function sourceTimeForOutput(outputTime) {
    return Math.min(end, Math.max(start, start + finiteSeconds(outputTime, 0)));
  }

  function outputTimeForSource(sourceTime) {
    return Math.min(end - start, Math.max(0, finiteSeconds(sourceTime, start) - start));
  }

  function subscribe(listener, { immediate = true } = {}) {
    if (typeof listener !== "function") return () => {};
    listeners.add(listener);
    if (immediate) listener(snapshot(), "subscribe");
    return () => listeners.delete(listener);
  }

  return {
    get: snapshot,
    subscribe,
    setTrackDuration,
    setRange,
    setStart,
    setEnd,
    setDuration,
    setMode,
    fullTrack,
    clear: () => fullTrack("clear"),
    sourceTimeForOutput,
    outputTimeForSource
  };
}
