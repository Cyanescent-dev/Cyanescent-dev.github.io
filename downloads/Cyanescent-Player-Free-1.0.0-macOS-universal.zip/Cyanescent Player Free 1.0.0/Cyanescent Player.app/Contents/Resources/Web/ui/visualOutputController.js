const OUTPUT_MESSAGE = "cyanescent-visual-output";

export function isVisualOutputDocument(windowRef = window) {
  return new URLSearchParams(windowRef.location.search).get("visualOutput") === "1";
}

export function createVisualOutputController({
  windowRef = window,
  nativeApp,
  outputRole = isVisualOutputDocument(windowRef),
  createStateSnapshot,
  applyStateSnapshot,
  onStateChanged,
  onOutputReady,
  onWarmupProgress,
  onTransitionState,
  onSignalReceived,
  onStartRequested,
  onBenchmarkStart
} = {}) {
  let outputWindow = null;
  let autoOpenSuppressed = false;
  // Held while the Export Studio is open: it previews inside the main window.
  let heldHidden = false;
  let reopenAfterHold = false;
  let fullscreen = false;
  let ready = false;
  let browserStateTimer = 0;
  let pendingState = null;
  let nativeOutputReady = false;

  function nativeHandler() {
    return nativeApp?.() || null;
  }

  function sendToMain(payload) {
    const handler = nativeHandler();
    if (handler) {
      handler.postMessage({ command: "visualOutputSignal", target: "main", payload });
      return;
    }
    try {
      windowRef.opener?.postMessage({ type: OUTPUT_MESSAGE, ...payload }, windowRef.location.origin);
    } catch (error) {
      console.warn("Could not signal the Cyanescent controller window:", error);
    }
  }

  function sendToOutput(payload) {
    const handler = nativeHandler();
    if (handler) {
      handler.postMessage({ command: "visualOutputSignal", target: "output", payload });
      return;
    }
    try {
      outputWindow?.postMessage({ type: OUTPUT_MESSAGE, ...payload }, windowRef.location.origin);
    } catch (error) {
      console.warn("Could not update the Cyanescent visual output:", error);
    }
  }

  function isOpen() {
    if (outputRole) return true;
    try {
      return Boolean(outputWindow && !outputWindow.closed);
    } catch {
      // Native WKWebView popups do not always expose a useful `closed` value.
      return Boolean(outputWindow);
    }
  }

  function publishState() {
    if (!outputRole) onStateChanged?.({ open: isOpen(), fullscreen });
  }

  function stopBrowserStatePump() {
    windowRef.clearInterval(browserStateTimer);
    browserStateTimer = 0;
  }

  function startBrowserStatePump() {
    if (outputRole || nativeHandler() || browserStateTimer) return;
    browserStateTimer = windowRef.setInterval(() => {
      if (!isOpen()) {
        stopBrowserStatePump();
        return;
      }
      const snapshot = createStateSnapshot?.();
      if (snapshot) sendToOutput({ action: "visual-state", state: snapshot });
    }, 1000 / 30);
  }

  function markClosed({ suppressAutomaticOpening = true } = {}) {
    stopBrowserStatePump();
    outputWindow = null;
    browserStateTimer = 0;
    pendingState = null;
    nativeOutputReady = false;
    document.body.classList.remove("visual-output-connected");
    if (suppressAutomaticOpening) autoOpenSuppressed = true;
    publishState();
  }

  function ensureOpen({ explicit = false, prewarm = false } = {}) {
    if (outputRole) return true;
    if (autoOpenSuppressed && !explicit && !prewarm) return false;
    if (heldHidden && !prewarm) return false;
    if (nativeHandler() && nativeOutputReady && !prewarm) {
      nativeHandler().postMessage({ command: "showVisualOutput" });
      return true;
    }
    if (isOpen()) {
      if (!prewarm) nativeHandler()?.postMessage({ command: "showVisualOutput" });
      return true;
    }
    if (explicit) autoOpenSuppressed = false;
    const outputUrl = new URL("index.html", windowRef.location.href);
    outputUrl.searchParams.set("visualOutput", "1");
    if (prewarm) outputUrl.searchParams.set("prewarm", "1");
    const benchmarkParams = new URLSearchParams(windowRef.location.search);
    if (benchmarkParams.get("worldshellBenchmark") === "1") {
      outputUrl.searchParams.set("worldshellBenchmark", "1");
      outputUrl.searchParams.set(
        "worldshellBenchmarkTarget",
        benchmarkParams.get("worldshellBenchmarkTarget") || "secondary"
      );
      for (const name of ["worldshellBenchmarkDuration", "worldshellBenchmarkWarmup"]) {
        const value = benchmarkParams.get(name);
        if (value) outputUrl.searchParams.set(name, value);
      }
    }
    outputWindow = windowRef.open(
      outputUrl.href,
      "cyanescent-visual-output",
      "popup=yes,width=640,height=360,resizable=yes"
    );
    if (!outputWindow) {
      console.warn("Visualiser window popup was blocked or failed to open");
      return false;
    }
    startBrowserStatePump();
    publishState();
    return true;
  }

  function toggleFullscreen() {
    if (outputRole) {
      if (nativeHandler()) nativeHandler().postMessage({ command: "toggleVisualOutputFullscreen" });
      else document.documentElement.requestFullscreen?.().catch(() => {});
      return true;
    }
    if (!ensureOpen({ explicit: true })) return false;
    const handler = nativeHandler();
    if (handler) handler.postMessage({ command: "toggleVisualOutputFullscreen" });
    else sendToOutput({ action: "toggle-fullscreen" });
    return true;
  }

  function applyPendingState() {
    if (!pendingState) return;
    const state = pendingState;
    pendingState = null;
    applyStateSnapshot?.(state);
  }

  function receiveSignal(detail) {
    if (!detail || typeof detail !== "object") return;
    if (outputRole) {
      if (detail.action === "visual-state") {
        pendingState = detail.state || null;
        if (ready) applyPendingState();
      } else if (detail.action === "toggle-fullscreen") {
        toggleFullscreen();
      } else if (detail.action === "preset-calibration" || detail.action === "preset-calibration-export") {
        onSignalReceived?.(detail);
      } else if (detail.action === "worldshell-benchmark-start") {
        onBenchmarkStart?.(detail.config || {});
      }
      return;
    }
    if (detail.action === "ready") {
      nativeOutputReady = true;
      autoOpenSuppressed = false;
      document.body.classList.add("visual-output-connected");
      onOutputReady?.();
      startBrowserStatePump();
      publishState();
    } else if (detail.action === "warmup-progress") {
      onWarmupProgress?.(detail);
    } else if (detail.action === "transition-state") {
      onTransitionState?.(detail);
    } else if (detail.action === "closed") {
      markClosed();
    } else {
      onSignalReceived?.(detail);
    }
  }

  function handleMessage(event) {
    if (event.origin !== windowRef.location.origin) return;
    const detail = event.data;
    if (detail?.type !== OUTPUT_MESSAGE) return;
    if (!outputRole && event.source) outputWindow = event.source;
    receiveSignal(detail);
  }

  function setFullscreen(value) {
    fullscreen = Boolean(value);
    document.body.classList.toggle("fullscreen-ui", outputRole && fullscreen);
    publishState();
  }

  function markReady() {
    ready = true;
    if (!outputRole) return;
    applyPendingState();
    sendToMain({ action: "ready" });
  }

  function showFirstRunHint() {
    if (!outputRole) return;
    if (!windowRef.localStorage.getItem("cyanescentVisualOutputHintSeen")) {
      const hint = windowRef.document.createElement("div");
      hint.className = "visual-output-hint";
      hint.textContent = "Drag to another display · Double-click for fullscreen";
      windowRef.document.body.appendChild(hint);
      windowRef.setTimeout(() => {
        hint.classList.add("visible");
      }, 100);
      windowRef.setTimeout(() => {
        hint.classList.remove("visible");
        windowRef.setTimeout(() => {
          hint.remove();
        }, 1200);
      }, 6000);
      windowRef.localStorage.setItem("cyanescentVisualOutputHintSeen", "true");
    }
  }

  function reportWarmupProgress(progress, status) {
    if (!outputRole) return;
    sendToMain({
      action: "warmup-progress",
      progress: Math.max(0, Math.min(1, Number(progress) || 0)),
      status: String(status || "Preparing visual renderer")
    });
  }

  function reportTransitionState(state = {}) {
    if (!outputRole) return;
    sendToMain({ action: "transition-state", ...state });
  }

  function setupWindowEvents() {
    windowRef.addEventListener("message", handleMessage);
    windowRef.addEventListener("beforeunload", () => {
      if (outputRole) sendToMain({ action: "closed" });
      else markClosed({ suppressAutomaticOpening: false });
    });
    if (outputRole) {
      windowRef.addEventListener("dblclick", (event) => {
        event.preventDefault();
        toggleFullscreen();
      });
      windowRef.addEventListener("unload", () => {
        sendToMain({ action: "closed" });
      });
    } else {
      windowRef.addEventListener("unload", () => {
        markClosed({ suppressAutomaticOpening: false });
      });
    }
  }

  setupWindowEvents();
  if (nativeHandler()) {
    windowRef.__cyanescentVisualOutputNativeSignal = receiveSignal;
    if (!outputRole) {
      windowRef.setTimeout(() => {
        nativeHandler().postMessage({ command: "queryVisualOutputState" });
      }, 50);
    }
  }

  windowRef.__cyanescentProduceVisualState = () => createStateSnapshot?.() || null;
  windowRef.__cyanescentVisualOutputNativeClosed = () => markClosed();
  // Called when the native visualiser window is hidden (parked) rather than
  // truly destroyed.  We keep nativeOutputReady=true so the next
  // ensureOpen({ explicit: true }) call sends "showVisualOutput" to Swift
  // (which un-parks instantly) instead of calling window.open() and triggering
  // a full page reload + warmup sequence.
  windowRef.__cyanescentVisualOutputNativeParked = () => {
    stopBrowserStatePump();
    outputWindow = null;          // isOpen() → false, so UI shows "open" button
    // nativeOutputReady intentionally kept true
    document.body.classList.remove("visual-output-connected");
    publishState();               // updates button text / tooltip
  };
  // Reply to parkVisualOutput when the window was not on screen: nothing to restore.
  windowRef.__cyanescentVisualOutputWasHidden = () => { reopenAfterHold = false; };
  windowRef.__cyanescentVisualOutputFullscreenChanged = setFullscreen;
  windowRef.__cyanescentRequestVisualOutput = (explicit = false) => ensureOpen({ explicit: Boolean(explicit) });
  windowRef.__cyanescentVisualOutputReceive = receiveSignal;
  windowRef.__cyanescentVisualOutputStart = () => {
    onStartRequested?.();
    showFirstRunHint();
  };

  publishState();
  return {
    prewarm: () => ensureOpen({ prewarm: true }),
    openAutomatically: () => ensureOpen({ explicit: false }),
    // Hide the visualiser and keep it hidden (playback normally opens it); on
    // release, bring it back only if it was showing before.
    holdHidden: (hold) => {
      if (outputRole) return;
      if (hold && !heldHidden) {
        heldHidden = true;
        // The native app knows whether the window is really on screen: it parks it,
        // or replies through __cyanescentVisualOutputWasHidden (nothing to restore).
        reopenAfterHold = Boolean(nativeHandler());
        nativeHandler()?.postMessage({ command: "parkVisualOutput" });
      } else if (!hold && heldHidden) {
        heldHidden = false;
        if (reopenAfterHold) ensureOpen({ explicit: true });
        reopenAfterHold = false;
      }
    },
    show: () => ensureOpen({ explicit: true }),
    toggleFullscreen,
    isOpen,
    automaticOpeningSuppressed: () => autoOpenSuppressed,
    setFullscreen,
    markReady,
    reportWarmupProgress,
    reportTransitionState,
    sendToMain,
    sendToOutput
  };
}
