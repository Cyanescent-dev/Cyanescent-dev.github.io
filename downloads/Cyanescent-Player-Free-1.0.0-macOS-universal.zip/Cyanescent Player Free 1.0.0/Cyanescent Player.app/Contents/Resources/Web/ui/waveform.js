import { clamp01 } from "../utils/math.js";

const SECTION_COLORS = {
  Intro: "rgba(125, 217, 213, 0.13)",
  Buildup: "rgba(221, 187, 102, 0.15)",
  Drop: "rgba(238, 110, 133, 0.18)",
  "Main riff": "rgba(151, 221, 124, 0.14)",
  Breakdown: "rgba(150, 126, 226, 0.15)",
  "Wind down": "rgba(190, 218, 244, 0.11)"
};

const LABEL_COLORS = {
  Intro: "rgba(151, 240, 235, 0.95)",
  Buildup: "rgba(239, 211, 126, 0.95)",
  Drop: "rgba(255, 151, 167, 0.98)",
  "Main riff": "rgba(179, 239, 145, 0.95)",
  Breakdown: "rgba(184, 165, 255, 0.95)",
  "Wind down": "rgba(210, 225, 239, 0.92)"
};

const SHORT_LABELS = {
  Buildup: "Build",
  Breakdown: "Break",
  "Wind down": "Wind"
};

function formatRulerTime(seconds) {
  const safe = Math.max(0, Number(seconds) || 0);
  const minutes = Math.floor(safe / 60);
  const whole = Math.floor(safe % 60).toString().padStart(2, "0");
  return `${minutes}:${whole}`;
}

function rulerStepForDuration(duration) {
  const safe = Math.max(1, Number(duration) || 1);
  const targetTicks = 8;
  const raw = safe / targetTicks;
  const steps = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600];
  return steps.find((step) => step >= raw) || 600;
}

export function waveformViewRangeFor({ duration, zoom = 1, center = 0.5 }) {
  if (!duration) return { start: 0, end: 0, duration: 0, zoom: 1 };
  const safeZoom = Math.max(1, Number(zoom) || 1);
  const numericCenter = center == null ? NaN : Number(center);
  const safeCenter = clamp01(Number.isFinite(numericCenter) ? numericCenter : 0.5);
  const windowSize = duration / safeZoom;
  let start = (safeCenter * duration) - (windowSize / 2);
  let end = start + windowSize;
  if (start < 0) {
    start = 0;
    end = Math.min(duration, windowSize);
  } else if (end > duration) {
    end = duration;
    start = Math.max(0, duration - windowSize);
  }
  return { start, end, duration, zoom: safeZoom };
}

export function waveformXToTimeInView(x, width, view) {
  if (!width || !view) return 0;
  const fraction = clamp01(x / width);
  return view.start + fraction * (view.end - view.start);
}

export function waveformZoomStateFor({
  zoom,
  anchorTime = 0,
  duration = 0,
  currentView = null,
  maxZoom = 64
}) {
  if (!duration) return null;
  const nextZoom = Math.max(1, Math.min(maxZoom, Number(zoom) || 1));
  const view = currentView || waveformViewRangeFor({ duration, zoom: 1, center: 0.5 });
  const currentWindow = view.end - view.start;
  const fraction = currentWindow > 0 ? (anchorTime - view.start) / currentWindow : 0.5;
  const newWindow = duration / nextZoom;
  let newStart = anchorTime - fraction * newWindow;
  let newCenter = newStart + newWindow / 2;
  if (newCenter - newWindow / 2 < 0) {
    newCenter = newWindow / 2;
  } else if (newCenter + newWindow / 2 > duration) {
    newCenter = duration - newWindow / 2;
  }
  return {
    zoom: nextZoom,
    center: clamp01(newCenter / duration)
  };
}

// Pointer coordinates are CSS pixels. The canvas bitmap fills the content
// box, excluding borders/padding (and may be displayed at a CSS scale).
export function waveformPointerPosition(canvas, clientX) {
  const rect = canvas.getBoundingClientRect();
  const style = getComputedStyle(canvas);
  const scale = canvas.offsetWidth ? rect.width / canvas.offsetWidth : 1;
  const left = (parseFloat(style.borderLeftWidth) || 0) + (parseFloat(style.paddingLeft) || 0);
  const right = (parseFloat(style.borderRightWidth) || 0) + (parseFloat(style.paddingRight) || 0);
  const width = Math.max(0, rect.width - (left + right) * scale);
  return { x: clientX - rect.left - left * scale, width, rect };
}

export function registerWaveformInteractionHandlers({
  canvas,
  zoomControl,
  resetControl,
  debugEnabled,
  canSeek,
  getView,
  getDuration,
  getCurrentTime,
  xToTime,
  onSeek,
  onZoom,
  onMarkDrop = null,
  getExportRange = () => null,
  onExportRangeChange = null
} = {}) {
  let rangeDrag = null;
  let suppressClick = false;

  canvas?.addEventListener("click", (event) => {
    if (suppressClick) {
      suppressClick = false;
      return;
    }
    if (!canSeek?.()) return;
    const { x, width, rect } = waveformPointerPosition(canvas, event.clientX);
    const time = xToTime?.(x, width, getView?.());
    if (!Number.isFinite(time)) return;
    // Option-click marks or unmarks a drop there (Option-Shift: a minor drop) instead of seeking
    if (event.altKey && onMarkDrop) onMarkDrop(time, { minor: event.shiftKey });
    else onSeek?.(time, { clientX: event.clientX, left: rect.left, width: rect.width, contentX: x, contentWidth: width });
  });

  function rangeHandleAt(event) {
    const range = getExportRange?.();
    if (!range?.valid || range.mode !== "selected") return null;
    const { x, width } = waveformPointerPosition(canvas, event.clientX);
    const view = getView?.();
    const visible = Math.max(0.001, (view?.end || 0) - (view?.start || 0));
    const startX = ((range.start - (view?.start || 0)) / visible) * width;
    const endX = ((range.end - (view?.start || 0)) / visible) * width;
    const nearest = Math.abs(x - startX) <= Math.abs(x - endX) ? "start" : "end";
    const nearestX = nearest === "start" ? startX : endX;
    return Math.abs(x - nearestX) <= 14 ? nearest : null;
  }

  canvas?.addEventListener("pointerdown", (event) => {
    const edge = rangeHandleAt(event);
    if (!edge) return;
    event.preventDefault();
    suppressClick = true;
    rangeDrag = { edge, pointerId: event.pointerId };
    canvas.setPointerCapture?.(event.pointerId);
    canvas.classList.add("dragging-export-range");
  });

  canvas?.addEventListener("pointermove", (event) => {
    if (!rangeDrag || rangeDrag.pointerId !== event.pointerId) return;
    event.preventDefault();
    const { x, width } = waveformPointerPosition(canvas, event.clientX);
    const time = xToTime?.(x, width, getView?.());
    if (Number.isFinite(time)) onExportRangeChange?.(rangeDrag.edge, time);
  });

  function finishRangeDrag(event) {
    if (!rangeDrag || rangeDrag.pointerId !== event.pointerId) return;
    event.preventDefault();
    canvas.releasePointerCapture?.(event.pointerId);
    canvas.classList.remove("dragging-export-range");
    rangeDrag = null;
  }
  canvas?.addEventListener("pointerup", finishRangeDrag);
  canvas?.addEventListener("pointercancel", finishRangeDrag);

  canvas?.addEventListener("wheel", (event) => {
    if (!debugEnabled?.() || !getDuration?.()) return;
    event.preventDefault();
    const { x, width } = waveformPointerPosition(canvas, event.clientX);
    const anchorTime = xToTime?.(x, width, getView?.());
    const direction = event.deltaY < 0 ? 1.18 : 1 / 1.18;
    onZoom?.(direction, anchorTime);
  }, { passive: false });

  zoomControl?.addEventListener("input", () => {
    onZoom?.(Number(zoomControl.value), getCurrentTime?.(), { absolute: true });
  });

  resetControl?.addEventListener("click", () => {
    onZoom?.(1, undefined, { absolute: true });
  });
}

function drawSectionBands(ctx, sections, duration, width, height, ratio, viewStart = 0) {
  ctx.save();
  ctx.font = `${Math.round(10.5 * ratio)}px sans-serif`;
  ctx.textBaseline = "top";
  let lastLabelEnd = -Infinity;
  for (const section of sections) {
    const startX = clamp01((section.start - viewStart) / duration) * width;
    const endX = clamp01((section.end - viewStart) / duration) * width;
    const sectionWidth = Math.max(1, endX - startX);
    const confidence = section.confidence ?? 0.72;
    ctx.globalAlpha = 0.62 + confidence * 0.38;
    ctx.fillStyle = SECTION_COLORS[section.label] || "rgba(190, 218, 244, 0.10)";
    ctx.fillRect(startX, 0, sectionWidth, height);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = "rgba(225, 240, 248, 0.18)";
    ctx.beginPath();
    ctx.moveTo(startX, 0);
    ctx.lineTo(startX, height);
    ctx.stroke();
    const fullLabel = section.label;
    const shortLabel = SHORT_LABELS[fullLabel] || fullLabel;
    let label = fullLabel;
    const labelWidth = ctx.measureText(label).width;
    if (sectionWidth <= labelWidth + 14 * ratio) label = shortLabel;
    const displayWidth = ctx.measureText(label).width;
    if (sectionWidth > displayWidth + 10 * ratio && startX > lastLabelEnd + 5 * ratio) {
      ctx.globalAlpha = 0.56 + confidence * 0.44;
      ctx.fillStyle = LABEL_COLORS[fullLabel] || "rgba(225, 240, 248, 0.84)";
      ctx.fillText(label, startX + 6 * ratio, 7 * ratio);
      ctx.globalAlpha = 1;
      lastLabelEnd = startX + 6 * ratio + displayWidth;
    }
  }
  ctx.strokeStyle = "rgba(225, 240, 248, 0.22)";
  ctx.beginPath();
  ctx.moveTo(width - 0.5, 0);
  ctx.lineTo(width - 0.5, height);
  ctx.stroke();
  ctx.restore();
}

function drawLoopBoundaries(ctx, timeline, duration, width, height, ratio, viewStart = 0) {
  if (!timeline?.tempo?.bpm || !duration) return;
  const boundaries = timeline.getLoopBoundariesBetween(viewStart, viewStart + duration, [8, 16, 32]);
  ctx.save();
  for (const boundary of boundaries) {
    const x = clamp01((boundary.time - viewStart) / duration) * width;
    if (boundary.beats === 32) {
      ctx.strokeStyle = "rgba(255, 151, 167, 0.72)";
      ctx.lineWidth = Math.max(2, ratio * 2.8);
    } else if (boundary.beats === 16) {
      ctx.strokeStyle = "rgba(221, 187, 102, 0.58)";
      ctx.lineWidth = Math.max(2, ratio * 2.2);
    } else {
      ctx.strokeStyle = "rgba(125, 217, 213, 0.42)";
      ctx.lineWidth = Math.max(2, ratio * 1.7);
    }
    ctx.beginPath();
    ctx.moveTo(x, boundary.beats === 8 ? height * 0.18 : 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  ctx.restore();
}

function drawSegmentLabels(ctx, segments, duration, width, height, ratio, viewStart = 0) {
  if (!segments?.length || !duration) return;
  ctx.save();
  ctx.font = `${Math.round(10 * ratio)}px sans-serif`;
  ctx.textBaseline = "bottom";
  ctx.shadowColor = "rgba(0, 0, 0, 0.86)";
  ctx.shadowBlur = 5 * ratio;
  for (const segment of segments) {
    const start = Number(segment.start);
    const end = Number(segment.end);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= viewStart || start >= viewStart + duration) continue;
    const startX = clamp01((start - viewStart) / duration) * width;
    const endX = clamp01((end - viewStart) / duration) * width;
    const segmentWidth = Math.max(1, endX - startX);
    const label = String(segment.label || "").trim();
    if (!label) continue;
    const maxWidth = segmentWidth - 10 * ratio;
    if (maxWidth < 36 * ratio) continue;
    let display = label;
    while (display.length > 5 && ctx.measureText(display).width > maxWidth) {
      display = `${display.slice(0, -2)}…`;
    }
    const labelWidth = ctx.measureText(display).width;
    ctx.fillStyle = "rgba(7, 12, 18, 0.62)";
    ctx.fillRect(startX + 4 * ratio, height - 19 * ratio, Math.min(maxWidth + 6 * ratio, labelWidth + 8 * ratio), 15 * ratio);
    ctx.fillStyle = "rgba(190, 218, 244, 0.86)";
    ctx.fillText(display, startX + 8 * ratio, height - 6 * ratio);
  }
  ctx.restore();
}

function drawSectionLabels(ctx, sections, duration, width, ratio, viewStart = 0) {
  ctx.save();
  ctx.font = `${Math.round(10.5 * ratio)}px sans-serif`;
  ctx.textBaseline = "top";
  ctx.shadowColor = "rgba(0, 0, 0, 0.8)";
  ctx.shadowBlur = 4 * ratio;
  let lastLabelEnd = -Infinity;
  for (const section of sections) {
    const startX = clamp01((section.start - viewStart) / duration) * width;
    const endX = clamp01((section.end - viewStart) / duration) * width;
    const sectionWidth = Math.max(1, endX - startX);
    const confidence = section.confidence ?? 0.72;
    let label = section.label;
    const fullWidth = ctx.measureText(label).width;
    if (sectionWidth <= fullWidth + 14 * ratio) label = SHORT_LABELS[section.label] || section.label;
    const labelWidth = ctx.measureText(label).width;
    if (sectionWidth > labelWidth + 10 * ratio && startX > lastLabelEnd + 5 * ratio) {
      ctx.globalAlpha = 0.56 + confidence * 0.44;
      ctx.fillStyle = LABEL_COLORS[section.label] || "rgba(225, 240, 248, 0.88)";
      ctx.fillText(label, startX + 6 * ratio, 7 * ratio);
      ctx.globalAlpha = 1;
      lastLabelEnd = startX + 6 * ratio + labelWidth;
    }
  }
  ctx.restore();
}

function drawTempoBadge(ctx, tempo, width, ratio) {
  if (!tempo?.bpm) return;
  const bpmText = `${tempo.bpm.toFixed(1)} BPM`;
  ctx.save();
  ctx.font = `${Math.round(12 * ratio)}px sans-serif`;
  ctx.textBaseline = "top";
  const paddingX = 8 * ratio;
  const paddingY = 5 * ratio;
  const textWidth = ctx.measureText(bpmText).width;
  const boxWidth = textWidth + paddingX * 2;
  const boxHeight = 22 * ratio;
  const x = width - boxWidth - 9 * ratio;
  const y = 8 * ratio;
  ctx.fillStyle = "rgba(4, 8, 14, 0.68)";
  ctx.fillRect(x, y, boxWidth, boxHeight);
  ctx.strokeStyle = "rgba(221, 187, 102, 0.38)";
  ctx.strokeRect(x + 0.5, y + 0.5, boxWidth - 1, boxHeight - 1);
  ctx.fillStyle = "rgba(239, 211, 126, 0.96)";
  ctx.fillText(bpmText, x + paddingX, y + paddingY);
  ctx.restore();
}

function drawTransitionMarkers(ctx, markers, duration, width, height, ratio, viewStart = 0) {
  if (!markers?.length || !duration) return;
  ctx.save();
  ctx.font = `${Math.round(9.5 * ratio)}px sans-serif`;
  ctx.textBaseline = "top";
  ctx.shadowColor = "rgba(0, 0, 0, 0.85)";
  ctx.shadowBlur = 4 * ratio;
  for (const marker of markers) {
    const landing = Number(marker.landingTime ?? marker.time);
    if (!Number.isFinite(landing)) continue;
    const x = clamp01((landing - viewStart) / duration) * width;
    if (x < -2 || x > width + 2) continue;
    const rising = marker.style === "rising" || marker.eventType === "drop";
    const falling = marker.style === "falling" || marker.eventType === "breakdown";
    ctx.strokeStyle = rising ? "rgba(244, 192, 82, 0.94)" : falling ? "rgba(157, 190, 255, 0.86)" : "rgba(224, 238, 248, 0.72)";
    ctx.lineWidth = Math.max(1.2 * ratio, rising ? 1.8 * ratio : 1.2 * ratio);
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
    const label = marker.status === "export" ? "Export" : marker.source || "Transition";
    ctx.fillStyle = ctx.strokeStyle;
    ctx.fillText(label, x + 4 * ratio, 18 * ratio);
  }
  ctx.restore();
}

// Drops from the track's drop map: a downward triangle at the top and a faint line; major drops
// larger and brighter; the listener's markers filled, the analysis' own outlined.
function drawDrops(ctx, drops, duration, width, height, ratio, viewStart = 0) {
  if (!drops?.length || !duration) return;
  ctx.save();
  for (const drop of drops) {
    const x = ((drop.time - viewStart) / duration) * width;
    if (x < -8 * ratio || x > width + 8 * ratio) continue;
    const major = drop.kind === "major";
    const color = major ? "rgba(255, 108, 150, 0.95)" : "rgba(255, 176, 200, 0.75)";
    const size = (major ? 6 : 4.2) * ratio;
    ctx.strokeStyle = major ? "rgba(255, 108, 150, 0.42)" : "rgba(255, 176, 200, 0.26)";
    ctx.lineWidth = Math.max(1, ratio);
    ctx.beginPath();
    ctx.moveTo(x, size * 1.6);
    ctx.lineTo(x, height);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x - size, 1.5 * ratio);
    ctx.lineTo(x + size, 1.5 * ratio);
    ctx.lineTo(x, 1.5 * ratio + size * 1.5);
    ctx.closePath();
    ctx.shadowColor = color;
    ctx.shadowBlur = 5 * ratio;
    if (drop.source === "marker") {
      ctx.fillStyle = color;
      ctx.fill();
    } else {
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.4 * ratio;
      ctx.stroke();
    }
    ctx.shadowBlur = 0;
  }
  ctx.restore();
}

function drawTimelineRuler(ctx, duration, width, ratio, viewStart = 0) {
  if (!duration || !width) return;
  const step = rulerStepForDuration(duration);
  const startTime = Math.ceil(viewStart / step) * step;
  const endTime = viewStart + duration;
  ctx.save();
  ctx.font = `${Math.round(9 * ratio)}px sans-serif`;
  ctx.textBaseline = "top";
  ctx.fillStyle = "rgba(190, 218, 244, 0.70)";
  ctx.strokeStyle = "rgba(190, 218, 244, 0.24)";
  ctx.lineWidth = Math.max(1, ratio);
  ctx.beginPath();
  ctx.moveTo(0, 17 * ratio);
  ctx.lineTo(width, 17 * ratio);
  ctx.stroke();
  for (let time = startTime; time <= endTime + 0.001; time += step) {
    const x = ((time - viewStart) / duration) * width;
    if (x < -1 || x > width + 1) continue;
    const major = Math.abs((time / (step * 2)) - Math.round(time / (step * 2))) < 0.001;
    ctx.strokeStyle = major ? "rgba(190, 218, 244, 0.44)" : "rgba(190, 218, 244, 0.25)";
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, major ? 17 * ratio : 11 * ratio);
    ctx.stroke();
    if (major || duration < 80) {
      ctx.fillStyle = "rgba(210, 225, 239, 0.78)";
      ctx.fillText(formatRulerTime(time), x + 4 * ratio, 2 * ratio);
    }
  }
  ctx.restore();
}

function drawExportRangeOverlay(ctx, range, duration, width, height, ratio, viewStart = 0) {
  if (!range?.valid || range.mode !== "selected" || !duration) return;
  const startX = clamp01((range.start - viewStart) / duration) * width;
  const endX = clamp01((range.end - viewStart) / duration) * width;
  if (endX <= startX) return;
  ctx.save();
  ctx.fillStyle = "rgba(3, 8, 15, 0.54)";
  ctx.fillRect(0, 0, startX, height);
  ctx.fillRect(endX, 0, width - endX, height);
  ctx.fillStyle = "rgba(125, 217, 213, 0.10)";
  ctx.fillRect(startX, 0, endX - startX, height);
  ctx.strokeStyle = "rgba(157, 244, 255, 0.96)";
  ctx.lineWidth = Math.max(2, ratio * 2);
  for (const x of [startX, endX]) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
    ctx.fillStyle = "rgba(157, 244, 255, 0.98)";
    ctx.beginPath();
    ctx.moveTo(x - 5 * ratio, 0);
    ctx.lineTo(x + 5 * ratio, 0);
    ctx.lineTo(x, 8 * ratio);
    ctx.closePath();
    ctx.fill();
  }
  ctx.font = `${Math.round(9 * ratio)}px sans-serif`;
  ctx.fillStyle = "rgba(205, 245, 248, 0.92)";
  const label = `Export ${formatRulerTime(range.start)}–${formatRulerTime(range.end)}`;
  ctx.fillText(label, Math.min(Math.max(5 * ratio, startX + 7 * ratio), Math.max(5 * ratio, width - ctx.measureText(label).width - 5 * ratio)), height - 7 * ratio);
  ctx.restore();
}

export function renderWaveformTimeline({
  canvas,
  timeline,
  peaks = [],
  sections = [],
  transitionMarkers = [],
  segmentLabels = [],
  tempo = null,
  progress = 0,
  waveformLoadProgress = 1,
  waveformLoading = false,
  duration = 0,
  viewStart = 0,
  playheadColor = "rgba(255, 248, 214, 0.92)",
  playheadWidth = 1,
  playheadGlow = 0,
  showBeatGrid = true,
  exportRange = null
}) {
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(2, Math.floor(rect.width * ratio));
  const height = Math.max(2, Math.floor(rect.height * ratio));
  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "rgba(0, 0, 0, 0.22)";
  ctx.fillRect(0, 0, width, height);
  const center = height * 0.5;
  drawTimelineRuler(ctx, duration, width, ratio, viewStart);

  if (sections.length && duration) {
    drawSectionBands(ctx, sections, duration, width, height, ratio, viewStart);
  }

  if (showBeatGrid) drawLoopBoundaries(ctx, timeline, duration, width, height, ratio, viewStart);

  ctx.strokeStyle = "rgba(190, 218, 244, 0.14)";
  ctx.beginPath();
  ctx.moveTo(0, center);
  ctx.lineTo(width, center);
  ctx.stroke();

  const visiblePeaks = peaks.length ? peaks : new Array(96).fill(0);
  const barWidth = Math.max(1, width / visiblePeaks.length);
  const progressX = width * progress;
  const loadedX = width * clamp01(waveformLoadProgress);
  for (let i = 0; i < visiblePeaks.length; i += 1) {
    const x = i * barWidth;
    if (waveformLoading && x > loadedX) {
      ctx.fillStyle = "rgba(190, 218, 244, 0.10)";
      ctx.fillRect(x, center - ratio * 0.5, Math.max(1, barWidth * 0.72), ratio);
      continue;
    }
    const peak = Math.max(0.018, visiblePeaks[i]);
    const barHeight = peak * height * 0.82;
    ctx.fillStyle = x <= progressX ? "rgba(125, 217, 213, 0.92)" : "rgba(190, 218, 244, 0.36)";
    ctx.fillRect(x, center - barHeight * 0.5, Math.max(1, barWidth * 0.72), barHeight);
  }

  drawExportRangeOverlay(ctx, exportRange, duration, width, height, ratio, viewStart);

  if (waveformLoading) {
    const scanWidth = Math.max(2 * ratio, 10 * ratio);
    const gradient = ctx.createLinearGradient(Math.max(0, loadedX - scanWidth), 0, loadedX + scanWidth, 0);
    gradient.addColorStop(0, "rgba(125, 217, 213, 0)");
    gradient.addColorStop(0.5, "rgba(157, 244, 255, 0.62)");
    gradient.addColorStop(1, "rgba(125, 217, 213, 0)");
    ctx.fillStyle = gradient;
    ctx.fillRect(Math.max(0, loadedX - scanWidth), 0, scanWidth * 2, height);
    ctx.fillStyle = "rgba(205, 235, 240, 0.82)";
    ctx.font = `${Math.round(10 * ratio)}px sans-serif`;
    ctx.fillText(`Building waveform ${Math.round(clamp01(waveformLoadProgress) * 100)}%`, 10 * ratio, height - 8 * ratio);
  }

  ctx.save();
  ctx.strokeStyle = playheadColor;
  ctx.lineWidth = Math.max(1, ratio * playheadWidth);
  if (playheadGlow > 0) {
    ctx.shadowColor = playheadColor;
    ctx.shadowBlur = playheadGlow * ratio;
  }
  ctx.beginPath();
  ctx.moveTo(progressX, 0);
  ctx.lineTo(progressX, height);
  ctx.stroke();
  ctx.restore();

  if (sections.length && duration) {
    drawSectionLabels(ctx, sections, duration, width, ratio, viewStart);
  }

  drawTransitionMarkers(ctx, transitionMarkers, duration, width, height, ratio, viewStart);
  drawDrops(ctx, timeline?.drops, duration, width, height, ratio, viewStart);
  drawSegmentLabels(ctx, segmentLabels, duration, width, height, ratio, viewStart);

  if (!peaks.length) {
    ctx.fillStyle = "rgba(143, 160, 174, 0.55)";
    ctx.font = `${Math.round(11 * ratio)}px sans-serif`;
    ctx.fillText("Waveform appears after track analysis", 10 * ratio, center + 4 * ratio);
  }

  drawTempoBadge(ctx, tempo, width, ratio);
}

export function createWaveformController({
  ui,
  getTimeline,
  getPlayerTime,
  getPlayerDuration,
  getDuration,
  getExportRange = () => null,
  clampTime,
  now = () => performance.now()
} = {}) {
  let peaks = [];
  let sections = [];
  let tempo = null;
  let progress = 0;
  let zoom = 1;
  let zoomCenter = 0.5;
  let transitionMarkers = [];
  let waveformLoadProgress = 1;
  let waveformLoading = false;
  let lastPaintAt = 0;
  let lastPaintProgress = -1;

  function duration() {
    return getDuration?.() || 0;
  }

  function playerTimeToWaveformTime(time = getPlayerTime?.() || 0) {
    return clampTime?.(time, duration()) ?? time;
  }

  function waveformTimeToPlayerTime(time) {
    return clampTime?.(time, getPlayerDuration?.() || 0) ?? time;
  }

  function viewRange() {
    return waveformViewRangeFor({
      duration: duration(),
      zoom,
      center: zoomCenter
    });
  }

  function xToTime(x, width, view) {
    return waveformXToTimeInView(x, width, view);
  }

  function draw() {
    const totalDuration = duration();
    const view = viewRange();
    const viewDuration = view.end - view.start || totalDuration;
    const visiblePeaks = peaks.length && totalDuration && viewDuration
      ? peaks.slice(
        Math.max(0, Math.floor((view.start / totalDuration) * peaks.length)),
        Math.min(peaks.length, Math.ceil((view.end / totalDuration) * peaks.length))
      )
      : peaks;
    const currentTime = playerTimeToWaveformTime(getPlayerTime?.() || 0);
    const viewProgress = viewDuration ? clamp01((currentTime - view.start) / viewDuration) : progress;
    const loadedTime = totalDuration * waveformLoadProgress;
    const visibleLoadProgress = viewDuration ? clamp01((loadedTime - view.start) / viewDuration) : waveformLoadProgress;
    renderWaveformTimeline({
      canvas: ui.waveformCanvas,
      timeline: getTimeline?.(),
      peaks: visiblePeaks,
      sections,
      transitionMarkers,
      tempo,
      progress: viewProgress,
      waveformLoadProgress: visibleLoadProgress,
      waveformLoading,
      duration: viewDuration,
      viewStart: view.start,
      exportRange: getExportRange?.()
    });
  }

  function updateProgress(force = false) {
    const totalDuration = duration();
    if (totalDuration) {
      progress = clamp01(playerTimeToWaveformTime(getPlayerTime?.() || 0) / totalDuration);
    } else {
      progress = 0;
    }
    const time = now();
    const progressMoved = Math.abs(progress - lastPaintProgress) > 0.0025;
    const paintDue = time - lastPaintAt > 90;
    if (force || (totalDuration && progressMoved && paintDue)) {
      lastPaintAt = time;
      lastPaintProgress = progress;
      draw();
    }
  }

  function setAnalysisTimeline(timeline) {
    peaks = timeline?.waveformPeaks || [];
    sections = timeline?.sections || [];
    tempo = timeline?.tempo || null;
    waveformLoadProgress = 1;
    waveformLoading = false;
  }

  function setProgressiveWaveform(nextPeaks, nextProgress = 0, complete = false) {
    peaks = Array.isArray(nextPeaks) ? nextPeaks : [];
    waveformLoadProgress = clamp01(nextProgress);
    waveformLoading = !complete;
    lastPaintAt = now();
    draw();
  }

  function clearAnalysis() {
    peaks = [];
    sections = [];
    tempo = null;
    waveformLoadProgress = 1;
    waveformLoading = false;
  }

  function resetForSource() {
    clearAnalysis();
    progress = 0;
    transitionMarkers = [];
    zoom = 1;
    zoomCenter = 0.5;
    lastPaintAt = 0;
    lastPaintProgress = -1;
    if (ui.waveformZoom) ui.waveformZoom.value = "1";
  }

  function resetZoomIfHidden(debugEnabled) {
    if (debugEnabled || zoom <= 1.001) return;
    zoom = 1;
    zoomCenter = 0.5;
    if (ui.waveformZoom) ui.waveformZoom.value = "1";
    draw();
  }

  function setZoom(nextZoom, anchorTime = 0) {
    const totalDuration = duration();
    if (!totalDuration) return;
    const nextState = waveformZoomStateFor({
      zoom: nextZoom,
      anchorTime,
      duration: totalDuration,
      currentView: viewRange()
    });
    if (!nextState) return;
    zoom = nextState.zoom;
    zoomCenter = nextState.center;
    if (ui.waveformZoom) ui.waveformZoom.value = String(nextState.zoom);
    draw();
  }

  function setZoomCenterFromTime(time) {
    const totalDuration = duration();
    zoomCenter = totalDuration ? clamp01(time / totalDuration) : 0.5;
  }

  function addTransitionMarker(marker) {
    if (!marker || !Number.isFinite(marker.landingTime ?? marker.time ?? NaN)) return;
    transitionMarkers.push(marker);
    transitionMarkers.sort((a, b) => (a.landingTime ?? a.time ?? 0) - (b.landingTime ?? b.time ?? 0));
    if (transitionMarkers.length > 256) {
      transitionMarkers.splice(0, transitionMarkers.length - 256);
    }
  }

  return {
    draw,
    updateProgress,
    setAnalysisTimeline,
    setProgressiveWaveform,
    clearAnalysis,
    resetForSource,
    resetZoomIfHidden,
    setZoom,
    setZoomCenterFromTime,
    addTransitionMarker,
    viewRange,
    xToTime,
    playerTimeToWaveformTime,
    waveformTimeToPlayerTime,
    progress: () => progress,
    zoom: () => zoom,
    setProgress: (value) => { progress = clamp01(value); }
  };
}
