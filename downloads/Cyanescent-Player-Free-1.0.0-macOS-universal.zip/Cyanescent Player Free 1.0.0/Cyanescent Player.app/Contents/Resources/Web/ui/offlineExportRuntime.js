import { enforceRuntimeOptions, requireRuntimePreset } from "../config/runtimeCapabilities.js";
import {
  appendNativeOfflineFrame,
  drawExportFraming,
  beginNativeOfflineExport,
  exportRenderDimensions,
  exportRenderSizeLabel,
  exportErrorMessage,
  exportSupersamplingWarning,
  finishNativeOfflineExport,
  nativeTrackIdForExport,
  offlineExportProgressMessage,
  validateExportRenderSize
} from "./export.js";
import { validateExportCapabilities } from "./exportCapabilities.js";
import {
  buildAuthoredTimelineClipPlan,
  buildFullTrackAutoClipPlan,
  buildStandaloneAutoClipPlan,
  normalizeOfflineSourceRange
} from "./offlineTimeline.js";

export function createMusicVideoExporter({
  ui,
  exportState,
  documentBody = document.body,
  performanceNow = () => performance.now(),
  waitForVisualsReady,
  waitForAnalysisReady,
  playerDuration,
  currentTrack,
  ensurePlayer,
  nativeAppBridge,
  updateExportFileNameExtension,
  selectedExportPath,
  chooseExportLocation,
  exportOptions,
  normalizePresetId,
  getActivePreset,
  setActivePreset,
  getTransition,
  setTransition,
  getRenderMode,
  setRenderMode,
  getWaveformProgress,
  setWaveformProgress,
  getReadIndex,
  setReadIndex,
  getQuality,
  setQuality,
  setOfflineRenderClock,
  setFeedbackStep,
  resetFeedbackStepTiming,
  setExportResolutionOverride,
  getGl,
  getActualRenderSize,
  resize,
  clearFeedbackBuffers,
  resetLookaheadState,
  drawWaveform,
  setExportProgress,
  buildOfflinePresetTimeline,
  renderOfflineFrameAt,
  prepareOfflineAudioState = null,
  getAnalysisTimeline = () => null,
  isTimelineMode = () => Boolean(ui?.exportTimelineEnabled?.checked),
  canvasFrameBase64,
  canvasEncodedFrame,
  offlineVideoTransitionCompositor,
  getVideoTransitionOptions,
  playPlayerAudioWithFade,
  renderModeOfflineExport,
  resetOfflineVideoBackgroundState,
  getCanvas = () => null,
  stopPresetRuntimes = () => {}
} = {}) {
  function currentNativeApp() {
    return nativeAppBridge?.();
  }

  function currentNativeTrackId() {
    return nativeTrackIdForExport(currentTrack?.());
  }

  function beginNativeEncoding(options, duration, totalFrames, sourceStart, sourceEnd, includeAudio) {
    return beginNativeOfflineExport({
      nativeApp: currentNativeApp(),
      state: exportState,
      options,
      outputPath: exportState.outputPath,
      audioTrackId: currentNativeTrackId(),
      duration,
      totalFrames,
      sourceStart,
      sourceEnd,
      includeAudio
    });
  }

  function appendNativeFrame(frameIndex, timeSeconds, encodedFrame, transitionOverlay = null, videoBackgroundOverlay = null) {
    return appendNativeOfflineFrame({
      nativeApp: currentNativeApp(),
      state: exportState,
      frameIndex,
      timeSeconds,
      base64Jpeg: encodedFrame?.base64 || encodedFrame || "",
      transitionOverlay,
      videoBackgroundOverlay,
      imageType: encodedFrame?.imageType || "jpeg",
      diagnostic: Boolean(encodedFrame?.diagnostic)
    });
  }

  function finishNativeEncoding() {
    return finishNativeOfflineExport({
      nativeApp: currentNativeApp(),
      state: exportState
    });
  }


  // The visual plan for a source range. Shared by export and the Export Studio
  // preview, so the preview always shows what the export renders.
  function buildClipPlan({ options, sourceRange, trackDuration, duration, startPreset, testPresetEnabled = false, sourceAnalysisTimeline }) {
    const selectedSourceRange = sourceRange.sourceStart > 0.0001
      || sourceRange.sourceEnd < trackDuration - 0.0001;
    const automaticBuilder = ({ analysisTimeline, duration: planDuration }) => buildOfflinePresetTimeline(
      planDuration,
      { analysisTimeline, allowManual: false }
    );
    let clipPlan;
    if (testPresetEnabled) {
      clipPlan = buildStandaloneAutoClipPlan({
        analysisTimeline: sourceAnalysisTimeline,
        sourceStart: sourceRange.sourceStart,
        sourceEnd: sourceRange.sourceEnd,
        sourceDuration: trackDuration,
        buildPlan: () => ({ timeline: [], startPreset }),
        planOptions: { activePreset: startPreset }
      });
    } else if (isTimelineMode?.() && selectedSourceRange) {
      const fullPlan = buildOfflinePresetTimeline(trackDuration);
      const fullTimeline = Array.isArray(fullPlan) ? fullPlan : fullPlan?.timeline || [];
      const fullStartPreset = Array.isArray(fullPlan) ? startPreset : fullPlan?.startPreset ?? startPreset;
      clipPlan = buildAuthoredTimelineClipPlan({
        analysisTimeline: sourceAnalysisTimeline,
        timeline: fullTimeline,
        startPreset: fullStartPreset,
        sourceStart: sourceRange.sourceStart,
        sourceEnd: sourceRange.sourceEnd,
        sourceDuration: trackDuration
      });
    } else if (!isTimelineMode?.() && selectedSourceRange && options.autoClipBehaviour === "standalone") {
      clipPlan = buildStandaloneAutoClipPlan({
        analysisTimeline: sourceAnalysisTimeline,
        sourceStart: sourceRange.sourceStart,
        sourceEnd: sourceRange.sourceEnd,
        sourceDuration: trackDuration,
        buildPlan: automaticBuilder,
        planOptions: { activePreset: startPreset }
      });
    } else if (!isTimelineMode?.() && selectedSourceRange) {
      clipPlan = buildFullTrackAutoClipPlan({
        analysisTimeline: sourceAnalysisTimeline,
        sourceStart: sourceRange.sourceStart,
        sourceEnd: sourceRange.sourceEnd,
        sourceDuration: trackDuration,
        buildPlan: automaticBuilder,
        planOptions: { activePreset: startPreset }
      });
    } else {
      const offlineTimelinePlan = buildOfflinePresetTimeline(duration);
      clipPlan = {
        timeline: Array.isArray(offlineTimelinePlan) ? offlineTimelinePlan : offlineTimelinePlan?.timeline || [],
        startPreset: Array.isArray(offlineTimelinePlan) ? startPreset : offlineTimelinePlan?.startPreset ?? startPreset,
        analysisTimeline: sourceAnalysisTimeline,
        renderDuration: duration,
        renderTimeAt: (outputTime) => outputTime,
        timelineTimeAtOutputTime: (outputTime) => outputTime
      };
    }
    return clipPlan;
  }

  function updateProgress(frameIndex, totalFrames, duration, fps, prefix = "", options = exportOptions()) {
    const done = frameIndex + 1;
    const percent = totalFrames ? done / totalFrames * 100 : 0;
    const baseMessage = offlineExportProgressMessage({
        frameIndex,
        totalFrames,
        duration,
        fps,
        startedAt: exportState.startedAt
      });
    setExportProgress(percent, `${prefix}${baseMessage} ${exportRenderSizeLabel(options, getActualRenderSize?.())}.`);
  }

  async function start(runConfig = {}) {
    if (exportState.active || exportState.nativeCancellationPending) return;
    const audio = ensurePlayer();
    if (!audio.src || !currentTrack()) {
      setExportProgress(0, "Load a track before exporting.");
      return;
    }
    if (!currentNativeApp()) {
      setExportProgress(0, "Music Video Mode requires the macOS app encoder.");
      return;
    }
    if (runConfig.outputPath) exportState.outputPath = runConfig.outputPath;
    if (!exportState.outputPath) {
      setExportProgress(0, "Choose an output location before exporting.");
      chooseExportLocation();
      return;
    }
    if (!runConfig.outputPath) updateExportFileNameExtension();
    exportState.outputPath = runConfig.outputPath || selectedExportPath() || (exportState.outputPath.match(/\.[^/.]+$/)
      ? exportState.outputPath.replace(/\.[^/.]+$/, ".mp4")
      : `${exportState.outputPath}.mp4`);
    if (ui.exportOutputPath) ui.exportOutputPath.value = exportState.outputPath;

    const trackDuration = playerDuration();
    if (!Number.isFinite(trackDuration) || trackDuration <= 0) {
      setExportProgress(0, "Track duration is not ready yet. Try again in a moment.");
      return;
    }

    let options = { ...exportOptions(), ...(runConfig.options || {}) };
    const testPresetEnabled = Boolean(options.testPresetEnabled || runConfig.presetId != null);
    if (testPresetEnabled) {
      try { requireRuntimePreset(runConfig.presetId ?? options.testPresetId); }
      catch (error) { setExportProgress(0, error.message); return; }
    }
    const videoTransitionOptions = getVideoTransitionOptions?.() || {};
    const defaultSourceStart = Number.isFinite(runConfig.sourceStart)
      ? Math.max(0, runConfig.sourceStart)
      : testPresetEnabled ? 0 : Math.max(0, Number(options.sourceStart) || 0);
    const requestedDuration = Number.isFinite(runConfig.durationSeconds)
      ? Math.min(Math.max(0.001, runConfig.durationSeconds), trackDuration - defaultSourceStart)
      : testPresetEnabled
        ? Math.min(30, trackDuration)
        : options.range === "test10"
          ? Math.min(10, trackDuration)
          : null;
    let sourceRange;
    let renderOptions;
    try {
      sourceRange = normalizeOfflineSourceRange({
        sourceStart: Number.isFinite(runConfig.sourceStart) ? runConfig.sourceStart : defaultSourceStart,
        sourceEnd: Number.isFinite(runConfig.sourceEnd)
          ? runConfig.sourceEnd
          : requestedDuration !== null
            ? defaultSourceStart + requestedDuration
            : Number(options.sourceEnd) > defaultSourceStart
              ? options.sourceEnd
              : trackDuration,
        sourceDuration: trackDuration
      });
      // Keep this normalized result, rather than merely using it as a guard:
      // a direct bridge/run-config request for Spotify Canvas must propagate
      // its silent-audio semantics all the way to native encoding.
      options = {
        ...options,
        ...validateExportCapabilities({ ...options, duration: sourceRange.duration })
      };
      validateExportRenderSize(getGl?.(), options);
      renderOptions = enforceRuntimeOptions({
        ...options,
        ...videoTransitionOptions,
        useVideoTransitions: testPresetEnabled ? false : videoTransitionOptions.useVideoTransitions
      });
    } catch (error) {
      setExportProgress(0, exportErrorMessage(error, "Selected export range or render size is not supported."));
      return;
    }
    const duration = sourceRange.duration;
    const includeAudio = options.includeAudio !== false;
    if (includeAudio && !currentNativeTrackId()) {
      setExportProgress(0, "Please load the track through the app picker so the native encoder can mux the selected audio range.");
      return;
    }
    const totalFrames = Math.max(1, Math.ceil(duration * options.fps));
    let startPreset = normalizePresetId(
      testPresetEnabled ? (runConfig.presetId ?? options.testPresetId) : getActivePreset()
    );

    exportState.active = true;
    exportState.savedPath = "";
    exportState.cancelRequested = false;
    exportState.startedAt = performanceNow();
    exportState.previousQuality = getQuality();
    exportState.previousTime = audio.currentTime || 0;
    exportState.wasPlaying = !audio.paused;
    documentBody.classList.add("exporting-video");
    ui.startExportVideo.disabled = true;
    ui.closeExportDialog.disabled = false; // Native close protection offers safe cancellation.
    ui.cancelExportVideo.classList.remove("hidden");
    ui.launchExportedVideo.classList.add("hidden");
    audio.pause();

    const previousPreset = getActivePreset();
    const previousTransition = { ...getTransition() };
    const previousRenderMode = getRenderMode();
    const previousWaveformProgress = getWaveformProgress();
    const previousReadIndex = getReadIndex();

    try {
      setExportProgress(
        0,
        testPresetEnabled
          ? `Preparing ${Math.round(duration)}-second single-preset test...`
          : "Preparing offline visual timeline..."
      );
      await waitForVisualsReady();
      await waitForAnalysisReady();
      const sourceAnalysisTimeline = getAnalysisTimeline?.() || null;
      const clipPlan = buildClipPlan({ options, sourceRange, trackDuration, duration, startPreset, testPresetEnabled, sourceAnalysisTimeline });
      const offlineTimeline = clipPlan.timeline || [];
      requireRuntimePreset(clipPlan.startPreset ?? startPreset);
      for (const item of offlineTimeline) { requireRuntimePreset(item.from); requireRuntimePreset(item.to); }
      startPreset = normalizePresetId(clipPlan.startPreset ?? startPreset);
      if (!testPresetEnabled) {
        await offlineVideoTransitionCompositor?.prepareTimeline(offlineTimeline, renderOptions);
      }
      const videoTransitionCount = offlineTimeline.filter((transition) => transition.videoTransition).length;
      if (renderOptions.useVideoTransitions) {
        setExportProgress(
          0,
          `Preparing offline encoder... ${videoTransitionCount}/${offlineTimeline.length} video transitions assigned.`
        );
      }
      if (exportState.cancelRequested) throw new Error("Export cancelled");
      await beginNativeEncoding(
        options,
        duration,
        totalFrames,
        sourceRange.sourceStart,
        sourceRange.sourceEnd,
        includeAudio
      );

      setRenderMode(renderModeOfflineExport);
      setQuality(1);
      ui.highMode.classList.add("active");
      ui.standardMode.classList.remove("active");
      setExportResolutionOverride(exportRenderDimensions(options));
      resize();
      clearFeedbackBuffers();
      setReadIndex(0);
      const firstRenderTime = clipPlan.renderTimeAt?.(0) ?? 0;
      // Bounded hidden preparation is only used for Match Full Music Video.
      // It warms feedback-dependent presets from the immediately preceding
      // source second without adding a frame to the MP4 or traversing the
      // unused portion of a long track.
      const hiddenPreparationSeconds = clipPlan.clipBehaviour === "match-full-video"
        ? Math.min(1, Math.max(0, firstRenderTime))
        : 0;
      const hiddenPreparationStart = Math.max(0, firstRenderTime - hiddenPreparationSeconds);
      prepareOfflineAudioState?.({
        analysisTimeline: clipPlan.analysisTimeline || sourceAnalysisTimeline,
        startTime: hiddenPreparationStart,
        duration: clipPlan.renderDuration || duration,
        // The match-full path retains source-time visual clocks. Prime only
        // the inexpensive audio smoothing state before any bounded hidden
        // visual warmup.
        historySeconds: clipPlan.clipBehaviour === "match-full-video"
          ? Math.min(12, hiddenPreparationStart)
          : 0,
        fps: options.fps
      });
      if (hiddenPreparationSeconds > 0) {
        const hiddenFrames = Math.min(60, Math.ceil(hiddenPreparationSeconds * options.fps));
        setExportProgress(0, "Priming the selected visual state...");
        for (let hiddenIndex = 0; hiddenIndex < hiddenFrames; hiddenIndex += 1) {
          if (exportState.cancelRequested) throw new Error("Export cancelled");
          const hiddenTime = Math.min(firstRenderTime, hiddenPreparationStart + hiddenIndex / options.fps);
          await renderOfflineFrameAt(
            hiddenTime,
            clipPlan.renderDuration || duration,
            options,
            offlineTimeline,
            startPreset,
            { analysisTimeline: clipPlan.analysisTimeline || sourceAnalysisTimeline, presetStart: clipPlan.presetStart || 0 }
          );
          if (hiddenIndex % 12 === 0) await new Promise((resolve) => window.setTimeout(resolve, 0));
        }
      }
      setExportProgress(0, `${exportRenderSizeLabel(options, getActualRenderSize?.())}.${exportSupersamplingWarning(options)}`);
      await new Promise((resolve) => window.setTimeout(resolve, 0));

      for (let frameIndex = 0; frameIndex < totalFrames; frameIndex += 1) {
        if (exportState.cancelRequested) throw new Error("Export cancelled");
        const videoTimeSeconds = Math.min(duration, frameIndex / options.fps);
        const renderTimeSeconds = clipPlan.renderTimeAt?.(videoTimeSeconds) ?? videoTimeSeconds;
        const timelineTimeSeconds = clipPlan.timelineTimeAtOutputTime?.(videoTimeSeconds) ?? renderTimeSeconds;
        const offlineFrameState = await renderOfflineFrameAt(
          renderTimeSeconds,
          clipPlan.renderDuration || duration,
          options,
          offlineTimeline,
          startPreset,
          { analysisTimeline: clipPlan.analysisTimeline || sourceAnalysisTimeline, presetStart: clipPlan.presetStart || 0, sourceTime: sourceRange.sourceStart + videoTimeSeconds }
        ) || {};
        const activeVideoTransition = offlineVideoTransitionCompositor?.activeTransitionAt(offlineTimeline, timelineTimeSeconds);
        const transitionOverlay = activeVideoTransition
          ? await offlineVideoTransitionCompositor.overlayPayload(activeVideoTransition, timelineTimeSeconds, renderOptions)
          : null;
        const videoBackgroundOverlay = offlineFrameState.videoBackgroundState?.active ? offlineFrameState.videoBackgroundState : null;
        const encodedFrame = canvasEncodedFrame
          ? await canvasEncodedFrame(options, null, videoBackgroundOverlay ? "png" : "jpeg")
          : { base64: await canvasFrameBase64(options), imageType: "jpeg" };
        const diagnostic = typeof window.__offlineExportDiagnostics === "function" && frameIndex % 30 === 0;
        if (exportState.cancelRequested) throw new Error("Export cancelled");
        const accepted = await appendNativeFrame(frameIndex, videoTimeSeconds, { ...encodedFrame, diagnostic }, transitionOverlay, videoBackgroundOverlay);
        if (diagnostic) {
          let hash = 2166136261;
          for (const char of encodedFrame.base64) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619) >>> 0;
          window.__offlineExportDiagnostics({ frameIndex, outputTime: videoTimeSeconds,
            sourceTime: sourceRange.sourceStart + videoTimeSeconds, renderTime: renderTimeSeconds,
            ...offlineFrameState.diagnostics, transitionOverlay, captureHash: hash,
            native: accepted?.diagnostics, submitted: true });
        }
        if (frameIndex % 3 === 0 || frameIndex === totalFrames - 1) {
          updateProgress(frameIndex, totalFrames, duration, options.fps, runConfig.progressPrefix || "", options);
          await new Promise((resolve) => window.setTimeout(resolve, 0));
        }
      }

      setExportProgress(
        99,
        !includeAudio
          ? "Finalizing silent Spotify Canvas MP4..."
          : options.audioFormat === "original"
          ? "Muxing original audio into the MP4..."
          : `Encoding AAC audio at ${options.audioBitrateKbps || 256} kbps...`
      );
      if (exportState.cancelRequested) throw new Error("Export cancelled");
      await finishNativeEncoding();
      setExportProgress(100, runConfig.completeMessage || "Music video export complete.");
      ui.launchExportedVideo.classList.toggle("hidden", !exportState.savedPath);
      return { success: true, path: exportState.savedPath };
    } catch (error) {
      console.error(error);
      if (exportState.cancelRequested) {
        setExportProgress(0, "Export cancelled.");
      } else {
        currentNativeApp()?.postMessage({ command: "cancelOfflineExport" });
        setExportProgress(0, `Export failed: ${exportErrorMessage(error)}`);
      }
      return { success: false, cancelled: exportState.cancelRequested, error };
    } finally {
      setRenderMode(previousRenderMode);
      setOfflineRenderClock(null);
      setFeedbackStep(1);
      resetFeedbackStepTiming();
      resetOfflineVideoBackgroundState?.();
      setExportResolutionOverride(null);
      setQuality(exportState.previousQuality);
      setActivePreset(previousPreset);
      ui.presetSelect.value = String(getActivePreset());
      setTransition(previousTransition);
      offlineVideoTransitionCompositor?.reset?.();
      setWaveformProgress(previousWaveformProgress);
      setReadIndex(previousReadIndex);
      resetLookaheadState();
      resize();
      drawWaveform();
      if (Number.isFinite(exportState.previousTime)) audio.currentTime = Math.min(exportState.previousTime, trackDuration);
      if (exportState.wasPlaying) playPlayerAudioWithFade().catch(console.error);
      ui.highMode.classList.toggle("active", getQuality() > 0.5);
      ui.standardMode.classList.toggle("active", getQuality() <= 0.5);
      exportState.active = false;
      exportState.cancelRequested = false;
      documentBody.classList.remove("exporting-video");
      ui.startExportVideo.disabled = false;
      ui.closeExportDialog.disabled = false;
      ui.cancelExportVideo.classList.add("hidden");
    }
  }

  // Export Studio preview: renders small frames with the export renderer and
  // plan, in this window, without touching the visualiser window. Live state is
  // saved on begin and restored on end, exactly as an export does.
  let previewRuntimeTimer = 0;
  // State each open preview session restores when it ends.
  const openPreviewStates = new Set();
  // A preset chosen while a preview session is open is the one to restore afterwards.
  function notePresetSelected(presetId) {
    for (const state of openPreviewStates) state.preset = presetId;
  }
  async function beginPreview({ maxWidth = 640 } = {}) {
    if (exportState.active) return null;
    clearTimeout(previewRuntimeTimer);
    const audio = ensurePlayer();
    const trackDuration = playerDuration();
    if (!audio?.src || !Number.isFinite(trackDuration) || trackDuration <= 0) return null;
    await waitForVisualsReady();
    await waitForAnalysisReady();
    if (exportState.active) return null;
    const options = { ...exportOptions() };
    const scale = Math.min(1, maxWidth / Math.max(options.width, options.height * 0.5625));
    const width = Math.max(2, Math.round((options.width * scale) / 2) * 2);
    const height = Math.max(2, Math.round((options.height * scale) / 2) * 2);
    const previewOptions = { ...options, width, height, renderWidth: width, renderHeight: height, supersampling: 1 };
    // Custom Timeline previews the whole authored timeline (playback and seeking may go
    // outside the export range); Automatic clips preview the clip plan they export.
    const selected = !isTimelineMode?.() && options.range === "selected" && options.sourceEnd > options.sourceStart;
    const sourceRange = normalizeOfflineSourceRange({
      sourceStart: selected ? options.sourceStart : 0,
      sourceEnd: selected ? options.sourceEnd : trackDuration,
      sourceDuration: trackDuration
    });
    const sourceAnalysisTimeline = getAnalysisTimeline?.() || null;
    const initialPreset = normalizePresetId(getActivePreset());
    const clipPlan = buildClipPlan({ options, sourceRange, trackDuration, duration: sourceRange.duration, startPreset: initialPreset, sourceAnalysisTimeline });
    const timeline = clipPlan.timeline || [];
    requireRuntimePreset(clipPlan.startPreset ?? initialPreset);
    for (const item of timeline) { requireRuntimePreset(item.from); requireRuntimePreset(item.to); }
    const startPreset = normalizePresetId(clipPlan.startPreset ?? initialPreset);
    const analysisTimeline = clipPlan.analysisTimeline || sourceAnalysisTimeline;
    const renderDuration = clipPlan.renderDuration || sourceRange.duration;
    // Video-clip transitions are composited over the frame by the native encoder in an
    // export; the preview draws the same overlay (path, clip time, opacity) itself.
    const previewRenderOptions = { ...previewOptions, ...(getVideoTransitionOptions?.() || {}) };
    try { await offlineVideoTransitionCompositor?.prepareTimeline(timeline, previewRenderOptions); } catch (error) { console.warn("Preview video transitions:", error); }
    if (exportState.active) return null;
    const previous = {
      preset: getActivePreset(),
      transition: { ...getTransition() },
      renderMode: getRenderMode(),
      waveformProgress: getWaveformProgress(),
      readIndex: getReadIndex(),
      quality: getQuality()
    };
    openPreviewStates.add(previous);
    // Same page mode as an export: video-driven presets keep their own <video>
    // element hidden instead of showing it over the controller window.
    documentBody.classList.add("exporting-video");
    setRenderMode(renderModeOfflineExport);
    setQuality(1);
    setExportResolutionOverride({ width, height });
    resize();
    clearFeedbackBuffers();
    setReadIndex(0);
    prepareOfflineAudioState?.({ analysisTimeline, startTime: clipPlan.renderTimeAt?.(0) ?? 0, duration: renderDuration, historySeconds: 0, fps: 30 });
    const frameCanvas = document.createElement("canvas");
    frameCanvas.width = width;
    frameCanvas.height = height;
    let ended = false;
    return {
      width,
      height,
      sourceStart: sourceRange.sourceStart,
      sourceEnd: sourceRange.sourceEnd,
      async renderAt(sourceTime) {
        if (ended || exportState.active) return null;
        const outputTime = Math.max(0, Math.min(sourceRange.duration, Number(sourceTime) - sourceRange.sourceStart));
        const renderTime = clipPlan.renderTimeAt?.(outputTime) ?? outputTime;
        const state = await renderOfflineFrameAt(renderTime, renderDuration, previewOptions, timeline, startPreset, { analysisTimeline, presetStart: clipPlan.presetStart || 0, sourceTime: sourceRange.sourceStart + outputTime }) || {};
        if (ended) return null;
        // Copy straight away: the WebGL buffer is not preserved between frames.
        getGl?.()?.finish?.();
        const ctx = frameCanvas.getContext("2d");
        ctx.clearRect(0, 0, width, height);
        const glCanvas = getCanvas?.();
        if (glCanvas) drawExportFraming(ctx, glCanvas, previewOptions);
        const timelineTime = clipPlan.timelineTimeAtOutputTime?.(outputTime) ?? renderTime;
        const activeVideoTransition = offlineVideoTransitionCompositor?.activeTransitionAt(timeline, timelineTime);
        let transitionOverlay = null;
        try {
          transitionOverlay = activeVideoTransition ? await offlineVideoTransitionCompositor.overlayPayload(activeVideoTransition, timelineTime, previewRenderOptions) : null;
        } catch {}
        return { image: frameCanvas, videoBackground: state.videoBackgroundState?.active ? state.videoBackgroundState : null, transitionOverlay, outputTime };
      },
      end() {
        if (ended) return;
        ended = true;
        openPreviewStates.delete(previous);
        setRenderMode(previous.renderMode);
        setOfflineRenderClock(null);
        setFeedbackStep(1);
        resetFeedbackStepTiming();
        resetOfflineVideoBackgroundState?.();
        setExportResolutionOverride(null);
        setQuality(previous.quality);
        setActivePreset(previous.preset);
        if (ui.presetSelect) ui.presetSelect.value = String(getActivePreset());
        setTransition(previous.transition);
        offlineVideoTransitionCompositor?.reset?.();
        setWaveformProgress(previous.waveformProgress);
        setReadIndex(previous.readIndex);
        resetLookaheadState();
        // Preset runtimes started for preview frames (video, particles) would otherwise
        // keep running in this window, which does not render. Stop them once the preview
        // has been idle for a while, so consecutive stills do not reload their assets.
        clearTimeout(previewRuntimeTimer);
        previewRuntimeTimer = setTimeout(() => { if (!exportState.active) stopPresetRuntimes(previous.preset); }, 20000);
        if (!exportState.active) documentBody.classList.remove("exporting-video");
        resize();
      }
    };
  }

  return { start, beginPreview, notePresetSelected };
}
