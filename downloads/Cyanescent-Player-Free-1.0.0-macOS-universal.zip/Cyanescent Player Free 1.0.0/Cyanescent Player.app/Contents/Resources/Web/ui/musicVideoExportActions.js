import { createMusicVideoExporter } from "./offlineExportRuntime.js";

export function createMusicVideoExportActions({
  ui,
  exportState,
  exportDialog,
  offlineExportController,
  playerDuration,
  currentTrack,
  ensurePlayer,
  nativeAppBridge,
  normalizePresetId,
  getActivePreset,
  setActivePreset,
  getTransition,
  setTransition,
  getRenderMode,
  setRenderMode,
  getWaveformProgress,
  setWaveformProgress,
  getReadIndex,
  setReadIndex,
  getQuality,
  setQuality,
  setOfflineRenderClock,
  setFeedbackStep,
  resetFeedbackStepTiming,
  setExportResolutionOverride,
  getGl,
  getActualRenderSize,
  resize,
  clearFeedbackBuffers,
  resetLookaheadState,
  drawWaveform,
  offlineFrameCapture,
  offlineVideoTransitionCompositor,
  getVideoTransitionOptions,
  playPlayerAudioWithFade,
  renderModeOfflineExport,
  resetOfflineVideoBackgroundState,
  getAnalysisTimeline,
  isTimelineMode,
  getCanvas,
  stopPresetRuntimes,
  builtInPresets = []
} = {}) {
  let batchActive = false;

  function cancel() {
    if (batchActive) exportState.batchCancelRequested = true;
    if (exportState.nativeCancellationPending) return exportState.nativeCancellationPending;
    if (!exportState?.active) return Promise.resolve();
    exportState.nativeCancellationPending = new Promise(resolve => {
      window.__nativeExportCancellationComplete = () => {
        exportState.nativeCancellationPending = null;
        resolve();
      };
    });
    exportState.cancelRequested = true;
    nativeAppBridge?.()?.postMessage({ command: "cancelOfflineExport" });
    exportDialog?.setProgress(ui?.exportProgress?.value, "Cancelling export...");
    return exportState.nativeCancellationPending;
  }

  function exporter() {
    const exporter = createMusicVideoExporter({
      ui,
      exportState,
      waitForVisualsReady: offlineExportController.waitForVisualsReady,
      waitForAnalysisReady: offlineExportController.waitForAnalysisReady,
      playerDuration,
      currentTrack,
      ensurePlayer,
      nativeAppBridge,
      updateExportFileNameExtension: exportDialog.updateFileNameExtension,
      selectedExportPath: exportDialog.selectedPath,
      chooseExportLocation: exportDialog.chooseLocation,
      exportOptions: exportDialog.exportOptions,
      normalizePresetId,
      getActivePreset,
      setActivePreset,
      getTransition,
      setTransition,
      getRenderMode,
      setRenderMode,
      getWaveformProgress,
      setWaveformProgress,
      getReadIndex,
      setReadIndex,
      getQuality,
      setQuality,
      setOfflineRenderClock,
      setFeedbackStep,
      resetFeedbackStepTiming,
      setExportResolutionOverride,
      getGl,
      getActualRenderSize,
      resize,
      clearFeedbackBuffers,
      resetLookaheadState,
      drawWaveform,
      setExportProgress: exportDialog.setProgress,
      buildOfflinePresetTimeline: offlineExportController.buildOfflinePresetTimeline,
      renderOfflineFrameAt: offlineExportController.renderOfflineFrameAt,
      prepareOfflineAudioState: offlineExportController.prepareOfflineAudioState,
      getAnalysisTimeline,
      isTimelineMode,
      canvasFrameBase64: offlineFrameCapture.captureBase64,
      canvasEncodedFrame: offlineFrameCapture.captureEncoded,
      offlineVideoTransitionCompositor,
      getVideoTransitionOptions,
      playPlayerAudioWithFade,
      renderModeOfflineExport,
      resetOfflineVideoBackgroundState,
      getCanvas,
      stopPresetRuntimes
    });
    return exporter;
  }

  // Preview sessions share one instance: it tracks open sessions and the idle
  // timer that stops preset runtimes started for preview frames.
  let previewExporter = null;
  function previewer() {
    previewExporter ||= exporter();
    return previewExporter;
  }

  async function start() {
    return exporter().start();
  }

  async function startPresetTestBatch({ outputDirectory } = {}) {
    if (batchActive || exportState.active) return;
    if (!outputDirectory) throw new Error("No preset-test output folder was selected.");
    const presets = builtInPresets.filter((preset) => Number.isFinite(Number(preset.id)));
    if (!presets.length) throw new Error("No built-in presets are available for testing.");
    batchActive = true;
    exportState.batchCancelRequested = false;
    const previousOutputPath = exportState.outputPath;
    const previousOutputDisplay = ui.exportOutputPath?.value || "";
    ui.exportPresetTestBatch.disabled = true;
    ui.startExportVideo.disabled = true;
    ui.cancelExportVideo.classList.remove("hidden");
    let completed = 0;
    try {
      for (let index = 0; index < presets.length; index += 1) {
        if (exportState.batchCancelRequested) break;
        const preset = presets[index];
        const safeName = String(preset.name || `Preset ${preset.id}`).replace(/[/:\\]/g, "-");
        const outputPath = `${outputDirectory}/${String(preset.id).padStart(3, "0")} - ${safeName}.mp4`;
        exportDialog?.setProgress(0, `[${index + 1}/${presets.length}] Preparing ${preset.name}...`);
        const result = await exporter().start({
          outputPath,
          presetId: Number(preset.id),
          durationSeconds: 15,
          progressPrefix: `[${index + 1}/${presets.length}] ${preset.name}: `,
          completeMessage: `[${index + 1}/${presets.length}] Completed ${preset.name}.`,
          options: {
            width: 1280,
            height: 720,
            // Diagnostics are deliberately independent from the current
            // platform preset (for example, a selected Spotify Canvas).
            destinationId: "custom",
            includeAudio: true,
            renderWidth: 1280,
            renderHeight: 720,
            fps: 30,
            codec: "h264",
            bitrate: 8_000_000,
            bitrateMbps: 8,
            supersampling: 1,
            jpegQuality: 0.80,
            testPresetEnabled: true,
            testPresetId: Number(preset.id)
          }
        });
        if (!result?.success) {
          if (result?.cancelled || exportState.batchCancelRequested) break;
          throw result?.error || new Error(`Export failed for ${preset.name}.`);
        }
        completed += 1;
      }
      if (exportState.batchCancelRequested) {
        exportDialog?.setProgress(0, `Preset test batch cancelled after ${completed}/${presets.length} videos.`);
      } else {
        exportDialog?.setProgress(100, `Preset test batch complete: ${completed} videos saved to ${outputDirectory}.`);
      }
    } finally {
      batchActive = false;
      exportState.batchCancelRequested = false;
      exportState.outputPath = previousOutputPath;
      if (ui.exportOutputPath) ui.exportOutputPath.value = previousOutputDisplay;
      ui.exportPresetTestBatch.disabled = false;
      ui.startExportVideo.disabled = false;
      ui.cancelExportVideo.classList.add("hidden");
    }
  }

  return {
    cancel,
    start,
    startPresetTestBatch,
    startDiagnostic: (config) => exporter().start(config),
    beginPreview: (options) => previewer().beginPreview(options),
    notePresetSelected: (presetId) => previewer().notePresetSelected(presetId)
  };
}
