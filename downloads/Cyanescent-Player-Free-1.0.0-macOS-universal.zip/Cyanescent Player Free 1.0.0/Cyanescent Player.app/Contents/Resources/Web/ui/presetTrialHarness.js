import { STINKHORN_ID } from '../engine/stinkhornField.js';
import { clamp01 } from "../utils/math.js";
import { APOLLONIAN_PHYSARUM_GENESIS_ID } from "../engine/forgeHybridAsset.js";
import { DUOVERSE_HD_ID } from "../engine/duoverseAsset.js";
import { NEWTON_BASIN_DESCENT_ID } from "../engine/newtonBasinAsset.js";
import { NEWTONS_LAW_ID } from "../engine/newtonLawAsset.js";
import { ARTIFICIAL_CONSCIOUSNESS_ID } from "../engine/artificialConsciousnessAsset.js";

import { HELIX_TUNNEL_ID } from "../engine/helixTunnelAsset.js";

export const PRESET_TRIAL_FIXTURES = [
  "steady", "kick-test", "frequency-band-sequence", "energy-ramp", "psytrance-test",
  "forge-140", "forge-145", "forge-150", "forge-off", "forge-quiet", "forge-excitation", "forge-compare", "forge-packets", "forge-align", "forge-video-only", "forge-braids", "forge-braids-only", "forge-braids-compare",
  "forge-calligraphy", "forge-elements", "forge-elements-off", "forge-elements-switch", "forge-loop", "forge-callback-stall",
  "duo-align", "duo-generation", "duo-material", "duo-flow", "duo-junction", "duo-confidence", "duo-particles", "duo-off", "duo-loop", "duo-140", "duo-150",
  "newton-145", "newton-140", "newton-150", "newton-song", "newton-quiet", "newton-off", "newton-align", "newton-boundary", "newton-flow", "newton-iteration", "newton-depth", "newton-anchors", "newton-domain", "newton-hit", "newton-attach", "newton-emission", "newton-waves", "newton-particles", "newton-loop", "newton-seek",
  "law-145", "law-song", "law-quiet", "law-off", "law-regions", "law-normals", "law-depth", "law-filament", "law-proximity", "law-shadows", "law-lights", "law-emission", "law-hit", "law-seek", "law-loop",
  // Artificial Consciousness (preset 394): ac-<mode>[-t<seconds>]; the optional suffix seeks the video, e.g. ac-song-t38.
  "ac-145", "ac-song", "ac-quiet", "ac-off", "ac-network", "ac-waves", "ac-loop", "ac-still", "ac-stillnet",
  // Clifford Metamorphosis (preset 396): cm-song (arrangement with lookahead), cm-quiet, or cm-<tokens> on the
  // 145 BPM pattern, where tokens pin a still state: w<world>, e<eruption %>, a scene name, freeze, nodrops, off.
  "cm-song", "cm-quiet", "helix-song", "helix-transition", "helix-long-break", "helix-quiet", "helix-align", "helix-fields", "helix-flow", "helix-loop", "helix-high", "track-test"
];

// Effect and loop trials may seek the beauty timeline independently of the compact
// musical arrangement: forge-elements-t15 starts at video second 15, with the same
// quiet/build/release fixture and its genuine future-sample lookahead.
export const FORGE_ELEMENT_TRIAL_FIXTURE_RE = /^forge-(?:calligraphy|elements(?:-(?:off|switch))?|loop|callback-stall)(?:-t\d+(?:\.\d+)?)?$/;
export function isForgeElementTrialFixture(id) {
  return FORGE_ELEMENT_TRIAL_FIXTURE_RE.test(String(id || ""));
}
export function isForgeArrangementTrialFixture(id) {
  return id === "forge-braids" || id === "forge-braids-only" || id === "forge-braids-compare" || id === "forge-packets" || isForgeElementTrialFixture(id) || id.startsWith("helix-") && id !== "helix-quiet"
    || /^stinkhorn-(?!quiet|off|beauty|material|depth|network|paths|visibility|flow|crown|emission|track|export)/.test(id);
}

function pulse(phase, decay = 11) {
  return Math.exp(-Math.max(0, phase) * decay);
}

// This feeds the ordinary live-audio state (bands, features, music-aware
// values, and waveform data). It is not a second renderer or preset API.
export function samplePresetTrialFixture(id, seconds) {
  if (id === "track-test") throw new Error("track-test uses real player audio, not synthetic fixture samples");
  const t = Math.max(0, Number(seconds) || 0);
  if (id.startsWith('stinkhorn-')) {
    const mode = id.replace(/-t[\d.]+$/, '');
    if (mode.startsWith('stinkhorn-quiet')) return samplePresetTrialFixture('newton-quiet', t);
    if (mode === 'stinkhorn-song') return sampleNewtonSong(t);
    if (mode === 'stinkhorn-forecast') return sampleCliffordSong(t);
    if (mode === 'stinkhorn-140') return samplePresetTrialFixture('newton-140', t);
    if (mode === 'stinkhorn-150') return samplePresetTrialFixture('newton-150', t);
    return samplePresetTrialFixture('psytrance-test', t);
  }
  const acBase = id.startsWith("ac-") ? id.replace(/-t[\d.]+$/, "") : "";
  if (id === "steady") return { bpm: 120, beatPhase: (t * 2) % 1, kick: 0.08, bass: 0.42, mids: 0.36, highs: 0.28, level: 0.43, intensity: 0.42, section: "steady" };
  if (id === "helix-quiet" || id === "forge-quiet" || id === "newton-quiet" || id === "law-quiet" || acBase === "ac-quiet") return { bpm: 145, beatPhase: (t * 145 / 60) % 1, kick: 0.04, bass: 0.12, mids: 0.10, highs: 0.05, level: 0.10, intensity: 0.10, section: "quiet" };
  if (id === "kick-test") {
    const beatPhase = (t * 128 / 60) % 1; const kick = pulse(beatPhase, 13);
    return { bpm: 128, beatPhase, kick, bass: 0.32 + kick * 0.62, mids: 0.24 + (1 - beatPhase) * 0.13, highs: 0.22 + kick * 0.24, level: 0.38 + kick * 0.44, intensity: 0.72, section: "kick" };
  }
  if (id === "frequency-band-sequence") {
    const phase = Math.floor(t / 8) % 3; const beatPhase = (t * 2) % 1; const kick = pulse(beatPhase, 12) * 0.45;
    return { bpm: 120, beatPhase, kick, bass: phase === 0 ? 0.86 : 0.18, mids: phase === 1 ? 0.86 : 0.18, highs: phase === 2 ? 0.86 : 0.18, level: 0.48, intensity: 0.54, section: ["low", "mid", "high"][phase] };
  }
  if (id === "newton-song" || id === "law-song" || acBase === "ac-song") return sampleNewtonSong(t);
  if (id.startsWith("cm-song") || /^(ia|hg)-(.*-)?song(-|$)/.test(id)) return sampleCliffordSong(t);
  if (id.startsWith("cm-quiet")) return { bpm: 145, beatPhase: (t * 145 / 60) % 1, kick: 0.04, bass: 0.12, mids: 0.10, highs: 0.05, level: 0.10, intensity: 0.10, section: "quiet" };
  // A deliberately wrong/sticky forecast: a long breakdown must still move
  // after one brief anticipation, even if a strong section keeps being predicted.
  if (id === "helix-long-break") {
    if (t < 6 || t >= 40) return samplePresetTrialFixture("psytrance-test", t);
    const f = sampleForgeBraidSong(12.5);
    return { ...f, kick: .02, bass: .10, mids: .30, highs: .10, level: .20,
      intensity: .20, calm: .85, breakdown: 1, upcomingDrop: 1,
      nextPhraseSeconds: (8 - (t * f.bpm / 60) % 8) * 60 / f.bpm };
  }
  if (isForgeArrangementTrialFixture(id)) return sampleForgeBraidSong(t);
  if (id === "energy-ramp") {
    const ramp = clamp01(t / 18); const beatPhase = (t * 126 / 60) % 1; const kick = pulse(beatPhase, 12) * (0.24 + ramp * 0.72);
    return { bpm: 126, beatPhase, kick, bass: 0.16 + ramp * 0.7 + kick * 0.15, mids: 0.14 + ramp * 0.67, highs: 0.12 + ramp * 0.73, level: 0.16 + ramp * 0.78, intensity: ramp, section: ramp < 1 ? "ramp" : "hold" };
  }
  const bpm = id === "forge-140" || id === "duo-140" || id === "newton-140" ? 140 : id === "forge-150" || id === "duo-150" || id === "newton-150" ? 150 : 145;
  const beat = t * bpm / 60; const beatPhase = beat % 1; const barPhase = (beat / 4) % 1; const phrasePhase = (beat / 32) % 1; const kick = pulse(beatPhase, 15); const offbeat = Math.exp(-Math.abs(beatPhase - 0.5) * 15);
  const build = phrasePhase > 0.72 ? (phrasePhase - 0.72) / 0.28 : 0;
  const drop = phrasePhase < 0.07 ? 1 - phrasePhase / 0.07 : 0;
  return { bpm, beatPhase, kick, bass: clamp01(0.36 + kick * 0.52 + offbeat * 0.18), mids: clamp01(0.32 + offbeat * 0.26 + build * 0.24), highs: clamp01(0.28 + kick * 0.19 + (0.5 + 0.5 * Math.sin(t * 11.7)) * 0.2 + build * 0.22), level: clamp01(0.47 + kick * 0.29 + build * 0.16), intensity: clamp01(0.62 + build * 0.3 + drop * 0.12), section: drop > 0.2 ? "drop" : build > 0.1 ? "build" : barPhase < 0.18 ? "accent" : "drive", drop, build };
}

// A 32-bar psytrance-shaped arrangement at 145 BPM (52.97 s, then it repeats), so a trial can
// show how a preset changes when the music changes: breakdown (pads and sparse hats, no kick),
// build (accelerating snare roll, rising highs), drop, drive (kick on every beat, rolling
// offbeat bass, 16th hats), a second breakdown and a second drop.
function sampleNewtonSong(t) {
  const bpm = 145;
  const beat = t * bpm / 60;
  const songBeat = beat % 128;
  const bar = Math.floor(songBeat / 4);
  const beatPhase = beat % 1;
  const sixteenth = (beat * 4) % 1;
  const lfo = 0.5 + 0.5 * Math.sin(t * 0.9);
  const hatOpen = Math.exp(-Math.abs(beatPhase - 0.5) * 22);
  const hat16 = pulse(sixteenth, 26);
  let section = "drive", kick = 0, bass = 0.12, mids = 0.30, highs = 0.18, level = 0.30, intensity = 0.3;
  let build = 0, drop = 0, breakdown = 0, calm = 0, sectionChange = 0;
  if (bar < 8 || (bar >= 24 && bar < 28)) {
    section = "breakdown";
    breakdown = 1; calm = 0.7;
    mids = 0.46 + 0.14 * lfo;
    highs = 0.14 + 0.16 * pulse((beat * 2) % 1, 18);
    bass = 0.10 + 0.05 * lfo;
    level = 0.30 + 0.06 * lfo;
    intensity = 0.28;
  } else if (bar < 12) {
    section = "build";
    build = (songBeat - 32) / 16;
    const rate = build < 0.5 ? 2 : build < 0.8 ? 4 : 8;   // snare roll: 8ths, 16ths, 32nds
    const roll = pulse((beat * rate) % 1, 16);
    mids = 0.36 + 0.34 * build + 0.20 * roll;
    highs = 0.20 + 0.55 * build + 0.12 * roll;
    bass = 0.12 + 0.10 * build;
    level = 0.34 + 0.36 * build + 0.08 * roll;
    intensity = 0.40 + 0.45 * build;
  } else {
    section = "drive";
    const barsIn = bar >= 28 ? bar - 28 : bar - 12;
    drop = barsIn === 0 ? Math.max(0, 1 - songBeat % 4 / 1.5) : 0;
    kick = pulse(beatPhase, 15);
    // Rolling psy bass: three notes after every kick.
    const roll = beatPhase > 0.25 ? pulse((beatPhase - 0.25) * 4 % 1, 9) : 0;
    bass = clamp01(0.30 + kick * 0.58 + roll * 0.30);
    mids = clamp01(0.30 + 0.10 * Math.sin(beat * Math.PI / 8) + 0.10 * roll);
    highs = clamp01(0.26 + 0.24 * hat16 + 0.28 * hatOpen);
    level = clamp01(0.58 + kick * 0.28 + roll * 0.08);
    intensity = 0.82 + drop * 0.15;
    sectionChange = drop > 0.5 ? 1 : 0;
  }
  return { bpm, beatPhase, kick, bass, mids, highs, level, intensity, section, drop, build, breakdown, calm, sectionChange };
}

// The 32-bar song above with genuine lookahead: future samples of the same arrangement aggregated
// over the analysis windows (0.5/5/20 s), and section forecasts that rise over the last 5 s before
// the drops (bars 12 and 28), the build (bar 8) and the second breakdown (bar 24).
function sampleCliffordSong(t) {
  const bpm = 145;
  const current = sampleNewtonSong(t);
  const features = (sample) => ({
    energy: sample.level, bass: sample.bass, mid: sample.mids, treble: sample.highs,
    brightness: sample.mids * 0.45 + sample.highs * 0.55, density: sample.intensity,
    beatStrength: sample.kick, sectionProbability: sample.sectionChange || 0,
    maxEnergy: sample.level, maxSectionProbability: sample.sectionChange || 0, energyDelta: 0, brightnessDelta: 0
  });
  const present = features(current);
  const aggregate = (horizon) => {
    const result = { ...present };
    const keys = ["energy", "bass", "mid", "treble", "brightness", "density", "beatStrength"];
    for (const key of keys) result[key] = 0;
    for (let index = 1; index <= 20; index += 1) {
      const future = features(sampleNewtonSong(t + horizon * index / 20));
      for (const key of keys) result[key] += future[key] / 20;
      result.maxEnergy = Math.max(result.maxEnergy, future.energy);
      result.maxSectionProbability = Math.max(result.maxSectionProbability, future.sectionProbability);
    }
    result.energyDelta = result.energy - present.energy;
    result.brightnessDelta = result.brightness - present.brightness;
    return result;
  };
  const songBeat = (t * bpm / 60) % 128;
  const secondsTo = (bar) => ((bar * 4 - songBeat + 128) % 128) * 60 / bpm;
  const near = (bar) => { const s = secondsTo(bar); return s < 5 ? clamp01(1 - s / 5) : 0; };
  const medium = aggregate(5);
  return {
    ...current, futureEnergy: medium.energy, futureBrightness: medium.brightness, futureDensity: medium.density,
    energyTrend: clamp01(0.5 + medium.energyDelta), mainRiff: current.section === "drive" ? 0.86 : 0.1,
    upcomingDrop: Math.max(near(12), near(28)), upcomingBuild: near(8), upcomingBreakdown: Math.max(near(24), near(0)),
    nextPhraseSeconds: (16 - (t * bpm / 60) % 16) * 60 / bpm,
    lookahead: { ready: true, current: present, short: aggregate(0.5), medium, long: aggregate(20) }
  };
}

// A compact 16-bar arrangement for checking one effect across different musical
// states. Its lookahead comes from future samples of this same arrangement, so
// anticipation is observable before the kick/bass return at beat 32.
function sampleForgeBraidSong(t) {
  const bpm = 145;
  const beat = t * bpm / 60;
  const songBeat = beat % 64;
  function sampleAt(seconds) {
    const b = seconds * bpm / 60;
    const position = b % 64;
    const beatPhase = b % 1;
    const melodic = 0.5 + 0.5 * Math.sin(b * Math.PI / 4);
    if (position < 16) return {
      bpm, beatPhase, kick: 0.02, bass: 0.09 + melodic * 0.03,
      mids: 0.26 + melodic * 0.18, highs: 0.07 + pulse((b * 2) % 1, 18) * 0.07,
      level: 0.18 + melodic * 0.05, intensity: 0.18,
      section: "quiet", breakdown: 1, calm: 0.85, build: 0, drop: 0, sectionChange: 0
    };
    if (position < 32) {
      const build = (position - 16) / 16;
      const roll = pulse((b * (build < 0.5 ? 2 : 4)) % 1, 15);
      return {
        bpm, beatPhase, kick: 0.03, bass: 0.12 + build * 0.12,
        mids: 0.34 + build * 0.25 + roll * 0.12,
        highs: 0.17 + build * 0.42 + roll * 0.12,
        level: 0.30 + build * 0.32, intensity: 0.32 + build * 0.43,
        section: "anticipation", breakdown: 0, calm: 0.12, build, drop: 0, sectionChange: 0
      };
    }
    const kick = pulse(beatPhase, 15);
    const rollingBass = beatPhase > 0.25 ? pulse(((beatPhase - 0.25) * 4) % 1, 9) : 0;
    const drop = Math.max(0, 1 - (position - 32) / 3);
    return {
      bpm, beatPhase, kick,
      bass: clamp01(0.32 + kick * 0.50 + rollingBass * 0.24),
      mids: 0.38 + melodic * 0.17 + rollingBass * 0.10,
      highs: 0.23 + pulse((b * 4) % 1, 26) * 0.22 + pulse((beatPhase + 0.5) % 1, 18) * 0.16,
      level: clamp01(0.58 + kick * 0.25 + rollingBass * 0.08), intensity: 0.82 + drop * 0.12,
      section: "release", breakdown: 0, calm: 0, build: 0, drop, sectionChange: drop
    };
  }
  const current = sampleAt(t);
  function features(sample) {
    return {
      energy: sample.level, bass: sample.bass, mid: sample.mids, treble: sample.highs,
      brightness: sample.mids * 0.45 + sample.highs * 0.55, density: sample.intensity,
      beatStrength: sample.kick, sectionProbability: sample.sectionChange,
      maxEnergy: sample.level, maxSectionProbability: sample.sectionChange,
      energyDelta: 0, brightnessDelta: 0
    };
  }
  const present = features(current);
  function aggregate(horizon) {
    const result = features(sampleAt(t + horizon));
    const samples = 20;
    let energy = 0, bass = 0, mid = 0, treble = 0, brightness = 0, density = 0;
    for (let index = 1; index <= samples; index += 1) {
      const future = features(sampleAt(t + horizon * index / samples));
      energy += future.energy; bass += future.bass; mid += future.mid;
      treble += future.treble; brightness += future.brightness; density += future.density;
      result.maxEnergy = Math.max(result.maxEnergy, future.energy);
      result.maxSectionProbability = Math.max(result.maxSectionProbability, future.sectionProbability);
    }
    Object.assign(result, { energy: energy / samples, bass: bass / samples, mid: mid / samples,
      treble: treble / samples, brightness: brightness / samples, density: density / samples });
    result.energyDelta = result.energy - present.energy;
    result.brightnessDelta = result.brightness - present.brightness;
    return result;
  }
  const short = aggregate(0.5), medium = aggregate(5), long = aggregate(20);
  const toDropBeats = songBeat < 32 ? 32 - songBeat : 96 - songBeat;
  const toDropSeconds = toDropBeats * 60 / bpm;
  const upcomingDrop = toDropSeconds < 5 ? clamp01(1 - toDropSeconds / 5) : 0;
  return {
    ...current, futureEnergy: medium.energy, futureBrightness: medium.brightness,
    futureDensity: medium.density, energyTrend: clamp01(0.5 + medium.energyDelta),
    upcomingDrop, upcomingBuild: songBeat < 16 ? clamp01(1 - (16 - songBeat) / 12) : 0,
    upcomingBreakdown: songBeat >= 52 ? (songBeat - 52) / 12 : 0,
    nextPhraseSeconds: (8 - beat % 8) * 60 / bpm,
    mainRiff: current.section === "release" ? 0.88 : 0.10,
    lookahead: { ready: true, current: present, short, medium, long }
  };
}

export function createPresetTrialRuntime({
  fixtureId,
  startedAt = performance.now(),
  nativeApp = () => null,
  targetFps = 30,
  warmupPeriod = 1,
  startVideoCapture = () => false,
  stopVideoCapture = () => Promise.resolve(false),
  noteVideoFrame = () => {}
} = {}) {
  let frames = 0; let firstFrameAt = 0; let lastFrameAt = 0; let slowestFrameMs = 0; let readySent = false; let finished = false; let videoStartedAt = null;
  let arrangementReadyAt = 0;
  let lastPresetId = 0;
  let lastForgeDiagnostics = null;
  const forgeVideoTimes = [];
  let forgeLoopsObserved = 0;
  let forgeClockLagMax = 0;
  let forgeClockLagSamples = 0;
  const findings = [];
  function elapsed() {
    // Keep this short preview's quiet passage intact even when first-use
    // shader/asset preparation takes several seconds.
    if (isForgeArrangementTrialFixture(fixtureId) && !arrangementReadyAt) return 0;
    return Math.max(0, (performance.now() - (arrangementReadyAt || startedAt)) / 1000);
  }
  function sample() { return samplePresetTrialFixture(fixtureId, elapsed()); }
  function frame({ presetId, presetDisplayName, shaderState, canvasValid = false, contextLost = false } = {}) {
    const now = performance.now(); if (!firstFrameAt) firstFrameAt = now; if (lastFrameAt) slowestFrameMs = Math.max(slowestFrameMs, now - lastFrameAt); lastFrameAt = now; frames += 1;
    lastPresetId = Number(presetId) || 0;
    if (lastPresetId === APOLLONIAN_PHYSARUM_GENESIS_ID || lastPresetId === DUOVERSE_HD_ID || lastPresetId === NEWTON_BASIN_DESCENT_ID || lastPresetId === NEWTONS_LAW_ID || lastPresetId === ARTIFICIAL_CONSCIOUSNESS_ID || lastPresetId === HELIX_TUNNEL_ID || lastPresetId === STINKHORN_ID) {
      const diagnostic = lastPresetId === STINKHORN_ID ? window.__stinkhornDiagnostics
        : lastPresetId === HELIX_TUNNEL_ID ? window.__helixTunnelDiagnostics
        : lastPresetId === ARTIFICIAL_CONSCIOUSNESS_ID ? window.__artificialConsciousnessDiagnostics
        : lastPresetId === NEWTONS_LAW_ID ? window.__newtonsLawDiagnostics
        : lastPresetId === NEWTON_BASIN_DESCENT_ID ? window.__newtonBasinDiagnostics
        : lastPresetId === DUOVERSE_HD_ID ? window.__duoverseDiagnostics : window.__forgeHybridDiagnostics;
      if (diagnostic && diagnostic !== lastForgeDiagnostics) {
        lastForgeDiagnostics = diagnostic;
        // Beauty playback can continue while augmentation waits for a coherent
        // field pair. Track that progress independently from the field clock.
        if ((diagnostic.started || diagnostic.videoReady) && Number.isFinite(diagnostic.videoTime)) {
          if (lastPresetId === APOLLONIAN_PHYSARUM_GENESIS_ID) {
            const previousTime = forgeVideoTimes.at(-1);
            if (Number.isFinite(previousTime) && diagnostic.videoTime < previousTime - 2) forgeLoopsObserved += 1;
            if (diagnostic.fieldReady && diagnostic.frameCoherent !== false && Number.isFinite(diagnostic.displayedVideoTime)) {
              const lag = Math.abs(diagnostic.videoTime - diagnostic.displayedVideoTime);
              forgeClockLagMax = Math.max(forgeClockLagMax, lag);
              if (lag > 0.25 && !diagnostic.seeking) forgeClockLagSamples += 1;
            }
          }
          forgeVideoTimes.push(diagnostic.videoTime);
        }
      }
    }
    if (contextLost) findings.push({ severity: "error", code: "WEBGL_CONTEXT_LOST", message: "The WebGL context was lost during the trial." });
    if (!readySent && frames > 0 && shaderState !== "error" && presetDisplayName && canvasValid) {
      if (isForgeArrangementTrialFixture(fixtureId)) arrangementReadyAt = now;
      if (startVideoCapture()) videoStartedAt = elapsed();
      readySent = true;
      nativeApp()?.postMessage({ command: "presetTrialReady", presetId, presetDisplayName, shaderState, firstFrameSeconds: elapsed(), targetFps, warmupPeriod });
    }
    noteVideoFrame(videoStartedAt !== null ? Math.max(0, elapsed() - videoStartedAt) : 0);
    return frames;
  }
  function report() { const span = Math.max(0.001, (lastFrameAt - firstFrameAt) / 1000); nativeApp()?.postMessage({ command: "presetTrialMetrics", frameCount: frames, averageFps: frames / span, minimumFps: slowestFrameMs ? 1000 / slowestFrameMs : 0, findings }); }
  async function finish() {
    if (finished) return;
    finished = true;
    if ((lastPresetId === APOLLONIAN_PHYSARUM_GENESIS_ID || lastPresetId === DUOVERSE_HD_ID || lastPresetId === NEWTON_BASIN_DESCENT_ID || lastPresetId === NEWTONS_LAW_ID || lastPresetId === ARTIFICIAL_CONSCIOUSNESS_ID || lastPresetId === HELIX_TUNNEL_ID || lastPresetId === STINKHORN_ID) && elapsed() >= 5
      && !(lastPresetId === STINKHORN_ID && fixtureId.includes('-still'))
      && !(lastPresetId === HELIX_TUNNEL_ID && /^helix-still(?:-t\d+(?:\.\d+)?)?$/.test(fixtureId))) {
      const advanced = forgeVideoTimes.some((time, index) => index > 0 && Math.abs(time - forgeVideoTimes[index - 1]) > 0.25);
      if (!advanced) findings.push({ severity: "error", code: "FORGE_VIDEO_STALLED", message: "The Forge video did not advance during the native trial." });
    }
    if (lastPresetId === APOLLONIAN_PHYSARUM_GENESIS_ID) {
      if (forgeClockLagSamples > 1) findings.push({ severity: "error", code: "FORGE_FIELD_CLOCK_STALLED",
        message: `The displayed field clock disagreed with the playing video by up to ${forgeClockLagMax.toFixed(3)} seconds (${forgeClockLagSamples} sampled frames).` });
      if (/^forge-loop(?:-t\d+(?:\.\d+)?)?$/.test(fixtureId) && !forgeLoopsObserved && elapsed() >= 5) {
        findings.push({ severity: "error", code: "FORGE_LOOP_NOT_OBSERVED", message: "The requested natural video loop was not observed; the loop trial must run past the MP4 end." });
      }
    }
    await stopVideoCapture();
    const span = Math.max(0.001, (lastFrameAt - firstFrameAt) / 1000);
    nativeApp()?.postMessage({ command: "presetTrialFinished", frameCount: frames, averageFps: frames / span, minimumFps: slowestFrameMs ? 1000 / slowestFrameMs : 0, findings });
  }
  return { elapsed, sample, frame, report, finish, ready: () => readySent };
}
