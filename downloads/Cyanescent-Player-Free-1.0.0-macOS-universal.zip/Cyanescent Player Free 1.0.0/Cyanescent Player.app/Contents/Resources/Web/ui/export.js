import { editionConfig } from "../generated/editionConfig.js";
import {
  DEFAULT_DESTINATION_ID,
  EXPORT_DESTINATION_PRESETS,
  SAFE_AREA_GUIDES,
  exportDimensionError,
  normaliseExportOutput,
  validateExportCapabilities
} from "./exportCapabilities.js";

// Kept as an exported compatibility view for small diagnostic tools. New UI
// and validation read EXPORT_DESTINATION_PRESETS from exportCapabilities.js.
export const EXPORT_PRESETS = Object.freeze(Object.fromEntries(
  EXPORT_DESTINATION_PRESETS.map((preset) => [preset.id, {
    width: preset.width,
    height: preset.height,
    fps: preset.fps,
    bitrate: preset.bitrateMbps,
    label: preset.label
  }])
));

export { EXPORT_DESTINATION_PRESETS, SAFE_AREA_GUIDES };

export function exportExtensionForFormat() {
  return "mp4";
}

export function exportRenderDimensions(options) {
  if (Number.isFinite(options?.renderWidth) && Number.isFinite(options?.renderHeight)) {
    return {
      width: Math.max(2, Math.round(options.renderWidth)),
      height: Math.max(2, Math.round(options.renderHeight))
    };
  }
  const sample = exportSupersamplingFactor(options);
  return {
    width: Math.round(options.width * sample),
    height: Math.round(options.height * sample)
  };
}

export function exportSupersamplingFactor(options) {
  return Math.max(1, Math.min(4, Number(options?.supersampling) || 1));
}

export function exportRenderSizeLabel(options, actualSize = null) {
  const renderSize = exportRenderDimensions(options);
  const sample = exportSupersamplingFactor(options);
  const base = `Rendering ${renderSize.width}x${renderSize.height} -> ${options.width}x${options.height}${sample > 1 ? ` (${sample}x supersampling)` : ""}`;
  if (!actualSize) return base;
  return `${base}. Canvas ${actualSize.canvasWidth}x${actualSize.canvasHeight}; framebuffer ${actualSize.renderWidth}x${actualSize.renderHeight}`;
}

export function exportSupersamplingWarning(options) {
  return exportSupersamplingFactor(options) >= 4
    ? " Warning: 4x supersampling is extremely slow and memory-heavy."
    : "";
}

export function validateExportRenderSize(gl, options) {
  validateExportCapabilities(options);
  if (!gl) return;
  const renderSize = exportRenderDimensions(options);
  const maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE) || 0;
  const maxRenderbufferSize = gl.getParameter(gl.MAX_RENDERBUFFER_SIZE) || 0;
  const maxSize = Math.min(
    maxTextureSize || Number.POSITIVE_INFINITY,
    maxRenderbufferSize || Number.POSITIVE_INFINITY
  );
  if (Number.isFinite(maxSize) && (renderSize.width > maxSize || renderSize.height > maxSize)) {
    throw new Error(
      `Supersampled render size ${renderSize.width}x${renderSize.height} exceeds this GPU limit (${Math.floor(maxSize)}). Try a lower resolution or lower supersampling.`
    );
  }
}

export function validateEditionExportResolution(options, config = editionConfig) {
  const width = Math.max(2, Math.round(Number(options?.width) || 0));
  const height = Math.max(2, Math.round(Number(options?.height) || 0));
  const error = exportDimensionError({ width, height }, config);
  if (error) throw new Error(error);
  return { width, height };
}

export function sanitizeExportFileName(rawName, fallbackName, extension = exportExtensionForFormat()) {
  const raw = (rawName || `${fallbackName}.${extension}`).trim();
  const clean = raw.replace(/[/:\\]/g, "-") || `${fallbackName}.${extension}`;
  return clean.replace(/\.(mp4|webm|mov)$/i, `.${extension}`);
}

export function exportPathWithFileName(outputPath, fileName) {
  if (!outputPath) return "";
  const directory = outputPath.replace(/\/[^/]*$/, "");
  if (directory && directory !== outputPath) return `${directory}/${fileName}`;
  return outputPath.replace(/[^/]*$/, fileName);
}

export function formatExportTime(seconds) {
  const safe = Math.max(0, Number(seconds) || 0);
  const minutes = Math.floor(safe / 60);
  const wholeSeconds = Math.floor(safe % 60).toString().padStart(2, "0");
  return `${minutes}:${wholeSeconds}`;
}

export function bytesToBase64(bytes) {
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

export async function canvasFrameToBase64({ canvas, captureCanvas = null, options, overlay, imageType = "jpeg" }) {
  const outputType = imageType === "png" ? "png" : "jpeg";
  let nextCaptureCanvas = captureCanvas;
  let source = canvas;
  const framing = options?.framingMode || "adaptive";
  const needsCopy = Boolean(overlay)
    || framing !== "adaptive"
    || options.supersampling > 1
    || canvas.width !== options.width
    || canvas.height !== options.height;
  if (needsCopy) {
    if (!nextCaptureCanvas) nextCaptureCanvas = document.createElement("canvas");
    nextCaptureCanvas.width = options.width;
    nextCaptureCanvas.height = options.height;
    const ctx = nextCaptureCanvas.getContext("2d", { alpha: outputType === "png" });
    if (outputType !== "png") {
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, options.width, options.height);
    } else {
      ctx.clearRect(0, 0, options.width, options.height);
    }
    drawExportFraming(ctx, canvas, options);
    if (overlay) await overlay(ctx, options.width, options.height);
    source = nextCaptureCanvas;
  }
  const blob = await new Promise((resolve) => {
    if (source.toBlob) source.toBlob(resolve, outputType === "png" ? "image/png" : "image/jpeg", options.jpegQuality);
    else resolve(null);
  });
  if (blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    return { base64: bytesToBase64(bytes), captureCanvas: nextCaptureCanvas, imageType: outputType };
  }
  return {
    base64: source.toDataURL(outputType === "png" ? "image/png" : "image/jpeg", options.jpegQuality).split(",")[1] || "",
    captureCanvas: nextCaptureCanvas,
    imageType: outputType
  };
}

// The WebGL renderer already receives the output frame aspect ratio. These
// transforms provide predictable Fit/Fill/Manual behavior for all presets
// without per-preset shader changes, and are applied only to captured pixels.
export function drawExportFraming(ctx, source, options = {}) {
  const targetWidth = Math.max(2, Number(options.width) || source.width || 2);
  const targetHeight = Math.max(2, Number(options.height) || source.height || 2);
  const sourceWidth = Math.max(1, source.width || targetWidth);
  const sourceHeight = Math.max(1, source.height || targetHeight);
  const mode = options.framingMode || "adaptive";
  if (mode === "adaptive") {
    ctx.drawImage(source, 0, 0, targetWidth, targetHeight);
    return;
  }
  const fit = mode === "fit";
  const baseScale = fit
    ? Math.min(targetWidth / sourceWidth, targetHeight / sourceHeight)
    : Math.max(targetWidth / sourceWidth, targetHeight / sourceHeight);
  const zoom = mode === "manual" ? Math.max(0.5, Math.min(3, Number(options.framingZoom) || 1)) : 1;
  const drawWidth = sourceWidth * baseScale * zoom;
  const drawHeight = sourceHeight * baseScale * zoom;
  const offsetX = mode === "manual" ? Math.max(-1, Math.min(1, Number(options.framingPositionX) || 0)) : 0;
  const offsetY = mode === "manual" ? Math.max(-1, Math.min(1, Number(options.framingPositionY) || 0)) : 0;
  const x = (targetWidth - drawWidth) * 0.5 + offsetX * Math.max(0, (drawWidth - targetWidth) * 0.5);
  const y = (targetHeight - drawHeight) * 0.5 + offsetY * Math.max(0, (drawHeight - targetHeight) * 0.5);
  ctx.drawImage(source, x, y, drawWidth, drawHeight);
}

export function nativeTrackIdForExport(track) {
  if (!track) return "";
  return track.nativeId || (String(track.id || "").startsWith("web-") ? "" : track.id);
}

export function offlineExportProgressMessage({
  frameIndex,
  totalFrames,
  duration,
  fps,
  startedAt,
  now = performance.now()
}) {
  const done = frameIndex + 1;
  const elapsed = (now - startedAt) / 1000;
  const rate = done / Math.max(0.001, elapsed);
  const remaining = (totalFrames - done) / Math.max(0.001, rate);
  const timeSeconds = frameIndex / fps;
  return `Rendering frame ${done}/${totalFrames} at ${formatExportTime(timeSeconds)} / ${formatExportTime(duration)}. Elapsed ${formatExportTime(elapsed)}, ETA ${formatExportTime(remaining)}.`;
}

export function beginNativeOfflineExport({
  nativeApp,
  state,
  options,
  outputPath,
  audioTrackId,
  duration,
  totalFrames,
  sourceStart = 0,
  sourceEnd = duration,
  includeAudio = true
}) {
  if (!nativeApp) return Promise.reject(new Error("Music Video Mode requires the macOS app encoder."));
  return new Promise((resolve, reject) => {
    state.offlineBeginResolver = resolve;
    state.offlineBeginRejecter = reject;
    nativeApp.postMessage({
      command: "beginOfflineExport",
      path: outputPath,
      audioTrackId,
      width: options.width,
      height: options.height,
      fps: options.fps,
      codec: options.codec,
      bitrate: options.bitrate,
      audioFormat: options.audioFormat,
      audioBitrate: options.audioBitrate,
      sourceStart: Math.max(0, Number(sourceStart) || 0),
      sourceEnd: Math.max(0, Number(sourceEnd) || Number(duration) || 0),
      includeAudio: Boolean(includeAudio),
      duration,
      totalFrames
    });
  });
}

export function appendNativeOfflineFrame({
  nativeApp,
  state,
  frameIndex,
  timeSeconds,
  base64Jpeg,
  transitionOverlay = null,
  videoBackgroundOverlay = null,
  imageType = "jpeg",
  diagnostic = false
}) {
  return new Promise((resolve, reject) => {
    state.offlineFrameResolver = resolve;
    state.offlineFrameRejecter = reject;
    state.lastFrameIndex = frameIndex;
    nativeApp.postMessage({
      command: "appendOfflineExportFrame",
      diagnostic,
      frameIndex,
      timeSeconds,
      imageType,
      image: base64Jpeg,
      backgroundVideoPath: videoBackgroundOverlay?.primary?.path || "",
      backgroundVideoTime: videoBackgroundOverlay?.primary?.time || 0,
      backgroundVideoAlpha: videoBackgroundOverlay?.primary?.alpha || 0,
      backgroundVideoPathB: videoBackgroundOverlay?.secondary?.path || "",
      backgroundVideoTimeB: videoBackgroundOverlay?.secondary?.time || 0,
      backgroundVideoAlphaB: videoBackgroundOverlay?.secondary?.alpha || 0,
      transitionVideoPath: transitionOverlay?.path || "",
      transitionVideoTime: transitionOverlay?.time || 0,
      transitionVideoAlpha: transitionOverlay?.alpha || 0,
      transitionVideoId: transitionOverlay?.id || ""
    });
  });
}

export function finishNativeOfflineExport({ nativeApp, state }) {
  return new Promise((resolve, reject) => {
    state.offlineFinishResolver = resolve;
    state.offlineFinishRejecter = reject;
    nativeApp.postMessage({ command: "finishOfflineExport" });
  });
}

export function exportErrorMessage(error, fallback = "Unknown error") {
  if (typeof error === "string" && error.trim()) return error;
  if (error && typeof error === "object" && typeof error.message === "string" && error.message.trim()) {
    return error.message;
  }
  return fallback;
}

export function rejectPendingOfflineExport(state, message) {
  const error = new Error(exportErrorMessage(message, "Native export failed"));
  for (const key of ["offlineBeginRejecter", "offlineFrameRejecter", "offlineFinishRejecter"]) {
    if (state[key]) state[key](error);
    state[key] = null;
  }
  state.offlineBeginResolver = null;
  state.offlineFrameResolver = null;
  state.offlineFinishResolver = null;
}

export function registerNativeOfflineExportCallbacks({
  target = window,
  state,
  setProgress,
  currentProgressValue = () => 0
} = {}) {
  target.__offlineExportNativeReady = (payload) => {
    if (state.offlineBeginResolver) state.offlineBeginResolver(payload || {});
    state.offlineBeginResolver = null;
    state.offlineBeginRejecter = null;
  };

  target.__offlineExportFrameAccepted = (payload) => {
    if (state.offlineFrameResolver) state.offlineFrameResolver(payload || {});
    state.offlineFrameResolver = null;
    state.offlineFrameRejecter = null;
  };

  target.__offlineExportNativeProgress = (payload) => {
    if (!state.active || !payload) return;
    if (payload.message) setProgress?.(currentProgressValue(), payload.message);
  };

  target.__offlineExportNativeComplete = (payload) => {
    state.savedPath = payload?.path || state.outputPath || "";
    if (state.offlineFinishResolver) state.offlineFinishResolver(payload || {});
    state.offlineFinishResolver = null;
    state.offlineFinishRejecter = null;
  };

  target.__offlineExportNativeFailed = (payload) => {
    rejectPendingOfflineExport(state, payload?.error || "Native export failed");
  };
}

// The Export Studio owns one configuration object (web/ui/exportStudio.js);
// this turns it, plus the shared range model, into the options the offline
// export runtime and the native encoder consume.
export function exportOptionsFromUi(ui) {
  const fields = ui?.__exportStudio?.exportOptionsFields?.() || { destinationId: DEFAULT_DESTINATION_ID };
  const rangeState = ui?.__exportRangeModel?.get?.() || { mode: "full", start: 0, end: 0, duration: 0, valid: false };
  const bitrateMbps = Math.max(1, Number(fields.bitrateMbps) || 18);
  const audioBitrateKbps = [128, 192, 256, 320].includes(Number(fields.audioBitrateKbps)) ? Number(fields.audioBitrateKbps) : 256;
  const supersampling = Math.max(1, Math.min(4, Number(fields.supersampling) || 1));
  const normalized = normaliseExportOutput({
    destinationId: fields.destinationId,
    width: fields.width,
    height: fields.height,
    fps: fields.fps,
    bitrateMbps,
    includeAudio: fields.includeAudio !== false
  });
  return {
    ...normalized,
    renderWidth: Math.round(normalized.width * supersampling),
    renderHeight: Math.round(normalized.height * supersampling),
    codec: fields.codec === "h265" ? "h265" : "h264",
    range: rangeState.mode || "full",
    sourceStart: Number(rangeState.start) || 0,
    sourceEnd: Number(rangeState.end) || 0,
    duration: Number(rangeState.duration) || 0,
    testPresetEnabled: false,
    testPresetId: null,
    bitrate: Math.round(bitrateMbps * 1000000),
    bitrateMbps,
    audioFormat: fields.audioFormat === "original" ? "original" : "aac",
    audioBitrate: audioBitrateKbps * 1000,
    audioBitrateKbps,
    supersampling,
    motionBlur: 0,
    jpegQuality: Math.max(0.72, Math.min(0.96, 0.76 + bitrateMbps / 240)),
    framingMode: fields.framingMode || "adaptive",
    framingPositionX: Math.max(-1, Math.min(1, Number(fields.framingPositionX) || 0)),
    framingPositionY: Math.max(-1, Math.min(1, Number(fields.framingPositionY) || 0)),
    framingZoom: Math.max(0.5, Math.min(3, Number(fields.framingZoom) || 1)),
    safeAreaGuide: fields.safeAreaGuide || "none",
    autoClipBehaviour: fields.autoClipBehaviour || "standalone",
    renderedTransitionDuration: fields.renderedTransitionDuration ?? 2.6,
    loopPreview: false
  };
}
