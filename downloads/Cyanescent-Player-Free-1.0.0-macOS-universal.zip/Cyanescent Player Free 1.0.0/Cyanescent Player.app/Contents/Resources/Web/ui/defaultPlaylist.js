// Store playlist identities, so renaming a playlist preserves the startup choice.
export function bindDefaultPlaylist({ select, store, options, save }) {
  if (!select || !store) return () => {};
  function render() {
    select.replaceChildren(...store.state.playlists.map(playlist => {
      const option = document.createElement('option');
      option.value = playlist.id;
      option.textContent = playlist.name;
      return option;
    }));
    select.value = store.playlist(options.defaultPlaylistId)?.id || store.state.selectedPlaylistId;
  }
  select.addEventListener('change', () => {
    if (!store.playlist(select.value)) return;
    options.defaultPlaylistId = select.value;
    save();
  });
  store.subscribe((_state, operation) => {
    if (operation === 'remove' && !store.playlist(options.defaultPlaylistId)) {
      options.defaultPlaylistId = store.state.selectedPlaylistId;
      save();
    }
    render();
  });
  render();
  return render;
}
