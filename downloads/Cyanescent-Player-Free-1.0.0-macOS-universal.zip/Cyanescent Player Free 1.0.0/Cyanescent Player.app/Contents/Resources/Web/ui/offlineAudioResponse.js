import { createAudioBands, createAudioFeatureState, smoothAudioBands, updateSlowAudioBands,
  updateAudioFeatureState } from "../audio/liveAudioState.js";
import { createMusicAwareState, computeMusicAwareState } from "../audio/musicAware.js";

// Replay the existing live envelopes on audio time, independent of encoding
// speed, export FPS, preview seeks or the live transport's previous state.
// Native and browser visual-output state pumps both update audio at 30 Hz.
const RATE = 30;
const caches = new WeakMap();
const clone = (s) => ({ ...s, smooth: { ...s.smooth }, features: { ...s.features }, music: { ...s.music } });
const initial = () => ({ smooth: createAudioBands(), features: createAudioFeatureState(1000),
  music: createMusicAwareState(), slowLevel: 0, slowBass: 0, wavePhase: 0, orbitPhase: 0, orbitEnergy: 0 });

export function sampleOfflineAudioResponse(timeline, time, targetsAt) {
  const t = Math.max(0, Number(time) || 0);
  // No analysis means there is no stable owner for a cache. This path is used
  // only by analysis-unavailable previews, never a successfully analysed track.
  const owner = timeline && typeof timeline === "object" ? timeline : targetsAt;
  let cache = caches.get(owner);
  if (!cache || cache.frames !== timeline?.frames || cache.sections !== timeline?.sections
    || cache.drops !== timeline?.drops) {
    cache = { tick: -1, state: initial(), checkpoints: [],
      frames: timeline?.frames, sections: timeline?.sections, drops: timeline?.drops };
    caches.set(owner, cache);
  }
  const tick = Math.floor(t * RATE + 1e-9);
  function advance(state, index) {
    const target = targetsAt(index / RATE);
    const oldLevel = state.slowLevel;
    const oldOrbit = state.orbitEnergy;
    state.smooth = smoothAudioBands({ smooth: state.smooth, bands: target.bands });
    Object.assign(state, updateSlowAudioBands({ slowLevel: state.slowLevel,
      slowBass: state.slowBass, bands: target.bands }));
    updateAudioFeatureState({ state: state.features, bands: target.bands,
      now: 1000 + (index + 1) * 1000 / RATE });
    // The offline transient detector owns onset timing (the tempo grid can be
    // out of phase). Reuse live band/energy envelopes without redetecting kicks.
    state.features.kickPulse = target.bands.kick;
    computeMusicAwareState({ previousState: state.music, lookaheadState: target.lookahead,
      analysisTimeline: timeline, audioFeatures: state.features, currentTime: index / RATE });
    const orbitTarget = Math.min(1, state.features.globalEnergy * 1.20 + state.music.highEnergy * 0.35);
    state.orbitEnergy += (orbitTarget - state.orbitEnergy) * (1 - Math.exp(-1 / (RATE * 2.4)));
    if (index > 0) {
      state.wavePhase += (0.45 + (oldLevel + state.slowLevel) * 0.5 * 1.35) / RATE;
      state.orbitPhase += Math.PI * 2 * (8.5 / 60)
        * (1 + (oldOrbit + state.orbitEnergy) * 0.5) / RATE;
    }
    return state;
  }
  if (tick < cache.tick) {
    const checkpoint = Math.floor(tick / RATE);
    cache.state = clone(cache.checkpoints[checkpoint]);
    cache.tick = checkpoint * RATE;
  }
  while (cache.tick < tick) {
    advance(cache.state, ++cache.tick);
    // One checkpoint per second bounds memory for hour-long tracks; ordinary
    // consecutive frames reuse the last tick. Seeking replays at most 29 ticks
    // after the nearest previously visited checkpoint.
    if (cache.tick % RATE === 0) cache.checkpoints[cache.tick / RATE] = clone(cache.state);
  }
  const a = cache.state;
  const b = advance(clone(a), tick + 1);
  const fraction = Math.max(0, Math.min(1, t * RATE - tick));
  const mix = (x, y) => x + (y - x) * fraction;
  const objectMix = (x, y) => Object.fromEntries(Object.keys(x).map((key) => [key,
    typeof x[key] === "number" ? mix(x[key], y[key]) : x[key]]));
  const smooth = objectMix(a.smooth, b.smooth);
  const features = objectMix(a.features, b.features);
  const music = objectMix(a.music, b.music);
  music.role = a.music.role;
  // Interpolating an onset would anticipate the next detector window. Attack
  // remains immediate; only release carries the live envelope's decay.
  const kick = targetsAt(t).bands.kick;
  smooth.kick = Math.max(kick, a.smooth.kick * Math.pow(0.72, fraction));
  features.kickPulse = kick;
  return { smooth, features, music, slowLevel: mix(a.slowLevel, b.slowLevel),
    slowBass: mix(a.slowBass, b.slowBass), wavePhase: mix(a.wavePhase, b.wavePhase),
    orbitPhase: mix(a.orbitPhase, b.orbitPhase) };
}
