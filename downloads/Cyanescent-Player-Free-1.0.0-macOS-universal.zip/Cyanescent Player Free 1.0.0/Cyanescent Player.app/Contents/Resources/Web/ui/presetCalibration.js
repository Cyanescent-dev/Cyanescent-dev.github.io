// UI lifecycle only. Runtime control objects remain authoritative, including when
// controls are unmounted. No storage, animation callbacks or analysis work here.
const panels = new Set();
const runtimes = new Map();
const tuned = new Map();
let onChange = null;

export function onPresetCalibrationChanged(listener) { onChange = listener; }
export function tunedPresetCalibrations() { return [...tuned.values()]; }
export function applyPresetCalibration(configuration) {
  return runtimes.get(configuration?.presetId)?.apply(configuration.parameters) || false;
}

// Called once per live frame with no allocation or DOM work unless selection changes.
export function selectPresetCalibration(presetId) {
  if (state.presetId === presetId) return;
  setPresetCalibrationState({ presetId });
}
const state = { debugEnabled: false, exporting: false, presetId: null };

export function setPresetCalibrationState(next) {
  if ((next.debugEnabled === undefined || next.debugEnabled === state.debugEnabled) &&
      (next.exporting === undefined || next.exporting === state.exporting) &&
      (next.presetId === undefined || next.presetId === state.presetId)) return;
  Object.assign(state, next);
  for (const panel of panels) panel.refresh();
}

export function createPresetCalibration({ presetId, presetName, controls, buildPanel, clearPanel }) {
  // Capture before URL fixtures or user edits; reset never guesses slider values.
  const defaults = { ...controls };
  let element = null;
  let active = false;
  const configuration = () => ({ presetId, presetName, parameters: { ...controls } });
  function syncInputs() {
    for (const input of element.querySelectorAll('[data-key], [data-control]')) {
      const value = controls[input.dataset.key || input.dataset.control];
      if (input.type === 'checkbox') input.checked = value;
      else input.value = String(value);
    }
  }
  function changed() {
    const settings = configuration();
    tuned.set(presetId, settings);
    onChange?.(settings);
  }
  function reset() {
    Object.assign(controls, defaults);
    if (element) syncInputs();
    changed();
  }
  async function copy() {
    const json = JSON.stringify(configuration(), null, 2);
    try {
      await navigator.clipboard.writeText(json);
    } catch {
      // WKWebView/file URLs may lack the async clipboard API. Keep this inside
      // the button gesture and preserve focus when using WebKit's copy command.
      const focused = document.activeElement;
      const text = document.createElement('textarea');
      text.value = json;
      text.style.cssText = 'position:fixed;left:-10000px;top:0';
      document.body.appendChild(text);
      text.select();
      let copied = false;
      try { copied = document.execCommand('copy'); }
      finally { text.remove(); focused?.focus(); }
      if (!copied) throw new Error('Clipboard unavailable');
    }
  }
  function refresh() {
    const visible = active && state.debugEnabled && !state.exporting && state.presetId === presetId;
    if (visible && !element) {
      element = buildPanel();
      element.dataset.presetCalibration = String(presetId);
      syncInputs();
      element.addEventListener('input', changed);
      element.addEventListener('change', changed);
      const actions = document.createElement('div');
      actions.className = 'preset-calibration-actions';
      const status = document.createElement('span');
      status.setAttribute('role', 'status');
      for (const [label, action] of [['Reset to Factory Defaults', reset], ['Copy Settings', copy]]) {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = label;
        button.addEventListener('click', async () => {
          try { await action(); status.textContent = label === 'Copy Settings' ? 'Settings copied' : 'Defaults restored'; }
          catch { status.textContent = 'Could not copy settings. Check clipboard access and retry.'; }
        });
        actions.appendChild(button);
      }
      actions.appendChild(status);
      element.appendChild(actions);
    } else if (!visible && element) {
      element.remove();
      element = null;
      clearPanel();
    }
  }
  runtimes.set(presetId, {
    apply(parameters) {
      if (!parameters || typeof parameters !== 'object') return false;
      for (const key of Object.keys(defaults)) {
        const value = parameters[key];
        if (typeof value !== typeof defaults[key] || (typeof value === 'number' && !Number.isFinite(value))) return false;
      }
      for (const key of Object.keys(defaults)) controls[key] = parameters[key];
      tuned.set(presetId, configuration());
      if (element) syncInputs();
      return true;
    }
  });
  const panel = { refresh };
  return {
    configuration, reset, copy,
    start() { active = true; panels.add(panel); refresh(); },
    stop() { active = false; panels.delete(panel); refresh(); }
  };
}
