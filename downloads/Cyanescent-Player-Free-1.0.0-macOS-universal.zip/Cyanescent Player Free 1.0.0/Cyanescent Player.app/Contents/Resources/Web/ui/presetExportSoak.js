// Diagnostic orchestration only. Every frame still goes through the production
// offline exporter, native compositor, encoder and source-audio muxer.
export async function runPresetExportSoak(ctx, config) {
  const stage = (name, value) => window.CyanescentDiagnostics?.reportStage?.(`preset-soak:${name}`, value);
  const preset = ctx.presets().find((p) => Number(p.id) === Number(config.presetId));
  if (!preset) throw new Error(`Preset ${config.presetId} is unavailable in this edition.`);
  const duration = Number(config.duration);
  const sourceStart = Number(config.offset);
  const trackDuration = ctx.analysis().duration;
  if (!(duration > 0 && sourceStart >= 0 && sourceStart + duration <= trackDuration + 0.0001)) {
    throw new Error(`Requested ${sourceStart}–${sourceStart + duration}s exceeds track duration ${trackDuration}s. Choose --offset 0 or a longer track.`);
  }
  const height = Number(config.height);
  if (![720, 1080].includes(height) || ![24, 30, 60].includes(Number(config.fps))) throw new Error("Unsupported soak format");
  const width = height === 720 ? 1280 : 1920;
  const heartbeat = () => stage("progress", {
    presetId: preset.id, percent: Number(document.getElementById("exportProgress")?.value || 0),
    message: document.getElementById("exportStatus")?.textContent || "Preparing analysed track"
  });
  const timer = window.setInterval(heartbeat, 10000);
  try {
    stage("start", { preset, duration, sourceStart, trackDuration, width, height, fps: config.fps,
      analysisFrames: ctx.analysis().timeline?.frames?.length || 0 });
    const result = await ctx.exportPreset({
      outputPath: config.outputPath, presetId: preset.id,
      sourceStart, sourceEnd: sourceStart + duration, durationSeconds: duration,
      options: {
        destinationId: "custom", width, height, renderWidth: width, renderHeight: height,
        fps: Number(config.fps), codec: "h264", includeAudio: true,
        bitrate: Number(config.bitrateMbps) * 1000000, bitrateMbps: Number(config.bitrateMbps),
        supersampling: 1, jpegQuality: 0.9, testPresetEnabled: true, testPresetId: preset.id
      }
    });
    const record = { success: result?.success === true, path: result?.path || config.outputPath,
      presetId: preset.id, name: preset.name, sourceStart, duration, trackDuration,
      analysisFrames: ctx.analysis().timeline?.frames?.length || 0,
      cancelled: Boolean(result?.cancelled),
      error: result?.error ? String(result.error.stack || result.error) : result?.success ? "" : "Exporter did not start; see exportStatus",
      status: document.getElementById("exportStatus")?.textContent || "" };
    stage("result", record);
    if (!record.success) throw new Error(record.error);
    return record;
  } finally {
    window.clearInterval(timer);
  }
}
