// Fractal Breaker (preset 165), Stage B: the director behind the living fractal wave.
//
// The wave is not an effect. The first fold of sdApollonian puts a spherical inversion pole at the
// centre of every lattice cell (x = y = 0, z = 0, 2, 4, ...). The camera travels along z just off
// that axis, so every 10 s of Stage A motion it passes ~0.14 from a pole. There the inversion
// magnification s / r^2 explodes, the remaining folds collapse, and the rays stop on the camera's
// exclusion shell inside a smooth glowing region that grows from the centre of the view and sweeps
// out past the camera. The camera's phase within the cell (fbClock.x / 10) decides it: across
// the whole test track the image is smoothest at phase 0.92-0.95, starts gathering from ~0.80 and
// has cleared by ~1.10. Inversion strength and the offsets only shape its size and texture.
//
// So the director guides the existing parameters instead of drawing anything:
//   - camera travel is a clock whose speed it controls: before a known drop it times the journey
//     to reach the gathering phase as the drop arrives (creeping there in the last seconds), then
//     releases the camera through the pole on the drop. Elsewhere the camera keeps travelling and
//     the spontaneous waves still come, slower in calm passages.
//   - the camera's lateral position (closest approach to the pole) sets a wave's intensity and its
//     angle the direction the wave sweeps; inversion strength rises a little while it gathers.
//   - the offsets, recursive rotations, roll and glow hue run on clocks paced by the music
//     (slower in breakdowns, the original speed when it drives); bass modulates their rate, slow
//     mids replace the raw mids in the rotation, kicks and treble only touch the lighting.
// Every value the shader reads is integrated or slew-limited: nothing jumps on a state change.
// Offline export replays it from the preset start at a fixed 120 Hz (identical at any frame rate,
// after any seek). Without a Drop Map nothing is predicted: a detected drop only hurries the
// camera on if a pole is already close.
import { follow } from "../engine/newtonBasinAudio.js";
import { createOfflineAnimationClock } from "../engine/offlineAnimationClock.js";

export const FRACTAL_BREAKER_PRESET_ID = 165;

export const FB = Object.freeze({
  cell: 10,          // camera clock units per lattice cell (Stage A: 0.2 world units/s, period 2)
  gather: 0.80,      // phase where the smooth region starts to form ahead
  poised: 0.83,      // phase held at the drop
  clear: 1.13,       // the wave has swept past (phase of the next cell + 0.13)
  peak: 0.935,       // phase of the strongest wave (measured)
  horizon: 20,       // s: drops further away are not planned for
  minorGap: 40,      // s: a minor drop only gets a wave this long after the last one
  r0: Math.hypot(0.1, 0.1), theta0: Math.PI / 4,
  step: 1 / 120
});

const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, Number.isFinite(x) ? x : a));
const smooth01 = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
const frac = (x) => x - Math.floor(x);
// deterministic per-drop variation
const hash = (n) => frac(Math.sin(n * 127.1 + 311.7) * 43758.5453);
// float32 precision: clocks reach the shader wrapped at a common period of every function of them
// (offsets 20pi, rotations 40pi, roll 20pi, hue 2pi; the camera a whole number of cells)
const WRAP = 1240 * Math.PI;
const wrap = (x) => x % WRAP;

export function createFractalBreakerDirector() {
  const s = {};
  const uniforms = {};

  function reset() {
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0, carry: 0,
      // clocks (seconds of Stage A motion)
      cam: 3, off: 20, rot: 20, roll: 20, hue: 0,
      v: 0.85, pace: 0.85, rate: 0.85,
      energy: 0.6, calm: 0, drive: 0.5, bassSlow: 0.4, midsSlow: 0.4, shimmer: 0, kick: 0,
      gather: 0, boost: 0, inv: 1.32,
      r: FB.r0, theta: FB.theta0, rGoal: FB.r0, thetaGoal: FB.theta0,
      // 0 free, 1 approach (timed to a known drop), 2 release (through the pole)
      mode: 0, targetC: 0, dropAt: 0, creep: 4, strength: 0, vr: 1, waves: 0, lastWaveAt: -1e9,
      prevAge: null, prevDetected: 0, liveDropAt: -1e9, mapKnown: false
    });
  }
  reset();

  const phaseOf = (c) => frac(c / FB.cell);
  // next camera clock value with phase p strictly ahead of c (at least `ahead` units)
  function nextAt(c, p, ahead = 0) {
    let target = (Math.floor(c / FB.cell) + p) * FB.cell;
    while (target < c + ahead) target += FB.cell;
    return target;
  }

  function plan(dropIn, strength) {
    const variant = hash(s.waves + 1);
    const creep = clamp(dropIn * 0.3, 2.5, 6) * (0.8 + 0.4 * variant);
    const travel = Math.max(0.5, dropIn - creep);
    const poleAhead = nextAt(s.cam, FB.peak, 0);
    let best = null;
    for (let k = 0; k < 3; k++) {
      const targetC = nextAt(s.cam, FB.poised, 0.35) + k * FB.cell;
      const avg = (targetC - 0.3 - s.cam) / travel;
      // reaching the target through another pole would spend the wave during the build
      const passesPole = poleAhead < targetC - FB.cell * 0.5;
      const score = Math.abs(avg - 0.55) + (passesPole ? 0.6 : 0) + (avg > 1.5 || avg < 0.1 ? 10 : 0);
      if (!best || score < best.score) best = { targetC, score };
    }
    if (best.score >= 10) return false;
    s.mode = 1; s.targetC = best.targetC; s.creep = creep; s.strength = strength;
    // variation: intensity (closest approach), direction (approach angle), duration (release speed)
    const major = strength >= 1;
    s.rGoal = major ? 0.065 + 0.04 * hash(s.waves + 7) : 0.12;
    s.thetaGoal = FB.theta0 + [0, 2.3, -1.9, 1.05][s.waves % 4] + 0.3 * (hash(s.waves + 3) - 0.5);
    s.vr = major ? 0.55 + 0.3 * hash(s.waves + 11) : 1.0;
    return true;
  }

  function release(targetC, strength) {
    s.mode = 2; s.targetC = targetC; s.strength = strength;
    if (!(s.vr > 0)) s.vr = 1;
    s.waves += 1; s.lastWaveAt = s.time;
  }

  function advance(dt, input = {}) {
    const { audio = {}, smooth = {}, music = {} } = input;
    s.time += dt;

    // ---- musical envelopes (slew-limited) ------------------------------------------------------
    s.energy = follow(s.energy, clamp(Number(audio.globalEnergy)), dt, 0.8, 1.6);
    const calmGoal = clamp(Math.max(clamp(Number(music.breakdown)), clamp(Number(music.calm))) * 1.3 - 0.15);
    s.calm = follow(s.calm, calmGoal, dt, 2.5, 2.0);
    s.drive = follow(s.drive, clamp(0.6 * clamp(Number(music.highEnergy)) + 0.4 * s.energy), dt, 1.5, 2.5);
    s.bassSlow = follow(s.bassSlow, clamp(Number(smooth.bass)), dt, 1.2, 1.8);
    s.midsSlow = follow(s.midsSlow, clamp(Number(smooth.mids)), dt, 2.0, 2.5);
    s.shimmer = follow(s.shimmer, clamp(Number(smooth.highs)), dt, 0.12, 0.45);
    s.kick = Math.max(s.kick * Math.exp(-dt / 0.16), clamp(Number(audio.kickPulse)));

    // Pacing: contemplative in breakdowns, the original speed when the music drives.
    const paceGoal = clamp(0.78 + 0.22 * s.drive - 0.5 * s.calm, 0.38, 1.0);
    s.pace = follow(s.pace, paceGoal, dt, 3.0, 2.5);
    // bass: a smooth modulation of how hard the structure moves
    s.rate = s.pace * (0.86 + 0.28 * s.bassSlow);

    // ---- drops ---------------------------------------------------------------------------------
    const known = Number(music.dropKnown) > 0.5;
    s.mapKnown = known;
    let dropNow = false, dropStrength = 0;
    if (known) {
      const age = clamp(Number(music.dropAge), 0, 64);
      const last = clamp(Number(music.dropLastStrength));
      if (s.prevAge !== null && age < s.prevAge - 0.2 && age < 0.75 && last > 0) { dropNow = true; dropStrength = last; }
      s.prevAge = age;
      const dropIn = clamp(Number(music.dropIn), 0, 64);
      const next = clamp(Number(music.dropNextStrength));
      // the planned drop has arrived: release (handled below) before the next drop is considered
      if (dropNow && s.mode === 1 && s.cam > s.targetC - 3) {
        release(s.targetC, Math.max(dropStrength, s.strength));
        dropNow = false;
      }
      const eligible = next >= 1 || s.time - s.lastWaveAt > FB.minorGap;
      if (s.mode === 1 && (next <= 0 || dropIn > FB.horizon + 2 || Math.abs(s.time + dropIn - s.dropAt) > 1.0)) {
        s.mode = 0;   // the drop moved (seek, re-analysis): plan again below
      }
      if (s.mode === 0 && next > 0 && eligible && dropIn > 2.5 && dropIn <= FB.horizon && s.time - s.lastWaveAt > 6) {
        if (plan(dropIn, next)) s.dropAt = s.time + dropIn;
      }
      if (s.mode === 1) s.dropAt = s.time + dropIn;
    } else {
      s.prevAge = null;
      if (s.mode === 1) s.mode = 0;
      const detected = Math.max(clamp(Number(audio.dropDetected)), clamp(Number(music.drop)));
      if (detected > 0.6 && s.prevDetected <= 0.6 && s.time - s.liveDropAt > 16) {
        dropNow = true; dropStrength = 0.75; s.liveDropAt = s.time;
      }
      s.prevDetected = detected;
    }

    if (dropNow && s.mode !== 2) {
      if (s.mode === 1 && s.cam > s.targetC - 3) release(s.targetC, Math.max(dropStrength, s.strength));
      else {
        // unprepared (no map, or no feasible plan): hurry on only if a pole is already near
        const near = nextAt(s.cam, FB.poised, 0);
        if (near - s.cam <= 3.0 && (dropStrength >= 1 || s.time - s.lastWaveAt > FB.minorGap)) {
          s.vr = 1.1; s.rGoal = Math.min(s.rGoal, 0.11); release(near, dropStrength);
        } else if (s.mode === 1) s.mode = 0;
      }
    }

    // ---- camera travel -------------------------------------------------------------------------
    let vGoal = s.pace;
    let gatherGoal = 0;
    if (s.mode === 1) {
      const remain = s.dropAt - s.time;
      vGoal = remain > s.creep
        ? (s.targetC - 0.3 - s.cam) / (remain - s.creep)
        : (s.targetC - s.cam) / Math.max(0.25, remain);
      vGoal = clamp(vGoal, 0.03, 1.6);
      // the build organises: inversion strength rises as the gathering phase nears
      gatherGoal = smooth01(1 - (s.targetC - s.cam) / 6) * (0.6 + 0.4 * s.strength);
    } else if (s.mode === 2) {
      vGoal = s.vr * (s.strength >= 1 ? 1 : 1.1);
      gatherGoal = s.cam < s.targetC + 1.5 ? 1 : 0;
      if (s.cam >= s.targetC + (FB.clear - FB.poised) * FB.cell) { s.mode = 0; s.rGoal = FB.r0; }
    }
    s.v = follow(s.v, vGoal, dt, s.mode === 2 ? 0.45 : 0.9, s.mode === 1 ? 0.6 : 1.4);
    s.cam += Math.max(0.02, s.v) * dt;
    s.gather = follow(s.gather, gatherGoal, dt, 2.0, 2.5);
    s.boost = follow(s.boost, s.mode === 2 ? 0.08 * s.strength : 0, dt, 0.6, 3.0);

    // lateral position: moved only while the camera is away from a pole (the view near a pole is
    // hypersensitive to it), so a wave's approach is settled before it forms
    const ph = phaseOf(s.cam);
    if (ph > 0.12 && ph < 0.74) {
      s.r = follow(s.r, s.rGoal, dt, 2.5, 2.5);
      s.theta = follow(s.theta, s.thetaGoal, dt, 3.0, 3.0);
    }

    // ---- structural clocks ---------------------------------------------------------------------
    s.off += s.rate * dt;
    s.rot += s.rate * dt;
    s.roll += s.pace * dt;
    s.hue += (0.6 + 0.4 * s.pace) * dt;
    s.inv = clamp(1.2 + 0.2 * s.energy + 0.1 * s.gather + s.boost, 1.15, 1.5);

    uniforms.fbClock = [s.cam % 4000, wrap(s.off), wrap(s.rot), wrap(s.roll)];
    uniforms.fbShape = [s.inv, s.r * Math.cos(s.theta), s.r * Math.sin(s.theta), s.midsSlow];
    uniforms.fbLight = [0.14 * s.kick * (0.5 + 0.5 * s.drive), 0.14 * s.shimmer, s.energy, wrap(s.hue)];
    return s;
  }

  // fixed 120 Hz sub-steps: live frames, offline replays and any frame rate integrate alike
  function run(dt, input) {
    s.carry += dt;
    while (s.carry >= FB.step - 1e-7) { advance(FB.step, input); s.carry -= FB.step; }
  }

  // Live: time is seconds since the preset started (monotonic per activation).
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = time - s.lastTime;
    s.lastTime = time;
    // a long gap (hidden window, stall) is not replayed; the clocks simply continue
    run(Math.min(Math.max(dt, 0), 0.25), input);
    return s;
  }

  function summary() {
    const r = (x, n = 2) => +Number(x).toFixed(n);
    return { t: r(s.time), mode: s.mode, cam: r(s.cam), ph: r(phaseOf(s.cam), 3), v: r(s.v), pace: r(s.pace),
      calm: r(s.calm), drive: r(s.drive), gather: r(s.gather), inv: r(s.inv, 3), r: r(s.r, 3), theta: r(s.theta),
      target: r(s.targetC), dropAt: r(s.dropAt), waves: s.waves, map: s.mapKnown ? 1 : 0 };
  }

  if (!uniforms.fbClock) advance(0, {});
  return { state: s, step, advance, run, reset, summary, uniforms: () => uniforms };
}

// ---- live and offline runtimes ------------------------------------------------------------------
const live = { director: createFractalBreakerDirector(), lastTime: -1, loggedAt: -99 };
const offline = { director: createFractalBreakerDirector(), active: false, clock: null };
offline.clock = createOfflineAnimationClock({
  reset: () => offline.director.reset(),
  step: (dt, inputs) => offline.director.run(dt, inputs)
});

export const FB_OFFLINE_RATE = 120;
export async function prepareFractalBreakerOffline(time, options = {}) {
  offline.active = true;
  await offline.clock.advanceAsync(time, { ...options, fps: FB_OFFLINE_RATE });
}
export function endFractalBreakerOffline() { offline.active = false; offline.clock.end(); }

export function bindFractalBreakerDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let director;
  if (opts.director) director = opts.director;
  else if (offline.active && opts.offline) director = offline.director;
  else {
    director = live.director;
    if (time !== live.lastTime) { director.step(time, input); live.lastTime = time; }
    if (globalThis.document?.body?.classList?.contains("preset-trial-role") && (time < live.loggedAt || time - live.loggedAt >= 2)) {
      live.loggedAt = time;
      globalThis.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "info", text: `[FB] ${JSON.stringify(director.summary())}` });
    }
  }
  const loc = (name) => uniformLocation(gl, program, name);
  const on = loc("fbDirector");
  if (on) gl.uniform1f(on, 1);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (l) gl.uniform4f(l, value[0], value[1], value[2], value[3]);
  }
  return director;
}
