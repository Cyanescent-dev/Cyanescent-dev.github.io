export function createSwirlieDomainRepeaterPresetShaderEntries({
    modularShaderPrelude,
    modularTransitionShaderBlock
  }) {
    const source = `${modularShaderPrelude}
  ${modularTransitionShaderBlock}
  // -------------------------------------------------------------------------
  // Preset 167: Swirlie Domain Repeater
  // Inspired by 'Geiss - Swirlie 3.milk' - fluid vortex recursion
  // -------------------------------------------------------------------------
  mat2 rot2(float a) {
      float s = sin(a), c = cos(a);
      return mat2(c, -s, s, c);
  }
  float hash11(float p) {
      p = fract(p * .1031);
      p *= p + 33.33;
      p *= p + p;
      return fract(p);
  }
  float noise3D(vec3 x) {
      vec3 p = floor(x);
      vec3 f = fract(x);
      f = f * f * (3.0 - 2.0 * f);
      float n = p.x + p.y * 57.0 + 113.0 * p.z;
      return mix(mix(mix(hash11(n +   0.0), hash11(n +   1.0), f.x),
                     mix(hash11(n +  57.0), hash11(n +  58.0), f.x), f.y),
                 mix(mix(hash11(n + 113.0), hash11(n + 114.0), f.x),
                     mix(hash11(n + 170.0), hash11(n + 171.0), f.x), f.y), f.z);
  }
  float fbm(vec3 p) {
      float f = 0.0;
      float amp = 0.5;
      for (int i = 0; i < 3; i++) {
          f += amp * noise3D(p);
          p *= 2.0;
          amp *= 0.5;
      }
      return f;
  }
  // Distance estimator: recursive domain repetition with fluid twist
  float sdSwirlie(vec3 p, float t) {
      // Apply a fluid vortex twist (Smoothed with globalEnergy)
      float twistAmount = fbm(p * 0.2 + time * 0.2) * (2.0 + globalEnergy * 0.5);
      p.xy *= rot2(twistAmount);
      p.xz *= rot2(twistAmount * 0.5);
      
      // Space folding (recursion substitute)
      float spacing = 2.0;
      p = mod(p + spacing * 0.5, spacing) - spacing * 0.5;
      
      // Base shape is an intersecting star/cross
      float d1 = length(p.xy) - 0.1;
      float d2 = length(p.xz) - 0.1;
      float d3 = length(p.yz) - 0.1;
      
      float d = min(d1, min(d2, d3));
      
      // Camera forcefield: physically pushes geometry away from the camera lens to prevent glitching
      return max(d, 0.3 - t);
  }
  void main() {
      vec2 uv = vUv * 2.0 - 1.0;
      uv.x *= resolution.x / max(resolution.y, 1.0);
      // Offset camera slightly so it doesn't fly directly inside the central cross axis
      vec3 ro = vec3(0.5, 0.5, -time * 2.0);
      vec3 rd = normalize(vec3(uv, 1.0));
      rd.xy *= rot2(time * 0.1 + globalEnergy * 0.3); // Smooth Global barrel roll
      
      float t = 0.0;
      float maxDist = 20.0;
      vec3 col = vec3(0.0);
      float glow = 0.0;
      
      for (int i = 0; i < 50; i++) {
          vec3 p = ro + rd * t;
          float d = sdSwirlie(p, t);
          // Fluid neon accumulation (capped step to prevent extreme foreground flashes)
          glow += 0.02 / max(abs(d), 0.05) * exp(-t * 0.2);
          
          if (d < 0.01 || t > maxDist) break;
          t += d * 0.7; // Safer stepping through heavily twisted domains
      }
      
      // Audio reactive palette
      vec3 baseColor = 0.5 + 0.5 * cos(time + t * 0.5 + vec3(0, 2, 4) + globalEnergy);
      // Smooth glow, capped to absolutely prevent grazing strobes, with increased brightness
      col += baseColor * min(glow, 2.5) * 0.7; 
      
      // Deep fluid fog
      col = mix(col, vec3(0.02, 0.01, 0.05), smoothstep(0.0, maxDist, t));
      
      outColor = vec4(col / (1.0 + col * 0.5), 1.0);
      
      // Transitions
      outColor.rgb += transitionTunnel(uv);
      outColor.rgb *= transitionIdentityPresence();
  }
  `;
    return [[167, { name: "Swirlie Domain Repeater", source }]];
  }
  