export const fullVisualizerSharedPrelude = `#version 300 es
precision highp float;

in vec2 vUv;
out vec4 outColor;

uniform sampler2D previousFrame;
uniform sampler2D omTexture;
uniform sampler2D presetBackground;
uniform vec2 resolution;
uniform float time;
uniform float kick;
uniform float bass;
uniform float mids;
uniform float highs;
uniform float brightness;
uniform float level;
uniform float sensitivity;
uniform float preset;
uniform float quality;
uniform float transitionPhase;
uniform float transitionSeed;
uniform float futureEnergy;
uniform float futureBrightness;
uniform float futureDensity;
uniform float sectionChange;
uniform float energyTrend;
uniform float breakdownState;
uniform float mainRiffState;
uniform float dropState;
uniform float buildUpState;
uniform float calmState;
uniform float highEnergyState;
uniform float adaptiveIntensity;
uniform float phrasePulse;
uniform float phraseProgress;
uniform float beatPhase;
uniform float absoluteBeat;
uniform float transitionStyle;
uniform float transitionSide;
uniform float presetTime;
uniform float trackProgress;
uniform float bassRel;
uniform float midRel;
uniform float trebleRel;
uniform float kickPulse;
uniform float globalEnergy;
uniform float dropDetected;
uniform float omTextureReady;
uniform float presetBackgroundReady;
uniform float knotOrbitPhase;
uniform float feedbackStep;
uniform float transitionToPreset;
uniform float transitionSwapAt;
uniform float u_waveform[64];
uniform float u_slowLevel;
uniform float u_slowBass;
uniform float u_wavePhase;


#define PI 3.14159265359

mat2 rot(float a) {
  float s = sin(a);
  float c = cos(a);
  return mat2(c, -s, s, c);
}

float feedbackRetain(float amount) {
  return pow(clamp(amount, 0.0, 0.9995), max(0.01, feedbackStep));
}

float feedbackZoom(float amount) {
  return pow(max(amount, 0.001), max(0.01, feedbackStep));
}

float hash(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
    mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
    u.y
  );
}

vec2 hash2(vec2 p) {
  return fract(sin(vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)))) * 43758.5453);
}

float mandala(vec2 p, float folds) {
  float a = atan(p.y, p.x);
  float r = length(p);
  a = mod(a, PI * 2.0 / folds) - PI / folds;
  vec2 q = vec2(cos(a), sin(a)) * r;
  float rings = sin(34.0 * r - time * (1.2 + bass * 2.0));
  float spokes = sin(q.x * 26.0 + sin(q.y * 12.0 + time));
  return smoothstep(0.82, 1.0, rings * 0.45 + spokes * 0.55);
}

vec3 presetBackgroundColor(vec2 uv) {
  vec2 cover = uv;
  float canvasAspect = resolution.x / max(1.0, resolution.y);
  float imageAspect = 16.0 / 9.0;
  if (canvasAspect > imageAspect) {
    cover.y = (cover.y - 0.5) * (imageAspect / canvasAspect) + 0.5;
  } else {
    cover.x = (cover.x - 0.5) * (canvasAspect / imageAspect) + 0.5;
  }
  vec3 bg = texture(presetBackground, clamp(cover, vec2(0.0), vec2(1.0))).rgb;
  float vignette = smoothstep(1.38, 0.10, length((uv * 2.0 - 1.0) * vec2(canvasAspect, 1.0)));
  return bg * (0.72 + 0.28 * vignette);
}

vec3 hypergeometryBackgroundColor(vec2 uv) {
  vec2 cover = uv;
  float canvasAspect = resolution.x / max(1.0, resolution.y);
  float imageAspect = 16.0 / 9.0;
  if (canvasAspect > imageAspect) {
    cover.y = (cover.y - 0.5) * (imageAspect / canvasAspect) + 0.5;
  } else {
    cover.x = (cover.x - 0.5) * (canvasAspect / imageAspect) + 0.5;
  }
  vec2 center = cover - 0.5;
  float slowZoom = 0.965 + 0.080 * sin(time * 0.115) + 0.035 * globalEnergy;
  center *= slowZoom;
  center = rot(0.060 * sin(time * 0.082)) * center;
  center += vec2(sin(time * 0.090), cos(time * 0.067)) * 0.070;
  cover = center + 0.5;
  vec3 bg = texture(presetBackground, clamp(cover, vec2(0.0), vec2(1.0))).rgb;
  float hueDrift = 0.052 + 0.055 * sin(time * 0.090);
  bg = mix(bg, bg.gbr, hueDrift);
  float audioLift = 0.34 + 1.08 * globalEnergy + 0.32 * bassRel + 0.26 * highs + 0.22 * kickPulse;
  float vignette = smoothstep(1.42, 0.06, length((uv * 2.0 - 1.0) * vec2(canvasAspect, 1.0)));
  return bg * audioLift * (0.66 + 0.34 * vignette);
}

vec3 blendPresetBackground(vec3 color, vec2 uv, float amount) {
  vec3 bg = presetBackgroundColor(uv);
  float ready = clamp(presetBackgroundReady, 0.0, 1.0);
  return mix(color, bg * 0.82 + color * 0.58, ready * amount);
}

vec3 palette60s(float t) {
  t = fract(t);
  vec3 red = vec3(0.86, 0.10, 0.11);
  vec3 orange = vec3(0.96, 0.42, 0.08);
  vec3 yellow = vec3(0.92, 0.72, 0.12);
  vec3 green = vec3(0.24, 0.68, 0.18);
  vec3 blue = vec3(0.08, 0.32, 0.78);
  vec3 violet = vec3(0.42, 0.12, 0.72);
  vec3 magenta = vec3(0.76, 0.10, 0.52);
  vec3 c = red;
  c = mix(c, orange, smoothstep(0.00, 0.14, t));
  c = mix(c, yellow, smoothstep(0.14, 0.28, t));
  c = mix(c, green, smoothstep(0.28, 0.43, t));
  c = mix(c, blue, smoothstep(0.43, 0.60, t));
  c = mix(c, violet, smoothstep(0.60, 0.76, t));
  c = mix(c, magenta, smoothstep(0.76, 0.90, t));
  c = mix(c, red, smoothstep(0.90, 1.0, t));
  return pow(c, vec3(0.96)) * 0.82;
}

float julia(vec2 z, vec2 c) {
  float m = 0.0;
  int maxIter = int(mix(24.0, 54.0, quality));
  for (int i = 0; i < 64; i++) {
    if (i >= maxIter) break;
    z = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c;
    if (dot(z, z) > 9.0) {
      m = float(i) / float(maxIter);
      break;
    }
  }
  return m;
}

float newtonBasin(vec2 z) {
  vec2 q = z;
  for (int i = 0; i < 18; i++) {
    vec2 z2 = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y);
    vec2 z3 = vec2(z2.x * z.x - z2.y * z.y, z2.x * z.y + z2.y * z.x);
    vec2 f = z3 - vec2(1.0, 0.0);
    vec2 df = 3.0 * z2;
    float d = max(dot(df, df), 0.001);
    vec2 stepv = vec2(f.x * df.x + f.y * df.y, f.y * df.x - f.x * df.y) / d;
    z -= stepv * (0.72 + 0.18 * sin(time * 0.4 + bass));
  }
  float a = atan(z.y, z.x);
  vec2 r0 = vec2(1.0, 0.0);
  vec2 r1 = vec2(-0.5, 0.8660254);
  vec2 r2 = vec2(-0.5, -0.8660254);
  float d0 = length(z - r0);
  float d1 = length(z - r1);
  float d2 = length(z - r2);
  float nearest = min(d0, min(d1, d2));
  float farthest = max(d0, max(d1, d2));
  float second = max(d0 + d1 + d2 - nearest - farthest, nearest + 0.0001);
  float basinEdge = 1.0 - smoothstep(0.030, 0.34, second - nearest);
  float rootOrbit = 1.0 - smoothstep(0.035, 0.30, abs(length(z) - 1.0));
  float rootHalo = exp(-nearest * (4.0 + 0.7 * sin(time * 0.18)));
  float radialWeb = smoothstep(0.58, 1.0, abs(sin(3.0 * atan(q.y, q.x) + 5.5 * log(length(q) + 0.22) - time * 0.22)));
  radialWeb *= exp(-length(q) * 0.74);
  float roots = smoothstep(-0.30, 0.94, cos(3.0 * a));
  return clamp(basinEdge * 1.12 + rootOrbit * roots * 0.44 + rootHalo * 0.34 + radialWeb * 0.30, 0.0, 2.2);
}

vec3 warm60sPalette(float t) {
  t = fract(t);
  vec3 c0 = vec3(0.04, 0.012, 0.024); // Deep chocolate plum
  vec3 c1 = vec3(0.68, 0.22, 0.15);  // Terracotta red
  vec3 c2 = vec3(0.86, 0.44, 0.12);  // Burnt orange
  vec3 c3 = vec3(0.84, 0.64, 0.15);  // Mustard gold
  vec3 c4 = vec3(0.35, 0.45, 0.18);  // Avocado green
  vec3 c5 = vec3(0.50, 0.25, 0.08);  // Dark amber
  
  float stepVal = 1.0 / 6.0;
  if (t < stepVal) return mix(c0, c1, t * 6.0);
  if (t < 2.0 * stepVal) return mix(c1, c2, (t - stepVal) * 6.0);
  if (t < 3.0 * stepVal) return mix(c2, c3, (t - 2.0 * stepVal) * 6.0);
  if (t < 4.0 * stepVal) return mix(c3, c4, (t - 3.0 * stepVal) * 6.0);
  if (t < 5.0 * stepVal) return mix(c4, c5, (t - 4.0 * stepVal) * 6.0);
  return mix(c5, c0, (t - 5.0 * stepVal) * 6.0);
}

float getWaveformValue(float x) {
  float t = (x + 1.0) * 0.5 * 63.0;
  t = clamp(t, 0.0, 63.0);
  int idx = int(floor(t));
  float f = fract(t);
  float v1 = u_waveform[clamp(idx, 0, 63)];
  float v2 = u_waveform[clamp(idx + 1, 0, 63)];
  return mix(v1, v2, f);
}

vec4 newtonBasinAdvanced(vec2 z, float musicMod) {
  vec2 q = z;
  int maxIter = 24;
  int convergedAt = maxIter;
  vec2 r0 = vec2(1.0, 0.0);
  vec2 r1 = vec2(-0.5, 0.8660254);
  vec2 r2 = vec2(-0.5, -0.8660254);
  float stepFactor = 0.72 + 0.18 * sin(time * 0.4 + u_slowBass * 0.5) + musicMod * 0.15;
  float orbit = 0.0;
  
  for (int i = 0; i < 24; i++) {
    vec2 z2 = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y);
    vec2 z3 = vec2(z2.x * z.x - z2.y * z.y, z2.x * z.y + z2.y * z.x);
    vec2 f = z3 - vec2(1.0, 0.0);
    vec2 df = 3.0 * z2;
    float d = max(dot(df, df), 0.0001);
    vec2 stepv = vec2(f.x * df.x + f.y * df.y, f.y * df.x - f.x * df.y) / d;
    z -= stepv * stepFactor;
    orbit += exp(-length(z) * 1.5);
    float d0 = length(z - r0);
    float d1 = length(z - r1);
    float d2 = length(z - r2);
    float dMin = min(d0, min(d1, d2));
    if (dMin < 0.02) {
      convergedAt = min(convergedAt, i);
    }
  }
  
  float d0 = length(z - r0);
  float d1 = length(z - r1);
  float d2 = length(z - r2);
  float rootId = 0.0;
  if (d0 < d1 && d0 < d2) {
    rootId = 0.0;
  } else if (d1 < d0 && d1 < d2) {
    rootId = 1.0;
  } else {
    rootId = 2.0;
  }
  
  float nearestRootDist = min(d0, min(d1, d2));
  float smoothIter = float(convergedAt);
  if (convergedAt < maxIter) {
    smoothIter += 1.0 - log(log(nearestRootDist + 1.0001) / log(1.02)) / log(3.0);
  }
  smoothIter = clamp(smoothIter / float(maxIter), 0.0, 1.0);
  return vec4(rootId, smoothIter, orbit / 24.0, nearestRootDist);
}

float apollonian(vec2 p) {
  vec3 q = vec3(p, 0.45 + 0.18 * sin(time * 0.25));
  float scale = 1.0;
  for (int i = 0; i < 8; i++) {
    q = -1.0 + 2.0 * fract(0.5 * q + 0.5);
    float r2 = max(dot(q, q), 0.025);
    float k = (1.18 + bass * 0.35) / r2;
    q *= k;
    scale *= k;
  }
  return 1.0 - smoothstep(0.0, 0.035, abs(length(q.xy) / scale));
}

float quasicrystal(vec2 p) {
  float v = 0.0;
  for (int i = 0; i < 7; i++) {
    float a = float(i) * PI / 7.0 + time * 0.025;
    vec2 d = vec2(cos(a), sin(a));
    v += cos(dot(p, d) * (14.0 + highs * 8.0) + sin(time * 0.33 + float(i)));
  }
  v /= 7.0;
  return smoothstep(0.42, 0.96, abs(v));
}

float clifford(vec2 p) {
  vec2 z = p * 1.35;
  float a = -1.42 + 0.18 * sin(time * 0.13);
  float b = 1.72 + 0.12 * cos(time * 0.17 + bass);
  float c = 1.28 + 0.2 * sin(time * 0.11 + mids);
  float d = 0.72 + 0.1 * cos(time * 0.19);
  float acc = 0.0;
  for (int i = 0; i < 18; i++) {
    z = vec2(sin(a * z.y) + c * cos(a * z.x), sin(b * z.x) + d * cos(b * z.y));
    acc += exp(-8.0 * length(p - z * 0.28));
  }
  return clamp(acc * 0.14, 0.0, 1.0);
}

float lineSegment(vec2 p, vec2 a, vec2 b, float width) {
  vec2 pa = p - a;
  vec2 ba = b - a;
  float h = clamp(dot(pa, ba) / max(dot(ba, ba), 0.0001), 0.0, 1.0);
  return 1.0 - smoothstep(width, width * 2.6, length(pa - ba * h));
}

float taperedSegment(vec2 p, vec2 a, vec2 b, float w0, float w1, float softness) {
  vec2 pa = p - a;
  vec2 ba = b - a;
  float along = clamp(dot(pa, ba) / max(dot(ba, ba), 0.0001), 0.0, 1.0);
  float width = max(0.0006, mix(w0, w1, along));
  float d = length(pa - ba * along);
  return 1.0 - smoothstep(width, width * softness, d);
}

vec3 rotateCyberphonic(vec3 v, float ax, float ay, float az) {
  float cx = cos(ax), sx = sin(ax);
  float cy = cos(ay), sy = sin(ay);
  float cz = cos(az), sz = sin(az);
  v.yz = mat2(cx, -sx, sx, cx) * v.yz;
  v.xz = mat2(cy, -sy, sy, cy) * v.xz;
  v.xy = mat2(cz, -sz, sz, cz) * v.xy;
  return v;
}

vec2 projectCyberphonic(vec3 v) {
  float depth = 2.55 + v.z;
  return v.xy / max(0.45, depth) * 1.72;
}

float curvedFrond(vec2 p, vec2 a, vec2 b, float curve, float w0, float w1, float grow) {
  vec2 last = a;
  float field = 0.0;
  vec2 chord = b - a;
  vec2 normal = normalize(vec2(-chord.y, chord.x) + 0.0001);
  for (int i = 1; i <= 7; i++) {
    float t = float(i) / 7.0;
    float tm = (float(i) - 0.5) / 7.0;
    float eased = t * t * (3.0 - 2.0 * t);
    vec2 pos = mix(a, b, eased) + normal * sin(t * PI) * curve;
    float gate = smoothstep(tm - 0.11, tm + 0.10, grow);
    field += taperedSegment(p, last, pos, mix(w0, w1, tm), mix(w0, w1, t), 2.8) * gate;
    last = pos;
  }
  return field;
}

float fernLeaflet(vec2 p, vec2 root, vec2 tip, float width, float grow) {
  vec2 axis = tip - root;
  float len = max(length(axis), 0.001);
  vec2 dir = axis / len;
  vec2 local = vec2(dot(p - root, dir), dot(p - root, vec2(-dir.y, dir.x)));
  float x = clamp(local.x / len, 0.0, 1.0);
  float taper = pow(max(0.0, sin(x * PI)), 0.58) * (1.0 - 0.18 * x);
  float serration = 1.0 + 0.10 * sin(x * 54.0 + time * 0.16);
  float body = 1.0 - smoothstep(width * taper * serration, width * taper * serration + 0.014, abs(local.y));
  float caps = smoothstep(0.0, 0.035, x) * (1.0 - smoothstep(0.92, 1.0, x));
  float vein = 1.0 - smoothstep(0.002, 0.009, abs(local.y));
  float sideVeins = smoothstep(0.86, 1.0, abs(sin((local.x / len) * 32.0 + abs(local.y) * 46.0))) * body * 0.26;
  return (body * 0.68 + vein * 0.28 + sideVeins) * caps * smoothstep(0.0, 1.0, grow - x * 0.36);
}

float fernOval(vec2 p, vec2 center, vec2 size, float angle) {
  vec2 q = (p - center) * rot(angle);
  float d = length(q / max(size, vec2(0.001)));
  float body = 1.0 - smoothstep(0.82, 1.08, d);
  float ridge = 1.0 - smoothstep(0.030, 0.120, abs(q.x));
  return body * (0.80 + ridge * 0.20);
}

float fernFiddlehead(vec2 p, vec2 center, float scale, float open, float spin) {
  vec2 q = (p - center) / max(scale, 0.001);
  q *= rot(spin);
  q.x -= open * 0.12;
  q.y -= open * 0.22;
  float field = 0.0;
  vec2 last = vec2(0.02, -0.20);
  for (int i = 0; i < 17; i++) {
    float fi = float(i);
    float u = fi / 16.0;
    float reveal = smoothstep(u * 0.32, u * 0.32 + 0.44, open);
    float theta = 6.25 - u * (4.10 + open * 1.92);
    float radius = mix(0.31, 0.070, u) * (1.0 - open * 0.30) + u * open * 0.23;
    vec2 pos = vec2(cos(theta), sin(theta)) * radius + vec2(open * u * 0.18, open * u * 0.42);
    float angle = theta + PI * 0.50 + sin(time * 0.18 + fi) * 0.045;
    vec2 size = vec2(0.038 + 0.030 * (1.0 - u), 0.074 + 0.048 * (1.0 - u)) * (0.78 + reveal * 0.30);
    field += fernOval(q, pos, size, angle) * reveal * (1.08 - u * 0.42);
    field += taperedSegment(q, last, pos, 0.035 * (1.0 - u * 0.32), 0.022 * (1.0 - u * 0.44), 2.2) * reveal * 0.46;
    last = pos;
  }
  float r = length(q);
  float head = exp(-length(q - vec2(0.02 + open * 0.12, 0.02 + open * 0.18)) * 13.0);
  float unfurlStem = lineSegment(q, vec2(0.02, -0.18), vec2(0.24 * open, 0.50 * open), 0.030);
  float visibility = smoothstep(0.02, 1.0, open);
  return (field * 0.92 + head * 0.20 + unfurlStem * 0.34) * visibility * (1.0 - smoothstep(0.18, 1.08, r));
}

float cinematicFern(vec2 p, float scale, float angle, float grow, float curl, float sideBias) {
  vec2 q = p / max(scale, 0.001);
  q *= rot(angle);
  q.x += sin(q.y * 1.9 + time * 0.070) * 0.040;
  vec2 base = vec2(-0.04, -0.82);
  vec2 tip = vec2(0.08 + 0.18 * curl, 0.78);
  vec2 axis = tip - base;
  vec2 normal = normalize(vec2(-axis.y, axis.x) + 0.0001);
  float field = curvedFrond(q, base, tip, 0.18 * curl, 0.030, 0.010, grow) * 0.86;
  for (int i = 1; i < 18; i++) {
    float fi = float(i);
    float t = fi / 18.0;
    float gate = smoothstep(t * 0.72, t * 0.72 + 0.30, grow);
    float eased = t * t * (3.0 - 2.0 * t);
    vec2 root = mix(base, tip, eased) + normal * sin(t * PI) * 0.18 * curl;
    float leafLen = (0.54 * sin(t * PI) + 0.08) * (0.90 + 0.12 * sin(time * 0.08 + fi));
    for (int sideIndex = 0; sideIndex < 2; sideIndex++) {
      float side = float(sideIndex) * 2.0 - 1.0;
      float sideGate = mix(0.70, 1.0, 1.0 - abs(side - sideBias) * 0.18);
      float leafAngle = side * (1.04 - t * 0.46 + 0.10 * curl) + 0.12 * sin(time * 0.06 + fi * 0.8);
      vec2 dir = normalize(axis * 0.20 + normal * side * leafLen + vec2(sin(leafAngle), cos(leafAngle)) * 0.22);
      vec2 leafTip = root + dir * leafLen;
      float width = (0.070 + 0.028 * sin(t * PI)) * (1.0 - t * 0.34);
      field += fernLeaflet(q, root, leafTip, width, gate) * gate * sideGate;
      field += fernLeaflet(q, root + dir * leafLen * 0.18, leafTip + normal * side * 0.035, width * 0.55, gate) * gate * 0.32;
    }
  }
  field += fernFiddlehead(q, tip + normal * 0.08 * curl, 0.42, grow, -angle + curl * 0.7) * (0.50 + 0.35 * (1.0 - grow));
  return field;
}

float fernSpore(vec2 p, vec2 origin, vec2 velocity, float phase, float size) {
  vec2 head = origin + velocity * phase;
  vec2 dir = normalize(velocity + vec2(0.001));
  vec2 q = p - head;
  float along = dot(q, -dir);
  float across = length(q + dir * along);
  float orb = exp(-length(q) / max(size, 0.001));
  float tail = exp(-across / max(size * 0.72, 0.001)) * exp(-max(along, 0.0) * 4.2) * step(0.0, along);
  return (orb * 1.4 + tail * 0.75) * (1.0 - smoothstep(0.72, 1.0, phase));
}

float circleLine(vec2 p, float radius, float width) {
  return 1.0 - smoothstep(width, width * 2.5, abs(length(p) - radius));
}

float arcLine(vec2 p, float radius, float startAngle, float sweep, float width) {
  float a = atan(p.y, p.x);
  float rel = mod(a - startAngle + PI * 2.0, PI * 2.0);
  float line = circleLine(p, radius, width);
  float cap = 1.0 - smoothstep(sweep, sweep + 0.08, rel);
  return line * cap;
}

float polygonLine(vec2 p, float sides, float radius, float width) {
  float a = atan(p.y, p.x) + PI / sides;
  float sector = PI * 2.0 / sides;
  float d = cos(floor(0.5 + a / sector) * sector - a) * length(p);
  return 1.0 - smoothstep(width, width * 2.8, abs(d - radius));
}

float polygonFill(vec2 p, float sides, float radius, float softness) {
  float a = atan(p.y, p.x) + PI / sides;
  float sector = PI * 2.0 / sides;
  float d = cos(floor(0.5 + a / sector) * sector - a) * length(p);
  return 1.0 - smoothstep(radius, radius + softness, d);
}

float wedgeGlyph(vec2 p, float angle, float innerRadius, float outerRadius, float halfAngle) {
  vec2 q = p * rot(-angle);
  float a = abs(atan(q.y, q.x));
  float r = length(q);
  return smoothstep(halfAngle, halfAngle * 0.38, a) * smoothstep(innerRadius, innerRadius + 0.018, r) * (1.0 - smoothstep(outerRadius, outerRadius + 0.030, r));
}

float radioactiveGlyph(vec2 p) {
  float glyph = circleLine(p, 0.34, 0.018) * 0.70;
  glyph += 1.0 - smoothstep(0.050, 0.090, length(p));
  for (int i = 0; i < 3; i++) {
    float a = float(i) * PI * 2.0 / 3.0 + PI * 0.5;
    glyph += wedgeGlyph(p, a, 0.12, 0.31, 0.36) * 0.92;
  }
  return clamp(glyph, 0.0, 1.5);
}

float radioactiveCartoonGlyph(vec2 p, out vec3 glyphColor) {
  vec2 q = p;
  float r = length(q);
  float disc = 1.0 - smoothstep(0.400, 0.438, r);
  float outline = circleLine(q, 0.420, 0.030);
  float bevelOuter = circleLine(q, 0.372, 0.020);
  float bevelInner = circleLine(q, 0.302, 0.010);
  float core = 1.0 - smoothstep(0.052, 0.092, r);
  float wedges = 0.0;
  float wedgeBevel = 0.0;
  for (int i = 0; i < 3; i++) {
    float a = float(i) * PI * 2.0 / 3.0 + PI * 0.5;
    wedges += wedgeGlyph(q, a, 0.118, 0.322, 0.37);
    wedgeBevel += wedgeGlyph(q + vec2(-0.018, 0.020), a, 0.126, 0.302, 0.31);
  }
  float highlight = exp(-dot(q - vec2(-0.150, 0.165), q - vec2(-0.150, 0.165)) * 28.0) * disc;
  float rimLight = (1.0 - smoothstep(-0.10, 0.55, dot(normalize(q + vec2(0.001)), normalize(vec2(-0.7, 0.9))))) * disc;
  float lowerShade = smoothstep(-0.24, 0.50, -q.y + q.x * 0.22) * disc;
  vec3 yellow = mix(vec3(1.00, 0.88, 0.22), vec3(0.62, 0.45, 0.060), lowerShade * 0.56);
  vec3 ink = vec3(0.030, 0.060, 0.034);
  glyphColor = yellow * disc;
  glyphColor = mix(glyphColor, ink, clamp(wedges + core * 0.95, 0.0, 1.0));
  glyphColor += vec3(1.00, 0.96, 0.50) * wedgeBevel * 0.10;
  glyphColor += vec3(1.00, 0.98, 0.62) * highlight * 0.34;
  glyphColor += vec3(0.90, 0.98, 0.42) * rimLight * 0.12;
  glyphColor += vec3(0.00, 0.020, 0.010) * outline * 0.96;
  glyphColor += vec3(1.00, 0.94, 0.40) * bevelOuter * 0.18;
  glyphColor += vec3(0.26, 0.20, 0.03) * bevelInner * 0.12;
  return clamp(disc + outline * 0.55, 0.0, 1.0);
}

float fallingTriangleLayer(vec2 p, out vec3 glyphColor) {
  glyphColor = vec3(0.0);
  float field = 0.0;
  for (int i = 0; i < 18; i++) {
    float fi = float(i);
    vec2 seed = hash2(vec2(fi * 19.13 + 4.0, fi * 7.73 + 2.0));
    vec2 seedB = hash2(seed + fi * 5.91);
    float phase = fract(time * (0.018 + seed.y * 0.009 + globalEnergy * 0.0012) + seedB.y);
    float lane = fract(fi * 0.61803398875 + seed.x * 0.37);
    float stagger = fract(fi * 0.754877666 + seedB.x * 0.41);
    float y = mix(1.20, -1.18, phase);
    float x = mix(-1.44, 1.44, lane);
    x += mix(0.20, -0.46, phase) * (0.55 + seed.x * 0.45);
    x += sin(phase * PI * 2.0 + seed.x * 6.3) * (0.050 + seedB.x * 0.060);
    x += sin(time * (0.035 + seedB.y * 0.035) + fi * 1.37) * 0.035;
    y += (stagger - 0.5) * 0.13 + sin(time * (0.026 + seed.x * 0.024) + fi) * 0.018;
    vec2 pos = vec2(x, y);
    float size = 0.090 + seedB.x * 0.050;
    float roll = -0.25 + seed.x * 0.50 + sin(time * (0.032 + seed.y * 0.028) + fi) * 0.18 + sin(phase * PI * 2.0 + seedB.y) * 0.10;
    vec2 local = (p - pos) * rot(roll) / size;
    float outline = polygonLine(local, 3.0, 0.38, 0.030);
    float fill = polygonFill(local, 3.0, 0.34, 0.035);
    float bevel = polygonLine(local + vec2(-0.030, 0.025), 3.0, 0.30, 0.018);
    vec3 icon = palette60s(0.10 + seed.x * 0.70 + time * 0.003) * fill * 0.18;
    icon += palette60s(0.38 + seedB.y * 0.50) * outline * 0.55;
    icon += vec3(0.95, 0.90, 0.58) * bevel * 0.16;
    float alpha = clamp(outline + fill * 0.18, 0.0, 1.0);
    float edgeFade = smoothstep(-1.16, -0.92, pos.y) * (1.0 - smoothstep(0.92, 1.16, pos.y));
    edgeFade *= smoothstep(-1.70, -1.44, pos.x) * (1.0 - smoothstep(1.44, 1.70, pos.x));
    float dissolveAtKnot = smoothstep(0.40, 0.86, length(pos * vec2(0.88, 1.12)));
    float depthDim = 0.10 + seedB.y * 0.10;
    alpha *= edgeFade * dissolveAtKnot * depthDim;
    glyphColor += icon * alpha;
    field += alpha;
  }
  return clamp(field, 0.0, 2.2);
}

float snowflakeGlyph(vec2 p) {
  float glyph = 0.0;
  for (int i = 0; i < 6; i++) {
    float a = float(i) * PI / 3.0;
    vec2 tip = vec2(cos(a), sin(a)) * 0.39;
    glyph += lineSegment(p, vec2(0.0), tip, 0.012);
    vec2 base = vec2(cos(a), sin(a)) * 0.20;
    vec2 b1 = base + vec2(cos(a + 0.74), sin(a + 0.74)) * 0.13;
    vec2 b2 = base + vec2(cos(a - 0.74), sin(a - 0.74)) * 0.13;
    glyph += lineSegment(p, base, b1, 0.0075) * 0.78;
    glyph += lineSegment(p, base, b2, 0.0075) * 0.78;
  }
  glyph += circleLine(p, 0.12, 0.006) * 0.34;
  return clamp(glyph, 0.0, 1.7);
}

float miniMandelbrotGlyph(vec2 p) {
  vec2 c = p * vec2(2.8, 2.6) + vec2(-0.55, 0.0);
  vec2 z = vec2(0.0);
  float escaped = 0.0;
  float shade = 0.0;
  for (int i = 0; i < 8; i++) {
    z = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c;
    float m = dot(z, z);
    float hit = step(4.0, m) * (1.0 - escaped);
    shade += hit * (1.0 - float(i) / 8.0);
    escaped = max(escaped, hit);
  }
  float body = 1.0 - escaped;
  float edge = smoothstep(0.06, 0.62, shade) * smoothstep(0.98, 0.18, length(p * vec2(1.05, 1.20)));
  return clamp(body * 0.58 + edge, 0.0, 1.3);
}

float crystalGlyph(vec2 p) {
  vec2 q = p * vec2(0.85, 1.18);
  float hex = polygonLine(q, 6.0, 0.34, 0.012);
  float inner = polygonLine(q * rot(PI / 6.0), 6.0, 0.19, 0.007) * 0.58;
  float spine = lineSegment(q, vec2(0.0, -0.35), vec2(0.0, 0.35), 0.006) * 0.70;
  return clamp(hex + inner + spine, 0.0, 1.5);
}

float triangleGlyph(vec2 p) {
  vec2 q = p * rot(0.18);
  float tri = polygonLine(q, 3.0, 0.36, 0.015);
  float fill = polygonFill(q, 3.0, 0.30, 0.028) * 0.18;
  float inner = polygonLine(q * rot(PI), 3.0, 0.18, 0.007) * 0.54;
  return clamp(tri + fill + inner, 0.0, 1.4);
}

float starGlyph(vec2 p) {
  float glyph = 0.0;
  for (int i = 0; i < 4; i++) {
    float a = float(i) * PI * 0.25;
    glyph += lineSegment(p, vec2(cos(a), sin(a)) * -0.34, vec2(cos(a), sin(a)) * 0.34, 0.009);
  }
  glyph += exp(-dot(p, p) * 42.0) * 0.38;
  return clamp(glyph, 0.0, 1.4);
}

float presetGlyph(vec2 p, float mode) {
  if (mode > 14.5 && mode < 15.5) return radioactiveGlyph(p);
  if (mode > 16.5 && mode < 17.5) return snowflakeGlyph(p);
  if (mode > 0.5 && mode < 1.5) return miniMandelbrotGlyph(p);
  if (mode > 3.5 && mode < 4.5) return miniMandelbrotGlyph(p * 0.92);
  if (mode > 12.5 && mode < 13.5) return triangleGlyph(p);
  if (mode > 10.5 && mode < 12.5) return crystalGlyph(p);
  if (mode > 13.5 && mode < 14.5) return crystalGlyph(p * 0.90);
  if (mode > 4.5 && mode < 5.5) return snowflakeGlyph(p * 0.86);
  return starGlyph(p);
}

float fallingGlyphLayer(vec2 p, float mode, float density) {
  vec2 drift = vec2(-time * 0.030, time * 0.044);
  if (mode > 14.5 && mode < 15.5) drift = vec2(-time * 0.020, time * 0.031);
  if (mode > 16.5 && mode < 17.5) drift = vec2(time * 0.012, -time * 0.018);
  float scale = 9.0 + density * 5.0;
  if (mode > 14.5 && mode < 15.5) scale *= 0.58;
  vec2 grid = (p + 1.2 + drift) * scale;
  vec2 cell = floor(grid);
  vec2 local = fract(grid) - 0.5;
  vec2 rnd = hash2(cell + floor(time * 0.075));
  local *= rot((rnd.x - 0.5) * PI * 0.72 + time * (0.018 + rnd.y * 0.035));
  float gateThreshold = 0.72 - density * 0.12;
  if (mode > 14.5 && mode < 15.5) gateThreshold = 0.90 - density * 0.06;
  float gate = smoothstep(gateThreshold, 1.0, hash(cell + vec2(mode * 17.0, 6.13)));
  float size = mix(1.48, 0.92, rnd.y);
  if (mode > 14.5 && mode < 15.5) size = mix(2.22, 1.38, rnd.y);
  float shape = presetGlyph(local / max(size, 0.18), mode);
  float focus = smoothstep(1.50, 0.16, length(p));
  return shape * gate * focus;
}

float sacredGeometry(vec2 p, vec3 state) {
  float angle = atan(p.y, p.x);
  float r = length(p);
  vec2 q = p * rot(state.z * 0.22 + time * 0.006);
  float g = 0.0;
  float base = 0.29 + 0.022 * sin(time * 0.045 + state.x * 1.8);
  float breathe = 1.0 + 0.032 * sin(time * 0.055 + state.z * 2.0);
  q *= breathe;
  g += circleLine(q, 0.33, 0.009) * 1.15;
  g += circleLine(q, 0.55, 0.008) * 1.05;
  g += circleLine(q, 0.78, 0.008) * 0.95;
  for (int i = 0; i < 6; i++) {
    float a = float(i) * PI / 3.0 + state.y * 0.22 + time * 0.004;
    vec2 center = vec2(cos(a), sin(a)) * base;
    g += circleLine(q - center, base, 0.009) * 1.0;
    g += circleLine(q - center * 1.58, base * 0.64, 0.0065) * 0.42;
    g += lineSegment(q, center * 0.12, center * 2.28, 0.006) * 0.48;
  }
  for (int i = 0; i < 12; i++) {
    float a = float(i) * PI / 6.0 - state.x * 0.4;
    vec2 center = vec2(cos(a), sin(a)) * base * 1.72;
    g += circleLine(q - center, base * 0.62, 0.006) * 0.44;
  }
  g += polygonLine(q * rot(0.15 + state.x * 0.34), 3.0, 0.63 + state.z * 0.028, 0.008) * 1.0;
  g += polygonLine(q * rot(PI / 3.0 - state.y * 0.32), 3.0, 0.63 - state.z * 0.028, 0.008) * 1.0;
  g += polygonLine(q, 6.0, 0.83, 0.007) * 0.78;
  g += smoothstep(0.86, 1.0, abs(sin(angle * 12.0 + time * 0.06 + state.x * 1.3))) * (1.0 - smoothstep(0.28, 0.96, r)) * 0.10;
  return clamp(g, 0.0, 2.8);
}

float schrodingerStandingDensity(vec2 p, vec3 state, float phi, out float nodes) {
  float r = length(p);
  float a = atan(p.y, p.x);
  float envelope = exp(-r * r * (0.82 + 0.15 * abs(state.z)));
  float radial1 = sin(PI * (1.08 + 0.08 * state.z) * r + 0.2 * sin(time * 0.08));
  float radial2 = sin(PI * (2.05 + 0.12 * state.x) * r - time * 0.045);
  float radial3 = sin(PI * (2.9 + 0.10 * state.y) * r + bass * 0.36);
  float realPsi = radial1 * cos(2.0 * a - phi * 0.35 - time * 0.16);
  realPsi += state.x * radial2 * cos(3.0 * a + time * 0.24);
  float imagPsi = state.y * radial2 * sin(3.0 * a - time * 0.20);
  imagPsi += state.z * radial3 * sin(4.0 * a + phi * 0.18);
  float density = (realPsi * realPsi + imagPsi * imagPsi) * envelope;
  nodes = (1.0 - smoothstep(0.015, 0.072, abs(realPsi))) * envelope;
  nodes += (1.0 - smoothstep(0.015, 0.068, abs(imagPsi))) * envelope * 0.45;
  return clamp(density, 0.0, 2.0);
}

float comet(vec2 p, vec2 head, vec2 velocity, float size) {
  vec2 dir = normalize(velocity + vec2(0.001, 0.0));
  vec2 tail = p - head;
  float along = dot(tail, -dir);
  float across = length(tail + dir * along);
  float headGlow = exp(-length(p - head) / max(size, 0.001));
  float tailGlow = exp(-across * 32.0 / max(size * 12.0, 0.001)) * exp(-max(along, 0.0) * 2.7) * step(0.0, along);
  return headGlow + tailGlow;
}

vec3 wormholeField(vec2 p) {
  float r = length(p);
  float a = atan(p.y, p.x);
  float depth = time * (0.22 + level * 0.30) + bass * 0.22;
  float ringField = 0.0;
  for (int i = 0; i < 7; i++) {
    float z = (float(i) + fract(depth)) / 7.0;
    float radius = mix(0.18, 1.42, z);
    float wave = 0.030 * sin(a * 8.0 + z * 9.0 + time * 0.28 + bass * 1.8);
    float width = mix(0.018, 0.006, z);
    ringField += circleLine(p, radius + wave, width) * (1.0 - z) * 0.55;
  }

  float wireField = 0.0;
  for (int i = 0; i < 12; i++) {
    float fi = float(i);
    float base = fi * PI / 6.0;
    float wave = 0.035 * sin(r * 8.0 - depth * 5.0 + fi * 0.8 + mids);
    float d = abs(atan(sin(a - base - wave), cos(a - base - wave)));
    wireField += 1.0 - smoothstep(0.008, 0.026, d * max(r, 0.18));
  }

  float tunnelMask = smoothstep(1.55, 0.18, r);
  vec3 wireColor = palette60s(a / (PI * 2.0) + depth * 0.035 + r * 0.18);
  vec3 ringColor = palette60s(0.55 - r * 0.24 + depth * 0.045);
  return (wireColor * wireField * 0.12 + ringColor * ringField * 0.42) * tunnelMask;
}

`;
