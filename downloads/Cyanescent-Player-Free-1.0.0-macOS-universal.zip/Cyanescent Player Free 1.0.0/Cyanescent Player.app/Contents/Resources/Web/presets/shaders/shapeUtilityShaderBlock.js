export const shapeUtilityShaderBlock = `float boxFrame2(vec2 p, vec2 b, float width) {
  vec2 q = abs(p);
  float edge = min(abs(q.x - b.x), abs(q.y - b.y));
  float mask = (1.0 - smoothstep(b.x + width, b.x + width * 2.0, q.x));
  mask *= (1.0 - smoothstep(b.y + width, b.y + width * 2.0, q.y));
  return (1.0 - smoothstep(width, width * 2.8, edge)) * mask;
}

`;
