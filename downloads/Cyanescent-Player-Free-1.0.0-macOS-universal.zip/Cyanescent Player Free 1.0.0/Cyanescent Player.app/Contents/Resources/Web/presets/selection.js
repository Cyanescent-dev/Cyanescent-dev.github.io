import { runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
import { createDiversityCycle } from "../engine/diversityCycle.js";

export function presetIdsFromSelect(select) {
  return Array.from(select?.options || [])
    .filter((option) => option.dataset.playlistAvailable !== "false")
    .map((option) => Number(option.value))
    .filter((value) => runtimeAllowsPreset(value));
}

export function presetCountFromSelect(select) {
  return presetIdsFromSelect(select).length;
}

export function normalizePresetIdFromList(value, ids) {
  ids = ids.filter((id) => runtimeAllowsPreset(id));
  if (!ids.length) return 0;
  const numeric = Number(value);
  if (ids.includes(numeric)) return numeric;
  let best = ids[0];
  let bestDistance = Infinity;
  for (const id of ids) {
    const distance = Math.abs(id - numeric);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = id;
    }
  }
  return best;
}

export function shuffleIntervalMsFromControl(control) {
  const seconds = Math.max(5, Math.min(600, Number(control?.value) || 45));
  if (control) control.value = String(seconds);
  return seconds * 1000;
}

export function chooseNextPresetFromList(ids, activePreset, random = Math.random) {
  if (ids.length <= 1) return activePreset;
  let next = activePreset;
  for (let i = 0; i < 8 && next === activePreset; i += 1) {
    next = ids[Math.floor(random() * ids.length)];
  }
  if (next !== activePreset) return next;
  const index = Math.max(0, ids.indexOf(activePreset));
  return ids[(index + 1) % ids.length];
}

export function createPresetSelectionController({
  select,
  shuffleSecondsControl,
  adaptiveEligiblePresetIds,
  getActivePreset,
  random = Math.random
} = {}) {
  const shuffleDiversity = createDiversityCycle();

  function presetIds() {
    return presetIdsFromSelect(select);
  }

  function presetCount() {
    return presetCountFromSelect(select);
  }

  function normalizePresetId(value) {
    return normalizePresetIdFromList(value, presetIds());
  }

  function eligibleAdaptivePresetIds() {
    return adaptiveEligiblePresetIds?.(presetIds()) || [];
  }

  function shuffleIntervalMs() {
    return shuffleIntervalMsFromControl(shuffleSecondsControl);
  }

  function chooseNextPreset() {
    const ids = presetIds();
    const activePreset = getActivePreset?.();
    const candidates = shuffleDiversity.candidates(ids, { activeId: activePreset });
    if (!candidates.length) return activePreset;
    return candidates[Math.floor(random() * candidates.length)];
  }

  function recordPresetStarted(presetId) {
    shuffleDiversity.record(presetId, presetIds());
  }

  return {
    presetIds,
    presetCount,
    normalizePresetId,
    adaptiveEligiblePresetIds: eligibleAdaptivePresetIds,
    shuffleIntervalMs,
    chooseNextPreset,
    recordPresetStarted,
    resetDiversity: () => shuffleDiversity.reset()
  };
}
