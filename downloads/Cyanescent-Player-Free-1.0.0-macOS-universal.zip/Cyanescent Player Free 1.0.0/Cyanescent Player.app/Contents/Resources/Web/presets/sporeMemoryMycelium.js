// Spore Memory's underground geometry and audio history only. The journey stays
// in its original shader. Geometry is seeded once, never rebuilt on audio/frame.
export const SPORE_MEMORY_PRESET_ID = 343;
export const SPORE_MEMORY_COLONIES = 48;
export const SPORE_MEMORY_BRANCHES = 65;
const TREE_BRANCHES = 63;
export const SPORE_MEMORY_SAMPLES = 8;
export const SPORE_MEMORY_STRIDE = SPORE_MEMORY_SAMPLES + 4;
const STRIDE = SPORE_MEMORY_STRIDE;
const TEXTURE_WIDTH = 256;
const TEXTURE_HEIGHT = Math.ceil((SPORE_MEMORY_COLONIES * (1 + SPORE_MEMORY_BRANCHES * STRIDE)) / TEXTURE_WIDTH);
const cache = new WeakMap();

const add = (a, b) => a.map((v, i) => v + b[i]);
const sub = (a, b) => a.map((v, i) => v - b[i]);
const scale = (a, s) => a.map(v => v * s);
const length = a => Math.hypot(...a);
const unit = a => scale(a, 1 / Math.max(length(a), 1e-9));
const cross = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
const mix = (a, b, t) => add(scale(a, 1-t), scale(b, t));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Number(v) || 0));

export function createSporeMemoryHyphae() {
  let seed = 0x53504f52;
  const random = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const randomUnit = () => unit([random()-.5, random()-.5, random()-.5]);
  const colonies = [];
  for (let c = 0; c < SPORE_MEMORY_COLONIES; c++) {
    // Staggered patches of substrate with jitter larger than the regular cell.
    const origin = [(c % 3 - 1) * 8 + (random()-.5)*6,
      -3.8 - Math.floor(c / 12)*8 - random()*6,
      2 - (Math.floor(c / 3) % 4)*10 - random()*6];
    const branches = [];
    // Older colonies coexist with young ones from the first underground view.
    const colonyDelay = random()*62 - 42;
    for (let b = 0; b < TREE_BRANCHES; b++) {
      const generation = Math.floor(Math.log2(b+1));
      const parent = b ? branches[Math.floor((b-1)/2)] : null;
      const start = parent ? parent.points[SPORE_MEMORY_SAMPLES] : origin;
      const tangent = parent ? parent.tangent : unit([random()-.5, (random()-.65)*.5, random()-.5]);
      const side = unit(cross(tangent, randomUnit()));
      const turn = (b % 2 ? -1 : 1) * (.32 + random()*.60);
      const direction = unit(add(scale(tangent, Math.cos(turn)), scale(side, Math.sin(turn))));
      const span = (2.8 + random()*1.8) * Math.pow(.76, generation);
      const end = add(start, scale(direction, span));
      // Cubic curves preserve the parent's tangent at each bifurcation.
      const controlA = add(start, scale(tangent, span*.38));
      const controlB = add(sub(end, scale(direction, span*.32)), scale(randomUnit(), span*.20));
      const points = [], distances = [0];
      for (let j = 0; j <= SPORE_MEMORY_SAMPLES; j++) {
        const t = j/SPORE_MEMORY_SAMPLES, s = 1-t;
        points.push(add(add(scale(start,s*s*s),scale(controlA,3*s*s*t)),
          add(scale(controlB,3*s*t*t),scale(end,t*t*t))));
        // No filament can protrude above the substrate.
        points[j][1] = Math.min(-.09, points[j][1]);
        if (j) distances.push(distances[j-1]+length(sub(points[j],points[j-1])));
      }
      const birth = parent ? parent.birth + parent.duration : colonyDelay;
      const duration = distances[SPORE_MEMORY_SAMPLES] / (.12 + random()*.07);
      branches.push({points, distances, birth, duration,
        path: parent ? parent.path + parent.distances[SPORE_MEMORY_SAMPLES] : 0,
        radius: (.014 + random()*.008)*Math.pow(.72,generation),
        tangent: unit(sub(points[SPORE_MEMORY_SAMPLES],points[SPORE_MEMORY_SAMPLES-1])), seed: random(), parent: b ? Math.floor((b-1)/2) : -1});
    }
    colonies.push(branches);
  }
  // Two fine anastomoses per patch approach real neighbouring tips; endpoints
  // and birth times are shared, so bridges never hang free before their hosts.
  for (let c = 0; c < colonies.length; c++) {
    for (let j = 0; j < 2; j++) {
      const source = colonies[c][7+j*6];
      let target = null, best = Infinity;
      for (let k = 0; k < colonies.length; k++) {
        if (k === c) continue;
        for (let b = 3; b < TREE_BRANCHES; b++) {
          const candidate = colonies[k][b];
          const distance = length(sub(source.points[SPORE_MEMORY_SAMPLES],candidate.points[SPORE_MEMORY_SAMPLES]));
          if (distance < best) { best = distance; target = candidate; }
        }
      }
      const points = [], distances = [0];
      const bend = scale(randomUnit(), Math.min(best*.18,.6));
      for (let s = 0; s <= SPORE_MEMORY_SAMPLES; s++) {
        points.push(add(mix(source.points[SPORE_MEMORY_SAMPLES],target.points[SPORE_MEMORY_SAMPLES],s/SPORE_MEMORY_SAMPLES), scale(bend, Math.sin(Math.PI*s/SPORE_MEMORY_SAMPLES))));
        points[s][1] = Math.min(-.09, points[s][1]);
        if (s) distances.push(distances[s-1]+length(sub(points[s],points[s-1])));
      }
      colonies[c].push({points, distances,
        birth: Math.max(source.birth+source.duration,target.birth+target.duration),
        duration: distances[SPORE_MEMORY_SAMPLES]/.35, path: source.path+source.distances[SPORE_MEMORY_SAMPLES],
        radius: .004, seed: random(), parent: 7+j*6});
    }
  }
  const data = new Float32Array(TEXTURE_WIDTH*TEXTURE_HEIGHT*4);
  for (let c = 0; c < colonies.length; c++) {
    const branches = colonies[c];
    const center = branches[0].points[0];
    let radius = 0;
    const descendants = b => b >= TREE_BRANCHES || 2*b+1 >= TREE_BRANCHES
      ? [b] : [b,...descendants(2*b+1),...descendants(2*b+2)];
    const order = [...descendants(0),TREE_BRANCHES,TREE_BRANCHES+1];
    for (let record = 0; record < order.length; record++) {
      const b = order[record];
      const branch = branches[b];
      const subtree = descendants(b);
      const subtreeCenter = branch.points[0];
      let subtreeRadius = 0;
      for (const child of subtree) for (const p of branches[child].points) {
        subtreeRadius = Math.max(subtreeRadius,length(sub(p,subtreeCenter)));
      }
      const offset = (SPORE_MEMORY_COLONIES+(c*SPORE_MEMORY_BRANCHES+record)*STRIDE)*4;
      data.set([branch.radius,branch.birth,branch.duration,branch.path],offset);
      data.set([branch.distances[SPORE_MEMORY_SAMPLES],branch.seed,subtree.length,0],offset+4);
      data.set([...subtreeCenter,subtreeRadius+.12],offset+8);
      branch.points.forEach((p,j) => {
        data.set([...p,branch.distances[j]],offset+12+j*4);
        radius = Math.max(radius,length(sub(p,center)));
      });
    }
    data.set([...center,radius+.12],c*4);
  }
  return {data, colonies, width: TEXTURE_WIDTH, height: TEXTURE_HEIGHT};
}

export function createSporeMemoryGrowthState() {
  return {time: 0, age: 29, lastKick: -10, kickHigh: false, serial: 0, pulses: []};
}

function undergroundElapsed(t) {
  const cycle = 320*60/145, start = 80*60/145, end = 248*60/145;
  return Math.floor(t/cycle)*(end-start)+clamp(t%cycle-start,0,end-start);
}

export function advanceSporeMemoryGrowth(state, time, audio = {}) {
  time = Math.max(0,Number(time)||0);
  if (time < state.time - .001) Object.assign(state,createSporeMemoryGrowthState());
  const dt = Math.max(0,undergroundElapsed(time)-undergroundElapsed(state.time));
  const mids = clamp(audio.mids,0,1.25), energy = clamp(audio.energy,0,1.25);
  const kick = clamp(audio.kick,0,1.5), bass = clamp(audio.bass,0,1.35);
  // Integrate positive velocity. Dropping audio never shortens a grown branch.
  state.age += dt*(.42+.48*mids+.28*energy+.65*kick);
  if (kick > .24 && !state.kickHigh && time-state.lastKick > .16 && dt > 0) {
    state.pulses.unshift([time,Math.min(1.6,.35+kick+.25*bass),state.serial++%3,state.serial%5]);
    state.pulses.length = Math.min(8,state.pulses.length);
    state.lastKick = time;
  }
  state.kickHigh = kick > .16;
  state.time = time;
  return state;
}

export function bindSporeMemoryMycelium(gl, program, time, audio, uniformLocation) {
  const activeUnit = gl.getParameter(gl.ACTIVE_TEXTURE);
  let runtime = cache.get(gl);
  if (!runtime || !gl.isTexture(runtime.texture)) {
    const {data,width,height} = createSporeMemoryHyphae();
    const texture = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0+10);
    gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    // Image uploads elsewhere in the renderer leave unpack orientation set.
    // This is structured data, so rows must keep their CPU address order.
    const flipY = gl.getParameter(gl.UNPACK_FLIP_Y_WEBGL);
    const premultiply = gl.getParameter(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA32F,width,height,0,gl.RGBA,gl.FLOAT,data);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,flipY);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,premultiply);
    runtime = {texture,state:createSporeMemoryGrowthState(),pulses:new Float32Array(32)};
    cache.set(gl,runtime);
  }
  const state = advanceSporeMemoryGrowth(runtime.state,time,audio);
  runtime.pulses.fill(0);
  state.pulses.forEach((pulse,i) => runtime.pulses.set(pulse,i*4));
  gl.activeTexture(gl.TEXTURE0+10);
  gl.bindTexture(gl.TEXTURE_2D,runtime.texture);
  gl.uniform1i(uniformLocation(gl,program,"spmHyphaeTexture"),10);
  gl.uniform1f(uniformLocation(gl,program,"spmHyphaAge"),state.age);
  gl.uniform4fv(uniformLocation(gl,program,"spmHyphaPulses[0]"),runtime.pulses);
  gl.activeTexture(activeUnit);
}
