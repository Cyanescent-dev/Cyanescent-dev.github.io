// Preset 274 mathematical journey. Playback and export share this fixed-step model.
const TAU=2*Math.PI;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const ease=x=>{x=clamp(x);return x*x*x*(10+x*(-15+6*x));};
const knots=[[0,.18],[.12,.43],[.25,.70],[.30,.84],[.35,.70],[.55,.40],[.72,.16],[.86,.12],[1,.18]];
// Monotone cubic interpolation: traverse the worlds, pause only at real turnarounds.
const secants=knots.slice(1).map(([x,y],i)=>(y-knots[i][1])/(x-knots[i][0]));
const slopes=knots.map((_,i)=>{
 const a=secants[(i-1+secants.length)%secants.length],b=secants[i%secants.length];
 return a*b<=0?0:2*a*b/(a+b);
});
slopes[slopes.length-1]=slopes[0];
function hermite(a,b,va,vb,h,u){const u2=u*u,u3=u2*u;return (2*u3-3*u2+1)*a+(u3-2*u2+u)*h*va+(-2*u3+3*u2)*b+(u3-u2)*h*vb;}
export function autonomousMnmMorph(t){
 const phase=t*.055+Math.PI*.5*Math.sin(t*.017),p=((phase/TAU+.14)%1+1)%1;
 let i=0;while(i<knots.length-2&&p>knots[i+1][0])i++;
 const [x,a]=knots[i],[y,b]=knots[i+1],h=y-x;
 return hermite(a,b,slopes[i],slopes[i+1],h,(p-x)/h);
}
// Exact critically damped step for a constant target. Build once at a fixed cadence;
// display frames interpolate this immutable path rather than integrating per render.
export function dampedStep(position,velocity,target,omega,dt){
 const y=position-target,j=velocity+omega*y,e=Math.exp(-omega*dt);
 return [target+(y+j*dt)*e,(velocity-omega*j*dt)*e];
}
export function mnmEventsFromAnalysis({drops=[],sections=[],duration=0},repeats=1){
 const events=[];
 for(let r=0;r<repeats;r++){
  const offset=r*duration;
  for(const d of drops)events.push({time:d.time+offset,kind:'drop',strength:d.kind==='major'?1:.60,sourceStrength:d.strength});
  for(let i=1;i<sections.length;i++){
   const a=sections[i-1],b=sections[i],delta=(b.level||0)-(a.level||0);
   if(!delta||b.end-b.start<4||drops.some(d=>Math.abs(d.time-b.start)<5))continue;
   events.push({time:b.start+offset,kind:'section',strength:Math.min(.55,.25+Math.abs(delta)*.1),target:delta>0?.76:.20});
  }
 }
 // Prevent short segmentation fluctuations from becoming repeated transformations.
 return events.sort((a,b)=>a.time-b.time).filter((e,i,a)=>e.kind==='drop'||!a.some((x,j)=>j!==i&&x.kind==='drop'&&Math.abs(x.time-e.time)<5));
}
// The live-input fallback uses the same integrator as analysed-track paths.
export function createMnmStepper({events=[],structuralAudio=true}={}) {
 const eventList=structuralAudio?events.map(e=>({...e})):[],active=[];let eventIndex=0;
 let x=autonomousMnmMorph(0),v=0,f=x,fv=0,riff=0,build=0,newtonResidence=0,returning=false;
 return {
  events:eventList,
  trigger(event){if(structuralAudio)active.push({...event,target:event.target??(x<.48?.84:.14)});},
  advance(t,a={},dt=1/60){
  riff+=(clamp(a.mainRiffState||0)-riff)*(1-Math.exp(-dt/1.2));
  build+=(clamp(a.buildUpState||0)-build)*(1-Math.exp(-dt/1.2));
  while(eventIndex<eventList.length&&eventList[eventIndex].time<=t+1e-9){
   const e=eventList[eventIndex++];e.from=x;e.target=e.target??(x<.48?.84:.14);active.push(e);
  }
  const base=autonomousMnmMorph(t),phrase=.5-.5*Math.cos(TAU*(a.phraseProgress||0));
  let target=base+(structuralAudio?.13*riff*phrase+.13*build:0);
  for(const e of active){
   const age=t-e.time;
   if(age<0||age>12)continue;
   const w=(age<4?ease(age/4):age<5?1:1-ease((age-5)/7))*e.strength;
   target=target*(1-w)+e.target*w;
  }
  // Preserve real excursions; exclude only the near-pure Newton pearl endpoint.
  target=clamp(target,.10,.84);
  // A Newton visit is an excursion, not a plateau. Smoothly leave after four
  // seconds in the upper basin; re-arm only once the musical/autonomous target
  // has returned below it. The damped path keeps position and velocity continuous.
  newtonResidence=x>.78?newtonResidence+dt:0;
  if(newtonResidence>4)returning=true;
  if(returning&&target<.70&&x<.72)returning=false;
  if(returning)target=Math.min(target,.64);
  [x,v]=dampedStep(x,v,target,2.4,dt);
  [f,fv]=dampedStep(f,fv,x,1.6,dt);
  while(active.length&&t-active[0].time>12)active.shift();
  return {morph:x,framing:f,morphVelocity:v,framingVelocity:fv};
  }
 };
}
export function createMnmJourney({duration,sampleAudio,events=[],structuralAudio=true,step=1/60}){
 const count=Math.max(2,Math.ceil(Math.max(0,duration)/step)+1),times=new Float64Array(count),morph=new Float64Array(count),velocity=new Float64Array(count),framing=new Float64Array(count),frameVelocity=new Float64Array(count);
 const state=createMnmStepper({events,structuralAudio});
 for(let i=0;i<count;i++){
  const t=i*step,a=sampleAudio(t)||{},dt=i?step:0;
  const value=state.advance(t,a,dt);
  times[i]=t;morph[i]=value.morph;velocity[i]=value.morphVelocity;framing[i]=value.framing;frameVelocity[i]=value.framingVelocity;
 }
 function sample(t){
  t=clamp(t,0,times[count-1]);const i=Math.min(count-2,Math.floor(t/step)),u=(t-times[i])/step;
  return {morph:hermite(morph[i],morph[i+1],velocity[i],velocity[i+1],step,u),framing:hermite(framing[i],framing[i+1],frameVelocity[i],frameVelocity[i+1],step,u)};
 }
 return {sample,events:state.events,times,morph,velocity,framing,frameVelocity,step,duration};
}
