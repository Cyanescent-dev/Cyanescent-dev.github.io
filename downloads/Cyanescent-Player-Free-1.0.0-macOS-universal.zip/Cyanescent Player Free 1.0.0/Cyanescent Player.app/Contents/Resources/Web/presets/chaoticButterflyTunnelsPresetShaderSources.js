export function createChaoticButterflyTunnelsPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const chaoticButterflyTunnelsFragmentSource = `${modularShaderPrelude}
  ${modularTransitionShaderBlock}

  // ═══════════════════════════════════════════════════════
  // CHAOTIC BUTTERFLY TUNNELS — The Living Butterfly
  // A Lorenz-driven psychedelic tunnel through one enormous butterfly: a chain of giant
  // translucent wing pairs hinged on the creature's spine, with rings of small butterflies,
  // a free swarm and hero butterflies around them. Motion and light come from
  // chaoticButterflyTunnelsDirector.js (cbt* uniforms); without it (cbtDir = 0) the preset
  // runs on gentle clocks of its own.
  // ═══════════════════════════════════════════════════════

  #ifndef CBT_ISO
  #define CBT_ISO 0xffff
  #endif
  #define CBT_ON(bit) ((CBT_ISO & (bit)) != 0)
  #define TAU 6.28318530718
  #define CBT_SPACING 0.7
  #define CBT_GAP 0.06

  uniform float cbtDir;
  uniform vec4 cbtWingA;   // psi (wingbeat phase), depth, posture, membrane flexibility
  uniform vec4 cbtWingB;   // travelling-wave constant, left/right asymmetry, tremor, tremor phase
  uniform vec4 cbtUnfurl;  // seconds since the drop, strength, style, surge
  uniform vec4 cbtTravel;  // slice index, slice fraction, speed, journey clock
  uniform vec4 cbtLight;   // kick age, kick strength, kick side, treble shimmer
  uniform vec4 cbtGlow;    // build-light phase, build-light amount, pre-drop gathering, hue drift
  uniform vec4 cbtMood;    // calm, gathering, flight, breath
  uniform vec4 cbtSwarm;   // swarm travel, activity, flap phase, orbit phase
  uniform vec4 cbtCam;     // journey clock, bank, concentration, slow bass
  uniform vec4 cbtFeed;    // feedback decay, zoom, rotation, slow mids

  vec4 gWingA, gWingB, gUnfurl, gTravel, gLight, gGlow, gMood, gSwarm, gCam, gFeed;

  void cbtControls() {
    if (cbtDir > 0.5) {
      gWingA = cbtWingA; gWingB = cbtWingB; gUnfurl = cbtUnfurl; gTravel = cbtTravel; gLight = cbtLight;
      gGlow = cbtGlow; gMood = cbtMood; gSwarm = cbtSwarm; gCam = cbtCam; gFeed = cbtFeed;
      return;
    }
    // no director (pipeline warm-up, a host without it): calm, continuous clocks
    float t = presetTime;
    float d = t * 0.3 / CBT_SPACING;
    gWingA = vec4(t * 0.75, 0.55, 0.6, 0.6);
    gWingB = vec4(0.4, 0.16, 0.0, 0.0);
    gUnfurl = vec4(99.0, 0.0, 0.0, 0.0);
    gTravel = vec4(floor(d), fract(d), 0.3, t * 0.8);
    gLight = vec4(9.0, 0.0, 0.0, 0.2);
    gGlow = vec4(t * 0.3, 0.0, 0.0, t * 0.006);
    gMood = vec4(0.3, 0.2, 0.4, 0.0);
    gSwarm = vec4(t * 0.35, 0.4, t * 4.4, t * 0.36);
    gCam = vec4(t * 0.8, 0.12 * sin(t * 0.18), 0.0, 0.5);
    gFeed = vec4(0.89, 0.991, 0.005, 0.5);
  }

  // ─── HASHING & NOISE ─────────────────────────────────

  float hash1(float n) { return fract(sin(n) * 43758.5453123); }

  float hash3(vec3 p) {
    p = fract(p * vec3(443.897, 397.297, 491.187));
    p += dot(p, p.yxz + 19.19);
    return fract(p.x * p.y * p.z);
  }

  float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(mix(hash3(i), hash3(i + vec3(1, 0, 0)), f.x),
          mix(hash3(i + vec3(0, 1, 0)), hash3(i + vec3(1, 1, 0)), f.x), f.y),
      mix(mix(hash3(i + vec3(0, 0, 1)), hash3(i + vec3(1, 0, 1)), f.x),
          mix(hash3(i + vec3(0, 1, 1)), hash3(i + vec3(1, 1, 1)), f.x), f.y),
      f.z);
  }

  float fbm3(vec3 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) { v += a * noise3(p); p *= 2.1; a *= 0.5; }
    return v;
  }

  float sq(float x) { return x * x; }
  float smin(float a, float b, float k) {
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
  }
  float sdCapsule(vec2 p, vec2 a, vec2 b, float r) {
    vec2 pa = p - a, ba = b - a;
    float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    return length(pa - ba * h) - r;
  }
  float sdEll(vec2 p, vec2 c, vec2 r, float a) {
    p -= c;
    float ca = cos(a), sa = sin(a);
    p = vec2(ca * p.x + sa * p.y, -sa * p.x + ca * p.y);
    return (length(p / r) - 1.0) * min(r.x, r.y);
  }

  // ─── LORENZ CAMERA ───────────────────────────────────
  // On the director's journey clock: smooth, never displaced by kicks or bass.

  vec3 lorenzCamera(float t) {
    float phase = t * 0.2;
    float lobePhase = sin(phase * 0.7);
    float lobe = smoothstep(-0.1, 0.1, lobePhase);

    vec3 rightCenter = vec3(8.5, 8.5, 27.0);
    vec3 leftCenter  = vec3(-8.5, -8.5, 27.0);

    float orbitPhase = phase * 1.8;

    vec3 rightPos = rightCenter + vec3(
      cos(orbitPhase) * 6.0,
      sin(orbitPhase) * 6.0,
      sin(orbitPhase * 0.7) * 4.0
    );
    vec3 leftPos = leftCenter + vec3(
      cos(orbitPhase + PI) * 6.0,
      sin(orbitPhase + PI) * 6.0,
      sin(orbitPhase * 0.7 + PI) * 4.0
    );
    return mix(leftPos, rightPos, lobe);
  }

  // ─── COLOUR ──────────────────────────────────────────

  vec3 butterflyPalette(float t, float lobe) {
    vec3 cyan = vec3(0.05, 0.72, 0.98);
    vec3 electricBlue = vec3(0.15, 0.35, 1.0);
    vec3 cyanLobe = mix(cyan, electricBlue, sin(t * PI) * 0.5 + 0.5);

    vec3 amber = vec3(0.98, 0.62, 0.06);
    vec3 gold = vec3(1.0, 0.85, 0.2);
    vec3 orangeLobe = mix(amber, gold, sin(t * PI + 1.0) * 0.5 + 0.5);

    vec3 magenta = vec3(0.92, 0.08, 0.72);

    float crossover = exp(-lobe * lobe * 8.0);
    vec3 col = mix(cyanLobe, orangeLobe, smoothstep(-1.0, 1.0, lobe));
    col = mix(col, magenta, crossover * 0.65);
    return col;
  }

  // ─── BUTTERFLY SDF — ORGANIC HINGED WINGS ────────────

  // Rotates point p around a hinge at pivot by angle a
  vec2 hingeRotate(vec2 p, vec2 pivot, float a) {
    vec2 q = p - pivot;
    float ca = cos(a), sa = sin(a);
    return vec2(q.x * ca - q.y * sa, q.x * sa + q.y * ca) + pivot;
  }

  // Wing vein pattern: procedural internal structure
  float wingVeins(vec2 p, float seed) {
    float r = length(p);
    float a = atan(p.y, p.x);
    float vein1 = abs(sin(a * 5.0 + seed * 2.0)) * 0.5;
    float vein2 = abs(sin(r * 18.0 - a * 3.0 + seed)) * 0.3;
    float veins = smoothstep(0.06, 0.0, vein1 * vein2);
    float cross1 = abs(sin(r * 25.0 + seed * 1.3));
    veins += smoothstep(0.08, 0.0, cross1 * 0.3) * 0.3;
    return veins;
  }

  // Full butterfly SDF with hinged wings and organic shape
  // Returns: x = distance, y = wing vein intensity, z = wing fill mask
  vec3 butterflyFull(vec2 p, float flapUpper, float flapLower, float seed, bool enableVeins) {
    vec2 q = vec2(abs(p.x), p.y);

    float bodyLen = 0.14;
    float bodyW = 0.022;
    float body = length(vec2(q.x, max(abs(q.y) - bodyLen, 0.0))) - bodyW;

    vec2 hingeUpper = vec2(bodyW + 0.005, 0.04);
    vec2 hingeLower = vec2(bodyW + 0.005, -0.05);

    // Upper wing with hinge rotation — wing tip lags
    float tipLag = sin(flapUpper * 1.3 + 0.5) * 0.15;
    vec2 uwPivot = hingeUpper;
    vec2 uwQ = hingeRotate(q, uwPivot, flapUpper * 0.3);
    vec2 uwCenter = uwPivot + vec2(0.18, 0.06);
    vec2 uwSize = vec2(0.20, 0.15);
    vec2 uwLocal = (uwQ - uwCenter) / uwSize;
    float scallop = 1.0 + 0.06 * sin(atan(uwLocal.y, uwLocal.x) * 5.0 + seed);
    float upperWing = (length(uwLocal) * scallop - 1.0) * min(uwSize.x, uwSize.y);
    vec2 tipQ = hingeRotate(q, uwPivot, (flapUpper + tipLag) * 0.35);
    vec2 tipCenter = uwPivot + vec2(0.32, 0.13);
    float tipExt = length((tipQ - tipCenter) / vec2(0.07, 0.04)) - 1.0;
    tipExt *= 0.04;
    upperWing = min(upperWing, tipExt);

    // Lower wing with separate hinge — smaller, rounder
    float lowerLag = sin(flapLower * 1.1 + 0.3) * 0.1;
    vec2 lwQ = hingeRotate(q, hingeLower, flapLower * 0.25 + lowerLag);
    vec2 lwCenter = hingeLower + vec2(0.13, -0.06);
    vec2 lwSize = vec2(0.14, 0.09);
    vec2 lwLocal = (lwQ - lwCenter) / lwSize;
    float lwScallop = 1.0 + 0.08 * sin(atan(lwLocal.y, lwLocal.x) * 4.0 + seed * 1.3);
    float lowerWing = (length(lwLocal) * lwScallop - 1.0) * min(lwSize.x, lwSize.y);

    // Antennae: graceful curves
    vec2 antBase = vec2(0.0, bodyLen + 0.01);
    vec2 antTip = vec2(0.06 + 0.02 * sin(seed), 0.26);
    vec2 antMid = vec2(0.03, 0.20);
    vec2 antDir1 = antMid - antBase;
    float antT1 = clamp(dot(q - antBase, antDir1) / dot(antDir1, antDir1), 0.0, 1.0);
    float ant1 = length(q - antBase - antDir1 * antT1) - 0.006;
    vec2 antDir2 = antTip - antMid;
    float antT2 = clamp(dot(q - antMid, antDir2) / dot(antDir2, antDir2), 0.0, 1.0);
    float ant2 = length(q - antMid - antDir2 * antT2) - 0.004;
    float antBulb = length(q - antTip) - 0.008;
    float antenna = min(min(ant1, ant2), antBulb);

    float wings = min(upperWing, lowerWing);
    float dist = min(min(wings, body), antenna);
    float wingFill = 1.0 - smoothstep(-0.01, 0.005, wings);

    float veins = 0.0;
    if (enableVeins && wings < 0.03) {
      vec2 veinUV = (q - vec2(0.15, 0.0)) * 6.0;
      veins = wingVeins(veinUV, seed) * wingFill;
    }
    return vec3(dist, veins, wingFill);
  }

  // ─── THE GIANT WINGS ─────────────────────────────────
  // Each slice of the tunnel is one wing pair of the enormous butterfly: a forewing and a
  // hindwing per side, hinged on a vertical line beside the spine (x = +-CBT_GAP), the tips
  // swept towards the viewer by the stroke angle phi (folded ~70 degrees: walls closing in
  // around the camera; open ~6 degrees: spread across the view). The membrane is a ruled
  // surface whose chord angle varies along the span, so the roots lead and the tips follow.

  // One stroke over a turn of psi: a fast opening from the roots (38%), a suspended extension
  // (12%) and a slower recovery that eases into the next stroke (50%). Quintic pieces: velocity
  // and acceleration are continuous; the tips' lag adds the settling.
  float s5(float x) { x = clamp(x, 0.0, 1.0); return x * x * x * (x * (x * 6.0 - 15.0) + 10.0); }
  float cbtStroke(float psi) {
    float u = fract(psi / TAU);
    if (u < 0.38) return s5(u / 0.38);
    if (u < 0.50) { float b = sin(PI * (u - 0.38) / 0.12); return 1.0 + 0.025 * b * b; }
    return 1.0 - s5((u - 0.50) / 0.50);
  }

  // The unfurling's weight over its own clock (mirrors unfurlWeight in the director).
  float cbtUnfurlW(float t) {
    if (t < 0.0) return 0.0;
    return smoothstep(0.0, 1.1, t) * (1.0 - smoothstep(2.2, 6.5, t));
  }

  // Openness (0 folded .. 1 open, beyond 1 swept back) at span s, height y of one wing.
  float cbtOpenness(float psiS, float tauS, float s, float y, float lag) {
    float hind = smoothstep(0.05, -0.25, y);          // the hindwing follows a little later
    float O = gWingA.z + gWingA.y * (cbtStroke(psiS - lag * (s + 0.35 * hind)) - 0.5);
    float tu = tauS - 0.38 * s - 0.12 * hind;          // the unfurling: roots first
    float uw = cbtUnfurlW(tu) * gUnfurl.y;
    float over = 1.06 + 0.12 * sin(PI * clamp((tu - 0.4) / 1.6, 0.0, 1.0));
    return mix(O, over, clamp(uw, 0.0, 1.0));
  }

  // Chord angle of the membrane from the hinge to span s.
  float cbtPhi(float psiS, float tauS, float s, float y, float lag, float seed) {
    float O = cbtOpenness(psiS, tauS, 0.55 * s, y, lag);
    float phi = mix(1.22, 0.10, O);
    // one coherent ripple running out along the span with the stroke, and pre-drop tremors
    phi += 0.022 * gWingA.w * gWingA.y * s * sin(6.0 * s - 2.0 * psiS);
    phi += gWingB.z * 0.035 * s * s * sin(gWingB.w + 7.0 * s + seed);
    return clamp(phi, -0.25, 1.38);
  }

  // The wing outline in wing space w = (span, height). region: 0 forewing, 1 hindwing.
  float cbtWingShape(vec2 w, float seed, out float region) {
    float fore = sdEll(w, vec2(0.52, 0.37), vec2(0.64, 0.30), 0.62);
    float hind = sdEll(w, vec2(0.40, -0.25), vec2(0.47, 0.32), -0.55);
    float tail = sdCapsule(w, vec2(0.64, -0.50), vec2(0.80, -0.80), 0.028);
    hind = smin(hind, tail, 0.06);
    region = smoothstep(-0.03, 0.03, fore - hind);
    float d = smin(fore, hind, 0.05);
    float a = atan(w.y, w.x + 0.05);
    d += 0.011 * sin(a * 15.0 + seed) * smoothstep(0.35, 0.85, length(w));
    return max(d, -w.x);
  }

  // Shades one wing. side +1 right, -1 left. Returns premultiplied colour.
  vec3 cbtWing(vec2 q, float zc, vec2 c, float side, float psiS, float tauS, float lag, float seed, float n, float sliceFade, float detail) {
    float X = side * q.x, CX = side * c.x;
    // the span's sign does not depend on the angle: rays on the other side of this wing's hinge
    // never reach it (half of every slice's pixels per wing)
    float num = X * zc - CX - CBT_GAP;
    if (num < -0.03) return vec3(0.0);
    float phi = cbtPhi(psiS, tauS, 0.6, q.y * zc - c.y, lag, seed);
    float sp = -1.0, y = 0.0, z = 0.0, den = 1.0;
    for (int k = 0; k < 2; k++) {
      float cp = cos(phi), sn = sin(phi);
      den = cp + X * sn;
      sp = num / max(den, 1e-3);
      z = zc - sp * sn;
      y = q.y * z - c.y;
      phi = cbtPhi(psiS, tauS, clamp(sp, 0.0, 1.4), y, lag, seed);
    }
    if (den < 0.02 || z < 0.04 || sp < -0.03 || sp > 1.3 || abs(y) > 1.0) return vec3(0.0);

    vec2 w = vec2(sp, y);
    float region;
    float d = cbtWingShape(w, seed, region);
    // screen footprint of a pixel on the membrane, in wing units
    vec3 nrm = vec3(side * sin(phi), 0.0, cos(phi));
    vec3 rdn = normalize(vec3(q, 1.0));
    float facing = abs(dot(nrm, rdn));
    float fres = 1.0 - facing;
    float aa = 2.4 * z / (1.3 * resolution.y * max(facing, 0.22));
    if (d > 0.08 + aa) return vec3(0.0);

    float inside = 1.0 - smoothstep(-aa, aa, d);
    vec2 rv = w - vec2(0.0, 0.02);
    float r = length(rv);
    float a = atan(rv.y, rv.x);

    // veins: radial from the root, branching beyond the discal cell, a cross vein and a
    // submarginal line that follows the outline
    float vw = 0.003 + 0.003 * r;
    float ac = a - 0.18 * r * r * sin(a * 1.5 + 0.4);         // veins curve back towards the margin
    float spacing = 0.30;
    float da = (fract((ac + 1.25) / spacing) - 0.5) * spacing * r;
    float da2 = (fract((ac + 1.25) / spacing * 2.0) - 0.5) * spacing * 0.5 * r;
    float vein = 1.0 - smoothstep(vw, vw + aa, abs(da));
    vein = max(vein, 0.7 * (1.0 - smoothstep(vw * 0.8, vw * 0.8 + aa, abs(da2))) * smoothstep(0.50, 0.66, r));
    vein *= smoothstep(0.08, 0.30, r) * (0.6 + 0.4 * smoothstep(0.3, 0.7, r));
    float cell = (1.0 - smoothstep(vw, vw + aa, abs(r - 0.36 - 0.025 * sin(a * 5.0 + seed)))) * smoothstep(0.0, 0.05, -d);
    float sub = 1.0 - smoothstep(0.003, 0.003 + aa, abs(d + 0.07));
    float veins = max(vein, max(cell * 0.7, sub * 0.6)) * inside;

    // margin spots and soft eyespots
    float cellA = (fract(a * 6.0 + 0.5) - 0.5) / 6.0 * r;
    float spots = (1.0 - smoothstep(0.009, 0.009 + aa, length(vec2(cellA, d + 0.032)))) * inside;
    float eyeH = length(w - vec2(0.47, -0.30));
    float eyeF = length(w - vec2(0.82, 0.55));
    float eyeCore = exp(-sq(eyeH / 0.028)) + 0.7 * exp(-sq(eyeF / 0.02));
    float eyeRing = exp(-sq((eyeH - 0.052) / 0.010)) + 0.6 * exp(-sq((eyeF - 0.036) / 0.008));

    // colour: mauve and magenta membranes, electric-blue margins, pearlescent sheen
    float hueT = gGlow.w + n * 0.071 + side * 0.04;
    vec3 mauve = vec3(0.55, 0.16, 0.80);
    vec3 magenta = vec3(0.92, 0.10, 0.70);
    vec3 eblue = vec3(0.20, 0.38, 1.0);
    vec3 cyan = vec3(0.05, 0.72, 0.98);
    vec3 gold = vec3(1.0, 0.78, 0.25);
    vec3 memb = mix(mauve, magenta, 0.5 + 0.5 * sin(hueT * TAU * 0.5 + r * 2.4));
    memb = mix(memb, eblue * 0.85, 0.28 * region);
    vec3 iri = 0.5 + 0.5 * cos(TAU * (fres * 0.9 + r * 0.35 + hueT * 0.3) + vec3(0.0, 2.1, 4.2));
    memb = mix(memb, iri * vec3(0.85, 0.55, 1.0), 0.30 * fres);
    float wake = gMood.w;
    float membA = (0.066 + 0.09 * fres * fres) * (1.0 + 0.8 * wake);

    // light along the veins
    float L = 0.11 + 0.05 * gMood.x;
    // kick: a front from the root through one wing of the slice in front of the camera
    float wK = detail * (side * (gLight.z * 2.0 - 1.0) > 0.0 ? 0.7 : 0.15);
    L += gLight.y * wK * (1.5 * exp(-sq((r - 0.05 - 2.2 * gLight.x) / 0.10)) + 0.35) * exp(-gLight.x / 0.55);
    // the unfurling: a wave of light racing out from the roots
    float uL = gUnfurl.y * cbtUnfurlW(tauS + 0.3);
    L += gUnfurl.y * 2.2 * exp(-sq((r + 0.1 - 1.8 * tauS) / 0.16)) * (1.0 - smoothstep(1.0, 2.0, tauS)) + 0.45 * uL;
    // the breath: light gathering in along the veins towards the roots
    L += gGlow.z * (0.16 + 0.34 * (0.5 + 0.5 * sin(r * 16.0 + gGlow.x * 7.0))) * (1.25 - 0.6 * r);
    // builds: restrained bands of light running in from the tips towards the roots
    float rb = 1.25 - fract(gGlow.x * 0.35) * 1.45;
    float band = exp(-sq((r - rb) / 0.12)) * gGlow.y * 0.6;
    L += band;
    // the unfurling's pulse: the whole membrane lights as the movement passes this slice
    // (tauS is delayed by depth, so the light travels down the tunnel with the wings)
    float pulse = gUnfurl.y * smoothstep(0.0, 0.35, tauS) * (1.0 - smoothstep(0.7, 2.6, tauS));
    L += 0.8 * pulse;
    vec3 veinCol = mix(vec3(1.0, 0.32, 0.82), vec3(0.62, 0.70, 1.0), region * 0.5);
    veinCol = mix(veinCol, gUnfurl.z > 0.5 ? cyan * 1.2 : gold, 0.55 * clamp(uL, 0.0, 1.0));

    // (no outline along the root clip at the hinge: it drew a seam down the spine)
    float rootFade = smoothstep(0.03, 0.14, sp);
    float outline = exp(-abs(d) / (0.005 + 0.8 * aa)) * rootFade;
    float halo = exp(-max(d, 0.0) * 28.0) * (1.0 - inside) * 0.22 * rootFade;
    vec3 edgeCol = mix(eblue, cyan, 0.5 + 0.5 * sin(seed * 1.7 + hueT * 3.0));
    float sparkle = 0.25 + 1.5 * gLight.w * (0.5 + 0.5 * sin(time * 9.0 + a * 40.0 + seed * 3.0));

    vec3 pulseCol = gUnfurl.z > 0.5 ? vec3(0.35, 0.75, 1.0) : vec3(1.0, 0.55, 0.85);
    memb = mix(memb, pulseCol, 0.45 * pulse);
    vec3 col = memb * membA * inside * (1.0 + 0.6 * band + 0.4 * uL + 1.15 * pulse)
             + edgeCol * (outline * (0.30 + 0.25 * fres) + halo) * (0.8 + 0.6 * wake)
             + veinCol * veins * L * 0.32 * detail
             + mix(cyan, gold, region) * spots * sparkle * 0.30 * detail
             + (gold * eyeCore * 0.22 + cyan * eyeRing * 0.22) * inside * (0.5 + 0.5 * L) * detail;
    float hitFade = smoothstep(0.04, 0.32, z);
    return col * sliceFade * hitFade;
  }

  // The butterflies of a ring are far apart (each spans about a tenth of the spacing), so only
  // the one in this pixel's angular sector can be seen: one evaluation per ring, not numBf.
  vec2 butterflyGate(vec2 p, float gateRadius, float flapPhase, float numBf,
                     float rotOffset, float seed, float bfScale) {
    float sector = PI * 2.0 / numBf;
    float fi = mod(floor((atan(p.y, p.x) - rotOffset) / sector + 0.5), numBf);
    float angle = fi * sector + rotOffset;
    float bfPhase = flapPhase * (0.85 + 0.3 * hash1(seed + fi * 2.3)) + fi * 1.3 + hash1(seed + fi * 7.7) * PI;
    float flapUpper = sin(bfPhase) * 0.8;
    float flapLower = sin(bfPhase * 0.85 + 0.4) * 0.6;
    vec2 localP = p - vec2(cos(angle), sin(angle)) * gateRadius;
    float sizeVar = 0.85 + hash1(seed + fi * 3.1) * 0.3;
    float scale = gateRadius * bfScale * sizeVar;
    float rotA = -angle - PI * 0.5 + sin(bfPhase * 0.5) * 0.15;
    float ca = cos(rotA), sa = sin(rotA);
    localP = vec2(localP.x * ca - localP.y * sa, localP.x * sa + localP.y * ca);
    vec3 bf = butterflyFull(localP / scale, flapUpper, flapLower, seed + fi, quality > 0.5);
    return vec2(bf.x * scale, bf.y);
  }

  // ─── HERO BUTTERFLY ──────────────────────────────────

  vec3 renderHeroButterfly(vec2 p, float idx, float t) {
    float seed = idx * 13.37;
    float phase = t * (1.2 + hash1(seed) * 0.8) * 0.8 + seed;

    float flap = gSwarm.z * (1.15 + 0.2 * hash1(seed + 1.0)) + seed;
    float flapUpper = sin(flap) * (0.9 + 0.2 * gSwarm.y);
    float flapLower = sin(flap * 0.85 + 0.4) * (0.7 + 0.15 * gSwarm.y);

    float xSwing = sin(phase * 0.3 + idx * 2.5) * 1.2;
    float ySwing = sin(phase * 0.4 + idx * 1.7) * 0.6 + cos(phase * 0.15) * 0.2;
    vec2 heroCenter = vec2(xSwing, ySwing) * (1.0 - 0.25 * gCam.z);

    float heroSize = (0.25 + sin(phase * 0.2) * 0.03) * 2.0 * (1.0 + 0.05 * gCam.w);

    float bankAngle = cos(phase * 0.3 + idx * 2.5) * 0.4;
    vec2 localP = p - heroCenter;
    float ca = cos(bankAngle), sa = sin(bankAngle);
    localP = vec2(localP.x * ca - localP.y * sa, localP.x * sa + localP.y * ca);

    vec3 bf = butterflyFull(localP / heroSize, flapUpper, flapLower, seed, true);
    float bfDist = bf.x * heroSize;

    float heroLobe = sin(phase * 0.2 + idx * PI);
    vec3 heroCol = butterflyPalette(phase * 0.05 + idx * 0.3, heroLobe);

    float outline = 1.0 - smoothstep(0.0, 0.008, bfDist);
    float edgeGlow = exp(-max(0.0, bfDist) * 60.0) * 0.6;
    float innerGlow = bf.z * (0.15 + bf.y * 0.4);
    float veinShimmer = bf.y * gLight.w * 1.5 * (sin(time * 15.0 + idx * 4.0) * 0.5 + 0.5);

    vec3 result = heroCol * (outline * 1.2 + edgeGlow + innerGlow + veinShimmer);

    float trailLen = 0.5 + gMood.z * 0.3;
    vec2 trailDir = vec2(-cos(phase * 0.3 + idx * 2.5), -cos(phase * 0.4 + idx * 1.7)) * 0.3;
    for (int ti = 1; ti < 5; ti++) {
      float tfi = float(ti);
      vec2 trailP = heroCenter + trailDir * tfi * 0.12 * trailLen * 2.0;
      float trailDist = length(p - trailP);
      float trailGlow = exp(-trailDist * 25.0) * exp(-tfi * 0.5) * 0.2;
      result += heroCol * trailGlow * (0.4 + gMood.z * 0.6);
    }
    return result;
  }

  // ─── MAIN ────────────────────────────────────────────

  void main() {
    cbtControls();
    vec2 uv = gl_FragCoord.xy / resolution;
    vec2 p = (gl_FragCoord.xy * 2.0 - resolution) / min(resolution.x, resolution.y);

    // Feedback: slow values only (the original zoomed on every kick)
    float transitionStrength = sin(clamp(transitionPhase, 0.0, 1.0) * PI);
    float identityPresence = transitionIdentityPresence();
    float decay = gFeed.x;
    vec2 fuv = p * rot(gFeed.z * feedbackStep) * feedbackZoom(gFeed.y);
    fuv = clamp(fuv * 0.5 + 0.5, vec2(0.001), vec2(0.999));
    vec3 prev = samplePreviousFrame(fuv, p, feedbackRetain(mix(decay, 0.78, transitionStrength)));

    // ═══ CAMERA ═══
    float J = gCam.x;
    vec3 camPos = lorenzCamera(J) * 0.06;
    vec3 camTarget = lorenzCamera(J + 0.15) * 0.06;
    vec3 ww = normalize(camTarget - camPos);
    vec3 uu = normalize(cross(ww, vec3(0.0, 1.0, 0.0)));
    vec3 vv = normalize(cross(uu, ww));
    float bank = gCam.y;
    vec3 uuB = uu * cos(bank) + vv * sin(bank);
    vec3 vvB = -uu * sin(bank) + vv * cos(bank);
    vec3 rd = normalize(p.x * uuB + p.y * vvB + 1.3 * ww);

    float lobeSign = sign(camPos.x);
    float lobeSmooth = clamp(camPos.x * 2.0, -1.0, 1.0);
    vec3 col = vec3(0.0);
    vec2 q0 = p / 1.3;
    // the tunnel bends towards the Lorenz lobe the camera is in
    vec2 bend = vec2(0.05 * lobeSmooth, 0.022 * sin(J * 0.21));
    float tau = gUnfurl.x;
    float wakeG = gMood.w;

    // ═══ LAYER 1: THE GIANT BUTTERFLY ═══
    // One enormous wing pair around the viewer, at a fixed depth: the tunnel's background. (The
    // first Living Butterfly flew a chain of 6-8 pairs past the camera; their overlapping
    // silhouettes and veins at different phases read as a crowd of giants.) A single faint,
    // detail-free echo deeper in the tunnel keeps the depth without competing.
    if (CBT_ON(256)) {
      float lag = 0.55 + 0.6 * gWingA.w;
      float hz = 1.15;
      vec2 c = bend * hz * hz;
      float roll = 0.05 * sin(J * 0.21);
      vec2 q = q0 * mat2(cos(roll), -sin(roll), sin(roll), cos(roll));
      float psiS = gWingA.x + gWingB.x * hz;
      col += cbtWing(q, hz, c, 1.0, psiS + gWingB.y, tau, lag * 1.1, 1.3, 0.0, 1.0, 1.0);
      col += cbtWing(q, hz, c, -1.0, psiS, tau - 0.04, lag, 3.0, 0.0, 1.0, 1.0);
      vec2 bq = q * hz - c;
      float body = sdCapsule(bq, vec2(0.0, -0.28), vec2(0.0, 0.20), 0.022);
      col += vec3(0.45, 0.20, 0.95) * exp(-max(body, 0.0) * 55.0) * 0.10 * (1.0 + wakeG);
      if (quality > 0.5) {
        float ez = 3.4;
        vec2 ec = bend * ez * ez;
        float psiE = gWingA.x + gWingB.x * ez;
        float tauE = tau - 0.35;
        col += cbtWing(q, ez, ec, 1.0, psiE + gWingB.y, tauE, lag * 1.1, 1.3, 1.0, 0.16, 0.0);
        col += cbtWing(q, ez, ec, -1.0, psiE, tauE, lag, 3.0, 1.0, 0.16, 0.0);
      }
    }

    // ═══ LAYER 2: RINGS OF SMALL BUTTERFLIES ═══
    if (CBT_ON(1)) {
      int numGates = quality > 0.5 ? 6 : 5;
      float numBf = quality > 0.5 ? 7.0 : 6.0;
      for (int gi = 0; gi < 6; gi++) {
        if (gi < numGates) {
          float fi = float(gi);
          float zg = (fi + 1.5 - gTravel.y) * CBT_SPACING;
          float n = gTravel.x + fi + 1.0;
          vec2 gateUV = q0 * zg - bend * zg * zg;
          float gateR = 1.32 * (1.0 + 0.06 * sin(n * 1.3));
          float gateRot = J * 0.06 + n * 0.45;
          float gateSeed = mod(n, 512.0) * 5.7 + 1.23;
          vec2 gate = butterflyGate(gateUV, gateR, gSwarm.z + n * 0.5, numBf, gateRot, gateSeed, 0.24);
          float fade = smoothstep(0.25, 0.8, zg) * (1.0 - smoothstep(float(numGates) * CBT_SPACING, (float(numGates) + 1.0) * CBT_SPACING, zg)) * exp(-zg * 0.25);
          float px = 2.0 * zg / (1.3 * resolution.y);
          float outline = 1.0 - smoothstep(0.0, 0.004 + px, gate.x);
          float edgeGlow = exp(-max(0.0, gate.x) * 45.0) * 0.4;
          float fillGlow = smoothstep(0.02, -0.005, gate.x) * 0.12;
          float veinGlow = gate.y * smoothstep(0.02, -0.01, gate.x);
          float gateLobe = lobeSign * 0.7 + sin(n * 0.8) * 0.3;
          vec3 gateColor = butterflyPalette(n * 0.12 + J * 0.03, gateLobe);
          vec3 veinColor = butterflyPalette(n * 0.12 + 0.3, gateLobe) * 1.4;
          col += (gateColor * (outline * 0.8 + edgeGlow + fillGlow)
                + veinColor * veinGlow * (0.4 + gLight.w * 0.8)) * fade * (0.55 + 0.25 * gMood.z);
        }
      }
    }

    // ═══ LAYER 3: BUTTERFLY SWARM ═══
    // They fly ahead of the camera more slowly than it travels, so they approach, pass to the
    // side and fade; their size is capped near the camera and speeds are bounded.
    if (CBT_ON(2)) {
      int numSwarm = quality > 0.5 ? 20 : 12;
      for (int si = 0; si < 20; si++) {
        if (si < numSwarm) {
          float fi = float(si);
          float seed = fi * 7.31 + 3.14;
          float spd = 0.6 + 0.8 * hash1(seed + 9.0);
          float zLife = mod(fi * 0.55 + gSwarm.x * spd, 6.6);
          float orbitZ = 6.9 - zLife;
          float orbitPhase = gSwarm.w * (0.6 + 0.5 * hash1(seed)) + seed;
          orbitPhase += gMood.z * 0.7 * sin(gSwarm.w * 0.5 + fi * 0.3);   // sweeping arcs in flight
          float orbitR = (0.25 + hash1(seed + 1.0) * 0.7) * (1.0 - 0.4 * gCam.z) + 0.15 * gUnfurl.w;
          orbitR += 0.4 * smoothstep(1.6, 0.4, orbitZ);                    // pass beside the camera
          float orbitY = sin(orbitPhase * 0.6 + fi * 1.2) * 0.4;
          float swarmLobe = sin(orbitPhase * 0.3 + fi * 0.7);
          float lobeShift = smoothstep(-0.25, 0.25, swarmLobe) * 2.0 - 1.0;
          vec3 local = vec3(cos(orbitPhase) * orbitR + lobeShift * 0.3,
                            orbitY + sin(orbitPhase * 3.0) * 0.03, orbitZ);
          float zDist = local.z;
          vec2 screenPos = local.xy / zDist * 1.3;
          float zSize = max(zDist, 0.55);
          vec2 localP = (p - screenPos) * zSize * 3.5;

          float bfPhase = gSwarm.z * (0.8 + 0.5 * hash1(seed + 2.0)) + seed * 2.0;
          float flapUpper = sin(bfPhase) * 0.85;
          float flapLower = sin(bfPhase * 0.85 + 0.4) * 0.65;
          float bodyBank = cos(orbitPhase) * 0.25;
          float bca = cos(bodyBank), bsa = sin(bodyBank);
          localP = vec2(localP.x * bca - localP.y * bsa, localP.x * bsa + localP.y * bca);
          float sizeVar = 0.8 + hash1(seed + 5.0) * 0.4;
          vec3 bf = butterflyFull(localP / sizeVar, flapUpper, flapLower, seed, quality > 0.5);
          float bfDist = bf.x * sizeVar;

          float bfOutline = 1.0 - smoothstep(0.0, 0.006 / max(zSize * 0.4, 0.15), bfDist);
          float bfGlow = exp(-max(0.0, bfDist) * 70.0 / max(zSize, 0.25));
          float bfFill = bf.z * 0.1;
          float bfVeins = bf.y * bf.z;
          float lifecycleFade = smoothstep(0.4, 1.0, zDist) * (1.0 - smoothstep(5.8, 6.7, zDist));
          float distFade = exp(-zDist * 0.28) * lifecycleFade;
          float swarmLobeCol = lobeShift + sin(fi * 0.5) * 0.3;
          vec3 swarmCol = butterflyPalette(fi * 0.08 + J * 0.03, swarmLobeCol);
          float sparkle = 1.0 + gLight.w * pow(sin(time * 9.0 + fi * 3.7) * 0.5 + 0.5, 4.0) * 2.0;
          col += (swarmCol * (bfOutline * 0.8 + bfGlow * 0.3 + bfFill)
                + swarmCol * 1.3 * bfVeins * (0.3 + gLight.w * 0.7))
                * distFade * sparkle * 1.25;
        }
      }
    }

    // ═══ LAYER 4: HERO BUTTERFLIES ═══
    if (CBT_ON(4)) {
      int numHeroes = quality > 0.5 ? 3 : 2;
      for (int hi = 0; hi < 3; hi++) {
        if (hi < numHeroes) col += renderHeroButterfly(p, float(hi), J);
      }
    }

    // ═══ LAYER 5: PHASE-SPACE STREAKS ═══
    if (CBT_ON(8)) {
      vec3 streakCol = vec3(0.0);
      for (int ti = 0; ti < 8; ti++) {
        float fi = float(ti);
        vec3 trailPos = lorenzCamera(J - fi * 0.035) * 0.06;
        vec3 toTrail = trailPos - camPos;
        float trailZ = dot(toTrail, ww);
        if (trailZ > 0.03) {
          vec2 trailScreen = vec2(dot(toTrail, uuB), dot(toTrail, vvB)) / trailZ * 1.3;
          float trailGlow = exp(-length(p - trailScreen) * 25.0) * exp(-fi * 0.35);
          streakCol += butterflyPalette(fi * 0.12, sign(trailPos.x)) * trailGlow;
        }
      }
      col += streakCol * (0.12 + gMood.z * 0.3);
    }

    // ═══ LAYER 6: ATMOSPHERIC FOG ═══
    if (CBT_ON(16)) {
      float fogDensity = fbm3(rd * 2.5 + vec3(time * 0.05, time * 0.03, -time * 0.02));
      vec3 fogCol = butterflyPalette(fogDensity + gGlow.w * 2.0, lobeSign * 0.5);
      col += fogCol * fogDensity * (0.065 + gCam.w * 0.06);
    }

    // ═══ LAYER 7: CROSSOVER FLARE ═══
    // The magenta heart of the tunnel: steady, swelling as light gathers before a drop and
    // with the unfurling (the original flashed it on every kick).
    if (CBT_ON(32)) {
      float crossoverProx = exp(-abs(camPos.x) * 2.5);
      float uFlash = tau >= 0.0 ? gUnfurl.y * exp(-tau / 1.2) * smoothstep(0.0, 0.35, tau) : 0.0;
      float flareIntensity = crossoverProx * (0.38 + 0.25 * gGlow.z + 0.6 * uFlash);
      float flareR = length(p);
      float flarePetal = abs(sin(atan(p.y, p.x) * 3.0 + J * 0.4));
      col += vec3(0.92, 0.08, 0.72) * flareIntensity * (0.5 + exp(-flareR * 3.0) * 1.5) * (0.7 + flarePetal * 0.3);
    }

    // ═══ LAYER 8: THE UNFURLING'S WING PORTAL ═══
    // The original's two-lobed wing portal, now once per drop: it opens outwards with the wings.
    if (CBT_ON(64) && tau >= 0.0 && tau < 3.5) {
      float portalR = length(p);
      float portalAngle = atan(p.y, p.x);
      float wingShape = abs(sin(portalAngle)) * 0.6 + 0.4;
      float grow = smoothstep(0.0, 2.4, tau);
      float portalRadius = (0.15 + 1.9 * grow) * wingShape;
      float portalDist = abs(portalR - portalRadius);
      float life = gUnfurl.y * smoothstep(0.0, 0.25, tau) * (1.0 - smoothstep(1.4, 3.4, tau));
      float portalGlow = exp(-portalDist * 18.0) * life;
      float portalVeins = pow(abs(sin(portalAngle * 8.0 + J * 0.5)), 8.0);
      portalGlow += portalVeins * exp(-portalDist * 30.0) * life * 0.4;
      vec3 portalCol = butterflyPalette(portalAngle * 0.3 + J * 0.05, lobeSign);
      col += portalCol * portalGlow * 0.6;
    }

    // ═══ LAYER 9: TREBLE SPARKLE FIELD ═══
    if (CBT_ON(128) && gLight.w > 0.3) {
      float sparkField = 0.0;
      for (int si = 0; si < 6; si++) {
        float fi = float(si);
        vec2 sparkPos = vec2(sin(time * 1.4 + fi * 5.1) * 1.3, cos(time * 1.2 + fi * 4.3) * 0.9);
        float spark = exp(-length(p - sparkPos) * 50.0) * (gLight.w - 0.3) * 2.0;
        spark *= sin(time * 12.0 + fi * 7.0) * 0.5 + 0.5;
        sparkField += spark;
      }
      col += vec3(0.95, 0.95, 1.0) * sparkField * 0.4;
    }

    // ═══ COMPOSE ═══
    vec3 finalColor = prev * 0.36 + col * identityPresence;

    float lum = dot(finalColor, vec3(0.2126, 0.7152, 0.0722));
    finalColor += finalColor * smoothstep(0.3, 1.0, lum) * 0.3;

    float vig = 1.0 - smoothstep(1.0, 1.85, length(p));
    finalColor *= vig;

    finalColor = finalColor / (1.0 + finalColor * 0.38);
    finalColor = pow(finalColor, vec3(0.95));

    finalColor += transitionTunnel(p);

    outColor = vec4(finalColor, 1.0);
  }
  `;

  return [[94, { name: "Chaotic Butterfly Tunnels", source: chaoticButterflyTunnelsFragmentSource }]];
}
