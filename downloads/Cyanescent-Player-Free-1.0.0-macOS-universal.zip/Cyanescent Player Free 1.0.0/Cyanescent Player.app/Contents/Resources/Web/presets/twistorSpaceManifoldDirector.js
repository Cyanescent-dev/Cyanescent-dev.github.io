// Twistor Space Manifold (preset 153) — the director.
//
// The manifold is the original preset's sculpture, unchanged in kind: four iterations of a mirror
// fold, three plane rotations and a 1.4x scale, then two families of tubes (one around the folded
// z axis, one around the folded x axis) joined with a smooth minimum. Every branch, junction and
// aperture on screen comes from those few numbers, so the director's job is to move them gracefully.
//
// This file is pure JS (no GL) so it can be tested. It turns Player's analysis into:
//   morph      the fold rotations advance on an accumulated phase whose rate follows the mids
//              (the original added raw mids, bass and kick values straight to the angles, which
//              shook the whole sculpture on every transient); slow audio envelopes add character
//   breathing  bass deepens the fold offsets and the tube blending, with a two-bar breath
//   tubes      tube radii follow slow highs / mids envelopes (the original's raw values flickered)
//   pulses     kicks send luminous shells outwards from the centre along the radiating branches;
//              build rolls, breakdown tides and drops send their own
//   camera     a contemplative journey that alternates immersive passages near the core, slow
//              transitional orbits and structural reveals far enough out to see the whole network;
//              breakdowns and drops favour the reveals. The camera never reads instantaneous kick
//              or bass values, and it is pushed smoothly away from tubes (see tsmDistance)
//   light      exposure, shimmer (highs and hats), drop flash, energy, calm, tension, hue drift
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";

export const TWISTOR_SPACE_MANIFOLD_PRESET_ID = 153;
export const TSM_FOLD_BASE = [0.9, 0.75, 0.9];
export const TSM_SMOOTH_FOLD = 0.04;       // smooth mirror fold (heals the hard abs() creases)
export const TSM_CAMERA_MARGIN = 0.3;      // clearance the camera keeps from every tube
export const TSM_PULSE_SLOTS = 4;
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth01 = (x) => { const t = clamp(x); return t * t * (3 - 2 * t); };

// ---- the distance field (JS port of the shader's tsmMap) -------------------------------------------
// GLSL rot(a) = mat2(c, -s, s, c) (column-major): v' = (c x + s y, -s x + c y).
function rot2(a, x, y) { const c = Math.cos(a), s = Math.sin(a); return [c * x + s * y, -s * x + c * y]; }

export function tsmDistance(point, params) {
  let [x, y, z] = point;
  const [aXY, aXZ, aYZ, aG] = params.rot;
  const [ox, oy, oz] = params.fold;
  const k2 = params.smoothFold * params.smoothFold;
  [x, z] = rot2(aG, x, z);
  [x, y] = rot2(aG, x, y);
  let scale = 1;
  for (let i = 0; i < 4; i++) {
    x = Math.sqrt(x * x + k2) - ox;
    y = Math.sqrt(y * y + k2) - oy;
    z = Math.sqrt(z * z + k2) - oz;
    [x, y] = rot2(aXY, x, y);
    [x, z] = rot2(aXZ, x, z);
    [y, z] = rot2(aYZ, y, z);
    x *= 1.4; y *= 1.4; z *= 1.4; scale *= 1.4;
  }
  const a = (Math.hypot(x, y) - params.r1) / scale;
  const b = (Math.hypot(y, z) - params.r2) / scale;
  const k = params.blend / scale;
  const h = clamp(0.5 + 0.5 * (b - a) / k);
  return b + (a - b) * h - k * h * (1 - h);
}

// Smooth repulsion away from nearby tubes: the gradient of a soft penalty sampled on a wide stencil,
// so it varies smoothly even between two tubes (a plain distance gradient flips there).
function repulsion(p, params, reach) {
  const w = (d) => { const x = Math.max(0, reach - d) / reach; return x * x; };
  const h = 0.45, f = [0, 0, 0];
  for (let i = 0; i < 3; i++) {
    const a = p.slice(), b = p.slice();
    a[i] += h; b[i] -= h;
    f[i] = (w(tsmDistance(b, params)) - w(tsmDistance(a, params))) / (2 * h);
  }
  return f;
}

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const scale3 = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm3 = (a) => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

// ---- the camera journey -------------------------------------------------------------------------
// One cycle of the journey clock (J, in seconds at a normal pace): immersive passage near the core,
// a transitional orbit outwards, a structural reveal, a slow drift back in. The goal radius is a
// smooth function of J and a critically damped spring follows it, so position, velocity and
// acceleration are all continuous.
export const TSM_JOURNEY_SECONDS = 56;
// The lattice is nearly solid inside r ~ 4.5 (gaps narrower than the camera margin), so immersive
// passages skim its outer surface, looking across it.
// The core is ~3.4 in radius in every phase (the radiating spokes come and go), so the reveals
// stay close enough to fill the frame even when there are no spokes.
const RADIUS = { immerse: 4.7, transit: 5.9, reveal: 7.4, grand: 8.4 };
export function journeyRadius(J) {
  const u = (((J / TSM_JOURNEY_SECONDS) % 1) + 1) % 1;
  const seg = (a, b) => smooth01((u - a) / (b - a));
  let r = RADIUS.immerse;
  r += (RADIUS.transit - RADIUS.immerse) * seg(0.24, 0.36);
  r += (RADIUS.reveal - RADIUS.transit) * seg(0.40, 0.52);
  r -= (RADIUS.reveal - RADIUS.transit) * seg(0.76, 0.84);
  r -= (RADIUS.transit - RADIUS.immerse) * seg(0.88, 0.99);
  return r;
}

// ---- the director -------------------------------------------------------------------------------
export function createTwistorSpaceManifoldDirector() {
  const audioModel = createNewtonAudioModel();
  const s = {};
  const pulses = [];
  const uniforms = {};

  function reset() {
    audioModel.reset();
    pulses.length = 0;
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0,
      // envelopes
      energy: 0.3, mids: 0.35, midsSlow: 0.35, highs: 0.35, highsSlow: 0.35, bass: 0.4, bassSlow: 0.4,
      calm: 0, drive: 0, tension: 0, shimmer: 0, flash: 0, reveal: 0, hatSpark: 0,
      // motion
      morph: 0, morphRate: 1, hue: 0, film: 0,
      J: 0, pace: 1, azimuth: 0.0, orbitSpeed: 0.05, radius: RADIUS.transit, radiusV: 0, safety: [0, 0, 0], safetyV: [0, 0, 0], lastPos: null, vel: [0, 0, 0],
      clearance: 1, minClearance: Infinity,
      // counters (tests, trial reports)
      kicks: 0, drops: 0, tides: 0, rolls: 0, lastDropAt: -1e9
    });
  }
  reset();

  function spawnPulse(kind, strength) {
    const speed = { kick: 7.0, roll: 8.5, tide: 2.4, drop: 7.5 }[kind] || 6;
    const life = { kick: 1.9, roll: 1.2, tide: 6.5, drop: 3.6 }[kind] || 2;
    if (pulses.length >= TSM_PULSE_SLOTS) {
      let oldest = 0;
      for (let i = 1; i < pulses.length; i++) if (pulses[i].age / pulses[i].life > pulses[oldest].age / pulses[oldest].life) oldest = i;
      pulses.splice(oldest, 1);
    }
    pulses.push({ kind, strength, speed, life, age: 0 });
  }

  function fieldParams(ahead = 0) {
    const breath = Math.sin(TAU * s.beat / 8) * 0.022 * (0.3 + 0.7 * s.bassSlow) * (1 - 0.5 * s.calm);
    const deepen = 1.07 + 0.13 * s.bassSlow + breath;
    const m = s.morph + ahead * 0.2 * s.morphRate;
    return {
      rot: [
        0.785398 + 0.5 * m + 0.30 * s.midsSlow,
        0.5 - 0.3 * m + 0.10 * s.drive - 0.06 * s.calm,
        0.3 + 0.4 * m + 0.20 * s.bassSlow,
        0.7 * m
      ],
      fold: TSM_FOLD_BASE.map((v) => v * deepen),
      blend: 0.2 + 0.3 * s.bassSlow + 0.05 * s.calm,
      r1: 0.4 + 0.2 * s.highsSlow,
      r2: 0.3 + 0.2 * s.midsSlow,
      smoothFold: TSM_SMOOTH_FOLD
    };
  }

  // time: seconds (monotonic per preset activation). input: { audio, smooth, music, tempo }.
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = clamp(time - s.lastTime, 0, 0.1);
    s.lastTime = time;
    s.time += dt;
    const { audio = {}, smooth = {}, music = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    s.beat = a.beat;

    // ---- musical envelopes (all slew-limited: nothing below reaches the geometry raw) -------------
    s.energy = follow(s.energy, Math.max(a.energyDrive * 0.9, clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.8), dt, 0.5, 1.6);
    s.mids = follow(s.mids, clamp(smooth.mids), dt, 0.4, 0.8);
    s.midsSlow = follow(s.midsSlow, s.mids, dt, 1.4, 1.8);
    s.highs = follow(s.highs, clamp(smooth.highs), dt, 0.05, 0.25);
    s.highsSlow = follow(s.highsSlow, s.highs, dt, 1.6, 2.2);
    s.bass = follow(s.bass, clamp(Math.max(a.sub, clamp(smooth.bass) * 0.85)), dt, 0.5, 1.1);
    s.bassSlow = follow(s.bassSlow, s.bass, dt, 0.9, 1.5);
    s.calm = follow(s.calm, clamp((a.breakdown - 0.35) / 0.45) * (1 - a.groove * 0.7) * (1 - clamp(Math.max(a.build, clamp(music.buildUp)) * 1.6)), dt, 1.4, 1.8);
    s.drive = follow(s.drive, clamp(a.groove * (0.5 + 0.5 * s.energy)), dt, 0.8, 1.6);
    const forecast = clamp(Math.max(clamp(music.upcomingDrop) * 1.2, a.build));
    s.tension = follow(s.tension, forecast * (1 - s.calm * 0.5), dt, 0.8, 1.2);

    // ---- events -------------------------------------------------------------------------------------
    for (const w of events.waves) {
      if (w.kind === "kick") { spawnPulse("kick", w.strength * (w.beatInBar === 0 ? 1 : 0.72)); s.kicks += 1; }
      else if (w.kind === "roll") { spawnPulse("roll", w.strength * 0.7); s.rolls += 1; }
      else if (w.kind === "tide") { spawnPulse("tide", 0.55 * w.strength); s.tides += 1; }
    }
    if (events.hats) s.hatSpark = Math.max(s.hatSpark, 0.5 + 0.5 * a.highDrive);
    // the kick returning in the middle of a build (a tease) is a rebound, not the drop
    const rebound = events.drop && clamp(music.buildUp) > 0.5 && clamp(music.drop) < 0.6;
    if (rebound) { spawnPulse("drop", 0.7); s.flash = Math.max(s.flash, 0.35); }
    if (events.drop && !rebound && s.time - s.lastDropAt > 6) {
      s.lastDropAt = s.time; s.drops += 1;
      pulses.length = 0;
      spawnPulse("drop", 1.6);
      s.flash = 1;
      s.reveal = 1;          // the drop pulls the camera back to reveal the whole network
    }
    s.flash *= Math.exp(-dt / 1.1);
    s.hatSpark *= Math.exp(-dt / 0.12);
    s.reveal = Math.max(0, s.reveal - dt / 14);
    s.shimmer = clamp(0.25 * s.highs + 0.55 * a.highDrive * (0.4 + 0.6 * s.energy) + 0.45 * s.hatSpark);
    for (const p of pulses) p.age += dt;
    for (let i = pulses.length - 1; i >= 0; i--) if (pulses[i].age > pulses[i].life) pulses.splice(i, 1);

    // ---- morph ------------------------------------------------------------------------------------
    // The original advanced at 0.2 rad-units per second; mids quicken the unfolding, breakdowns
    // make it broad and slow, a build tightens it.
    const rateGoal = 0.82 + 0.55 * s.mids + 0.18 * s.drive + 0.22 * s.tension - 0.28 * s.calm;
    s.morphRate = follow(s.morphRate, rateGoal, dt, 1.8, 1.8);
    s.morph += dt * 0.2 * s.morphRate;
    s.hue += dt * (0.055 + 0.05 * s.drive - 0.02 * s.calm);
    s.film += dt * (0.05 + 0.35 * s.shimmer);
    const params = fieldParams();

    // ---- camera -----------------------------------------------------------------------------------
    s.pace = follow(s.pace, 0.8 + 0.35 * s.drive + 0.2 * s.tension - 0.25 * s.calm, dt, 2.5, 2.5);
    s.J += dt * s.pace;
    let goal = journeyRadius(s.J);
    goal += (RADIUS.reveal + 0.4 - goal) * 0.75 * smooth01(s.calm);             // breakdowns reveal
    goal += (RADIUS.immerse + 0.6 - goal) * 0.45 * s.tension * (1 - s.calm);    // builds draw in
    goal += (RADIUS.grand - goal) * smooth01(s.reveal * 1.6);                   // drops pull back
    const w = 0.42 + 0.25 * s.reveal;
    s.radiusV += (w * w * (goal - s.radius) - 2 * w * s.radiusV) * dt;
    s.radius += s.radiusV * dt;
    const orbitGoal = (0.05 + 0.035 * s.drive - 0.018 * s.calm) * (1 + 0.5 * s.reveal);
    s.orbitSpeed = follow(s.orbitSpeed, orbitGoal, dt, 2.5, 2.5);
    s.azimuth += dt * s.orbitSpeed;
    const J = s.J;
    const elevation = 0.36 * Math.sin(J * 0.047 + 0.4) + 0.14 * Math.sin(J * 0.113 + 1.3);
    const near = clamp((7.2 - s.radius) / 2.0);
    const dir = [Math.cos(elevation) * Math.sin(s.azimuth), Math.sin(elevation), -Math.cos(elevation) * Math.cos(s.azimuth)];
    // close to the lattice the gaze skims across its surface instead of staring at the centre
    const tangent = norm3(cross([0, 1, 0], dir));
    const drift = scale3([Math.sin(J * 0.051), 0.7 * Math.sin(J * 0.071 + 1), Math.cos(J * 0.043 + 0.3)], 0.3);
    const target = add(drift, scale3(tangent, 2.2 * smooth01(near) * Math.sin(J * 0.029 + 0.8)));
    let pos = add(scale3(dir, s.radius), drift);
    // clearance: a critically damped spring follows a smooth repulsion, evaluated where the camera
    // and the sculpture will be shortly, so the camera eases away before a branch arrives
    const reach = TSM_CAMERA_MARGIN * 2.5;
    const aheadParams = fieldParams(1.0);
    const probe = add(pos, s.safety);
    const ahead = add(probe, scale3(s.vel, 1.0));
    const f0 = repulsion(probe, params, reach), f1 = repulsion(ahead, aheadParams, reach);
    const push = add(f0, f1).map((v, i) => s.safety[i] + v * 1.4);
    const ws = 1.5;
    for (let i = 0; i < 3; i++) {
      const goalI = clamp(push[i], -2.2, 2.2) * 0.985;
      s.safetyV[i] += (ws * ws * (goalI - s.safety[i]) - 2 * ws * s.safetyV[i]) * dt;
      s.safety[i] += s.safetyV[i] * dt;
    }
    pos = add(pos, s.safety);
    if (s.lastPos && dt > 0) s.vel = scale3(sub(pos, s.lastPos), 1 / dt);
    s.lastPos = pos;
    s.clearance = tsmDistance(pos, params);
    s.minClearance = Math.min(s.minClearance, s.clearance);
    const fwd = norm3(sub(target, pos));
    const roll = 0.1 * Math.sin(J * 0.037);
    const up0 = [Math.sin(roll), Math.cos(roll), 0];
    const right = norm3(cross(up0, fwd));
    const up = cross(fwd, right);
    const tanHalf = 0.84 - 0.012 * (s.radius - 4);

    // ---- uniforms ---------------------------------------------------------------------------------
    uniforms.tsmRot = params.rot;
    uniforms.tsmFold = [...params.fold, params.blend];
    uniforms.tsmTube = [params.r1, params.r2, params.smoothFold, 0];
    uniforms.tsmCam = [...pos, tanHalf];
    uniforms.tsmBasis = [...right, ...up, ...fwd];
    const ages = [99, 99, 99, 99], amps = [0, 0, 0, 0], speeds = [1, 1, 1, 1];
    pulses.forEach((p, i) => {
      ages[i] = p.age; speeds[i] = p.speed;
      const fadeIn = clamp(p.age / 0.06);
      amps[i] = p.strength * fadeIn * Math.exp(-p.age / (p.life * 0.55)) * (0.55 + 0.45 * s.energy);
    });
    uniforms.tsmPulseAge = ages; uniforms.tsmPulseAmp = amps; uniforms.tsmPulseSpeed = speeds;
    uniforms.tsmLight = [0.92 + 0.22 * s.energy + 0.18 * s.calm + 0.35 * s.flash, s.shimmer, s.flash, s.energy];
    uniforms.tsmMood = [s.calm, s.drive, s.tension, s.hue % 1000];
    uniforms.tsmClock = [s.beat % 1024, s.film % 1000, s.reveal, s.radius];
    s.camera = { pos, fwd, radius: s.radius, goal, clearance: s.clearance };
    s.params = params;
    return s;
  }

  return { state: s, step, uniforms: () => uniforms, pulses };
}

const cache = new WeakMap();

export function bindTwistorSpaceManifoldDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime) { runtime = { director: createTwistorSpaceManifoldDirector(), lastTime: -1 }; cache.set(gl, runtime); }
  const director = opts.director || runtime.director;
  // a frame drawn twice at the same time (transition, re-render) reuses the state
  if (time !== runtime.lastTime || opts.director) { director.step(time, input); runtime.lastTime = time; }
  const loc = (name) => uniformLocation(gl, program, name);
  const dirLoc = loc("tsmDir");
  if (dirLoc) gl.uniform1f(dirLoc, 1);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (!l) continue;
    if (value.length === 9) gl.uniformMatrix3fv(l, false, value);
    else gl.uniform4f(l, value[0], value[1], value[2], value[3]);
  }
  return director;
}
