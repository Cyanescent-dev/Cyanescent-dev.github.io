export function createTieDyeSupernovaPresetShaderEntries({ modularShaderPrelude, modularTransitionShaderBlock }) {
    return [
      [146, {
        name: "Tie-Dye Supernova",
        source: `${modularShaderPrelude}
  ${modularTransitionShaderBlock}

  // Easy tuning constants exposed at the top of the preset block
  const float fluidMemory = 0.880;      // Dye retention per frame (~0.13s of momentum)
  const float flowSpeed = 1.85;         // Global multiplier on the velocity field
  const float vortexSpin = 0.24;        // Base differential rotation of the swirl
  const float eddyLarge = 0.46;         // Broad slow eddies
  const float eddySmall = 0.28;         // Fine counter-rotating eddies
  const float kickSurge = 1.05;         // Outward impulse a kick pushes through the core
  const float coreGlow = 0.55;          // Brightness of the central supernova

  float fbm(vec2 p) {
      float f = 0.0;
      float w = 0.5;
      int iters = int(mix(7.0, 20.0, quality));
      for (int i = 0; i < 20; i++) {
          if (i >= iters) break;
          f += w * noise(p);
          w *= 0.5;
          p = rot(1.2) * p * 2.0;
      }
      return f;
  }

  // Cheap 3-octave field for the broad hue bands and the fine filigree
  float flowFbm(vec2 p) {
      float f = 0.0;
      float w = 0.5;
      for (int i = 0; i < 3; i++) {
          f += w * noise(p);
          w *= 0.5;
          p = rot(1.7) * p * 2.03;
      }
      return f;
  }

  // Two octaves is deliberate: a real velocity field is smooth, and the fine
  // structure belongs to the dye it carries. More octaves here just buys noisy
  // little swirls that read as fizz rather than flow.
  float flowPotential(vec2 p) {
      return 0.5 * noise(p) + 0.25 * noise(rot(1.7) * p * 2.03);
  }

  // Curl of a scalar potential. Divergence-free by construction, so the field
  // swirls and folds like an incompressible fluid instead of pumping dye in and
  // out of the frame.
  vec2 curlFlow(vec2 p) {
      const float e = 0.06;
      float n0 = flowPotential(p);
      float nx = flowPotential(p + vec2(e, 0.0));
      float ny = flowPotential(p + vec2(0.0, e));
      return vec2(ny - n0, -(nx - n0)) / e;
  }

  // bassRel/midRel/trebleRel rest near 1.0 and spike toward 2.8 on electronic
  // transients. Compress that into a saturating drive so a hard hit leans on the
  // motion instead of snapping it.
  float bandDrive(float rel) {
      float x = max(rel - 1.0, 0.0);
      return x / (1.0 + x * 1.6);
  }

  void main() {
      vec2 p = (gl_FragCoord.xy - 0.5 * resolution.xy) / resolution.y;
      vec2 tuv = gl_FragCoord.xy / resolution.xy;
      float r = length(p);

      // u_wavePhase is integrated on the CPU at a rate that rises with the slow
      // level, so the flow speeds up with the music but can never jump or run
      // backwards the way time * audio does.
      float wave = u_wavePhase;
      float dt = clamp(feedbackStep, 0.01, 4.0) / 60.0;

      float lowHit = bandDrive(bassRel);
      float midHit = bandDrive(midRel);
      float highHit = bandDrive(trebleRel);
      float bodyLevel = clamp(u_slowLevel * 1.5, 0.0, 1.0);
      float bodyBass = clamp(u_slowBass * 1.7, 0.0, 1.0);
      float energy = clamp(globalEnergy, 0.0, 1.0);
      float kickEnv = smoothstep(0.0, 0.6, kickPulse);

      // 1. Velocity field
      // Audio drives velocity here, never position. A step in velocity still
      // leaves every particle on a continuous path, which is why the motion stays
      // smooth even when the track is hitting hard.

      // Rankine-style vortex: shear peaks around r = 0.3 and eases to zero at the
      // core, so the dye winds into arms rather than spinning as a rigid disc.
      vec2 vortex = vec2(-p.y, p.x) / (r * r + 0.09);

      // Two counter-rotating eddy layers at different scales. They shear against
      // each other the way two miscible fluids do.
      vec2 eddyA = curlFlow(p * 1.05 + vec2(0.0, wave * 0.09));
      vec2 eddyB = curlFlow(p * 2.35 - vec2(3.7, 1.9) - vec2(wave * 0.13, 0.0));

      vec2 vel = vortex * (vortexSpin + bodyLevel * 0.22 + midHit * 0.10)
               + eddyA * (eddyLarge + bodyBass * 0.30 + lowHit * 0.26)
               - eddyB * (eddySmall + bodyLevel * 0.12 + highHit * 0.22);

      // A kick pushes a bubble of dye out of the core; advection then carries it
      // outward over the frames that follow, so the hit reads as a launched
      // ripple instead of the whole frame changing scale at once.
      vel += (p / (r + 0.06)) * kickEnv * exp(-r * r * 2.6) * kickSurge;

      vec2 toTex = vec2(resolution.y / max(resolution.x, 1.0), 1.0);
      vec2 advectUv = tuv - vel * (flowSpeed * dt) * toTex;

      // 2. Dye field
      // Everything that touches geometry runs off the slow bodies. Wiring midRel
      // straight into the twist and the pattern frequency is what rotated and
      // rescaled the entire frame on every transient.
      float twist = r * (0.85 + bodyLevel * 0.45) - wave * 0.26;
      vec2 warped = p * rot(wave * 0.19 + twist);

      vec2 q = vec2(fbm(warped + wave * 0.17),
                    fbm(warped + vec2(5.2, 1.3) - wave * 0.29));
      vec2 s = vec2(fbm(warped + q * 2.0 + wave * 0.40),
                    fbm(warped + q * 2.0 - vec2(8.3, 2.8)));
      vec2 dp = warped + s * (0.30 + bodyBass * 0.24 + lowHit * 0.10);

      // Hue rides a broad, low-frequency field. Keeping it smooth in space is
      // what stops the advection average from washing the colours toward grey:
      // a parcel drifting a tenth of a unit lands on nearly the same hue. It is
      // also closer to real tie-dye, which is bold bands rather than confetti.
      float bands = flowFbm(dp * 2.4 + wave * 0.45);
      // Hue carries the fast response: a colour shift reads as musical without
      // displacing anything, so it can track transients safely.
      float hue = bands * 1.45 + length(dp) * 0.55 - wave * 0.42 + highHit * 0.06 + lowHit * 0.04;
      vec3 dye = palette60s(hue);

      // Fine structure rides on brightness instead of hue, so the temporal
      // average keeps it as contrast rather than turning it to mud.
      float detail = fbm(dp * (6.2 - bodyLevel * 1.1) + wave * 0.66);
      dye *= 0.66 + 0.70 * detail;

      // Treble adds amplitude to a fine layer that is already there rather than
      // moving it, so hats sparkle without shifting the geometry.
      float filigree = flowFbm(dp * 12.0 + wave * 0.55);
      dye += palette60s(hue + 0.34) * smoothstep(0.58, 0.96, filigree) * (0.05 + highHit * 0.28);

      // Bounded core glow, kept tight and coloured.
      //
      // Three things previously combined to wash out the middle of the frame:
      // a third profile term (exp(-r * 1.3)) so broad it was still lifting the
      // frame edge, a tint mixed 45% toward white, and a peak near 3.1 that blew
      // through the knee below and clipped to neutral. Advection then dragged
      // that white core outwards, so the wash covered far more than the core.
      // The falloff now dies away by roughly a quarter of the radius, the tint
      // stays close to the palette, and the peak sits just above the knee.
      float core = exp(-r * 10.0) * 1.30 + exp(-r * 4.0) * 0.35;
      vec3 coreTint = mix(palette60s(wave * 0.04 + 0.10), vec3(1.0, 0.94, 0.82), 0.16);
      dye += coreTint * core * coreGlow * (0.45 + bodyBass * 0.35 + kickEnv * 0.30);

      // Soft knee, so only the hot core compresses and midtones keep their punch
      dye = dye / (1.0 + max(dye - 0.75, vec3(0.0)) * 1.2);

      // 3. Fluid accumulation
      // Semi-Lagrangian advection: sample where this pixel's dye drifted in from
      // and fold in a little fresh colour. The visible image becomes an
      // exponential average over ~0.13s, which absorbs transient spikes by itself
      // and stretches fast-moving regions into filaments.
      float transitionStrength = sin(clamp(transitionPhase, 0.0, 1.0) * PI);
      float warmUp = 1.0 - smoothstep(0.0, 0.8, presetTime);
      float memory = mix(fluidMemory - energy * 0.02, 0.35, max(transitionStrength, warmUp));
      float retainStep = feedbackRetain(memory);
      float persistStep = retainStep * transitionPreviousPresence(p);

      vec3 fluid = samplePreviousFrame(advectUv, p, retainStep);
      vec3 source = dye * transitionIdentityPresence() + transitionTunnel(p);

      outColor = vec4(fluid + source * (1.0 - persistStep), 1.0);
  }`
      }]];
  }
