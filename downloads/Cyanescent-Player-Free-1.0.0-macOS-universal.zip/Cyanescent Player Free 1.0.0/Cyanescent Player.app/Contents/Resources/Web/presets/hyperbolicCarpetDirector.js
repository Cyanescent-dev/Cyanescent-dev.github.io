// Hyperbolic Carpet (preset 316) — the director.
//
// The canopy is the original preset's exact reflection tessellations ({5,4} and {7,3}, blended
// over the phrase) with their nested contours, child tiles and embroidery. The geometry is not
// changed here; the director decides how the viewer floats beneath it and how the music lights it.
//
// This file is pure JS (no GL) so it can be tested. It turns Player's analysis (through the shared
// Newton audio model) into:
//   view       a slow, deliberate float: the screen centre eases between landmarks of the canopy
//              (the central polygon, an edge midpoint, a vertex) phrase by phrase on a critically
//              damped spring, the canopy turning about it; a small drift on a journey clock; a
//              very gradual rotation that quickens a little with melody; slow changes of viewing
//              distance (the chart's curvature). The journey's pace follows the section through a
//              slow follower; no transient, kick, bass note or drop ever reaches the view
//   pulses     light that travels through the tessellation's own structure. A pulse is a front in
//              "generation" units (how many polygon edges a tile is from the canopy's central
//              tile); the shader adds how far the light has soaked into each polygon's nested
//              tiers, how far it has run along the edge, an optional sector of the canopy it
//              favours or sweeps around from, and light circulating around each polygon's
//              perimeter as it passes (the fold's orientation makes that coordinate continuous).
//              Kinds:
//                tick     ordinary kick: a tight, local impact on the edges near the centre
//                kick     bar downbeat: a few rings, favouring a sector that turns bar by bar
//                accent   every fourth bar / energy surge: a slow, broad cascade across the canopy
//                         whose shape follows the current motif (see below)
//                counter  in the "weave" motif: a front converging inwards through the contours
//                         from the opposite sector, crossing the accents
//                roll     build-up subdivisions: fronts converging inwards from the outer rings,
//                         alternating between the edges and the nested contours
//                tide     breakdown pads, once a bar: a slow, wide wave through the nested contours
//                drop     the release: one long cascade through every generation and tier,
//                         sweeping and circulating
//   motifs     sustained drives alternate lighting behaviours every eight bars instead of showing
//              everything at once: spiral (accents sweep around the canopy), weave (sector accents
//              crossed by counter fronts), circuit (accents circulate around the perimeters and
//              the melody circulates around the contours)
//   membrane   the nested contours draw in and release: an off-beat pump with the groove's bass, a
//              two-bar breath, a slow four-bar breath in breakdowns, tautness that grows through a
//              build, and a damped spring that a qualified drop kicks outwards
//   evolution  phrase by phrase (32 beats) the contours' prominence, depth, recursion and ribbon
//              weight drift to new values
//   melody     quiet comets along selected contours; sustained sweeps of whole contours through
//              the generations; energetic circulation around the contours; builds add comets and
//              bring the lanes into step. Treble: embroidery and child-tile shimmer, hi-hats
//              lighting alternating child generations
//   mood       calm (breakdown), tension (build), the drop cascade, and a slow colour drift that
//              reassigns the palette ring by ring, mostly during breakdowns
//   unfolding  the hero moment, rare and earned (see stepUnfold): IDLE -> GATHER -> UNFOLD ->
//              BLOSSOM -> RETURN -> COOLDOWN. The canopy opens (the central polygons swell, the rest
//              recede), the nested contours stream inwards layer after layer and a miniature canopy
//              grows inside the polygons; a qualified drop blossoms it outwards. Disable it with
//              HC_SETTINGS.unfold = false, createHyperbolicCarpetDirector({ unfold: false }) or
//              globalThis.cyanescentHyperbolicUnfold = false (e.g. from the console); everything
//              else is unaffected
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";

export const HYPERBOLIC_CARPET_PRESET_ID = 316;
export const HC_PULSE_SLOTS = 8;
const TAU = Math.PI * 2;
const GOLDEN_ANGLE = 2.39996323;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth01 = (x) => { const t = clamp(x); return t * t * (3 - 2 * t); };
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

// speed: generations per second (negative travels inwards); tail: generations of afterglow behind
// the front; seam / nested: how strongly the polygon edges / nested contours carry it; soak: how
// far (in generations) the front runs on into each polygon's nested tiers; reach: generations over
// which its strength falls off (e-folding); start: the generation the front starts at; life: s.
// Shape: focus (how strongly it favours its sector), sweep (generations of delay from its sector
// round to the opposite side), run (perimeter circulation) and runRate (circulation per generation).
export const HC_PULSE_KINDS = Object.freeze({
  tick:    { speed: 9,   tail: 0.60, seam: 1.0,  nested: 0.25, soak: 0.45, reach: 1.4, start: -0.4, life: 0.50 },
  kick:    { speed: 7,   tail: 1.20, seam: 1.0,  nested: 0.50, soak: 0.70, reach: 3.6, start: -0.4, life: 1.20, focus: 1.6 },
  accent:  { speed: 4.6, tail: 2.40, seam: 1.0,  nested: 0.75, soak: 1.00, reach: 10,  start: -0.5, life: 3.00 },
  counter: { speed: -5.5, tail: 1.40, seam: 0.45, nested: 1.0, soak: 0.80, reach: 30,  start: 7.0, life: 1.60, focus: 1.2 },
  roll:    { speed: -11, tail: 0.60, seam: 0.65, nested: 0.80, soak: 0.50, reach: 30,  start: 7.0, life: 0.75 },
  tide:    { speed: 1.2, tail: 0.70, seam: 0.12, nested: 1.0,  soak: 1.00, reach: 12,  start: -0.8, life: 6.0 },
  drop:    { speed: 4.2, tail: 3.20, seam: 1.0,  nested: 1.0,  soak: 1.20, reach: 40,  start: -0.5, life: 3.8, sweep: 1.2, run: 0.6, runRate: 1.6 }
});
export const HC_MOTIFS = Object.freeze(["spiral", "weave", "circuit"]);

// The unfolding's switch (shared by every director unless one is created with its own option).
export const HC_SETTINGS = { unfold: true };
export const HC_UNFOLD = Object.freeze({
  settle: 20,          // s of playback before the first unfolding can gather
  cooldown: 75,        // s after one finishes before another can gather (one or two per track)
  calmHold: 12,        // s of breakdown (calm > 0.45) that earns a gathering
  buildHold: 5,        // or s of held build (tension > 0.7)
  gatherMin: 4,        // s of gathering before it may unfold
  gatherMax: 16,       // s after which it unfolds anyway
  maxAway: 60,         // s from gathering to the latest possible blossom; then it returns unreleased
  blossom: 3.5,        // s
  returnMin: 4         // s
});

// The drift: Möbius translation (x, y) and rotation as functions of the journey clock J (seconds
// at a normal pace). Shared with the shader's fallback (hcDir = 0), which uses J = 0.85 t; the
// director scales the translation down and adds the landmark journey to it.
export function hcView(J) {
  return [
    0.22 * Math.sin(J * 0.061) + 0.05 * Math.sin(J * 0.023 + 1.9),
    0.15 * Math.sin(J * 0.043 + 1.1) + 0.04 * Math.sin(J * 0.089 + 0.4),
    0.014 * J + 0.10 * Math.sin(J * 0.037)
  ];
}

// Landmarks of the central polygon in the Poincaré disk (tessellation frame): edge midpoint on the
// +x axis (where the fold's inversion circle sits) and a vertex at angle pi / p.
function landmarks(p, q) {
  const a = Math.PI / p, b = Math.PI / q;
  const cc = Math.cos(b) / Math.sqrt(Math.cos(b) ** 2 - Math.sin(a) ** 2);
  return { midpoint: cc - Math.sqrt(cc * cc - 1), vertex: Math.sqrt(Math.cos(a + b) / Math.cos(a - b)), vertexAngle: a };
}
const LANDMARKS = [landmarks(5, 4), landmarks(7, 3)];
const JOURNEY = ["centre", "vertex", "midpoint", "centre", "midpoint", "vertex"];   // one per ~16 bars
export function hcLandmark(kind, blend, index = 0) {
  const mix = (k) => LANDMARKS[0][k] + (LANDMARKS[1][k] - LANDMARKS[0][k]) * clamp(blend);
  if (kind === "centre") return [0, 0];
  if (kind === "midpoint") return [0.85 * mix("midpoint"), 0];
  const r = 0.9 * mix("vertex"), t = mix("vertexAngle") * (index % 2 ? -1 : 1);
  return [r * Math.cos(t), r * Math.sin(t)];
}
const rotate2 = (v, t) => [Math.cos(t) * v[0] - Math.sin(t) * v[1], Math.sin(t) * v[0] + Math.cos(t) * v[1]];

export function createHyperbolicCarpetDirector(options = {}) {
  const audioModel = createNewtonAudioModel();
  const s = {};
  const pulses = [];
  const uniforms = {};
  const pulseA = new Float32Array(HC_PULSE_SLOTS * 4);
  const pulseB = new Float32Array(HC_PULSE_SLOTS * 4);
  const pulseC = new Float32Array(HC_PULSE_SLOTS * 4);
  const pulseD = new Float32Array(HC_PULSE_SLOTS * 4);

  function reset() {
    audioModel.reset();
    pulses.length = 0;
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0, beat: 0,
      energy: 0.3, calm: 0, drive: 0, tension: 0, bass: 0, bassSlow: 0, depth: 0, mids: 0.3, midsSlow: 0.3, flowAmount: 0.3,
      shimmer: 0, hatSpark: 0, hatParity: 0, impact: 0, cascade: 0, detail: 0.2,
      J: 0, pace: 0.85, flowPhase: 0, threadPhase: 0, lumPhase: 0, drift: 0, blend: null, turn: 0,
      circPhase: 0, sweepPhase: 0, cometCount: 1, laneSync: 0, quiet: 0.5, sustain: 0, energetic: 0,
      release: 0, releaseV: 0, membrane: 0, tautness: 0, evolve: [1, 0, 0, 1],
      focus: [0, 0], focusV: [0, 0], landmark: "centre", motif: "spiral", motifGate: 0,
      calmSeen: 0, buildHold: 0, lastAccentBar: -99, lastCounterBar: -99, rollParity: 0, accentParity: 0,
      kicks: 0, accents: 0, counters: 0, rolls: 0, tides: 0, drops: 0, rebounds: 0, lastDropAt: -1e9, qualifiedDrop: false,
      journeyShift: 0, hero: 0, heroV: 0,
      unfold: { stage: "idle", t: 0, away: 0, open: 0, openV: 0, stream: 0, streamV: 0, bloom: 0, calmHold: 0, grooveBack: 0, lastEnd: -1e9, count: 0, blossoms: 0, aborts: 0, log: [] }
    });
  }
  reset();

  function spawn(kind, strength, shape = {}) {
    if (!(strength > 0.01)) return;
    if (pulses.length >= HC_PULSE_SLOTS) {
      let oldest = 0;
      for (let i = 1; i < pulses.length; i++) if (pulses[i].age / pulses[i].life > pulses[oldest].age / pulses[oldest].life) oldest = i;
      pulses.splice(oldest, 1);
    }
    const k = HC_PULSE_KINDS[kind];
    const variant = kind === "roll" ? (s.rollParity ^= 1) : 0;
    pulses.push({ kind, strength, age: 0, life: k.life, focus: 0, sweep: 0, run: 0, runRate: 0, angle: 0, ...k, ...shape,
      // build rolls alternate between the edges and the nested contours (overlapping sequences)
      seam: variant ? 0.3 : k.seam, nested: variant ? 0.95 : k.nested });
  }

  // The accent's shape in the current motif.
  function accentShape(bar) {
    const angle = bar * GOLDEN_ANGLE;
    s.accentParity ^= 1;
    const sense = s.accentParity ? 1 : -1;
    if (s.motif === "weave") return { angle, focus: 1.4, sweep: 0.4, run: 0.25, runRate: 1.2 * sense };
    if (s.motif === "circuit") return { angle, focus: 0, sweep: 0.6, run: 0.85, runRate: 1.8 * sense };
    return { angle, focus: 0, sweep: 2.4, run: 0.2, runRate: 1.0 * sense };   // spiral
  }

  const unfoldEnabled = () => options.unfold ?? (globalThis.cyanescentHyperbolicUnfold === false ? false : HC_SETTINGS.unfold);

  function enter(stage) {
    const u = s.unfold;
    u.log.push([+s.time.toFixed(2), stage]);
    if (u.log.length > 32) u.log.shift();
    u.stage = stage; u.t = 0;
    if (stage === "gather") u.away = 0;
    if (stage === "return") s.journeyShift += 1;      // arrive at a different composition
    if (stage === "cooldown") { u.lastEnd = s.time; u.open = 0; u.openV = 0; u.stream = 0; u.streamV = 0; u.bloom = 0; }
  }

  // A critically damped (or, with zeta < 1, slightly bouncy) spring towards goal.
  function spring(x, v, goal, w, zeta, dt) {
    v += (w * w * (goal - x) - 2 * zeta * w * v) * dt;
    return [x + v * dt, v];
  }

  // The Hyperbolic Unfolding. Earned by a deep breakdown or a held build, never by a forecast:
  // the blossom needs an actual qualified drop (the same rule as the drop cascade), so live input
  // without lookahead behaves the same. Every stage has a time limit, and turning it off or a
  // preset reset returns the geometry to rest.
  function stepUnfold(dt, qualifiedDrop) {
    const u = s.unfold, L = HC_UNFOLD;
    u.t += dt;
    // a breakdown with music in it (silence also reads as calm to the audio model). On TestPsy
    // Player's analysis holds calm at 0.45-0.75 through the long breakdown (a build mixed in)
    u.calmHold = s.calm > 0.45 && s.energy > 0.12 ? u.calmHold + dt : Math.max(0, u.calmHold - 2 * dt);
    // the groove back for a while without a qualified drop: the moment has passed
    u.grooveBack = s.drive > 0.7 && s.calm < 0.1 && s.tension < 0.25 ? u.grooveBack + dt : 0;
    const active = u.stage === "gather" || u.stage === "unfold";
    if (active) u.away += dt;
    if (!unfoldEnabled() && u.stage !== "idle" && u.stage !== "cooldown" && u.stage !== "return") enter("return");

    let openGoal = 0, streamRate = 0;
    switch (u.stage) {
      case "idle":
        if (unfoldEnabled() && s.time > L.settle && s.time - u.lastEnd > L.cooldown &&
            (u.calmHold > L.calmHold || (s.buildHold > L.buildHold && s.tension > 0.7))) { u.count += 1; enter("gather"); }
        break;
      case "gather":
        openGoal = 0.32; streamRate = 0.10;
        if (qualifiedDrop) { enter("blossom"); break; }
        if ((u.t > L.gatherMin && s.tension > 0.45) || u.t > L.gatherMax) enter("unfold");
        else if (u.grooveBack > 4) { u.aborts += 1; enter("return"); }
        break;
      case "unfold":
        openGoal = 0.55 + 0.35 * s.tension; streamRate = (0.14 + 0.42 * s.tension) * (u.stream > 4 ? 0.4 : 1);
        if (qualifiedDrop) { enter("blossom"); break; }
        if (u.away > L.maxAway || u.grooveBack > 4) { u.aborts += 1; enter("return"); }
        break;
      case "blossom":
        if (u.t > L.blossom) enter("return");
        break;
      case "return":
        if (u.t > L.returnMin && Math.abs(u.open) < 0.01 && Math.abs(u.stream) < 0.02 && Math.abs(u.streamV) < 0.05) enter("cooldown");
        break;
      case "cooldown":
        if (s.time - u.lastEnd > 2) enter("idle");
        break;
    }

    if (u.stage === "gather" || u.stage === "unfold") {
      [u.open, u.openV] = spring(u.open, u.openV, openGoal, u.stage === "gather" ? 0.45 : 0.6, 1, dt);
      u.streamV = follow(u.streamV, streamRate, dt, 2.5, 2.5);   // the stream's speed eases in
      u.stream += u.streamV * dt;
    } else if (u.stage === "blossom") {
      // the release: the canopy bursts a little further open, then the contours rush back out past
      // their rest (a slightly bouncy spring) while the drop cascade lights the generations
      [u.open, u.openV] = spring(u.open, u.openV, u.t < 0.6 ? 1.0 : 0.15, u.t < 0.6 ? 4.0 : 1.2, 0.8, dt);
      [u.stream, u.streamV] = spring(u.stream, u.streamV, 0, 2.6, 0.5, dt);
    } else if (u.stage === "return") {
      [u.open, u.openV] = spring(u.open, u.openV, 0, 0.9, 1, dt);
      [u.stream, u.streamV] = spring(u.stream, u.streamV, 0, 1.4, 1, dt);
    }
    u.bloom = u.stage === "blossom" ? Math.max(u.bloom, smooth01(u.t / 0.3)) : u.bloom * Math.exp(-dt / 1.6);
    if (u.stage === "idle" || u.stage === "cooldown") { u.open = 0; u.openV = 0; u.stream = 0; u.streamV = 0; }
    // the camera's share: calm, centred on the central polygon while the canopy opens
    // (a critically damped spring: its speed eases in and out, so the view never jolts)
    [s.hero, s.heroV] = spring(s.hero, s.heroV, active || u.stage === "blossom" ? 1 : 0, 0.7, 1, dt);
  }

  // time: seconds (monotonic per preset activation). input: { audio, smooth, music, tempo }.
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = clamp(time - s.lastTime, 0, 0.1);
    s.lastTime = time;
    s.time += dt;
    const { audio = {}, smooth = {}, music = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    s.beat = a.beat;

    // ---- envelopes (slew-limited: nothing below reaches the canopy raw) ---------------------------
    const energyGoal = clamp(0.58 * clamp(audio.globalEnergy ?? a.energy) + 0.42 * clamp(music.highEnergy));
    s.energy = follow(s.energy, energyGoal, dt, 0.6, 1.8);
    // a build over a breakdown (no groove: risers over pads) keeps half the breakdown's calm
    s.calm = follow(s.calm, clamp((a.breakdown - 0.35) / 0.45) * (1 - a.groove * 0.7) * (1 - 0.55 * clamp(Math.max(a.build, clamp(music.buildUp)) * 1.6)), dt, 1.4, 1.8);
    s.drive = follow(s.drive, clamp(a.groove * (0.5 + 0.5 * s.energy)), dt, 0.8, 1.6);
    const forecast = clamp(Math.max(clamp(music.upcomingDrop) * 1.2, a.build));
    s.tension = follow(s.tension, forecast * (1 - s.calm * 0.5), dt, 0.8, 1.2);
    s.bass = follow(s.bass, clamp(Math.max(a.bassDrive, a.subDrive)), dt, 0.12, 0.55);
    s.bassSlow = follow(s.bassSlow, s.bass, dt, 1.2, 2.0);
    s.depth = follow(s.depth, s.bassSlow, dt, 1.5, 1.5);   // the chart's curvature: a third stage, no jolts
    s.mids = follow(s.mids, a.midDrive, dt, 0.25, 0.9);
    s.midsSlow = follow(s.midsSlow, s.mids, dt, 2.5, 3.0);
    // melodic flow: present in every section, carried most visibly by breakdown pads
    s.flowAmount = follow(s.flowAmount, clamp(0.25 + 0.60 * s.mids + 0.20 * s.calm * s.mids + 0.15 * s.tension), dt, 0.6, 1.4);
    s.shimmer = follow(s.shimmer, clamp(0.25 * clamp(smooth.highs) + 0.65 * a.highDrive * (0.4 + 0.6 * s.energy)), dt, 0.08, 0.35);
    // fine detail: treble reveals the embroidery and child tiles; breakdowns favour the delicate interior
    s.detail = follow(s.detail, clamp(0.12 + 0.55 * s.shimmer + 0.35 * s.calm + 0.10 * s.tension), dt, 0.3, 1.2);
    // An earned drop follows a break or a build held for a while. On TestPsy the second of silence
    // before a real drop lifts calm to ~0.25, while the brief builds Player reports inside drives
    // (the groove never leaving) stay below 0.03: those get accents, not the cascade.
    s.calmSeen = Math.max(s.calm, s.calmSeen * Math.exp(-dt / 20));
    s.buildHold = s.tension > 0.6 ? s.buildHold + dt : s.buildHold * Math.exp(-dt / 8);

    // ---- motif: sustained drives alternate lighting behaviours every eight bars -----------------
    const bar = Math.floor(s.beat / 4 + 0.01);
    const block = Math.floor(bar / 8);
    s.motif = HC_MOTIFS[((block % 3) + 3) % 3];
    s.motifGate = follow(s.motifGate, s.motif === "circuit" ? 1 : s.motif === "weave" ? 0.35 : 0.15, dt, 1.5, 1.5);

    // ---- events ---------------------------------------------------------------------------------
    for (const w of events.waves) {
      if (w.kind === "kick") {
        s.kicks += 1;
        const quiet = 1 - 0.7 * s.calm;
        s.impact = Math.max(s.impact, 0.12 * w.strength * quiet * (0.4 + 0.6 * s.drive));
        const phraseBar = w.beatInBar === 0 && ((bar % 4) + 4) % 4 === 0;
        const surge = a.surge > 0.6 && bar - s.lastAccentBar >= 2;
        if ((phraseBar || surge) && bar !== s.lastAccentBar) {
          s.lastAccentBar = bar; s.accents += 1;
          spawn("accent", 1.15 * w.strength * quiet, accentShape(bar));
        } else if (w.beatInBar === 0) spawn("kick", 0.85 * w.strength * quiet, { angle: bar * GOLDEN_ANGLE });
        else if (w.beatInBar === 2 && s.motif === "weave" && s.drive > 0.5 && bar % 2 === 1 && bar !== s.lastCounterBar) {
          // the weave: a front converging through the contours from the far side of the last accent
          s.lastCounterBar = bar; s.counters += 1;
          spawn("counter", 0.8 * w.strength * quiet, { angle: s.lastAccentBar * GOLDEN_ANGLE + Math.PI });
        } else spawn("tick", 0.55 * w.strength * quiet);
      } else if (w.kind === "roll") {
        // build rolls: never in the release after a drop, and never crowding out the kicks
        const rolling = pulses.filter((p) => p.kind === "roll").length;
        if (s.time - s.lastDropAt > 6 && rolling < 5) { s.rolls += 1; spawn("roll", (0.35 + 0.65 * s.tension) * w.strength * 1.6); }
      } else if (w.kind === "tide" && s.calm > 0.4) { s.tides += 1; spawn("tide", 0.5 * w.strength + 0.12); }
    }
    if (events.hats) { s.hatSpark = Math.max(s.hatSpark, 0.45 + 0.55 * a.highDrive); s.hatParity ^= 1; }
    // The kick returning in the middle of a held build (a tease) is a rebound, not the drop. Player's
    // buildUp lags past a real drop (0.5-0.75), so a high, held tension still counts as the drop.
    const bu = clamp(music.buildUp);
    const rebound = events.drop && bu > 0.5 && clamp(music.drop) < 0.6 && (s.tension < 0.85 || bu > 0.9);
    s.qualifiedDrop = false;
    if (events.drop && rebound) { s.rebounds += 1; spawn("accent", 0.9, accentShape(bar)); }
    else if (events.drop) {
      if (s.time - s.lastDropAt > 24 && (s.calmSeen > 0.15 || s.buildHold > 4)) {
        s.qualifiedDrop = true;
        s.lastDropAt = s.time; s.drops += 1; s.calmSeen = 0; s.buildHold = 0;
        pulses.length = 0;
        const heroic = s.unfold.stage === "gather" || s.unfold.stage === "unfold";
        // the blossom's light: stronger, circulating harder, reaching every generation at once
        spawn("drop", heroic ? 1.8 : 1.5, heroic ? { angle: bar * GOLDEN_ANGLE, run: 0.85, runRate: 2.2, sweep: 0.4, tail: 3.8 } : { angle: bar * GOLDEN_ANGLE });
        s.cascade = 1;
        s.releaseV -= 3.2;                       // the membrane's stored tension lets go outwards
      } else spawn("accent", 0.8, accentShape(bar));   // a drop flag inside a sustained section: an accent
    }
    s.impact *= Math.exp(-dt / 0.11);
    s.hatSpark *= Math.exp(-dt / 0.13);
    s.cascade *= Math.exp(-dt / 1.8);
    for (const p of pulses) p.age += dt;
    for (let i = pulses.length - 1; i >= 0; i--) if (pulses[i].age > pulses[i].life) pulses.splice(i, 1);

    stepUnfold(dt, s.qualifiedDrop);

    // ---- membrane ---------------------------------------------------------------------------------
    // + draws the nested contours in (taut), - lets them out. The off-beat pump sits where
    // psytrance's rolling bass sits (0 on the kick, 1 between kicks); breakdowns breathe over
    // four bars; a build grows taut; a qualified drop kicks a damped spring outwards.
    const pump = 0.5 - 0.5 * Math.cos(TAU * s.beat);
    const twoBar = 0.5 + 0.5 * Math.sin(TAU * s.beat / 8);
    const fourBar = 0.5 + 0.5 * Math.sin(TAU * s.beat / 16);
    s.tautness = follow(s.tautness, clamp(s.tension * (0.4 + 0.6 * smooth01(s.buildHold / 8))), dt, 1.2, 0.6);
    const w0 = 3.2, zeta = 0.42;
    s.releaseV += (-w0 * w0 * s.release - 2 * zeta * w0 * s.releaseV) * dt;
    s.release += s.releaseV * dt;
    const groove = s.bass * (1 - s.calm) * (0.62 * pump * s.drive + 0.38 * twoBar);
    const relaxed = s.calm * (0.25 + 0.45 * s.bassSlow) * fourBar;
    s.membrane = clamp(groove + relaxed + 0.55 * s.tautness + s.release, -1.2, 1.4);

    // ---- phrase evolution (32 beats): contour prominence, depth, recursion, ribbon weight --------
    const phrase = Math.floor(s.beat / 32);
    const goal = [0.80 + 0.40 * hash(phrase), 0.28 * (hash(phrase + 17.3) - 0.5), 1.1 * (hash(phrase + 41.9) - 0.4), 0.75 + 0.5 * hash(phrase + 73.1)];
    for (let i = 0; i < 4; i++) s.evolve[i] = follow(s.evolve[i], goal[i], dt, 6, 6);

    // ---- melody -----------------------------------------------------------------------------------
    s.quiet = follow(s.quiet, clamp(1 - s.drive) * (0.45 + 0.55 * s.mids), dt, 1.5, 1.5);
    s.sustain = follow(s.sustain, clamp((s.midsSlow - 0.25) * 1.8) * (0.45 + 0.55 * s.calm + 0.3 * s.tension), dt, 2.0, 2.5);
    s.energetic = follow(s.energetic, s.drive * (0.3 + 0.7 * s.mids) * (0.35 + 0.65 * s.motifGate), dt, 1.0, 1.5);
    s.cometCount = follow(s.cometCount, 1 + 2 * s.tension, dt, 2.0, 2.0);
    s.laneSync = follow(s.laneSync, Math.pow(s.tension, 1.5), dt, 1.5, 1.5);
    s.circPhase += dt * (0.25 + 0.9 * s.mids * s.drive + 0.4 * s.tension);
    s.sweepPhase += dt * (0.22 + 0.35 * s.midsSlow - 0.08 * s.calm);

    // ---- motion clocks ----------------------------------------------------------------------------
    // The journey's pace is section-level only (4 s follower): drives float a little quicker,
    // breakdowns slower, a build holds still in anticipation.
    s.pace = follow(s.pace, (0.80 + 0.45 * s.drive - 0.35 * s.calm - 0.15 * s.tension) * (1 - 0.6 * s.hero), dt, 4, 4);
    s.J += dt * s.pace;
    s.turn += dt * 0.022 * s.midsSlow * (1 - 0.5 * s.calm);   // melody turns the canopy a little more
    s.flowPhase += dt * (0.10 + 0.32 * s.mids + 0.22 * s.tension + 0.10 * s.drive - 0.03 * s.calm);
    s.threadPhase += dt * (0.55 + 1.6 * s.shimmer);
    s.lumPhase += dt * (0.18 + 0.10 * s.calm);
    s.drift += dt * (0.003 + 0.009 * s.calm);   // one palette step per ~80 s of breakdown, ~5 min otherwise

    // Tessellation family: the original phrase crossfade, slew-limited so a jump in the phrase
    // clock (a beat-grid relock) cannot snap the canopy from one family to the other.
    const cycle = 0.5 - 0.5 * Math.cos(TAU * clamp(music.phraseProgress));
    const blendGoal = cycle <= 0.08 ? 0 : cycle >= 0.92 ? 1 : smooth01((cycle - 0.08) / 0.84);
    if (s.blend === null) s.blend = blendGoal;
    s.blend += clamp(blendGoal - s.blend, -1.5 * dt, 1.5 * dt);

    // ---- view: landmarks, drift, rotation, viewing distance ----------------------------------------
    const journeyIndex = Math.floor(s.J / 26) + s.journeyShift;   // ~16 bars at a normal pace
    s.landmark = JOURNEY[journeyIndex % JOURNEY.length];
    const landmark = hcLandmark(s.landmark, s.blend, journeyIndex);
    // the unfolding centres the central polygon, so the geometry carries the spectacle
    const target = [landmark[0] * (1 - s.hero), landmark[1] * (1 - s.hero)];
    const wf = 0.26;   // critically damped, ~12 s to settle: an approach, never a throw
    for (let i = 0; i < 2; i++) {
      s.focusV[i] += (wf * wf * (target[i] - s.focus[i]) - 2 * wf * s.focusV[i]) * dt;
      s.focus[i] += s.focusV[i] * dt;
    }
    const [dx, dy, spin] = hcView(s.J);
    const rotation = spin + s.turn;
    // the canopy point under the screen centre is rotate(-a, rotation): put the landmark there
    const toCentre = rotate2(s.focus, -rotation);
    const drift = 0.45 * (1 - 0.7 * s.hero);
    const ax = drift * dx - toCentre[0], ay = drift * dy - toCentre[1];
    // viewing distance: mostly nearer (larger polygons) than Pass 1's rest, sometimes a little farther
    const distance = 0.07 * Math.sin(TAU * s.J / 95) + 0.035 * Math.sin(TAU * s.J / 41 + 1.3) - 0.03;

    // ---- uniforms -------------------------------------------------------------------------------
    uniforms.hcView = [ax, ay, rotation, 0.98 + 0.03 * s.depth + distance];
    uniforms.hcShape = [s.detail, Math.max(s.energy, 0.85 * s.cascade), s.blend, 0];
    // edges at rest: dimmer than Pass 1 so travelling light has room (contrast), dimmest in breakdowns
    uniforms.hcLight = [0.42 - 0.20 * s.calm - 0.04 * s.drive, s.impact, s.hatSpark, s.hatParity];
    uniforms.hcFlow = [s.flowPhase % 4096, s.flowAmount * (1 - 0.35 * s.cascade), s.shimmer, s.threadPhase % 4096];
    uniforms.hcMood = [s.calm, s.tension, s.cascade, s.drift];
    uniforms.hcMembrane = [s.membrane, 0.014 * s.bassSlow + 0.006, s.lumPhase % 4096, s.tautness];
    // breakdowns: the broad ribbons and contours recede so the delicate detail and melody carry it
    uniforms.hcEvolve = [s.evolve[0] * (1 - 0.30 * s.calm), s.evolve[1], s.evolve[2], s.evolve[3] * (1 - 0.50 * s.calm)];
    uniforms.hcMelody = [s.quiet, s.sustain, s.energetic, s.sweepPhase % 3072];
    uniforms.hcMelody2 = [s.cometCount, s.laneSync, s.circPhase % 4096, 0];
    uniforms.hcUnfold = [s.unfold.open, s.unfold.stream, s.unfold.bloom, 0];
    pulseA.fill(0); pulseB.fill(0); pulseC.fill(0); pulseD.fill(0);
    for (let i = 0; i < HC_PULSE_SLOTS; i++) {
      const p = pulses[i];
      if (!p) { pulseA[i * 4 + 1] = 1; pulseA[i * 4 + 3] = 1; pulseB[i * 4 + 3] = 1; continue; }   // non-zero widths: no 0/0
      const fadeIn = clamp(p.age / 0.03);
      const fadeOut = 1 - smooth01((p.age / p.life - 0.6) / 0.4);
      pulseA.set([p.start + p.speed * p.age, p.tail, p.strength * fadeIn * fadeOut, Math.sign(p.speed)], i * 4);
      pulseB.set([p.seam, p.nested, p.soak, p.reach], i * 4);
      pulseC.set([Math.cos(p.angle), Math.sin(p.angle), p.focus, p.sweep], i * 4);
      pulseD.set([p.run, p.runRate, 0, 0], i * 4);
    }
    uniforms.hcPulseA = pulseA;
    uniforms.hcPulseB = pulseB;
    uniforms.hcPulseC = pulseC;
    uniforms.hcPulseD = pulseD;
    return s;
  }

  return { state: s, step, uniforms: () => uniforms, pulses };
}

const cache = new WeakMap();

export function bindHyperbolicCarpetDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime) { runtime = { director: createHyperbolicCarpetDirector(), lastTime: -1 }; cache.set(gl, runtime); }
  const director = opts.director || runtime.director;
  // a frame drawn twice at the same time (transition, re-render) reuses the state
  if (time !== runtime.lastTime || opts.director) { director.step(time, input); runtime.lastTime = time; }
  const loc = (name) => uniformLocation(gl, program, name);
  const dirLoc = loc("hcDir");
  if (dirLoc) gl.uniform1f(dirLoc, 1);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (!l) continue;
    if (value.length > 4) gl.uniform4fv(l, value);
    else gl.uniform4f(l, value[0], value[1], value[2], value[3]);
  }
  return director;
}
