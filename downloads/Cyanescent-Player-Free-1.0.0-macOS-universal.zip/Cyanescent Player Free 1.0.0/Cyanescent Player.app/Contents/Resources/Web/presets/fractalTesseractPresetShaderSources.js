// The primary march, emitted once per distance field (see seamRay in main).
// A ray that uses up its 60 steps without a confirmed hit (threading the narrow
// gaps between spheres) continues with a pixel-sized hit tolerance, instead of
// being shaded at whatever point it stopped. Rare, so its cost is small.
function marchSource(field) {
  return `        for (int i = 0; i < 60; i++) {
            p = ro + rd * t;
            d = ${field};
            if (d < 0.001) { hit = true; break; }
            if (t > 10.0) break;
            glow += 0.005 / (0.005 + abs(d)) * (1.0 + highs);
            minD = min(minD, d / max(t, 0.5));
            t += d;
        }
        exhausted = !hit && t < 10.0;
        if (exhausted) {
            for (int i = 0; i < FT_EXTRA_STEPS; i++) {
                if (d < max(0.001, 1.5 * pixel * t)) { hit = true; break; }
                if (t > 10.0) break;
                t += d;
                p = ro + rd * t;
                d = ${field};
            }
        }`;
}

export function createFractalTesseractPresetShaderEntries({ modularShaderPrelude, modularTransitionShaderBlock }) {
  return [[143, {
    name: "Fractal Tesseract",
    source: `${modularShaderPrelude}
${modularTransitionShaderBlock}

// The fold of map1005 is unchanged: abs, offset, the xy/xz/yz rotations and x2,
// six times. Its rotation only depends on uniforms, so the three plane rotations
// (and the x2 scale) are composed into one matrix per pixel instead of 18 sin/cos
// pairs per distance sample. ftFoldRotate is the original rotation code.
#ifndef FT_EXTRA_STEPS
#define FT_EXTRA_STEPS 32
#endif
mat3 ftFold;
vec3 ftOffset;

vec3 ftFoldRotate(vec3 p, float t) {
    p.xy *= rot(t);
    p.xz *= rot(t * 0.7);
    p.yz *= rot(t * 1.1);
    return p;
}

// Fold timing. The original drove the fold angle with bassRel and the offset with
// midRel: fast/slow band ratios that leap within ~35 ms on kicks and transients,
// and six nested folds amplify a leap into a visible jump of the whole lattice.
// The structure now evolves on the original autonomous clock, with only slow
// musical drift: u_slowBass (a ~0.7 s average of the bass band, smooth on both the
// live and export paths) leans the angle and offset over seconds, so a breakdown
// into a drop refolds the lattice gracefully. Fast music goes to the materials.
// FT_FOLD_MODE (A/B only): 0 = original, 1 = autonomous only, 2 = slow musical,
// 3 = original bass term only, 4 = original mid term only.
#ifndef FT_FOLD_MODE
#define FT_FOLD_MODE 2
#endif
void ftPrepareFold() {
#if FT_FOLD_MODE == 0
    float t = presetTime * 0.2 + bassRel * 0.1;
    ftOffset = vec3(0.5 + 0.1 * midRel);
#elif FT_FOLD_MODE == 1
    float t = presetTime * 0.2 + 0.1;
    ftOffset = vec3(0.6);
#elif FT_FOLD_MODE == 3
    float t = presetTime * 0.2 + bassRel * 0.1;
    ftOffset = vec3(0.6);
#elif FT_FOLD_MODE == 4
    float t = presetTime * 0.2 + 0.1;
    ftOffset = vec3(0.5 + 0.1 * midRel);
#else
    float slow = clamp(u_slowBass, 0.0, 1.0) - 0.5;
    float t = presetTime * 0.2 + 0.1 + 0.05 * slow;
    ftOffset = vec3(0.6 + 0.035 * slow);
#endif
    ftFold = mat3(ftFoldRotate(vec3(1.0, 0.0, 0.0), t),
                  ftFoldRotate(vec3(0.0, 1.0, 0.0), t),
                  ftFoldRotate(vec3(0.0, 0.0, 1.0), t)) * 2.0;
}

// Centre seam correction. The first fold mirrors space about x = 0 and y = 0,
// planes that contain the camera. A sphere whose centre lies a distance a just
// across a mirror plane leaves a cap on this side, which the fold turns into a lens
// (the sphere intersected with its mirror image) straddling the plane; seen exactly
// edge-on, these lenses line up into dark blades along the centre row and column.
// Each lens is completed into the round sphere through its rim: centred on the
// plane, radius sqrt(r^2 - a^2). It contains the lens, equals the original sphere
// as a -> 0 and shrinks to nothing as a -> r, so nothing pops; nothing is removed.
// Only evaluated within one sphere radius of the two planes.
const float FT_RADIUS = 1.0 / 64.0;

// Centre, in first-fold space, of the sphere whose fold cell contains a (for the
// field ftMapFolded): the six folds unwound through their recorded mirror signs.
vec3 ftCellCentre(vec3 a) {
    vec3 q = ftFold * (a - ftOffset);
    vec3 s1 = vec3(1.0), s2 = vec3(1.0), s3 = vec3(1.0), s4 = vec3(1.0), s5 = vec3(1.0);
    for (int i = 1; i < 6; i++) {
        vec3 s = vec3(q.x < 0.0 ? -1.0 : 1.0, q.y < 0.0 ? -1.0 : 1.0, q.z < 0.0 ? -1.0 : 1.0);
        if (i == 1) s1 = s; else if (i == 2) s2 = s; else if (i == 3) s3 = s; else if (i == 4) s4 = s; else s5 = s;
        q = ftFold * (q * s - ftOffset);
    }
    mat3 back = transpose(ftFold) * 0.25;
    vec3 c = s5 * ftOffset;
    c = s4 * (back * c + ftOffset);
    c = s3 * (back * c + ftOffset);
    c = s2 * (back * c + ftOffset);
    c = s1 * (back * c + ftOffset);
    return back * c + ftOffset;
}

// Distance from a (already in the positive octant) to the completed lens spheres
// of the two centre planes; sphere returns the nearest one (centre, radius).
float ftLensSpheres(vec3 a, out vec4 sphere) {
    float best = 1e3;
    sphere = vec4(0.0, 0.0, 0.0, -1.0);
    if (a.y < FT_RADIUS) {
        vec3 c = ftCellCentre(vec3(a.x, -a.y, a.z));
        if (c.y < 0.0 && c.y > -FT_RADIUS) {
            vec4 s = vec4(c.x, 0.0, c.z, sqrt(FT_RADIUS * FT_RADIUS - c.y * c.y));
            float d = length(a - s.xyz) - s.w;
            if (d < best) { best = d; sphere = s; }
        }
    }
    if (a.x < FT_RADIUS) {
        vec3 c = ftCellCentre(vec3(-a.x, a.y, a.z));
        if (c.x < 0.0 && c.x > -FT_RADIUS) {
            vec4 s = vec4(0.0, c.y, c.z, sqrt(FT_RADIUS * FT_RADIUS - c.x * c.x));
            float d = length(a - s.xyz) - s.w;
            if (d < best) { best = d; sphere = s; }
        }
    }
    return best;
}

// map1005 after its first abs(): the fold of a point already mirrored into the
// positive octant. Evaluated slightly outside that octant it continues the surface
// smoothly, which is what the one-sided normals below rely on.
float ftMapFolded(vec3 a) {
    vec3 q = ftFold * (a - ftOffset);
    for (int i = 1; i < 6; i++) {
        q = ftFold * (abs(q) - ftOffset);
    }
    return (length(q) - 1.0) / 64.0;
}

// Exact surface normal: inside one fold cell the field is |M p + b| - 1, so its
// gradient is the final point carried back through the six folds (transposed
// rotation, then the recorded mirror signs). Cheaper than finite differences and
// one-sided at every mirror plane, so no line appears where mirrored halves meet
// and nothing leaks in from neighbouring cells near the removed blades.
vec3 ftNormal(vec3 p) {
    vec3 q = p;
    vec3 s0 = vec3(1.0), s1 = vec3(1.0), s2 = vec3(1.0), s3 = vec3(1.0), s4 = vec3(1.0), s5 = vec3(1.0);
    for (int i = 0; i < 6; i++) {
        vec3 s = vec3(q.x < 0.0 ? -1.0 : 1.0, q.y < 0.0 ? -1.0 : 1.0, q.z < 0.0 ? -1.0 : 1.0);
        if (i == 0) s0 = s; else if (i == 1) s1 = s; else if (i == 2) s2 = s;
        else if (i == 3) s3 = s; else if (i == 4) s4 = s; else s5 = s;
        q = ftFold * (q * s - ftOffset);
    }
    mat3 ft = transpose(ftFold);
    vec3 g = s5 * (ft * q);
    g = s4 * (ft * g);
    g = s3 * (ft * g);
    g = s2 * (ft * g);
    g = s1 * (ft * g);
    g = s0 * (ft * g);
    return normalize(g);
}

// The marched field: the original fold, with its centre-plane lenses completed.
float map1005(vec3 p) {
    vec3 a = abs(p);
    float d = ftMapFolded(a);
#ifndef FT_NO_SEAM_FIX
    if (min(a.x, a.y) < FT_RADIUS) {
        vec4 sphere;
        d = min(d, ftLensSpheres(a, sphere));
    }
#endif
    return d;
}

// Shading-only twin of map1005: also returns a smooth orbit trap (where the point
// sits after the coarse folds) that drifts material and iridescence across regions.
float ftMapTrap(vec3 p, out float trap) {
    trap = 0.0;
    vec3 q = p;
    for (int i = 0; i < 6; i++) {
        q = ftFold * (abs(q) - ftOffset);
        if (i == 1) trap = length(q) * 0.25;
    }
    return (length(q) - 1.0) / 64.0;
}

// Gaussian band of half-width w around 0 (explicit square: pow() of a negative is undefined).
float ftBand(float x, float w) {
    float u = x / w;
    return exp(-u * u);
}

// Restrained thin-film tint: cyan and violet, with gold only near the top of the cycle.
// flow shifts the cyan/violet cycle alone.
vec3 ftFilm(float phase, float flow) {
    float c = 0.5 + 0.5 * cos(6.28318 * (phase + flow));
    vec3 film = mix(vec3(0.10, 0.86, 1.00), vec3(0.30, 0.45, 1.00), smoothstep(0.0, 0.5, c));
    film = mix(film, vec3(0.72, 0.30, 1.00), smoothstep(0.5, 1.0, c));
    float gold = smoothstep(0.82, 0.98, 0.5 + 0.5 * cos(6.28318 * (phase * 0.5 + 0.21)));
    return mix(film, vec3(1.00, 0.72, 0.34), gold * 0.8);
}

// Procedural surroundings for reflections: black space, a soft warm key panel,
// a cool cyan panel, a violet horizon band and a faint gold low lobe.
vec3 ftEnvironment(vec3 r, vec3 keyDir, float energy) {
    float up = r.y;
    vec3 c = mix(vec3(0.010, 0.008, 0.020), vec3(0.030, 0.026, 0.060), smoothstep(-0.6, 0.2, up));
    // Broad overhead panel: gives every sphere a soft cool-white crown.
    c += vec3(0.52, 0.54, 0.58) * smoothstep(0.05, 0.85, up) * (0.75 + 0.35 * energy);
    // Violet horizon band and a cyan panel to the left.
    c += vec3(0.20, 0.09, 0.42) * pow(max(0.0, 1.0 - abs(up - 0.02) * 2.2), 3.0) * (0.75 + 0.45 * energy);
    c += vec3(0.08, 0.50, 0.66) * pow(max(dot(r, normalize(vec3(-0.80, 0.25, -0.55))), 0.0), 5.0);
    // Warm key softbox and a low gold bounce.
    c += vec3(1.00, 0.88, 0.70) * 3.0 * pow(max(dot(r, keyDir), 0.0), 24.0);
    c += vec3(1.00, 0.66, 0.28) * 0.30 * pow(max(dot(r, normalize(vec3(0.6, -0.7, -0.4))), 0.0), 6.0);
    return c;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * resolution.xy) / resolution.y;
    vec3 ro = vec3(0.0, 0.0, -2.5);
    vec3 rd = normalize(vec3(uv, 1.0));
    ftPrepareFold();

    float t = 0.0;
    vec3 p = ro;
    float d = 1.0;
    float glow = 0.0;
    float minD = 1e3;
    bool hit = false;

    // Only rays that pass within one sphere radius of the centre planes (beyond the
    // camera's first metre, before which there is no structure) can meet a completed
    // lens; the camera sits on both planes, so that is known per pixel. Those rays
    // (a few percent of the screen) march the corrected field, all others the plain
    // fold, which keeps the per-step cost of the main march unchanged.
    float pixel = 1.0 / resolution.y;
    bool exhausted = false;
#ifdef FT_NO_SEAM_FIX
    bool seamRay = false;
#else
    bool seamRay = min(abs(rd.x), abs(rd.y)) < FT_RADIUS;
#endif
    if (seamRay) {
${marchSource("map1005(p)")}
    } else {
${marchSource("ftMapFolded(abs(p))")}
    }

    // Musical light: steady energy (not kick transients) opens up the light; calm
    // and breakdown sections close it down to a cooler, contemplative glimmer.
    float energy = clamp(globalEnergy, 0.0, 1.0);
    float calm = clamp(max(calmState, breakdownState), 0.0, 1.0);
    float lift = (0.72 + 0.42 * energy + 0.12 * clamp(highEnergyState, 0.0, 1.0)) * (1.0 - 0.28 * calm);
    vec3 keyDir = normalize(vec3(1.0, 2.0, -2.0));

    // Musical materials. The fold no longer takes fast music; it is expressed here,
    // in light travelling through the spheres. All clocks are stateless (beat phase,
    // the drop map's decay, accumulated phases), so seeking and export reproduce them.
    //  groove: how strongly the beat drives the lattice (none in calm/breakdowns).
    //  build:  build-ups add half-beat waves and richer film.
    //  drop:   dropState is the drop map's exp(-age / 2 s) decay; its age clocks one
    //          wide wave of light from the centre out through the whole lattice.
#ifdef FT_NO_MUSIC_MATERIALS
    float groove = 0.0, build = 0.0, dropOn = 0.0, dropAge = 0.0, sparkleAmp = 0.0, midsFlow = 0.0, bassRich = 0.5, flowPhase = 0.0;
#else
    float groove = clamp(0.35 * energy + 0.65 * max(clamp(highEnergyState, 0.0, 1.0), 0.8 * clamp(mainRiffState, 0.0, 1.0)), 0.0, 1.0) * (1.0 - 0.85 * calm);
    float build = clamp(buildUpState, 0.0, 1.0) * (1.0 - calm);
    float dropOn = smoothstep(0.03, 0.12, dropState);
    float dropAge = -2.0 * log(max(dropState, 1e-4));
    float sparkleAmp = smoothstep(0.12, 0.6, highs) * (1.0 - 0.7 * calm);
    float midsFlow = clamp(mids, 0.0, 1.0) * (1.0 - 0.5 * calm);
    float bassRich = clamp(u_slowBass, 0.0, 1.0);
    float flowPhase = 0.04 * u_wavePhase;
#endif

    vec3 col = vec3(0.0);
#ifdef FT_DEBUG
    if (FT_DEBUG == 3) { outColor = vec4(vec3(hit ? 1.0 : 0.0), 1.0); return; }
    if (FT_DEBUG == 2) { outColor = vec4(vec3(hit ? (t - 1.0) / 2.0 : 1.0), 1.0); return; }
    if (FT_DEBUG == 1) { outColor = vec4(hit ? (exhausted ? vec3(0.0, 1.0, 0.0) : vec3(0.4)) : (t < 10.0 ? vec3(1.0, 0.0, 0.0) : vec3(0.0)), 1.0); return; }
#endif
    if (hit) {
#ifdef FT_NO_SEAM_FIX
        // Previous version: tetrahedral finite differences (A/B reference only).
        float eps = max(0.0012, 0.5 * pixel * t);
        vec2 k = vec2(1.0, -1.0);
        vec3 n = normalize(k.xyy * map1005(p + k.xyy * eps) + k.yyx * map1005(p + k.yyx * eps) +
                           k.yxy * map1005(p + k.yxy * eps) + k.xxx * map1005(p + k.xxx * eps));
#else
        vec3 n = ftNormal(p);
        vec3 pa = abs(p);
        if (min(pa.x, pa.y) < FT_RADIUS) {
            vec4 sphere;
            if (ftLensSpheres(pa, sphere) < ftMapFolded(pa)) {
                vec3 side = vec3(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0, p.z < 0.0 ? -1.0 : 1.0);
                n = side * normalize(pa - sphere.xyz);
            }
        }
#endif
        float trap;
        float d0 = ftMapTrap(p, trap);
#ifndef FT_NO_SEAM_FIX
        if (min(abs(p.x), abs(p.y)) < FT_RADIUS) { vec4 sphere; d0 = min(d0, ftLensSpheres(abs(p), sphere)); }
#endif
        // Two-tap occlusion along the normal: the seams between spheres darken.
        float ao = clamp(0.5 + 0.5 * ((map1005(p + n * 0.007) - d0) / 0.007 * 0.55 +
                                      (map1005(p + n * 0.018) - d0) / 0.018 * 0.45), 0.0, 1.0);
        ao = ao * ao;
#ifdef FT_DEBUG
        if (FT_DEBUG == 4) { outColor = vec4(vec3(0.15 + 0.85 * max(dot(n, normalize(vec3(1.0, 2.0, -2.0))), 0.0)), 1.0); return; }
        if (FT_DEBUG == 5) { outColor = vec4(n * 0.5 + 0.5, 1.0); return; }
        if (FT_DEBUG == 7) { vec4 sph; float dl = ftLensSpheres(abs(p), sph); outColor = vec4(dl < ftMapFolded(abs(p)) ? vec3(1.0, 0.4, 0.1) : vec3(0.3), 1.0); return; }
        if (FT_DEBUG == 6) { outColor = vec4(vec3(ao), 1.0); return; }
#endif

        vec3 v = -rd;
        float ndv = clamp(dot(n, v), 0.0, 1.0);
        vec3 r = reflect(rd, n);
        float fres = pow(1.0 - ndv, 5.0);

        // Waves of light belong to the spheres: each sphere is lit as a front passes
        // its centre (the hit point less one radius along the normal). Fronts travel
        // outward from the central axis and back into the depth of the fold.
        vec3 centre = p - n * FT_RADIUS;
        float reach = length(centre.xy) + 0.5 * (t - 1.3);
        // Beat waves: a narrow shell per beat (and per half beat in builds), lighting
        // a different half of the spheres each beat; it starts at the centre with the
        // beat and has faded before the next, so the selection never switches mid-wave.
        float beatA = fract(absoluteBeat), beatB = fract(absoluteBeat * 2.0);
        float shellA = ftBand(reach - beatA * 1.5, 0.07) * (1.0 - beatA) * (1.0 - beatA);
        float shellB = ftBand(reach - beatB * 1.5, 0.07) * (1.0 - beatB) * (1.0 - beatB);
        float chosen = smoothstep(0.3, 0.85, 0.5 + 0.5 * sin(dot(centre, vec3(91.7, 57.3, 73.1)) + floor(absoluteBeat) * 2.399));
        float beatWave = mix(shellA, max(shellA, shellB), 0.7 * build) * chosen * groove;
        // The drop wave: wide, through every sphere, cyan turning violet then gold.
        float dropFront = dropAge * 0.75;
        float dropWave = dropOn * smoothstep(0.0, 0.12, dropAge) * exp(-0.45 * dropAge) *
                         (ftBand(reach - dropFront, 0.16) + 0.18 * smoothstep(dropFront, dropFront - 0.6, reach));
        vec3 dropCol = mix(mix(vec3(0.15, 0.85, 1.00), vec3(0.62, 0.30, 1.00), smoothstep(0.3, 1.2, dropAge)),
                           vec3(1.00, 0.72, 0.36), smoothstep(1.4, 2.6, dropAge) * 0.7);
        // High-frequency glints: individual spheres' highlights flare briefly.
        float glint = pow(max(0.0, sin(dot(centre, vec3(53.1, 97.3, 41.9)) + presetTime * 1.7)), 60.0) * sparkleAmp;

        // Material drifts smoothly between obsidian, dark titanium and liquid chrome.
        float region = 0.5 + 0.5 * sin(trap * 5.0 + presetTime * 0.05);
        float metal = smoothstep(0.0, 0.55, region);
        vec3 titanium = vec3(0.30, 0.31, 0.36);
        vec3 chrome = vec3(0.62, 0.64, 0.70);
        vec3 f0 = mix(vec3(0.045), mix(titanium, chrome, smoothstep(0.65, 1.0, region)), metal);
        vec3 albedo = mix(vec3(0.030, 0.030, 0.042), vec3(0.012, 0.012, 0.016), metal);

        // Iridescent film: shifts with view angle, region and the original drifting
        // diagonal (p.x + p.y + time) of the cosine palette.
        // Mid frequencies thicken the film; the level-paced wave phase keeps it flowing.
        // (The flow moves only the cyan/violet cycle; gold stays an occasional accent.)
        float phase = 0.5 * ndv + trap * 0.35 + (p.x + p.y) * 0.38 + presetTime * 0.03;
        vec3 film = ftFilm(phase, flowPhase);
        float filmAmount = (0.55 + 0.2 * energy) * (1.0 - 0.25 * calm) + 0.12 * midsFlow + 0.15 * build + 0.35 * beatWave + 0.3 * dropWave;
        vec3 spec0 = mix(f0, f0 * film * 1.9, filmAmount);
        vec3 fresnel = spec0 + (vec3(1.0) - spec0) * fres * mix(vec3(1.0), film, 0.55);

        // Key (warm), fill (cool cyan) and back rim (violet) lights.
        vec3 keyCol = vec3(1.00, 0.90, 0.78) * 2.4 * lift;
        vec3 fillDir = normalize(vec3(-1.2, -0.35, -0.8));
        vec3 fillCol = vec3(0.18, 0.62, 0.85) * 0.75 * lift;
        vec3 rimDir = normalize(vec3(-0.2, 0.35, 1.0));
        vec3 rimCol = vec3(0.50, 0.32, 1.00) * (0.6 + 0.5 * energy) * (1.0 - 0.2 * calm);

        float shadowSoft = mix(0.35, 1.0, ao);
        vec3 h1 = normalize(keyDir + v);
        float ndl1 = max(dot(n, keyDir), 0.0);
        float nh1 = max(dot(n, h1), 0.0);
        float broad = pow(nh1, 60.0) * 2.6;
        // The pin-point lobe fades on the small, deep spheres where it would shimmer.
        float sharp = pow(nh1, 700.0) * 9.0 * (1.0 - smoothstep(1.5, 2.0, t)) * (1.0 + 1.5 * glint);
        col += keyCol * ndl1 * (albedo + fresnel * (broad + sharp)) * shadowSoft;

        vec3 h2 = normalize(fillDir + v);
        float ndl2 = max(dot(n, fillDir), 0.0);
        col += fillCol * ndl2 * (albedo + fresnel * pow(max(dot(n, h2), 0.0), 40.0) * 0.6) * ao;

        // Rim: light wrapping round the silhouettes from behind; strongest at the
        // edges of apertures, where the surfaces turn away into open space.
        float rim = pow(1.0 - ndv, 3.0) * smoothstep(-0.3, 0.6, dot(n, rimDir));
        col += rimCol * rim * mix(vec3(1.0), film, 0.5) * (0.35 + 0.65 * ao);

        // Reflected surroundings, occluded in the seams; sustained bass deepens them,
        // and a passing wave makes the sphere's reflections flare in its own film colour.
        col += ftEnvironment(r, keyDir, energy) * fresnel * mix(0.25, 1.0, ao) * lift * (0.85 + 0.3 * bassRich) * (1.0 + 0.35 * beatWave + 0.6 * dropWave);
        vec3 waveCol = mix(vec3(0.12, 0.80, 1.00), vec3(0.60, 0.30, 1.00), smoothstep(0.2, 1.3, reach));
        col += (waveCol * mix(vec3(1.0), film, 0.4) * beatWave * 0.2 + dropCol * dropWave * 0.32) * (0.4 + 0.6 * ao) * (0.5 + 0.5 * ndv);

        // Depth reveals the machine: surfaces at the front of the fold catch the key
        // light, recesses fall away from it and glow from within instead. Tunnels and
        // apertures read as light leaking from a deeper space.
        float depth = smoothstep(1.32, 2.05, t);
        col *= mix(1.15, 0.42, depth);
        vec3 inner = mix(vec3(0.12, 0.70, 1.00), vec3(0.62, 0.26, 1.00), 0.5 + 0.5 * sin(phase * 2.6 + 1.3));
        col += inner * depth * depth * (0.16 + 0.26 * energy) * (1.0 - 0.35 * calm) * (0.45 + 0.55 * ao) * (0.6 + 0.4 * ndv);

        // Faint luminescence in the seams, keeping the lattice lines of the original.
        float seam = (1.0 - ao) * (1.0 - ao);
        col += mix(vec3(0.30, 0.12, 0.85), vec3(0.08, 0.55, 0.85), 0.5 + 0.5 * sin(trap * 3.0 + presetTime * 0.07)) *
               seam * (0.10 + 0.14 * energy) * (1.0 - 0.4 * calm);
        col += vec3(0.5, 0.2, 1.0) * glow * 0.006 * (0.6 + 0.6 * energy);
    } else {
        // Open space: near-black depths, with the structure's violet/cyan halo hugging
        // the aperture rims (closest approach of the ray) and a whisper of nebula.
        vec3 deep = vec3(0.004, 0.003, 0.010) + vec3(0.020, 0.010, 0.045) * smoothstep(1.2, 0.0, length(uv));
        float halo = exp(-minD * 420.0);
        float aura = exp(-minD * 90.0);
        vec3 haloCol = mix(vec3(0.15, 0.70, 1.00), vec3(0.62, 0.28, 1.00), smoothstep(0.0, 1.0, aura - halo));
        col = deep + haloCol * (halo * 0.45 + aura * 0.05) * (0.55 + 0.6 * energy) * (1.0 - 0.3 * calm);
        col += vec3(0.5, 0.2, 1.0) * glow * 0.012 * (0.6 + 0.6 * energy) * (1.0 - 0.3 * calm);
    }

    // Soft filmic shoulder: highlights roll off instead of clipping white.
    col = vec3(1.0) - exp(-col * 1.8);
    col = pow(col, vec3(0.92));

    outColor = vec4(col, 1.0);
}
`
  }]];
}
