// Tesseract Unfolding (preset 148): The Hyperdimensional Engine — the director.
//
// The machine is one 4D object, a Menger tesseract (a hypercube whose sub-hypercubes with three or
// four middle coordinates are removed, recursively), seen as its 3D cross-section with a hyperplane.
// The hyperplane is fixed in the viewer's world; the machine rotates through it in SO(4), so every
// wall, aperture and chamber on screen is a genuine slice that refolds as the rotation proceeds.
// Inside the great central chamber hang three nested tesseract frames (their 2-skeletons sliced
// are polyhedral cages whose shape changes with their own 4D rotations) around a crystal core that
// morphs between the 24-cell, the tesseract and the 16-cell.
//
// This file is pure JS (no GL) so it can be tested. It turns Player's analysis into:
//   orientation  the machine's SO(4) rotation as a quaternion pair: a slow drift whose speed follows
//                the music, plus eased "revelations" (drops) towards sacred orientations (axis, edge,
//                face and long diagonals), and a return to the plain Menger slice once per journey
//   corridor     while the camera flies through an aperture, the rotation is bent (minimally) so
//                the flight axis lies on a 4D coordinate axis: the aperture tunnel then provably
//                contains the camera whatever the rest of the rotation does
//   journey      a closed camera path: encounter outside, approach, passage through an aperture,
//                the central chamber, emergence on the far side, return. Speed follows the music;
//                before a forecast drop the camera waits at the threshold and plunges on the drop
//   apertures    hole widths per sponge level (drops burst the great apertures open, builds tighten)
//   gyros        nested frame rotations, sizes ("unfolding", mids) and 4D offsets (one recedes into
//                the fourth dimension while another emerges)
//   pulses       kicks send light outwards through the framework as expanding hypercube shells;
//                build rolls, breakdown tides and drops send their own
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";
import { quat, rotationMatrix } from "../engine/hypergeometryMath.js";

export const TESSERACT_UNFOLDING_PRESET_ID = 148;
export const TU_HALF = 12;                 // half-size of the machine's hypercube (shader TU_H)
export const TU_CHAMBER = TU_HALF / 3;     // the removed central sub-hypercube contains this ball
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth01 = (x) => { const t = clamp(x); return t * t * (3 - 2 * t); };
const smoother = (x) => { const t = clamp(x); return t * t * t * (t * (t * 6 - 15) + 10); };

// ---- 4D linear algebra (column-major 4x4, as GLSL) ---------------------------------------------
const col = (m, c) => [m[c * 4], m[c * 4 + 1], m[c * 4 + 2], m[c * 4 + 3]];
const dot4 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];

// Quaternion pair (qL, qR) of a rotation matrix (v -> qL v qR, see rotationMatrix). p = R(1) = qL qR;
// R(e) conj(p) = qL e conj(qL) for the pure units e, which is qL's 3D rotation.
export function quatPairFromMatrix(m) {
  const p = quat.norm(col(m, 3));                       // image of the real unit (w axis)
  const S = [0, 1, 2].map((c) => quat.mul(col(m, c), quat.conj(p)));   // columns of qL's rotation
  const r = (i, j) => S[j][i];
  const tr = r(0, 0) + r(1, 1) + r(2, 2);
  let q;
  if (tr > 0) {
    const s = Math.sqrt(tr + 1) * 2;
    q = [(r(2, 1) - r(1, 2)) / s, (r(0, 2) - r(2, 0)) / s, (r(1, 0) - r(0, 1)) / s, 0.25 * s];
  } else if (r(0, 0) > r(1, 1) && r(0, 0) > r(2, 2)) {
    const s = Math.sqrt(1 + r(0, 0) - r(1, 1) - r(2, 2)) * 2;
    q = [0.25 * s, (r(0, 1) + r(1, 0)) / s, (r(0, 2) + r(2, 0)) / s, (r(2, 1) - r(1, 2)) / s];
  } else if (r(1, 1) > r(2, 2)) {
    const s = Math.sqrt(1 + r(1, 1) - r(0, 0) - r(2, 2)) * 2;
    q = [(r(0, 1) + r(1, 0)) / s, 0.25 * s, (r(1, 2) + r(2, 1)) / s, (r(0, 2) - r(2, 0)) / s];
  } else {
    const s = Math.sqrt(1 + r(2, 2) - r(0, 0) - r(1, 1)) * 2;
    q = [(r(0, 2) + r(2, 0)) / s, (r(1, 2) + r(2, 1)) / s, 0.25 * s, (r(1, 0) - r(0, 1)) / s];
  }
  const qL = quat.norm(q);
  return { qL, qR: quat.norm(quat.mul(quat.conj(qL), p)) };
}

// The machine's rotational symmetries: signed permutation matrices with determinant +1 (192).
// Slicing R and P R gives the same picture, so targets are always taken in the nearest copy.
function permutations(a) {
  if (a.length <= 1) return [a];
  return a.flatMap((x, i) => permutations([...a.slice(0, i), ...a.slice(i + 1)]).map((p) => [x, ...p]));
}
function parity(p) { let s = 1; for (let i = 0; i < p.length; i++) for (let j = i + 1; j < p.length; j++) if (p[i] > p[j]) s = -s; return s; }
export const SYMMETRIES = (() => {
  const out = [];
  for (const perm of permutations([0, 1, 2, 3])) {
    for (let signs = 0; signs < 16; signs++) {
      const sg = [0, 1, 2, 3].map((i) => (signs >> i) & 1 ? -1 : 1);
      if (parity(perm) * sg[0] * sg[1] * sg[2] * sg[3] !== 1) continue;
      const m = new Float32Array(16);
      for (let c = 0; c < 4; c++) m[c * 4 + perm[c]] = sg[c];     // column c -> sg * e_perm[c]
      out.push(m);
    }
  }
  return out;
})();
function mul4(a, b) {
  const m = new Float32Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
    let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
    m[c * 4 + r] = s;
  }
  return m;
}
const traceAtB = (a, b) => { let s = 0; for (let i = 0; i < 16; i++) s += a[i] * b[i]; return s; };

// The copy P T of target T (P a symmetry) closest to the current rotation R.
export function nearestEquivalent(target, current) {
  let best = null, score = -Infinity;
  for (const P of SYMMETRIES) {
    const m = mul4(P, target), s = traceAtB(m, current);
    if (s > score) { score = s; best = m; }
  }
  return best;
}

// Rotation whose w column (the slice normal R e4) is n, completed by Gram-Schmidt from the other
// axes, then spun by `spin` in its own slice (the xy plane of the slice).
export function orientationWithNormal(n, spin = 0) {
  const l = Math.hypot(...n); n = n.map((x) => x / l);
  const basis = [];
  for (const e of [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]) {
    let v = e.slice();
    for (const b of [n, ...basis]) { const d = dot4(v, b); v = v.map((x, i) => x - d * b[i]); }
    const vl = Math.hypot(...v);
    if (vl > 1e-3 && basis.length < 3) basis.push(v.map((x) => x / vl));
  }
  const c = Math.cos(spin), s = Math.sin(spin);
  const b0 = basis[0].map((x, i) => c * x + s * basis[1][i]), b1 = basis[1].map((x, i) => -s * basis[0][i] + c * x);
  const m = new Float32Array(16);
  [b0, b1, basis[2], n].forEach((v, k) => m.set(v, k * 4));
  // keep it a rotation
  if (det4(m) < 0) for (let r = 0; r < 4; r++) m[r] = -m[r];
  return m;
}
export function det4(m) {
  const a = (r, c) => m[c * 4 + r];
  let det = 0;
  for (let c = 0; c < 4; c++) {
    const minor = [];
    for (let r = 1; r < 4; r++) for (let k = 0; k < 4; k++) if (k !== c) minor.push(a(r, k));
    const d3 = minor[0] * (minor[4] * minor[8] - minor[5] * minor[7]) - minor[1] * (minor[3] * minor[8] - minor[5] * minor[6]) + minor[2] * (minor[3] * minor[7] - minor[4] * minor[6]);
    det += (c % 2 ? -1 : 1) * a(0, c) * d3;
  }
  return det;
}

// Sacred orientations, by the 4D direction the slice faces: the axis gives the classical Menger
// sponge, the long diagonal octahedral / star-tetrahedral halls, the others prisms and hexagrams.
const PHI = (1 + Math.sqrt(5)) / 2;
export const REVELATIONS = Object.freeze([
  { name: "long diagonal", normal: [1, 1, 1, 1], spin: 0.0 },
  { name: "face diagonal", normal: [0, 1, 1, 1], spin: 0.4 },
  { name: "golden", normal: [1, PHI, PHI * PHI, 0.0], spin: 0.9 },
  { name: "edge diagonal", normal: [0, 0, 1, 1], spin: 0.25 },
  { name: "skew diagonal", normal: [1, 1, 1, 2.2], spin: 1.3 },
  { name: "golden diagonal", normal: [PHI, 1, PHI, 1], spin: 0.6 }
]);

// Rotation G in the plane of unit vectors u and v that turns u by fraction f of the angle to v.
function planeRotate(m, u, v, f) {
  const cosA = clamp(dot4(u, v), -1, 1), angle = Math.acos(cosA) * f;
  if (angle < 1e-7) return m;
  let b = v.map((x, i) => x - cosA * u[i]);
  const bl = Math.hypot(...b); if (bl < 1e-9) return m;
  b = b.map((x) => x / bl);
  const c = Math.cos(angle) - 1, s = Math.sin(angle);
  const out = new Float32Array(16);
  for (let k = 0; k < 4; k++) {
    const x = col(m, k), xa = dot4(x, u), xb = dot4(x, b);
    for (let r = 0; r < 4; r++) out[k * 4 + r] = x[r] + c * (xa * u[r] + xb * b[r]) + s * (xa * b[r] - xb * u[r]);
  }
  return out;
}

// ---- the journey ----------------------------------------------------------------------------------
// Keyframes in bars (one loop = 72 bars, about 2 minutes at 145 BPM). Spherical camera position
// (r, az, el) around the machine's centre, az = 0 on the +z flight axis; yaw turns the view away
// from the centre about the world up axis (0 = facing the centre: the camera backs out of the
// chamber through the far aperture still facing the core, so the machine is always in view); corridor: weight of the flight-axis constraint (1 whenever the camera
// is inside the machine's bounding radius away from the chamber).
export const JOURNEY_BARS = 72;
export const SEGMENTS = Object.freeze([
  { name: "encounter", from: 0, to: 16 }, { name: "approach", from: 16, to: 24 },
  { name: "passage", from: 24, to: 32 }, { name: "chamber", from: 32, to: 56 },
  { name: "emergence", from: 56, to: 62 }, { name: "return", from: 62, to: 72 }
]);
const PI = Math.PI;
//            bar    r     az              el     yaw   fov   roll   corridor
const KEYS = [
  [0, 56.0, PI + 1.15, 0.27, 0.0, 0.78, 0.0, 0],
  [8, 47.0, PI + 1.8, 0.2, 0.0, 0.78, 0.0, 0],
  [16, 38.0, PI + 2.55, 0.11, 0.0, 0.80, 0.0, 0],
  [21, 28.5, TAU, 0.0, 0.0, 0.84, 0.0, 1],
  [24, 25.0, TAU, 0.0, 0.0, 0.88, 0.0, 1],
  [28, 12.5, TAU, 0.0, 0.0, 1.00, 0.18, 1],
  [32, 3.3, TAU, 0.0, 0.0, 1.10, 0.26, 1],
  [36, 3.05, TAU + 0.55, 0.32, 0.45, 1.16, 0.10, 0],
  [42, 2.95, TAU + 1.40, -0.22, 0.85, 1.18, -0.14, 0],
  [48, 3.05, TAU + 2.25, 0.40, -0.25, 1.16, 0.0, 0],
  [53, 3.2, TAU + 2.95, 0.06, 0.0, 1.12, 0.06, 1],
  [56, 3.4, TAU + PI, 0.0, 0.0, 1.08, 0.0, 1],
  [59, 12.0, TAU + PI, 0.0, 0.0, 1.02, -0.16, 1],
  [62, 27.0, TAU + PI, 0.0, 0.0, 0.92, -0.10, 1],
  [66.5, 40.0, TAU + PI + 0.55, 0.16, 0.0, 0.82, 0.0, 0],
  [72, 56.0, TAU + PI + 1.15, 0.27, 0.0, 0.78, 0.0, 0]
];
// az grows by TAU per loop; everything else repeats.

// Monotone cubic Hermite (Fritsch-Carlson) per channel: flat stretches stay exactly flat, so the
// camera never leaves the flight axis between two on-axis keys.
const CHANNELS = KEYS[0].length - 1;
const TANGENTS = (() => {
  const n = KEYS.length, out = [];
  for (let c = 1; c <= CHANNELS; c++) {
    const x = KEYS.map((k) => k[0]), y = KEYS.map((k) => k[c]);
    const d = [], m = [];
    for (let i = 0; i < n - 1; i++) d.push((y[i + 1] - y[i]) / (x[i + 1] - x[i]));
    // periodic: the slope before key 0 is the last interval's
    const dPrev = (i) => (i === 0 ? d[n - 2] : d[i - 1]), dNext = (i) => (i === n - 1 ? d[0] : d[i]);
    for (let i = 0; i < n; i++) {
      const a = dPrev(i), b = dNext(i);
      m.push(a * b <= 0 ? 0 : (2 * a * b) / (a + b));   // harmonic mean: monotone
    }
    out.push(m);
  }
  return out;
})();

export function journeyAt(bar) {
  const loops = Math.floor(bar / JOURNEY_BARS);
  const x = bar - loops * JOURNEY_BARS;
  let i = 0;
  while (i < KEYS.length - 2 && x >= KEYS[i + 1][0]) i++;
  const k0 = KEYS[i], k1 = KEYS[i + 1], h = k1[0] - k0[0], t = (x - k0[0]) / h;
  const h00 = 2 * t * t * t - 3 * t * t + 1, h10 = t * t * t - 2 * t * t + t, h01 = -2 * t * t * t + 3 * t * t, h11 = t * t * t - t * t;
  const v = [];
  for (let c = 1; c <= CHANNELS; c++) v.push(h00 * k0[c] + h10 * h * TANGENTS[c - 1][i] + h01 * k1[c] + h11 * h * TANGENTS[c - 1][i + 1]);
  const [r, az0, el, yaw, fov, roll, corridor] = v;
  const az = az0 + loops * TAU;
  const pos = [r * Math.cos(el) * Math.sin(az), r * Math.sin(el), r * Math.cos(el) * Math.cos(az)];
  let segment = SEGMENTS[0].name;
  for (const s of SEGMENTS) if (x >= s.from && x < s.to) segment = s.name;
  return { pos, r, az, el, yaw, fov, roll, corridor: clamp(corridor), segment, bar: x };
}

const normalize3 = (v) => { const l = Math.hypot(...v) || 1; return v.map((x) => x / l); };
const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];

// Camera basis for a bar position: the direction to the centre, turned by yaw about world up.
export function cameraAt(bar) {
  const j = journeyAt(bar);
  const toCentre = normalize3(j.pos.map((x) => -x));
  const cy = Math.cos(j.yaw), sy = Math.sin(j.yaw);
  const fwd = normalize3([cy * toCentre[0] + sy * toCentre[2], toCentre[1], -sy * toCentre[0] + cy * toCentre[2]]);
  // up reference that never degenerates (pitch stays well inside +-0.5 rad)
  let right = normalize3(cross3(fwd, [0, 1, 0]));
  let up = cross3(right, fwd);
  const c = Math.cos(j.roll), s = Math.sin(j.roll);
  const r2 = right.map((x, i) => c * x + s * up[i]), u2 = up.map((x, i) => -s * right[i] + c * x);
  return { ...j, fwd, right: r2, up: u2 };
}

// ---- the director ---------------------------------------------------------------------------------
const PULSE_SLOTS = 4;

export function createTesseractUnfoldingDirector() {
  const audioModel = createNewtonAudioModel();
  const s = {};
  const pulses = [];
  const uniforms = {};

  function makeRotor(speed, seed) {
    return { qL: quat.identity(), qR: quat.identity(), speed, seed, phase: seed * 7.3 };
  }

  function reset() {
    audioModel.reset();
    pulses.length = 0;
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0,
      bar: 0, speed: 1, speedGoal: 1, holdSince: null, plunge: 0,
      energy: 0.3, mids: 0.2, highs: 0.2, bass: 0.2, groove: 0, breakdown: 0, build: 0, tension: 0,
      calm: 0, drive: 0, insideness: 0,
      // the machine's rotation
      qL: quat.identity(), qR: quat.identity(), driftPhase: 0, driftSpeed: 0.02, driftRamp: 1,
      tr: null,                        // eased rotation transition {fromL, fromR, toL, toR, start, dur}
      revelation: 0, lastHomeLoop: -1, lastBreakTransition: -1e9,
      corridorAxis: null,              // 4D axis vector the flight axis is bent onto
      w0: 0, wPhase: 0, kickX: 0, kickV: 0,
      holes: [0.345, 0.34, 0.34, 0], burst: 0, intricacy: 0,
      gyros: [makeRotor(0.11, 0.17), makeRotor(-0.16, 0.53), makeRotor(0.24, 0.91)],
      gyroScale: [0.84, 0.56, 0.34], unfold: 0, gyroW: [0, 0, 0], gyroPhase: [0, TAU / 3, (2 * TAU) / 3],
      core: makeRotor(0.33, 0.31), outer: makeRotor(0.035, 0.77), outerPhase: 0, coreShape: 0, coreShapeFrom: 0, coreShapeTo: 0, coreShapeAt: -1e9,
      flare: 0, flash: 0, charge: 0, shimmer: 0, hueShift: 0,
      drops: 0, kicks: 0, holds: 0, plunges: 0, revelations: 0, homes: 0, lastDropAt: -1e9,
      breakAt: null
    });
    // a calm, slightly turned entry: the Menger hall already leaning into the fourth dimension
    const start = quatPairFromMatrix(orientationWithNormal([0.0, 0.18, 0.1, 1], 0.2));
    s.qL = start.qL; s.qR = start.qR;
  }
  reset();

  function spawnPulse(kind, strength) {
    const speed = { kick: 24, roll: 18, tide: 7, drop: 30, hat: 40 }[kind] || 20;
    const life = { kick: 0.95, roll: 0.7, tide: 4.5, drop: 2.2, hat: 0.5 }[kind] || 1;
    if (pulses.length >= PULSE_SLOTS) {
      let oldest = 0;
      for (let i = 1; i < pulses.length; i++) if (pulses[i].age / pulses[i].life > pulses[oldest].age / pulses[oldest].life) oldest = i;
      pulses.splice(oldest, 1);
    }
    pulses.push({ kind, strength, speed, life, age: 0 });
  }

  function currentMatrix() { return rotationMatrix(s.qL, s.qR); }

  function startTransition(targetMatrix, seconds) {
    const near = nearestEquivalent(targetMatrix, currentMatrix());
    const to = quatPairFromMatrix(near);
    // the pair (qL, qR) and (-qL, -qR) is the same rotation: pick the closer sign for both
    const d = quat.mul(quat.conj(s.qL), to.qL)[3];
    const sign = d < 0 ? -1 : 1;
    s.tr = { fromL: s.qL.slice(), fromR: s.qR.slice(), toL: to.qL.map((x) => x * sign), toR: to.qR.map((x) => x * sign), start: s.time, dur: seconds };
  }

  function stepRotor(r, dt, speedScale) {
    r.phase += dt * 0.031;
    const aL = [Math.sin(r.phase + r.seed * 3), Math.cos(r.phase * 0.71 + r.seed), Math.sin(r.phase * 0.53 + 2)];
    const aR = [Math.cos(r.phase * 0.83 + 1), Math.sin(r.phase * 0.61 + r.seed * 5), Math.cos(r.phase * 0.47)];
    const ang = r.speed * speedScale * dt;
    r.qL = quat.norm(quat.mul(quat.exp(normalize3(aL), ang * 0.5), r.qL));
    r.qR = quat.norm(quat.mul(r.qR, quat.exp(normalize3(aR), ang * 0.37)));
  }

  // time: seconds (monotonic per preset activation). input: { audio, smooth, music, lookahead, tempo }.
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = clamp(time - s.lastTime, 0, 0.1);
    s.lastTime = time;
    s.time += dt;
    const { audio = {}, smooth = {}, music = {}, lookahead = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    const a = audioModel.state;

    // ---- musical envelopes ----------------------------------------------------------------------
    s.energy = follow(s.energy, Math.max(a.energyDrive * 0.9, clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.8), dt, 0.4, 1.4);
    s.mids = follow(s.mids, a.midDrive, dt, 0.15, 0.6);
    s.highs = follow(s.highs, a.highDrive, dt, 0.04, 0.25);
    s.bass = follow(s.bass, Math.max(a.subDrive, clamp(((audio.bassRel ?? 1) - 0.8) * 1.6)), dt, 0.1, 0.7);
    s.groove = a.groove; s.breakdown = a.breakdown; s.build = a.build;
    // a build-up is not calm, even when its kick has stopped
    s.calm = follow(s.calm, clamp((a.breakdown - 0.35) / 0.45) * (1 - a.groove * 0.7) * (1 - clamp(Math.max(a.build, clamp(music.buildUp)) * 1.6)), dt, 1.2, 1.6);
    s.drive = follow(s.drive, clamp(a.groove * (0.5 + 0.5 * s.energy)), dt, 0.6, 1.4);

    // Anticipation: lookahead agrees a drop is close, or the analysis calls a full build.
    const current = lookahead.current || {}, med = lookahead.medium || {};
    const rise = clamp(((med.maxEnergy || med.energy || 0) - (current.energy || 0) - 0.08) * 3.2);
    const forecast = clamp(Math.max(clamp(music.upcomingDrop) * 1.2, rise * 0.8, a.build));
    s.tension = follow(s.tension, forecast * (1 - s.calm * 0.5), dt, 0.6, 1.2);

    // ---- events -----------------------------------------------------------------------------------
    for (const w of events.waves) {
      if (w.kind === "kick") { spawnPulse("kick", w.strength * (w.beatInBar === 0 ? 1 : 0.7)); s.kicks += 1; s.kickV += 1.6 * w.strength; }
      else if (w.kind === "roll") spawnPulse("roll", w.strength);
      else if (w.kind === "tide") spawnPulse("tide", w.strength);
    }
    if (events.hats) s.shimmer = Math.max(s.shimmer, 0.55 + 0.45 * s.highs);
    // the kick returning in the middle of a build (a tease) is a rebound, not the drop
    const rebound = events.drop && clamp(music.buildUp) > 0.5 && clamp(music.drop) < 0.6;
    if (rebound) { spawnPulse("drop", 0.8); s.flash = Math.max(s.flash, 0.4); s.rebounds = (s.rebounds || 0) + 1; }
    if (events.drop && !rebound && s.time - s.lastDropAt > 6) {
      s.lastDropAt = s.time; s.drops += 1;
      pulses.length = 0;
      spawnPulse("drop", 1.5);
      s.flash = 1; s.flare = 1; s.burst = 1;
      // the revelation: the machine turns to its next sacred orientation in 6 beats
      const rev = REVELATIONS[s.revelation % REVELATIONS.length];
      s.revelation += 1; s.revelations += 1;
      startTransition(orientationWithNormal(rev.normal, rev.spin), 6 / bps);
      // the core becomes the next regular polytope
      s.coreShapeFrom = s.coreShape; s.coreShapeTo = (Math.round(s.coreShapeTo) + 1) % 3; s.coreShapeAt = s.time;
      // at the threshold, the camera plunges in on the drop
      const j = journeyAt(s.bar);
      if (j.bar >= 17 && j.bar < 26) { s.plunge = 1; s.plunges += 1; }
      s.holdSince = null;
    }
    // A long breakdown slowly turns the machine to another orientation (32 beats).
    if (s.calm > 0.6 && s.time - s.lastBreakTransition > 40 && !s.tr && s.time - s.lastDropAt > 12) {
      s.lastBreakTransition = s.time;
      const rev = REVELATIONS[(s.revelation + 2) % REVELATIONS.length];
      s.revelation += 1;
      startTransition(orientationWithNormal(rev.normal, rev.spin + 0.7), 32 / bps);
    }

    // ---- journey ------------------------------------------------------------------------------------
    let goal = 1.0 - 0.22 * s.calm + 0.1 * s.drive;
    const jNow = journeyAt(s.bar);
    // wait at the threshold for a forecast drop (at most 14 s)
    if (jNow.bar >= 21.5 && jNow.bar < 24 && s.tension > 0.5 && s.plunge < 0.05) {
      if (s.holdSince === null) { s.holdSince = s.time; s.holds += 1; }
      if (s.time - s.holdSince < 14) goal = 0.1;
    } else if (jNow.bar < 21.5 || jNow.bar >= 24) s.holdSince = null;
    if (s.plunge > 0) {
      goal = Math.max(goal, 1.9);
      if (jNow.bar >= 30 || jNow.bar < 17) s.plunge = 0;
    }
    s.speed = follow(s.speed, goal, dt, goal > s.speed ? 0.9 : 1.2, 1.2);
    s.bar += dt * bps / 4 * s.speed;
    const cam = cameraAt(s.bar);
    s.insideness = follow(s.insideness, clamp((TU_HALF * 1.2 - cam.r) / 6), dt, 0.5, 0.5);

    // Once per loop, during the return, the machine settles back into the plain Menger slice.
    const loop = Math.floor(s.bar / JOURNEY_BARS);
    if (cam.bar >= 62.5 && s.lastHomeLoop !== loop && !s.tr) {
      s.lastHomeLoop = loop; s.homes += 1;
      startTransition(orientationWithNormal([0.05, 0.12, 0.08, 1], 0.15 * (loop % 3)), 9.5 * 4 / bps);
    }

    // ---- orientation ------------------------------------------------------------------------------
    const driftGoal = 0.016 + 0.03 * s.mids + 0.05 * s.tension * (1 - s.calm) + 0.018 * s.calm + 0.02 * s.drive;
    s.driftSpeed = follow(s.driftSpeed, driftGoal, dt, 1.5, 2.5);
    if (s.tr) {
      const u = (s.time - s.tr.start) / s.tr.dur;
      const e = smoother(u);
      s.qL = quat.slerp(s.tr.fromL, s.tr.toL, e);
      s.qR = quat.slerp(s.tr.fromR, s.tr.toR, e);
      if (u >= 1) s.tr = null;
    }
    {
      s.driftPhase += dt * 0.021;
      const p = s.driftPhase;
      const aL = normalize3([Math.sin(p), Math.cos(p * 0.73 + 1.1), Math.sin(p * 0.41 + 2.3)]);
      const aR = normalize3([Math.cos(p * 0.89 + 0.4), Math.sin(p * 0.57 + 3.1), Math.cos(p * 0.37 + 1.7)]);
      s.driftRamp = s.tr ? 0 : follow(s.driftRamp, 1, dt, 1.5, 1.5);   // drift resumes gently
      const ang = s.driftSpeed * dt * s.driftRamp;
      s.qL = quat.norm(quat.mul(quat.exp(aL, ang * 0.5), s.qL));
      s.qR = quat.norm(quat.mul(s.qR, quat.exp(aR, ang * 0.5)));
    }
    let M = currentMatrix();
    // corridor: bend the rotation so the flight axis (3D z) lies on the nearest 4D axis
    if (cam.corridor > 1e-4) {
      const u = col(M, 2);
      if (!s.corridorAxis) {
        let k = 0; for (let i = 1; i < 4; i++) if (Math.abs(u[i]) > Math.abs(u[k])) k = i;
        s.corridorAxis = [0, 0, 0, 0]; s.corridorAxis[k] = Math.sign(u[k]) || 1;
      }
      M = planeRotate(M, u, s.corridorAxis, smoother(cam.corridor));
    } else s.corridorAxis = null;

    // ---- slice offset, apertures ------------------------------------------------------------------
    s.kickV += (-s.kickX * 60 - s.kickV * 9) * dt;          // damped kick oscillator (about 1.2 Hz)
    s.kickX += s.kickV * dt;
    s.wPhase += dt * (0.05 + 0.05 * s.mids);
    s.w0 = 0.32 * Math.sin(s.wPhase) + 0.12 * (s.bass - 0.4) + 0.045 * s.kickX;
    s.burst *= Math.exp(-dt / (16 / bps));                      // a drop's burst relaxes over 4 bars
    const open = 0.08 * s.calm - 0.018 * s.tension * (1 - s.calm);
    // intricacy: the fourth level of apertures grows through the journey inwards (transcendence in
    // the chamber) and with a build's tension; it is gone again outside
    const journeyIntricacy = { encounter: 0, approach: 0.15, passage: 0.45, chamber: 0.55 + 0.45 * smooth01((cam.bar - 34) / 14), emergence: 0.6, return: 0 }[cam.segment] ?? 0;
    s.intricacy = follow(s.intricacy, clamp(journeyIntricacy * (1 - 0.35 * s.calm) + 0.45 * s.tension * (1 - s.calm) + 0.3 * s.burst), dt, 2.5, 3.5);
    s.holes = [
      0.345 + open + 0.13 * s.burst,
      0.34 + 0.045 * s.mids + 0.6 * open + 0.06 * s.burst,
      0.34 + 0.03 * s.highs + 0.03 * s.burst,
      0.36 * smooth01(s.intricacy * 1.25)
    ];

    // ---- gyros and core -------------------------------------------------------------------------------
    s.unfold = follow(s.unfold, clamp(0.25 + 0.55 * s.mids + 0.35 * s.calm + 0.4 * s.burst), dt, 0.6, 1.6);
    const spin = 0.6 + 0.6 * s.mids + 0.9 * s.tension * (1 - s.calm) + 0.7 * s.burst - 0.25 * s.calm;
    s.gyros.forEach((g) => stepRotor(g, dt, spin));
    stepRotor(s.core, dt, 1 + 1.5 * s.flare);
    stepRotor(s.outer, dt, 0.7 + 0.6 * s.drive + 0.8 * s.burst);
    s.outerPhase += dt * 0.017;
    const base = [0.84, 0.56, 0.34], spread = [0.12, 0.2, 0.28];
    s.gyroScale = base.map((b, i) => b * (1 + s.unfold * spread[i] * 0.6 - spread[i] * 0.25) * (1 + 0.012 * s.kickX));
    s.gyroPhase = s.gyroPhase.map((p, i) => p + dt * (0.11 + 0.05 * i + 0.08 * s.mids));
    s.gyroW = s.gyroScale.map((sc, i) => sc * 1.15 * Math.sin(s.gyroPhase[i]));
    const shapeU = smoother((s.time - s.coreShapeAt) / (4 / bps));
    s.coreShape = s.coreShapeFrom + (s.coreShapeTo - s.coreShapeFrom) * shapeU;

    // ---- light ------------------------------------------------------------------------------------------
    s.flare *= Math.exp(-dt / 1.4);
    s.flash *= Math.exp(-dt / 0.9);
    s.shimmer *= Math.exp(-dt / 0.12);
    s.charge = follow(s.charge, clamp(s.tension * (1 - s.calm)), dt, 1.2, 0.8);
    s.hueShift += dt * (0.004 + 0.01 * s.drive);
    for (const p of pulses) p.age += dt;
    for (let i = pulses.length - 1; i >= 0; i--) if (pulses[i].age > pulses[i].life) pulses.splice(i, 1);

    // ---- uniforms -------------------------------------------------------------------------------------
    uniforms.tuR = M;
    uniforms.tuG0 = rotationMatrix(s.gyros[0].qL, s.gyros[0].qR);
    uniforms.tuG1 = rotationMatrix(s.gyros[1].qL, s.gyros[1].qR);
    uniforms.tuG2 = rotationMatrix(s.gyros[2].qL, s.gyros[2].qR);
    uniforms.tuC = rotationMatrix(s.core.qL, s.core.qR);
    uniforms.tuO = rotationMatrix(s.outer.qL, s.outer.qR);
    // half-size beyond the camera's widest orbit (56), so the cage never crosses the camera
    uniforms.tuOuter = [66, 26 * Math.sin(s.outerPhase), 0.55, 1];
    const tanHalf = Math.tan(cam.fov * 0.5);
    uniforms.tuCamPos = [...cam.pos, tanHalf];
    uniforms.tuCamBasis = [...cam.right, ...cam.up, ...cam.fwd];
    uniforms.tuHoles = s.holes;
    uniforms.tuSlice = [s.w0, s.time, s.hueShift % 1, s.insideness];
    uniforms.tuGyroA = [...s.gyroScale, s.unfold];
    uniforms.tuGyroW = [...s.gyroW, 0];
    const k = ((s.coreShape % 3) + 3) % 3, i0 = Math.floor(k), f = smooth01(k - i0);
    const shape = [0, 0, 0]; shape[i0] += 1 - f; shape[(i0 + 1) % 3] += f;
    uniforms.tuCoreShape = [...shape, 0.17 * (1 + 0.25 * s.flare)];
    uniforms.tuLight = [1 + 1.2 * s.flare + 0.25 * s.drive, s.charge, clamp(s.shimmer + 0.35 * s.highs), s.flash];
    uniforms.tuMood = [s.calm, s.drive, s.tension, s.energy];
    const ages = [99, 99, 99, 99], amps = [0, 0, 0, 0], speeds = [1, 1, 1, 1];
    pulses.forEach((p, i) => {
      ages[i] = p.age; speeds[i] = p.speed;
      amps[i] = p.strength * Math.exp(-p.age / (p.life * 0.45)) * (p.kind === "tide" ? 0.6 : 1);
    });
    uniforms.tuPulseAge = ages; uniforms.tuPulseAmp = amps; uniforms.tuPulseSpeed = speeds;
    s.camera = cam;
    return s;
  }

  return { state: s, step, uniforms: () => uniforms, pulses };
}

const cache = new WeakMap();

export function bindTesseractUnfoldingDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime) { runtime = { director: createTesseractUnfoldingDirector(), lastTime: -1 }; cache.set(gl, runtime); }
  const director = opts.director || runtime.director;
  // a frame drawn twice at the same time (transition, re-render) reuses the state
  if (time !== runtime.lastTime || opts.director) { director.step(time, input); runtime.lastTime = time; }
  const loc = (name) => uniformLocation(gl, program, name);
  gl.uniform1f(loc("tuDir"), 1);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (!l) continue;
    if (value.length === 16) gl.uniformMatrix4fv(l, false, value);
    else if (value.length === 9) gl.uniformMatrix3fv(l, false, value);
    else gl.uniform4f(l, value[0], value[1], value[2], value[3]);
  }
  return director;
}
