// A small, preset-local magnetic system. No GPU feedback or global audio mutation.
export const FERROFLUID_ORACLE_ID = 224;
export const FO_POLE_COUNT = 9;
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, Number(x) || 0));
const mix = (a, b, t) => a + (b - a) * t;
const smoothstep = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const approach = (a, b, dt, seconds) => mix(a, b, -Math.expm1(-dt / seconds));

export function createFerrofluidField() {
  return { lastTime: null, lastTrack: null, phase: 0, orbit: 0, force: 0, activity: 0,
    mids: 0, fine: 0, tension: 0, memory: 0, connection: 0, forest: 0,
    hero: 0, heroKind: 0, eventCount: 0, lastEvent: -100, lastKick: -100,
    previousKick: 0, previousDrop: 0, waves: [], roots: new Float32Array(36),
    pulls: new Float32Array(36), bridgeA: new Float32Array(16), bridgeB: new Float32Array(16),
    waveData: new Float32Array(8), camera: new Float32Array(4), controls: new Float32Array(4) };
}

// Softened scalar source potential and its analytic horizontal gradient.
// Evaluated at the nine material sites ONCE per frame, never per ray step.
export function sampleFerrofluidPotential(x, z, sources) {
  let potential = 0, dx = 0, dz = 0;
  for (const s of sources) {
    const qx = x - s.x, qz = z - s.z, r2 = .85 + qx * qx + qz * qz;
    potential += s.strength / Math.sqrt(r2);
    const g = -s.strength / Math.pow(r2, 1.5);
    dx += g * qx; dz += g * qz;
  }
  return { potential, dx, dz };
}

export function updateFerrofluidField(s, time, input = {}) {
  const a = input.audio || {}, m = input.music || {}, bands = input.smooth || {};
  const track = Number(input.trackTime);
  let dt = s.lastTime === null ? 0 : time - s.lastTime;
  const discontinuity = s.lastTime !== null && (dt < 0 || dt > .75 ||
    (Number.isFinite(track) && s.lastTrack !== null && Math.abs(track - s.lastTrack - dt) > .65));
  if (discontinuity) Object.assign(s, createFerrofluidField());
  // Same-time warm/preflight/transition draws must not advance the simulation.
  const fresh = s.lastTime === null;
  dt = fresh ? 0 : clamp(time - s.lastTime, 0, .1);
  const energy = clamp(.58 * clamp(a.globalEnergy ?? bands.level) + .42 * clamp(input.slowLevel ?? bands.level));
  const bass = clamp(input.slowBass ?? bands.bass);
  const mid = clamp(bands.mids), fine = clamp(bands.highs);
  const quiet = 1 - .55 * clamp(m.breakdown);
  const force = clamp((.15 + .85 * bass) * smoothstep(.015, .4, energy) * quiet);
  const activity = clamp(energy * quiet);
  const future = input.lookahead?.ready ? clamp(input.lookahead.short?.energy) : energy;
  const anticipation = Math.max(0, future - energy) * clamp(m.buildUp + .3);
  const tension = clamp(.8 * clamp(m.buildUp) + anticipation * .7);
  if (fresh) {
    s.force = force; s.activity = activity; s.mids = mid; s.fine = fine; s.tension = tension;
    s.phase = 0; s.orbit = .35;
  }
  s.force = approach(s.force, force, dt, .8);
  s.activity = approach(s.activity, activity, dt, 1.25);
  s.mids = approach(s.mids, mid, dt, 1.3);
  s.fine = approach(s.fine, fine, dt, .18);
  s.tension = approach(s.tension, tension, dt, .85);
  s.memory = approach(s.memory, s.activity * s.force, dt, 6);
  // Integrated musical work, not a free-running formation timer. Silence stops it.
  s.phase += dt * s.activity * (.10 + .38 * s.mids + .18 * s.memory);
  s.orbit += dt * (.027 + .025 * s.activity);
  const kick = clamp(a.kickPulse ?? bands.kick);
  const drop = clamp(Math.max(a.dropDetected || 0, m.drop || 0));
  if (dt > 0 && drop > .48 && s.previousDrop <= .48 && time - s.lastEvent > 10 && s.activity > .3) {
    s.heroKind = s.eventCount++ % 3; s.lastEvent = time;
    s.waves.unshift({ x: 0, z: 0, birth: time, strength: .85 });
  }
  if (dt > 0 && kick > .22 && kick > s.previousKick + .07 && time - s.lastKick > .18) {
    const angle = s.phase * .7 + s.eventCount * 2.4;
    s.waves.unshift({ x: Math.cos(angle) * 1.7, z: Math.sin(angle) * 1.7, birth: time, strength: kick * (.3 + .7 * s.force) });
    s.lastKick = time;
  }
  const eventAge = time - s.lastEvent;
  s.hero = approach(s.hero, smoothstep(0,.45,eventAge) * Math.exp(-eventAge/3.1), dt, .16);
  s.previousKick = kick; s.previousDrop = drop;
  s.waves = s.waves.filter(w => time - w.birth < 3).slice(0, 8);
  s.waveData.fill(0);
  s.waves.slice(0,2).forEach((w, i) => s.waveData.set([w.x, w.z, time - w.birth, w.strength * (1-smoothstep(.40,.72,time-w.birth))], i * 4));
  const braid = smoothstep(.12, .85, Math.sin(s.phase * .63 - .65)) * smoothstep(.2, .65, s.activity);
  const forest = smoothstep(.25, .95, Math.sin(s.phase * .43 + 2.5)) * (1 - s.tension);
  const reversal = s.heroKind === 2 ? s.hero : 0;
  const convergence = clamp(s.tension * .8 + braid * .64 + (s.heroKind === 1 ? s.hero * .6 : 0));
  s.connection = approach(s.connection, convergence, dt, 1.05);
  s.forest = approach(s.forest, forest, dt, 1.8);
  const radius = mix(2.0, .8, s.connection) + .5 * (s.heroKind === 0 ? s.hero : 0);
  const orientation = s.phase * .27 + s.mids * .5;
  const sources = Array.from({length: 3}, (_, i) => {
    const angle = i * TAU / 3 + orientation;
    return { x: Math.cos(angle) * radius * .7, z: Math.sin(angle) * radius * .7,
      strength: (.3 + 1.8 * s.force) * (1 + .22 * Math.sin(s.phase + i * 2.1)) };
  });
  let tallest = 0;
  for (let i = 0; i < FO_POLE_COUNT; i++) {
    const angle = (i - 1) * TAU / 8 + orientation;
    const ringX = i ? Math.cos(angle) * radius : 0, ringZ = i ? Math.sin(angle) * radius : 0;
    const gx = (i % 3 - 1) * 1.6, gz = (Math.floor(i / 3) - 1) * 1.6;
    const x = mix(ringX, gx, s.forest * .85), z = mix(ringZ, gz, s.forest * .85);
    const field = sampleFerrofluidPotential(x, z, sources);
    let disturbance = 0;
    for (const w of s.waves) {
      const r = Math.hypot(x - w.x, z - w.z), age = time - w.birth;
      const front = r - age * 3.8;
      disturbance += w.strength * Math.exp(-front * front * 3 - age * .85) * Math.sin(front * 4);
    }
    const local = clamp((field.potential - .3) / 3.5);
    const instability = .68 + .32 * Math.sin(s.phase * 1.9 + angle * 2 + local * 3);
    const support = (1 - reversal * .8) * smoothstep(.01, .20, s.activity);
    const height = (.18 + (1.0 + 2.25 * s.force) * local * instability + s.connection * .95
      + (i === 0 ? s.connection * 1.35 : 0) + disturbance * .35) * support;
    const h = Math.max(.035, height);
    // Gradient attraction plus a transverse field creates curved, cohesive columns.
    const tangent = s.connection * h * .20;
    const leanX = clamp(field.dx * .25 * h, -.60, .60) - x * s.connection * .30 * support - Math.sin(angle) * tangent;
    const leanZ = clamp(field.dz * .25 * h, -.60, .60) - z * s.connection * .30 * support + Math.cos(angle) * tangent;
    const r = (.24 + .19 * local + .14 * s.connection) * Math.sqrt(support + .015);
    s.roots.set([x, z, h, r], i * 4);
    s.pulls.set([leanX, leanZ, .09 * s.mids * Math.sin(angle + s.phase), .011], i * 4);
    tallest = Math.max(tallest, h);
  }
  // Four necks grow from connected column sides; no detached bridge endpoints.
  for (let i = 0; i < 4; i++) {
    const ia = (i * 2 + 1) * 4, ib = (i * 2 + 2) * 4, t = .45;
    const endpoint = j => [s.roots[j] + s.pulls[j] * t*t - s.pulls[j+1]*4*t*t*(1-t)*(1-t)*s.pulls[j+2], s.roots[j+2] * t,
      s.roots[j+1] + s.pulls[j+1] * t*t + s.pulls[j]*4*t*t*(1-t)*(1-t)*s.pulls[j+2]];
    const pa = endpoint(ia), pb = endpoint(ib);
    // Growing upward out of the pool makes births/deaths connected, even at zero neck radius.
    const neck = smoothstep(.18, .78, s.connection) * (1 - reversal * .9);
    pa[1] = pa[1]*neck - .28*(1-neck); pb[1] = pb[1]*neck - .28*(1-neck);
    s.bridgeA.set([...pa, .13 * neck + .012], i * 4);
    s.bridgeB.set([...pb, .20 * neck], i * 4);
  }
  s.controls.set([s.activity, s.fine, s.connection, s.force]);
  // Continuous framing, always outside the maximum sculpture envelope.
  const overhead = s.forest * .75 + .25 * (1 - s.activity);
  const cameraTarget = [s.orbit, 6.7 + tallest * .48 - s.tension * .30, 1.65 + overhead * 3.0 + tallest * .30,
    .35 + tallest * .43];
  cameraTarget.forEach((v,i) => { s.camera[i] = fresh ? v : approach(s.camera[i],v,dt,1.4); });
  s.lastTime = time; s.lastTrack = Number.isFinite(track) ? track : null;
  return s;
}

export function bindFerrofluidField(gl, program, s, location) {
  const loc = name => location(gl, program, name);
  gl.uniform1f(loc('fo_ready'), 1);
  gl.uniform4fv(loc('fo_roots[0]'), s.roots);
  gl.uniform4fv(loc('fo_pulls[0]'), s.pulls);
  gl.uniform4fv(loc('fo_bridgeA[0]'), s.bridgeA);
  gl.uniform4fv(loc('fo_bridgeB[0]'), s.bridgeB);
  gl.uniform4fv(loc('fo_waves[0]'), s.waveData);
  gl.uniform4fv(loc('fo_controls'), s.controls);
  gl.uniform4fv(loc('fo_camera'), s.camera);
  gl.uniform1f(loc('fo_phase'), s.phase);
}
