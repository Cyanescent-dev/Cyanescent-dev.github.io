export { createSwirlieDomainRepeaterPresetShaderEntries as createPresetShaderEntries } from "../../swirlieDomainRepeaterPresetShaderSources.js";
