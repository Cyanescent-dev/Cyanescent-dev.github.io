export function createSriYantraHyperspacePresetShaderEntries({
    modularShaderPrelude,
    modularTransitionShaderBlock
  }) {
    const source = `${modularShaderPrelude}
  ${modularTransitionShaderBlock}

  // ID 174: Sri Yantra Hyperspace
  // An infinite tunnel of interlocking fractal pyramids.
  //
  // The yantra is not sitting in front of a space backdrop. The same fourfold
  // fold that builds the 3D fractal is evaluated again in two dimensions, and
  // the gradient of THAT field is what bends the surrounding space, opens a
  // throat at each lobe and drags the starfield into it. The geometry is the
  // source of the hyperspace, not a shape drawn on top of it.

  // Easy tuning constants exposed at the top of the preset block
  const float syLensDepth    = 0.055;  // How hard the arms bend passing sight-lines
  const float syThroatPull   = 0.58;   // How far each lobe draws the horizon inward
  const float syEchoDepth    = 0.085;  // Brightness of the receding ghost yantras
  const float syVoidLift     = 1.00;   // Overall brightness of the deep-space field
  const float syStreakLength = 0.30;   // How far particles smear along the throat

  // Resolved once per fragment in main() and read by map(), which runs roughly
  // 96 times per pixel. Anything trigonometric left inside map() is paid for
  // 96 times over.
  float syAnim;      // fold animation clock
  float syBreath;    // slow bass-driven swell of the central structure

  float sdOctahedron( vec3 p, float s) {
      p = abs(p);
      return (p.x+p.y+p.z-s)*0.57735027;
  }

  float map(vec3 p, float t_dist) {
      // Tunnel domain repetition along Z
      vec3 q = p;
      float zId = floor((q.z + 2.0) / 4.0);
      q.z = mod(q.z + 2.0, 4.0) - 2.0;

      float t_anim = syAnim;

      float d = 1000.0;
      float scale = 1.0;

      // Fractal iteration (Sierpinski / Octahedral hybrid) -- unchanged, this is
      // the hero. syBreath only swells the fold offset, so the structure
      // inhales rather than being replaced.
      for(int i = 0; i < 4; i++) {
          // Twist the space slightly
          q.xy *= rot(t_anim * 0.2 + zId * 0.1);

          q = abs(q) - vec3(1.0, 1.0, 0.5) * (0.8 + 0.2 * sin(t_anim + float(i)) + syBreath * 0.05);

          if(q.x < q.y) q.xy = q.yx;
          if(q.x < q.z) q.xz = q.zx;
          if(q.y < q.z) q.yz = q.zy;

          float s = 2.0 + 0.1 * sin(t_anim);
          q *= s;
          scale *= s;

          q.z -= 0.5;
      }

      d = sdOctahedron(q, 1.5) / scale;

      // Carve out the center for the camera to fly through
      float centerHole = length(p.xy) - 0.8;
      d = max(d, -centerHole);

      // Camera forcefield
      d = max(d, 0.3 - t_dist);
      return d;
  }

  vec3 getNormal(vec3 p, float t_dist) {
      vec2 e = vec2(0.005, 0.0);
      return normalize(vec3(
          map(p + e.xyy, t_dist) - map(p - e.xyy, t_dist),
          map(p + e.yxy, t_dist) - map(p - e.yxy, t_dist),
          map(p + e.yyx, t_dist) - map(p - e.yyx, t_dist)
      ));
  }

  // ---------------------------------------------------------------------------
  // The yantra's own symmetry, in two dimensions.
  //
  // Same abs()-fold, same axis sort, same octahedral cross-section as map()
  // above, just flattened. Three iterations is enough to read as the silhouette
  // and cheap enough to evaluate six times per pixel.
  // ---------------------------------------------------------------------------
  float sy_yantra(vec2 q, float t_anim) {
      float scale = 1.0;
      for (int i = 0; i < 3; i++) {
          q *= rot(t_anim * 0.2 + float(i) * 0.35);
          q = abs(q) - 0.62 * (0.8 + 0.2 * sin(t_anim + float(i)));
          if (q.x < q.y) q = q.yx;
          q *= 1.85;
          scale *= 1.85;
      }
      return (abs(q.x) + abs(q.y) - 1.25) / scale;
  }

  // Deflection of a sight-line passing the yantra. Taking the gradient of the
  // silhouette field means space bends AROUND the arms -- the lensing follows
  // the geometry's actual shape instead of being a generic radial swirl.
  vec2 sy_lens(vec2 uv, float t_anim, out float sil) {
      const float e = 0.007;
      sil = sy_yantra(uv, t_anim);
      float gx = sy_yantra(uv + vec2(e, 0.0), t_anim) - sil;
      float gy = sy_yantra(uv + vec2(0.0, e), t_anim) - sil;
      // Falls away with distance from the set, so far space stays straight.
      return (vec2(gx, gy) / e) / (1.0 + sil * sil * 90.0);
  }

  // ---------------------------------------------------------------------------
  // Deep space, warped by the geometry.
  // ---------------------------------------------------------------------------
  vec3 sy_hyperspace(vec2 uv, float travel, float energy, float shimmer, float swell) {
      float sil;
      vec2 defl = sy_lens(uv, syAnim, sil);

      // Each lobe pulls the horizon inward. Shrinking the effective radius near
      // the arms is what turns a lobe into the MOUTH of a throat, rather than a
      // beam laid over a backdrop -- the field genuinely recedes there.
      float throat = exp(-abs(sil) * 2.6);
      vec2 w = uv + defl * syLensDepth * (0.6 + energy * 0.8);
      float rw = max(length(w) * (1.0 - throat * syThroatPull), 0.035);
      float ang = atan(w.y, w.x);

      // 1/r is the perspective term: equal steps of depth are equal steps in
      // this coordinate, so scrolling it reads as falling inward forever.
      float depth = 1.0 / rw + travel * 0.35;

      // Bilateral fourfold fold of the angle. abs() keeps it mirror-continuous,
      // so the surrounding space inherits the yantra's symmetry without a seam.
      float fa = abs(mod(ang, 1.5707963) - 0.7853981);
      vec2 tun = vec2(fa * 2.2, depth);

      // Nebula. Two octaves only: at projection scale the broad shapes are what
      // carry, and fine detail is lost across a room anyway.
      float neb = noise(tun * vec2(3.00, 0.28) + vec2(0.0, syAnim * 0.04)) * 0.55
                + noise(tun * vec2(6.50, 0.62) - vec2(0.0, syAnim * 0.07)) * 0.30
                + noise(tun * vec2(13.0, 1.40) + vec2(0.0, syAnim * 0.11)) * 0.15;

      // Linear values: these still pass through the tonemap and 1/2.2 gamma at
      // the end of main(), which lifts them hard. A plum of 0.105 lands near
      // luminance 86 -- brighter than the geometry's own midtones.
      vec3 col = mix(vec3(0.0014, 0.0004, 0.0038),  // near-black indigo
                     vec3(0.0270, 0.0062, 0.0440),  // deep plum
                     smoothstep(0.10, 0.92, neb));
      col = mix(col, vec3(0.0080, 0.0072, 0.0360),  // blue-violet haze
                smoothstep(0.40, 0.95, neb) * 0.65);

      // The throats themselves glow faintly, so the lobes read as openings.
      col += vec3(0.042, 0.022, 0.062) * throat * (0.18 + energy * 0.26);

      // Depth-layered particles, drifting down the throat. Because tun is built
      // from the warped radius, they bend around the lobes and vanish into them.
      for (int i = 0; i < 3; i++) {
          float fi = float(i);
          float layer = 7.0 + fi * 11.0;
          float speed = 0.5 + fi * 0.8;
          vec2 sc = vec2(tun.x * layer, (depth * speed) * layer * 0.22);
          vec2 cell = floor(sc);
          vec2 f = fract(sc) - 0.5;
          vec2 jit = hash2(cell + fi * 31.7) - 0.5;
          // Squashing the depth axis smears each point into a short streak, so
          // motion reads as travel rather than as drifting dots.
          vec2 dv = (f - jit * 0.7) * vec2(1.0, syStreakLength + fi * 0.06);
          float pt = exp(-dot(dv, dv) * 42.0);
          float alive = step(0.70 - energy * 0.18, hash(cell + fi * 7.3));
          // Near layers champagne, far layers violet.
          vec3 tint = mix(vec3(0.30, 0.20, 0.42), vec3(0.85, 0.74, 0.52), fi * 0.5);
          col += tint * pt * alive * (0.075 + shimmer * 0.32) / (1.0 + fi * 0.7);
      }

      // Ghost yantras receding into the throat: smaller, dimmer and more twisted
      // each step. Kept faint so they read as strange structures out in
      // hyperspace before they read as copies of the hero.
      for (int i = 1; i <= 3; i++) {
          float fi = float(i);
          float s = 1.0 + fi * 1.35;
          vec2 eq = (uv + defl * syLensDepth * 0.35 * fi) * s;
          eq *= rot(syAnim * 0.10 * fi + fi * 0.7);
          float ed = sy_yantra(eq, syAnim - fi * 0.55);
          float band = smoothstep(0.090 / s, 0.0, abs(ed));
          vec3 ghost = mix(vec3(0.30, 0.22, 0.40), vec3(0.62, 0.55, 0.40), 1.0 / fi);
          col += ghost * band * syEchoDepth * (0.30 + energy * 0.28) / (fi * fi);
      }

      // The void breathes with the low end, without ever getting bright enough
      // to compete with the geometry.
      return col * syVoidLift * (0.88 + swell * 0.20);
  }

  void main() {
      vec2 uv = (gl_FragCoord.xy - 0.5 * resolution.xy) / min(resolution.x, resolution.y);

      float energy = clamp(globalEnergy, 0.0, 1.0);
      float bodyBass = clamp(u_slowBass * 1.7, 0.0, 1.0);
      float bodyLevel = clamp(u_slowLevel * 1.6, 0.0, 1.0);
      float kickEnv = smoothstep(0.0, 0.7, kickPulse);
      float shimmer = clamp(highs * 0.8 + trebleRel * 0.12 - 0.12, 0.0, 1.0);

      // Travel is integrated on the CPU: u_wavePhase advances faster with the
      // music but never jumps. The original added globalEnergy straight into the
      // camera's Z, which shifted it 1.5 units -- over a third of the 4.0 tunnel
      // period -- the instant the level moved.
      float travel = presetTime * 1.5 + u_wavePhase * 0.9;

      // Fold animation and portal breathing, resolved once for all 96 map calls.
      syAnim = (presetTime * 0.5 + u_wavePhase * 0.25) * 1.5;
      syBreath = (0.5 + 0.5 * sin(presetTime * 0.55)) * (0.35 + bodyBass * 0.75) + kickEnv * 0.35;

      vec3 ro = vec3(0.0, 0.0, travel);

      // Gentle sway
      ro.x += sin(presetTime * 0.25) * 0.2;
      ro.y += cos(presetTime * 0.35) * 0.2;

      // Roll camera
      uv *= rot(sin(presetTime * 0.1) * 0.3);

      vec3 target = vec3(0.0, 0.0, ro.z + 5.0);
      vec3 fwd = normalize(target - ro);
      vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
      vec3 up = cross(fwd, right);
      vec3 rd = normalize(fwd + uv.x * right + uv.y * up);

      float t = 0.0;
      float max_t = 30.0;
      float d = 0.0;
      float glow = 0.0;
      vec3 p = ro;

      for(int i = 0; i < 90; i++) {
          p = ro + rd * t;
          d = map(p, t);

          // Halo around the structure. The original multiplied this by up to 5x
          // with energy, which pinned it at its clamp and flooded the frame with
          // flat colour -- the reason the background read as a solid plane.
          // Exponential in distance, not reciprocal. A 1/d falloff still returns
          // 0.025 per step at d = 0.8, which is the typical clearance flying down
          // the open tunnel, so it accumulated into a flat wash over 90 steps.
          glow += 0.024 * exp(-abs(d) * 5.5) * exp(-t * 0.11) * (1.0 + energy * 1.1);

          if(d < 0.002 || t > max_t) break;
          t += d * 0.8;
      }

      // The deep-space field, warped by the yantra's own symmetry.
      vec3 voidCol = sy_hyperspace(uv, travel, energy, shimmer, bodyBass);

      vec3 col = voidCol;

      if(t < max_t) {
          vec3 n = getNormal(p, t);

          vec3 lightDir = normalize(vec3(0.5, 1.0, -1.0));
          float diff = max(dot(n, lightDir), 0.0);
          float spec = pow(max(dot(reflect(-lightDir, n), -rd), 0.0), 32.0);

          // Cream / pale gold / champagne, so the hero stays warm and bright
          // against the cold void. The original cycled through vivid hues here.
          vec3 matCol = mix(vec3(0.94, 0.88, 0.74), vec3(0.99, 0.93, 0.80),
                            0.5 + 0.5 * sin(p.z * 0.5 - syAnim * 0.6));
          matCol = mix(matCol, vec3(0.86, 0.72, 0.94), 0.10 + 0.10 * sin(p.z * 0.23));

          col = matCol * (diff * 0.80 + 0.42) + vec3(1.0, 0.97, 0.90) * spec * (0.6 + energy * 0.6);

          float fresnel = pow(1.0 - max(dot(n, -rd), 0.0), 4.0);
          col += vec3(1.0, 0.82, 0.52) * fresnel * (1.1 + shimmer * 1.0);

          // Recede into the void rather than into a flat colour.
          col = mix(col, voidCol, smoothstep(6.0, max_t, t));
      }

      // Halo, warm and bounded so it lifts the geometry without washing the void.
      vec3 glowColor = mix(vec3(0.55, 0.30, 0.62), vec3(1.0, 0.84, 0.55), 0.35 + energy * 0.45);
      col += glowColor * min(glow, 2.2) * 0.055 * (0.8 + kickEnv * 0.5);

      col = col / (1.0 + col);
      col = pow(col, vec3(0.4545));

      col *= transitionIdentityPresence();
      col += transitionTunnel(uv);

      outColor = vec4(col, 1.0);
  }
  `;
    return [[174, { name: "Sri Yantra Hyperspace", source }]];
  }
