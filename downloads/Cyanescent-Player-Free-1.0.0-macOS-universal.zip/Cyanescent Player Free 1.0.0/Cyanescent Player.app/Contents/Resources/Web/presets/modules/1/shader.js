export { createFractalTemplePresetShaderEntries as createPresetShaderEntries } from "../../fractalTemplePresetShaderSources.js";
