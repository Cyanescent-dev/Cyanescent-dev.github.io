// Quantum Circuit City (preset 13), HD remaster.
//
// The city is sphere traced inside the slab between its floor and the top of its tallest
// node; the floor itself is an exact ray-plane intersection. The old renderer marched the
// floor as part of the distance field with a 40-60 step budget and a 0.018 minimum step:
// grazing rays crawled along the ground traces and ran out of steps after 6-9 units, so
// the floor only existed in irregular patches that moved with the camera. The floor can
// now never be missed, and the march only has to find architecture.
//
// Surface detail (channels, seams, panels, traces, latitude lines) is shading, filtered by
// the pixel footprint so it fades instead of shimmering. Music lights specific structures:
// packets flow along floor channels into a tower, climb its channel and fire its quantum
// node; rails carry traffic; gates follow the highs; cores pulse with the bass.
// Icosahedron for the sky dome's geodesic lattice, turned so one vertex sits at the zenith
// (the classic geodesic dome crown). Faces are found by nearest face centre, which is exact
// for a regular polyhedron.
function qccIcosahedronGlsl() {
  const phi = (1 + Math.sqrt(5)) / 2;
  const raw = [[-1, phi, 0], [1, phi, 0], [-1, -phi, 0], [1, -phi, 0], [0, -1, phi], [0, 1, phi],
    [0, -1, -phi], [0, 1, -phi], [phi, 0, -1], [phi, 0, 1], [-phi, 0, -1], [-phi, 0, 1]];
  const unit = (v) => { const l = Math.hypot(...v); return v.map((x) => x / l); };
  const top = unit(raw[0]);
  // Rotation taking the first vertex to +Y (Rodrigues about top x Y).
  const axis = unit([top[2], 0, -top[0]]);
  const angle = Math.acos(top[1]);
  const c = Math.cos(angle), s = Math.sin(angle);
  const rotate = (v) => {
    const k = axis, dot = k[0] * v[0] + k[1] * v[1] + k[2] * v[2];
    const cross = [k[1] * v[2] - k[2] * v[1], k[2] * v[0] - k[0] * v[2], k[0] * v[1] - k[1] * v[0]];
    return v.map((x, i) => x * c + cross[i] * s + k[i] * dot * (1 - c));
  };
  const verts = raw.map((v) => rotate(unit(v)));
  const faces = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2],
    [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11],
    [6, 2, 10], [8, 6, 7], [9, 8, 1]];
  const f = (v) => `vec3(${v.map((x) => x.toFixed(6)).join(', ')})`;
  const corners = faces.flatMap((face) => face.map((i) => f(verts[i])));
  const centres = faces.map((face) => f(unit([0, 1, 2].map((a) => face.reduce((sum, i) => sum + verts[i][a], 0)))));
  return `const vec3 QCC_ICO_CENTRE[20] = vec3[20](${centres.join(', ')});
const vec3 QCC_ICO_CORNER[60] = vec3[60](${corners.join(', ')});`;
}

export const quantumCircuitCityShaderBlock = `
const float QCC_FLOOR = -0.70;
const float QCC_TOP = 1.38;
const float QCC_FAR = 30.0;
const vec3 QCC_KEY = vec3(-0.7232, 0.5373, 0.4339);
const vec3 QCC_FILL = vec3(0.6092, 0.3323, -0.7200);

float qccPix = 0.001;
int qccMat = 0;
float qccHeat = 0.0;
float qccDrop = 0.0;
float qccBeatHeat = 0.0;
float qccRise = 0.0;
float qccBliss = 0.0;
float qccShift = 0.0;
float qccPhrase = 0.0;
float qccActivity = 0.5;
float qccEmit = 1.0;
float qccHueShift = 0.0;
vec3 qccFocus = vec3(0.0);

const vec3 QCC_HUES[8] = vec3[8](
  vec3(0.34, 0.86, 0.86),
  vec3(0.66, 0.56, 0.98),
  vec3(0.94, 0.36, 0.74),
  vec3(1.00, 0.64, 0.50),
  vec3(0.98, 0.86, 0.50),
  vec3(0.56, 0.90, 1.00),
  vec3(0.56, 0.94, 0.72),
  vec3(0.52, 0.34, 0.90)
);

// Curated psychedelic pastel cycle: turquoise, lavender, magenta, peach, gold, opal cyan,
// mint, violet. Display-space colour; square it for lighting.
vec3 qccHue(float t) {
  float x = fract(t) * 8.0;
  int i = int(floor(x));
  return mix(QCC_HUES[i], QCC_HUES[(i + 1) % 8], smoothstep(0.0, 1.0, fract(x)));
}

vec3 qccLin(vec3 c) {
  return c * c;
}

float qccRoundBox(vec3 p, vec3 b, float r) {
  vec3 q = abs(p) - b + r;
  return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0) - r;
}

float qccCylinder(vec3 p, float h, float r, float e) {
  vec2 d = vec2(length(p.xz) - r + e, abs(p.y) - h + e);
  return min(max(d.x, d.y), 0.0) + length(max(d, 0.0)) - e;
}

float qccTorus(vec3 p, vec2 t) {
  return length(vec2(length(p.xz) - t.x, p.y)) - t.y;
}

float qccRail(vec2 q, vec2 b, float r) {
  vec2 d = abs(q) - b + r;
  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0) - r;
}

float qccBox2(vec2 p, vec2 b) {
  vec2 d = abs(p) - b;
  return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}

// x: height and type seed, y: footprint and hue seed, z: depth and tilt seed,
// w: tower height above the floor (breathing slightly with bass and level).
vec4 qccCellData(vec2 id) {
  float rnd = hash(id + vec2(12.7, 3.1));
  float rndB = hash(id + vec2(5.3, 18.4));
  float rndC = hash(id + vec2(7.9, 1.4));
  float breath = (0.42 + 0.58 * sin(time * 0.32 + rnd * 6.28)) * (bass * 0.10 + level * 0.07);
  return vec4(rnd, rndB, rndC, 0.18 + rnd * 1.18 + breath + 0.06 * sin(time * 0.23 + rnd * 6.28));
}

// Rails run the full length of their row or column at one level, so the conductors are
// continuous. X rails (along x) sit lower than Z rails, as the original buses did.
float qccRailHeightX(float row) {
  return -0.12 + 0.22 * sin(row * 0.9 + 1.7);
}

float qccRailHeightZ(float column) {
  return 0.06 + 0.22 * sin(column * 1.7 + 0.9);
}

vec3 qccCoreShape(vec2 mid) {
  float coreBeat = 1.0 + bass * 0.05 + level * 0.03;
  float coreHeight = 1.10 + 0.32 * sin(time * 0.11 + hash(mid) * 6.28) + level * 0.12;
  return vec3(0.30 * coreBeat, coreHeight, 0.0);
}

// Materials: 2 tower, 4 quantum node, 5 node ring, 6 rail, 7 core, 8 core crown node,
// 9 halo ring, 10 vertical gate, 11 node neck, 12 crown ring.
float qccMap(vec3 p) {
  float y0 = p.y - QCC_FLOOR;
  vec2 id = floor((p.xz + 0.85) / 1.70);
  vec2 c = mod(p.xz + 0.85, 1.70) - 0.85;

  float railX = qccRail(vec2(p.y - qccRailHeightX(id.y), c.y), vec2(0.018, 0.022), 0.007);
  float railZ = qccRail(vec2(p.y - qccRailHeightZ(id.x), c.x), vec2(0.018, 0.022), 0.007);
  float d = min(railX, railZ);
  qccMat = 6;

  vec4 cell = qccCellData(id);
  float height = cell.w;
  if (max(length(c) - 0.36, y0 - height - 0.34) < d) {
    vec3 tp = vec3(c.x, y0 - height * 0.5, c.y);
    float tower;
    if (cell.x >= 0.58) {
      float radius = 0.12 + cell.y * 0.10;
      tower = qccCylinder(tp, height * 0.5, radius, 0.010);
      if (cell.x > 0.80) tower = min(tower, qccCylinder(vec3(c.x, y0 - height * 0.86, c.y), 0.012, radius + 0.020, 0.005));
    } else {
      tower = qccRoundBox(tp, vec3(0.11 + cell.y * 0.12, height * 0.5, 0.10 + cell.z * 0.13), 0.010);
    }
    if (tower < d) { d = tower; qccMat = 2; }

    vec3 np = vec3(c.x, y0 - height - 0.10, c.y);
    float neck = qccCylinder(np + vec3(0.0, 0.065, 0.0), 0.040, 0.026, 0.004);
    if (neck < d) { d = neck; qccMat = 11; }
    float node = length(np) - (0.095 + highs * 0.010 + level * 0.006);
    if (node < d) { d = node; qccMat = 4; }
    float tilt = (cell.z - 0.5) * 0.56;
    vec3 rp = np;
    rp.yz = rot(tilt) * rp.yz;
    rp.xy = rot(tilt * 0.7 - 0.12) * rp.xy;
    float ring = qccTorus(rp, vec2(0.18 + bass * 0.018, max(0.010 + highs * 0.004, qccPix * 0.6)));
    if (cell.x > 0.72) ring = min(ring, qccTorus(rp, vec2(0.236 + bass * 0.012, max(0.0045, qccPix * 0.5))));
    if (ring < d) { d = ring; qccMat = 5; }
  }

  vec2 mid = floor((p.xz + 2.65) / 5.30);
  vec2 m = mod(p.xz + 2.65, 5.30) - 2.65;
  if (max(length(m) - 0.95, y0 - 2.15) < d) {
    vec3 core = qccCoreShape(mid);
    float w = core.x;
    float coreHeight = core.y;
    float body = qccRoundBox(vec3(m.x, y0 - coreHeight * 0.40, m.y), vec3(w, coreHeight * 0.40, w), 0.014);
    float crown = qccRoundBox(vec3(m.x, y0 - coreHeight * 0.90, m.y), vec3(w * 0.74, coreHeight * 0.10 + 0.012, w * 0.74), 0.010);
    float coreD = min(body, crown);
    if (coreD < d) { d = coreD; qccMat = 7; }
    vec3 cp = vec3(m.x, y0 - coreHeight - 0.22, m.y);
    float crownNeck = qccCylinder(cp + vec3(0.0, 0.14, 0.0), 0.09, 0.05, 0.006);
    if (crownNeck < d) { d = crownNeck; qccMat = 11; }
    float crownNode = length(cp) - (0.15 + highs * 0.012);
    if (crownNode < d) { d = crownNode; qccMat = 8; }
    vec3 crp = cp;
    crp.yz = rot(0.32) * crp.yz;
    float crownRing = min(qccTorus(crp, vec2(0.29 + bass * 0.02, max(0.012, qccPix * 0.6))), qccTorus(crp, vec2(0.355, max(0.005, qccPix * 0.5))));
    if (crownRing < d) { d = crownRing; qccMat = 12; }
    vec3 haloP = vec3(m.x, p.y - (0.48 + 0.08 * sin(time * 0.09)), m.y);
    float halo = qccTorus(haloP, vec2(0.70 + bass * 0.08, max(0.014 + highs * 0.006, qccPix * 0.6)));
    if (halo < d) { d = halo; qccMat = 9; }
    vec3 gp = vec3(m.x, p.y - 0.20, m.y).xzy;
    float gateR = 0.58 + 0.04 * sin(time * 0.13);
    float gate = min(qccTorus(gp, vec2(gateR, max(0.016 + highs * 0.006, qccPix * 0.6))), qccTorus(gp, vec2(gateR - 0.075, max(0.0045, qccPix * 0.5))));
    if (gate < d) { d = gate; qccMat = 10; }
  }

  // Each repeated cell only knows its own objects. Anything in a neighbouring cell is at
  // least the distance to this cell's boundary plus the gap between the bounding volumes.
  float cellGap = 0.85 - max(abs(c.x), abs(c.y));
  float megaGap = 2.65 - max(abs(m.x), abs(m.y));
  return min(d, min(cellGap + 0.45, megaGap + 1.60));
}

vec3 qccNormal(vec3 p, float e) {
  const vec2 k = vec2(1.0, -1.0);
  return normalize(
    k.xyy * qccMap(p + k.xyy * e) +
    k.yyx * qccMap(p + k.yyx * e) +
    k.yxy * qccMap(p + k.yxy * e) +
    k.xxx * qccMap(p + k.xxx * e)
  );
}

float qccOcclusion(vec3 p, vec3 n, int samples) {
  float occ = 0.0;
  float weight = 1.0;
  for (int i = 0; i < 5; i++) {
    if (i >= samples) break;
    float h = 0.024 + 0.062 * float(i);
    occ += (h - qccMap(p + n * h)) * weight;
    weight *= 0.70;
  }
  return clamp(1.0 - 2.6 * occ, 0.0, 1.0);
}

// Soft shadow toward the key light (improved penumbra estimate, so thin rings and rails
// cast clean shadows instead of banded ones).
float qccShadow(vec3 ro, vec3 rd, int steps) {
  float res = 1.0;
  float t = 0.015;
  float prevH = 1e9;
  for (int i = 0; i < 32; i++) {
    if (i >= steps) break;
    vec3 q = ro + rd * t;
    if (q.y > QCC_TOP) break;
    float h = qccMap(q);
    float y = h * h / (2.0 * prevH);
    float dd = sqrt(max(h * h - y * y, 0.0));
    res = min(res, 10.0 * dd / max(t - y, 1e-4));
    prevH = h;
    if (res < 0.01) break;
    t += clamp(h, 0.012, 0.24);
  }
  res = clamp(res, 0.0, 1.0);
  return res * res * (3.0 - 2.0 * res);
}

// One energy packet every two beats per tower. Towers launch on beats (even or odd),
// and the music's activity decides which towers carry a packet in each cycle.
// x: phase in the cycle, y: 1 if this tower is active in this cycle.
vec2 qccCycle(vec2 id) {
  float clock = absoluteBeat * 0.5 + floor(hash(id + vec2(31.7, 4.3)) * 2.0) * 0.5;
  float index = floor(clock);
  float pick = hash(id + vec2(index * 1.37 + 0.3, index * 0.61 + 9.2));
  return vec2(fract(clock), step(pick, qccActivity));
}

// Packet travelling inwards along a floor channel: s is the distance from the tower axis.
float qccFloorPulse(float s, vec2 cycle) {
  if (cycle.x > 0.30) return 0.0;
  float head = 0.85 * (1.0 - cycle.x / 0.30);
  float behind = s - head;
  return cycle.y * exp(-max(behind, 0.0) * 8.0) * smoothstep(-0.025, 0.0, behind);
}

// The same packet climbing the tower's vertical channel to its node.
float qccClimbPulse(float y0, float height, vec2 cycle) {
  float k = (cycle.x - 0.30) / 0.50;
  if (k < 0.0 || k > 1.2) return 0.0;
  float head = height * min(k, 1.0);
  float behind = head - y0;
  float fade = k > 1.0 ? 1.0 - (k - 1.0) * 5.0 : 1.0;
  return cycle.y * fade * exp(-max(behind, 0.0) * 4.5) * smoothstep(-0.02, 0.0, behind);
}

float qccNodeFlash(vec2 cycle) {
  return cycle.y * smoothstep(0.77, 0.81, cycle.x) * exp(-max(cycle.x - 0.81, 0.0) * 6.0) * (1.0 - smoothstep(0.93, 1.0, cycle.x));
}

// Anti-aliased line: coverage of a line of half-width w at distance dist for a pixel
// footprint fw, energy-conserving so fine lines fade instead of shimmering.
float qccLine(float dist, float w, float fw) {
  float edge = max(fw, 0.0005);
  return (1.0 - smoothstep(w - edge * 0.5, w + edge * 0.5, dist)) * min(1.0, (2.0 * w) / max(2.0 * w, edge));
}

vec3 qccSky(vec3 rd) {
  float h = rd.y;
  vec3 zenith = vec3(0.007, 0.005, 0.020);
  vec3 mid = vec3(0.030, 0.016, 0.062);
  vec3 horizon = vec3(0.120, 0.048, 0.135);
  vec3 col = mix(horizon, mid, smoothstep(-0.02, 0.16, h));
  col = mix(col, zenith, smoothstep(0.12, 0.65, h));
  vec2 flat2 = normalize(rd.xz + vec2(1e-5));
  float sunSide = max(0.0, dot(flat2, normalize(QCC_KEY.xz)));
  col += vec3(0.22, 0.10, 0.05) * pow(sunSide, 3.0) * exp(-abs(h) * 9.0) * 0.55;
  // Breakdowns: slow, world-anchored aurora curtains high in the sky (replaces the old
  // screen-space aurora and inner light).
  if (qccBliss > 0.001 && h > 0.0) {
    float az = atan(rd.z, rd.x);
    float curtain = 0.5 + 0.5 * sin(az * 5.0 + sin(az * 3.0 + time * 0.07) * 1.6 + time * 0.05);
    curtain *= smoothstep(0.05, 0.22, h) * (1.0 - smoothstep(0.30, 0.62, h));
    col += mix(vec3(0.10, 0.36, 0.32), vec3(0.26, 0.16, 0.42), 0.5 + 0.5 * sin(az * 2.0 + time * 0.04)) * curtain * qccBliss * 0.22;
  }
  return col;
}

${qccIcosahedronGlsl()}

// A colossal geodesic dome encloses the whole city, far beyond the skyline. It is a
// spherical cap (radius 1, centre 0.6 below the ground) around the viewer, so it never
// approaches or parallaxes against the city; the crown is 0.4 radii overhead and the base
// meets the horizon 0.8 radii away, so the lattice foreshortens toward the horizon and
// sinks into the haze. Two tiers: frequency-6 ribs and a frequency-24 space frame between
// them. It is drawn only on open sky: it never lights, reflects in, or fogs the city.
vec3 qccDome(vec3 rd, vec3 sky, float pixAngle) {
  if (rd.y <= 0.0) return sky;
  const float k = 0.6;
  float t = -k * rd.y + sqrt(k * k * rd.y * rd.y - k * k + 1.0);
  vec3 n = t * rd + vec3(0.0, k, 0.0);

  int face = 0;
  float best = -2.0;
  for (int i = 0; i < 20; i++) {
    float d = dot(n, QCC_ICO_CENTRE[i]);
    if (d > best) { best = d; face = i; }
  }
  vec3 a = QCC_ICO_CORNER[face * 3];
  vec3 b = QCC_ICO_CORNER[face * 3 + 1];
  vec3 c = QCC_ICO_CORNER[face * 3 + 2];
  vec3 fc = QCC_ICO_CENTRE[face];
  vec3 q = n * (dot(a, fc) / dot(n, fc));
  vec3 e0 = b - a, e1 = c - a, e2 = q - a;
  float d00 = dot(e0, e0), d01 = dot(e0, e1), d11 = dot(e1, e1), d20 = dot(e2, e0), d21 = dot(e2, e1);
  float den = d00 * d11 - d01 * d01;
  float v = (d11 * d20 - d01 * d21) / den;
  float w = (d00 * d21 - d01 * d20) / den;
  vec3 bary = vec3(1.0 - v - w, v, w);
  // Barycentric units to radians on the dome: face height 0.9106 on a plane 0.7947 out.
  const float faceAngle = 0.9106 / 0.7947;
  vec3 majorDist = abs(fract(bary * 6.0 + 0.5) - 0.5) * (faceAngle / 6.0);
  vec3 minorDist = abs(fract(bary * 24.0 + 0.5) - 0.5) * (faceAngle / 24.0);

  // Pixel footprint on the dome surface, widened where the view grazes it.
  float graze = max(abs(dot(rd, n)), 0.12);
  float fw = pixAngle * t / graze;
  float rib = qccLine(min(majorDist.x, min(majorDist.y, majorDist.z)), 0.0026, fw);
  float frame = qccLine(min(minorDist.x, min(minorDist.y, minorDist.z)), 0.0008, fw);

  // Panels of the fine frame: glazed, a few faintly tinted. Stable per panel.
  vec3 cellId = floor(bary * 24.0);
  float panelSeed = hash(vec2(float(face) * 13.7 + cellId.x * 3.1 + cellId.z * 0.7, cellId.y * 5.3 + cellId.x * 1.9));

  float sunSide = pow(max(0.0, dot(normalize(rd.xz + vec2(1e-5)), normalize(QCC_KEY.xz))), 2.0);
  float low = 1.0 - smoothstep(0.62, 0.95, n.y);
  // The dome's underside catches the city's light near its base and the warm horizon on
  // the key-light side; the struts read as silhouettes against the sky above.
  vec3 underLight = vec3(0.090, 0.030, 0.085) * low * low;
  vec3 strutCol = sky * 0.55 + underLight * 0.6 + vec3(0.11, 0.06, 0.04) * sunSide * low;
  vec3 panel = sky + underLight * 0.18 + mix(vec3(0.003, 0.005, 0.008), vec3(0.006, 0.003, 0.007), panelSeed) * step(0.82, panelSeed);
  vec3 dome = mix(panel, strutCol, frame * 0.55);
  dome = mix(dome, strutCol * 0.85 + vec3(0.016, 0.012, 0.026), rib * 0.85);

  // Distance haze: the base of the dome is far away and dissolves into the horizon.
  float haze = 1.0 - smoothstep(0.02, 0.34, rd.y);
  return mix(dome, sky, haze * 0.9);
}

vec3 qccHorizon(vec3 rd) {
  return qccSky(normalize(vec3(rd.x, 0.0, rd.z) + vec3(0.0, 1e-4, 0.0)));
}

// Lit colour (linear) for a surface with diffuse albedo and a satin/metal specular lobe.
vec3 qccLight(vec3 albedo, vec3 specTint, vec3 n, vec3 v, float rough, float f0, float ao, float shadow) {
  vec3 keyDir = QCC_KEY;
  vec3 fillDir = QCC_FILL;
  vec3 keyCol = vec3(1.00, 0.82, 0.68) * 1.30;
  vec3 fillCol = vec3(0.46, 0.50, 1.00) * 0.38;
  float ndl = max(dot(n, keyDir), 0.0);
  float ndf = max(dot(n, fillDir), 0.0);
  vec3 skyAmb = mix(vec3(0.06, 0.025, 0.06), vec3(0.10, 0.10, 0.22), n.y * 0.5 + 0.5);
  float nv = max(dot(n, v), 0.0);
  float fres = f0 + (1.0 - f0) * pow(1.0 - nv, 5.0);
  vec3 lit = albedo * (keyCol * ndl * shadow + fillCol * ndf * (0.4 + 0.6 * ao) + skyAmb * ao) * (1.0 - fres * 0.5);
  vec3 h = normalize(keyDir + v);
  float shin = mix(220.0, 10.0, rough);
  float spec = pow(max(dot(n, h), 0.0), shin) * (shin + 8.0) / 40.0;
  lit += specTint * keyCol * spec * fres * ndl * shadow;
  vec3 hf = normalize(fillDir + v);
  lit += specTint * fillCol * pow(max(dot(n, hf), 0.0), shin * 0.5) * fres * 0.5;
  lit += specTint * qccSky(reflect(-v, n)) * fres * ao * (1.0 - rough * 0.75);
  return lit;
}

// Floor: a solid electronic substrate with panels, recessed main channels under the
// towers' axes, PCB traces fanning into each tower base, and contact darkening.
vec3 qccFloor(vec3 pos, vec3 rd, float t, float pixAngle, float shadow, out vec3 emit) {
  emit = vec3(0.0);
  float fw = t * pixAngle / max(-rd.y, 0.03);
  float near = 1.0 - smoothstep(0.010, 0.045, fw);
  float mid = 1.0 - smoothstep(0.030, 0.110, fw);
  vec2 id = floor((pos.xz + 0.85) / 1.70);
  vec2 c = mod(pos.xz + 0.85, 1.70) - 0.85;
  vec4 cell = qccCellData(id);
  vec2 cycle = qccCycle(id);

  vec2 pid = floor((pos.xz + 0.85) / 0.425);
  vec2 pc = mod(pos.xz + 0.85, 0.425) - 0.2125;
  float panelEdge = 0.2125 - max(abs(pc.x), abs(pc.y));
  float seam = qccLine(panelEdge, 0.0025, fw) * near;
  float panelTone = 0.90 + 0.16 * hash(pid + vec2(3.1, 7.7)) * mid;

  float chDist = min(abs(c.x), abs(c.y));
  float groove = qccLine(chDist, 0.026, fw);
  float coreLine = qccLine(chDist, 0.0085, fw);
  vec2 a = abs(c);
  vec2 ba = vec2(0.30) - vec2(0.15);
  vec2 pa = a - vec2(0.15);
  float diag = length(pa - ba * clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0));
  float runX = length(vec2(a.x - clamp(a.x, 0.30, 0.85), a.y - 0.30));
  float runZ = length(vec2(a.y - clamp(a.y, 0.30, 0.85), a.x - 0.30));
  float traceDist = min(diag, min(runX, runZ));
  float trace = qccLine(traceDist, 0.0045, fw) * mid;
  float via = qccLine(abs(length(a - vec2(0.30)) - 0.016), 0.004, fw) * near;

  // Contact shading from the tower and core footprints (analytic, so it is stable).
  float foot = cell.x >= 0.58 ? length(c) - (0.12 + cell.y * 0.10) : qccBox2(c, vec2(0.11 + cell.y * 0.12, 0.10 + cell.z * 0.13));
  vec2 mid2 = floor((pos.xz + 2.65) / 5.30);
  vec2 m = mod(pos.xz + 2.65, 5.30) - 2.65;
  float coreFoot = qccBox2(m, vec2(qccCoreShape(mid2).x));
  float contact = mix(0.30, 1.0, smoothstep(0.0, 0.20, foot)) * mix(0.25, 1.0, smoothstep(0.0, 0.34, coreFoot));

  vec3 substrate = qccLin(vec3(0.22, 0.17, 0.32)) * panelTone;
  substrate *= 1.0 - seam * 0.45;
  substrate = mix(substrate, qccLin(vec3(0.06, 0.05, 0.09)), groove * 0.9);
  vec3 traceTint = qccLin(vec3(0.86, 0.74, 0.56));
  substrate = mix(substrate, traceTint * 0.40, max(trace, via) * 0.70);
  vec3 col = qccLight(substrate, vec3(1.0), vec3(0.0, 1.0, 0.0), -rd, 0.42, 0.045, contact, shadow * contact);

  vec3 accent = qccLin(qccHue(cell.y * 0.62 + cell.x * 0.21 + qccHueShift + 0.5));
  float s = abs(c.y) < abs(c.x) ? abs(c.x) : abs(c.y);
  float pulse = qccFloorPulse(s, cycle) * (0.9 + bass * 0.8 + kick * 0.5);
  float idle = (0.20 + qccRise * 0.30 + qccShift * 0.22 + kick * qccBeatHeat * 0.35) * (1.0 - qccBliss * 0.35);
  float wave = 0.0;
  if (qccPhrase > 0.001) {
    float radius = mix(0.6, 11.0, phraseProgress);
    wave = exp(-abs(length(pos.xz - qccFocus.xz) - radius) * 2.2) * qccPhrase * 0.55;
  }
  emit += accent * coreLine * (idle + pulse * 3.2 + wave) * qccEmit;
  emit += accent * groove * (pulse * 0.30 + wave * 0.15) * qccEmit;
  float spill = exp(-chDist * 26.0);
  emit += accent * spill * (idle * 0.10 + pulse * 0.55 + wave * 0.18) * qccEmit;
  float dataFlow = smoothstep(0.75, 1.0, fract((a.x + a.y) * 3.0 - u_wavePhase * 0.6 + cell.z)) * (0.15 + highs * 0.55);
  emit += qccLin(qccHue(cell.z * 0.5 + qccHueShift + 0.1)) * trace * dataFlow * 0.22 * qccEmit;
  return col;
}

vec3 qccArch(vec3 pos, vec3 n, int mat, vec3 rd, float t, float pixAngle, float ao, float shadow, out vec3 emit) {
  emit = vec3(0.0);
  vec3 v = -rd;
  float y0 = pos.y - QCC_FLOOR;
  float fw = t * pixAngle;
  float near = 1.0 - smoothstep(0.004, 0.016, fw);
  vec2 id = floor((pos.xz + 0.85) / 1.70);
  vec2 c = mod(pos.xz + 0.85, 1.70) - 0.85;
  vec4 cell = qccCellData(id);
  vec2 cycle = qccCycle(id);
  float height = cell.w;
  float hueT = cell.y * 0.62 + cell.x * 0.21 + qccHueShift;
  vec3 accent = qccLin(qccHue(hueT + 0.5));
  float flash = qccNodeFlash(cycle);
  float side = 1.0 - smoothstep(0.55, 0.85, abs(n.y));
  float contact = mix(0.45, 1.0, smoothstep(0.0, 0.28, y0));
  ao *= contact;

  vec3 albedo = vec3(0.5);
  vec3 specTint = vec3(1.0);
  float rough = 0.35;
  float f0 = 0.05;

  if (mat == 2) {
    vec3 body = mix(qccHue(hueT), vec3(0.50, 0.46, 0.60), 0.18);
    float u;
    bool isRound = cell.x >= 0.58;
    float radius = 0.12 + cell.y * 0.10;
    if (isRound) {
      float ang = atan(c.y, c.x);
      u = abs(mod(ang + PI * 0.25, PI * 0.5) - PI * 0.25) * radius;
    } else {
      vec2 foot = vec2(0.11 + cell.y * 0.12, 0.10 + cell.z * 0.13);
      u = abs(c.x) / foot.x > abs(c.y) / foot.y ? abs(c.y) : abs(c.x);
    }
    float roof = smoothstep(0.85, 0.95, n.y);
    float groove = qccLine(u, 0.012, fw) * side;
    float channel = qccLine(u, 0.0055, fw) * side;
    float seamY = abs(fract(y0 / 0.16 + 0.5) - 0.5) * 0.16;
    float seam = qccLine(seamY, 0.0016, fw) * near * side * step(0.35, cell.x);
    float topBand = qccLine(abs(y0 - (height - 0.06)), 0.007, fw) * side;
    float collar = (isRound && cell.x > 0.80 && abs(y0 - height * 0.86) < 0.018 && length(c) > radius + 0.004) ? 1.0 : 0.0;
    float socket = qccLine(abs(length(c) - 0.055), 0.005, fw) * roof;
    float plinth = 1.0 - smoothstep(0.03, 0.05, y0);
    albedo = qccLin(body) * (0.82 + 0.18 * smoothstep(0.0, height, y0));
    albedo *= 1.0 - seam * 0.35;
    albedo *= 1.0 - plinth * 0.45;
    albedo = mix(albedo, qccLin(vec3(0.16, 0.13, 0.22)), groove * 0.75);
    rough = 0.34;
    f0 = 0.05;
    if (collar > 0.5) {
      albedo = qccLin(vec3(0.70, 0.66, 0.76));
      specTint = albedo * 1.4;
      rough = 0.18;
      f0 = 0.5;
    }
    float climb = qccClimbPulse(y0, height, cycle) * (1.0 + bass * 0.7 + kick * 0.4);
    float k = (cycle.x - 0.30) / 0.50;
    float riding = cycle.y * step(0.0, k) * (1.0 - smoothstep(0.92, 1.0, k));
    float band = qccLine(abs(y0 - height * clamp(k, 0.0, 1.0)), 0.009, fw) * riding * (1.0 - roof);
    float charge = clamp(buildUpState * 0.75 + qccRise * 0.85, 0.0, 1.0);
    float charged = charge * smoothstep(height * charge + 0.04, height * charge - 0.04, y0) * 0.45;
    float idle = (0.20 + qccShift * 0.25) * (1.0 - qccBliss * 0.35);
    emit += accent * channel * (idle + charged + climb * 4.0) * qccEmit;
    emit += accent * groove * climb * 0.35 * qccEmit;
    emit += accent * band * (1.6 + bass * 0.8) * qccEmit;
    emit += accent * exp(-u * 40.0) * side * (idle * 0.10 + climb * 0.55 + charged * 0.3) * qccEmit;
    emit += accent * roof * exp(-length(c) * 9.0) * flash * 0.9 * qccEmit;
    emit += accent * topBand * (0.38 + flash * 1.8 + qccHeat * 0.20) * qccEmit;
    emit += accent * collar * (0.25 + flash * 1.8) * qccEmit;
    emit += accent * socket * (0.35 + flash * 2.2) * qccEmit;
  } else if (mat == 4) {
    vec3 np = vec3(c.x, y0 - height - 0.10, c.y);
    float nv = max(dot(n, v), 0.0);
    vec3 pearl = mix(vec3(0.86, 0.84, 0.94), qccHue(hueT + 0.5 + (1.0 - nv) * 0.45 + n.y * 0.12), 0.58);
    float lat = abs(fract(n.y * 5.0 + 0.5) - 0.5) / 5.0;
    float latLine = qccLine(lat, 0.004, fw * 2.0) * near;
    float equator = qccLine(abs(np.y), 0.006, fw);
    albedo = qccLin(pearl) * (1.0 - latLine * 0.25);
    specTint = mix(vec3(1.0), qccLin(qccHue(hueT + 0.15 + nv * 0.3)) * 1.6, 0.5);
    rough = 0.12;
    f0 = 0.10;
    float breathe = qccBliss * 0.20 * (0.5 + 0.5 * sin(time * 0.7 + cell.y * 6.28));
    float inner = (0.16 + highs * 0.30 + qccHeat * 0.20 + breathe + flash * 2.6) * (0.30 + 0.70 * nv * nv);
    emit += accent * inner * qccEmit;
    emit += accent * (equator * (0.35 + flash * 2.0) + latLine * flash * 0.6) * qccEmit;
  } else if (mat == 5 || mat == 12) {
    vec3 metal = mix(vec3(0.64, 0.62, 0.72), qccHue(hueT + 0.35), 0.35);
    albedo = qccLin(metal) * 0.55;
    specTint = qccLin(metal) * 1.5;
    rough = 0.20;
    f0 = 0.55;
    float act = mat == 5 ? flash * 2.2 + kick * qccBeatHeat * 0.35 + highs * 0.10 : bass * 0.5 + kick * qccBeatHeat * 0.6 + qccDrop * 0.4;
    vec3 ringCol = mat == 5 ? accent : qccLin(qccHue(0.62 + qccHueShift));
    emit += ringCol * (0.06 + act) * 0.8 * qccEmit;
  } else if (mat == 11) {
    albedo = qccLin(vec3(0.46, 0.44, 0.54));
    specTint = qccLin(vec3(0.80, 0.78, 0.88)) * 1.3;
    rough = 0.25;
    f0 = 0.5;
  } else if (mat == 6) {
    float hx = qccRailHeightX(id.y);
    float hz = qccRailHeightZ(id.x);
    bool alongX = length(vec2(pos.y - hx, c.y)) < length(vec2(pos.y - hz, c.x));
    float h = alongX ? hx : hz;
    float along = alongX ? pos.x : pos.z;
    float row = alongX ? id.y : id.x + 41.0;
    float rowSeed = hash(vec2(row, 5.7));
    vec3 railCol = qccLin(qccHue(rowSeed * 0.5 + qccHueShift + 0.05));
    albedo = qccLin(mix(vec3(0.80, 0.70, 0.56), vec3(0.62, 0.58, 0.72), rowSeed)) * 0.62;
    specTint = albedo * 1.8;
    rough = 0.24;
    f0 = 0.45;
    float stripe = qccLine(abs(pos.y - h), 0.0035, fw) * side;
    float dir = rowSeed > 0.5 ? 1.0 : -1.0;
    float x = fract(along * 0.55 - u_wavePhase * 0.75 * dir + rowSeed * 7.0);
    x = dir > 0.0 ? x : 1.0 - x;
    float packet = smoothstep(0.72, 0.985, x) * (1.0 - smoothstep(0.985, 1.0, x));
    float rowActive = step(hash(vec2(row, floor(time * 0.07) + 3.0)), 0.30 + highs * 0.45 + futureDensity * 0.20 + qccDrop * 0.25);
    float traffic = packet * rowActive * (0.9 + highs * 1.3);
    emit += railCol * (stripe * (0.30 + traffic * 2.6) + traffic * 0.14) * qccEmit;
  } else if (mat == 7) {
    vec2 mid = floor((pos.xz + 2.65) / 5.30);
    vec2 m = mod(pos.xz + 2.65, 5.30) - 2.65;
    vec3 core = qccCoreShape(mid);
    float coreHeight = core.y;
    float u = abs(n.x) > abs(n.z) ? m.y : m.x;
    float lane = abs(fract(u / 0.075 + 0.5) - 0.5) * 0.075;
    float laneIndex = floor(u / 0.075 + 0.5);
    float channel = qccLine(lane, 0.0042, fw) * side;
    float panelY = abs(fract(y0 / 0.12 + 0.5) - 0.5) * 0.12;
    float seam = qccLine(panelY, 0.0018, fw) * near * side;
    float setback = qccLine(abs(y0 - coreHeight * 0.80), 0.010, fw);
    vec3 coreCol = qccLin(qccHue(hash(mid) * 0.5 + 0.58 + qccHueShift));
    albedo = qccLin(vec3(0.34, 0.27, 0.52)) * (1.0 - seam * 0.35);
    albedo = mix(albedo, qccLin(vec3(0.08, 0.06, 0.12)), channel * 0.8);
    specTint = vec3(1.1);
    rough = 0.28;
    f0 = 0.06;
    float flow = pow(fract(y0 * 0.9 - absoluteBeat * 0.25 + hash(vec2(laneIndex, mid.x + mid.y)) * 3.0), 8.0);
    emit += coreCol * channel * (0.22 + flow * (0.7 + bass * 1.6) + qccDrop * 0.4) * qccEmit;
    emit += coreCol * setback * (0.55 + bass * 0.8 + kick * qccBeatHeat * 0.6) * qccEmit;
  } else if (mat == 8) {
    vec2 mid = floor((pos.xz + 2.65) / 5.30);
    float nv = max(dot(n, v), 0.0);
    vec3 coreCol = qccLin(qccHue(hash(mid) * 0.5 + 0.58 + qccHueShift));
    vec3 pearl = mix(vec3(0.86, 0.84, 0.94), qccHue(0.58 + (1.0 - nv) * 0.5 + n.y * 0.15 + qccHueShift), 0.62);
    float lat = abs(fract(n.y * 7.0 + 0.5) - 0.5) / 7.0;
    float latLine = qccLine(lat, 0.0035, fw * 1.5) * near;
    albedo = qccLin(pearl) * (1.0 - latLine * 0.25);
    specTint = mix(vec3(1.0), qccLin(qccHue(0.2 + nv * 0.3)) * 1.6, 0.5);
    rough = 0.10;
    f0 = 0.10;
    float act = 0.10 + bass * 0.45 + kick * qccBeatHeat * 0.9 + qccDrop * 0.6 + qccBliss * 0.15;
    emit += coreCol * act * (0.30 + 0.70 * nv * nv) * qccEmit;
    emit += coreCol * latLine * act * 0.8 * qccEmit;
  } else {
    vec2 mid = floor((pos.xz + 2.65) / 5.30);
    vec2 m = mod(pos.xz + 2.65, 5.30) - 2.65;
    float ang = mat == 9 ? atan(m.y, m.x) : atan(pos.y - 0.20, m.x);
    vec3 gateCol = qccLin(qccHue((mat == 9 ? 0.06 : 0.80) + hash(mid) * 0.25 + qccHueShift));
    albedo = qccLin(vec3(0.80, 0.78, 0.86)) * 0.5;
    specTint = vec3(1.2);
    rough = 0.18;
    f0 = 0.30;
    float bands = 0.55 + 0.45 * sin(ang * 6.0 - time * (0.8 + highs * 1.6));
    float act = 0.34 + highs * 1.0 + qccRise * 0.40 + qccDrop * 0.45 + qccShift * 0.30;
    emit += gateCol * act * bands * qccEmit;
  }
  return qccLight(albedo, specTint, n, v, rough, f0, ao, shadow);
}

vec3 qccTonemap(vec3 x) {
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

// Returns the display-space city colour.
vec3 quantumCircuitCity(vec2 p) {
  // Camera journey: unchanged from the original preset.
  float travel = time * 0.31;
  float orbit = time * 0.118 + sin(time * 0.049) * 0.52 + sin(time * 0.017) * 0.18;
  vec3 focus = vec3(
    0.56 * sin(time * 0.050) + 0.18 * sin(time * 0.019),
    0.05 + 0.14 * sin(time * 0.061),
    travel + 0.66 * cos(time * 0.041)
  );
  vec3 ro = focus + vec3(
    cos(orbit) * (2.68 + 0.18 * sin(time * 0.073)),
    1.04 + 0.28 * sin(time * 0.067 + 1.0),
    sin(orbit) * 2.14 - 1.30
  );
  vec3 target = focus + vec3(
    sin(orbit * 0.70) * 0.46,
    0.10 + 0.16 * cos(time * 0.052),
    1.12 + cos(orbit * 0.55) * 0.40
  );
  vec3 forward = normalize(target - ro);
  vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
  vec3 up = normalize(cross(forward, right));
  vec3 rd = normalize(forward * 1.42 + right * p.x * 0.82 + up * p.y * 0.82);
  qccFocus = focus;

  float pixAngle = 1.16 / min(resolution.x, resolution.y);
  bool high = quality > 0.5;
  int maxSteps = high ? 128 : 92;

  float tFloor = rd.y < -1e-5 ? (QCC_FLOOR - ro.y) / rd.y : 1e9;
  float tExit = rd.y > 1e-5 ? (QCC_TOP - ro.y) / rd.y : 1e9;
  float t = 0.04;
  if (ro.y > QCC_TOP) t = rd.y < 0.0 ? max(t, (QCC_TOP - ro.y) / rd.y) : 1e9;
  float tEnd = min(min(tFloor, tExit), QCC_FAR);

  bool hit = false;
  int mat = 0;
  float steps = 0.0;
  float lastD = 1e9;
  int lastMat = 0;
  for (int i = 0; i < 128; i++) {
    if (i >= maxSteps || t > tEnd) break;
    qccPix = t * pixAngle;
    float d = qccMap(ro + rd * t);
    if (d < qccPix * 0.35) {
      hit = true;
      mat = qccMat;
      break;
    }
    t += d * 0.94;
    steps += 1.0;
    lastD = d;
    lastMat = qccMat;
  }
  if (!hit && t < tEnd && lastD < qccPix * 3.0) {
    hit = true;
    mat = lastMat;
  }
  bool floorHit = !hit && tFloor < 1e8;

  #ifdef QCC_DEBUG
  if (QCC_DEBUG == 1) {
    bool exhausted = !hit && t < tEnd;
    vec3 dbg = hit ? vec3(0.2, 0.3, 0.9) : floorHit ? vec3(0.1, 0.8, 0.2) : vec3(0.0);
    if (exhausted && tFloor < 1e8) dbg = vec3(0.95, 0.1, 0.1);
    return dbg;
  }
  if (QCC_DEBUG == 2) return vec3(steps / float(maxSteps), 1.0 - steps / float(maxSteps), 0.1);
  #endif

  vec3 keyDir = QCC_KEY;
  vec3 lit = qccSky(rd);
  if (!hit && !floorHit) lit = qccDome(rd, lit, pixAngle);
  vec3 emit = vec3(0.0);
  float dist = 1e9;

  if (floorHit || hit) {
    vec3 floorLit = vec3(0.0);
    vec3 floorEmit = vec3(0.0);
    float fade = hit ? smoothstep(QCC_FAR * 0.70, QCC_FAR, t) : 1.0;
    if (floorHit || (fade > 0.0 && tFloor < 1e8)) {
      vec3 fpos = ro + rd * tFloor;
      float fshadow = 1.0;
      float shadowRange = high ? 13.0 : 11.0;
      #ifdef QCC_DEBUG
      if (QCC_DEBUG == 10) shadowRange = 0.0;
      #endif
      if (tFloor < shadowRange) {
        qccPix = 0.002;
        fshadow = mix(qccShadow(fpos + vec3(0.0, 0.002, 0.0), keyDir, high ? 22 : 16), 1.0, smoothstep(shadowRange * 0.65, shadowRange, tFloor));
      }
      floorLit = qccFloor(fpos, rd, tFloor, pixAngle, fshadow, floorEmit);
      lit = floorLit;
      emit = floorEmit;
      dist = tFloor;
    }
    if (hit) {
      vec3 pos = ro + rd * t;
      qccPix = t * pixAngle;
      vec3 n = qccNormal(pos, max(0.0012, qccPix * 0.7));
      int aoSamples = high ? 4 : 3;
      #ifdef QCC_DEBUG
      if (QCC_DEBUG == 11) aoSamples = 0;
      #endif
      float ao = qccOcclusion(pos, n, aoSamples);
      float shadow = 1.0;
      float shadowRange = high ? 11.0 : 9.0;
      #ifdef QCC_DEBUG
      if (QCC_DEBUG == 10) shadowRange = 0.0;
      #endif
      if (t < shadowRange) {
        qccPix = 0.002;
        shadow = mix(qccShadow(pos + n * 0.004, keyDir, high ? 22 : 16), 1.0, smoothstep(shadowRange * 0.65, shadowRange, t));
      }
      vec3 archEmit;
      vec3 archLit = qccArch(pos, n, mat, rd, t, pixAngle, ao, shadow, archEmit);
      lit = mix(archLit, lit, fade);
      emit = mix(archEmit, emit, fade);
      dist = mix(t, dist, fade);
    }
    // Aerial perspective: distance only, converging on the horizon colour so the infinite
    // floor and the far city meet the sky without a seam.
    float fog = 1.0 - exp(-max(dist - 8.0, 0.0) * 0.034);
    vec3 horizon = qccHorizon(rd);
    lit = mix(lit, horizon, fog);
    emit *= 1.0 - fog * 0.78;
  }

  vec3 color = qccTonemap((lit + emit) * 1.25);
  return pow(color, vec3(1.0 / 2.2));
}
`;
