export { createKaleidoscopicWoodstockPresetShaderEntries as createPresetShaderEntries } from "../../kaleidoscopicWoodstockPresetShaderSources.js";
