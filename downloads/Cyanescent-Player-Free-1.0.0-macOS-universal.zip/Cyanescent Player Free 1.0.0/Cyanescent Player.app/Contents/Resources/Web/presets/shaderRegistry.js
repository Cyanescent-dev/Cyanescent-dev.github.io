import { runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
import { PresetShaderModuleCache } from "../engine/shaderModules.js";
import { presetShaderFactories } from "../generated/presetModules.js";
import { modularShaderPrelude } from "./shaders/modularPrelude.js";
import { transitionShaderPrelude } from "./shaders/transitionPrelude.js";
export function createPresetShaderRegistry(entries) {
  const modules = new Map(entries);

  function moduleIdForPreset(presetValue) {
    const id = Math.round(Number(presetValue) || 0);
    return modules.has(id) ? id : null;
  }

  return {
    modules,
    ids: () => Array.from(modules.keys()),
    has: (presetValue) => moduleIdForPreset(presetValue) !== null,
    moduleIdForPreset
  };
}

export function createApplicationPresetShaderRegistry() {
  const shaderContext = {
    modularShaderPrelude,
    modularTransitionShaderBlock: transitionShaderPrelude
  };
  return createPresetShaderRegistry(
    presetShaderFactories.flatMap((createEntries) => createEntries(shaderContext)).filter(([id]) => runtimeAllowsPreset(id))
  );
}

export function createPresetShaderCache({
  registry,
  compileModule,
  shouldDeferCompile,
  isActive,
  onModuleReady,
  onModuleError
}) {
  return new PresetShaderModuleCache({
    modules: registry.modules,
    compileModule,
    shouldDeferCompile,
    isActive,
    onModuleReady,
    onModuleError
  });
}

export async function warmPresetShaderModules(cache, options = {}, onProgress = null) {
  const ids = cache.ids();
  const total = ids.reduce((count, moduleId) => (
    count + (cache.modules.get(moduleId)?.qualitySources ? 2 : 1)
  ), 0);
  if (total === 0) return;

  let completed = 0;
  for (const moduleId of ids) {
    const module = cache.modules.get(moduleId);
    const qualities = module?.qualitySources ? [0, 1] : [0];
    for (const qualityValue of qualities) {
      if (onProgress) {
        onProgress(completed / total, `Compiling: ${module?.name || 'Preset module'}`);
      }
      cache.ensure(moduleId, { ...options, qualityValue });
      completed += 1;
      // Yield to the main thread every few module variants to keep UI responsive.
      if (completed % 3 === 0) await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }
  
  if (onProgress) {
    onProgress(1, "Preset modules compiled");
  }
}

export function queuePresetShaderModule(cache, presetValue, delay = 1200, active = false, qualityValue = 0) {
  cache.queuePrime(presetValue, delay, active, qualityValue);
}

export function ensurePresetShaderModule(cache, presetValue, options = {}, active = false, qualityValue = 0) {
  return cache.ensure(presetValue, { ...options, active, qualityValue });
}

export function primePresetShaderModule(cache, registry, presetValue, delay = 0, active = false, qualityValue = 0) {
  if (registry.moduleIdForPreset(presetValue) === null) return;
  cache.prime(presetValue, delay, active, qualityValue);
}

export function renderProgramForPresetShader({
  cache,
  registry,
  presetValue,
  qualityValue = 0,
  shellProgram,
  fullProgram,
  fullShaderReady,
  queueModulePrime,
  onModuleUnavailable
}) {
  const moduleId = registry.moduleIdForPreset(presetValue);
  const moduleProgram = moduleId === null ? null : cache.programFor(moduleId, qualityValue);
  if (moduleId !== null && !moduleProgram) {
    if (cache.hasError(moduleId, qualityValue)) {
      onModuleUnavailable?.(moduleId, cache.modules.get(moduleId), "error", cache.errorFor(moduleId, qualityValue));
    } else {
      onModuleUnavailable?.(moduleId, cache.modules.get(moduleId), "not-ready", "");
    }
    queueModulePrime?.(moduleId, 2000);
    return { program: shellProgram, shellActive: true };
  }
  if (moduleProgram) {
    return { program: moduleProgram, shellActive: false };
  }
  const program = fullShaderReady && fullProgram ? fullProgram : shellProgram;
  return { program, shellActive: program === shellProgram };
}

export class PresetShaderModuleManager {
  constructor({
    registry,
    createCache,
    isActive,
    shellProgram,
    fullProgram,
    fullShaderReady,
    onShellActive,
    onModuleUnavailable
  }) {
    this.registry = registry;
    this.createCache = createCache;
    this.isActive = isActive;
    this.shellProgram = shellProgram;
    this.fullProgram = fullProgram;
    this.fullShaderReady = fullShaderReady;
    this.onShellActive = onShellActive;
    this.onModuleUnavailable = onModuleUnavailable;
    this.cache = null;
  }

  getCache() {
    if (!this.cache) this.cache = this.createCache();
    return this.cache;
  }

  moduleIdForPreset(presetValue) {
    return this.registry.moduleIdForPreset(presetValue);
  }

  queuePrime(presetValue, delay = 1200, qualityValue = 0) {
    queuePresetShaderModule(this.getCache(), presetValue, delay, this.isActive?.(), qualityValue);
  }

  ensure(presetValue, options = {}, qualityValue = 0) {
    return ensurePresetShaderModule(this.getCache(), presetValue, options, this.isActive?.(), qualityValue);
  }

  prime(presetValue, delay = 0, qualityValue = 0) {
    primePresetShaderModule(this.getCache(), this.registry, presetValue, delay, this.isActive?.(), qualityValue);
  }

  async warm(options = {}, onProgress = null) {
    await warmPresetShaderModules(this.getCache(), options, onProgress);
  }

  renderProgramForPreset(presetValue, qualityValue = 0) {
    const result = renderProgramForPresetShader({
      cache: this.getCache(),
      registry: this.registry,
      presetValue,
      qualityValue,
      shellProgram: this.shellProgram(),
      fullProgram: this.fullProgram(),
      fullShaderReady: this.fullShaderReady(),
      queueModulePrime: (moduleId, delay) => this.queuePrime(moduleId, delay, qualityValue),
      onModuleUnavailable: this.onModuleUnavailable
    });
    this.onShellActive?.(result.shellActive);
    return result.program;
  }

  diagnosticState(presetValue, qualityValue = 0) {
    return this.getCache().diagnosticState(presetValue, qualityValue);
  }
}

export function createPresetShaderModuleController({
  registry,
  compileModule,
  shouldDeferCompile,
  isActive,
  shellProgram,
  fullProgram,
  fullShaderReady,
  onShellActive,
  onModuleUnavailable,
  onModuleReady,
  onModuleError
}) {
  const manager = new PresetShaderModuleManager({
    registry,
    createCache: () => createPresetShaderCache({
      registry,
      compileModule,
      shouldDeferCompile,
      isActive,
      onModuleReady,
      onModuleError
    }),
    isActive,
    shellProgram,
    fullProgram,
    fullShaderReady,
    onShellActive,
    onModuleUnavailable
  });

  return {
    moduleIdForPreset: (presetValue) => registry.moduleIdForPreset(presetValue),
    queuePrime: (presetValue, delay = 1200, qualityValue = 0) => manager.queuePrime(presetValue, delay, qualityValue),
    ensure: (presetValue, options = {}, qualityValue = 0) => manager.ensure(presetValue, options, qualityValue),
    renderProgramForPreset: (presetValue, qualityValue = 0) => manager.renderProgramForPreset(presetValue, qualityValue),
    diagnosticState: (presetValue, qualityValue = 0) => manager.diagnosticState(presetValue, qualityValue),
    prime: (presetValue, delay = 0, qualityValue = 0) => manager.prime(presetValue, delay, qualityValue),
    warm: async (options = {}, onProgress = null) => await manager.warm(options, onProgress)
  };
}
