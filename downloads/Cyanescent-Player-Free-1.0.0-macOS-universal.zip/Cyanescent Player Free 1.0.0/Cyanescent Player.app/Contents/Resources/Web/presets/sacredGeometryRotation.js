export const SACRED_GEOMETRY_PRESET_ID = 144;

const unit = (value) => Math.max(0, Math.min(1, Number(value) || 0));

// Integrate velocity, rather than scaling an absolute angle: changing musical
// intensity must never move the scene instantly to a different orientation.
export function createSacredGeometryRotation() {
  let lastTime = null, lastBeat = null;
  let scene = 0, fold = 0, speed = 1;
  return {
    step(time, music = {}, audio = {}) {
      const beat = Number.isFinite(music.absoluteBeat) ? music.absoluteBeat : time * 2.4;
      if (lastTime === null || time < lastTime) {
        scene = beat * 0.25 + time * 0.025;
        fold = beat * 0.05 + time * 0.025;
        speed = 1;
        lastTime = time;
        lastBeat = beat;
      }
      const elapsed = time - lastTime;
      const dt = Math.min(0.1, Math.max(0, elapsed));
      const beatDelta = beat - lastBeat;
      // Discard seek jumps and long gaps while keeping the visible angle.
      const db = elapsed <= 0.25 && beatDelta >= 0 && beatDelta <= 1
        ? beatDelta : dt * 2.4;
      const anticipation = unit(music.upcomingDrop);
      const impact = unit(Math.max(music.dropPulse || music.drop || 0, audio.dropDetected || 0));
      const target = (1 - 0.85 * anticipation) * (1 - impact) + 3 * impact;
      const tau = target > speed ? 0.06 : 0.4;
      const decay = Math.exp(-dt / tau);
      // Exact average of the smoothed speed over this frame.
      const average = dt > 0 ? target + (speed - target) * tau * (1 - decay) / dt : speed;
      scene += (db * 0.25 + dt * 0.025) * average;
      fold += (db * 0.05 + dt * 0.025) * average;
      speed = target + (speed - target) * decay;
      lastTime = time;
      lastBeat = beat;
      return [scene, fold, speed, 1];
    }
  };
}

const rotations = new WeakMap();
export function bindSacredGeometryRotation(gl, program, time, music, audio, uniformLocation) {
  let rotation = rotations.get(gl);
  if (!rotation) {
    rotation = createSacredGeometryRotation();
    rotations.set(gl, rotation);
  }
  gl.uniform4f(uniformLocation(gl, program, "sacredRotation"), ...rotation.step(time, music, audio));
}
