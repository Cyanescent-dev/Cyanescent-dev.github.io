// Crystal Resonance (preset 181): the musical director for the twelve Chladni modes.
//
// Schedule: the visual beat follows the analysed beat grid (absoluteBeat). Every 16-beat
// block is split, when it begins, into segments of 2, 4, 8 or 16 beats chosen from the
// musical section at that moment. A segment holds its pattern (resonance) and then morphs
// into the next one in atlas order (transformation); its transition type is chosen when
// the segment starts. Nothing already on screen is ever re-planned, so changes in the
// detected energy cannot cause a jump. Seeks resynchronise to the new beat position.
//
// Resonance: damped oscillators excited by kicks (per-mode frequency), a beat-locked bass
// sway, and bounded mid/high/harmonic excitation with attack/release and adaptive gain.
export const CRYSTAL_RESONANCE_PRESET_ID = 181;
export const CRYSTAL_PATTERNS = 12;
export const CRYSTAL_BLOCK_BEATS = 16;

export const TRANSITION_MORPH = 0;
export const TRANSITION_COLLAPSE = 1;
export const TRANSITION_SHOCK = 2;

const FALLBACK_BPS = 145 / 60;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Number.isFinite(v) ? v : lo));
const clamp01 = (v) => clamp(v, 0, 1);
const smoothstep = (a, b, x) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };
const approach = (value, target, dt, attack, release) => {
  const tau = target > value ? attack : release;
  return value + (target - value) * (1 - Math.exp(-dt / Math.max(1e-4, tau)));
};

// Deterministic [0, 1) hash of an integer and a salt.
export function crystalHash(n, salt = 0) {
  let h = (Math.imul((n | 0) ^ 0x9e3779b9, 0x85ebca6b) ^ Math.imul(salt + 1, 0xc2b2ae35)) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 0x7feb352d) >>> 0;
  h = Math.imul(h ^ (h >>> 15), 0x846ca68b) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

// Block partitions per musical class. 4 and 8 beats dominate, 2-beat segments only appear
// in energetic or anticipatory blocks, 16-beat holds mostly in quiet sections.
export const CRYSTAL_PARTITIONS = {
  quiet: [[[16], 5], [[8, 8], 5], [[8, 4, 4], 1], [[4, 4, 8], 1]],
  flow: [[[8, 8], 5], [[4, 4, 8], 3], [[8, 4, 4], 3], [[4, 8, 4], 2], [[4, 4, 4, 4], 2], [[16], 1]],
  build: [[[8, 4, 4], 3], [[4, 4, 4, 4], 3], [[4, 4, 8], 2], [[8, 4, 2, 2], 2], [[4, 4, 4, 2, 2], 1]],
  peak: [[[4, 4, 8], 3], [[8, 8], 3], [[4, 4, 4, 4], 3], [[8, 4, 4], 2], [[4, 8, 4], 2], [[2, 2, 4, 8], 1], [[4, 4, 2, 2, 4], 1]],
  // the block that leads into a forecast drop accelerates towards it
  approach: [[[8, 4, 2, 2], 3], [[4, 4, 4, 2, 2], 2], [[8, 4, 4], 1]]
};

// Hold / morph splits [hold, morph] per segment length and class.
const SPLITS = {
  2: { any: [[[0, 2], 1]] },
  4: { quiet: [[[0, 4], 2], [[2, 2], 2]], any: [[[0, 4], 2], [[2, 2], 3], [[3, 1], 1]] },
  8: { quiet: [[[4, 4], 3], [[0, 8], 2], [[6, 2], 1]], any: [[[6, 2], 3], [[4, 4], 3], [[0, 8], 1], [[5, 3], 1]] },
  16: { quiet: [[[8, 8], 3], [[12, 4], 2], [[10, 6], 2]], any: [[[12, 4], 3], [[8, 8], 2], [[10, 6], 2]] }
};

function pickWeighted(options, r) {
  const total = options.reduce((sum, [, w]) => sum + w, 0);
  let x = r * total;
  for (const [value, w] of options) { if ((x -= w) < 0) return value; }
  return options[options.length - 1][0];
}

export function classifyCrystalMood({ calm = 0, drive = 0, build = 0, upcomingDrop = 0 } = {}) {
  if (upcomingDrop > 0.6 && calm < 0.7) return "approach";
  if (build > 0.45 && calm < 0.6) return "build";
  if (calm > 0.5 && drive < 0.55) return "quiet";
  if (drive > 0.62) return "peak";
  return "flow";
}

export function createCrystalResonanceDirector() {
  const s = {
    initialised: false, lastTime: 0, lastMusicBeat: NaN, offset: 0, stall: 1e9, bps: FALLBACK_BPS,
    beat: 0, block: null, segIndex: -1, seg: null, serial: 0, pattern: 0,
    lastDramaticSerial: -99, lastDramaticType: -1, dropCount: 0, dropStyles: [], dropLevel: 0, sectionLevel: 0,
    lastEventBeat: -1e9, kickPrev: 0, kickOnsetAt: -1e9, kickX: 0, kickV: 0, kickEnv: 0,
    bassEnv: 0, bassX: 0, midExc: 0, highExc: 0, midPhase: 0, energy: 0, fatigue: 0,
    secondary: 0, tertiary: 0, calm: 0, drive: 0, build: 0, instability: 0, shockAge: -1, morph: 0, blend: 0,
    from: 0, to: 1, type: TRANSITION_MORPH, resyncs: 0, history: []
  };
  const uniforms = {
    crSeg: [0, 1, 0, 0], crClock: [0, FALLBACK_BPS, 0, -1], crOsc: [0, 0, 0, 0],
    crExc: [0, 0, 0, 0], crHarm: [0, 0, 0, 0]
  };

  function mood(input) {
    const music = input.music || {}, audio = input.audio || {};
    const calm = clamp01(Math.max(music.breakdown || 0, (music.calm || 0) * 0.85));
    const drive = clamp01(Math.max((music.highEnergy || 0) * 0.9, music.mainRiff || 0, (audio.globalEnergy || 0) * 0.8));
    const build = clamp01(Math.max(music.buildUp || 0, (music.upcomingDrop || 0) * 0.9));
    return { calm, drive, build, upcomingDrop: clamp01(music.upcomingDrop || 0) };
  }

  function planBlock(blockIndex, input) {
    const m = mood(input);
    const cls = classifyCrystalMood(m);
    // the block before a forecast drop either accelerates into it or, when this drop's
    // style is a collapse, destabilises through its last 8 beats and reforms on the drop
    const collapseIntoDrop = cls === "approach" && dropStyle(s.dropCount + 1) === TRANSITION_COLLAPSE;
    const lengths = collapseIntoDrop ? [4, 4, 8] : pickWeighted(CRYSTAL_PARTITIONS[cls], crystalHash(blockIndex, 11));
    const segs = [];
    let at = blockIndex * CRYSTAL_BLOCK_BEATS;
    lengths.forEach((len, i) => {
      const table = SPLITS[len][cls === "quiet" ? "quiet" : "any"] || SPLITS[len].any;
      const last = i === lengths.length - 1;
      const [hold, morph] = collapseIntoDrop && last ? [6, 2] : pickWeighted(table, crystalHash(blockIndex * 8 + i, 23));
      segs.push({ start: at, len, hold, morph, morphStart: at + hold, morphEnd: at + len, type: TRANSITION_MORPH, cls, collapseIntoDrop: collapseIntoDrop && last });
      at += len;
    });
    return { index: blockIndex, cls, segs };
  }

  // Transition type, chosen when the segment begins from the music at that moment.
  function decideType(seg, input) {
    const m = mood(input);
    const serial = s.serial;
    const sinceDramatic = serial - s.lastDramaticSerial;
    const r = crystalHash(serial, 37);
    const recentEvent = s.beat - s.lastEventBeat < 1.25;
    let type = TRANSITION_MORPH;
    if (recentEvent && seg.len >= 4 && sinceDramatic >= 2 && dropStyle(s.dropCount) === TRANSITION_SHOCK) {
      type = TRANSITION_SHOCK;
    } else if (seg.collapseIntoDrop && sinceDramatic >= 2) {
      // instability builds through the end of the block and reforms on the drop
      type = TRANSITION_COLLAPSE;
    } else if (sinceDramatic >= 2 && seg.len >= 4) {
      // [collapse, shock] probabilities; never two dramatic transitions in a row
      const p = {
        quiet: [0, 0], flow: [0.28, 0.05], build: [0.38, 0.0], approach: [0.3, 0.0], peak: [0.42, 0.11]
      }[seg.cls] || [0, 0];
      const quietScale = 1 - smoothstep(0.45, 0.9, m.calm);
      if (r < p[1] * quietScale && s.lastDramaticType !== TRANSITION_SHOCK) type = TRANSITION_SHOCK;
      else if (r < (p[0] + p[1]) * quietScale) type = TRANSITION_COLLAPSE;
    }
    if (type === TRANSITION_SHOCK) shapeShock(seg, seg.start);
    seg.type = type;
    if (type !== TRANSITION_MORPH) { s.lastDramaticSerial = serial; s.lastDramaticType = type; }
  }

  // Each drop gets one style, never the same as the previous drop's.
  function dropStyle(n) {
    while (s.dropStyles.length <= n) {
      const i = s.dropStyles.length;
      const prev = i ? s.dropStyles[i - 1] : -1;
      const r = crystalHash(i, 53);
      let style = r < 0.45 ? TRANSITION_SHOCK : r < 0.8 ? TRANSITION_COLLAPSE : TRANSITION_MORPH;
      if (style === prev && style !== TRANSITION_MORPH) style = style === TRANSITION_SHOCK ? TRANSITION_COLLAPSE : TRANSITION_SHOCK;
      s.dropStyles.push(style);
    }
    return s.dropStyles[n];
  }

  // A shock morphs first (the transient excites the plate), then holds the new pattern.
  function shapeShock(seg, at) {
    const remaining = seg.start + seg.len - at;
    const morph = remaining >= 8 ? 4 : remaining >= 4 ? 3 : 2;
    seg.morphStart = at;
    seg.morphEnd = at + morph;
  }

  // A drop forecast that appears mid-block re-plans only the segments that have not begun:
  // the rest of the block accelerates into the drop, or destabilises and reforms on it.
  function replanApproachTail(index, input) {
    const block = s.block;
    if (index === 0 || block.cls === "approach" || classifyCrystalMood(mood(input)) !== "approach") return;
    const start = block.segs[index].start;
    const remaining = block.index * CRYSTAL_BLOCK_BEATS + CRYSTAL_BLOCK_BEATS - start;
    const collapse = dropStyle(s.dropCount + 1) === TRANSITION_COLLAPSE;
    const tails = collapse
      ? { 2: [2], 4: [4], 6: [2, 4], 8: [8], 10: [2, 8], 12: [4, 8], 14: [2, 4, 8] }
      : { 2: [2], 4: [2, 2], 6: [2, 2, 2], 8: [4, 2, 2], 10: [4, 2, 2, 2], 12: [4, 4, 2, 2], 14: [4, 4, 2, 2, 2] };
    const lengths = tails[remaining];
    if (!lengths) return;
    let at = start;
    const segs = lengths.map((len, i) => {
      const last = i === lengths.length - 1;
      const [hold, morph] = collapse && last && len >= 4 ? [len - 2, 2] : len === 2 ? [0, 2] : [len / 2, len / 2];
      const seg = { start: at, len, hold, morph, morphStart: at + hold, morphEnd: at + len, type: TRANSITION_MORPH, cls: "approach", collapseIntoDrop: collapse && last && len >= 4 };
      at += len;
      return seg;
    });
    block.segs.splice(index, block.segs.length - index, ...segs);
    block.cls = "approach";
  }

  function enterSegment(index, input) {
    replanApproachTail(index, input);
    const seg = s.block.segs[index];
    s.segIndex = index;
    s.seg = seg;
    seg.from = s.pattern;
    seg.to = (s.pattern + 1) % CRYSTAL_PATTERNS;
    s.serial += 1;
    decideType(seg, input);
    s.history.push({ start: seg.start, len: seg.len, morphStart: seg.morphStart, morphEnd: seg.morphEnd, type: seg.type, from: seg.from, to: seg.to, cls: seg.cls });
    if (s.history.length > 512) s.history.shift();
  }

  function advanceTo(beat, input) {
    const blockIndex = Math.floor(beat / CRYSTAL_BLOCK_BEATS);
    let guard = 0;
    while (guard++ < 64) {
      if (!s.block) {
        s.block = planBlock(blockIndex, input);
        enterSegment(s.block.segs.findIndex((seg) => beat < seg.start + seg.len), input);
        continue;
      }
      const seg = s.seg;
      if (beat < seg.start + seg.len) break;
      s.pattern = seg.to;
      if (s.segIndex + 1 < s.block.segs.length) {
        enterSegment(s.segIndex + 1, input);
      } else {
        s.block = planBlock(s.block.index + 1, input);
        enterSegment(0, input);
      }
    }
  }

  function resync(beat, input, visiblePattern) {
    s.resyncs += 1;
    s.block = null;
    s.pattern = visiblePattern;
    advanceTo(beat, input);
    // never land mid-morph: hold the visible pattern until a morph can start cleanly
    const seg = s.seg;
    if (beat > seg.morphStart) {
      const start = Math.ceil(beat);
      if (seg.start + seg.len - start >= 1) {
        seg.morphStart = start;
        seg.morphEnd = Math.max(start + 1, Math.min(seg.morphEnd, seg.start + seg.len));
        if (seg.type === TRANSITION_SHOCK) seg.type = TRANSITION_MORPH;
      } else {
        seg.to = seg.from;
      }
    }
  }

  // The visual beat follows absoluteBeat plus an offset. The offset absorbs stalls (paused
  // track, no analysis) so the plate keeps moving, and drifts back to the 16-beat phrase grid
  // once the music runs again. A jump in the music beat is a seek: resynchronise.
  function updateClock(dt, input) {
    const mb = Number(input.music?.absoluteBeat);
    const previous = s.lastMusicBeat;
    if (!Number.isFinite(mb)) {
      s.lastMusicBeat = NaN;
      return { beat: s.beat + dt * s.bps, seek: false };
    }
    s.lastMusicBeat = mb;
    if (!Number.isFinite(previous)) {
      s.offset = s.beat - mb;
      return { beat: s.beat, seek: false };
    }
    const d = mb - previous;
    const expected = dt * s.bps;
    if (d < -0.25 || Math.abs(d - expected) > Math.max(1.5, expected * 4)) {
      s.offset = 0;
      return { beat: Math.max(0, mb), seek: true };
    }
    if (d > 1e-5) {
      if (dt > 1e-3) s.bps = clamp(s.bps + (d / dt - s.bps) * (1 - Math.exp(-dt / 2)), 80 / 60, 200 / 60);
      s.stall = 0;
      const home = Math.abs(s.offset) < 8 ? 0 : Math.round(s.offset / CRYSTAL_BLOCK_BEATS) * CRYSTAL_BLOCK_BEATS;
      const diff = home - s.offset;
      const rate = Math.abs(diff) < 1 ? 2 : 0.5;
      s.offset += clamp(diff, -rate * dt, rate * dt);
    } else {
      s.stall += dt;
      s.offset += dt * s.bps;
    }
    return { beat: mb + s.offset, seek: false };
  }

  function updateEvents(input, beat) {
    const music = input.music || {}, audio = input.audio || {};
    const dropLevel = Math.max(music.drop || 0, audio.dropDetected || 0);
    if (dropLevel > 0.5 && s.dropLevel <= 0.5 && beat - s.lastEventBeat > 8) {
      s.dropCount += 1;
      s.lastEventBeat = beat;
      preemptForEvent(beat, input);
    }
    s.dropLevel = dropLevel;
    const section = (music.sectionChange || 0) * smoothstep(0.45, 0.75, music.energyTrend ?? 0.5);
    if (section > 0.65 && s.sectionLevel <= 0.65 && beat - s.lastEventBeat > 8 && (audio.globalEnergy || 0) > 0.45) {
      s.lastEventBeat = beat;
    }
    s.sectionLevel = section;
  }

  // A drop that lands while a pattern is resonating can trigger its shock right away.
  function preemptForEvent(beat, input) {
    const seg = s.seg;
    if (!seg || seg.type !== TRANSITION_MORPH || dropStyle(s.dropCount) !== TRANSITION_SHOCK) return;
    if (s.serial - s.lastDramaticSerial < 2) return;
    const phase = beat - Math.floor(beat);
    const at = phase < 0.35 ? Math.floor(beat) : Math.ceil(beat);
    if (at < seg.start || at + 0.5 > seg.morphStart || seg.start + seg.len - at < 3) return;
    shapeShock(seg, at);
    seg.type = TRANSITION_SHOCK;
    s.lastDramaticSerial = s.serial;
    s.lastDramaticType = TRANSITION_SHOCK;
    const h = s.history[s.history.length - 1];
    if (h) Object.assign(h, { type: seg.type, morphStart: seg.morphStart, morphEnd: seg.morphEnd, preempted: true });
  }

  function updateResonance(dt, input, beat) {
    const audio = input.audio || {}, smooth = input.smooth || {};
    const m = mood(input);
    s.calm = approach(s.calm, m.calm, dt, 0.8, 1.6);
    s.drive = approach(s.drive, m.drive, dt, 0.5, 2.0);
    s.build = approach(s.build, m.build, dt, 0.6, 1.2);
    // adaptive gain: long passages of continuous kick and bass keep headroom
    const kick = clamp01(Math.max(audio.kickPulse || 0, smooth.kick || 0));
    s.fatigue = approach(s.fatigue, clamp01(kick * 0.7 + (smooth.bass || 0) * 0.5), dt, 5, 8);
    const gain = 1 / (1 + 0.9 * s.fatigue);
    // kick: a sharp impulse into a damped oscillator tuned per Chladni mode
    const visible = s.morph > 0.5 ? s.to : s.from;
    const freq = 3.4 + 2.2 * crystalHash(visible, 71);
    const w = 2 * Math.PI * freq, decay = 1 / 0.32;
    if (kick - s.kickPrev > 0.14 && kick > 0.32 && s.lastTime - s.kickOnsetAt > 0.11) {
      s.kickV += kick * w * (0.55 + 0.45 * gain) * (1.6 - 0.6 * Math.min(1, s.kickEnv));
      s.kickOnsetAt = s.lastTime;
      s.energy = Math.min(1.6, s.energy + kick * 0.45 * gain);
    }
    s.kickPrev = kick;
    const steps = Math.max(1, Math.ceil(dt * 240));
    const h = dt / steps;
    for (let i = 0; i < steps; i += 1) {
      s.kickV += (-w * w * s.kickX - 2 * decay * s.kickV) * h;
      s.kickX += s.kickV * h;
    }
    s.kickX = clamp(s.kickX, -1.6, 1.6);
    s.kickV = clamp(s.kickV, -1.6 * w, 1.6 * w);
    s.kickEnv = Math.min(1.6, Math.hypot(s.kickX, s.kickV / w));
    // bass: a slower, beat-locked sway of the whole membrane (one cycle per two beats)
    const bassTarget = clamp01(((smooth.bass || 0) - 0.14) / 0.7) * (0.45 + 0.55 * gain);
    s.bassEnv = approach(s.bassEnv, bassTarget, dt, 0.14, 0.75);
    s.bassX = s.bassEnv * Math.cos(Math.PI * beat);
    // mids excite secondary standing waves, highs a fast shimmer on the nodes
    s.midExc = approach(s.midExc, clamp01(((smooth.mids || 0) - 0.16) / 0.6) * (0.6 + 0.4 * gain), dt, 0.12, 0.65);
    s.highExc = approach(s.highExc, clamp01(((smooth.highs || 0) - 0.14) / 0.6), dt, 0.04, 0.28);
    s.midPhase = (s.midPhase + dt * 2 * Math.PI * (0.8 + 1.2 * s.midExc)) % (Math.PI * 200);
    s.energy *= Math.exp(-dt / 0.65);
    // harmonic complexity: revealed by activity, bounded, and slower than the excitation
    const secondaryTarget = clamp01(0.06 + 0.5 * s.midExc + 0.28 * Math.min(1, s.energy) + 0.3 * s.build + 0.18 * s.drive - 0.2 * s.calm + 0.5 * s.instability);
    const tertiaryTarget = clamp01((secondaryTarget - 0.42) * 1.5 + 0.35 * s.highExc * s.drive + 0.6 * s.instability);
    s.secondary = approach(s.secondary, secondaryTarget, dt, 0.35, 1.4);
    s.tertiary = approach(s.tertiary, tertiaryTarget, dt, 0.3, 1.2);
  }

  function updateSegmentState(beat) {
    const seg = s.seg;
    s.from = seg.from;
    s.to = seg.to;
    s.type = seg.type;
    const window = Math.max(1e-3, seg.morphEnd - seg.morphStart);
    s.morph = seg.to === seg.from ? 0 : clamp01((beat - seg.morphStart) / window);
    // eased field blend: long morphs linger at both ends, short ones stay fluid
    if (seg.type === TRANSITION_COLLAPSE) s.blend = smoothstep(0.2, 0.86, s.morph);
    else if (seg.type === TRANSITION_SHOCK) s.blend = smoothstep(0.06, 0.94, s.morph);
    else if (window <= 2) s.blend = smoothstep(0, 1, s.morph);
    else {
      const x = smoothstep(0.04, 1, s.morph);
      s.blend = x * x * x * (x * (x * 6 - 15) + 10);
    }
    s.instability = 0;
    s.shockAge = -1;
    if (seg.type === TRANSITION_COLLAPSE) {
      // destabilise through the end of the hold (or the first part of a continuous morph),
      // then reorganise into the next mode
      const lead = Math.min(seg.morphStart - seg.start, 4);
      const rise = lead >= 1 ? smoothstep(seg.morphStart - lead, seg.morphStart, beat) : smoothstep(0, 0.3, s.morph);
      s.instability = rise * (1 - smoothstep(0.4, 1, s.morph));
    } else if (seg.type === TRANSITION_SHOCK && beat >= seg.morphStart) {
      s.shockAge = beat - seg.morphStart;
      if (!seg.shockFired) {
        seg.shockFired = true;
        s.kickV += 2 * Math.PI * 4 * 1.1;   // the transient strikes the plate
        s.energy = Math.min(1.6, s.energy + 0.6);
      }
    }
  }

  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) {
      Object.assign(s, createCrystalResonanceDirector().state, { initialised: true, lastTime: time });
      const mb = Number(input.music?.absoluteBeat);
      s.lastMusicBeat = Number.isFinite(mb) ? mb : NaN;
      s.beat = Number.isFinite(mb) ? Math.max(0, mb) : 0;
      // deterministic entry pattern from the beat position
      s.pattern = (Math.floor(s.beat / CRYSTAL_BLOCK_BEATS) * 5) % CRYSTAL_PATTERNS;
      advanceTo(s.beat, input);
    }
    const dt = clamp(time - s.lastTime, 0, 0.1);
    s.lastTime = time;
    const { beat, seek } = updateClock(dt, input);
    if (seek) {
      const visible = s.morph > 0.5 ? s.to : s.from;
      s.beat = beat;
      resync(beat, input, visible);
    } else {
      s.beat = Math.max(s.beat, beat);   // never runs backwards
      updateEvents(input, s.beat);      // an event on a segment boundary informs that segment
      advanceTo(s.beat, input);
    }
    updateSegmentState(s.beat);
    updateResonance(dt, input, s.beat);
    uniforms.crSeg = [s.from, s.to, s.blend, s.type];
    uniforms.crClock = [s.beat, s.bps, s.instability, s.shockAge];
    uniforms.crOsc = [s.kickX, s.kickEnv, s.bassX, s.bassEnv];
    uniforms.crExc = [s.midExc, s.highExc, Math.min(1, s.energy), s.midPhase];
    uniforms.crHarm = [s.secondary, s.tertiary, s.calm, s.drive];
    return s;
  }

  return { state: s, step, uniforms: () => uniforms };
}

const cache = new WeakMap();

export function bindCrystalResonanceDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime) {
    runtime = { director: createCrystalResonanceDirector(), lastTime: -1 };
    cache.set(gl, runtime);
  }
  const director = opts.director || runtime.director;
  // a frame drawn twice at the same time (transition, re-render) reuses the state
  if (time !== runtime.lastTime || opts.director) {
    director.step(time, input);
    runtime.lastTime = time;
  }
  const loc = (name) => uniformLocation(gl, program, name);
  gl.uniform1f(loc("crDir"), 1);
  for (const [name, value] of Object.entries(director.uniforms())) gl.uniform4f(loc(name), value[0], value[1], value[2], value[3]);
  return director;
}
