export function createRedCageStinkhornPresetShaderEntries({
  modularShaderPrelude, modularTransitionShaderBlock
}) {
  const PRESET_ID = "red-cage-stinkhorn";
  const source = `${modularShaderPrelude}
${modularTransitionShaderBlock}

const float rcrTau = 6.28318530718;
const float rcrSector = 1.25663706144;

vec3 rcrJoints[90];
vec3 rcrBoundsLo[15];
vec3 rcrBoundsHi[15];
vec3 rcrOrigins[4];
float rcrSizes[4];
float rcrAges[4];
float rcrSplits[4];
bool rcrVisible[4];

float rcrClock;
float rcrBass;
float rcrMid;
float rcrHigh;
float rcrEnergy;
float rcrKick;
float rcrInside;
vec3 rcrCameraEye;

float rcrRandom(float n) {
  return fract(sin(n * 127.137 + 19.713) * 43758.5453);
}

float rcrHash3(vec3 p) {
  p = fract(p * 0.1031);
  p += dot(p, p.yzx + 33.33);
  return fract((p.x + p.y) * p.z);
}

vec4 rcrNoiseGradient(vec3 p) {
  vec3 i = floor(p);
  vec3 f = fract(p);
  vec3 u = f * f * (3.0 - 2.0 * f);
  vec3 du = 6.0 * f * (1.0 - f);

  float a = rcrHash3(i);
  float b = rcrHash3(i + vec3(1.0, 0.0, 0.0));
  float c = rcrHash3(i + vec3(0.0, 1.0, 0.0));
  float d = rcrHash3(i + vec3(1.0, 1.0, 0.0));
  float e = rcrHash3(i + vec3(0.0, 0.0, 1.0));
  float f1 = rcrHash3(i + vec3(1.0, 0.0, 1.0));
  float g = rcrHash3(i + vec3(0.0, 1.0, 1.0));
  float h = rcrHash3(i + vec3(1.0, 1.0, 1.0));

  float z0 = mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
  float z1 = mix(mix(e, f1, u.x), mix(g, h, u.x), u.y);
  float dx = mix(
    mix(b - a, d - c, u.y),
    mix(f1 - e, h - g, u.y), u.z
  ) * du.x;
  float dy = mix(
    mix(c - a, d - b, u.x),
    mix(g - e, h - f1, u.x), u.z
  ) * du.y;
  float dz = (z1 - z0) * du.z;
  return vec4(mix(z0, z1, u.z), dx, dy, dz);
}

float rcrNoise3(vec3 p) {
  return rcrNoiseGradient(p).x;
}

mat2 rcrTurn(float a) {
  float c = cos(a);
  float s = sin(a);
  return mat2(c, s, -s, c);
}

vec3 rcrSafeNormal(vec3 p) {
  return p * inversesqrt(max(dot(p, p), 1e-12));
}

float rcrBox(vec3 p, vec3 b) {
  vec3 q = abs(p) - b;
  return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float rcrBoundsDistance(vec3 p, vec3 lo, vec3 hi) {
  return rcrBox(p - 0.5 * (lo + hi), 0.5 * (hi - lo));
}

float rcrSmoothMinimum(float a, float b, float k) {
  float h = max(k - abs(a - b), 0.0) / k;
  return min(a, b) - h * h * k * 0.25;
}

float rcrInverse(float x) {
  if (x < 0.0) return -1.0 / max(-x, 0.00001);
  return 1.0 / max(x, 0.00001);
}

bool rcrRayBounds(vec3 ro, vec3 rd, vec3 lo, vec3 hi) {
  vec3 inv = vec3(rcrInverse(rd.x), rcrInverse(rd.y), rcrInverse(rd.z));
  vec3 a = (lo - ro) * inv;
  vec3 b = (hi - ro) * inv;
  vec3 mn = min(a, b);
  vec3 mx = max(a, b);
  float nearT = max(mn.x, max(mn.y, mn.z));
  float farT = min(mx.x, min(mx.y, mx.z));
  return farT >= max(nearT, 0.0);
}

vec3 rcrLocal(vec3 p, int organism) {
  p = (p - rcrOrigins[organism]) / rcrSizes[organism];
  p.xz = rcrTurn(float(organism) * 0.73) * p.xz;
  return p;
}

vec3 rcrWorld(vec3 p, int organism) {
  p.xz = rcrTurn(-float(organism) * 0.73) * p.xz;
  return p * rcrSizes[organism] + rcrOrigins[organism];
}

float rcrImpulse(float y, float angle) {
  float path = max(y - 0.13, 0.0) * 0.93
    + 0.18 * (1.0 - cos(angle - 0.63));
  float front = (1.0 - rcrKick) * 1.72;
  float d = path - front;
  return exp(-74.0 * d * d) * sqrt(rcrKick);
}

// Five basal buttresses connect staggered, non-coplanar courses.
// Their connections form large basal pentagons, lateral hexagons,
// smaller crown pentagons, and one irregular apical opening.
vec3 rcrJoint(int organism, int sector, int kind) {
  float fi = float(sector);
  float fk = float(kind);
  float seed = fi * 17.0 + fk * 31.0 + float(organism) * 113.0;
  float angle = fi * rcrSector;
  float radius = 0.35;
  float height = 0.16;

  if (kind == 1) {
    radius = 0.625;
    height = 0.605;
  } else if (kind == 2) {
    angle += 0.5 * rcrSector;
    radius = 0.715;
    height = 0.865;
  } else if (kind == 3) {
    angle += 0.5 * rcrSector;
    radius = 0.575;
    height = 1.115;
  } else if (kind == 4) {
    radius = 0.465;
    height = 1.290;
  } else if (kind == 5) {
    radius = 0.245;
    height = 1.455;
  }

  angle += (rcrRandom(seed + 3.0) - 0.5) * 0.19;
  radius *= 0.92 + 0.16 * rcrRandom(seed + 7.0);
  height += (rcrRandom(seed + 13.0) - 0.5)
    * (0.045 + 0.08 * step(0.5, fk));

  float age = rcrAges[organism];
  float hn = clamp((height - 0.14) / 1.34, 0.0, 1.0);
  float rise = smoothstep(0.15, 0.77, age);
  float unfold = smoothstep(0.19 + hn * 0.10, 0.73 + hn * 0.21, age);
  float inflate = smoothstep(0.28, 0.94, age);

  float foldedRadius = 0.12 + 0.105 * sin(hn * 3.14159265)
    + 0.028 * rcrRandom(seed + 23.0);
  float foldedHeight = 0.17 + 0.185 * hn
    + 0.024 * sin(angle * 2.0 + fk * 1.7);

  float r = mix(foldedRadius, radius, unfold);
  float y = mix(foldedHeight, height, rise);

  r += 0.053 * sin(rise * 3.14159265) * (1.0 - unfold)
    * cos(fk * 1.9 + angle);
  y += 0.060 * sin(unfold * 3.14159265)
    * sin(angle * 2.0 + fk * 1.3);
  angle += (1.0 - unfold)
    * (0.43 * sin(hn * 4.3) + 0.19 * cos(angle * 2.0 + hn * 6.8));

  // Keep the mature cage architecturally stable.  Music response belongs to
  // the interior wall illumination rather than deforming/pumping the red ribs.
  // Growth/unfolding still follows the developmental state above.

  return vec3(cos(angle) * r, y, sin(angle) * r);
}

void rcrBuildPlant(int organism) {
  int base = organism * 30;
  for (int i = 0; i < 5; ++i) {
    for (int k = 0; k < 6; ++k) {
      rcrJoints[base + i * 6 + k] = rcrJoint(organism, i, k);
    }
  }

  for (int i = 0; i < 5; ++i) {
    int a = base + i * 6;
    int b = base + ((i + 1) % 5) * 6;
    vec3 lo = min(rcrJoints[a], rcrJoints[b]);
    vec3 hi = max(rcrJoints[a], rcrJoints[b]);

    for (int k = 1; k < 6; ++k) {
      lo = min(lo, rcrJoints[a + k]);
      hi = max(hi, rcrJoints[a + k]);
    }
    lo = min(lo, min(rcrJoints[b + 1], min(rcrJoints[b + 4], rcrJoints[b + 5])));
    hi = max(hi, max(rcrJoints[b + 1], max(rcrJoints[b + 4], rcrJoints[b + 5])));

    rcrBoundsLo[organism * 5 + i] = lo - vec3(0.185);
    rcrBoundsHi[organism * 5 + i] = hi + vec3(0.185);
  }
}

void rcrRib(
  vec3 p, vec3 a, vec3 b, float seed, float age,
  inout vec2 nearest
) {
  float verticalBound = max(min(a.y, b.y) - p.y, p.y - max(a.y, b.y)) - 0.18;
  if (verticalBound > nearest.x + 0.02) return;

  vec3 ab = b - a;
  float lengthSquared = max(dot(ab, ab), 0.00001);
  vec3 middle = (a + b) * 0.5;
  vec3 outward = rcrSafeNormal(vec3(middle.x, (middle.y - 0.75) * 0.42, middle.z));
  float bowAmount = 0.021 + 0.021 * rcrRandom(seed + 4.0);
  bowAmount += 0.012 * (1.0 - smoothstep(0.35, 0.95, age));
  vec3 bow = outward * bowAmount;
  bow.y += 0.011 * sin(seed * 2.1);

  float h = clamp(dot(p - a, ab) / lengthSquared, 0.0, 1.0);
  vec3 curve = a + ab * h + bow * (4.0 * h * (1.0 - h));
  vec3 tangent = ab + bow * (4.0 - 8.0 * h);
  vec3 delta = p - curve;
  float denominator = max(
    dot(tangent, tangent) + 8.0 * dot(delta, bow),
    lengthSquared * 0.15
  );
  h = clamp(h + dot(delta, tangent) / denominator, 0.0, 1.0);
  curve = a + ab * h + bow * (4.0 * h * (1.0 - h));
  delta = p - curve;

  float radius = 0.055 + 0.011 * (1.0 - clamp(curve.y / 1.5, 0.0, 1.0));
  radius += 0.007 * rcrRandom(seed + 11.0);
  radius *= 0.72 + 0.28 * smoothstep(0.18, 0.9, age);
  radius *= 1.0 + 0.12 * pow(abs(2.0 * h - 1.0), 4.0);

  vec3 radial = rcrSafeNormal(vec3(curve.x, (curve.y - 0.72) * 0.72, curve.z));
  float inward = smoothstep(0.05, 0.65, -dot(rcrSafeNormal(delta), radial));
  float sticky = 0.5 + 0.5 * sin(curve.y * 23.0 + seed)
    * sin(curve.x * 19.0 + curve.z * 17.0 + seed * 0.4);
  radius += 0.005 * inward * smoothstep(0.42, 0.72, sticky);

  float d = length(delta) - radius;
  if (d < nearest.x) nearest.y = seed;
  nearest.x = rcrSmoothMinimum(nearest.x, d, 0.016);
}

vec2 rcrCage(vec3 p, int organism) {
  vec2 nearest = vec2(100.0, 0.0);
  float angle = atan(p.z, p.x);
  int first = int(floor((angle + rcrTau) / rcrSector)) % 5;
  int base = organism * 30;
  float age = rcrAges[organism];

  for (int search = 0; search < 5; ++search) {
    // Always evaluate all five angular sectors for the hero. The previous
    // three-sector standard-quality shortcut could drop back-facing ribs at
    // some view angles and make the lattice look physically broken. Standard
    // mode now saves more work elsewhere instead.
    int offset = 0;
    if (search == 1) offset = 1;
    else if (search == 2) offset = 4;
    else if (search == 3) offset = 2;
    else if (search == 4) offset = 3;

    int i = (first + offset) % 5;
    int boundsIndex = organism * 5 + i;
    float bound = rcrBoundsDistance(p, rcrBoundsLo[boundsIndex], rcrBoundsHi[boundsIndex]);
    if (bound > nearest.x + 0.02) continue;

    int a = base + i * 6;
    int b = base + ((i + 1) % 5) * 6;
    float seed = float(i * 9 + organism * 47);

    rcrRib(p, rcrJoints[a],     rcrJoints[b],     seed,       age, nearest);
    rcrRib(p, rcrJoints[a],     rcrJoints[a + 1], seed + 1.0, age, nearest);
    rcrRib(p, rcrJoints[a + 1], rcrJoints[a + 2], seed + 2.0, age, nearest);
    rcrRib(p, rcrJoints[a + 2], rcrJoints[b + 1], seed + 3.0, age, nearest);
    rcrRib(p, rcrJoints[a + 2], rcrJoints[a + 3], seed + 4.0, age, nearest);
    rcrRib(p, rcrJoints[a + 3], rcrJoints[a + 4], seed + 5.0, age, nearest);
    rcrRib(p, rcrJoints[a + 3], rcrJoints[b + 4], seed + 6.0, age, nearest);
    rcrRib(p, rcrJoints[a + 4], rcrJoints[a + 5], seed + 7.0, age, nearest);
    rcrRib(p, rcrJoints[a + 5], rcrJoints[b + 5], seed + 8.0, age, nearest);
  }
  return nearest;
}

float rcrEggShell(vec3 p, float pressure) {
  vec3 radii = vec3(0.347, 0.402, 0.347);
  radii *= 1.0 + pressure * 0.016;
  vec3 q = p - vec3(0.0, 0.306, 0.0);
  float k0 = length(q / radii);
  float k1 = length(q / (radii * radii));
  float ellipsoid = k0 * (k0 - 1.0) / max(k1, 0.00001);
  return abs(ellipsoid) - 0.019;
}

// The original egg shell separates into hinged, curling, crumpled pieces.
// The basal cup remains physically present throughout emergence.
float rcrVolva(vec3 p, int organism) {
  float split = rcrSplits[organism];
  float pressure = rcrBass * (1.0 - split)
    * (0.7 + 0.3 * sin(rcrClock * 1.5));
  float shell = rcrEggShell(p, pressure);
  if (split < 0.001) return shell;

  // Standard quality uses a cheap continuous five-lobed opening instead of
  // hard-switching from the intact egg to a basal cup.  The previous hard
  // branch at split>0.34 made the shell visibly disappear in one frame.
  // Here the top edge descends smoothly while five broad lobes remain higher,
  // giving the impression of the egg peeling/unfurling without the expensive
  // transformed-petal SDF used in high quality.
  if (quality <= 0.5) {
    float thetaFast = atan(p.z, p.x);
    float openFast = smoothstep(0.08, 0.86, split);
    float petalFast = pow(max(0.0, 0.5 + 0.5 * cos(thetaFast * 5.0 + 0.7)), 0.72);
    float intactTop = 0.705 + 0.010 * sin(thetaFast * 3.0);
    float tornCup = 0.188
      + 0.026 * sin(thetaFast * 5.0 + 0.7)
      + 0.008 * sin(thetaFast * 10.0 - 0.4);
    float lobeTop = tornCup + 0.145 * petalFast * (1.0 - 0.42 * openFast);
    float rimFast = mix(intactTop, lobeTop, openFast);
    float cup = max(shell, p.y - rimFast);
    return cup;
  }

  float theta = atan(p.z, p.x);
  float rim = 0.203 + 0.018 * sin(theta * 5.0 + 0.7)
    + 0.012 * sin(theta * 11.0);
  float d = max(shell, p.y - rim);

  for (int i = 0; i < 5; ++i) {
    float angle = float(i) * rcrSector;
    vec2 radial = vec2(cos(angle), sin(angle));
    vec2 sideways = vec2(-radial.y, radial.x);
    vec3 q = vec3(dot(p.xz, radial), p.y, dot(p.xz, sideways));

    float seed = float(i + organism * 7);
    // Keep the ruptured volva as a handful of broad, attached fleshy lobes.
    // The original version over-rotated and over-crumpled these pieces, which
    // could read as disconnected triangular shards after eruption.
    float opening = split * (1.24 + 0.16 * rcrRandom(seed + 52.0));
    float crumple = 1.0 - 0.24 * split * split;
    vec2 hinge = vec2(0.292, 0.195);
    q.xy = rcrTurn(opening) * (q.xy - hinge) / crumple + hinge;
    q.z /= crumple;

    float tear = 0.0028 * split
      * (sin(q.y * 23.0 + seed) + 0.45 * sin(q.y * 47.0 - seed));
    float wedge = abs(q.z) * 0.80901699 - q.x * 0.58778525
      + split * 0.006 + tear;
    float lowerCut = 0.194 + 0.010 * sin(q.z * 19.0 + seed) - q.y;
    float piece = max(rcrEggShell(q, pressure), max(wedge, lowerCut));
    d = rcrSmoothMinimum(d, piece * crumple, 0.008);
  }
  return d;
}

vec4 rcrPlant(vec3 worldPosition, int organism) {
  vec3 p = rcrLocal(worldPosition, organism);
  float shell = rcrVolva(p, organism);
  vec4 result = vec4(shell, 2.0, float(organism), 0.0);

  if (organism < 3 && rcrAges[organism] > 0.085) {
    vec2 cage = rcrCage(p, organism);
    if (cage.x < result.x) result = vec4(cage.x, 1.0, float(organism), cage.y);
  }
  result.x *= rcrSizes[organism];
  return result;
}

float rcrSoilHeight(vec2 p) {
  return 0.012 * noise(p * 5.2)
    + 0.006 * noise(p * 18.0) - 0.010;
}

vec4 rcrGround(vec3 p) {
  if (p.y > 0.20) return vec4(p.y - 0.105, 3.0, -1.0, 0.0);

  float ground = p.y - rcrSoilHeight(p.xz);
  vec4 result = vec4(ground, 3.0, -1.0, 0.0);

  // The old floor built four raymarched sticks/leaves for EVERY ground SDF
  // query.  Ground is queried by the marcher, normals and AO, making that one
  // of the dominant costs in standard quality and causing noisy/broken detail
  // toward the horizon.  Standard quality now uses a clean heightfield and
  // gets its debris appearance from shading instead of geometry.
  if (quality <= 0.5) return result;

  // Even in high quality, detailed debris is only useful around the hero.
  // Beyond this radius it becomes subpixel and aliases at the back of scene.
  if (length(p.xz) > 2.75) return result;

  float spacing = 0.345;
  vec2 cell = floor(p.xz / spacing);
  vec2 fraction = fract(p.xz / spacing);
  vec2 direction = mix(vec2(-1.0), vec2(1.0), step(vec2(0.5), fraction));

  for (int i = 0; i < 4; ++i) {
    vec2 offset = vec2(float(i % 2), float(i / 2)) * direction;
    vec2 id = cell + offset;
    float seed = rcrHash3(vec3(id, 8.31));
    vec2 jitter = vec2(
      rcrHash3(vec3(id, 21.7)),
      rcrHash3(vec3(id, 43.2))
    ) - 0.5;
    vec2 center = (id + 0.5) * spacing + jitter * 0.090;
    vec3 q = p - vec3(center.x, 0.018, center.y);
    q.xz = rcrTurn(seed * rcrTau) * q.xz;
    q.y -= (seed - 0.5) * q.x * 0.22;

    float d;
    float material;
    if (seed < 0.56) {
      vec3 dimensions = vec3(
        0.082 + 0.075 * rcrRandom(seed * 97.0),
        0.010 + 0.010 * seed,
        0.022 + 0.028 * rcrRandom(seed * 173.0)
      );
      d = rcrBox(q, dimensions) - 0.005;
      material = 5.0;
    } else {
      float lensA = length(q.xz - vec2(0.0, 0.16)) - 0.207;
      float lensB = length(q.xz + vec2(0.0, 0.16)) - 0.207;
      float surface = 0.012 * cos(q.x * 14.0) + 0.15 * abs(q.z);
      d = max(max(lensA, lensB), abs(q.y - surface) - 0.004);
      material = 4.0;
    }
    if (d < result.x) result = vec4(d, material, -1.0, seed);
  }
  return result;
}

vec4 rcrScene(vec3 p) {
  // During the upward-looking cathedral sequence the floor is behind the
  // camera and cannot contribute.  Avoid evaluating it at every march step.
  // Keep the cheap ground present through almost the entire entry move.
  // Dropping it at rcrInside>0.62 exposed holes while the camera could still
  // see the floor beneath/behind the cage. Only skip it once the camera is
  // genuinely deep inside and looking upward.
  vec4 result = rcrInside > 0.94
    ? vec4(20.0, 3.0, -1.0, 0.0)
    : rcrGround(p);
  for (int i = 0; i < 4; ++i) {
    if (!rcrVisible[i]) continue;
    vec3 q = rcrLocal(p, i);
    float bound = rcrBox(q - vec3(0.0, 0.73, 0.0), vec3(0.93, 0.91, 0.93))
      * rcrSizes[i];
    if (bound > result.x + 0.008) continue;
    vec4 plant = rcrPlant(p, i);
    if (plant.x < result.x) result = plant;
  }
  return result;
}

float rcrSurfaceDistance(vec3 p, vec4 hit) {
  if (hit.z >= 0.0) return rcrPlant(p, int(hit.z + 0.1)).x;
  return rcrGround(p).x;
}

vec3 rcrNormal(vec3 p, vec4 hit, float epsilon) {
  vec3 a = vec3(1.0, -1.0, -1.0);
  vec3 b = vec3(-1.0, -1.0, 1.0);
  vec3 c = vec3(-1.0, 1.0, -1.0);
  vec3 d = vec3(1.0, 1.0, 1.0);
  return rcrSafeNormal(
    a * rcrSurfaceDistance(p + a * epsilon, hit)
    + b * rcrSurfaceDistance(p + b * epsilon, hit)
    + c * rcrSurfaceDistance(p + c * epsilon, hit)
    + d * rcrSurfaceDistance(p + d * epsilon, hit)
  );
}

vec4 rcrMarch(vec3 ro, vec3 rd, out float travel) {
  travel = 0.002;
  vec4 hit = vec4(1.0, -1.0, -1.0, 0.0);
  int budget = 46;
  if (quality > 0.5) budget = 80;

  float marchScale = quality > 0.5 ? 0.73 : 0.84;
  float minStep = quality > 0.5 ? 0.00018 : 0.00034;
  float epsilonBase = quality > 0.5 ? 0.00038 : 0.00056;
  float epsilonSlope = quality > 0.5 ? 0.00023 : 0.00032;

  for (int i = 0; i < 80; ++i) {
    if (i >= budget || travel > 11.0) break;
    vec4 sampleValue = rcrScene(ro + rd * travel);
    float epsilon = max(epsilonBase, travel * epsilonSlope);
    if (sampleValue.x < epsilon) {
      hit = sampleValue;
      break;
    }
    travel += max(sampleValue.x * marchScale, minStep);
  }
  return hit;
}

float rcrAmbientOcclusion(vec3 p, vec3 n, vec4 hit) {
  float a = rcrSurfaceDistance(p + n * 0.040, hit);
  if (quality <= 0.5) {
    return clamp(1.0 - 3.2 * max(0.040 - a, 0.0), 0.42, 1.0);
  }
  float b = rcrSurfaceDistance(p + n * 0.105, hit);
  return clamp(1.0 - 3.4 * max(0.040 - a, 0.0)
    - 2.0 * max(0.105 - b, 0.0), 0.35, 1.0);
}

float rcrSelfShadow(vec3 p, vec3 light, int organism) {
  float shade = 1.0;
  float distanceAlong = 0.018;
  for (int i = 0; i < 10; ++i) {
    float d = rcrPlant(p + light * distanceAlong, organism).x;
    if (d < 0.0008) return 0.20;
    shade = min(shade, 11.0 * d / max(distanceAlong, 0.01));
    distanceAlong += clamp(d * 0.82, 0.018, 0.16);
    if (distanceAlong > 0.85) break;
  }
  return clamp(shade, 0.20, 1.0);
}



float rcrExteriorLanePhase(float laneId) {
  // Keep every route tempo-locked, but stagger launches into four beat slots
  // with a tiny fixed per-lane offset. This avoids the robotic "all lanes fire
  // at once" look while remaining musically coherent.
  float seed = rcrRandom(laneId * 29.0 + 3.7);
  float slot = floor(seed * 4.0);
  float humanOffset = (rcrRandom(laneId * 43.0 + 17.0) - 0.5) * 0.055;
  return fract(beatPhase + slot * 0.25 + humanOffset);
}

vec3 rcrFloorSignal(vec3 p) {
  // One continuous exterior signal path: it begins at the hero stinkhorn,
  // crosses essentially the entire visible floor as fine cymatic/mycelial
  // threads, then hands the same lane/phase to the vertical wall pulse.
  vec2 d = p.xz - rcrOrigins[0].xz;
  float r = length(d);
  if (r < 0.20 || r > 41.0) return vec3(0.0);

  float az = atan(d.y, d.x);
  float laneId = floor((az + 3.14159265) * 11.0 / rcrTau);
  float localPhase = rcrExteriorLanePhase(laneId);

  // The lane identity is based on the unwarped azimuth so it remains the same
  // from fungus to horizon. Only the drawn thread meanders gently.
  float warpedAz = az
    + 0.040 * sin(r * 1.55 + az * 2.0)
    + 0.018 * sin(r * 3.7 - az * 3.0);
  // Let the strand meander near the fungus, but straighten it back onto its
  // canonical lane as it approaches the horizon.  This guarantees that the
  // floor strand arrives at exactly the same azimuth used by the wall lane.
  float horizonStraighten = smoothstep(22.0, 35.0, r);
  warpedAz = mix(warpedAz, az, horizonStraighten);

  float primary = pow(max(0.0, 0.5 + 0.5 * cos(warpedAz * 11.0)), 82.0);
  float secondary = pow(max(0.0, 0.5 + 0.5 * cos(warpedAz * 17.0 + 1.15)), 112.0) * 0.20;
  float threads = max(primary, secondary);

  float laneGate = smoothstep(0.16, 0.70, rcrRandom(laneId * 17.0 + 5.0));

  // About 62% of each lane's staggered beat cycle is spent crossing the floor.
  // The front reaches the far floor/horizon before the matching wall pulse
  // begins, so the two read as one travelling signal rather than two effects.
  const float floorEnd = 0.62;
  float floorProgress = clamp(localPhase / floorEnd, 0.0, 1.0);
  float floorActive = 1.0 - smoothstep(floorEnd - 0.025, floorEnd + 0.020, localPhase);
  float frontR = mix(0.28, 37.0, floorProgress);
  float headWidth = mix(0.10, 0.22, smoothstep(0.0, 37.0, r));
  float head = exp(-0.5 * pow((r - frontR) / headWidth, 2.0)) * floorActive;

  // Keep a very fine mycelial route visible all the way to the wall, not just
  // halfway across the floor. The actual moving packet stays much brighter.
  float farFade = 1.0 - smoothstep(37.0, 41.0, r);
  float backbone = threads * laneGate * farFade
    * (0.022 + 0.018 * rcrBass + 0.010 * rcrHigh);

  // A short wake behind the packet suggests propagation but does not make the
  // whole strand flash. It also preserves the nice existing mycelial look.
  float wake = smoothstep(0.24, 0.50, r)
    * (1.0 - smoothstep(frontR - 0.20, frontR + 0.05, r))
    * floorActive;

  float nodes = 0.78 + 0.22 * (0.5 + 0.5 * sin(r * 4.5 - az * 2.0));
  float moving = threads * laneGate * nodes * farFade
    * (head * (0.66 + 0.56 * rcrEnergy + 0.18 * rcrKick)
       + wake * 0.040 * (0.35 + 0.65 * rcrBass));

  float intensity = backbone + moving;
  intensity *= smoothstep(0.24, 0.42, r);
  return vec3(0.91, 0.96, 1.0) * intensity * 0.92;
}

vec3 rcrExteriorCathedralPulses(vec3 rd) {
  // Exterior wall signal: fine mycelial strands rooted at the actual visible
  // floor/wall seam, with compact packets travelling upward along them.  Keep
  // the background filament itself crisp and dim; the moving packet provides
  // the musical emphasis. This replaces the previous broad/foggy searchlight
  // appearance.
  const float farFloorDistance = 42.0;
  const float farGroundY = -0.008;
  float seamY = (farGroundY - rcrCameraEye.y) / farFloorDistance;

  float wallTopY = 0.74;
  float wallV = clamp((rd.y - seamY) / max(wallTopY - seamY, 0.05), 0.0, 1.0);
  float wallMask = smoothstep(seamY - 0.0060, seamY + 0.0005, rd.y)
    * (1.0 - smoothstep(0.70, 0.78, rd.y));

  vec3 seamPoint = rcrCameraEye + rd * farFloorDistance;
  vec2 seamDelta = seamPoint.xz - rcrOrigins[0].xz;
  float az = atan(seamDelta.y, seamDelta.x);
  float laneId = floor((az + 3.14159265) * 11.0 / rcrTau);
  float localPhase = rcrExteriorLanePhase(laneId);

  // Tiny organic wander, explicitly zero at the seam so the floor strand and
  // wall strand physically meet. The line then remains almost vertical.
  float drift = wallV * (
      0.00080 * sin(wallV * 8.0 + az * 2.0)
    + 0.00045 * sin(wallV * 17.0 - az * 1.2)
  );
  float laneAz = az + drift;

  // Screen-derivative AA keeps the strands about a pixel wide instead of
  // becoming thick fuzzy columns at low render scale. This costs no extra rays.
  float laneCoord = laneAz * 11.0 / rcrTau;
  float laneDist = abs(fract(laneCoord + 0.5) - 0.5);
  float laneAA = max(fwidth(laneCoord), 0.0012);
  float primary = 1.0 - smoothstep(0.0045 + laneAA * 0.55,
                                   0.0100 + laneAA * 1.15, laneDist);

  float secondaryCoord = laneAz * 17.0 / rcrTau + 0.183;
  float secondaryDist = abs(fract(secondaryCoord + 0.5) - 0.5);
  float secondaryAA = max(fwidth(secondaryCoord), 0.0012);
  float secondary = (1.0 - smoothstep(0.0035 + secondaryAA * 0.50,
                                      0.0080 + secondaryAA * 1.10, secondaryDist)) * 0.12;

  float channels = max(primary, secondary) * wallMask;
  float laneGate = smoothstep(0.16, 0.70, rcrRandom(laneId * 17.0 + 5.0));

  const float wallStart = 0.62;
  float wallProgress = clamp((localPhase - wallStart) / (1.0 - wallStart), 0.0, 1.0);
  float wallActive = smoothstep(wallStart - 0.018, wallStart + 0.018, localPhase)
    * (1.0 - smoothstep(0.975, 0.998, localPhase));
  float pulseCenter = wallProgress * 1.01;
  float pulseWidth = mix(0.0100, 0.0065, clamp(rcrEnergy, 0.0, 1.0));
  float head = exp(-0.5 * pow((wallV - pulseCenter) / pulseWidth, 2.0));

  // Keep the route visible from the floor upward, but much dimmer than the
  // packet. This reads as a mycelial strand carrying a pulse, not a searchlight.
  float strand = channels * laneGate * (0.026 + 0.016 * rcrHigh);
  float packet = channels * laneGate * wallActive * head
    * (0.78 + 0.48 * rcrEnergy + 0.10 * rcrKick);

  // Very small seam anchor only to guarantee an unbroken connection with the
  // horizontal floor thread. It must not bloom into a foggy base.
  float seamAnchor = exp(-wallV * 150.0) * channels * laneGate * 0.055;

  // A secondary packet can follow on mid-heavy passages, still on a fine strand.
  float branchProgress = clamp((localPhase - 0.69) / 0.31, 0.0, 1.0);
  float branchCenter = branchProgress * 0.98;
  float branchActive = smoothstep(0.67, 0.71, localPhase)
    * (1.0 - smoothstep(0.975, 0.998, localPhase));
  float branchHead = exp(-0.5 * pow((wallV - branchCenter) / 0.0080, 2.0));
  float branchPacket = secondary * laneGate * branchActive * branchHead
    * smoothstep(0.28, 0.78, rcrMid) * 0.16 * wallMask;

  return vec3(0.93, 0.97, 1.0) * (strand + packet + seamAnchor + branchPacket);
}

vec3 rcrCathedralInterior(vec3 rd) {
  // World-space fungal "cathedral" background.  The apex is fixed in the
  // organism, so it moves naturally with camera orientation rather than
  // behaving like a screen-space tunnel.
  vec3 apexWorld = vec3(0.0, 1.54, 0.0);
  vec3 apexDir = rcrSafeNormal(apexWorld - rcrCameraEye);
  vec3 refAxis = abs(apexDir.y) > 0.92 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
  vec3 bx = rcrSafeNormal(cross(refAxis, apexDir));
  vec3 by = rcrSafeNormal(cross(apexDir, bx));

  float z = clamp(dot(rd, apexDir), -1.0, 1.0);
  float theta = acos(z);
  float az = atan(dot(rd, by), dot(rd, bx));
  float wallV = clamp(theta / 1.34, 0.0, 1.0); // 0 = apex, 1 = lower chamber

  // Rich but inexpensive fungal wall material: broad olive variation,
  // fibrous radial flow, moist dark patches and restrained porous detail.
  float nBroad = noise(vec2(az * 1.55 + 8.0, wallV * 4.2 - 2.1));
  float nFiber = noise(vec2(az * 4.8 - wallV * 1.7, wallV * 13.0 + 5.3));
  float nWet = noise(vec2(az * 8.6 + 17.0, wallV * 6.4 - 9.0));
  float nPore = noise(vec2(az * 15.0 - 3.0, wallV * 22.0 + 11.0));

  vec3 wall = mix(vec3(0.055, 0.068, 0.034), vec3(0.155, 0.182, 0.082), nBroad);
  float fibrous = 0.5 + 0.5 * sin(wallV * 44.0 + az * 2.3 + (nFiber - 0.5) * 3.2);
  wall *= 0.82 + 0.18 * fibrous;
  float wetPatch = smoothstep(0.62, 0.84, nWet);
  wall = mix(wall, vec3(0.028, 0.034, 0.018), wetPatch * 0.52);
  float pores = smoothstep(0.74, 0.90, nPore) * (1.0 - wetPatch);
  wall *= 1.0 - pores * 0.18;

  // Organic radial channels converge at the apex.  Warp them enough to avoid
  // a perfect electronic/starburst look while retaining cathedral-like flow.
  float warp = (noise(vec2(az * 2.4 + 31.0, wallV * 5.5)) - 0.5) * 0.22
    + 0.055 * sin(wallV * 8.0 + az * 3.0);
  float warpedAz = az + warp * wallV;
  float primary = pow(0.5 + 0.5 * cos(warpedAz * 13.0), 18.0);
  float secondary = pow(0.5 + 0.5 * cos(warpedAz * 21.0 + 1.7), 24.0) * 0.42;
  float channels = max(primary, secondary);
  channels *= smoothstep(0.025, 0.18, wallV);

  // Static channels are only faintly visible in the tissue.
  wall += vec3(0.11, 0.030, 0.085) * channels * 0.18;

  // Beat-phase motion creates a luminous packet that travels from the lower
  // chamber (wallV ~ 1) to the apex (wallV ~ 0).  It is intentionally driven
  // by the world, not by camera motion or cage deformation.
  float travelPhase = fract(beatPhase);
  float pulseCenter = 1.02 - travelPhase * 1.08;
  float pulseWidth = mix(0.072, 0.045, clamp(rcrEnergy, 0.0, 1.0));
  float pulseFront = exp(-0.5 * pow((wallV - pulseCenter) / max(pulseWidth, 0.015), 2.0));

  // Keep only a subset of pathways bright so the wall does not globally flash.
  float laneId = floor((warpedAz + 3.14159265) * 13.0 / rcrTau);
  float laneGate = smoothstep(0.24, 0.78, rcrRandom(laneId * 19.0 + 7.0));
  float pulseStrength = (0.34 + 0.66 * rcrEnergy)
    * (0.58 + 0.42 * clamp(rcrBass, 0.0, 1.0));
  float pulse = channels * laneGate * pulseFront * pulseStrength;

  // A second, softer mid-driven stream makes occasional branching feel alive
  // without turning the walls into a strobe.
  float branchCenter = 1.10 - fract(travelPhase + 0.36) * 1.16;
  float branchFront = exp(-0.5 * pow((wallV - branchCenter) / 0.060, 2.0));
  float branchMask = secondary * smoothstep(0.18, 0.70, rcrMid);
  float branchPulse = branchMask * branchFront * (0.18 + 0.34 * rcrMid);

  vec3 pulseColor = vec3(1.0, 0.20, 0.62);
  wall += pulseColor * pulse * 1.65;
  wall += vec3(1.0, 0.38, 0.70) * branchPulse * 0.70;

  // Fine high-frequency gleam on active biological tissue.
  wall += vec3(0.38, 0.12, 0.26) * channels * rcrHigh * 0.10;

  // Convergence glow at the crown.  Phrase peaks gently reinforce it without
  // producing a full-frame flash.
  float apexGlow = exp(-theta * theta * 58.0);
  float arrival = exp(-pulseCenter * pulseCenter * 95.0);
  float crown = apexGlow * clamp(arrival * (0.45 + 0.85 * rcrEnergy)
    + phrasePulse * 0.32 + sectionChange * 0.18, 0.0, 1.2);
  wall += vec3(1.0, 0.30, 0.66) * crown * 0.72;

  // Sparse microscopic sparkle/spores around the upper chamber.
  float sparkNoise = noise(vec2(az * 42.0 + rcrClock * 0.13, wallV * 58.0 - rcrClock * 0.21));
  float spark = smoothstep(0.925, 0.985, sparkNoise) * rcrHigh
    * (1.0 - smoothstep(0.08, 0.62, wallV));
  wall += vec3(0.78, 0.43, 0.60) * spark * 0.22;

  // Gentle depth darkening toward the lower periphery keeps the apex readable.
  wall *= 0.72 + 0.28 * (1.0 - wallV);
  return wall;
}

vec3 rcrForest(vec3 rd) {
  float angle = atan(rd.x, rd.z);
  float canopy = noise(vec2(angle * 8.0, rd.y * 6.0 + 4.1));
  float leaves = noise(vec2(angle * 21.0 + 7.2, rd.y * 15.0));
  float trunks = smoothstep(0.18, 0.035,
    abs(sin(angle * 13.0 + noise(vec2(angle * 2.7, 8.0)) * 3.0)));
  vec3 color = mix(vec3(0.012, 0.020, 0.012), vec3(0.060, 0.087, 0.037), canopy);
  color *= 1.0 - trunks * 0.53;
  color += vec3(0.085, 0.100, 0.047)
    * smoothstep(0.67, 0.94, leaves) * smoothstep(-0.15, 0.65, rd.y);
  color = mix(vec3(0.027, 0.024, 0.016), color, smoothstep(-0.22, 0.23, rd.y));

  // Exterior vertical wall pulses removed. The opening now keeps only the
  // floor-level mycelial/cymatic signalling; the pink cathedral pulses remain
  // reserved for the interior reveal.

  if (rcrInside > 0.001) {
    vec3 cathedral = rcrCathedralInterior(rd);
    color = mix(color, cathedral, smoothstep(0.10, 0.82, rcrInside));
  }
  return color;
}

vec3 rcrShade(vec3 p, vec3 rd, vec4 hit, float travel, float lens) {
  float epsilon = max(0.00065, travel * 0.0003);
  bool standard = quality <= 0.5;
  bool simpleGround = standard && hit.z < 0.0 && hit.y < 3.5;

  // Standard mode previously paid for four full plant-SDF evaluations for a
  // normal plus another plant-SDF evaluation for AO on every visible cage
  // pixel. At the adaptive render scale that cost far more than the extra
  // shading fidelity bought. Use smooth analytic biological normals instead;
  // this both lowers GPU cost substantially and makes low-resolution ribs look
  // less faceted. High quality keeps the exact SDF normal/AO path.
  vec3 geometricNormal;
  if (simpleGround) {
    geometricNormal = vec3(0.0, 1.0, 0.0);
  } else if (standard && hit.z >= 0.0) {
    int normalOrganism = int(hit.z + 0.1);
    vec3 nq = rcrLocal(p, normalOrganism);
    vec3 localN;
    if (hit.y < 1.5) {
      localN = rcrSafeNormal(vec3(nq.x, (nq.y - 0.73) * 0.52, nq.z));
    } else {
      vec3 eq = nq - vec3(0.0, 0.306, 0.0);
      vec3 er = vec3(0.347, 0.402, 0.347);
      localN = rcrSafeNormal(eq / (er * er));
    }
    localN.xz = rcrTurn(-float(normalOrganism) * 0.73) * localN.xz;
    geometricNormal = localN;
  } else {
    geometricNormal = rcrNormal(p, hit, epsilon);
  }

  vec3 n = geometricNormal;
  vec3 albedo;
  float wet = 0.0;
  float gleba = 0.0;
  float scarlet = 0.0;
  float impulse = 0.0;
  float occlusion = standard ? (hit.z >= 0.0 ? 0.88 : 1.0)
    : rcrAmbientOcclusion(p, n, hit);
  float footprint = max(travel * lens * 2.0 / max(resolution.y, 1.0), 0.0001);

  if (hit.z >= 0.0) {
    int organism = int(hit.z + 0.1);
    vec3 q = rcrLocal(p, organism);
    vec3 localNormal = n;
    localNormal.xz = rcrTurn(float(organism) * 0.73) * localNormal.xz;

    if (hit.y < 1.5) {
      scarlet = 1.0;
      vec3 radial = rcrSafeNormal(vec3(q.x, (q.y - 0.74) * 0.80, q.z));
      float insideFace = smoothstep(-0.06, 0.64, -dot(localNormal, radial));
      float coating;
      if (quality > 0.5) {
        coating = 0.65 * rcrNoise3(q * 13.0 + vec3(3.4, 1.0, 8.0))
          + 0.35 * rcrNoise3(q * 28.0 + vec3(8.0, 2.0, 1.0));
      } else {
        coating = noise(q.xz * 12.0 + vec2(q.y * 3.2, -q.y * 2.4));
      }
      gleba = insideFace * smoothstep(0.39, 0.61, coating);
      gleba *= smoothstep(0.28, 0.65, rcrAges[organism]);

      float grainStrength = 1.0 - smoothstep(0.003, 0.012, footprint);
      float poreMask;
      if (quality > 0.5) {
        vec4 pores = rcrNoiseGradient(q * 72.0);
        poreMask = smoothstep(0.54, 0.79, pores.x);
        vec3 bump = pores.yzw;
        if (grainStrength > 0.08) {
          vec4 fine = rcrNoiseGradient(q * 157.0 + vec3(4.0));
          bump += fine.yzw * 0.37;
          poreMask = clamp(poreMask + 0.16 * smoothstep(0.67, 0.86, fine.x), 0.0, 1.0);
        }
        bump.xz = rcrTurn(-float(organism) * 0.73) * bump.xz;
        bump -= n * dot(n, bump);
        n = rcrSafeNormal(n - bump * grainStrength * mix(0.18, 0.045, gleba));
      } else {
        // Cheap scalar pore suggestion in standard quality; no 3D gradients.
        float simplePores = noise(q.xy * 38.0 + vec2(q.z * 7.0, -q.z * 5.0));
        poreMask = smoothstep(0.61, 0.84, simplePores) * grainStrength;
      }

      float mottling = quality > 0.5
        ? rcrNoise3(q * 8.0 + vec3(0.0, 7.0, 0.0))
        : noise(q.xz * 7.5 + vec2(q.y * 2.1, q.y * -1.8));
      albedo = mix(vec3(0.53, 0.012, 0.005), vec3(0.86, 0.049, 0.014), mottling);
      albedo *= 1.0 - poreMask * grainStrength * 0.34;
      vec3 slime = mix(vec3(0.029, 0.025, 0.006), vec3(0.070, 0.059, 0.017), coating);
      albedo = mix(albedo, slime, gleba);
      wet = mix(0.17, 0.90, gleba);
      impulse = 0.0;
      occlusion *= 0.86 + 0.14 * max(dot(localNormal, radial), 0.0);
    } else {
      float texture = rcrNoise3(q * 38.0);
      float dirt = (1.0 - smoothstep(0.015, 0.27, q.y))
        * (0.35 + 0.65 * rcrNoise3(q * 19.0));
      albedo = mix(vec3(0.72, 0.67, 0.51), vec3(0.51, 0.46, 0.32), texture * 0.45);
      albedo = mix(albedo, vec3(0.091, 0.060, 0.026), dirt * 0.79);
      float wrinkles = pow(0.5 + 0.5 * sin(q.y * 81.0
        + rcrNoise3(q * 18.0) * 8.0), 9.0);
      albedo *= 1.0 - wrinkles * 0.07;
      wet = 0.16;
    }
  } else {
    float broad = noise(p.xz * 3.1);
    float groundDetail = 1.0 - smoothstep(0.004, 0.024, footprint);
    float fineRaw = noise(p.xz * 72.0);
    float fine = mix(0.50, fineRaw, groundDetail);
    albedo = mix(vec3(0.022, 0.013, 0.008), vec3(0.100, 0.053, 0.023), broad);
    albedo *= 0.67 + fine * 0.46;
    float moss = smoothstep(0.67, 0.86, noise(p.xz * 2.0 + vec2(17.0, 8.0)));
    albedo = mix(albedo, vec3(0.036, 0.070, 0.020) * (0.68 + fine * 0.42), moss * 0.70);

    if (hit.y > 3.5) {
      float seed = hit.w;
      vec2 grainCoordinate = rcrTurn(seed * rcrTau) * p.xz;
      float fibers = noise(vec2(grainCoordinate.x * 28.0, grainCoordinate.y * 220.0));
      if (hit.y < 4.5) {
        albedo = mix(vec3(0.043, 0.019, 0.009), vec3(0.24, 0.112, 0.033), seed * seed);
        float veins = pow(0.5 + 0.5 * sin(
          grainCoordinate.x * 87.0 + abs(grainCoordinate.y) * 56.0
        ), 17.0);
        albedo *= 0.72 + 0.30 * fibers + 0.10 * veins;
        wet = 0.40;
      } else {
        albedo = mix(vec3(0.028, 0.016, 0.009), vec3(0.15, 0.087, 0.042), seed);
        albedo *= 0.66 + 0.49 * fibers;
        wet = 0.21;
      }
    }

    for (int i = 0; i < 4; ++i) {
      vec2 shadowCenter = rcrOrigins[i].xz + vec2(0.21, -0.14) * rcrSizes[i];
      vec2 delta = (p.xz - shadowCenter) / max(rcrSizes[i], 0.1);
      float contact = exp(-dot(delta, delta) * 5.2);
      occlusion *= 1.0 - contact * (0.36 + 0.20 * rcrAges[i]);
    }
  }

  vec3 light = rcrSafeNormal(vec3(-0.68, 1.12, 0.48));
  vec3 halfVector = rcrSafeNormal(light - rd);
  float diffuse = max(dot(n, light), 0.0);
  float shadow = 1.0;
  if (quality > 0.5 && hit.z >= 0.0 && diffuse > 0.03) {
    if (rcrInside > 0.55) {
      // Ten extra full plant evaluations per shaded pixel were especially
      // costly inside the hero cage.  AO gives a stable close-range proxy.
      shadow = mix(0.76, 1.0, occlusion);
    } else {
      shadow = rcrSelfShadow(p + geometricNormal * 0.003, light, int(hit.z + 0.1));
    }
  }

  vec3 ambient = mix(vec3(0.15, 0.13, 0.09), vec3(0.28, 0.34, 0.25), n.y * 0.5 + 0.5);
  vec3 color = albedo * (
    ambient * occlusion
    + vec3(2.15, 1.82, 1.43) * diffuse * shadow * (0.60 + 0.40 * occlusion)
  );

  // Exterior music response now starts at the fungus, crosses the physical
  // floor as fine cymatic threads, then visually continues into the matching
  // white lanes on the background wall. This is emissive and therefore stays
  // readable without making the ground geometry itself move.
  if (hit.z < 0.0 && hit.y < 3.5 && rcrInside < 0.58) {
    color += rcrFloorSignal(p);
  }

  float exponent = mix(28.0, 112.0, wet);
  float specular = pow(max(dot(n, halfVector), 0.0), exponent);
  float fresnel = pow(1.0 - max(dot(n, -rd), 0.0), 5.0);
  color += vec3(1.0, 0.89, 0.68) * specular
    * (0.032 + wet * 0.41 + wet * rcrHigh * 0.075) * shadow;
  color += vec3(0.043, 0.058, 0.042) * fresnel * wet * occlusion;

  if (scarlet > 0.5) {
    float transmission = pow(max(dot(-geometricNormal, light), 0.0), 1.6);
    color += vec3(0.34, 0.014, 0.003) * transmission
      * (1.0 - gleba) * (0.40 + 0.60 * occlusion);
    // Keep the red cage visually stable; beat response is carried by the
    // cathedral wall pulses rather than flashing the cage itself.
    vec3 iridescence = 0.5 + 0.5 * cos(
      vec3(0.0, 2.2, 4.4) + dot(p, vec3(4.0, 7.0, 3.0))
      - rcrClock * 1.1
    );
    color += iridescence * gleba * specular * rcrHigh * rcrEnergy * 0.075;
  }

  // Near-free silhouette softening for raymarched plant edges.  We already
  // need the background for fog, so this adds no extra scene/ray samples.
  // It gently reduces high-contrast stair-stepping at grazing silhouettes
  // without blurring surface detail or lowering march performance.
  vec3 background = rcrForest(rd);
  if (hit.z >= 0.0) {
    float facing = abs(dot(geometricNormal, -rd));
    float grazing = 1.0 - smoothstep(0.018, 0.115, facing);
    float edgeBlend = grazing * (quality > 0.5 ? 0.045 : 0.105);
    color = mix(color, background, edgeBlend);
  }

  float fog = 1.0 - exp(-max(travel - 2.7, 0.0) * 0.072);
  return mix(color, background, fog);
}

vec3 rcrSpores(vec3 ro, vec3 rd, float surfaceDistance, float lens) {
  vec3 result = vec3(0.0);
  if (!rcrVisible[0] || rcrAges[0] < 0.55) return result;

  float activity = rcrHigh * (0.18 + 0.82 * rcrEnergy)
    * smoothstep(0.55, 0.95, rcrAges[0]);
  if (activity < 0.025) return result;

  int count = 5;
  if (quality > 0.5) count = 22;

  for (int i = 0; i < 22; ++i) {
    if (i >= count) break;
    float seed = float(i) * 13.0 + 7.0;
    int sector = i % 5;
    int base = sector * 6;
    float alongRib = 0.18 + 0.64 * rcrRandom(seed + 1.0);
    vec3 anchor = mix(rcrJoints[base + 2], rcrJoints[base + 3], alongRib);
    vec3 inward = rcrSafeNormal(vec3(-anchor.x, -0.18, -anchor.z));
    anchor += inward * 0.060;

    float life = fract(rcrClock * (0.052 + 0.026 * rcrRandom(seed + 2.0))
      + rcrRandom(seed + 3.0));
    vec3 particle = anchor;
    particle.y += life * (0.32 + 0.34 * rcrRandom(seed + 4.0));
    particle.x += 0.080 * life * sin(life * 5.0 + seed);
    particle.z += 0.065 * life * cos(life * 4.0 + seed * 1.3);

    vec3 delta = particle - ro;
    float distanceAlong = dot(delta, rd);
    if (distanceAlong < 0.01 || distanceAlong > surfaceDistance) continue;

    float radius = 0.0010 + 0.0013 * rcrRandom(seed + 5.0);
    float pixel = max(distanceAlong * lens * 1.5 / max(resolution.y, 1.0), 0.00035);
    float perpendicular = length(delta - rd * distanceAlong);
    float disc = 1.0 - smoothstep(radius * 0.3, radius + pixel, perpendicular);
    float fade = sin(life * 3.14159265);
    result += vec3(0.29, 0.25, 0.12) * disc * fade * activity
      * min(1.0, radius / pixel);
  }
  return result;
}

void rcrCamera(out vec3 eye, out vec3 target, out float lens) {
  rcrInside = 0.0;
  float age = rcrAges[0];
  float grown = smoothstep(0.10, 0.88, age);
  float angle = 0.63 + 0.025 * sin(rcrClock * 0.09);
  vec3 direction = vec3(cos(angle), 0.0, sin(angle));
  vec3 entranceDirection = vec3(cos(0.63), 0.0, sin(0.63));

  vec3 exteriorEye = direction * mix(1.82, 3.12, grown);
  exteriorEye.y = mix(0.86, 1.47, grown);
  vec3 exteriorTarget = vec3(0.0, mix(0.30, 0.71, grown), 0.0);
  eye = exteriorEye;
  target = exteriorTarget;
  lens = 0.34;

  if (rcrClock < 24.0) return;

  float tour = mod(rcrClock - 24.0, 60.0);
  vec3 mouthEye = entranceDirection * 1.08 + vec3(0.0, 0.57, 0.0);
  vec3 entryEye = entranceDirection * 0.21 + vec3(0.0, 0.545, 0.0);
  vec3 entryTarget = vec3(-0.31, 0.93, -0.22);
  vec3 secondEye = vec3(-0.18, 0.77, 0.085);
  vec3 secondTarget = vec3(-0.24, 1.22, 0.40);
  vec3 thirdEye = vec3(0.075, 1.035, -0.16);
  vec3 thirdTarget = vec3(0.42, 1.30, 0.23);

  float phraseAngle = rcrTau * phraseProgress;
  float routeAmount = sin(phraseAngle) * clamp(mainRiffState, 0.0, 1.0);
  secondEye.x += routeAmount * 0.027;
  thirdEye.z += routeAmount * 0.025;
  secondTarget.x += routeAmount * 0.075;
  thirdTarget.z += routeAmount * 0.075;

  vec3 colonyEye = direction * (4.42 + 0.34 * rcrEnergy);
  colonyEye.y = 1.99;
  vec3 colonyTarget = vec3(-0.12, 0.52, -0.18);
  float inside = 0.0;

  if (tour < 5.0) {
    eye = exteriorEye;
    target = exteriorTarget;
  } else if (tour < 13.0) {
    float u = smoothstep(5.0, 13.0, tour);
    eye = mix(exteriorEye, mouthEye, u);
    target = mix(exteriorTarget, vec3(0.0, 0.62, 0.0), u);
  } else if (tour < 17.0) {
    float u = smoothstep(13.0, 17.0, tour);
    eye = mix(mouthEye, entryEye, u);
    target = mix(vec3(0.0, 0.62, 0.0), entryTarget, u);
    inside = u;
  } else if (tour < 24.0) {
    float u = smoothstep(17.0, 24.0, tour);
    eye = mix(entryEye, secondEye, u);
    target = mix(entryTarget, secondTarget, u);
    inside = 1.0;
  } else if (tour < 30.0) {
    float u = smoothstep(24.0, 30.0, tour);
    eye = mix(secondEye, thirdEye, u);
    target = mix(secondTarget, thirdTarget, u);
    inside = 1.0;
  } else if (tour < 33.0) {
    float u = smoothstep(30.0, 33.0, tour);
    eye = mix(thirdEye, entryEye, u);
    target = mix(thirdTarget, entryTarget, u);
    inside = 1.0;
  } else if (tour < 35.0) {
    float u = smoothstep(33.0, 35.0, tour);
    eye = mix(entryEye, colonyEye, u);
    target = mix(entryTarget, colonyTarget, u);
    inside = 1.0 - u;
  } else if (tour < 48.0) {
    eye = colonyEye;
    target = colonyTarget;
  } else {
    float u = smoothstep(48.0, 60.0, tour);
    eye = mix(colonyEye, exteriorEye, u);
    target = mix(colonyTarget, exteriorTarget, u);
  }

  rcrInside = clamp(inside, 0.0, 1.0);
  lens = mix(0.34, 0.70, rcrInside);
}

vec3 rcrToneMap(vec3 color) {
  color = max(color, vec3(0.0));
  color = (color * (2.51 * color + 0.03))
    / (color * (2.43 * color + 0.59) + 0.14);
  return pow(clamp(color, 0.0, 1.0), vec3(0.454545));
}

void main() {
  vec2 p = (gl_FragCoord.xy * 2.0 - resolution) / max(resolution.y, 1.0);
  rcrClock = max(presetTime, 0.0);
  rcrBass = clamp(u_slowBass * 0.80 + bass * 0.20, 0.0, 1.35);
  rcrMid = clamp(mids * 0.65 + mainRiffState * 0.35, 0.0, 1.2);
  rcrHigh = clamp(highs * 0.78 + max(trebleRel - 1.0, 0.0) * 0.16, 0.0, 1.25);
  rcrEnergy = clamp(globalEnergy * 0.55 + u_slowLevel * 0.45, 0.0, 1.0);
  rcrKick = clamp(kickPulse, 0.0, 1.0);

  float development = smoothstep(2.5, 22.0, rcrClock);
  float growingWindow = sin(development * 3.14159265);
  float phrasePressure = clamp(phrasePulse, 0.0, 1.0);

  rcrAges[0] = clamp(development + growingWindow
    * (0.075 * rcrEnergy + 0.032 * rcrBass + 0.035 * phrasePressure), 0.0, 1.0);

  float secondary = smoothstep(10.0, 45.0, rcrClock);
  rcrAges[1] = clamp(secondary + sin(secondary * 3.14159265)
    * (0.085 * rcrEnergy + 0.030 * phrasePressure), 0.0, 1.0);
  rcrAges[2] = clamp(
    0.59 * smoothstep(17.0, 60.0, rcrClock)
    + 0.10 * rcrEnergy * smoothstep(22.0, 36.0, rcrClock),
    0.0, 0.70
  );
  rcrAges[3] = 0.0;

  rcrOrigins[0] = vec3(0.0, 0.0, 0.0);
  rcrOrigins[1] = vec3(-1.18, -0.005, -0.48);
  rcrOrigins[2] = vec3(-0.08, -0.005, -1.30);
  rcrOrigins[3] = vec3(-0.75, -0.005, 0.52);
  rcrSizes[0] = 1.0;
  rcrSizes[1] = 0.74;
  rcrSizes[2] = 0.68;
  rcrSizes[3] = 0.72;

  for (int i = 0; i < 4; ++i) {
    rcrSplits[i] = smoothstep(0.12, 0.48, rcrAges[i]);
  }

  vec3 eye;
  vec3 target;
  float lens;
  rcrCamera(eye, target, lens);
  rcrCameraEye = eye;

  vec3 forward = rcrSafeNormal(target - eye);
  vec3 right = rcrSafeNormal(cross(forward, vec3(0.0, 1.0, 0.0)));
  vec3 up = rcrSafeNormal(cross(right, forward));
  vec3 rd = rcrSafeNormal(forward + lens * (p.x * right + p.y * up));

  for (int i = 0; i < 4; ++i) {
    // During the interior cathedral tour only the hero can contribute.
    // Standard quality also omits the small rear specimen: it costs a complete
    // cage build per pixel but contributes very little at the reduced render
    // scale used by the adaptive renderer.
    if ((rcrInside > 0.55 && i > 0) || (quality <= 0.5 && i > 0)) {
      // Standard mode renders only the hero stinkhorn. This more than pays for
      // restoring all five hero cage sectors (needed for intact lattice
      // geometry) and removes a complete second 30-joint build/SDF per pixel.
      rcrVisible[i] = false;
      continue;
    }

    vec3 localEye = rcrLocal(eye, i);
    vec3 localDirection = rd / rcrSizes[i];
    localDirection.xz = rcrTurn(float(i) * 0.73) * localDirection.xz;
    rcrVisible[i] = rcrRayBounds(
      localEye, localDirection,
      vec3(-1.04, -0.20, -1.04),
      vec3(1.04, 2.25, 1.04)
    );
    if (i < 3 && rcrVisible[i] && rcrAges[i] > 0.085) {
      rcrBuildPlant(i);
    }
  }

  float travel;
  vec4 hit = rcrMarch(eye, rd, travel);

  // The raymarcher intentionally has a finite distance budget.  At shallow
  // viewing angles that could expose tiny holes between the procedural floor
  // and the distant wall.  Fill only the FAR floor analytically with a cheap
  // flat-plane intersection; nearby soil/volva geometry is unchanged.
  // Keep the analytic far floor active through the entry transition so the
  // floor cannot tear open while it is still visible through the cage. Disable
  // it only once the camera is essentially fully inside and looking upward.
  if (rcrInside < 0.94 && rd.y < -0.0005) {
    float farGroundT = (-0.008 - eye.y) / rd.y;
    bool farFloor = farGroundT > 3.2 && farGroundT < 42.0;
    if (farFloor && (hit.y <= 0.0 || farGroundT < travel)) {
      travel = farGroundT;
      hit = vec4(0.0, 3.0, -1.0, 0.0);
    }
  }

  vec3 color = rcrForest(rd);
  float visibleDistance = 42.0;

  if (hit.y > 0.0) {
    visibleDistance = travel;
    color = rcrShade(eye + rd * travel, rd, hit, travel, lens);
  }

  color += rcrSpores(eye, rd, visibleDistance, lens);
  float vignette = 1.0 - 0.16 * smoothstep(0.30, 1.85, length(p * vec2(0.72, 1.0)));
  color = rcrToneMap(color * vignette * 1.12);
  color += transitionTunnel(p);
  color *= transitionIdentityPresence();
  outColor = vec4(color, 1.0);
}
`;
  return [[360, { name: "Red Cage Stinkhorn", source }]];
}