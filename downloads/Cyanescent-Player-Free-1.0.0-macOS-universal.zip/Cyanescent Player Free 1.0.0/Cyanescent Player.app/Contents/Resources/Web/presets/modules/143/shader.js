export { createFractalTesseractPresetShaderEntries as createPresetShaderEntries } from "../../fractalTesseractPresetShaderSources.js";
