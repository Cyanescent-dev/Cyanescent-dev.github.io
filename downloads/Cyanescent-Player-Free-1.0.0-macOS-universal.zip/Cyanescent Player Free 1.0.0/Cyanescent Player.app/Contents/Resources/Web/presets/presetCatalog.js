import { runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
export const PresetRenderer = Object.freeze({
  CYANESCENT: "cyanescent",
  USER_SHADER: "user-shader"
});

export const PresetSource = Object.freeze({
  BUILT_IN: "built-in",
  JSON_IMPORT: "json-import"
});

function normalizedRecord(record, defaults = {}) {
  const id = Number(record?.id);
  if (!Number.isFinite(id)) return null;
  return {
    ...defaults,
    ...record,
    id,
    name: String(record?.name || defaults.name || `Preset ${id}`),
    author: String(record?.author || defaults.author || "Unknown"),
    category: String(record?.category || defaults.category || "uncategorised")
  };
}

export function createPresetCatalog({
  builtInPresets = [],
  getUserShaderPresets = () => [],
  hasUserShader = () => true
} = {}) {
  function builtIns() {
    return builtInPresets.map((preset) => normalizedRecord(preset, {
      renderer: PresetRenderer.CYANESCENT,
      source: PresetSource.BUILT_IN,
      builtIn: true,
      imported: false
    })).filter(Boolean);
  }

  function userShaders() {
    return getUserShaderPresets().map((preset) => normalizedRecord(preset, {
      renderer: PresetRenderer.USER_SHADER,
      source: PresetSource.JSON_IMPORT,
      builtIn: false,
      imported: true
    })).filter(Boolean);
  }

  function all() {
    const seen = new Set();
    return [...builtIns(), ...userShaders()].filter((preset) => {
      if (seen.has(preset.id)) return false;
      seen.add(preset.id);
      return true;
    });
  }

  function isPlayable(preset) {
    if (!preset || !runtimeAllowsPreset(preset.id)) return false;
    if (preset.renderer === PresetRenderer.CYANESCENT) return true;
    if (preset.renderer === PresetRenderer.USER_SHADER) return preset.id >= 10000 && hasUserShader(preset.id);
    return false;
  }

  function playable() {
    return all().filter(isPlayable);
  }

  function byId(id) {
    const numeric = Number(id);
    return all().find((preset) => preset.id === numeric) || null;
  }

  function imported() {
    return all().filter((preset) => preset.imported);
  }

  return {
    all,
    playable,
    builtIns,
    imported,
    byId,
    isPlayable
  };
}
