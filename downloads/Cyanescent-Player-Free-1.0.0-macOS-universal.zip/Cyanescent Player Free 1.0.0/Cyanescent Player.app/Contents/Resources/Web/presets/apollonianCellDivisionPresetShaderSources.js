export function createApollonianCellDivisionPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const source = `${modularShaderPrelude}
${modularTransitionShaderBlock}

// -------------------------------------------------------------------------
// Preset 165: Fractal Breaker
// Inspired by 'Cell division.milk' - Microscopic biological recursion
// -------------------------------------------------------------------------

// Stage B: the director (fractalBreakerDirector.js) owns the clocks that used to read time:
// fbClock = camera travel, offsets, recursive rotations, camera roll (seconds of Stage A motion);
// fbShape = inversion strength, camera lateral position (the camera's passage past each cell's
// inversion pole is what forms the wave), mids rotation term;
// fbLight = kick illumination, treble highlights, energy, glow hue clock.
// fbDirector = 0 (nothing bound) reproduces Stage A exactly.
uniform float fbDirector;
uniform vec4 fbClock;
uniform vec4 fbShape;
uniform vec4 fbLight;

vec3 fbOffset;
mat2 fbRotA;
mat2 fbRotB;

mat2 rot2(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

// Apollonian Gasket distance estimator
float sdApollonian(vec3 p, float s, float t) {
    float scale = 1.0;
    
    vec3 offset = fbOffset;

    for (int i = 0; i < 7; i++) {
        p = mod(p - 1.0, 2.0) - 1.0;
        
        // Below the smallest sampled radius; protects the exact inversion pole.
        float r2 = max(dot(p, p), 1e-8);
        
        // Spherical Inversion
        float k = s / r2;
        p *= k;
        scale *= k;
        
        // Translation (Smooth cellular division)
        p += offset; 
        
        // Organic rotation
        p.xy *= fbRotA;
        p.xz *= fbRotB;
    }
    
    float d = length(p) / scale;
    
    // Camera forcefield: physically pushes geometry away from the camera lens to prevent glitching/strobing
    return max(d, 0.2 - t);
}

void main() {
    vec2 uv = vUv * 2.0 - 1.0;
    uv.x *= resolution.x / max(resolution.y, 1.0);
    
    bool directed = fbDirector > 0.5;
    vec4 clock = directed ? fbClock : vec4(time);
    // Animate the offset based on music (Cell division)
    fbOffset = vec3(0.5 + sin(clock.y * 0.3) * 0.2, 0.5 + cos(clock.y * 0.4) * 0.1, 0.5);
    // Organic rotation
    fbRotA = rot2(clock.z * 0.1 + (directed ? fbShape.w : mids) * 0.2);
    fbRotB = rot2(clock.z * 0.15);

    // Biological camera drift
    vec3 ro = vec3(directed ? fbShape.yz : vec2(0.1), clock.x * 0.2);
    vec3 rd = normalize(vec3(uv, 1.0));
    rd.xy *= rot2(sin(clock.w * 0.1) * 0.2);
    
    // Smooth inversion radius (No fast jumping)
    float s = directed ? fbShape.x : 1.2 + globalEnergy * 0.2;
    float energy = directed ? fbLight.z : globalEnergy;
    // Kicks: brief, restrained membrane light; treble: fine highlights on the rims
    float kickLight = directed ? 1.0 + fbLight.x : 1.0;
    float rimLight = directed ? 1.0 + fbLight.y : 1.0;
    
    float t = 0.0;
    float maxDist = 8.0;
    vec3 col = vec3(0.0);
    float glow = 0.0;
    // 0: exhausted, 1: confirmed hit, 2: range exit, 3: invalid DE.
    int marchState = 0;
    float lastD = maxDist;
    
    // Keep the original main loop; refine only near-surface stragglers below.
    for(int i = 0; i < 70; i++) {
        if (t > maxDist) { marchState = 2; break; }
        vec3 p = ro + rd * t;
        float d = sdApollonian(p, s, t);
        if (!(d >= 0.0 && d < 1e20)) {
            marchState = 3;
            break;
        }
        lastD = d;
        glow += 0.005 / max(d, 0.002) * exp(-t * 0.5);
        if (d < 0.001) { marchState = 1; break; }
        // The repeated, translated DE is not a globally conservative SDF.
        // Bound long jumps across folds; retain the original near-surface step.
        t += min(d * 0.8, 0.2);
    }

    // A separate cold loop keeps the common path inexpensive on Metal.
    // Continuation does not accumulate extra glow.
    if (marchState == 0 && lastD < 0.01) {
        for (int j = 0; j < 8; j++) {
            if (t > maxDist) { marchState = 2; break; }
            float d = sdApollonian(ro + rd * t, s, t);
            if (!(d >= 0.0 && d < 1e20)) { marchState = 3; break; }
            if (d < 0.001) { marchState = 1; break; }
            t += min(d * 0.8, 0.2);
        }
    }

    // Classify a range exit on the last budgeted step as well.
    if (marchState == 0 && t > maxDist) marchState = 2;

    // Membrane lighting
    if (marchState == 1) {
        vec3 p = ro + rd * t;
        vec3 n;
        vec2 e = vec2(0.001, 0.0);
        // Camera exclusion is a marching gate, not a spatial gradient:
        // keep its radius for marching, but sample the fractal normal itself.
        // This retains the original six taps and epsilon, without zero-gradient
        // camera plateaus or an expensive second distance-estimator stencil.
        n.x = sdApollonian(p + e.xyy, s, 0.2) - sdApollonian(p - e.xyy, s, 0.2);
        n.y = sdApollonian(p + e.yxy, s, 0.2) - sdApollonian(p - e.yxy, s, 0.2);
        n.z = sdApollonian(p + e.yyx, s, 0.2) - sdApollonian(p - e.yyx, s, 0.2);
        float n2 = dot(n, n);
        // Ordered comparisons reject NaN/Inf as well as degenerate gradients.
        n = n2 > 1e-20 && n2 < 1e20 ? n * inversesqrt(n2) : -rd;

        // Cellular fluid lighting
        vec3 lightCol = vec3(0.1, 0.5, 0.8);
        float diff = max(0.0, dot(n, normalize(vec3(1, 1, -1))));
        float fresnel = pow(1.0 - clamp(dot(n, -rd), 0.0, 1.0), 3.0);
        
        col += lightCol * diff * exp(-t * 0.5) * kickLight;
        col += vec3(0.0, 1.0, 0.5) * fresnel * (0.8 + energy * 0.2) * rimLight;
    }
    
    // Inner Cytoplasm Glow
    vec3 bioGlow = vec3(0.2, 0.8, 0.3) + vec3(0.0, 0.2, 0.5) * sin((directed ? fbLight.w : time) + t * 2.0);
    col += bioGlow * glow * 0.4;
    
    // Depth fluid fog
    col = mix(col, vec3(0.0, 0.05, 0.1), smoothstep(0.0, maxDist, t));
    
    // Post-processing
    col *= 1.0 - length(uv) * 0.4;
    outColor = vec4(col / (1.0 + col * 0.5), 1.0);
    
    // Transitions
    outColor.rgb += transitionTunnel(uv);
    outColor.rgb *= transitionIdentityPresence();
}
`;
  return [[165, { name: "Fractal Breaker", source }]];
}
