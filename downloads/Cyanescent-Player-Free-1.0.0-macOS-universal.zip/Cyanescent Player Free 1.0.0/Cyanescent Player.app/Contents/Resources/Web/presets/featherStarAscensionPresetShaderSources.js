export function createFeatherStarAscensionPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const fragmentSource = `${modularShaderPrelude}
${modularTransitionShaderBlock}

// Feather Star Ascension
// A swimming crinoid with radial symmetry, branching feathery arms, and bioluminescence.
// HD restoration (2026-10-15): the original 14-arm swim, bend, timing, framing and palette
// are unchanged; spines, pinnules, glow and plankton are redrawn with analytic,
// pixel-footprint antialiasing. Original: docs/rollback/feather-star-ascension-v1.

const float FS_ARMS = 14.0;
const float FS_SECTOR = 0.44879895;   // 2 PI / 14
const float FS_PINNULES = 45.0;       // pinnules per unit of arm, as the original branches

float fsSq(float x) { return x * x; }

// Coverage of a line of half width hw at distance d, for a pixel of size px.
// Lines thinner than a pixel keep their energy instead of breaking up.
float fsLine(float d, float hw, float px) {
  float w = max(hw, px * 0.5);
  return (1.0 - smoothstep(w - px * 0.5, w + px * 0.5, d)) * (hw / w);
}

vec3 fsTone(vec3 c) {
  // palette60s with blues and violets lifted to the brightness of the warm hues
  float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
  return c * mix(1.0, 0.34 / max(lum, 0.06), 0.25);
}

// One arm k (any integer, wrapped onto the 14 arms) lit at polar position (a, r).
// owner is 1 for the arm whose sector holds the pixel: only it draws the open-water part of the
// kick ring, so the ring stays the original clean 14-sided polygon.
vec3 featherArm(float a, float r, float k, float px, float expansion, float flutterAmp, float owner) {
  // Arm ids -6..7 as the original; the arm at +-PI keeps one id (and one swim phase) on both halves.
  float id = k - FS_ARMS * floor((k + 6.5) / FS_ARMS);
  float la = a - k * FS_SECTOR;
  la -= 6.2831853 * floor((la + PI) / 6.2831853);
  // X is tangential, Y is radial outward
  vec2 q = vec2(sin(la), cos(la)) * r;

  // Swimming motion (folding up and down), unchanged: a travelling wave around the crown
  float flap = sin(time * 2.5 + id * 0.6) * 0.2;
  q.y -= expansion;
  float armLength = 0.9 + sin(id * 2.3) * 0.15;
  float v = q.y;
  if (v <= 0.0 || v >= armLength) return vec3(0.0);

  // Curvature from swimming flap (original bend), and the true distance to the bent spine
  float x = q.x + v * v * flap * 0.5;
  float ax = abs(x) * inversesqrt(1.0 + v * v * flap * flap);
  float side = sign(x);
  float taper = smoothstep(0.0, 0.1, v) * smoothstep(armLength, armLength * 0.4, v);

  float hue = 0.55 + id * 0.03 + time * 0.04 - r * 0.15;
  vec3 base = fsTone(palette60s(hue));
  vec3 deep = pow(base, vec3(1.35)) * 1.35;

  // Kick: the original polygonal rings of light travelling outward (same wave, speed and gate),
  // now fading softly at the arm tips instead of being cut there
  float ring = smoothstep(0.8, 1.0, sin(v * 10.0 - time * 3.0)) * smoothstep(armLength * 0.95, armLength * 0.6, v) * smoothstep(0.0, 0.04, v);
  float pulse = ring * kick;

  // ---- Spine: a translucent tube, bright internal core, fine luminous rims ----
  float spineHW = (0.0042 + 0.0064 * taper) * smoothstep(armLength, armLength * 0.72, v) + 0.0004;
  float s = clamp(ax / spineHW, 0.0, 1.0);
  float body = fsLine(ax, spineHW, px);
  float rim = s * s * s * s * s * s;
  // Segment rhythm at each pinnule pair, like the joints of a crinoid arm
  float wSpine = FS_PINNULES * (v + 0.12 * v * v);
  float joint = 0.86 + 0.14 * cos(6.2831853 * wSpine);
  // Highlight on the outer side of the bend
  float sheen = clamp(side * flap * 6.0, 0.0, 1.0) * s;
  float coreLight = exp(-s * s * 9.0) * (1.0 + bass * 0.35);
  vec3 spineCol = mix(base, vec3(1.0, 0.96, 1.0), 0.26);
  vec3 col = body * (spineCol * (0.32 + 0.62 * coreLight * joint + 0.25 * sheen) + mix(base, vec3(1.0), 0.5) * 0.4 * rim);
  col *= 1.0 + 1.3 * pulse;

  // ---- Pinnules: fine curved filaments sweeping toward the tip ----
  float u = ax - spineHW * 0.75;
  float len = min(0.15 * taper, (v + expansion) * 0.205);
  // gentle tightening toward the tip
  float sweep = 0.30 * u + 1.5 * u * u;
  float w = FS_PINNULES * (v + 0.12 * v * v - sweep);
  float reach = clamp(u / max(len, 1e-4), 0.0, 1.0);
  // Flutter of the free pinnule tips (original phase and speed)
  w += flutterAmp * reach * reach * sin(FS_PINNULES * v * 0.3 - time * 6.0);
  float pid = floor(w + 0.5);
  float f = w - pid;
  float alt = mod(pid, 2.0);
  float pinLen = len * (1.0 - 0.12 * alt);
  float t = clamp(u / max(pinLen, 1e-4), 0.0, 1.0);
  float grad = FS_PINNULES * sqrt(fsSq(1.0 + 0.24 * v) + fsSq(0.30 + 3.0 * u));
  float d = abs(f) / grad;
  float pinHW = 0.0019 * (1.0 - 0.78 * t) * (0.8 + 0.2 * taper);
  float pinMask = step(0.0, u) * (1.0 - smoothstep(0.82, 1.0, u / max(pinLen, 1e-4)));
  float pinVar = 0.82 + 0.18 * cos(pid * 0.9 + id * 1.7);
  float filament = fsLine(d, pinHW, px) * pinMask * pinVar;
  float filamentGlow = exp(-fsSq(d / 0.0055)) * pinMask * (1.0 - 0.7 * t) * 0.32;
  // Highs: a delicate shimmer running out along the filaments
  float glint = pow(0.5 + 0.5 * sin(pid * 2.39 + t * 7.0 - time * 7.0), 10.0) * highs * 0.9;
  vec3 pinCol = mix(fsTone(palette60s(hue + 0.035 + t * 0.05)), vec3(1.0), 0.12 * (1.0 - t));
  float pinLight = (0.68 + mids * 0.22 + highEnergyState * 0.08) * taper + 0.05;
  col += pinCol * (filament * (pinLight * (1.0 + glint) + pulse * (1.0 - t) * 1.2) + filamentGlow * pinLight);

  // ---- Soft bioluminescent halos: the original fan between pinnules, and the spine glow ----
  float out_ = max(u - len, 0.0);
  float fan = exp(-out_ * (20.0 - highs * 10.0)) * (0.22 + 0.08 * (1.0 - reach)) * taper;
  float spineGlow = exp(-max(ax - spineHW, 0.0) * 20.0) * 0.5 * taper;
  float restraint = 1.0 - 0.22 * max(breakdownState, calmState);
  // High-energy sections: a wider, fainter aura so the crown fills out as the original fans did
  float aura = exp(-out_ * 6.5) * taper * 0.06 * (highs * 0.7 + highEnergyState * 0.35);
  col += deep * (fan * restraint + spineGlow + aura) * (1.0 + 0.7 * pulse);
  col += mix(base, deep, 0.5) * ring * kick * 0.36 * owner;
  return col;
}

void main() {
  vec2 uv = gl_FragCoord.xy / resolution.xy;
  vec2 p = (gl_FragCoord.xy * 2.0 - resolution.xy) / min(resolution.x, resolution.y);
  float px = 2.0 / min(resolution.x, resolution.y);

  float r = length(p);

  // Global environment (abyss)
  vec3 env = vec3(0.002, 0.008, 0.015);

  // Water current and plankton drift: soft round motes at the original cells and timing
  vec2 driftUV = p + vec2(time * 0.015, -time * 0.025);
  vec2 cell = floor(driftUV * 40.0);
  float planktonHash = fract(sin(dot(cell, vec2(12.9898, 78.233))) * 43758.5453);
  vec2 mote = fract(driftUV * 40.0) - 0.5 - (hash2(cell) - 0.5) * 0.5;
  float moteSize = 0.10 + 0.08 * fract(planktonHash * 17.0) + px * 20.0;
  float plankton = smoothstep(0.985, 1.0, planktonHash) * (0.5 + 0.5 * sin(time + planktonHash * 10.0));
  plankton *= exp(-dot(mote, mote) / (moteSize * moteSize)) * 1.6;
  // A sparser, slower and finer layer further away
  vec2 farUV = p * 1.0 + vec2(time * 0.006, -time * 0.010);
  vec2 farCell = floor(farUV * 75.0);
  float farHash = hash(farCell + 17.0);
  vec2 farMote = fract(farUV * 75.0) - 0.5 - (hash2(farCell) - 0.5) * 0.5;
  float farSize = 0.12 + px * 37.0;
  float farPlankton = smoothstep(0.992, 1.0, farHash) * (0.5 + 0.5 * sin(time * 0.7 + farHash * 31.0))
    * exp(-dot(farMote, farMote) / (farSize * farSize)) * 0.6;
  env += vec3(0.1, 0.8, 0.9) * (plankton + farPlankton) * (0.2 + highs * 0.6);

  // Deep caustics
  float caustic1 = sin(p.x * 8.0 + time * 0.3 + sin(p.y * 4.0)) * 0.5 + 0.5;
  float caustic2 = sin(p.y * 10.0 - time * 0.2 + cos(p.x * 5.0)) * 0.5 + 0.5;
  env += vec3(0.005, 0.02, 0.04) * caustic1 * caustic2 * (1.0 + bass * 0.3);

  // Coordinate system for the crinoid, with the original slow rotation
  vec2 cp = p * rot(time * 0.08);
  float a = atan(cp.y, cp.x);

  // Bass breathing expansion (pushing the base outwards)
  float expansion = bass * 0.08 + level * 0.05;
  float flutterAmp = 0.10 * (0.5 + highs * 1.5);

  // Radial symmetry: the arm owning this sector plus the nearer neighbour, so glows and
  // bent tips cross the sector seams smoothly
  float fa = a / FS_SECTOR;
  float k0 = floor(fa + 0.5);
  float k1 = k0 + (fa > k0 ? 1.0 : -1.0);
  vec3 arms = featherArm(a, r, k0, px, expansion, flutterAmp, 1.0)
            + featherArm(a, r, k1, px, expansion, flutterAmp, 0.0);

  // Central radiant core
  float coreDist = length(p);
  float corePulse = 1.0 + kick * 0.4 + bass * 0.2;
  float coreGlow = exp(-coreDist * 12.0 / corePulse) * 0.4;
  float innerCore = exp(-coreDist * 35.0 / corePulse);
  // Faint 14-lobed calyx where the arms meet
  float lobes = 0.5 + 0.5 * cos(a * FS_ARMS);
  float calyx = exp(-fsSq((r - 0.045 - expansion * 0.6) / 0.010)) * (0.25 + 0.75 * lobes * lobes) * 0.22;

  vec3 color = env;
  // the redrawn arms carry more light per pixel than the original lines; 0.86 keeps the
  // original overall exposure with Player's real music levels
  color += arms * (1.2 + mids * 0.6) * 0.86;
  color += vec3(0.4, 0.9, 1.0) * coreGlow;
  color += mix(vec3(0.55, 0.95, 1.0), fsTone(palette60s(0.55 + time * 0.04)), 0.4) * calyx * (1.0 + kick * 0.6);
  color += vec3(1.0, 0.9, 1.0) * innerCore * (0.8 + kick * 0.8);

  // Vignette
  color *= smoothstep(1.6, 0.6, r);

  // Transition effects
  float identityPresence = transitionIdentityPresence();
  color *= identityPresence;

  vec3 prev = samplePreviousFrame(uv, p, feedbackRetain(0.82));
  color = prev * 0.35 + color;

  color += transitionTunnel(p);
  color = color / (1.0 + color * 0.4);
  color = pow(color, vec3(0.85));

  outColor = vec4(color, 1.0);
}
`;

  return [[97, {
    name: "Feather Star Ascension",
    source: fragmentSource
  }]];
}
