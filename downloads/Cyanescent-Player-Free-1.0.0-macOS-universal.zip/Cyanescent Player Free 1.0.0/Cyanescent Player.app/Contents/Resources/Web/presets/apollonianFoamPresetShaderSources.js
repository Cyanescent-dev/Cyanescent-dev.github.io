import { fullVisualizerSharedPrelude } from "./shaders/sharedPrelude.js";
import { fractalTempleShaderBlock } from "./shaders/fractalTempleShaderBlock.js";

const apollonianFoamShaderMain = `
vec2 apollonianFoamFeedbackUv(vec2 p) {
  float angle = atan(p.y, p.x);
  float radius = length(p);
  float transitionStrength = sin(clamp(transitionPhase, 0.0, 1.0) * PI);
  vec2 q = p;

  if (transitionStrength > 0.001) {
    float style = floor(transitionStyle + 0.5);
    if (style < 0.5) {
      float silk = sin(q.y * 3.2 + sin(q.x * 2.5 + time * 0.08) * 1.5 + time * 0.07);
      float cross = sin(q.x * 2.8 - time * 0.06 + silk * 0.5);
      q += vec2(silk, cross) * transitionStrength * 0.040 * feedbackStep;
      q += normalize(p + 0.0001) * transitionStrength * 0.018 * sin(radius * 9.0 - time * 0.16) * feedbackStep;
      q *= feedbackZoom(1.0 - transitionStrength * 0.066);
    } else if (style < 1.5) {
      q *= rot(transitionStrength * (0.070 + 0.025 * kickPulse + 0.010 * sin(radius * 8.0 + time * 1.4)) * feedbackStep);
      q *= feedbackZoom(1.0 - transitionStrength * (0.078 + kickPulse * 0.024));
      q += normalize(p + 0.0001) * transitionStrength * 0.018 * sin(16.0 * log(radius + 0.08) - time * 4.0) * feedbackStep;
    } else {
      float melt = sin(q.x * 3.4 + time * 0.07) * 0.18 + sin(q.y * 2.0 - time * 0.05) * 0.10;
      q += vec2(sin(q.y * 2.6 + time * 0.07) * 0.34, -0.54 + melt) * transitionStrength * 0.050 * feedbackStep;
      q *= feedbackZoom(1.0 + transitionStrength * 0.028);
    }
    return clamp(q * 0.5 + 0.5, vec2(0.001), vec2(0.999));
  }

  float spiral = sin(angle * 6.0 + time * 0.6 + bass * 2.0) * 0.007;
  q *= rot((0.004 + 0.018 * bass + 0.010 * sin(time * 0.15)) * feedbackStep);
  q *= feedbackZoom(0.994 - kick * 0.022 + spiral);
  q += normalize(p + 0.0001) * (0.002 * sin(radius * 18.0 - time * 2.0)) * feedbackStep;
  q.x = abs(q.x) * sign(sin(angle * 3.0 + time * 0.3));
  q *= rot((0.012 * sin(radius * 12.0 + time) + bass * 0.018) * feedbackStep);
  q += vec2(sin(q.y * 9.0 + time), cos(q.x * 8.0 - time)) * 0.0025 * (1.0 + level) * feedbackStep;
  return clamp(q * 0.5 + 0.5, vec2(0.001), vec2(0.999));
}

void main() {
  vec2 uv = gl_FragCoord.xy / resolution;
  vec2 p = (gl_FragCoord.xy * 2.0 - resolution) / min(resolution.x, resolution.y);
  vec2 vUv = uv;
  float mode = 5.0;
  float sens = sensitivity;
  float futureRise = clamp(futureEnergy - level, 0.0, 1.0);
  float futureFall = clamp(level - futureEnergy, 0.0, 1.0);
  float narrativeShift = smoothstep(0.18, 0.68, sectionChange);
  float phraseLift = smoothstep(0.42, 1.0, phrasePulse);
  float storyDrive = clamp(adaptiveIntensity + phraseLift * 0.22 + highEnergyState * 0.28 + dropState * 0.34, 0.0, 1.6);

  vec2 fuv = apollonianFoamFeedbackUv(p);
  vec2 futureWarp = normalize(p + vec2(0.0001)) * (futureRise * 0.010 - futureFall * 0.004 + phraseLift * 0.002) * feedbackStep;
  fuv = mix(fuv + futureWarp, 0.5 + (fuv - 0.5) * (1.0 + narrativeShift * 0.028), narrativeShift * 0.55);
  vec3 prev = samplePreviousFrame(fuv, p, feedbackRetain(0.934 + quality * 0.022 - narrativeShift * 0.018 + futureFall * 0.010));

  float wave = interference(p * (1.0 + 0.35 * bass));
  float fractal = julia(p * rot(time * 0.04 + bass * 0.25) * (1.25 + 0.3 * sin(time * 0.13)), vec2(-0.74 + 0.08 * sin(time * 0.17), 0.18 + 0.08 * cos(time * 0.11)));
  float foam = apollonian(p * (1.0 + 0.12 * sin(time * 0.3)));
  float organic = sin(7.0 * length(p) - time * 1.3 + wave * 2.4 + bass * 2.0);
  organic += sin((p.x + wave * 0.04) * 19.0 + sin(p.y * 9.0 + time));
  organic = smoothstep(0.25, 1.5, organic * 0.5 + 0.7);
  float field = foam * 1.35 + fractal * 0.25 + organic * 0.32;

  float r = length(p);
  float a = atan(p.y, p.x);
  float sparkle = smoothstep(0.986 - highs * 0.016 - futureDensity * 0.006, 1.0, hash(floor((p + 1.0) * resolution.y * 0.018 + time)));
  float collapse = exp(-r * (5.0 - kick * 2.0 - futureRise * 0.70)) * max(kick, futureRise * 0.42);
  collapse *= 0.68 + 0.32 * smoothstep(0.07, 0.28, r);
  float energy = clamp((level * 1.2 + kick * 1.55 + bass * 0.9 + mids * 0.52 + highs * 0.42) * sens, 0.0, 2.8);
  float fullOnHeat = clamp(smoothstep(0.52, 1.32, energy + futureEnergy * 0.46 + futureDensity * 0.64 + bass * 0.30 + storyDrive * 0.22) + mainRiffState * 0.52 + dropState * 0.32 + highEnergyState * 0.24, 0.0, 1.45);
  float dropHeat = max(smoothstep(0.45, 1.28, energy + kick * 0.88 + bass * 0.44 + futureRise * 0.95 + narrativeShift * 0.28 + phraseLift * 0.18), max(dropState, buildUpState * 0.38));
  float beatHeat = smoothstep(0.34, 1.04, kick * 1.35 + bass * 0.66 + highs * 0.28 + futureDensity * 0.28 + phraseLift * 0.16);
  float surgeHeat = max(dropHeat, fullOnHeat * 0.82);
  float organicPulse = 0.5 + 0.5 * sin(time * (0.34 + futureDensity * 0.55) + sin(p.x * 2.6 + time * 0.17) + cos(p.y * 2.2 - time * 0.13));

  float futureHue = futureBrightness * 0.26 + futureDensity * 0.13 + narrativeShift * 0.10;
  vec3 color = palette(time * 0.035 + brightness * 0.35 + field * 0.22 + mode * 0.18 + futureHue);
  vec3 quantumLine = vec3(0.5, 0.95, 0.95) * smoothstep(0.91, 1.0, abs(wave));
  vec3 draw = color * field * (0.32 + energy * 0.58);

  draw += quantumLine * (0.08 + brightness * 0.2);
  draw += vec3(1.0, 0.86, 0.48) * collapse * (0.52 + sens * 0.14);
  draw += vec3(0.78, 0.96, 1.0) * sparkle * highs * (0.4 + quality);

  float ambientWeave = smoothstep(0.80, 1.0, abs(sin(p.x * 5.2 + sin(p.y * 3.8 + time * 0.16) * 1.8 - time * 0.22)));
  ambientWeave *= exp(-r * 0.72);
  float ambientOrbit = smoothstep(0.78, 1.0, sin(a * 5.0 + r * 8.0 - time * 0.18)) * exp(-r * 1.15);
  float detailGuard = 1.0 - smoothstep(0.72, 1.8, field);
  draw += palette60s(0.36 + a / (PI * 2.0) + time * 0.006 + mode * 0.031) * (ambientWeave * 0.030 + ambientOrbit * 0.020) * (0.45 + detailGuard * 0.55);

  float dropShock = smoothstep(0.72, 1.0, sin(42.0 * r - time * (2.35 + dropHeat * 3.0) + bass * 5.0)) * exp(-r * (1.10 - dropHeat * 0.18));
  float riffPlasma = smoothstep(0.60, 1.0, sin(p.x * 7.5 + sin(p.y * 5.4 + time * 0.42) * 2.6 + time * (0.45 + fullOnHeat)));
  riffPlasma *= smoothstep(1.48, 0.12, r) * organicPulse;
  float beatConstellation = fallingGlyphLayer(p, mode, fullOnHeat) * smoothstep(0.08, 1.0, beatHeat + surgeHeat * 0.35);
  draw *= 1.0 + fullOnHeat * 0.40 + dropHeat * 0.62;
  draw += palette60s(0.10 + a / (PI * 2.0) + time * 0.030) * dropShock * dropHeat * 0.42;
  draw += palette60s(0.54 + futureBrightness * 0.32 + time * 0.017) * riffPlasma * fullOnHeat * 0.18;
  draw += palette60s(0.84 + time * 0.065 + a * 0.03) * beatConstellation * beatHeat * surgeHeat * 0.42;

  float bliss = clamp(breakdownState, 0.0, 1.0);
  float aurora = smoothstep(0.42, 1.0, sin(p.y * 4.2 + sin(p.x * 3.0 + time * 0.18) * 2.0 + time * 0.22));
  aurora *= exp(-r * 0.72) * (0.52 + 0.48 * organicPulse);
  float innerLight = exp(-r * (2.15 + 0.30 * sin(time * 0.11))) * (0.55 + 0.45 * sin(time * 0.17 + p.y * 2.0));
  float breathLines = smoothstep(0.80, 1.0, abs(sin(a * 9.0 + r * 5.0 - time * 0.20))) * exp(-r * 1.45);
  draw = mix(draw, draw * 0.58 + palette60s(0.28 + time * 0.006 + r * 0.16) * aurora * 0.28, bliss);
  draw += mix(vec3(0.42, 0.62, 0.78), palette60s(0.15 + time * 0.004), 0.42) * innerLight * bliss * 0.28;
  draw += palette60s(0.62 + a / (PI * 2.0) + time * 0.006) * breathLines * bliss * 0.10;

  float phraseShell = exp(-abs(r - mix(0.24, 1.08, phraseProgress)) * (5.2 + storyDrive * 2.6)) * phraseLift;
  float buildVeil = smoothstep(0.74, 1.0, sin(a * 11.0 + r * 7.0 - time * (0.22 + buildUpState * 0.55))) * exp(-r * 1.18);
  float calmMist = smoothstep(0.38, 1.0, sin(p.y * 3.0 + sin(p.x * 2.4 + time * 0.12) * 2.2 + time * 0.11)) * exp(-r * 0.90);
  draw += palette60s(0.04 + beatPhase * 0.18 + a / (PI * 2.0) + time * 0.008) * phraseShell * (0.10 + storyDrive * 0.14);
  draw += palette60s(0.22 + futureBrightness * 0.30 + time * 0.012) * buildVeil * buildUpState * 0.11;
  draw = mix(draw, draw * 0.78 + palette60s(0.54 + r * 0.20 + time * 0.004) * calmMist * 0.18, calmState * 0.34);

  float anticipationRing = smoothstep(0.74, 1.0, sin(24.0 * r - time * (0.55 + futureEnergy * 1.45) + futureDensity * 4.0)) * exp(-r * (1.35 + futureFall * 1.20));
  float sectionHalo = exp(-abs(r - (0.36 + futureBrightness * 0.30)) * (5.0 - narrativeShift * 1.3)) * narrativeShift;
  draw += palette60s(0.48 + futureBrightness * 0.28 + time * 0.010) * anticipationRing * (futureRise * 0.18 + futureDensity * 0.045);
  draw += palette60s(0.08 + energyTrend * 0.30 + time * 0.016) * sectionHalo * 0.16;
  draw *= transitionIdentityPresence();
  draw += transitionTunnel(p);

  vec3 finalColor = prev + draw;
  finalColor = blendPresetBackground(finalColor, vUv, 0.78);
  finalColor *= 0.995 - r * 0.018;
  finalColor = finalColor / (1.0 + finalColor * 0.48);
  float luma = max(finalColor.r, max(finalColor.g, finalColor.b));
  finalColor = mix(finalColor, finalColor / (1.0 + luma * 0.42), smoothstep(0.82, 1.45, luma) * 0.34);
  finalColor = pow(max(finalColor, vec3(0.0)), vec3(0.88));
  outColor = vec4(finalColor, 1.0);
}
`;

export function createApollonianFoamPresetShaderEntries({ modularTransitionShaderBlock }) {
  const apollonianFoamFragmentSource = `${fullVisualizerSharedPrelude}
${modularTransitionShaderBlock}
${fractalTempleShaderBlock}
${apollonianFoamShaderMain}`;

  return [[5, { name: "Apollonian Foam", source: apollonianFoamFragmentSource }]];
}
