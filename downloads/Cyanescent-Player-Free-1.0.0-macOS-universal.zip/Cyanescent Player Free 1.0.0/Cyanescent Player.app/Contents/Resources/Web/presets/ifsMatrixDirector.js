// Audio-Reactive IFS Matrix (preset 166): the director behind the living fractal matrix.
//
// The world is the original repeated distance field: one Menger-variant cube per 6-unit lattice
// cell, every cube sharing one orientation. The director never edits that geometry directly. It
// supplies smooth, integrated state that the shader reads per cell:
//   - the camera journey: pure-pursuit steering along the lattice's free corridors (the lines
//     through the cell corners, 4.2 units from every cube centre), with musical speed, sway,
//     glances at nearby formations and rounded 90-degree turns at corridor intersections;
//   - the lattice orientation (an integrated quaternion, never reset) and the fold shape;
//   - breathing groups (a slow plane wave of scale across the lattice);
//   - up to six travelling spherical wave fronts (kick ripples from a cube ahead, converging build
//     shells, the drop's outward expansion, slow breakdown swells) that scale and light every cube
//     they pass;
//   - the palette, which moves with the musical sections rather than cycling.
// Everything the shader reads is integrated or slew-limited, so state changes never jump.
// Offline export replays it from the preset start at a fixed 120 Hz (identical at any frame rate).
import { follow } from "../engine/newtonBasinAudio.js";
import { createOfflineAnimationClock } from "../engine/offlineAnimationClock.js";

export const IFS_MATRIX_PRESET_ID = 166;

export const IFS = Object.freeze({
  cell: 6,
  rObj: 1.5,         // cube bound (the original's sphere clip) at scale 1
  sMax: 1.3,         // cell scale clamp in the shader
  look: 4.5,         // pursuit carrot distance (sets the turn radius)
  swayMax: 1.3,      // lateral wander inside a corridor
  clear: 0.9,        // minimum camera clearance from any cube bound
  waves: 6,          // 0-2 kick ripples, 3-5 structural waves
  step: 1 / 120,
  recentre: 240      // shift the shader origin by whole cells beyond this distance
});

const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, Number.isFinite(x) ? x : a));
const smooth01 = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
const frac = (x) => x - Math.floor(x);
const hash = (n) => frac(Math.sin(n * 127.1 + 311.7) * 43758.5453);
const TAU = Math.PI * 2;
const BREATH = [0.21, 0.13, 0.17];   // breathing direction * wavenumber

// --- small vector helpers (arrays of 3) ---------------------------------------------------------
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const len = (a) => Math.hypot(a[0], a[1], a[2]);
const norm = (a) => { const l = len(a); return l > 1e-9 ? mul(a, 1 / l) : [0, 0, 1]; };
const mix3 = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const follow3 = (a, b, dt, tau) => mix3(a, b, 1 - Math.exp(-dt / Math.max(1e-4, tau)));
const rotateAbout = (v, axis, ang) => {
  const c = Math.cos(ang), s = Math.sin(ang), k = dot(axis, v);
  const cr = cross(axis, v);
  return [v[0] * c + cr[0] * s + axis[0] * k * (1 - c), v[1] * c + cr[1] * s + axis[1] * k * (1 - c), v[2] * c + cr[2] * s + axis[2] * k * (1 - c)];
};

// --- quaternions [w, x, y, z] ------------------------------------------------------------------
export const qmul = (a, b) => [
  a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
  a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
  a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
  a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]
];
export const qslerp = (a, b, k) => {
  let d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
  if (d < 0) { b = b.map((v) => -v); d = -d; }
  if (d > 0.9995) return qnorm(a.map((v, i) => v + (b[i] - v) * k));
  const th = Math.acos(d), sa = Math.sin((1 - k) * th) / Math.sin(th), sb = Math.sin(k * th) / Math.sin(th);
  return qnorm(a.map((v, i) => v * sa + b[i] * sb));
};
export const qnorm = (q) => { const l = Math.hypot(q[0], q[1], q[2], q[3]) || 1; return q.map((v) => v / l); };
// integrate a world-space angular velocity w over dt
export const qintegrate = (q, w, dt) => {
  const a = len(w) * dt;
  if (a < 1e-9) return q;
  const ax = mul(w, 1 / len(w)), s = Math.sin(a / 2);
  return qnorm(qmul([Math.cos(a / 2), ax[0] * s, ax[1] * s, ax[2] * s], q));
};
// rotation matrix (body -> world) as rows
export const qmat = (q) => {
  const [w, x, y, z] = q;
  return [
    [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
    [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
    [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]
  ];
};
// GLSL mat3 (column-major) mapping world -> body: the transpose of body -> world, whose columns are
// the body -> world rows, so the column-major array is those rows in order.
export const glWorldToBody = (q) => { const m = qmat(q); return [...m[0], ...m[1], ...m[2]]; };

// Palette positions (cyclic, period 4): 0 cyan, 1 iridescent blue, 2 deep violet, 3 magenta.
const PAL = { cyan: 0, blue: 1, violet: 2, magenta: 3 };
const wrapPal = (x) => ((x % 4) + 4) % 4;
const palDelta = (from, to) => { let d = wrapPal(to) - wrapPal(from); if (d > 2) d -= 4; if (d < -2) d += 4; return d; };

export function createIfsMatrixDirector() {
  const s = {};
  const uniforms = {};

  function reset() {
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0, carry: 0,
      // musical envelopes
      energy: 0.5, bassSlow: 0.4, bassMid: 0.4, midsSlow: 0.4, highs: 0, kick: 0, kickLight: 0,
      calm: 0, drive: 0.4, build: 0, buildHeld: 0, buildRaw: 0, antic: 0, dropEnv: 0, released: 0,
      flash: 0, mood: "groove", lastDropAt: -1e9, dropStrength: 0, recovery: 0,
      prevAge: null, prevDetected: 0, prevKick: 0, lastKickAt: -1e9, kickCount: 0,
      prevBeat: null, beatLen: 60 / 145, beats: 0, lastBar: 0,
      // camera
      pos: [3, 3, -4], dir: [0, 0, 1], look: [0, 0, 1], up: [0, 1, 0], bank: 0, v: 1.0, focal: 1.55,
      axis: 2, sign: 1, line: [3, 3, 0], sway: [0, 0], swayPh: [0.3, 1.7], swayAmp: 0.8,
      turn: null, lastTurnAt: 0, turnsTaken: 0, nextNode: null,
      glanceAt: [0, 0, 12], glanceW: 0, glanceIdx: 0, glanceSince: 0,
      origin: [0, 0, 0],
      // lattice
      rot: qnorm([0.92, 0.18, 0.3, 0.12]), rotRate: 0.2, rotAxisPh: 0.4,
      breathPh: 0, breathAmp: 0.04, zfold: 0.5, offset: 2.0,
      // colour
      pal: PAL.blue, palGoal: PAL.blue, gold: 0, depth: 0, sat: 0.85, colourPh: 0, shimmer: 0,
      exposure: 1, glow: 1,
      // waves: { o:[x,y,z] (world), r, v, w, amp, light, hue, life, age }
      waves: Array.from({ length: IFS.waves }, () => null), kickSlot: 0, waveSlot: 3,
      lastBuildWaveBar: -1, lastSwellAt: -1e9, latW: [0, 0, 0],
      hero: { phase: 0, endAt: -1e9, cells: [], dice: [], emphasis: 0, weight: 0, room: 0, count: 0, rb: 0, reveal: 0, revealKick: 0, revealAt: 0,
        phaseAt: 0, dropAt: 0, lastBeats: null, lastImpulse: 0, centroid: [0, 0, 0], spawn: null }
    });
  }
  reset();

  // ---------------------------------------------------------------------------------------------
  // lattice helpers
  const cellCentre = (p) => p.map((x) => Math.round(x / IFS.cell) * IFS.cell);
  function clearance(p) {
    const c0 = cellCentre(p);
    let best = 1e9;
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) for (let k = -1; k <= 1; k++) {
      const c = [c0[0] + i * IFS.cell, c0[1] + j * IFS.cell, c0[2] + k * IFS.cell];
      best = Math.min(best, len(sub(p, c)) - IFS.rObj * IFS.sMax);
    }
    return best;
  }
  function nearestCube(p) {
    const c0 = cellCentre(p);
    let best = null, bd = 1e9;
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) for (let k = -1; k <= 1; k++) {
      const c = [c0[0] + i * IFS.cell, c0[1] + j * IFS.cell, c0[2] + k * IFS.cell];
      const d = len(sub(p, c));
      if (d < bd) { bd = d; best = c; }
    }
    return best;
  }

  function spawnWave(slot, wave) {
    s.waves[slot] = { r: 0, v: 8, w: 2, amp: 0.06, light: 0.6, hue: 0, life: 2, age: 0, ...wave };
  }
  function structuralSlot() {
    // reuse the oldest (or an empty) structural slot
    let best = 3, bestAge = -1;
    for (let i = 3; i < IFS.waves; i++) {
      const w = s.waves[i];
      if (!w) return i;
      const age = w.age / w.life;
      if (age > bestAge) { bestAge = age; best = i; }
    }
    return best;
  }


  // ---------------------------------------------------------------------------------------------
  // The cosmic dice hero. Three prominent cubes ahead of the camera leave the lattice (the shader
  // stops drawing their cells) and continue as world-space dice: at hand-over each die has its
  // cell's exact position, scale and orientation, so nothing jumps. Each die then has its own
  // quaternion, integrated from a world-space angular velocity that the beats kick; a spring
  // settles it onto the nearest orientation that shows a face to the camera, and the return spring
  // brings it back onto an orientation equivalent (by the cube's symmetry) to the lattice's own,
  // at its cell centre and cell scale, before the cell takes over again.
  // Phases: 0 idle, 1 anticipation (chosen cubes glow; still lattice cubes), 2 roll, 3 settle,
  // 4 reveal, 5 return.
  const HERO = Object.freeze({ rollBeats: 16, settleBeats: 4, revealBeats: 8, returnBeats: 10,
    cooldown: 40, lift: 1.1, grow: 1.3, count: 3, ahead: 14.5 });

  const waveFade = (w) => smooth01(w.age / 0.25) * (1 - smooth01((w.age - w.life * 0.55) / (w.life * 0.45)));
  // JS mirror of the shader's cellState(c).x
  function cellScale(c) {
    let sc = 1 + s.breathAmp * Math.sin(dot(c, BREATH) - s.breathPh);
    for (const w of s.waves) {
      if (!w) continue;
      const x = (len(sub(c, w.o)) - w.r) / Math.max(0.5, w.w);
      sc += w.amp * waveFade(w) * Math.exp(-x * x);
    }
    // cubes near the camera make room while the dice are out
    sc *= 1 - 0.28 * s.hero.room * (1 - smooth01((len(sub(c, s.pos)) - 8) / 5));
    return clamp(sc, 0.72, 1.3);
  }

  function cameraFrame() {
    const right = norm(cross(s.up, s.look));
    return { right, up: cross(s.look, right), fwd: s.look };
  }

  // choose up to three cells around the view, `ahead` units in front of `from` (+-4)
  function chooseCells(from, ahead) {
    const { right, up, fwd } = cameraFrame();
    const centre = add(from, mul(fwd, ahead));
    const c0 = cellCentre(centre);
    const cands = [];
    for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++) for (let k = -2; k <= 2; k++) {
      const c = [c0[0] + i * IFS.cell, c0[1] + j * IFS.cell, c0[2] + k * IFS.cell];
      const rel = sub(c, from);
      const along = dot(rel, fwd);
      if (along < ahead - 4.5 || along > ahead + 6) continue;
      const x = dot(rel, right), y = dot(rel, up);
      const ang = Math.hypot(x, y) / along;
      if (ang < 0.14 || ang > 0.34) continue;
      cands.push({ c, along, ang, polar: Math.atan2(y, x), score: Math.abs(along - ahead) * 0.15 + Math.abs(ang - 0.24) * 2 });
    }
    cands.sort((a, b) => a.score - b.score);
    const chosen = [];
    for (const cand of cands) {
      if (chosen.every((o) => Math.abs(Math.atan2(Math.sin(o.polar - cand.polar), Math.cos(o.polar - cand.polar))) > 1.15)) chosen.push(cand);
      if (chosen.length === HERO.count) break;
    }
    return chosen.map((o) => o.c);
  }

  // rotation matrices as rows; m3mul(a, b) = a * b
  const m3mul = (a, b) => a.map((row) => [0, 1, 2].map((j) => row[0] * b[0][j] + row[1] * b[1][j] + row[2] * b[2][j]));
  const m3T = (a) => [0, 1, 2].map((i) => [a[0][i], a[1][i], a[2][i]]);
  const PERMS = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]];
  const SIGNED = [];
  for (const pm of PERMS) for (let sg = 0; sg < 8; sg++) {
    const m = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    for (let i = 0; i < 3; i++) m[i][pm[i]] = sg & (1 << i) ? -1 : 1;
    const det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    if (det > 0) SIGNED.push(m);
  }
  function quatFromMat(m) {
    const tr = m[0][0] + m[1][1] + m[2][2];
    let q;
    if (tr > 0) { const S = Math.sqrt(tr + 1) * 2; q = [0.25 * S, (m[2][1] - m[1][2]) / S, (m[0][2] - m[2][0]) / S, (m[1][0] - m[0][1]) / S]; }
    else if (m[0][0] > m[1][1] && m[0][0] > m[2][2]) { const S = Math.sqrt(1 + m[0][0] - m[1][1] - m[2][2]) * 2; q = [(m[2][1] - m[1][2]) / S, 0.25 * S, (m[0][1] + m[1][0]) / S, (m[0][2] + m[2][0]) / S]; }
    else if (m[1][1] > m[2][2]) { const S = Math.sqrt(1 + m[1][1] - m[0][0] - m[2][2]) * 2; q = [(m[0][2] - m[2][0]) / S, (m[0][1] + m[1][0]) / S, 0.25 * S, (m[1][2] + m[2][1]) / S]; }
    else { const S = Math.sqrt(1 + m[2][2] - m[0][0] - m[1][1]) * 2; q = [(m[1][0] - m[0][1]) / S, (m[0][2] + m[2][0]) / S, (m[1][2] + m[2][1]) / S, 0.25 * S]; }
    return qnorm(q);
  }
  // the symmetric equivalent of `frame * P` (P a cube rotation) closest to body->world R;
  // `penalty(P)` lets the reveal prefer faces the other dice are not showing
  function nearestSymmetric(R, frame, penalty = () => 0) {
    const M = m3mul(m3T(frame), R);
    let best = null, bs = -1e9;
    for (const P of SIGNED) {
      let tr = 0;
      for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) tr += P[i][j] * M[i][j];
      const sc = tr - penalty(P);
      if (sc > bs) { bs = sc; best = P; }
    }
    return best;
  }
  // body axis -> face value (opposite faces sum to seven): +x 1, -x 6, +y 2, -y 5, +z 3, -z 4
  const faceValue = (axis, sign) => [[1, 6], [2, 5], [3, 4]][axis][sign > 0 ? 0 : 1];
  // the face whose outward normal maps to the camera direction under frame * P (third frame column)
  function facingValue(P) {
    // world = frame * P * body: the body axis that P sends to frame row 2 (towards the camera)
    for (let j = 0; j < 3; j++) if (P[2][j] !== 0) return faceValue(j, P[2][j]);
    return 1;
  }
  const rotError = (qt, q) => {
    let e = qmul(qt, [q[0], -q[1], -q[2], -q[3]]);
    if (e[0] < 0) e = e.map((v) => -v);
    const sv = Math.hypot(e[1], e[2], e[3]);
    if (sv < 1e-9) return [0, 0, 0];
    const ang = 2 * Math.atan2(sv, e[0]);
    return [e[1] / sv * ang, e[2] / sv * ang, e[3] / sv * ang];
  };

  // a frame (as rows) whose third axis points from the die to the camera, upright on screen
  function facingFrame(p, frame) {
    const bk = norm(sub(s.pos, p));
    const rt = norm(cross(frame.up, bk));
    const upv = cross(bk, rt);
    return [[rt[0], upv[0], bk[0]], [rt[1], upv[1], bk[1]], [rt[2], upv[2], bk[2]]];
  }

  function heroEligible() { return s.hero.phase === 0 && s.time - s.hero.endAt > HERO.cooldown; }

  function heroAnticipate(cells, dropAt) {
    const h = s.hero;
    h.phase = 1; h.dropAt = dropAt; h.cells = cells; h.phaseAt = s.time;
  }

  function heroLaunch() {
    const h = s.hero;
    if (h.phase !== 1 || !h.cells.length) {
      h.cells = chooseCells(s.pos, HERO.ahead);
      if (h.cells.length < 2) { h.phase = 0; return false; }
    }
    const { right, up } = cameraFrame();
    h.phase = 2; h.phaseAt = s.time; h.beat0 = s.beats; h.rb = 0; h.lastBeats = s.beats; h.beatSeenAt = s.time; h.lastImpulse = 0; h.count += 1;
    h.dice = h.cells.map((c, i) => {
      const sc = cellScale(c);
      // spin: a drop launch about an axis across the view, different per die
      const axis = norm(add(mul(right, Math.cos(i * 2.1 + h.count)), mul(up, Math.sin(i * 2.1 + h.count) * 0.8)));
      return { home: c, pos: [...c], vel: [0, 0, 0], q: [...s.rot], w: add(mul(axis, 4.2 + 0.8 * i), s.latW),
        scale: sc, amt: 0, pip: 0, hop: 0, hopAt: -1, P: null, value: 0 };
    });
    h.reveal = 0; h.revealKick = 0;
    return true;
  }

  function heroStep(dt, ev) {
    const h = s.hero;
    // ---- anticipation: plan the hero for a known major drop --------------------------------------
    if (ev.known && heroEligible() && ev.nextMajor && ev.dropIn > 1.5 && ev.dropIn < 6.5) {
      // predict where the camera will be at the drop (it eases towards ~0.85 units/s)
      const cells = chooseCells(s.pos, HERO.ahead + 0.5 * (s.v + 0.85) * ev.dropIn);
      if (cells.length >= 2) heroAnticipate(cells, s.time + ev.dropIn);
    }
    if (h.phase === 1) {
      // the drop moved (seek, re-analysis) or never came: stand down smoothly
      if (ev.known && (!ev.nextMajor || Math.abs(s.time + ev.dropIn - h.dropAt) > 1.5) && !ev.dropNow) h.phase = 0;
      if (s.time > h.dropAt + 1.5) h.phase = 0;
    }
    if (ev.dropNow && ev.strength >= 1 && (h.phase === 1 || heroEligible())) heroLaunch();
    h.emphasis = follow(h.emphasis, h.phase === 1 ? smooth01((s.time - h.phaseAt) / 3) : 0, dt, 0.6, 0.8);
    h.room = follow(h.room, Math.max(h.weight, 0.7 * h.emphasis), dt, 0.8, 2.0);
    if (h.phase < 2) { h.weight = follow(h.weight, 0, dt, 1, 1.5); return; }

    // ---- roll, settle, reveal, return ------------------------------------------------------------
    const db = Math.max(0, s.beats - (h.lastBeats ?? s.beats));
    h.lastBeats = s.beats;
    // beats drive the sequence; if the beat grid stalls it still progresses at half tempo
    if (db > 0) h.beatSeenAt = s.time;
    h.rb += s.time - (h.beatSeenAt ?? s.time) > 1 ? dt / s.beatLen : db;
    const tRoll = HERO.rollBeats, tSettle = tRoll + HERO.settleBeats, tReveal = tSettle + HERO.revealBeats, tEnd = tReveal + HERO.returnBeats;
    const prevPhase = h.phase;
    h.phase = h.rb < tRoll ? 2 : h.rb < tSettle ? 3 : h.rb < tReveal ? 4 : 5;
    h.weight = follow(h.weight, h.phase < 5 ? 1 : 0, dt, 0.8, 2.5);
    const frame = cameraFrame();
    const back = mul(frame.fwd, -1);
    const centroid = mul(h.dice.reduce((a, d) => add(a, d.pos), [0, 0, 0]), 1 / h.dice.length);
    h.centroid = centroid;

    // impulses on the beat grid: every beat early in the roll, every other beat as it matures,
    // weakening so that momentum develops and resolves
    const beatIdx = Math.floor(h.rb);
    if (h.phase === 2 && beatIdx > h.lastImpulse) {
      h.lastImpulse = beatIdx;
      const every = beatIdx < 8 ? 1 : 2;
      if (beatIdx % every === 0) {
        const strength = (1 - beatIdx / tRoll) * (0.6 + 0.6 * Math.max(s.kick, 0.4));
        h.dice.forEach((d, i) => {
          // face-over-face tumbles: about the camera's right, up or a diagonal, varied per die
          const k = (beatIdx + i * 2) % 4;
          const axis = k === 0 ? frame.right : k === 1 ? frame.up : k === 2 ? norm(add(frame.right, frame.up)) : norm(sub(frame.right, mul(frame.fwd, 0.7)));
          const sign = hash(beatIdx * 3.1 + i * 7.7 + h.count) < 0.5 ? -1 : 1;
          d.w = add(d.w, mul(axis, sign * 3.6 * strength));
          d.hopAt = h.rb; d.hop = 0.55 * strength;
        });
      }
    }
    if (h.phase === 3 && prevPhase === 2) {
      // choose each die's resting orientation: a face towards the camera, preferring faces the
      // other dice are not showing
      const used = [];
      for (const d of h.dice) {
        const camFrame = facingFrame(d.pos, frame);
        d.P = nearestSymmetric(qmat(d.q), camFrame, (P) => used.includes(facingValue(P)) ? 1.4 : 0);
        d.value = facingValue(d.P);
        used.push(d.value);
      }
    }
    if (h.phase === 5 && prevPhase !== 5) {
      for (const d of h.dice) d.P = nearestSymmetric(qmat(d.q), qmat(s.rot));
    }
    if (h.phase === 4 && prevPhase !== 4) { h.revealKick = 1; h.revealAt = s.time; h.spawn = "reveal"; }
    if (h.phase === 5 && prevPhase !== 5) h.spawn = "return";
    // the reveal's pulse swells over a few frames and fades over ~2 s
    h.reveal = follow(h.reveal, h.revealKick, dt, 0.12, 1.6);
    h.revealKick *= Math.exp(-dt / 0.3);

    for (const [i, d] of h.dice.entries()) {
      // morph: fractal -> die over the first two beats; die -> fractal through the return
      const amtGoal = h.phase < 5 ? 1 : 0;
      d.amt = h.phase < 5 ? Math.min(1, d.amt + dt / (2 * s.beatLen)) : Math.max(0, d.amt - dt / (6 * s.beatLen));
      d.amt = amtGoal ? d.amt : d.amt;
      d.pip = follow(d.pip, h.phase >= 3 && h.phase < 5 ? 1 : h.phase === 2 ? 0.45 : 0, dt, 0.5, 1.2);

      // orientation
      if (h.phase === 2) {
        d.w = mul(d.w, Math.exp(-dt / 1.1));
      } else {
        let target;
        if (h.phase === 5) target = quatFromMat(m3mul(qmat(s.rot), d.P));
        else {
          const camFrame = facingFrame(d.pos, frame);
          target = quatFromMat(m3mul(camFrame, d.P));
        }
        const wn = h.phase === 3 ? 2.6 : h.phase === 4 ? 4 : 2.2;
        const e = rotError(target, d.q);
        const wTarget = h.phase === 5 ? s.latW : [0, 0, 0];
        d.w = add(d.w, mul(sub(mul(e, wn * wn), mul(sub(d.w, wTarget), 2 * wn)), dt));
      }
      d.q = qintegrate(d.q, d.w, dt);

      // position: lifted towards the camera's line of sight, hopping on the impulses
      const toAxis = sub(d.home, add(s.pos, mul(frame.fwd, dot(sub(d.home, s.pos), frame.fwd))));
      const liftDir = mul(norm(toAxis), -1);
      const lift = h.phase < 5 ? HERO.lift * smooth01(Math.min(1, (h.rb) / 3)) : 0;
      const hx = d.hopAt >= 0 ? (h.rb - d.hopAt) / 0.9 : 1;
      const hop = hx < 1 ? 4 * hx * (1 - hx) * d.hop : 0;
      const goal = add(add(d.home, mul(liftDir, lift)), mul(frame.up, hop + (h.phase === 4 ? 0.12 * Math.sin((s.time - h.revealAt) * 1.6 + i) : 0)));
      const pn = h.phase === 5 ? 1.6 : 3.2;
      d.vel = add(d.vel, mul(sub(mul(sub(goal, d.pos), pn * pn), mul(d.vel, 2 * pn)), dt));
      d.pos = add(d.pos, mul(d.vel, dt));
      // scale: grows into an enormous die, returns to the cell's live scale
      const scGoal = h.phase < 5 ? HERO.grow : cellScale(d.home);
      d.scale = follow(d.scale, scGoal, dt, 0.9, h.phase === 5 ? 1.0 : 0.9);
      if (h.phase === 5) {
        // the last four beats blend exactly onto the cell's live state, so the hand-back is exact
        const f = smooth01((h.rb - (tEnd - 4)) / 4);
        if (f > 0) {
          d.pos = mix3(d.pos, d.home, f);
          d.vel = mul(d.vel, 1 - f);
          d.scale += (cellScale(d.home) - d.scale) * f;
          d.q = qslerp(d.q, quatFromMat(m3mul(qmat(s.rot), d.P)), f);
          d.w = mix3(d.w, s.latW, f);
        }
      }
    }

    if (h.phase === 5 && h.rb >= tEnd) {
      // hand back once every die sits on its cell (it has converged by now; any residue is tiny)
      // every die now sits exactly on its cell (position, scale, orientation up to the cube's
      // symmetry) and is a plain fractal cube again
      h.residual = Math.max(...h.dice.map((d) => len(sub(d.pos, d.home)) + Math.abs(d.scale - cellScale(d.home)) + len(rotError(quatFromMat(m3mul(qmat(s.rot), d.P)), d.q)) + d.amt));
      {
        h.phase = 0; h.endAt = s.time; h.dice = []; h.cells = [];
      }
    }
  }

  // ---------------------------------------------------------------------------------------------
  function musical(dt, input) {
    const { audio = {}, smooth = {}, music = {} } = input;
    s.energy = follow(s.energy, clamp(Number(audio.globalEnergy)), dt, 0.6, 1.4);
    s.bassSlow = follow(s.bassSlow, clamp(Number(smooth.bass)), dt, 1.6, 2.4);
    s.bassMid = follow(s.bassMid, clamp(Number(smooth.bass)), dt, 0.25, 0.6);
    s.midsSlow = follow(s.midsSlow, clamp(Number(smooth.mids)), dt, 1.2, 1.8);
    s.highs = follow(s.highs, clamp(Number(smooth.highs)), dt, 0.08, 0.35);
    const kp = clamp(Number(audio.kickPulse));
    s.kick = Math.max(s.kick * Math.exp(-dt / 0.14), kp);
    const calmGoal = clamp(Math.max(clamp(Number(music.breakdown)), clamp(Number(music.calm))) * 1.3 - 0.15);
    s.calm = follow(s.calm, calmGoal, dt, 2.2, 2.0);
    s.drive = follow(s.drive, clamp(0.6 * clamp(Number(music.highEnergy)) + 0.4 * s.energy), dt, 1.4, 2.6);

    // beat grid (robust to seeks: only small forward steps count)
    const beat = Number(music.absoluteBeat);
    if (Number.isFinite(beat) && s.prevBeat !== null) {
      const db = beat - s.prevBeat;
      if (db > 0 && db < 0.5) {
        s.beats += db;
        if (dt > 0) s.beatLen = follow(s.beatLen, clamp(dt / db, 0.3, 0.75), dt, 4, 4);
      }
    }
    s.prevBeat = Number.isFinite(beat) ? beat : null;

    // builds: real analysis reports brief builds inside drives and keeps buildUp high after a
    // drop, so a build needs to be held, and is suppressed while a drop is being released
    const bu = clamp(Number(music.buildUp));
    s.buildRaw = bu;
    if (bu > 0.55 && s.released <= 0) s.buildHeld += dt; else if (bu < 0.35 || s.released > 0) s.buildHeld = Math.max(0, s.buildHeld - dt * 3);
    const buildGoal = s.released > 0 ? 0 : smooth01((s.buildHeld - 1.2) / 5);
    s.build = follow(s.build, buildGoal, dt, 1.2, 1.6);
    s.released = Math.max(0, s.released - dt);

    // anticipation: the Drop Map when it is known, otherwise Player's upcomingDrop
    const known = Number(music.dropKnown) > 0.5;
    let anticGoal = 0;
    const dropIn = clamp(Number(music.dropIn), 0, 64);
    const next = clamp(Number(music.dropNextStrength));
    if (known) {
      if (next > 0) anticGoal = smooth01((9 - dropIn) / 7) * (next >= 1 ? 1 : 0.55);
    } else {
      anticGoal = smooth01((clamp(Number(music.upcomingDrop)) - 0.4) / 0.45) * 0.8;
    }
    if (s.released > 0) anticGoal = 0;
    s.antic = follow(s.antic, anticGoal, dt, 0.9, 0.5);

    // drop events
    let dropNow = false, strength = 0;
    if (known) {
      const age = clamp(Number(music.dropAge), 0, 64);
      const last = clamp(Number(music.dropLastStrength));
      if (s.prevAge !== null && age < s.prevAge - 0.2 && age < 0.75 && last > 0) { dropNow = true; strength = last; }
      s.prevAge = age;
    } else {
      s.prevAge = null;
      const detected = Math.max(clamp(Number(audio.dropDetected)), clamp(Number(music.drop)));
      if (detected > 0.6 && s.prevDetected <= 0.6 && s.time - s.lastDropAt > 16) {
        dropNow = true;
        // a live drop after a held build counts as major
        strength = s.build > 0.5 || s.antic > 0.4 ? 1 : 0.5;
      }
      s.prevDetected = detected;
    }
    if (dropNow) {
      s.lastDropAt = s.time; s.dropStrength = strength;
      s.dropEnv = Math.max(s.dropEnv, strength >= 1 ? 1 : 0.65);
      s.flash = Math.max(s.flash, strength >= 1 ? 1 : 0.6);
      s.released = strength >= 1 ? 9 : 6;
      s.buildHeld = 0;
    }
    s.dropEnv *= Math.exp(-dt / 5.5);
    s.flash *= Math.exp(-dt / 0.9);
    s.recovery = s.time - s.lastDropAt < 14 ? smooth01((s.time - s.lastDropAt - 4) / 4) * (1 - smooth01((s.time - s.lastDropAt - 10) / 4)) : 0;

    // kick edges
    const kickEdge = kp > 0.55 && s.prevKick <= 0.55 && s.time - s.lastKickAt > 0.28;
    s.prevKick = kp;
    if (kickEdge) { s.lastKickAt = s.time; s.kickCount += 1; s.kickLight = Math.max(s.kickLight, kp); }
    s.kickLight *= Math.exp(-dt / 0.22);

    // labelled state (reporting and a few discrete choices)
    s.mood = s.dropEnv > 0.55 ? "drop"
      : s.antic > 0.35 ? "anticipation"
      : s.build > 0.4 ? "build"
      : s.calm > 0.5 ? "breakdown"
      : s.recovery > 0.5 ? "recovery"
      : s.drive > 0.7 ? "high"
      : s.energy < 0.25 ? "calm" : "groove";
    return { dropNow, strength, kickEdge, kp, known, dropIn, nextMajor: known && next >= 1 };
  }

  // ---------------------------------------------------------------------------------------------
  function camera(dt, ev) {
    const a = s.axis;
    const others = [0, 1, 2].filter((i) => i !== a);
    // speed: contemplative in breakdowns, flowing in the groove, gathering through builds,
    // deliberate just before a drop, surging on it
    const groove = 1.25 + 0.5 * s.energy;
    let vGoal = groove * (1 - s.calm) + 0.5 * s.calm;
    vGoal += s.build * (0.9 + 0.4 * smooth01(s.buildHeld / 10));
    vGoal = vGoal * (1 - s.antic) + 0.85 * s.antic;
    vGoal += s.dropEnv * (s.dropStrength >= 1 ? 1.7 : 1.0);
    vGoal += s.drive * 0.25;
    // the dice hero: the camera drifts while the dice roll in front of it
    const hw = s.hero.weight;
    vGoal = vGoal * (1 - hw) + 0.12 * hw;
    s.v = follow(s.v, clamp(vGoal, 0.1, 3.6), dt, vGoal > s.v ? 1.4 : 2.0, 2.0);
    if (ev.dropNow && s.hero.phase < 2) s.v += 0.6 * ev.strength;   // a small kick of momentum, then the follower

    // sway: wider and slower when calm (drifting near the formations), tighter when driving
    const swayAmpGoal = IFS.swayMax * (0.55 + 0.45 * s.calm - 0.25 * s.dropEnv - 0.3 * s.antic);
    s.swayAmp = follow(s.swayAmp, clamp(swayAmpGoal, 0.25, IFS.swayMax) * (1 - 0.75 * hw), dt, 3, 3);
    const swayRate = 0.07 + 0.05 * (1 - s.calm) + 0.03 * s.drive;
    s.swayPh[0] += swayRate * dt * TAU * 0.61;
    s.swayPh[1] += swayRate * dt * TAU * 0.43;
    s.sway = [s.swayAmp * Math.sin(s.swayPh[0]), s.swayAmp * Math.sin(s.swayPh[1] + 1.1) * 0.85];

    // corridor intersections lie at along = 3 + 6k
    const along = s.pos[a] * s.sign;
    const nodeAhead = (Math.floor((along - 3) / IFS.cell) + 1) * IFS.cell + 3;
    if (s.nextNode === null) s.nextNode = nodeAhead;
    if (along > s.nextNode) {
      // passed an intersection: consider scheduling a turn at the next-but-one
      s.nextNode = nodeAhead;
      const quiet = s.antic < 0.15 && s.build < 0.6 && s.hero.phase === 0;
      const gap = s.calm > 0.5 ? 20 : s.drive > 0.7 ? 11 : 15;
      const want = hash(s.turnsTaken * 7.3 + Math.floor(s.time / 3)) < (s.dropEnv > 0.5 ? 0.9 : 0.4);
      if (!s.turn && quiet && s.time - s.lastTurnAt > gap && want) {
        const newAxis = others[hash(s.turnsTaken + 3.1) < 0.5 ? 0 : 1];
        s.turn = { at: nodeAhead + IFS.cell, axis: newAxis, sign: hash(s.turnsTaken + 9.7) < 0.5 ? -1 : 1 };
      }
    }
    if (s.turn && (s.antic > 0.3 || s.hero.phase > 0)) s.turn = null;   // keep the view steady before a drop
    if (s.turn && along > s.turn.at - IFS.look * 0.9) {
      // switch corridors: the old axis coordinate becomes the intersection's
      const nodeCoord = s.turn.at * s.sign;
      s.line[a] = nodeCoord;
      s.axis = s.turn.axis; s.sign = s.turn.sign;
      s.line[s.axis] = 0;
      s.turn = null; s.lastTurnAt = s.time; s.turnsTaken += 1; s.nextNode = null;
    }
    const ax = s.axis, oth = [0, 1, 2].filter((i) => i !== ax);
    const carrot = [0, 0, 0];
    carrot[ax] = s.pos[ax] + s.sign * IFS.look;
    carrot[oth[0]] = s.line[oth[0]] + s.sway[0];
    carrot[oth[1]] = s.line[oth[1]] + s.sway[1];
    const want = norm(sub(carrot, s.pos));
    s.dir = norm(follow3(s.dir, want, dt, 0.55 / Math.max(0.6, Math.min(2, s.v))));
    s.pos = add(s.pos, mul(s.dir, s.v * dt));
    // safety: never closer than IFS.clear to a cube bound
    const cl = clearance(s.pos);
    if (cl < IFS.clear) {
      const c = nearestCube(s.pos);
      s.pos = add(s.pos, mul(norm(sub(s.pos, c)), (IFS.clear - cl) * Math.min(1, dt * 8)));
    }
    for (const d of s.hero.dice) {
      const dc = len(sub(s.pos, d.pos)) - 1.65 * d.scale;
      if (dc < IFS.clear) s.pos = add(s.pos, mul(norm(sub(s.pos, d.pos)), (IFS.clear - dc) * Math.min(1, dt * 8)));
    }

    // glances: a formation ahead and beside the corridor, swapped every few seconds
    s.glanceSince += dt;
    if (s.glanceSince > 7) {
      s.glanceSince = 0; s.glanceIdx += 1;
    }
    {
      const slab = Math.round((s.pos[ax] + s.sign * 11) / IFS.cell) * IFS.cell;
      const k = s.glanceIdx % 4;
      const g = [0, 0, 0];
      g[ax] = slab;
      g[oth[0]] = s.line[oth[0]] + (k & 1 ? 3 : -3);
      g[oth[1]] = s.line[oth[1]] + (k & 2 ? 3 : -3);
      s.glanceAt = follow3(s.glanceAt, g, dt, 1.8);
    }
    const glanceGoal = 0.32 * s.calm + 0.12 * (1 - s.calm) * (1 - s.drive * 0.5) - 0.12 * s.antic;
    s.glanceW = follow(s.glanceW, clamp(glanceGoal, 0, 0.4), dt, 2.5, 2.5);
    const toGlance = norm(sub(s.glanceAt, s.pos));
    let lookGoal = norm(mix3(s.dir, toGlance, s.glanceW));
    // anticipation and hero: hold the chosen formations in view
    const h = s.hero;
    if (h.phase >= 1 && h.cells.length) {
      const focus = h.phase >= 2 ? h.centroid : mul(h.cells.reduce((a, c) => add(a, c), [0, 0, 0]), 1 / h.cells.length);
      const wf = h.phase >= 2 ? 0.35 * hw : 0.25 * h.emphasis;
      lookGoal = norm(mix3(lookGoal, norm(sub(focus, s.pos)), wf));
    }
    s.look = norm(follow3(s.look, lookGoal, dt, 0.7));

    // up: parallel transported, pulled gently towards the lattice axis it is closest to, banked
    // into turns
    let up = norm(sub(s.up, mul(s.look, dot(s.up, s.look))));
    let best = null, bd = -2;
    for (const cand of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
      if (Math.abs(dot(cand, s.look)) > 0.7) continue;
      const d = dot(cand, up);
      if (d > bd) { bd = d; best = cand; }
    }
    if (best) {
      const target = norm(sub(best, mul(s.look, dot(best, s.look))));
      up = norm(follow3(up, target, dt, 5));
    }
    s.up = up;
    const right = norm(cross(up, s.look));
    const lateral = dot(sub(want, s.dir), right);
    s.bank = follow(s.bank, clamp(-lateral * 1.6 * Math.min(1.5, s.v), -0.3, 0.3), dt, 0.8, 0.8);
    s.focal = follow(s.focal, 1.55 - 0.16 * s.dropEnv + 0.08 * s.antic, dt, 0.6, 1.5);

    // keep shader coordinates small: shift the origin by whole cells
    const rel = sub(s.pos, s.origin);
    if (Math.max(Math.abs(rel[0]), Math.abs(rel[1]), Math.abs(rel[2])) > IFS.recentre) {
      s.origin = cellCentre(s.pos);
    }
  }

  // ---------------------------------------------------------------------------------------------
  function lattice(dt, ev) {
    // orientation: an integrated rotation about a slowly precessing axis, paced by the music
    const rateGoal = 0.1 + 0.12 * (1 - s.calm) + 0.1 * s.drive + 0.18 * s.dropEnv + 0.06 * s.bassSlow;
    s.rotRate = follow(s.rotRate, rateGoal, dt, 1.5, 2.5);
    s.rotAxisPh += dt * 0.031;
    const axis = norm([Math.sin(s.rotAxisPh * 1.3) * 0.6, 0.75 + 0.25 * Math.sin(s.rotAxisPh * 0.7), Math.cos(s.rotAxisPh) * 0.5]);
    s.latW = mul(axis, s.rotRate);
    s.rot = qintegrate(s.rot, s.latW, dt);

    // breathing groups: slow bass makes the plane wave of scale deeper and faster
    s.breathAmp = follow(s.breathAmp, 0.025 + 0.06 * s.bassSlow * (1 - 0.4 * s.calm) + 0.02 * s.calm, dt, 2, 3);
    s.breathPh += dt * (0.35 + 0.35 * s.bassSlow + 0.2 * s.drive);

    // fold shape: the asymmetric fold factor (0.5 in the original) slowly opens towards lace in
    // breakdowns and closes towards denser concentric squares when the music drives
    const zGoal = 0.5 + 0.06 * s.drive - 0.07 * s.calm + 0.04 * s.build + 0.05 * s.dropEnv;
    s.zfold = follow(s.zfold, zGoal, dt, 4, 4);
    s.offset = follow(s.offset, 2.0 - 0.05 * s.midsSlow + 0.06 * s.calm, dt, 3, 3);
  }

  // ---------------------------------------------------------------------------------------------
  function waves(dt, ev) {
    const fwd = s.look;
    for (let i = 0; i < IFS.waves; i++) {
      const w = s.waves[i];
      if (!w) continue;
      w.age += dt;
      w.r += w.v * dt;
      if (w.age > w.life || w.r < -w.w * 3) s.waves[i] = null;
    }
    // kick ripples: from a cube ahead, every other kick in the groove, each kick at peaks
    if (ev.kickEdge && s.calm < 0.6) {
      const every = s.drive > 0.75 || s.dropEnv > 0.3 ? 1 : 2;
      if (s.kickCount % every === 0) {
        const lateral = cross(fwd, s.up);
        const k = s.kickCount;
        const p = add(add(s.pos, mul(fwd, 9 + 6 * hash(k))), add(mul(lateral, (hash(k + 1) - 0.5) * 8), mul(s.up, (hash(k + 2) - 0.5) * 6)));
        spawnWave(s.kickSlot, { o: cellCentre(p), r: 0, v: 9, w: 2.2, amp: 0.05 + 0.04 * ev.kp, light: 0.45 + 0.4 * ev.kp, hue: 0.0, life: 1.8 });
        s.kickSlot = (s.kickSlot + 1) % 3;
      }
    }
    // build shells: converge on a focus ahead once per bar, stronger as the build matures
    const bar = Math.floor(s.beats / 4);
    if ((s.build > 0.35 || s.antic > 0.3) && bar !== s.lastBuildWaveBar) {
      s.lastBuildWaveBar = bar;
      const focus = add(s.pos, mul(fwd, 13));
      const g = Math.max(s.build, s.antic);
      spawnWave(structuralSlot(), { o: focus, r: 34, v: -13, w: 2.8, amp: 0.035 + 0.05 * g, light: 0.5 + 0.7 * g, hue: 0.9 + 0.6 * g, life: 2.6 });
    }
    // the drop: an outward expansion from just ahead of the camera
    const h = s.hero;
    if (h.spawn) {
      // the reveal's celebration and the return's ripple start at the dice
      const reveal = h.spawn === "reveal";
      spawnWave(structuralSlot(), { o: h.centroid, r: 0, v: reveal ? 11 : 7, w: reveal ? 3.5 : 4.5, amp: reveal ? 0.08 : 0.1, light: reveal ? 1.5 : 0.9, hue: reveal ? -0.4 : 0.8, life: reveal ? 3.5 : 5 });
      h.spawn = null;
    }
    if (ev.dropNow) {
      const major = ev.strength >= 1;
      spawnWave(structuralSlot(), { o: h.phase >= 2 ? h.centroid : add(s.pos, mul(fwd, 8)), r: 0, v: major ? 15 : 12, w: major ? 4.5 : 3.2, amp: major ? 0.16 : 0.1, light: major ? 1.7 : 1.1, hue: -0.6, life: 4.2 });
    }
    // breakdown swells: slow, wide and dim, every two bars
    if (s.calm > 0.5 && s.time - s.lastSwellAt > 8 * s.beatLen * 1.0 + 2) {
      s.lastSwellAt = s.time;
      const back = add(s.pos, mul(fwd, -10));
      spawnWave(structuralSlot(), { o: back, r: 0, v: 4.2, w: 6, amp: 0.045, light: 0.35, hue: 0.6, life: 9 });
    }
  }

  // ---------------------------------------------------------------------------------------------
  function colour(dt, ev) {
    // section-driven palette: groove drifts through cyan and blue, builds lean to magenta,
    // breakdowns sink to deep violet-blue, drops snap to cyan with gold accents
    s.colourPh += dt * (0.05 + 0.08 * s.drive);
    let goal = 0.55 + 0.45 * Math.sin(s.colourPh);            // cyan <-> blue
    if (s.drive > 0.6) goal = 0.5 + 1.0 * Math.sin(s.colourPh * 0.7) * s.drive;  // reaches violet / magenta (-0.5 = 3.5)
    goal = goal + palDelta(goal, PAL.violet + 0.2 * Math.sin(s.colourPh * 0.5)) * smooth01(s.calm * 1.2);
    goal = goal + palDelta(goal, PAL.magenta) * clamp(Math.max(s.build, s.antic) * 1.1);
    goal = goal + palDelta(goal, PAL.cyan) * smooth01(s.dropEnv * 1.4);
    s.palGoal = goal;
    const tau = s.dropEnv > 0.6 ? 0.8 : 2.8;
    s.pal = wrapPal(s.pal + palDelta(s.pal, goal) * (1 - Math.exp(-dt / tau)));
    s.gold = follow(s.gold, clamp(0.85 * s.dropEnv + 0.25 * s.flash + 0.12 * s.kickLight * s.drive + 0.7 * s.hero.reveal), dt, 0.25, 1.8);
    s.depth = follow(s.depth, s.calm, dt, 2.5, 2.5);
    s.sat = follow(s.sat, 0.78 + 0.18 * s.drive - 0.12 * s.calm, dt, 2, 2);
    s.shimmer += dt * (0.4 + 1.2 * s.highs);
    s.exposure = follow(s.exposure, 1.0 - 0.25 * s.calm + 0.12 * s.build + 0.1 * s.dropEnv, dt, 1.2, 2.0);
    s.glow = follow(s.glow, 0.75 + 0.35 * s.bassSlow + 0.4 * s.dropEnv - 0.25 * s.calm, dt, 0.8, 1.6);
  }

  function advance(dt, input = {}) {
    s.time += dt;
    const ev = musical(dt, input);
    heroStep(dt, ev);
    camera(dt, ev);
    lattice(dt, ev);
    waves(dt, ev);
    colour(dt, ev);
    publish();
    return s;
  }

  function publish() {
    const o = s.origin;
    const right = norm(cross(s.up, s.look));
    const up0 = cross(s.look, right);
    // bank: rotate right/up about the look direction
    const r = rotateAbout(right, s.look, s.bank), u = rotateAbout(up0, s.look, s.bank);
    uniforms.ifsDirector = 1;
    uniforms.ifsCamPos = sub(s.pos, o);
    uniforms.ifsCamBasis = [...r, ...u, ...s.look];
    uniforms.ifsLens = [s.focal, s.exposure, 0.058 + 0.012 * s.calm - 0.008 * s.dropEnv, s.glow];
    uniforms.ifsRot = glWorldToBody(s.rot);
    const bdir = [0.21, 0.13, 0.17];
    uniforms.ifsShape = [s.breathAmp, (s.breathPh - dot(o, bdir)) % TAU, s.zfold, s.offset];
    uniforms.ifsBreath = [...bdir, 0];
    const wa = [], wb = [];
    for (let i = 0; i < IFS.waves; i++) {
      const w = s.waves[i];
      if (!w) { wa.push(0, 0, 0, -100); wb.push(0, 1, 0, 0); continue; }
      const fade = smooth01(w.age / 0.25) * (1 - smooth01((w.age - w.life * 0.55) / (w.life * 0.45)));
      const oo = sub(w.o, o);
      wa.push(oo[0], oo[1], oo[2], w.r);
      wb.push(w.amp * fade, Math.max(0.5, w.w), w.light * fade, w.hue);
    }
    uniforms.ifsWaveA = wa;
    uniforms.ifsWaveB = wb;
    uniforms.ifsLight = [s.bassMid, s.midsSlow, s.highs, s.kickLight];
    uniforms.ifsColor = [s.pal, s.gold, s.depth, s.sat];
    uniforms.ifsClock = [s.shimmer % 1000, s.colourPh % 1000, s.flash, s.antic];
    const h = s.hero, da = [], db = [], dr = [], dh = [];
    for (let i = 0; i < HERO.count; i++) {
      const d = h.dice[i], cell = h.cells[i];
      if (d) {
        const p = sub(d.pos, o), hm = sub(d.home, o);
        da.push(p[0], p[1], p[2], d.amt);
        db.push(d.scale, d.pip, h.reveal, 1);
        dr.push(...glWorldToBody(d.q));
        dh.push(hm[0], hm[1], hm[2], 1);
      } else {
        da.push(1e4, 1e4, 1e4, 0); db.push(1, 0, 0, 0); dr.push(1, 0, 0, 0, 1, 0, 0, 0, 1);
        if (cell && h.phase === 1) { const hm = sub(cell, o); dh.push(hm[0], hm[1], hm[2], 0); }
        else dh.push(1e4, 1e4, 1e4, 0);
      }
    }
    uniforms.ifsDiceA = da;
    uniforms.ifsDiceB = db;
    uniforms.ifsDiceR = dr;
    uniforms.ifsDiceHome = dh;
    uniforms.ifsHero = [h.emphasis, h.reveal, h.room, h.phase];
  }

  // fixed 120 Hz sub-steps: live frames, offline replays and any frame rate integrate alike
  function run(dt, input) {
    s.carry += dt;
    while (s.carry >= IFS.step - 1e-7) { advance(IFS.step, input); s.carry -= IFS.step; }
  }

  // Live: time is seconds since the preset started (monotonic per activation).
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); publish(); s.lastTime = time; }
    const dt = time - s.lastTime;
    s.lastTime = time;
    // a long gap (hidden window, stall) is not replayed; the journey simply continues
    run(Math.min(Math.max(dt, 0), 0.25), input);
    return s;
  }

  function summary() {
    const r = (x, n = 2) => +Number(x).toFixed(n);
    return { t: r(s.time), mood: s.mood, v: r(s.v), cl: r(clearance(s.pos)), axis: s.axis * s.sign, calm: r(s.calm), build: r(s.build),
      antic: r(s.antic), drop: r(s.dropEnv), drive: r(s.drive), pal: r(s.pal), gold: r(s.gold), zf: r(s.zfold, 3), turns: s.turnsTaken,
      waves: s.waves.filter(Boolean).length, hero: s.hero.phase, heroes: s.hero.count, rb: r(s.hero.rb),
      faces: s.hero.dice.map((d) => d.value).join("") };
  }

  publish();
  return { state: s, step, advance, run, reset: () => { reset(); publish(); }, summary, uniforms: () => uniforms, clearance };
}

// ---- live and offline runtimes ------------------------------------------------------------------
const live = { director: createIfsMatrixDirector(), lastTime: -1, loggedAt: -99 };
const offline = { director: createIfsMatrixDirector(), active: false, clock: null };
offline.clock = createOfflineAnimationClock({
  reset: () => offline.director.reset(),
  step: (dt, inputs) => offline.director.run(dt, inputs)
});

export const IFS_OFFLINE_RATE = 120;
export async function prepareIfsMatrixOffline(time, options = {}) {
  offline.active = true;
  await offline.clock.advanceAsync(time, { ...options, fps: IFS_OFFLINE_RATE });
}
export function endIfsMatrixOffline() { offline.active = false; offline.clock.end(); }

export function bindIfsMatrixDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let director;
  if (opts.director) director = opts.director;
  else if (offline.active && opts.offline) director = offline.director;
  else {
    director = live.director;
    if (time !== live.lastTime) { director.step(time, input); live.lastTime = time; }
    if (globalThis.document?.body?.classList?.contains("preset-trial-role") && (time < live.loggedAt || time - live.loggedAt >= 2)) {
      live.loggedAt = time;
      globalThis.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "info", text: `[IFS] ${JSON.stringify(director.summary())}` });
    }
  }
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = uniformLocation(gl, program, name);
    if (!l) continue;
    if (typeof value === "number") gl.uniform1f(l, value);
    else if (value.length === 9 || name === "ifsDiceR") gl.uniformMatrix3fv(l, false, value);
    else if (value.length === 3) gl.uniform3fv(l, value);
    else gl.uniform4fv(l, value);
  }
  return director;
}
