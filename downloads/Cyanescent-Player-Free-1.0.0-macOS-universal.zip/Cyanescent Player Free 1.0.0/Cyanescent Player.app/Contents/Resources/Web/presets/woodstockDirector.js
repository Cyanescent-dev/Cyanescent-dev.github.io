// Preset 147: musical direction through the existing four-layer kaleidoscope.
// Reuses Player's band/onset model, Drop Map and phrase timing; no audio analysis here.
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";
import { createOfflineAnimationClock } from "../engine/offlineAnimationClock.js";

export const WOODSTOCK_PRESET_ID = 147;
export const WOODSTOCK_RATE = 120;
const TAU = Math.PI * 2;
const clamp = (x, hi = 1) => Math.max(0, Math.min(hi, Number.isFinite(x) ? x : 0));
const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
const lift = x => 1.25 * clamp(x) / (0.25 + clamp(x));
const wrap = (x, period = TAU) => (x % period + period) % period;

export function createWoodstockDirector() {
  const model = createNewtonAudioModel(), s = {}, uniforms = {};
  function reset() {
    model.reset();
    Object.assign(s, { time:0, carry:0, lastTime:null, trackTime:null, beat:null, phrase:null,
      phrasePulse:0, dropAge:null, detected:0, lastDrop:-100, lastPhrase:-100,
      energy:0, bass:0, mids:0, highs:0, kick:0, shimmer:0, calm:0, tension:0, pace:1,
      main:0, layer:0, evolution:0, hue:0, breath:0, pose:0, poseGoal:0, colour:0, colourGoal:0,
      eventAge:8, eventStrength:0, drops:0, phrases:0, armed:false, heard:false,
      portraitEnergy:0, portraitMids:0, portraitCalm:0 });
    publish();
  }
  function develop(major) {
    // Bounded persistent portraits, not a reset after every event. The interpolation
    // is in pattern parameters, so rotational symmetry never becomes fractional.
    s.poseGoal = (s.poseGoal + (major ? 0.43 : 0.23)) % 1;
    s.colourGoal = wrap(s.colourGoal + (major ? 0.16 : 0.07), 1);
    s.portraitEnergy = s.energy; s.portraitMids = s.mids; s.portraitCalm = s.calm;
  }
  function publish() {
    uniforms.wwMotion = [s.main, s.layer, s.evolution, s.hue];
    uniforms.wwBands = [s.bass, s.mids, s.highs, s.energy];
    uniforms.wwMood = [s.kick, s.calm, s.tension, s.shimmer];
    uniforms.wwPattern = [s.pose, s.colour, Math.sin(s.breath), 1];
    uniforms.wwEvent = [Math.min(s.eventAge, 8), s.eventStrength, 0, 0];
  }
  function advance(dt, input = {}) {
    const {audio = {}, smooth:bands = {}, music = {}, tempo = {}, lookahead = {}} = input;
    s.time += dt;
    const bpm = Number(tempo.bpm) || Number(music.bpm) || 120;
    const events = model.step(dt, input, {beatsPerSecond:bpm/60, leadSeconds:0});
    const a = model.state;
    const energy = clamp(audio.globalEnergy ?? bands.level);
    const audible = Math.max(energy, clamp(bands.bass), clamp(bands.mids)) > 0.025;
    s.heard ||= audible;
    // Relative bands retain texture in compressed masters; absolute bands retain quiet material.
    const relative = (value, base) => clamp((Number.isFinite(value) ? value - 0.7 : 0) / 1.0) * lift(base);
    s.energy = follow(s.energy, lift(energy), dt, 0.35, 1.4);
    s.bass = follow(s.bass, 0.55*lift(bands.bass) + 0.45*relative(audio.bassRel, bands.bass), dt, 0.07, 0.35);
    s.mids = follow(s.mids, 0.6*lift(bands.mids) + 0.4*relative(audio.midRel, bands.mids), dt, 0.2, 0.65);
    s.highs = follow(s.highs, 0.5*lift(bands.highs) + 0.5*relative(audio.trebleRel, bands.highs), dt, 0.05, 0.25);
    s.calm = follow(s.calm, Math.max(clamp(music.breakdown), clamp(music.calm)*0.8, a.breakdown*0.6), dt, 1.2, 1.0);
    const mapped = Number(music.dropKnown) > 0.5;
    const imminent = mapped && Number(music.dropNextStrength) > 0
      ? clamp(music.dropLeadIn) * smooth((16 - Number(music.dropBeatsIn))/14)
      : 0;
    const future = lookahead.ready ? clamp(((lookahead.medium?.energy || 0) - (lookahead.current?.energy || 0))*3) : 0;
    const anticipation = mapped ? imminent : Math.max(clamp(music.upcomingDrop)*0.7, future*a.build);
    const released = smooth((s.time-s.lastDrop-3)/3);
    s.tension = follow(s.tension, Math.max(a.build*0.65, anticipation)*released, dt, 0.6, 0.5);
    if (audible && (s.tension > 0.25 || s.calm > 0.55)) s.armed = true;

    // Beat jumps are seeks, never a reason to burst or change the portrait.
    const beat = Number(music.absoluteBeat);
    const jumped = Number.isFinite(beat) && s.beat !== null && (beat < s.beat-0.1 || beat-s.beat > 3);
    if (jumped) { s.dropAge = null; s.phrase = null; s.armed = false; }
    s.beat = Number.isFinite(beat) ? beat : null;
    s.eventAge = Math.min(8, s.eventAge + dt);
    const age = Number(music.dropAge);
    const mapHit = mapped && Number.isFinite(age) && s.dropAge !== null && age < s.dropAge-0.15 && age < 0.65 && Number(music.dropLastStrength) > 0;
    const detection = Math.max(clamp(audio.dropDetected), clamp(music.drop));
    const liveHit = !mapped && s.heard && s.armed && (events.drop || (detection > 0.6 && s.detected <= 0.6));
    if (!jumped && (mapHit || liveHit) && s.time-s.lastDrop > (mapped ? 1 : 8)) {
      s.lastDrop = s.time; s.drops++; s.armed = false;
      s.eventAge = mapped ? Math.max(0, age) : 0;
      s.eventStrength = mapped ? Math.max(0.55, clamp(music.dropLastStrength)) : 0.85;
      s.tension = 0;
      develop(true);
    }
    s.dropAge = mapped && Number.isFinite(age) ? age : null;
    s.detected = detection;

    const phrase = Number(music.phraseProgress), pulse = clamp(music.phrasePulse);
    const boundary = Number.isFinite(phrase) && s.phrase !== null && s.phrase > 0.75 && phrase < 0.25;
    const pulseBoundary = pulse > 0.55 && s.phrasePulse <= 0.55 && Number(music.nextPhraseSeconds) > 0;
    // A phrase is an opportunity, not a timer: develop only when the arrangement has
    // changed or anticipation has accumulated, with space around each major event.
    const novelty = Math.abs(s.energy-s.portraitEnergy) + Math.abs(s.mids-s.portraitMids) + Math.abs(s.calm-s.portraitCalm);
    if (!jumped && audible && (boundary || pulseBoundary) && s.time-s.lastPhrase > 12 && s.time-s.lastDrop > 6
        && (novelty > 0.22 || s.tension > 0.4)) {
      develop(false); s.phrases++; s.lastPhrase = s.time;
    }
    s.phrase = Number.isFinite(phrase) ? phrase : null; s.phrasePulse = pulse;
    // The grid's decaying pump survives compressed/saturated kick inputs. Raw
    // transients still own live input without a usable grid.
    const rhythmic = a.beatSource === "track" && a.groove > 0.35;
    const kickTarget = audible && s.calm < 0.85
      ? Math.max(clamp(audio.kickPulse)*(rhythmic ? 0.45 : 1), rhythmic ? a.pump : (events.kick ? 0.85 : 0)) : 0;
    s.kick = follow(s.kick, kickTarget, dt, 0.018, 0.15);
    s.shimmer = follow(s.shimmer, Math.max(s.highs*0.5, events.hats ? 1 : 0), dt, 0.025, 0.18);
    s.pace = follow(s.pace, 0.95 + 0.42*s.energy - 0.18*s.calm + 0.10*s.tension, dt, 1.4, 2);
    s.main = wrap(s.main + dt*0.15*s.pace);
    s.layer = wrap(s.layer + dt*0.24*s.pace*(0.85+0.3*s.mids));
    s.evolution = wrap(s.evolution + dt*(0.40*s.pace+0.10*s.mids));
    s.hue = wrap(s.hue + dt*(0.018+0.008*s.mids), 1);
    s.breath = wrap(s.breath + dt*(0.42+0.25*s.energy));
    s.pose = follow(s.pose, s.poseGoal, dt, 1.3, 1.3);
    // Hue takes the shortest path across the cyclic palette.
    s.colour = wrap(s.colour + (wrap(s.colourGoal-s.colour+0.5,1)-0.5)*(1-Math.exp(-dt/1.5)), 1);
    publish();
  }
  function run(dt, input) {
    s.carry += Math.max(0, dt);
    while (s.carry >= 1/WOODSTOCK_RATE-1e-8) { advance(1/WOODSTOCK_RATE, input); s.carry -= 1/WOODSTOCK_RATE; }
  }
  function step(time, input = {}) {
    time = Math.max(0, Number(time) || 0);
    const trackTime = Number(input.trackTime);
    const dt = s.lastTime === null ? 0 : time-s.lastTime;
    if (dt < -0.001 || (s.trackTime !== null && Number.isFinite(trackTime) && Math.abs(trackTime-s.trackTime-dt) > 0.75)) reset();
    const elapsed = s.lastTime === null ? 0 : Math.max(0, time-s.lastTime);
    s.lastTime = time; s.trackTime = Number.isFinite(trackTime) ? trackTime : null;
    run(Math.min(elapsed, 0.25), input);
    return s;
  }
  reset();
  return {state:s, reset, step, run, uniforms:() => uniforms};
}

// Per-context live state, separate deterministic export state, following the recent directors.
const live = new WeakMap();
const offline = createWoodstockDirector();
let offlineActive = false;
const offlineClock = createOfflineAnimationClock({reset:offline.reset, step:offline.run});
export async function prepareWoodstockOffline(time, options = {}) {
  offlineActive = true;
  await offlineClock.advanceAsync(time, {...options, fps:WOODSTOCK_RATE});
}
export function endWoodstockOffline() { offlineActive = false; offlineClock.end(); }
export function bindWoodstockDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = live.get(gl);
  if (!runtime) { runtime = {director:createWoodstockDirector(), entry:null}; live.set(gl, runtime); }
  const director = opts.director || (opts.offline && offlineActive ? offline : runtime.director);
  if (director === runtime.director) {
    if (opts.entryToken !== undefined && opts.entryToken !== runtime.entry) { director.reset(); runtime.entry = opts.entryToken; }
    director.step(time, input);
  }
  for (const [name, v] of Object.entries(director.uniforms())) {
    const loc = uniformLocation(gl, program, name);
    if (loc !== null && loc !== undefined) gl.uniform4f(loc, ...v);
  }
  return director;
}
