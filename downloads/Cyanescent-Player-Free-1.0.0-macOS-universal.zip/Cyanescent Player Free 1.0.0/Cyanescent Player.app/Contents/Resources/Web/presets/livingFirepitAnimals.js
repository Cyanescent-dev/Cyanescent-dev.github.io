// Living Firepit: the constellation animals (pure JS, no GL, deterministic).
//
// Each animal is an articulated rig with anatomical proportions: a skeleton of rigid frames
// (forehand, hindquarters, neck, head, leg bones, tail) posed by a coherent motion model, and a
// silhouette authored as anatomical landmarks attached to those frames. Every frame the
// landmarks are posed and joined by smooth (centripetal Catmull-Rom) curves, so the outline
// stretches and contracts with the body instead of being a set of independently animated sticks.
//
//   horse   transverse gallop: a four-beat footfall sequence (LH, RH, LF, RF), a gathered
//           suspension, body pitch, spine compression/extension and a balancing neck
//   eagle   3D wings (shoulder, elbow, wrist) with fingered primaries, a fanned tail; long
//           glides, banking turns and occasional deep wingbeats with a folding upstroke
//   bison   lateral-sequence walk, heavy hump, low head, short hindquarters
//   salmon  travelling body wave from mid-body to tail, leaps with whole-body flex
//   deer    a white-tailed doe: careful walk, pause, head raise, ear turns, an occasional bound
//
// Output (local units: withers height = 1 for mammals, body length = 1 for eagle/salmon):
//   { lines: [{ pts: [[x,y,z],...], w, i, tint, rank }], stars: [{ p: [x,y,z], s, i, tint, rank }] }
// x forward, y up, z toward the viewer for profile animals. w scales line width, i intensity,
// tint 0..1 (cool silver .. warm gold), rank 0..1 the order in which the part forms (0 first).

const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, x));
const fract = (x) => x - Math.floor(x);
const mix = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };

// ---------- periodic keyframes (Catmull-Rom through keys at arbitrary u in [0,1)) ----------
export function keyed(keys, u) {
  u = fract(u);
  const n = keys.length;
  let i = n - 1;
  for (let k = 0; k < n; k += 1) if (keys[k][0] <= u) i = k;
  const k0 = keys[(i - 1 + n) % n], k1 = keys[i], k2 = keys[(i + 1) % n], k3 = keys[(i + 2) % n];
  const t0 = k1[0], t1 = i + 1 < n ? k2[0] : k2[0] + 1;
  const t = (u - t0 + (u < t0 ? 1 : 0)) / Math.max(t1 - t0, 1e-6);
  const out = [];
  for (let c = 1; c < k1.length; c += 1) {
    const p0 = k0[c], p1 = k1[c], p2 = k2[c], p3 = k3[c];
    const t2 = t * t, t3 = t2 * t;
    out.push(0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3));
  }
  return out;
}

// ---------- 2D frames ----------
const frame = (x, y, a) => ({ x, y, a, c: Math.cos(a), s: Math.sin(a) });
const apply = (f, lx, ly) => [f.x + lx * f.c - ly * f.s, f.y + lx * f.s + ly * f.c];
const unapply = (f, px, py) => { const dx = px - f.x, dy = py - f.y; return [dx * f.c + dy * f.s, -dx * f.s + dy * f.c]; };
const child = (f, lx, ly, da) => { const [x, y] = apply(f, lx, ly); return frame(x, y, f.a + da); };

// ---------- curves ----------
// Centripetal Catmull-Rom through points (2D or 3D), `per` samples per span; keeps the ends.
export function spline(pts, per = 4) {
  if (pts.length < 3) return pts.map((p) => p.slice());
  const out = [];
  const dim = pts[0].length;
  const P = [pts[0].map((v, k) => 2 * v - pts[1][k]), ...pts, pts[pts.length - 1].map((v, k) => 2 * v - pts[pts.length - 2][k])];
  const dist = (a, b) => Math.sqrt(Math.max(1e-9, Math.sqrt(a.reduce((s, v, k) => s + (v - b[k]) ** 2, 0))));
  for (let i = 1; i < P.length - 2; i += 1) {
    const p0 = P[i - 1], p1 = P[i], p2 = P[i + 1], p3 = P[i + 2];
    const t1 = dist(p0, p1), t2 = t1 + dist(p1, p2), t3 = t2 + dist(p2, p3);
    for (let j = 0; j < per; j += 1) {
      const t = t1 + (t2 - t1) * (j / per);
      const q = [];
      for (let k = 0; k < dim; k += 1) {
        const a1 = ((t1 - t) * p0[k] + t * p1[k]) / t1;
        const a2 = ((t2 - t) * p1[k] + (t - t1) * p2[k]) / (t2 - t1);
        const a3 = ((t3 - t) * p2[k] + (t - t2) * p3[k]) / (t3 - t2);
        const b1 = ((t2 - t) * a1 + t * a2) / t2;
        const b2 = ((t3 - t) * a2 + (t - t1) * a3) / (t3 - t1);
        q.push(((t2 - t) * b1 + (t - t1) * b2) / (t2 - t1));
      }
      out.push(q);
    }
  }
  out.push(pts[pts.length - 1].slice());
  return out;
}

const z3 = (p, z = 0) => [p[0], p[1], z];

// Collector with the per-part style.
function collector() {
  const lines = [], stars = [];
  return {
    lines, stars,
    line(pts, { w = 1, i = 1, tint = 0.5, rank = 0.5, per = 4, z = 0, raw = false } = {}) {
      const p3 = pts.map((p) => (p.length === 3 ? p : z3(p, z)));
      lines.push({ pts: raw ? p3 : spline(p3, per), w, i, tint, rank });
    },
    star(p, { s = 1, i = 1, tint = 0.5, rank = 0.2, z = 0 } = {}) {
      stars.push({ p: p.length === 3 ? p.slice() : z3(p, z), s, i, tint, rank });
    }
  };
}

// ======================================================================================
// Quadruped rig. Landmarks are authored in absolute "neutral" coordinates and bound to the
// frame they ride on; the rig poses the frames and maps each landmark through its frame.
// ======================================================================================
function bindLandmarks(neutralFrames, list) {
  return list.map(([f, x, y]) => {
    const [lx, ly] = unapply(neutralFrames[f], x, y);
    return [f, lx, ly];
  });
}

// Leg: a chain of bones from a root joint, absolute angles from straight down (+ = distal end
// forward), measured in the body frame. Returns joint positions.
function legChain(root, bodyAngle, lengths, angles) {
  const pts = [root];
  let p = root;
  for (let k = 0; k < lengths.length; k += 1) {
    const a = angles[k] + bodyAngle;
    p = [p[0] + Math.sin(a) * lengths[k], p[1] - Math.cos(a) * lengths[k]];
    pts.push(p);
  }
  return pts;
}

// Front/back silhouette edges of a leg: samples along the bones with anatomical half-widths.
// samples: [boneIndex, t along bone, frontHalfWidth, backHalfWidth]
function legEdges(joints, samples) {
  const front = [], back = [], centre = [];
  for (const [b, t, wf, wb] of samples) {
    const a = joints[b], c = joints[Math.min(b + 1, joints.length - 1)];
    let dx = c[0] - a[0], dy = c[1] - a[1];
    // blend the direction with the neighbouring bone near joints so edges stay smooth
    if (t < 0.2 && b > 0) {
      const pa = joints[b - 1]; const ex = a[0] - pa[0], ey = a[1] - pa[1];
      const k = 0.5 * (1 - t / 0.2); dx = mix(dx, ex, k); dy = mix(dy, ey, k);
    } else if (t > 0.8 && b + 2 < joints.length) {
      const na = joints[b + 2]; const ex = na[0] - c[0], ey = na[1] - c[1];
      const k = 0.5 * ((t - 0.8) / 0.2); dx = mix(dx, ex, k); dy = mix(dy, ey, k);
    }
    const L = Math.hypot(dx, dy) || 1;
    const nx = -dy / L, ny = dx / L; // perpendicular, toward the leg's front for a downward bone
    const px = mix(a[0], c[0], t), py = mix(a[1], c[1], t);
    front.push([px + nx * wf, py + ny * wf]);
    back.push([px - nx * wb, py - ny * wb]);
    centre.push([px, py]);
  }
  return { front, back, centre };
}

// Hoof (or cloven hoof): coronet at the last joint, toe forward along the pastern direction.
function hoofShape(joints, size, cloven = false) {
  const n = joints.length;
  const f = joints[n - 1], p = joints[n - 2];
  const dx = f[0] - p[0], dy = f[1] - p[1], L = Math.hypot(dx, dy) || 1;
  const ux = dx / L, uy = dy / L, nx = -uy, ny = ux;
  const toe = [f[0] + ux * size * 0.9 + nx * size * 0.55, f[1] + uy * size * 0.9 + ny * size * 0.55];
  const heel = [f[0] + ux * size * 0.55 - nx * size * 0.5, f[1] + uy * size * 0.55 - ny * size * 0.5];
  const top = [f[0] + nx * size * 0.45, f[1] + ny * size * 0.45];
  const back = [f[0] - nx * size * 0.4, f[1] - ny * size * 0.4];
  const pts = [top, toe, heel, back];
  if (cloven) pts.splice(2, 0, [mix(toe[0], heel[0], 0.5) - ux * size * 0.25, mix(toe[1], heel[1], 0.5) - uy * size * 0.25]);
  return pts;
}

// ======================================================================================
// HORSE — transverse gallop
// ======================================================================================
const HORSE = (() => {
  // neutral frames (absolute standing coordinates, withers height 1)
  const F0 = frame(0.15, 0.80, 0);              // forehand
  const H0 = frame(-0.22, 0.85, 0);             // hindquarters (pivot at the loin)
  // neck/head neutral pose (galloping carriage): neck base, two neck bones, head
  const NB = [0.40, 0.88];
  const neckA = [0.66, 0.40], neckL = [0.30, 0.26], headA = -0.98, headL = 0.54;
  const N10 = frame(NB[0], NB[1], neckA[0]);
  const N20 = child(N10, neckL[0], 0, neckA[1] - neckA[0]);
  const HD0 = child(N20, neckL[1], 0, headA - neckA[1]);
  const frames0 = { F: F0, H: H0, N1: N10, N2: N20, HD: HD0 };
  const L = (f, x, y) => [f, x * 0.9, y];
  // Head landmarks authored in head-local coordinates (u toward muzzle, v toward forehead).
  const headLocal = (u, v) => apply(HD0, u, v);
  const neckLocal = (f, u, v) => apply(frames0[f], u, v);
  const top = bindLandmarks(frames0, [
    L('F', 0.53, 0.63), L('F', 0.585, 0.745),                     // breast, point of chest
    ['N1', ...neckLocal('N1', 0.10, -0.145)], ['N1', ...neckLocal('N1', 0.24, -0.105)],
    ['N2', ...neckLocal('N2', 0.10, -0.085)], ['N2', ...neckLocal('N2', 0.24, -0.075)],   // throat
    ['HD', ...headLocal(0.06, -0.135)], ['HD', ...headLocal(0.19, -0.165)],   // jowl
    ['HD', ...headLocal(0.33, -0.10)], ['HD', ...headLocal(0.48, -0.072)],   // under jaw, chin groove
    ['HD', ...headLocal(0.525, -0.085)], ['HD', ...headLocal(0.555, -0.045)],  // lower lip, muzzle
    ['HD', ...headLocal(0.545, -0.005)], ['HD', ...headLocal(0.48, 0.03)],   // nostril, nose
    ['HD', ...headLocal(0.34, 0.045)], ['HD', ...headLocal(0.17, 0.065)],     // nasal bone, forehead
    ['HD', ...headLocal(0.03, 0.045)],                                          // poll
    ['N2', ...neckLocal('N2', 0.20, 0.07)], ['N2', ...neckLocal('N2', 0.05, 0.088)],  // crest
    ['N1', ...neckLocal('N1', 0.20, 0.115)], ['N1', ...neckLocal('N1', 0.04, 0.14)],
    L('F', 0.17, 1.035), L('F', 0.02, 0.985),                       // withers, back
    L('H', -0.20, 0.982), L('H', -0.38, 1.012), L('H', -0.52, 0.985), // loin, croup, top of tail
    L('H', -0.60, 0.92), L('H', -0.625, 0.84), L('H', -0.61, 0.72)  // buttock, point, hamstring
  ]);
  const belly = bindLandmarks(frames0, [
    L('F', 0.345, 0.565), L('F', 0.20, 0.515), L('F', 0.02, 0.51), L('H', -0.10, 0.535), L('H', -0.20, 0.575), L('H', -0.245, 0.61)
  ]);
  const details = [
    // scapula, humerus, ribcage arc, pelvis, femur, cheek
    { pts: bindLandmarks(frames0, [L('F', 0.17, 0.99), L('F', 0.32, 0.84), L('F', 0.50, 0.71)]), i: 0.5 },
    { pts: bindLandmarks(frames0, [L('F', 0.50, 0.71), L('F', 0.42, 0.62), L('F', 0.36, 0.565)]), i: 0.38 },
    { pts: bindLandmarks(frames0, [L('F', 0.06, 0.53), L('F', -0.01, 0.72), L('F', 0.0, 0.93)]), i: 0.3 },
    { pts: bindLandmarks(frames0, [L('H', -0.28, 0.93), L('H', -0.45, 0.89), L('H', -0.61, 0.85)]), i: 0.42 },
    { pts: bindLandmarks(frames0, [L('H', -0.28, 0.93), L('H', -0.40, 0.80), L('H', -0.30, 0.62)]), i: 0.3 },
    { pts: bindLandmarks(frames0, [['HD', ...headLocal(0.05, -0.02)], ['HD', ...headLocal(0.15, -0.10)], ['HD', ...headLocal(0.30, -0.07)], ['HD', ...headLocal(0.33, 0.0)]]), i: 0.35 }
  ];
  const tailRoot = bindLandmarks(frames0, [L('H', -0.57, 0.955)])[0];
  const shoulder = bindLandmarks(frames0, [L('F', 0.50, 0.70)])[0];
  const chest = bindLandmarks(frames0, [L('F', 0.585, 0.745)])[0];
  const hip = bindLandmarks(frames0, [L('H', -0.40, 0.81)])[0];
  const foreLen = [0.20, 0.27, 0.19, 0.10];
  const hindLen = [0.28, 0.34, 0.23, 0.10];
  // [bone, t, front half-width, back half-width]
  const foreSamples = [[1, 0.06, 0.075, 0.065], [1, 0.5, 0.05, 0.04], [2, 0.0, 0.034, 0.04], [2, 0.5, 0.022, 0.028], [3, 0.0, 0.03, 0.042], [3, 0.6, 0.02, 0.024], [3, 1.0, 0.026, 0.022]];
  const hindSamples = [[1, 0.12, 0.085, 0.095], [1, 0.55, 0.055, 0.06], [2, 0.0, 0.036, 0.065], [2, 0.5, 0.024, 0.028], [3, 0.0, 0.03, 0.042], [3, 0.6, 0.02, 0.024], [3, 1.0, 0.026, 0.022]];

  // Gallop: leg cycle u from touchdown; stance 0..0.3. Absolute bone angles (rad from down).
  const FORE = [
    [0.00, -0.45, 0.30, 0.30, 0.55],
    [0.10, -0.70, 0.08, 0.02, 0.95],
    [0.20, -0.95, -0.22, -0.28, 0.80],
    [0.30, -1.10, -0.50, -0.62, 0.00],
    [0.40, -1.05, -0.48, -1.35, -1.20],
    [0.52, -0.80, -0.10, -2.20, -2.60],
    [0.64, -0.45, 0.55, -1.30, -1.90],
    [0.76, -0.25, 1.05, 0.10, -0.50],
    [0.88, -0.25, 0.80, 0.70, 0.40]
  ];
  const HIND = [
    [0.00, 0.85, -0.25, 0.35, 0.55],
    [0.10, 0.65, -0.55, 0.10, 0.90],
    [0.20, 0.35, -0.85, -0.25, 0.85],
    [0.30, -0.02, -0.78, -0.50, 0.05],
    [0.42, 0.12, -0.80, -1.30, -1.70],
    [0.55, 0.42, -0.80, -1.30, -1.80],
    [0.68, 0.80, -0.65, -0.70, -1.00],
    [0.82, 1.08, -0.42, -0.12, -0.55],
    [0.92, 1.04, -0.33, 0.22, 0.10]
  ];
  // whole-body motion over the stride (c = 0 at the trailing hind's touchdown)
  const BODY = [ // [c, bob, pitch, flex, neck, head]
    [0.00, 0.000, 0.035, 0.07, 0.02, 0.00],
    [0.15, 0.010, 0.055, 0.02, 0.06, -0.03],
    [0.32, -0.015, 0.010, -0.05, 0.00, 0.00],
    [0.48, -0.045, -0.050, -0.04, -0.11, 0.06],
    [0.62, -0.020, -0.030, 0.00, -0.06, 0.04],
    [0.80, 0.035, 0.010, 0.06, 0.03, -0.02],
    [0.92, 0.030, 0.025, 0.08, 0.04, -0.02]
  ];
  const OFFS = { LH: 0.0, RH: 0.10, LF: 0.30, RF: 0.40 };

  function pose(c, opt = {}) {
    const amp = opt.amp ?? 1;
    const [bob, pitch, flex, dNeck, dHead] = keyed(BODY, c).map((v) => v * amp);
    const pivot = [0, 0.8];
    const rot = (p, a) => { const s = Math.sin(a), co = Math.cos(a); const dx = p[0] - pivot[0], dy = p[1] - pivot[1]; return [pivot[0] + dx * co - dy * s, pivot[1] + bob + dx * s + dy * co]; };
    const fo = rot([F0.x, F0.y], pitch);
    const F = frame(fo[0], fo[1], pitch);
    const ho = rot([H0.x, H0.y], pitch);
    const H = frame(ho[0], ho[1], pitch + flex);
    const nb = apply(F, ...unapply(F0, NB[0], NB[1]));
    const N1 = frame(nb[0], nb[1], pitch + neckA[0] + dNeck);
    const N2 = child(N1, neckL[0], 0, neckA[1] - neckA[0] + dNeck * 0.6);
    const HD = child(N2, neckL[1], 0, headA - neckA[1] + dHead - dNeck * 0.9 + (opt.headLift || 0));
    const fr = { F, H, N1, N2, HD };
    const P = ([f, x, y]) => apply(fr[f], x, y);
    const out = collector();
    const warm = 0.55;
    out.line(top.map(P), { w: 1.0, i: 1.0, tint: warm, rank: 0.25, per: 4 });
    out.line(belly.map(P), { w: 0.85, i: 0.75, tint: warm, rank: 0.45, per: 4 });
    for (const d of details) out.line(d.pts.map(P), { w: 0.55, i: d.i, tint: 0.35, rank: 0.75, per: 3 });

    // legs
    const legs = {};
    for (const name of ['LH', 'RH', 'LF', 'RF']) {
      const fore = name[1] === 'F';
      const u = fract(c - OFFS[name]);
      const neutral = fore ? [-0.75, 0.0, 0.0, 0.6] : [0.56, -0.74, 0.13, 0.55];
      const a = keyed(fore ? FORE : HIND, u).map((v, k) => mix(neutral[k], v, amp));
      const root = fore ? P(shoulder) : P(hip);
      const joints = legChain(root, fore ? F.a : H.a, fore ? foreLen : hindLen, a);
      legs[name] = joints;
      const near = name[0] === 'R';
      const zf = near ? 0.06 : -0.06;
      const ii = near ? 1 : 0.5;
      const e = legEdges(joints, fore ? foreSamples : hindSamples);
      const anchorF = fore ? P(top[0]) : P(belly[belly.length - 1]);
      const anchorB = fore ? P(belly[0]) : P(top[top.length - 1]);
      out.line([anchorF, ...e.front], { w: near ? 0.9 : 0.7, i: 0.9 * ii, tint: warm, rank: 0.4, z: zf });
      out.line([anchorB, ...e.back], { w: near ? 0.85 : 0.65, i: 0.8 * ii, tint: warm, rank: 0.45, z: zf });
      out.line(hoofShape(joints, 0.05), { w: 0.7, i: 0.75 * ii, tint: 0.6, rank: 0.55, z: zf, raw: true });
      out.line(e.centre.slice(0, -1), { w: 0.4, i: 0.22 * ii, tint: 0.3, rank: 0.85, z: zf, per: 2 });
      out.star(joints[2], { s: 0.8, i: 0.55 * ii, tint: 0.5, rank: 0.3, z: zf });           // knee / hock
      out.star(joints[3], { s: 0.6, i: 0.4 * ii, tint: 0.5, rank: 0.5, z: zf });            // fetlock
      out.star(joints[4], { s: 0.7, i: 0.6 * ii, tint: 0.6, rank: 0.2, z: zf });            // hoof
    }

    // mane: strands rooted on the crest, flowing back with a travelling wave
    const crest = [P(top[16]), P(top[17]), P(top[18]), P(top[19]), P(top[20]), P(top[21])];
    const crestS = spline(crest.map((p) => z3(p)), 2);
    const t = opt.time || 0;
    for (let k = 1; k < crestS.length - 1; k += 1) {
      const p = crestS[k], q = crestS[k + 1];
      const dx = q[0] - p[0], dy = q[1] - p[1];
      const s = k / crestS.length;
      const wave = Math.sin(TAU * (c * amp - s * 0.9) + t * 0.7) * amp;
      const ang = Math.atan2(dy, dx) - 0.5 + wave * 0.18;
      const len = 0.11 + 0.05 * Math.sin(k * 2.3) ** 2;
      const m = [p[0] + Math.cos(ang) * len * 0.5, p[1] + Math.sin(ang) * len * 0.5];
      const a2 = ang - 0.25 - wave * 0.25;
      const e2 = [m[0] + Math.cos(a2) * len * 0.55, m[1] + Math.sin(a2) * len * 0.55];
      out.line([p, m, e2], { w: 0.45, i: 0.5, tint: 0.7, rank: 0.7, per: 3 });
    }
    // forelock
    { const pp = P(['HD', 0.02, 0.06]); const f1 = apply(HD, 0.10, 0.075); out.line([pp, f1, apply(HD, 0.16, 0.05)], { w: 0.45, i: 0.45, tint: 0.7, rank: 0.7, per: 3 }); }
    // ears (pricked)
    { const b0 = apply(HD, 0.035, 0.05), b1 = apply(HD, 0.085, 0.055), tip = apply(HD, -0.01, 0.17 + 0.01 * Math.sin(t * 1.3));
      out.line([b0, apply(HD, 0.005, 0.12), tip, apply(HD, 0.055, 0.12), b1], { w: 0.7, i: 0.85, tint: 0.55, rank: 0.35, per: 2 });
      out.star(tip, { s: 0.6, i: 0.6, rank: 0.35 }); }
    // eye, nostril, key landmarks
    out.star(apply(HD, 0.19, 0.005), { s: 1.25, i: 1.0, tint: 0.65, rank: 0.0 });
    out.star(apply(HD, 0.53, -0.01), { s: 0.6, i: 0.45, tint: 0.5, rank: 0.4 });
    out.star(P(top[21]), { s: 1.0, i: 0.85, tint: 0.55, rank: 0.05 });   // withers
    out.star(P(top[24]), { s: 0.9, i: 0.8, tint: 0.55, rank: 0.1 });     // croup
    out.star(P(chest), { s: 0.85, i: 0.7, tint: 0.55, rank: 0.1 }); // chest
    out.star(P(details[3].pts[0]), { s: 0.8, i: 0.6, rank: 0.15 });      // point of hip

    // tail: a dock chain whose links lag the body's motion, spread into flowing hair
    const tr = P(tailRoot);
    const base = Math.PI - 0.38 + H.a;
    let tp = tr, ang = base;
    const dock = [tr];
    for (let k = 0; k < 7; k += 1) {
      const lag = Math.sin(TAU * (c - 0.12 - k * 0.07)) * (0.05 + 0.035 * k) * amp + Math.sin(t * 0.9 + k * 0.6) * 0.03;
      ang = base + 0.11 * k + lag + (k > 3 ? 0.04 * k : 0);
      tp = [tp[0] + Math.cos(ang) * 0.085, tp[1] + Math.sin(ang) * 0.085];
      dock.push(tp);
    }
    for (let s = -2; s <= 2; s += 1) {
      const hair = dock.map((p, k) => {
        if (k < 2) return p;
        const spread = s * 0.012 * (k - 1) ** 1.15;
        const prev = dock[k - 1];
        const dx = p[0] - prev[0], dy = p[1] - prev[1], Ld = Math.hypot(dx, dy) || 1;
        const ripple = Math.sin(TAU * (c * 1.0 - k * 0.12) + s) * 0.006 * k * amp;
        return [p[0] - dy / Ld * (spread + ripple), p[1] + dx / Ld * (spread + ripple)];
      });
      out.line(hair, { w: s === 0 ? 0.8 : 0.6, i: s === 0 ? 0.85 : 0.6, tint: 0.7, rank: 0.65, per: 3 });
    }
    out.star(dock[dock.length - 1], { s: 0.7, i: 0.5, tint: 0.7, rank: 0.4 });
    return out;
  }
  return { pose, legsOrder: OFFS };
})();


// ======================================================================================
// EAGLE — 3D wings. Local frame: x forward (head), y dorsal, z toward the right wing tip.
// Body length (beak to tail tip) ~1, span ~2.2. Pose parameters:
//   flap      wingbeat phase (rad); amp 0 = glide
//   amp       wingbeat amplitude 0..1
//   flexL/R   extra wrist/elbow flex per wing 0..1 (inner wing in a turn, braking)
//   dihedral  glide dihedral (rad)
//   spread    tail fan 0..1;  twist  tail twist (rad, about the body axis)
//   bend      upward bend of the primaries under load 0..1
// ======================================================================================
// Wingbeat phase warp: the downstroke takes 60% of the cycle. Returns theta (0 top, pi bottom).
export function eagleStroke(flap) {
  const ph = fract(flap / TAU);
  return ph < 0.6 ? (ph / 0.6) * Math.PI : Math.PI + ((ph - 0.6) / 0.4) * Math.PI;
}

const EAGLE = (() => {
  const rotX = (p, a) => { const c = Math.cos(a), s = Math.sin(a); return [p[0], p[1] * c - p[2] * s, p[1] * s + p[2] * c]; };
  const rotY = (p, a) => { const c = Math.cos(a), s = Math.sin(a); return [p[0] * c + p[2] * s, p[1], -p[0] * s + p[2] * c]; };
  const add3 = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  // body planform (right half, x forward, z right); mirrored for the left
  // planform (from below): hooked beak tapering from a broad skull, a short neck into broad shoulders
  const BODY_R = [[0.302, 0.0], [0.297, 0.011], [0.286, 0.022], [0.271, 0.034], [0.252, 0.046], [0.228, 0.053], [0.203, 0.051], [0.178, 0.055], [0.142, 0.07], [0.10, 0.087], [0.05, 0.10], [-0.07, 0.092], [-0.17, 0.07], [-0.235, 0.06]];
  // side profile: nape, crown, flat brow ridge over the eye, cere, strongly hooked culmen, gape, chin
  const PROFILE = [[0.17, 0.052], [0.205, 0.064], [0.232, 0.068], [0.252, 0.064], [0.266, 0.053], [0.279, 0.051], [0.292, 0.045], [0.301, 0.032], [0.304, 0.017], [0.299, 0.005], [0.293, 0.011], [0.283, 0.016], [0.266, 0.012], [0.248, 0.004], [0.226, -0.006], [0.2, -0.014], [0.17, -0.022]];
  // primaries: [base position along the hand 0..1, direction (rad, 0 = straight out along the
  // hand, + = swept back), length, half-width]
  const PRIM = [
    [1.00, -0.30, 0.33, 0.030], [0.90, -0.08, 0.37, 0.033], [0.78, 0.16, 0.38, 0.035],
    [0.64, 0.42, 0.37, 0.037], [0.48, 0.70, 0.36, 0.039], [0.30, 0.98, 0.35, 0.041], [0.12, 1.22, 0.33, 0.043]
  ];

  // One wing in wing-local 2D (s outward, c forward) given flex; then lifted to 3D by the caller.
  function wing2D(fold, flapT) {
    // joint angles in the wing plane (0 = straight outward), + sweeps the distal bone forward
    const hum = -0.12 - 0.35 * fold;
    const fore = 0.18 + 0.75 * fold;
    const hand = -0.10 - 1.25 * fold;
    const sh = [0.07, 0.0];
    const el = [sh[0] + Math.cos(hum) * 0.22, sh[1] + Math.sin(hum) * 0.22];
    const wr = [el[0] + Math.cos(fore) * 0.30, el[1] + Math.sin(fore) * 0.30];
    const handDir = fore + hand;
    const tip = [wr[0] + Math.cos(handDir) * 0.24, wr[1] + Math.sin(handDir) * 0.24];
    return { sh, el, wr, tip, handDir, fore };
  }

  function pose(o = {}) {
    const out = collector();
    const t = o.time || 0;
    const amp = o.amp ?? 0, flap = o.flap ?? 0;
    const spread = o.spread ?? 0.4, twist = o.twist ?? 0, bend = o.bend ?? 0.6;
    const warm = 0.62;
    // ---- body ----
    // the head's planform sits at mid-head height, so seen edge-on it reads as the cheek line
    const hy = (x) => 0.03 * smooth(0.15, 0.225, x) - 0.008 * smooth(0.27, 0.302, x);
    const bodyR = BODY_R.map(([x, z]) => [x, hy(x), z]);
    const bodyL = BODY_R.map(([x, z]) => [x, hy(x), -z]).reverse();
    out.line([...bodyL, ...bodyR.slice(1)], { w: 0.9, i: 0.9, tint: warm, rank: 0.3, per: 3 });
    // head and body in profile (the vertical plane), so the head reads from every orientation
    out.line(PROFILE.map(([x, y]) => [x, y, 0]), { w: 0.75, i: 0.85, tint: 0.7, rank: 0.35, per: 3 });
    out.line([[0.294, 0.013, 0], [0.276, 0.02, 0], [0.258, 0.024, 0]], { w: 0.45, i: 0.45, tint: 0.6, rank: 0.7, per: 2 });   // gape line
    out.line([[0.17, 0.052, 0], [0.08, 0.066, 0], [-0.06, 0.062, 0], [-0.18, 0.04, 0], [-0.235, 0.024, 0]], { w: 0.45, i: 0.32, tint: 0.5, rank: 0.8, per: 3 });   // back
    out.line([[0.17, -0.022, 0], [0.1, -0.055, 0], [-0.04, -0.06, 0], [-0.17, -0.035, 0], [-0.235, -0.02, 0]], { w: 0.45, i: 0.32, tint: 0.5, rank: 0.8, per: 3 });   // breast, belly
    // the eyes sit on the sides of the skull under the brow
    out.star([0.248, 0.046, 0.034], { s: 1.05, i: 1.0, tint: 0.7, rank: 0.0 });
    out.star([0.248, 0.046, -0.034], { s: 0.85, i: 0.7, tint: 0.7, rank: 0.05 });
    out.star([0.302, 0.012, 0], { s: 0.55, i: 0.5, tint: 0.7, rank: 0.3 });
    // ---- tail: 12 rectrices in a fan, twisted about the body axis ----
    const base = [-0.235, 0.0];
    const half = 0.16 + 0.32 * spread;
    const tips = [];
    for (let k = 0; k <= 12; k += 1) {
      const a = mix(-half, half, k / 12);
      const L = 0.33 - 0.025 * Math.abs(a / half) ** 2;
      const tip = [base[0] - Math.cos(a) * L, 0.0, Math.sin(a) * L * 1.05 + Math.sin(a) * 0.12];
      tips.push(rotX(tip, twist));
    }
    const tailEdge = [];
    for (let k = 0; k < tips.length; k += 1) {
      tailEdge.push(tips[k]);
      if (k + 1 < tips.length) { const m = tips[k].map((v, j) => (v + tips[k + 1][j]) / 2); tailEdge.push([m[0] + 0.006, m[1], m[2]]); }
    }
    const tb0 = rotX([base[0], 0, -0.06], twist), tb1 = rotX([base[0], 0, 0.06], twist);
    out.line([[-0.17, 0, -0.07], tb0, ...tailEdge, tb1, [-0.17, 0, 0.07]], { w: 0.8, i: 0.8, tint: warm, rank: 0.45, per: 2 });
    for (let k = 2; k <= 10; k += 4) out.line([rotX([base[0] + 0.01, 0, mix(-0.03, 0.03, k / 12)], twist), tips[k]], { w: 0.4, i: 0.3, tint: 0.4, rank: 0.85, per: 1, raw: true });
    out.star(tips[6], { s: 0.8, i: 0.6, tint: warm, rank: 0.15 });

    // ---- wings ----
    for (const side of [1, -1]) {
      const extra = side > 0 ? (o.flexR || 0) : (o.flexL || 0);
      // wingbeat: a powerful downstroke (60% of the cycle, wing extended, primaries spread and
      // reaching forward) and a recovery stroke (wrist flexed, hand folded, primaries slotted).
      // theta 0 = top of the stroke, pi = bottom.
      const theta = eagleStroke(flap);
      const armElev = (th) => amp * (0.56 * Math.cos(th) - 0.04);
      const elev = (o.dihedral ?? 0.09) + armElev(theta);
      const up = amp * clamp(Math.sin(theta - Math.PI));          // > 0 only on the upstroke
      const down = amp * clamp(Math.sin(theta));                  // > 0 only on the downstroke
      const fold = clamp(0.06 + 0.62 * up + 0.4 * extra);
      const sweepFwd = 0.12 * down;
      const W = wing2D(fold, 0);
      // lift wing-local (s, c, lift) into body coordinates
      const toBody = (sv, cv, yv = 0) => {
        let p = [cv - 0.02 + sweepFwd * sv * 0.3, yv, sv];
        // elevation (dihedral / flap) about the shoulder line (x axis), then mirror
        p = rotX(p, -elev * 1.0);
        // outer wing elevates a little more (flexible wing), hand lags the arm in a beat
        return [p[0], p[1], side * p[2]];
      };
      // the hand lags the arm, so a bend travels out along the wing instead of a rigid panel
      const lag = armElev(theta - 0.75) - armElev(theta);
      const handLift = (sv) => {
        const k = clamp((sv - 0.45) / 0.6);
        return k * k * (0.05 * bend * (1 - amp) + 0.55 * lag * sv + 0.02 * Math.sin(t * 1.3 + side));
      };
      const P = (p2, yv = 0) => toBody(p2[0], p2[1], yv + handLift(p2[0]));
      // leading edge: shoulder -> patagium -> wrist -> hand leading edge
      const n = [-Math.sin(W.handDir), Math.cos(W.handDir)];
      const lead = [[0.07, 0.10], [mix(0.07, W.wr[0], 0.45), mix(0.10, W.wr[1] + 0.06, 0.55) + 0.015], [W.wr[0], W.wr[1] + 0.055],
        [mix(W.wr[0], W.tip[0], 0.55) + n[0] * 0.04, mix(W.wr[1], W.tip[1], 0.55) + n[1] * 0.04 + 0.01]];
      // primaries fan from the hand
      const prim = PRIM.map(([pos, dir, len, hw], k) => {
        const b = [mix(W.wr[0], W.tip[0], pos), mix(W.wr[1], W.tip[1], pos)];
        const sep = (1 - 0.55 * fold) * (1 + 0.18 * down) + 0.25 * up;  // spread on the downstroke, slotted on the recovery
        const a = W.handDir - (dir + 0.15 * fold * k) * sep - 0.06;
        const L = len * (1 - 0.15 * fold);
        const tip = [b[0] + Math.cos(a) * L, b[1] + Math.sin(a) * L];
        // emarginated: narrow outer part
        const nx = -Math.sin(a), ny = Math.cos(a);
        const mid = [b[0] + Math.cos(a) * L * 0.45, b[1] + Math.sin(a) * L * 0.45];
        return { b, a, tip, L, hw, nx, ny, mid };
      });
      // trailing edge: inner secondaries bulge, scalloped, from the body to the last primary
      const trail = [];
      const nSec = 9;
      for (let k = 0; k <= nSec; k += 1) {
        const u = k / nSec;
        const along = [mix(0.08, W.wr[0] + 0.07, u), mix(-0.02, W.wr[1] - 0.03, u)];
        const chord = 0.36 + 0.05 * Math.sin(Math.PI * u * 0.8) - 0.03 * u;
        const dirc = Math.cos(W.fore) * 0.0;
        trail.push([along[0] + 0.02 * u + dirc, along[1] - chord]);
        if (k < nSec) trail.push([mix(0.08, W.wr[0] + 0.07, u + 0.5 / nSec) + 0.02 * u, mix(-0.02, W.wr[1] - 0.02, u + 0.5 / nSec) - chord + 0.007]);
      }
      // outline: body side -> leading edge -> fingers -> trailing edge -> body side
      const outline = [];
      outline.push(P([0.07, 0.08]));
      for (const p of lead) outline.push(P(p));
      for (let k = 0; k < prim.length; k += 1) {
        const f = prim[k];
        const ux = Math.cos(f.a), uy = Math.sin(f.a);
        const at = (along, side) => [f.b[0] + ux * f.L * along + f.nx * side, f.b[1] + uy * f.L * along + f.ny * side];
        if (k === 0) outline.push(P(at(0.5, f.hw * 1.1)));
        outline.push(P(at(0.88, f.hw * 0.75)));
        outline.push(P(at(1.0, 0), 0.05 * down + 0.015 * bend));
        outline.push(P(at(0.88, -f.hw * 0.8)));
        if (k + 1 < prim.length) {
          // the slot between two fingers (emargination): notch at ~40% of the finger
          const g = prim[k + 1];
          const a1 = at(0.42, -f.hw * 1.2);
          const gx = Math.cos(g.a), gy = Math.sin(g.a);
          const a2 = [g.b[0] + gx * g.L * 0.42 + g.nx * g.hw * 1.2, g.b[1] + gy * g.L * 0.42 + g.ny * g.hw * 1.2];
          outline.push(P([mix(a1[0], a2[0], 0.5), mix(a1[1], a2[1], 0.5)]));
        }
      }
      for (let k = trail.length - 1; k >= 0; k -= 1) outline.push(P(trail[k]));
      outline.push(P([0.07, -0.20]));
      out.line(outline.map((p) => p), { w: 0.95, i: 0.95, tint: warm, rank: 0.35, per: 2 });
      // flight feather structure: primary shafts, secondary lines, covert line
      for (const f of prim) out.line([P(f.b), P([mix(f.b[0], f.tip[0], 0.5), mix(f.b[1], f.tip[1], 0.5)]), P(f.tip)], { w: 0.42, i: 0.42, tint: 0.45, rank: 0.8, per: 2 });
      for (let k = 1; k < nSec; k += 2) {
        const u = k / nSec;
        const a0 = [mix(0.08, W.wr[0] + 0.02, u), mix(-0.02, W.wr[1] - 0.02, u) - 0.04];
        out.line([P(a0), P(trail[k * 2])], { w: 0.38, i: 0.3, tint: 0.4, rank: 0.85, per: 1, raw: true });
      }
      const cov = [];
      for (let k = 0; k <= 6; k += 1) { const u = k / 6; cov.push(P([mix(0.09, W.wr[0], u), mix(-0.07, W.wr[1] - 0.09, u)])); }
      cov.push(P([mix(W.wr[0], W.tip[0], 0.5), mix(W.wr[1], W.tip[1], 0.5) - 0.06]));
      out.line(cov, { w: 0.42, i: 0.35, tint: 0.4, rank: 0.8, per: 2 });
      // stars: wrist, finger tips, elbow
      out.star(P(W.wr), { s: 1.0, i: 0.85, tint: warm, rank: 0.08 });
      out.star(P(prim[1].tip), { s: 0.9, i: 0.8, tint: warm, rank: 0.1 });
      out.star(P(prim[4].tip), { s: 0.6, i: 0.5, tint: warm, rank: 0.25 });
      out.star(P(W.el), { s: 0.6, i: 0.45, tint: 0.5, rank: 0.3 });
    }
    out.star([0.06, 0.0, 0.0], { s: 0.9, i: 0.7, tint: 0.55, rank: 0.12 });
    return out;
  }
  return { pose, rotX, rotY, add3 };
})();

// ======================================================================================
// Generic quadruped (bison, deer): same frame/landmark machinery as the horse.
// def: { F0, H0, NB, neckA[], neckL[], headA, top[], belly[], details[], shoulder, hip,
//        foreLen, hindLen, foreSamples, hindSamples, neutralFore, neutralHind, hoof, cloven,
//        offsets{LH,LF,RH,RF}, fore[], hind[] (walk keys), body[] (c, bob, pitch, flex, neck, head),
//        extras(out, ctx) }
// ======================================================================================
function makeQuadruped(D) {
  const F0 = frame(...D.F0), H0 = frame(...D.H0);
  const N = [];
  let f = frame(D.NB[0], D.NB[1], D.neckA[0]);
  N.push(f);
  for (let k = 1; k < D.neckA.length; k += 1) { f = child(f, D.neckL[k - 1], 0, D.neckA[k] - D.neckA[k - 1]); N.push(f); }
  const HD0 = child(f, D.neckL[D.neckL.length - 1], 0, D.headA - D.neckA[D.neckA.length - 1]);
  const frames0 = { F: F0, H: H0, HD: HD0 };
  N.forEach((n, k) => { frames0[`N${k + 1}`] = n; });
  const resolve = (list) => bindLandmarks(frames0, list.map((e) => (e[0] === 'HD' || e[0][0] === 'N') && e[3] === 'local' ? [e[0], ...apply(frames0[e[0]], e[1], e[2])] : e));
  const top = resolve(D.top), belly = resolve(D.belly);
  const details = D.details.map((d) => ({ ...d, pts: resolve(d.pts) }));
  const shoulder = resolve([D.shoulder])[0], hip = resolve([D.hip])[0];
  const named = Object.fromEntries(Object.entries(D.named || {}).map(([k, v]) => [k, resolve([v])[0]]));

  function pose(c, m = {}) {
    const amp = m.amp ?? 1;
    const [bob, pitch, flex, dNeck, dHead] = (D.body ? keyed(D.body, c) : [0, 0, 0, 0, 0]).map((v) => v * amp);
    const pivot = [0, D.F0[1]];
    const rot = (p, a) => { const s2 = Math.sin(a), co = Math.cos(a); const dx = p[0] - pivot[0], dy = p[1] - pivot[1]; return [pivot[0] + dx * co - dy * s2, pivot[1] + bob + (m.lift || 0) + dx * s2 + dy * co]; };
    const P0 = m.pitch || 0;
    const fo = rot([F0.x, F0.y], pitch + P0); const F = frame(fo[0], fo[1], pitch + P0);
    const ho = rot([H0.x, H0.y], pitch + P0); const H = frame(ho[0], ho[1], pitch + P0 + flex + (m.flex || 0));
    const fr = { F, H };
    const nb = apply(F, ...unapply(F0, D.NB[0], D.NB[1]));
    const neckRaise = m.neck || 0;                 // posture: + raises the neck (alert)
    let nf = frame(nb[0], nb[1], pitch + P0 + D.neckA[0] + dNeck + neckRaise);
    fr.N1 = nf;
    for (let k = 1; k < D.neckA.length; k += 1) { nf = child(nf, D.neckL[k - 1], 0, D.neckA[k] - D.neckA[k - 1] + dNeck * 0.5 + neckRaise * 0.5); fr[`N${k + 1}`] = nf; }
    fr.HD = child(nf, D.neckL[D.neckL.length - 1], 0, D.headA - D.neckA[D.neckA.length - 1] + dHead - dNeck * 0.8 - neckRaise * 1.1 + (m.head || 0));
    const P = ([fname, x, y]) => apply(fr[fname], x, y);
    const out = collector();
    const warm = D.tint ?? 0.5;
    out.line(top.map(P), { w: 1.0, i: 1.0, tint: warm, rank: 0.25, per: 4 });
    out.line(belly.map(P), { w: 0.85, i: 0.75, tint: warm, rank: 0.45, per: 4 });
    for (const d of details) out.line(d.pts.map(P), { w: 0.55, i: d.i, tint: 0.35, rank: 0.75, per: 3 });
    const legs = {};
    for (const name of ['LH', 'RH', 'LF', 'RF']) {
      const fore = name[1] === 'F';
      const u = fract(c - D.offsets[name]);
      const neutral = fore ? D.neutralFore : D.neutralHind;
      const keys = m.legs?.[name] || keyed(fore ? D.fore : D.hind, u);
      const a = keys.map((v, k) => mix(neutral[k], v, amp));
      const root = fore ? P(shoulder) : P(hip);
      const joints = legChain(root, fore ? F.a : H.a, fore ? D.foreLen : D.hindLen, a);
      legs[name] = joints;
      const near = name[0] === 'R';
      const zf = near ? 0.06 : -0.06, ii = near ? 1 : 0.5;
      const e = legEdges(joints, fore ? D.foreSamples : D.hindSamples);
      const anchorF = fore ? P(top[0]) : P(belly[belly.length - 1]);
      const anchorB = fore ? P(belly[0]) : P(top[top.length - 1]);
      out.line([anchorF, ...e.front], { w: near ? 0.9 : 0.7, i: 0.9 * ii, tint: warm, rank: 0.4, z: zf });
      out.line([anchorB, ...e.back], { w: near ? 0.85 : 0.65, i: 0.8 * ii, tint: warm, rank: 0.45, z: zf });
      out.line(hoofShape(joints, D.hoof, D.cloven), { w: 0.65, i: 0.7 * ii, tint: 0.6, rank: 0.55, z: zf, raw: true });
      out.line(e.centre.slice(0, -1), { w: 0.4, i: 0.2 * ii, tint: 0.3, rank: 0.85, z: zf, per: 2 });
      out.star(joints[2], { s: 0.75, i: 0.5 * ii, tint: 0.5, rank: 0.3, z: zf });
      out.star(joints[4], { s: 0.65, i: 0.55 * ii, tint: 0.6, rank: 0.2, z: zf });
    }
    D.extras?.(out, { fr, P, c, amp, m, legs, top, named, warm, t: m.time || 0 });
    return out;
  }
  return { pose, frames0 };
}

const LOCAL = 'local';
// ---------- BISON ----------
const BISON = makeQuadruped({
  tint: 0.72,
  F0: [0.20, 0.70, 0], H0: [-0.33, 0.70, 0],
  NB: [0.42, 0.66], neckA: [0.10], neckL: [0.16], headA: -1.18,
  top: [
    ['F', 0.40, 0.42], ['F', 0.50, 0.44],                         // chest hair, dewlap
    ['HD', 0.06, -0.20, LOCAL], ['HD', 0.17, -0.27, LOCAL], ['HD', 0.26, -0.22, LOCAL],   // beard
    ['HD', 0.36, -0.10, LOCAL], ['HD', 0.43, -0.07, LOCAL],         // chin
    ['HD', 0.46, -0.02, LOCAL], ['HD', 0.43, 0.04, LOCAL],          // muzzle, nose
    ['HD', 0.31, 0.075, LOCAL], ['HD', 0.16, 0.12, LOCAL], ['HD', 0.03, 0.14, LOCAL],   // brow, shaggy forehead
    ['HD', -0.06, 0.12, LOCAL],                                      // topknot
    ['F', 0.40, 0.86], ['F', 0.27, 0.99], ['F', 0.12, 1.03],         // neck rising into the hump
    ['F', -0.05, 0.96], ['F', -0.20, 0.86],                          // hump falls away
    ['H', -0.36, 0.81], ['H', -0.52, 0.80], ['H', -0.60, 0.77],       // loin, rump
    ['H', -0.64, 0.68], ['H', -0.62, 0.55]                            // buttock, hamstring
  ],
  belly: [['F', 0.25, 0.40], ['F', 0.08, 0.385], ['F', -0.10, 0.40], ['H', -0.26, 0.44], ['H', -0.38, 0.49]],
  details: [
    { pts: [['F', 0.30, 0.97], ['F', 0.36, 0.72], ['F', 0.40, 0.50]], i: 0.35 },     // edge of the shaggy cape
    { pts: [['F', -0.12, 0.92], ['F', -0.10, 0.65], ['F', -0.06, 0.42]], i: 0.3 },   // cape boundary
    { pts: [['H', -0.40, 0.80], ['H', -0.50, 0.70], ['H', -0.42, 0.52]], i: 0.3 },   // haunch
    { pts: [['HD', 0.05, 0.02, LOCAL], ['HD', 0.15, -0.05, LOCAL], ['HD', 0.30, -0.03, LOCAL]], i: 0.3 }
  ],
  shoulder: ['F', 0.36, 0.56], hip: ['H', -0.48, 0.66],
  named: { hump: ['F', 0.12, 1.03], rump: ['H', -0.52, 0.80], eye: ['HD', 0.14, 0.035, LOCAL] },
  foreLen: [0.14, 0.17, 0.13, 0.07], hindLen: [0.20, 0.22, 0.17, 0.07],
  foreSamples: [[1, 0.05, 0.10, 0.09], [1, 0.5, 0.075, 0.06], [2, 0.0, 0.04, 0.045], [2, 0.5, 0.028, 0.03], [3, 0.0, 0.032, 0.036], [3, 1.0, 0.03, 0.028]],
  hindSamples: [[1, 0.1, 0.07, 0.08], [1, 0.55, 0.045, 0.05], [2, 0.0, 0.034, 0.055], [2, 0.5, 0.026, 0.028], [3, 0.0, 0.03, 0.036], [3, 1.0, 0.03, 0.028]],
  neutralFore: [-0.6, 0.0, 0.0, 0.45], neutralHind: [0.55, -0.7, 0.1, 0.45], hoof: 0.045, cloven: true,
  // lateral-sequence walk: LH, LF, RH, RF; stance 0..0.64
  offsets: { LH: 0.0, LF: 0.25, RH: 0.5, RF: 0.75 },
  fore: [[0.00, -0.45, 0.22, 0.18, 0.40], [0.30, -0.62, 0.0, 0.0, 0.55], [0.60, -0.80, -0.26, -0.28, 0.30],
    [0.72, -0.78, -0.22, -0.80, -0.50], [0.84, -0.58, 0.22, -0.55, -0.40], [0.94, -0.48, 0.32, 0.10, 0.15]],
  hind: [[0.00, 0.72, -0.52, 0.24, 0.40], [0.30, 0.55, -0.75, 0.05, 0.55], [0.60, 0.32, -0.98, -0.28, 0.30],
    [0.72, 0.40, -1.05, -0.72, -0.45], [0.84, 0.66, -0.80, -0.35, -0.25], [0.94, 0.76, -0.58, 0.12, 0.25]],
  body: [[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], [0.12, -0.012, 0.012, 0.0, -0.035, 0.02], [0.25, 0.0, 0.0, 0.0, 0.0, 0.0],
    [0.37, -0.012, -0.012, 0.0, -0.035, 0.02], [0.5, 0.0, 0.0, 0.0, 0.0, 0.0], [0.62, -0.012, 0.012, 0.0, -0.035, 0.02],
    [0.75, 0.0, 0.0, 0.0, 0.0, 0.0], [0.87, -0.012, -0.012, 0.0, -0.035, 0.02]],
  extras(out, { fr, P, c, amp, named, warm, t }) {
    const HD = fr.HD;
    // horns: short, curving out and up, hooking forward (near and far)
    for (const [z, ii] of [[0.05, 1], [-0.05, 0.5]]) {
      out.line([apply(HD, 0.02, 0.13), apply(HD, -0.03, 0.19), apply(HD, -0.01, 0.255), apply(HD, 0.05, 0.27)], { w: 0.8, i: 0.85 * ii, tint: 0.55, rank: 0.35, per: 3, z });
      out.line([apply(HD, 0.06, 0.13), apply(HD, 0.02, 0.19), apply(HD, 0.05, 0.27)], { w: 0.5, i: 0.4 * ii, tint: 0.55, rank: 0.6, per: 3, z });
      out.star(apply(HD, 0.05, 0.27), { s: 0.7, i: 0.6 * ii, rank: 0.25, z });
    }
    out.line([apply(HD, 0.0, 0.07), apply(HD, -0.06, 0.08), apply(HD, -0.03, 0.03)], { w: 0.55, i: 0.5, tint: 0.6, rank: 0.5, per: 2 }); // ear in the shag
    out.star(P(named.eye), { s: 1.1, i: 0.95, tint: 0.65, rank: 0.0 });
    out.star(P(named.hump), { s: 1.1, i: 0.95, tint: 0.7, rank: 0.02 });
    out.star(P(named.rump), { s: 0.8, i: 0.6, rank: 0.12 });
    out.star(apply(HD, 0.45, 0.0), { s: 0.7, i: 0.6, rank: 0.15 });
    // tail: hangs with a tuft, swishes slowly
    const root = P(['H', ...unapply(BISON_H0, -0.60, 0.76)]);
    const sw = Math.sin(t * 1.4 + c * TAU) * 0.15 * amp;
    const a0 = -Math.PI / 2 - 0.35 + sw;
    const p1 = [root[0] + Math.cos(a0) * 0.12, root[1] + Math.sin(a0) * 0.12];
    const p2 = [p1[0] + Math.cos(a0 + sw * 0.8) * 0.1, p1[1] + Math.sin(a0 + sw * 0.8) * 0.1];
    out.line([root, p1, p2], { w: 0.55, i: 0.55, tint: 0.6, rank: 0.6, per: 3 });
    out.line([p2, [p2[0] - 0.02, p2[1] - 0.06], [p2[0] + 0.02, p2[1] - 0.055], p2], { w: 0.45, i: 0.45, tint: 0.6, rank: 0.7, per: 2 });
    // hair along the forelegs and the beard: short strokes
    for (let k = 0; k < 5; k += 1) {
      const a = apply(fr.F, 0.40 - k * 0.04 - 0.20, 0.43 - k * 0.012 - 0.70);
      out.line([a, [a[0] - 0.012, a[1] - 0.05 - 0.01 * Math.sin(k * 3.1)]], { w: 0.4, i: 0.3, tint: 0.6, rank: 0.8, per: 1, raw: true });
    }
  }
});
const BISON_H0 = frame(-0.33, 0.70, 0);

// ---------- WHITE-TAILED DEER (doe) ----------
const DEER = makeQuadruped({
  tint: 0.45,
  F0: [0.14, 0.80, 0], H0: [-0.22, 0.83, 0],
  NB: [0.33, 0.86], neckA: [1.12, 0.92], neckL: [0.21, 0.20], headA: -0.95,
  top: [
    ['F', 0.42, 0.63], ['F', 0.47, 0.74],                              // breast, chest
    ['N1', 0.08, -0.085, LOCAL], ['N1', 0.20, -0.07, LOCAL], ['N2', 0.10, -0.06, LOCAL], ['N2', 0.20, -0.05, LOCAL],
    ['HD', 0.05, -0.085, LOCAL], ['HD', 0.14, -0.095, LOCAL],          // jowl
    ['HD', 0.26, -0.06, LOCAL], ['HD', 0.325, -0.045, LOCAL],          // jaw, chin
    ['HD', 0.35, -0.015, LOCAL], ['HD', 0.335, 0.015, LOCAL],          // muzzle, nose
    ['HD', 0.22, 0.04, LOCAL], ['HD', 0.10, 0.065, LOCAL], ['HD', 0.02, 0.05, LOCAL],   // bridge, forehead, poll
    ['N2', 0.14, 0.05, LOCAL], ['N2', 0.02, 0.06, LOCAL], ['N1', 0.12, 0.07, LOCAL], ['N1', 0.0, 0.085, LOCAL],
    ['F', 0.13, 1.0], ['F', -0.02, 0.975],                              // withers, back
    ['H', -0.18, 0.985], ['H', -0.36, 1.0], ['H', -0.47, 0.975],         // loin, croup
    ['H', -0.53, 0.90], ['H', -0.52, 0.76]                               // rump, hamstring
  ],
  belly: [['F', 0.30, 0.585], ['F', 0.15, 0.55], ['F', 0.0, 0.545], ['H', -0.12, 0.565], ['H', -0.22, 0.61], ['H', -0.26, 0.65]],
  details: [
    { pts: [['F', 0.13, 0.96], ['F', 0.26, 0.82], ['F', 0.40, 0.70]], i: 0.35 },
    { pts: [['H', -0.26, 0.93], ['H', -0.40, 0.88], ['H', -0.51, 0.86]], i: 0.3 },
    { pts: [['HD', 0.06, 0.0, LOCAL], ['HD', 0.13, -0.05, LOCAL], ['HD', 0.22, -0.035, LOCAL]], i: 0.3 }
  ],
  shoulder: ['F', 0.38, 0.69], hip: ['H', -0.38, 0.84],
  named: { eye: ['HD', 0.12, 0.022, LOCAL], withers: ['F', 0.13, 1.0], croup: ['H', -0.36, 1.0], tail: ['H', -0.50, 0.95], nose: ['HD', 0.34, 0.0, LOCAL] },
  foreLen: [0.18, 0.25, 0.22, 0.08], hindLen: [0.25, 0.32, 0.27, 0.08],
  foreSamples: [[1, 0.06, 0.045, 0.04], [1, 0.5, 0.028, 0.024], [2, 0.0, 0.022, 0.026], [2, 0.5, 0.012, 0.016], [3, 0.0, 0.017, 0.02], [3, 1.0, 0.016, 0.014]],
  hindSamples: [[1, 0.1, 0.06, 0.07], [1, 0.55, 0.035, 0.04], [2, 0.0, 0.022, 0.04], [2, 0.5, 0.013, 0.018], [3, 0.0, 0.017, 0.02], [3, 1.0, 0.016, 0.014]],
  neutralFore: [-0.62, 0.0, 0.0, 0.5], neutralHind: [0.55, -0.72, 0.12, 0.5], hoof: 0.032, cloven: true,
  offsets: { LH: 0.0, LF: 0.25, RH: 0.5, RF: 0.75 },
  // careful walk: high lifts of the foreleg, precise placement
  fore: [[0.00, -0.48, 0.20, 0.18, 0.45], [0.30, -0.65, 0.0, 0.0, 0.55], [0.60, -0.84, -0.28, -0.28, 0.35],
    [0.70, -0.80, -0.20, -0.80, -0.90], [0.80, -0.55, 0.42, -0.85, -1.10], [0.90, -0.42, 0.50, -0.15, -0.30], [0.96, -0.45, 0.32, 0.12, 0.25]],
  hind: [[0.00, 0.72, -0.58, 0.22, 0.45], [0.30, 0.58, -0.76, 0.04, 0.55], [0.60, 0.40, -0.88, -0.20, 0.35],
    [0.72, 0.50, -1.0, -0.75, -0.60], [0.84, 0.72, -0.80, -0.40, -0.35], [0.94, 0.78, -0.62, 0.12, 0.25]],
  body: [[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], [0.12, -0.008, 0.008, 0.0, -0.025, 0.02], [0.25, 0.0, 0.0, 0.0, 0.0, 0.0],
    [0.37, -0.008, -0.008, 0.0, -0.025, 0.02], [0.5, 0.0, 0.0, 0.0, 0.0, 0.0], [0.62, -0.008, 0.008, 0.0, -0.025, 0.02],
    [0.75, 0.0, 0.0, 0.0, 0.0, 0.0], [0.87, -0.008, -0.008, 0.0, -0.025, 0.02]],
  extras(out, { fr, P, named, m, t }) {
    const HD = fr.HD;
    // large ears; m.ears = rotation (rad), m.earTurn = how much they face the viewer (narrower)
    const turn = m.earTurn || 0;
    for (const [z, ii, off] of [[0.04, 1, 0], [-0.04, 0.55, 0.12]]) {
      const ea = 0.35 + (m.ears || 0) + off + 0.05 * Math.sin(t * 2.1 + off * 9);
      const base = apply(HD, 0.02, 0.055);
      const dir = HD.a + Math.PI / 2 + ea;
      const L = 0.17, Wd = 0.055 * (1 - 0.55 * turn);
      const tip = [base[0] + Math.cos(dir) * L, base[1] + Math.sin(dir) * L];
      const nx = -Math.sin(dir), ny = Math.cos(dir);
      const b0 = [base[0] - nx * 0.02, base[1] - ny * 0.02], b1 = [base[0] + nx * 0.022, base[1] + ny * 0.022];
      const m0 = [base[0] + Math.cos(dir) * L * 0.5 - nx * Wd, base[1] + Math.sin(dir) * L * 0.5 - ny * Wd];
      const m1 = [base[0] + Math.cos(dir) * L * 0.55 + nx * Wd * 0.9, base[1] + Math.sin(dir) * L * 0.55 + ny * Wd * 0.9];
      out.line([b0, m0, tip, m1, b1], { w: 0.75, i: 0.9 * ii, tint: 0.5, rank: 0.3, per: 3, z });
      out.star(tip, { s: 0.7, i: 0.65 * ii, rank: 0.2, z });
    }
    out.star(P(named.eye), { s: 1.2, i: 1.0, tint: 0.55, rank: 0.0 });
    out.star(P(named.nose), { s: 0.7, i: 0.6, rank: 0.15 });
    out.star(P(named.withers), { s: 0.85, i: 0.7, rank: 0.08 });
    out.star(P(named.croup), { s: 0.8, i: 0.65, rank: 0.1 });
    // white tail: down and still, or raised as a flag (m.tail 0..1)
    const flag = m.tail || 0;
    const root = P(named.tail);
    const ta = fr.H.a + mix(-Math.PI / 2 - 0.25, Math.PI * 0.42, flag) + 0.06 * Math.sin(t * 3.0) * (1 - flag);
    const tl = 0.13 + 0.03 * flag;
    const tip = [root[0] + Math.cos(ta) * tl, root[1] + Math.sin(ta) * tl];
    const nx = -Math.sin(ta), ny = Math.cos(ta);
    const wd = 0.018 + 0.035 * flag;
    out.line([root, [mix(root[0], tip[0], 0.5) + nx * wd, mix(root[1], tip[1], 0.5) + ny * wd], tip, [mix(root[0], tip[0], 0.5) - nx * wd, mix(root[1], tip[1], 0.5) - ny * wd], root], { w: 0.65, i: 0.7 + 0.3 * flag, tint: 0.2, rank: 0.4, per: 3 });
  }
});

// Deer bound: a continuous bounding cycle, u = 0 at the hind legs' touchdown under the body.
//   0.00-0.15  hinds load and push off; the forelegs, just lifted, fold up under the chest
//   0.15-0.60  flight: a ballistic arc; body extends, forelegs unfold and reach forward, hinds trail
//              then fold forward
//   0.60       forelegs touch down ahead of the body
//   0.60-1.00  the body rolls over the forelegs (fetlocks sink) while the hinds swing under it
// Consecutive bounds flow into each other; entry and exit blend from and to standing.
const DEER_BOUND_BODY = [ // [u, lift, pitch, flex, neck, head]
  [0.00, -0.07, 0.04, 0.10, -0.05, 0.03],
  [0.15, 0.00, 0.02, -0.04, 0.06, -0.04],
  [0.38, 0.00, 0.00, -0.10, 0.07, -0.04],
  [0.60, -0.02, -0.05, 0.00, 0.00, 0.03],
  [0.75, -0.07, -0.02, 0.06, -0.06, 0.05],
  [0.90, -0.05, 0.03, 0.10, -0.05, 0.04]
];
const DEER_BOUND_FORE = [
  [0.00, -0.95, -0.35, -0.55, 0.20],
  [0.08, -0.85, 0.30, -1.30, -1.20],
  [0.15, -0.65, 1.15, -1.50, -1.40],
  [0.30, -0.40, 1.10, -0.40, -0.40],
  [0.45, -0.15, 0.95, 0.65, 0.45],
  [0.54, -0.22, 0.68, 0.55, 0.55],
  [0.60, -0.35, 0.40, 0.35, 0.55],
  [0.72, -0.70, 0.05, 0.00, 0.85],
  [0.86, -0.95, -0.30, -0.35, 0.60]
];
const DEER_BOUND_HIND = [
  [0.00, 0.95, -1.05, 0.05, 0.60],
  [0.08, 0.65, -0.95, -0.15, 0.55],
  [0.15, 0.15, -0.70, -0.55, -0.25],
  [0.30, -0.02, -0.95, -0.75, -0.55],
  [0.45, 0.40, -1.30, -0.55, -0.80],
  [0.60, 0.75, -1.20, -0.20, -0.45],
  [0.75, 0.92, -1.00, -0.05, 0.00],
  [0.90, 0.98, -1.00, 0.00, 0.30]
];
export const DEER_BOUND_AIR = [0.15, 0.60];   // takeoff and forelegs' touchdown within the cycle
// Pose overrides for a bound at cycle position u (amount 0..1 blends from standing). The body's
// pitch follows the flight path (nose up on takeoff, level at the top, down toward the landing);
// the head stays steadier than the body.
export function deerBound(u, amount = 1, height = 0.42, length = 1.6) {
  const w = fract(u);
  const [lift, pitch, flex, neck, head] = keyed(DEER_BOUND_BODY, w);
  const [a, b] = DEER_BOUND_AIR;
  const sA = clamp((w - a) / (b - a));
  const inAir = w > a && w < b;
  const arc = inAir ? 4 * height * sA * (1 - sA) : 0;
  const slope = inAir ? (4 * height * (1 - 2 * sA)) / (length * 0.82) : 0;
  const pathPitch = 0.3 * Math.atan(slope) * smooth(0, 0.18, sA) * (1 - smooth(0.82, 1, sA));
  const legs = {
    LF: keyed(DEER_BOUND_FORE, w), RF: keyed(DEER_BOUND_FORE, w - 0.04),
    LH: keyed(DEER_BOUND_HIND, w), RH: keyed(DEER_BOUND_HIND, w - 0.03)
  };
  const stand = { LF: [-0.62, 0, 0, 0.5], RF: [-0.62, 0, 0, 0.5], LH: [0.55, -0.72, 0.12, 0.5], RH: [0.55, -0.72, 0.12, 0.5] };
  for (const k of Object.keys(legs)) legs[k] = legs[k].map((v, i) => mix(stand[k][i], v, amount));
  const totalPitch = (pitch + pathPitch) * amount;
  return { legs, lift: (lift + arc) * amount, pitch: totalPitch, flex: flex * amount, neck: neck * amount, head: head * amount - 0.6 * totalPitch, airborne: inAir ? Math.sin(Math.PI * sA) : 0 };
}
// Ground covered over a cycle: constant speed in the air (ballistic), a little on the ground.
export function deerBoundTravel(u) {
  const w = fract(u), [a, b] = DEER_BOUND_AIR;
  const g = w < a ? 0.09 * w / a : w < b ? 0.09 + 0.82 * (w - a) / (b - a) : 0.91 + 0.09 * (w - b) / (1 - b);
  return Math.floor(u) + g;
}

// ---------- SALMON (3D: lateral body wave seen from above/side) ----------
// x forward, y dorsal, z lateral. s = 0 at the snout .. 1 at the tail fork.
const SALMON = (() => {
  // dorsal (+) and ventral (-) profile half-depths along s
  const DORS = [[0, 0.0], [0.04, 0.04], [0.12, 0.085], [0.25, 0.12], [0.40, 0.125], [0.55, 0.105], [0.70, 0.07], [0.82, 0.045], [0.86, 0.045]];
  const VENT = [[0, -0.005], [0.03, -0.035], [0.10, -0.07], [0.22, -0.10], [0.38, -0.105], [0.55, -0.09], [0.70, -0.06], [0.82, -0.038], [0.86, -0.04]];
  const prof = (tab, s) => { for (let k = 1; k < tab.length; k += 1) if (s <= tab[k][0]) { const [s0, v0] = tab[k - 1], [s1, v1] = tab[k]; const u = (s - s0) / (s1 - s0); return mix(v0, v1, u * u * (3 - 2 * u)); } return tab[tab.length - 1][1]; };
  // m: { phase, amp (wave amplitude 0..1), flexY (arch, + = belly concave), bendZ (C-flex) }
  function spine(s, m) {
    const amp = m.amp ?? 1;
    const A = (0.012 + 0.11 * smooth(0.25, 1.0, s) * s) * amp;  // the wave grows from mid-body to the tail
    const z = A * Math.sin((m.phase || 0) - s * TAU * 0.95) + (m.bendZ || 0) * s * s * 0.35;
    const y = (m.flexY || 0) * (s - 0.45) * (s - 0.45) * 0.6;
    return [0.45 - s, y, z];
  }
  // local frame along the spine (tangent) so fins and edges follow the bend
  function at(s, v, m) {
    const p = spine(s, m), q = spine(s + 0.01, m);
    const tx = q[0] - p[0], ty = q[1] - p[1], tz = q[2] - p[2], L = Math.hypot(tx, ty, tz) || 1;
    // dorsal direction: perpendicular to the tangent in the x-y plane
    const ny = tx / L, nx = -ty / L;
    return [p[0] - nx * v * (tx < 0 ? -1 : 1), p[1] + ny * v * (tx < 0 ? -1 : 1), p[2]];
  }
  function pose(m = {}) {
    const out = collector();
    const warm = 0.75;
    const S = [];
    for (let k = 0; k <= 22; k += 1) S.push(0.86 * (k / 22) ** 1.05);
    const dorsal = S.map((s) => at(s, prof(DORS, s), m));
    const ventral = S.map((s) => at(s, prof(VENT, s), m));
    // caudal fin: slightly forked, follows the tail's angle
    const tb = 0.86;
    const fork = (v, ds) => at(tb + ds, v, m);
    const tailU = [at(tb, 0.045, m), fork(0.11, 0.09), fork(0.17, 0.165), fork(0.03, 0.135), fork(0.0, 0.125), fork(-0.03, 0.135), fork(-0.16, 0.16), fork(-0.10, 0.09), at(tb, -0.04, m)];
    out.line([...dorsal, ...tailU, ...ventral.slice().reverse()], { w: 1.0, i: 1.0, tint: warm, rank: 0.3, per: 2 });
    // head: gill cover arc, jaw line (hooked kype hint), eye
    out.line([at(0.17, 0.08, m), at(0.2, 0.02, m), at(0.18, -0.05, m), at(0.15, -0.075, m)], { w: 0.55, i: 0.5, tint: 0.5, rank: 0.6, per: 3 });
    out.line([at(0.0, -0.002, m), at(0.05, -0.012, m), at(0.12, -0.03, m)], { w: 0.5, i: 0.45, tint: 0.5, rank: 0.65, per: 2 });
    out.star(at(0.07, 0.03, m), { s: 1.1, i: 1.0, tint: 0.7, rank: 0.0 });
    // fins: dorsal, adipose, pectoral, pelvic, anal
    const fin = (s0, s1, v, h, back) => { const a = at(s0, v, m), b = at(s1, v * 0.95, m), tip = at(mix(s0, s1, back), v + h, m); out.line([a, tip, b], { w: 0.65, i: 0.75, tint: warm, rank: 0.5, per: 2 }); };
    fin(0.36, 0.50, prof(DORS, 0.36), 0.085, 0.75);
    fin(0.69, 0.73, prof(DORS, 0.69), 0.03, 0.8);
    fin(0.47, 0.55, prof(VENT, 0.47), -0.055, 0.85);
    fin(0.63, 0.71, prof(VENT, 0.63), -0.05, 0.85);
    const pec = at(0.21, -0.05, m), pecTip = at(0.31, -0.095, m);
    out.line([pec, pecTip, at(0.27, -0.06, m)], { w: 0.55, i: 0.6, tint: warm, rank: 0.5, per: 2 });
    // lateral line and a few scale-row hints
    out.line(S.filter((s) => s > 0.18 && s < 0.84).map((s) => at(s, 0.012, m)), { w: 0.45, i: 0.35, tint: 0.5, rank: 0.75, per: 1 });
    for (const s of [0.3, 0.45, 0.6]) out.star(at(s, 0.05, m), { s: 0.5, i: 0.35, tint: 0.6, rank: 0.4 });
    out.star(fork(0.17, 0.165), { s: 0.8, i: 0.7, rank: 0.1 });
    out.star(fork(-0.16, 0.16), { s: 0.8, i: 0.7, rank: 0.1 });
    out.star(at(0.43, prof(DORS, 0.43) + 0.08, m), { s: 0.7, i: 0.6, rank: 0.15 });
    return out;
  }
  return { pose, spine };
})();

export const ANIMALS = { horse: HORSE, eagle: EAGLE, bison: BISON, deer: DEER, salmon: SALMON };
export { clamp, fract, mix, smooth, TAU };

// Preview descriptors for tools/living-firepit-animals-preview.mjs: one motion cycle per sheet.
let previewHeadView = 0;
export function previewPose(name) {
  if (name === "horse") return { duration: 1, cell: [360, 260], view: { scale: 150, cx: 0.1, cy: 0.62 }, at: (c) => HORSE.pose(c, { time: c * 0.8 }) };
  if (name === "eagle-beat") {
    // one wingbeat seen from below and a little behind (as in the sky), and side-on
    return { duration: 1, cell: [480, 300], view: { scale: 190, cx: 0, cy: 0, project: (p) => [p[2], p[0] * 0.45 + p[1] * 0.9] }, at: (u) => EAGLE.pose({ time: u, flap: u * TAU, amp: 1, spread: 0.55, bend: 0.7 }) };
  }
  if (name === "eagle-head") {
    // three views of the head and shoulders: from below, from the side, three-quarter from below
    const views = [(p) => [p[2], p[0]], (p) => [p[0], p[1]], (p) => { const q = EAGLE.rotY(EAGLE.rotX(p, -0.9), 0.7); return [q[0], q[2] * 0.5 + q[1]]; }];
    return { duration: 3, cell: [300, 300], view: { scale: 900, cx: 0, cy: 0, project: (p) => { const k = Math.min(2, Math.floor(previewHeadView)); return views[k](p); } },
      at: (u) => { previewHeadView = u; const g = EAGLE.pose({ amp: 0, spread: 0.5, bend: 0.7 }); const off = [0.27, 0, 0]; const c = (p) => [p[0] - off[0], p[1], p[2]];
        return { lines: g.lines.map((l) => ({ ...l, pts: l.pts.map(c) })), stars: g.stars.map((st) => ({ ...st, p: c(st.p) })) }; } };
  }
  if (name === "eagle-below") {
    return { duration: 1, cell: [720, 420], view: { scale: 300, cx: 0, cy: 0.0, project: (p) => [p[2], p[0] + p[1] * 0.3] }, at: (u) => EAGLE.pose({ time: u * 4, amp: 0, spread: 0.5, bend: 0.7 }) };
  }
  if (name === "eagle" || name === "eagle-flap") {
    // seen from below and in front, tilted like an eagle circling overhead
    const view = { scale: 92, cx: 0, cy: 0, project: (p) => [p[0], p[1] * 0.6 + p[2] * 0.8] };
    const flapping = name === "eagle-flap";
    return { duration: 1, cell: [360, 260], view, at: (u) => EAGLE.pose({ time: u * 4, flap: u * TAU, amp: flapping ? 1 : 0, spread: 0.45, bend: 0.7 }) };
  }
  if (name === "bison") return { duration: 1, cell: [360, 260], view: { scale: 140, cx: 0.0, cy: 0.58 }, at: (c) => BISON.pose(c, { time: c * 2 }) };
  if (name === "deer") return { duration: 1, cell: [360, 300], view: { scale: 140, cx: 0.0, cy: 0.75 }, at: (c) => DEER.pose(c, { time: c * 2 }) };
  if (name === "deer-air") return { duration: 1, cell: [360, 300], view: { scale: 110, cx: 0.0, cy: 0.85 }, at: (u) => DEER.pose(0, { ...deerBound(0.12 + u * 0.55), amp: 1, tail: 1, time: u }) };
  if (name === "deer-bound") return { duration: 1, cell: [360, 300], view: { scale: 110, cx: 0.0, cy: 0.85 }, at: (u) => { const m = deerBound(u); const g = DEER.pose(0, { ...m, amp: 1, tail: 1, time: u }); const dx = -(deerBoundTravel(u) - u) * 0; return g; } };
  if (name === "salmon-sky") return { duration: 1, cell: [420, 200], view: { scale: 300, cx: 0.0, cy: 0.0, project: (p) => [p[0], p[1] * Math.cos(0.45) - p[2] * Math.sin(0.45)] }, at: (u) => SALMON.pose({ phase: u * TAU, amp: 1 }) };
  if (name === "salmon") return { duration: 1, cell: [360, 220], view: { scale: 250, cx: 0.0, cy: 0.0, project: (p) => [p[0], p[1] * 0.75 + p[2] * 0.66] }, at: (u) => SALMON.pose({ phase: u * TAU, amp: 1 }) };
  throw new Error(`no preview for ${name}`);
}
