export function createQuantumFoamPresetShaderEntries({ modularShaderPrelude, modularTransitionShaderBlock }) {
  return [[141, {
    name: "Quantum Foam",
    source: `${modularShaderPrelude}
${modularTransitionShaderBlock}

float hash1001(vec3 p) {
    p = fract(p * vec3(17.1, 31.7, 47.9));
    p += dot(p, p.yzx + 19.19);
    return fract((p.x + p.y) * p.z);
}

float map1001(vec3 p) {
    vec3 q = p;
    q.xy *= rot(presetTime * 0.2 + p.z * 0.05);
    vec3 cell = fract(q) - 0.5;
    vec3 id = floor(q);
    
    float t = presetTime * 2.0 + hash1001(id) * 6.28;
    float pulse = sin(t + bassRel * 5.0) * 0.5 + 0.5;
    
    float rad = 0.1 + 0.15 * pulse;
    float sph = length(cell) - rad;
    
    float c1 = length(cell.xy) - 0.02 - 0.02 * midRel;
    float c2 = length(cell.yz) - 0.02 - 0.02 * midRel;
    float c3 = length(cell.zx) - 0.02 - 0.02 * midRel;
    
    float links = min(c1, min(c2, c3));
    float d = min(sph, links);
    
    d += 0.015 * sin(15.0 * p.x + presetTime * 5.0) * sin(15.0 * p.y) * sin(15.0 * p.z) * globalEnergy;
    
    return d * 0.7;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * resolution.xy) / resolution.y;
    vec3 ro = vec3(0.0, 0.0, -3.0 + presetTime * 0.5);
    vec3 rd = normalize(vec3(uv, 1.0));
    rd.xy *= rot(presetTime * 0.1);
    
    float t = 0.0;
    vec3 p;
    float d;
    float glow = 0.0;
    
    for(int i = 0; i < 60; i++) {
        p = ro + rd * t;
        d = map1001(p);
        if(d < 0.001 || t > 12.0) break;
        glow += 0.005 / (0.005 + abs(d)) * bassRel;
        t += d;
    }
    
    vec3 col = vec3(0.0);
    if(t < 12.0) {
        vec2 e = vec2(0.005, 0.0);
        vec3 n = normalize(vec3(
            map1001(p + e.xyy) - map1001(p - e.xyy),
            map1001(p + e.yxy) - map1001(p - e.yxy),
            map1001(p + e.yyx) - map1001(p - e.yyx)
        ));
        
        vec3 light = normalize(vec3(1.0, 2.0, -1.0));
        float diff = max(dot(n, light), 0.0);
        float spec = pow(max(dot(reflect(-light, n), -rd), 0.0), 32.0);
        
        vec3 base = 0.5 + 0.5 * cos(vec3(0.0, 1.0, 2.0) + p.z + presetTime + globalEnergy);
        col = base * (diff * 0.8 + 0.2) + spec * 0.5;
    }
    
    col += vec3(0.2, 0.5, 1.0) * glow * 0.2;
    col = mix(col, vec3(0.02, 0.0, 0.05), smoothstep(4.0, 12.0, t));
    col = col / (1.0 + col);
    
    outColor = vec4(col, 1.0);
    
}
`
  }]];
}
