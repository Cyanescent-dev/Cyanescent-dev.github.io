const USER_PRESETS_STORAGE_KEY = "cyanescent.userPresets.v1";
const USER_PRESET_ID_BASE = 10000;

function safeLocalStorage() {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function readArray(key) {
  const storage = safeLocalStorage();
  if (!storage) return [];
  try {
    const parsed = JSON.parse(storage.getItem(key) || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeArray(key, value) {
  const storage = safeLocalStorage();
  if (!storage) return false;
  storage.setItem(key, JSON.stringify(Array.isArray(value) ? value : []));
  return true;
}

function stableSlug(value) {
  return String(value || "user-preset")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64) || "user-preset";
}

function nextAvailableUserId(usedIds, requestedId) {
  const numeric = Math.round(Number(requestedId));
  if (Number.isFinite(numeric) && numeric >= USER_PRESET_ID_BASE && !usedIds.has(numeric)) {
    return numeric;
  }
  let next = USER_PRESET_ID_BASE;
  while (usedIds.has(next)) next += 1;
  return next;
}

export function createUserPresetStore({
  storageKey = USER_PRESETS_STORAGE_KEY,
  builtInPresetIds = [],
  loadPersisted = true
} = {}) {
  let presets = (loadPersisted ? readArray(storageKey) : [])
    .filter((preset) => preset && typeof preset === "object");

  function save() {
    writeArray(storageKey, presets);
  }

  function all() {
    return presets.map((preset) => ({ ...preset }));
  }

  function usedIds(extraIds = []) {
    return new Set([
      ...builtInPresetIds.map(Number).filter(Number.isFinite),
      ...presets.map((preset) => Number(preset.id)).filter(Number.isFinite),
      ...extraIds.map(Number).filter(Number.isFinite)
    ]);
  }

  function install(validatedPreset, extraUsedIds = []) {
    const base = validatedPreset?.preset || validatedPreset;
    const id = nextAvailableUserId(usedIds(extraUsedIds), base.id);
    const installed = {
      ...base,
      id,
      originalId: base.originalId ?? base.id,
      storageId: `${id}-${stableSlug(base.name)}`,
      imported: true,
      importedAt: new Date().toISOString()
    };
    presets = presets.filter((preset) => Number(preset.id) !== id);
    presets.push(installed);
    save();
    return { ...installed };
  }

  function remove(id) {
    const numericId = Number(id);
    const before = presets.length;
    presets = presets.filter((preset) => Number(preset.id) !== numericId);
    if (presets.length !== before) save();
    return presets.length !== before;
  }

  function replaceAll(nextPresets) {
    presets = Array.isArray(nextPresets) ? nextPresets.filter(Boolean) : [];
    save();
  }

  return {
    all,
    install,
    remove,
    replaceAll,
    usedIds
  };
}
