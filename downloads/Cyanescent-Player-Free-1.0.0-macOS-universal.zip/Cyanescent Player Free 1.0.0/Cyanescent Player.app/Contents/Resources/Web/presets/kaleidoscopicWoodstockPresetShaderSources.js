export const createKaleidoscopicWoodstockPresetShaderEntries = ({ modularShaderPrelude, modularTransitionShaderBlock }) => {
    return [    [147, {
        name: "Kaleidoscopic Woodstock",
        source: `${modularShaderPrelude}\n${modularTransitionShaderBlock}
  uniform vec4 wwMotion;  // integrated rotation, counter-rotation, shape phase, colour cycle
  uniform vec4 wwBands;   // bass, mids, highs, sustained energy
  uniform vec4 wwMood;    // kick envelope, breakdown, anticipation, treble onset envelope
  uniform vec4 wwPattern; // persistent portrait, palette offset, breath, director present
  uniform vec4 wwEvent;   // seconds since drop, strength (geometry, never a white flash)
  vec3 palette(float t) {
      vec3 a = vec3(0.5, 0.5, 0.5);
      vec3 b = vec3(0.5, 0.5, 0.5);
      vec3 c = vec3(1.0, 1.0, 1.0);
      vec3 d = vec3(0.263,0.416,0.557);
      return a + b*cos( 6.28318*(c*t+d) );
  }
  void main() {
      vec2 uv = (gl_FragCoord.xy - 0.5 * resolution.xy) / resolution.y;
      vec2 uv0 = uv;
      
      bool directed = wwPattern.w > 0.5;
      vec4 bands = directed ? wwBands : clamp(vec4(u_slowBass, mids, highs, u_slowLevel), 0.0, 1.0);
      vec4 mood = directed ? wwMood : vec4(clamp(kickPulse, 0.0, 1.0), breakdownState, buildUpState, 0.0);
      float energy = bands.w, low = bands.x, mid = bands.y, high = bands.z;
      float pulse = mood.x, calm = mood.y, tension = mood.z;
      float breath = directed ? wwPattern.z : sin(mod(time * 0.5, 2.0 * PI));
      float evolution = directed ? wwMotion.z : mod(time * 0.40, 2.0 * PI);
      float colourCycle = directed ? wwMotion.w + wwPattern.y : fract(time * 0.018);
      float portrait = directed ? sin(wwPattern.x * 2.0 * PI) : 0.0;
      float age = directed ? wwEvent.x : 8.0;
      float front = exp(-pow((length(uv0) - (age * 0.48 - 0.04)) / 0.13, 2.0));
      front *= directed ? wwEvent.y * smoothstep(0.0, 0.09, age) * (1.0 - smoothstep(2.0, 3.0, age)) : 0.0;
      // Bass pumps the mandala, while a drop unfolds a travelling annulus through it.
      // The event has no rotation-speed or exposure boost.
      uv *= 1.0 + breath * (0.014 + 0.025 * low) - 0.026 * pulse - 0.15 * front + 0.06 * calm;
      uv *= rot(directed ? wwMotion.x : mod(time * 0.15, 2.0 * PI));
      
      float a = atan(uv.y, uv.x);
      float r = length(uv);
      // Keep exact eightfold symmetry while its internal petals unfold and develop.
      float petals = 8.0;
      float sect = 6.28318 / petals;
      a = mod(a, sect) - sect * 0.5;
      a += sin(a * petals) * (0.055 * mid + 0.08 * tension + 0.17 * front);
      uv = vec2(cos(a), sin(a)) * r;
      
      vec3 col = vec3(0.0);
      for (int i = 0; i < 4; i++) {
          float spacing = 1.48 + 0.10 * low + 0.09 * mid + 0.08 * tension - 0.12 * calm + 0.055 * portrait;
          uv = fract(uv * (spacing + breath * 0.014 * low)) - 0.5;
          float direction = mod(float(i), 2.0) < 0.5 ? 1.0 : -1.0;
          float turn = directed ? wwMotion.y : mod(time * 0.24, 2.0 * PI);
          uv *= rot(direction * turn + float(i) * (1.0 + 0.25 * portrait + 0.14 * tension) + front * (0.30 + 0.14 * float(i)));
          
          float shape = abs(length(uv) - (0.3 + 0.035 * portrait + 0.025 * mid)) - 0.02;
          shape = min(shape, max(abs(uv.x)-0.01, uv.y-0.3));
          
          vec2 uvd1 = uv * rot(2.5);
          shape = min(shape, max(abs(uvd1.x)-0.01, uvd1.y)); 
          vec2 uvd2 = uv * rot(-2.5);
          shape = min(shape, max(abs(uvd2.x)-0.01, uvd2.y)); 
          
          // Mids articulate the old repeating motifs; treble reveals fine line detail.
          shape = sin(shape * (8.0 + 1.8 * mid + 1.5 * tension) + evolution + 0.6 * front) / 8.0;
          shape = abs(shape);
          shape = pow((0.019 + 0.003 * high) / max(shape, 0.001), 1.2);
          // Compress each line before summing, retaining detail at overlaps.
          shape = shape / (1.0 + shape * 0.75);
          
          vec3 ink = palette(length(uv0) + float(i) * 0.2 + colourCycle + 0.16 * front + high * 0.025 * float(i));
          ink = mix(ink, ink * ink, energy * 0.30);
          float fine = 1.0 + 0.09 * mood.w * sin(length(uv0) * 38.0 - evolution * 2.0 + float(i));
          col += ink * shape * 0.55 * fine;
      }

      col *= 1.0 + energy * 0.30 + pulse * 0.14;
      // A soft shoulder preserves RGB ratios (and therefore saturated hues).
      // Leave the transition overlay's established behaviour untouched.
      float peak = max(col.r, max(col.g, col.b));
      float shoulder = 0.65 + 0.30 * (1.0 - exp(-max(peak - 0.65, 0.0) / 0.30));
      col *= min(peak, shoulder) / max(peak, 0.0001);
      
      col *= transitionIdentityPresence(); 
      col += transitionTunnel(uv0);
      
      outColor = vec4(col, 1.0);
  }
  `
      }]
    ];
  };
