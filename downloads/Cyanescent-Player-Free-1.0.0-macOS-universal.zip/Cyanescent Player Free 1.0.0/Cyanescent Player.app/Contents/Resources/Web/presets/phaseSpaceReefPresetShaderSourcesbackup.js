export function createPhaseSpaceReefPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const phaseSpaceReefFragmentSource = `${modularShaderPrelude}
  ${modularTransitionShaderBlock}
  
  // Custom Mandelbulb map for obstacle boundary (invisible shape)
  float reefMandelbulbSDF(vec3 p, float bassVal, float midsVal, float kickVal) {
    float distToCenter = length(p);
    float wave = sin(distToCenter * 15.0 - time * 10.0) * 0.035 * kickVal;
    vec3 w = p * (1.0 + wave);
    
    float dr = 1.0;
    float r = 0.0;
    float power = 6.0 + 2.5 * bassVal;
    int iterations = int(mix(4.0, 6.0, midsVal));
    
    for (int i = 0; i < 5; i++) {
      if (i >= iterations) break;
      r = length(w);
      if (r > 1.8) break;
      
      float theta = acos(clamp(w.y / r, -1.0, 1.0));
      float phi = atan(w.z, w.x);
      float rpow = pow(r, power - 1.0);
      dr = rpow * power * dr + 1.0;
      float zr = rpow * r;
      theta *= power;
      phi *= power;
      
      w = zr * vec3(sin(theta) * cos(phi), cos(theta), sin(theta) * sin(phi));
      w += p;
    }
    return 0.5 * log(r) * r / dr;
  }
  
  vec2 reefFeedbackUv(vec2 uv, vec2 p, float bassVal, float midsVal, float kickVal, out float obstacleGlow) {
    vec3 pos3D = vec3(p * 1.35, sin(time * 0.06) * 0.25);
    float d = reefMandelbulbSDF(pos3D, bassVal, midsVal, kickVal);
    
    float eps = 0.008;
    float d_px = reefMandelbulbSDF(pos3D + vec3(eps, 0.0, 0.0), bassVal, midsVal, kickVal);
    float d_py = reefMandelbulbSDF(pos3D + vec3(0.0, eps, 0.0), bassVal, midsVal, kickVal);
    vec2 g = vec2(d_px - d, d_py - d) / eps;
    
    vec2 v = vec2(-g.y, g.x);
    
    vec2 noiseFlow = vec2(
      sin(p.y * 6.0 + time * 0.9 + midsVal * 3.0),
      cos(p.x * 5.0 - time * 0.75 + midsVal * 3.0)
    ) * (0.04 + midsVal * 0.14);
    
    float wrapInfluence = smoothstep(0.42, 0.02, abs(d));
    vec2 baseStream = vec2(0.0, -0.15 - 0.08 * bassVal);
    vec2 flow = mix(baseStream, normalize(v + 0.001) * 0.20, wrapInfluence) + noiseFlow;
    
    flow += normalize(g + 0.001) * kickVal * 0.09;
    vec2 q = p + flow * 0.075 * feedbackStep;
    q *= feedbackZoom(0.995);
    
    obstacleGlow = smoothstep(0.01, 0.0, d) * clamp((level - 1.35) * 1.5, 0.0, 1.0);
    
    return clamp(q * 0.5 + 0.5, vec2(0.001), vec2(0.999));
  }
  
  float drawOrganicSpeaker(vec2 p) {
    float r = length(p);
    
    // 16 beat macro animation (clam shell)
    float beatCycle = (phraseProgress * 16.0) / 16.0;
    float clamPhase = sin(beatCycle * PI * 2.0);
    float widthMult = mix(0.5, 1.0, clamPhase * 0.5 + 0.5);
    
    vec2 clamP = p;
    clamP.x /= widthMult;
    
    float clamR = length(clamP);
    
    float excursion = kick * 0.15 + bass * 0.1;
    float mouth = smoothstep(0.3 + excursion, 0.28 + excursion, clamR);
    float lips = smoothstep(0.35 + excursion, 0.32 + excursion, clamR) - mouth;
    
    return mouth * 0.2 + lips * 0.8;
  }
  
  float drawShockwaves(vec2 p) {
    float r = length(p);
    float wave = fract(r * 5.0 - time * 3.0);
    return smoothstep(0.8, 1.0, wave) * kick * exp(-r * 3.0);
  }
  
  float drawSpores(vec2 p) {
    float spores = 0.0;
    for (int i = 0; i < 5; i++) {
        float fi = float(i);
        vec2 seed = vec2(floor(time * 5.0) + fi, 12.34);
        vec2 pos = hash2(seed) * 2.0 - 1.0;
        pos.y -= fract(time * 2.0 + fi * 0.5) * 2.0;
        float dist = length(p - pos);
        spores += exp(-dist * 100.0) * highs;
    }
    return spores;
  }
  
  float drawResonators(vec2 p) {
    float res = 0.0;
    for (int i = 0; i < 6; i++) {
        float angle = float(i) * (PI * 2.0 / 6.0) + time * 0.5;
        vec2 pos = vec2(cos(angle), sin(angle)) * 0.6;
        float dist = length(p - pos);
        res += exp(-dist * 30.0) * mids;
    }
    return res;
  }
  
  float drawFlowNoise(vec2 p, float highsVal, float levelVal) {
    vec2 flowCoord = p * 1.6;
    flowCoord.y -= time * 0.42;
    
    float n = noise(flowCoord * 4.5 + sin(time * 0.15) * 0.4);
    n = fract(n * 5.5);
    float streams = smoothstep(0.12, 0.0, abs(n - 0.5)) * 0.42;
    return streams;
  }
  
  void main() {
    vec2 uv = gl_FragCoord.xy / resolution;
    vec2 p = (gl_FragCoord.xy * 2.0 - resolution) / min(resolution.x, resolution.y);
    
    float obstacleGlow = 0.0;
    vec2 fuv = reefFeedbackUv(uv, p, bass, mids, kick, obstacleGlow);
    
    float transitionStrength = sin(clamp(transitionPhase, 0.0, 1.0) * PI);
    float identityPresence = transitionIdentityPresence();
    
    float decay = mix(0.92, 0.96, level * 0.04);
    vec3 prev = samplePreviousFrame(fuv, p, feedbackRetain(mix(decay, 0.82, transitionStrength)));
    
    float currentField = drawFlowNoise(p, highs, level);
    float speaker = drawOrganicSpeaker(p);
    float shockwaves = drawShockwaves(p);
    float spores = drawSpores(p);
    float resonators = drawResonators(p);
    
    // Aggressive Jade Green, Magenta/Pink, and Electric Gold palette
    vec3 jade = vec3(0.0, 0.65, 0.4);
    vec3 magenta = vec3(0.9, 0.1, 0.6);
    vec3 gold = vec3(1.0, 0.8, 0.1);
    
    vec3 flowColor = mix(jade, magenta, sin(p.y * 2.0 + time * 0.15) * 0.5 + 0.5);
    
    vec3 newDraw = currentField * flowColor * (0.6 + level * 0.4);
    newDraw += speaker * mix(magenta, gold, kick) * 1.5;
    newDraw += shockwaves * jade * 2.0;
    newDraw += spores * gold * 3.0;
    newDraw += resonators * magenta * 2.0;
    
    vec3 obstacleColor = mix(jade, gold, kickPulse) * obstacleGlow * 1.5;
    
    vec3 finalColor = prev + (newDraw + obstacleColor) * identityPresence;
    finalColor = blendPresetBackground(finalColor, vUv, 0.78);
    
    float r = length(p);
    float vignette = 1.0 - smoothstep(1.15, 1.80, r);
    finalColor *= vignette;
    
    finalColor = finalColor / (1.0 + finalColor * 0.38);
    finalColor = pow(finalColor, vec3(0.94));
    
    outColor = vec4(finalColor, 1.0);
  }
  `;

  return [[54, { name: "Phase Space Reef", source: phaseSpaceReefFragmentSource }]];
}
