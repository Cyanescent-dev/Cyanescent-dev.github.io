export const USER_PRESET_SCHEMA_VERSION = 1;
export const CYANESCENT_PLAYER_VERSION = "0.1.0";

const VALID_CATEGORY = /^[a-z0-9][a-z0-9 _-]{1,48}$/i;
const VALID_NAME = /^[^\n\r\t<>]{2,96}$/;

function versionParts(value) {
  return String(value || "0.0.0").split(".").map((part) => Math.max(0, Number.parseInt(part, 10) || 0));
}

function compareVersions(a, b) {
  const left = versionParts(a);
  const right = versionParts(b);
  for (let i = 0; i < Math.max(left.length, right.length); i += 1) {
    const delta = (left[i] || 0) - (right[i] || 0);
    if (delta !== 0) return delta;
  }
  return 0;
}

function asStringArray(value, fieldName, errors, { required = false } = {}) {
  if (value === undefined || value === null) {
    if (required) errors.push(`${fieldName} is required.`);
    return [];
  }
  if (!Array.isArray(value)) {
    errors.push(`${fieldName} must be an array of strings.`);
    return [];
  }
  return value
    .map((item) => String(item || "").trim())
    .filter(Boolean)
    .slice(0, 24);
}

function parsePresetJson(input) {
  if (typeof input === "string") {
    try {
      return { value: JSON.parse(input), parseError: "" };
    } catch (error) {
      return { value: null, parseError: error?.message || "Invalid JSON." };
    }
  }
  return { value: input, parseError: "" };
}

function compileUserPresetShader({
  gl,
  vertexSource,
  fragmentShaderSource
}) {
  if (!gl || !vertexSource) return "";
  const vertex = gl.createShader(gl.VERTEX_SHADER);
  const fragment = gl.createShader(gl.FRAGMENT_SHADER);
  const program = gl.createProgram();
  try {
    gl.shaderSource(vertex, vertexSource);
    gl.compileShader(vertex);
    if (!gl.getShaderParameter(vertex, gl.COMPILE_STATUS)) {
      return `Vertex shader: ${gl.getShaderInfoLog(vertex) || "compile failed"}`;
    }
    gl.shaderSource(fragment, fragmentShaderSource);
    gl.compileShader(fragment);
    if (!gl.getShaderParameter(fragment, gl.COMPILE_STATUS)) {
      return `Fragment shader: ${gl.getShaderInfoLog(fragment) || "compile failed"}`;
    }
    gl.attachShader(program, vertex);
    gl.attachShader(program, fragment);
    gl.bindAttribLocation(program, 0, "position");
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      return `Shader link: ${gl.getProgramInfoLog(program) || "link failed"}`;
    }
    return "";
  } finally {
    try { gl.deleteShader(vertex); } catch {}
    try { gl.deleteShader(fragment); } catch {}
    try { gl.deleteProgram(program); } catch {}
  }
}

export function createUserPresetValidator({
  gl,
  vertexSource,
  existingPresetIds = [],
  playerVersion = CYANESCENT_PLAYER_VERSION
} = {}) {
  const existingIds = new Set(existingPresetIds.map(Number).filter(Number.isFinite));

  function validate(input) {
    const errors = [];
    const warnings = [];
    const { value: raw, parseError } = parsePresetJson(input);
    if (parseError) {
      return { ok: false, errors: [`Preset JSON could not be parsed: ${parseError}`], warnings, preset: null };
    }
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return { ok: false, errors: ["Preset file must contain a single JSON object."], warnings, preset: null };
    }

    if (Number(raw.schemaVersion) !== USER_PRESET_SCHEMA_VERSION) {
      errors.push(`schemaVersion must be ${USER_PRESET_SCHEMA_VERSION}.`);
    }
    const id = Math.round(Number(raw.id));
    if (!Number.isFinite(id) || id < 1) {
      errors.push("id must be a positive number.");
    } else if (existingIds.has(id)) {
      warnings.push(`Preset ID ${id} already exists. The imported preset will be assigned a safe user ID.`);
    }
    const name = String(raw.name || "").trim();
    if (!VALID_NAME.test(name)) errors.push("name is required and must be 2-96 plain text characters.");
    const category = String(raw.category || "").trim();
    if (!VALID_CATEGORY.test(category)) errors.push("category is required and must be simple text.");
    const fragmentShaderSource = String(raw.fragmentShaderSource || "");
    if (!fragmentShaderSource.trim()) errors.push("fragmentShaderSource is required.");
    if (fragmentShaderSource.includes("<script") || fragmentShaderSource.includes("javascript:")) {
      errors.push("fragmentShaderSource must not contain script tags or JavaScript URLs.");
    }
    const minimumPlayerVersion = String(raw.minimumPlayerVersion || "0.1.0").trim();
    if (compareVersions(minimumPlayerVersion, playerVersion) > 0) {
      errors.push(`This preset requires Cyanescent Player ${minimumPlayerVersion}; this app is ${playerVersion}.`);
    }

    const tags = asStringArray(raw.tags, "tags", errors);
    const energyTags = asStringArray(raw.energyTags, "energyTags", errors);
    if (raw.uniforms !== undefined && (typeof raw.uniforms !== "object" || Array.isArray(raw.uniforms))) {
      errors.push("uniforms must be an object when provided.");
    }
    if (raw.audioBindings !== undefined && (typeof raw.audioBindings !== "object" || Array.isArray(raw.audioBindings))) {
      errors.push("audioBindings must be an object when provided.");
    }
    if (!errors.length) {
      const shaderError = compileUserPresetShader({ gl, vertexSource, fragmentShaderSource });
      if (shaderError) errors.push(`Shader validation failed: ${shaderError}`);
    }

    const preset = errors.length ? null : {
      schemaVersion: USER_PRESET_SCHEMA_VERSION,
      id,
      originalId: id,
      name,
      author: String(raw.author || "Unknown").trim().slice(0, 96) || "Unknown",
      description: String(raw.description || "").trim().slice(0, 600),
      category,
      tags,
      energyTags,
      minimumPlayerVersion,
      createdAt: String(raw.createdAt || new Date().toISOString()).trim(),
      vertexShaderSource: raw.vertexShaderSource ? String(raw.vertexShaderSource) : "",
      fragmentShaderSource,
      uniforms: raw.uniforms && typeof raw.uniforms === "object" ? raw.uniforms : {},
      audioBindings: raw.audioBindings && typeof raw.audioBindings === "object" ? raw.audioBindings : {},
      notes: String(raw.notes || "").trim().slice(0, 1200)
    };

    return {
      ok: errors.length === 0,
      errors,
      warnings,
      preset
    };
  }

  return { validate };
}

