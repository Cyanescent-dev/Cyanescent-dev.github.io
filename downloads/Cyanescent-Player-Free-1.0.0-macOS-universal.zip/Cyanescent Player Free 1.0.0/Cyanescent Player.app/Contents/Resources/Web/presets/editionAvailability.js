import { runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
export function filterAvailablePresetIds(presetIds, availablePresetIds) {
  const available = new Set((availablePresetIds || []).map(Number));
  return (presetIds || []).map(Number).filter((id) => runtimeAllowsPreset(id) && available.has(id));
}

export function availablePresetOrFallback(preferredPresetId, availablePresetIds) {
  const available = (availablePresetIds || []).map(Number).filter((id) => runtimeAllowsPreset(id));
  const preferred = Number(preferredPresetId);
  if (available.includes(preferred)) return preferred;
  return available[0] ?? null;
}
