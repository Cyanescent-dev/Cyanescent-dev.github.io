// Tesseract Unfolding (preset 148): The Hyperdimensional Engine.
//
// Everything on screen is a 3D cross-section of genuine 4D geometry (see tesseractUnfoldingDirector.js):
//   machine  a Menger tesseract of half-size TU_H: sub-hypercubes with three or four middle
//            coordinates are removed, recursively (3 levels, a 4th as
//            the intricacy rises). Its axis-aligned slice through the
//            centre is the classical Menger sponge; turned in SO(4) it refolds into octahedral halls,
//            hexagram lattices and prisms. Walls whose 4D normal is the hidden w axis only exist
//            while the machine leans into the fourth dimension: they are crystal.
//   gyros    three nested tesseract frames: thickened 2-skeletons, whose slices are the edges of
//            the cross-section polyhedron, with gems where 4D edges pierce the slice. Their faces
//            (the slices of the 8 cubic cells) are drawn as analytic luminous membranes.
//   core     a solid regular polytope (24-cell, tesseract, 16-cell) sliced: a morphing crystal and
//            the chamber's light, casting the cages' shadows on the chamber walls.
// Distances: the sponge's carving uses the second-largest of the per-axis hole distances (a
// Chebyshev lower bound, Lipschitz 1); slicing is an isometric embedding, so every field stays a
// valid bound in 3D.
export function createTesseractUnfoldingPresetShaderEntries({ modularShaderPrelude, modularTransitionShaderBlock }) {
  return [
    [148, {
      name: "Tesseract Unfolding",
      source: `${modularShaderPrelude}
${modularTransitionShaderBlock}

// ---- director uniforms (see tesseractUnfoldingDirector.js) ----
uniform float tuDir;
uniform mat4 tuR, tuG0, tuG1, tuG2, tuC;
uniform vec4 tuCamPos;        // xyz position, w tan(fov/2)
uniform mat3 tuCamBasis;      // right, up, forward
uniform vec4 tuHoles;         // hole half-widths per sponge level (fraction of the cell half-size)
uniform vec4 tuSlice;         // w offset of the slice, director time, hue drift, insideness
uniform vec4 tuGyroA;         // gyro half-sizes, unfold
uniform vec4 tuGyroW;         // gyro 4D offsets
uniform vec4 tuCoreShape;     // weights tesseract-like blend: 24-cell, tesseract, 16-cell; size
uniform vec4 tuLight;         // core intensity, charge (build), shimmer (highs), drop flash
uniform vec4 tuMood;          // calm, drive, tension, energy
uniform vec4 tuPulseAge, tuPulseAmp, tuPulseSpeed;
uniform mat4 tuO;             // the colossal outer hyper-cage
uniform vec4 tuOuter;         // half-size, 4D offset, beam scale, presence

#define TU_H 12.0
// the key star sits on the side the encounter orbit looks from; the warm rim light behind the machine
#define TU_KEY_DIR normalize(vec3(-0.62, 0.58, -0.18))
#define TU_RIM_DIR normalize(vec3(0.62, -0.08, 0.78))
#define TU_FAR 120.0
#ifndef TU_DEBUG
#define TU_DEBUG 0
#endif
// light-term switches for diagnostics (def=TU_ENV:0.0 in the trial tool)
#ifndef TU_REFL_MAP
#define TU_REFL_MAP tuMap
#endif
#ifndef TU_KEY
#define TU_KEY 1.0
#endif
#ifndef TU_RIM
#define TU_RIM 1.0
#endif
#ifndef TU_CORE
#define TU_CORE 1.0
#endif
#ifndef TU_ENV
#define TU_ENV 1.0
#endif
#ifndef TU_EMIT
#define TU_EMIT 1.0
#endif

mat4 gR, gG0, gG1, gG2, gC, gO;
vec4 gOuter;
vec4 gHoles, gGyroA, gGyroW, gCoreShape, gLight, gMood;
vec3 gRo;
float gW0, gPix, gTime, gInside, gClusterR, gReflT = -1.0;

// ---------------------------------------------------------------------------------------------
float tuSecond(vec4 e) {              // second largest component
  float a = max(e.x, e.y), b = min(e.x, e.y);
  float c = max(e.z, e.w), d = min(e.z, e.w);
  return max(min(a, c), max(b, d));
}
vec4 tuSortDesc(vec4 q) {
  vec4 s = q;
  float t;
  if (s.x < s.y) { t = s.x; s.x = s.y; s.y = t; }
  if (s.z < s.w) { t = s.z; s.z = s.w; s.w = t; }
  if (s.x < s.z) { t = s.x; s.x = s.z; s.z = t; }
  if (s.y < s.w) { t = s.y; s.y = s.w; s.w = t; }
  if (s.y < s.z) { t = s.y; s.y = s.z; s.z = t; }
  return s;
}
float tuMax4(vec4 v) { return max(max(v.x, v.y), max(v.z, v.w)); }

// Level-of-detail: a level's holes close smoothly once they shrink below a few pixels.
float tuLod(float halfWidth, float dist) {
  return smoothstep(4.0, 11.0, 2.0 * halfWidth / max(dist * gPix, 1e-5));
}

// The machine: Menger tesseract, three levels and a fourth that comes and goes. p3 -> p4 = R (p3, w0).
float tuSponge(vec3 p3) {
  vec4 p = gR * vec4(p3, gW0);
  vec4 dq = abs(p) - TU_H;
  float d = length(max(dq, 0.0)) + min(tuMax4(dq), 0.0);
  if (d > 1.0) return d;
  float dist = length(p3 - gRo);
  vec4 c = p;
  float s = TU_H;
  for (int i = 0; i < 4; i++) {
    // the fourth level is the director's intricacy: absent until the journey and the music ask
    if (i == 3 && gHoles.w < 0.01) break;
    float h = gHoles[i] * s;
    if (i >= 2) h *= tuLod(h, dist);
    d = max(d, -tuSecond(abs(c) - h));
    float cs = s / 3.0;
    c -= clamp(floor(c / (2.0 * cs) + 0.5), -1.0, 1.0) * 2.0 * cs;
    s = cs;
  }
  return d;
}

// Material query for the sponge: carving level (0 = outer faces), 4D axis of the face, and the
// distance to the nearest 4D edge of that face (for luminous seams).
float tuSpongeInfo(vec3 p3, out float level, out float axis, out float edge, out vec4 p4) {
  vec4 p = gR * vec4(p3, gW0);
  p4 = p;
  vec4 dq = abs(p) - TU_H;
  float d = length(max(dq, 0.0)) + min(tuMax4(dq), 0.0);
  vec4 sd = tuSortDesc(dq);
  float second = -1e9;
  level = 0.0;
  edge = sd.x - sd.y;
  axis = dq.x >= sd.x ? 0.0 : dq.y >= sd.x ? 1.0 : dq.z >= sd.x ? 2.0 : 3.0;
  float dist = length(p3 - gRo);
  vec4 c = p;
  float s = TU_H;
  for (int i = 0; i < 4; i++) {
    // the fourth level is the director's intricacy: absent until the journey and the music ask
    if (i == 3 && gHoles.w < 0.01) break;
    float h = gHoles[i] * s;
    if (i >= 2) h *= tuLod(h, dist);
    vec4 e = abs(c) - h;
    float cut = -tuSecond(e);
    if (cut > d) {
      second = d;
      d = cut;
      level = float(i + 1);
      vec4 es = tuSortDesc(e);
      edge = min(es.x - es.y, es.y - es.z);
      // the face is the hyperplane of the coordinate holding the second-largest e
      axis = e.x == es.y ? 0.0 : e.y == es.y ? 1.0 : e.z == es.y ? 2.0 : 3.0;
    } else second = max(second, cut);
    float cs = s / 3.0;
    c -= clamp(floor(c / (2.0 * cs) + 0.5), -1.0, 1.0) * 2.0 * cs;
    s = cs;
  }
  edge = min(edge, d - second);
  return d;
}

// A nested tesseract frame of half-size a, rotated by G and offset by w along the hidden axis.
// Its slice is a convex polyhedron whose edges are where two of the hyperplanes |x_i| = a meet the
// slice and whose vertices are where three meet. Thickening in 4D would turn a 2-face that lies
// almost inside the slice into a flat paddle, so edges and vertices are measured in 3D: the
// distance to the line where two 3D planes meet is f^T Gram^-1 f (f the plane offsets, Gram the
// dot products of the planes' 3D normals, the rows of G); the remaining coordinates clamp the
// segment ends (their excess is a lower bound of the 3D distance, since |n_k| <= 1).
mat4 gGram0, gGram1, gGram2, gGramO;
mat4 tuGram(mat4 G) {
  vec3 n0 = vec3(G[0][0], G[1][0], G[2][0]), n1 = vec3(G[0][1], G[1][1], G[2][1]);
  vec3 n2 = vec3(G[0][2], G[1][2], G[2][2]), n3 = vec3(G[0][3], G[1][3], G[2][3]);
  return mat4(dot(n0, n0), dot(n0, n1), dot(n0, n2), dot(n0, n3),
              dot(n1, n0), dot(n1, n1), dot(n1, n2), dot(n1, n3),
              dot(n2, n0), dot(n2, n1), dot(n2, n2), dot(n2, n3),
              dot(n3, n0), dot(n3, n1), dot(n3, n2), dot(n3, n3));
}
float tuLine2(float fi, float fj, float gii, float gjj, float gij) {
  float det = max(gii * gjj - gij * gij, 1e-5);
  return max((gjj * fi * fi - 2.0 * gij * fi * fj + gii * fj * fj) / det, 0.0);
}
float tuFrame(vec3 p3, mat4 G, mat4 gram, float w, float a, float thick, out float gem) {
  vec4 P = G * vec4(p3, w);
  vec4 sg = sign(P + 1e-9);
  vec4 q = abs(P) - a;
  // indices of the three largest q
  int i0 = 0, i1 = 1, i2 = 2, i3 = 3;
  float v0 = q.x, v1 = q.y, v2 = q.z, v3 = q.w, tv; int ti;
  if (v0 < v1) { tv = v0; v0 = v1; v1 = tv; ti = i0; i0 = i1; i1 = ti; }
  if (v2 < v3) { tv = v2; v2 = v3; v3 = tv; ti = i2; i2 = i3; i3 = ti; }
  if (v0 < v2) { tv = v0; v0 = v2; v2 = tv; ti = i0; i0 = i2; i2 = ti; }
  if (v1 < v3) { tv = v1; v1 = v3; v3 = tv; ti = i1; i1 = i3; i3 = ti; }
  if (v1 < v2) { tv = v1; v1 = v2; v2 = tv; ti = i1; i1 = i2; i2 = ti; }
  float g01 = gram[i0][i1] * sg[i0] * sg[i1], g02 = gram[i0][i2] * sg[i0] * sg[i2], g12 = gram[i1][i2] * sg[i1] * sg[i2];
  float g00 = gram[i0][i0], g11 = gram[i1][i1], g22 = gram[i2][i2];
  float e2 = max(v2, 0.0), e3 = max(v3, 0.0);
  float l01 = tuLine2(v0, v1, g00, g11, g01) + e2 * e2 + e3 * e3;
  float l02 = tuLine2(v0, v2, g00, g22, g02) + max(v1, 0.0) * max(v1, 0.0) + e3 * e3;
  float l12 = tuLine2(v1, v2, g11, g22, g12) + max(v0, 0.0) * max(v0, 0.0) + e3 * e3;
  float beam = sqrt(min(l01, min(l02, l12))) - a * 0.028 * thick;
  // vertex: the point where the three planes meet (3x3 Gram inverse by adjugate)
  float c00 = g11 * g22 - g12 * g12, c01 = g02 * g12 - g01 * g22, c02 = g01 * g12 - g02 * g11;
  float c11 = g00 * g22 - g02 * g02, c12 = g01 * g02 - g00 * g12, c22 = g00 * g11 - g01 * g01;
  float det = max(g00 * c00 + g01 * c01 + g02 * c02, 1e-5);
  float pt = (c00 * v0 * v0 + c11 * v1 * v1 + c22 * v2 * v2 + 2.0 * (c01 * v0 * v1 + c02 * v0 * v2 + c12 * v1 * v2)) / det;
  float node = sqrt(max(pt, 0.0) + e3 * e3) - a * 0.065 * thick;
  gem = node < beam ? 1.0 : 0.0;
  return min(beam, node);
}

// The core: a solid regular polytope, blending 24-cell, tesseract and 16-cell bounds.
float tuCore(vec3 p3) {
  vec4 q = abs(gC * vec4(p3, 0.0));
  vec4 s = tuSortDesc(q);
  float r = gCoreShape.w;
  float c24 = (s.x + s.y) * 0.70710678 - r * 1.22;
  float c8 = s.x - r;
  float c16 = (s.x + s.y + s.z + s.w) * 0.5 - r * 1.3;
  return c24 * gCoreShape.x + c8 * gCoreShape.y + c16 * gCoreShape.z;
}

float tuCluster(vec3 p, out float id) {
  float g;
  float d = tuCore(p);
  id = 4.0;
  float f = tuFrame(p, gG0, gGram0, gGyroW.x, gGyroA.x, 1.0, g);
  if (f < d) { d = f; id = 1.0 + g * 0.5; }
  f = tuFrame(p, gG1, gGram1, gGyroW.y, gGyroA.y, 1.0, g);
  if (f < d) { d = f; id = 2.0 + g * 0.5; }
  f = tuFrame(p, gG2, gGram2, gGyroW.z, gGyroA.z, 1.0, g);
  if (f < d) { d = f; id = 3.0 + g * 0.5; }
  return d;
}

float gClusterD;                       // the cages' share of the last tuMap (for edge anti-aliasing)
float tuMap(vec3 p) {
  float d = tuSponge(p);
  float r = length(p) - gClusterR;
  gClusterD = 1e9;
  if (r < d) {
    float id;
    gClusterD = max(r, tuCluster(p, id));
    d = min(d, gClusterD);
  }
  return d;
}

// Shadow casters for the core light: the cages and the core.
float tuMapCluster(vec3 p) {
  float r = length(p) - gClusterR;
  if (r > 0.3) return r;
  float id;
  return tuCluster(p, id);
}

vec3 tuNormal(vec3 p, float e) {
  vec2 k = vec2(1.0, -1.0);
  return normalize(k.xyy * tuMap(p + k.xyy * e) + k.yyx * tuMap(p + k.yyx * e) +
                   k.yxy * tuMap(p + k.yxy * e) + k.xxx * tuMap(p + k.xxx * e));
}

// ---------------------------------------------------------------------------------------------
// The space between dimensions: deep indigo, slow luminous folds, faint dust.
vec3 tuSky(vec3 rd) {
  float up = rd.y;
  vec3 col = mix(vec3(0.004, 0.003, 0.010), vec3(0.012, 0.010, 0.032), smoothstep(-0.6, 0.7, up));
  // folds: two crossing families of great-circle bands, drifting
  float t = gTime * 0.01;
  float f1 = dot(rd, normalize(vec3(0.35, 0.9, -0.25)));
  float f2 = dot(rd, normalize(vec3(-0.7, 0.2, 0.68)));
  float band = sin(f1 * 4.0 + sin(f2 * 3.0 + t) * 1.4 + t * 2.0);
  float fold = exp(-band * band * 6.0) * smoothstep(-0.2, 0.5, f2 * 0.5 + 0.5);
  col += vec3(0.07, 0.03, 0.14) * fold * 0.35;
  float band2 = sin(f2 * 5.0 - f1 * 2.0 - t * 1.3);
  col += vec3(0.02, 0.06, 0.08) * exp(-band2 * band2 * 9.0) * 0.5;
  // a distant warm glow low on one side gives the void a horizon
  col += vec3(0.10, 0.045, 0.02) * pow(max(dot(rd, normalize(vec3(0.6, -0.15, 0.78))), 0.0), 6.0) * 0.6;
  // dust
  vec3 a = abs(rd);
  vec2 uv = a.x > a.y && a.x > a.z ? rd.yz / a.x : a.y > a.z ? rd.xz / a.y : rd.xy / a.z;
  vec2 cell = floor(uv * 140.0);
  float h = hash(cell + floor(a.x * 3.0) * 17.0);
  vec2 off = fract(uv * 140.0) - 0.5 - (hash2(cell) - 0.5) * 0.6;
  col += vec3(0.75, 0.8, 1.0) * step(0.985, h) * exp(-dot(off, off) * 60.0) * 0.35 * (0.6 + 0.4 * sin(gTime * 1.7 + h * 50.0));
  return col;
}

// Environment for reflections: the sky outside, the warm chamber inside.
vec3 tuEnv(vec3 p, vec3 rd, vec3 coreCol) {
  vec3 sky = tuSky(rd) * 1.3 + vec3(0.012, 0.012, 0.02) * smoothstep(-0.2, 0.9, rd.y);
  vec3 toCore = -normalize(p);
  float inside = smoothstep(TU_H * 0.9, TU_H * 0.4, length(p));
  float glint = pow(max(dot(rd, toCore), 0.0), 40.0) * 3.0 + pow(max(dot(rd, toCore), 0.0), 6.0) * 0.35;
  vec3 hall = mix(vec3(0.004, 0.003, 0.006), vec3(0.014, 0.009, 0.008), rd.y * 0.5 + 0.5);
  return mix(sky, hall, inside * 0.75) + coreCol * glint * inside * 0.6;
}

vec3 tuFilm(float x) {                // thin-film interference palette
  return 0.5 + 0.5 * cos(6.28318 * (x + vec3(0.0, 0.33, 0.67)));
}

float tuSoftShadow(vec3 ro, vec3 rd, float maxT, int steps) {
  float res = 1.0;
  float t = 0.04;
  for (int i = 0; i < 48; i++) {
    if (i >= steps || t > maxT) break;
    float h = tuSponge(ro + rd * t);
    res = min(res, 10.0 * h / t);
    if (res < 0.02) break;
    t += clamp(h, 0.05, 2.5);
  }
  return clamp(res, 0.0, 1.0);
}

float tuCoreShadow(vec3 p) {          // cages between p and the core
  float L = length(p);
  vec3 rd = -p / L;
  float res = 1.0;
  float t = 0.03;
  for (int i = 0; i < 28; i++) {
    float h = tuMapCluster(p + rd * t);
    res = min(res, 14.0 * h / t);
    t += clamp(h, 0.02, 0.5);
    if (res < 0.02 || t > L - gCoreShape.w * 2.4) break;
  }
  return clamp(res, 0.0, 1.0);
}

float tuAO(vec3 p, vec3 n, float scale) {
  float occ = 0.0, w = 1.0;
  for (int i = 1; i <= 4; i++) {
    float h = scale * float(i) * float(i) * 0.06;
    occ += w * (h - tuMap(p + n * h));
    w *= 0.6;
  }
  return clamp(1.0 - occ * 2.2 / scale, 0.0, 1.0);
}

// Pulse light: hypercube shells (4D Chebyshev radius) expanding from the centre.
float tuPulses(float radius) {
  float sum = 0.0;
  for (int i = 0; i < 4; i++) {
    float front = tuPulseAge[i] * tuPulseSpeed[i];
    float x = (radius - front) / (0.45 + front * 0.025);
    sum += tuPulseAmp[i] * exp(-x * x) * smoothstep(0.0, 1.5, radius + 0.3);
  }
  return sum;
}

// ---- one reflection bounce for mirror-like surfaces: the machine reflects itself ------------
vec3 tuReflection(vec3 p, vec3 R, vec3 coreTint, int steps, float spread) {
  // detail is filtered by the whole path length: a virtual camera behind the mirror
  vec3 roSaved = gRo;
  gRo = p - R * length(p - gRo) * spread;
  float t = 0.03;
  bool hit = false;
  for (int i = 0; i < 64; i++) {
    if (i >= steps) break;
    float d = TU_REFL_MAP(p + R * t);
    // a tight threshold: a loose one stops rays that skim parallel walls (contour banding)
    if (d < 0.0015 + t * gPix * 0.25) { hit = true; break; }
    t += d;
    if (t > 60.0) break;
  }
  if (!hit) {
    gRo = roSaved;
    vec3 env = tuEnv(p, R, coreTint * gLight.x);
    // a ray that ran out of steps is deep inside the architecture, not out in the void
    if (t < 60.0) env = mix(vec3(0.010, 0.008, 0.016) + coreTint * 0.02 * gInside, env, smoothstep(20.0, 60.0, t) * 0.5);
    return env;
  }
  gReflT = t;
  vec3 q = p + R * t;
  vec3 n = tuNormal(q, max(0.004, t * gPix * 3.0));
  float level, axis, edge;
  vec4 q4;
  float ds = tuSpongeInfo(q, level, axis, edge, q4);
  vec3 L = TU_KEY_DIR;
  float ndl = max(dot(n, L), 0.0);
  float r = length(q);
  float ndlc = max(dot(n, -q / max(r, 1e-3)), 0.0);
  float tunnel = -tuSecond(abs(q4) - gHoles.x * TU_H);
  float reach = smoothstep(-1.5, 0.4, tunnel) * smoothstep(TU_H * 1.6, TU_H * 0.3, r);
  vec3 base = axis > 2.5 ? vec3(0.05, 0.03, 0.10) : level > 2.5 ? vec3(0.45, 0.30, 0.14) : vec3(0.14, 0.14, 0.16);
  vec3 c = base * (vec3(0.80, 0.86, 1.0) * 1.6 * ndl + coreTint * gLight.x * 26.0 / (1.0 + r * r) * reach * ndlc + 0.04);
  float pulse = tuPulses(tuMax4(abs(q4)));
  // footprint of the reflected pixel: path length, widened by the mirror's grazing angle
  float rfoot = (length(p - roSaved) + t) * gPix * spread;
  float lw = max(0.03, rfoot * 1.5);
  float seam = (0.03 / lw) * (1.0 - smoothstep(0.0, lw, edge));
  c += vec3(1.0, 0.68, 0.30) * seam * (0.03 + 0.8 * gLight.y + 2.0 * pulse) * 0.6;
  if (ds > 0.05) c = coreTint * 1.2;                 // a cage or the core: bright
  gRo = roSaved;
  // detail finer than the footprint averages out instead of aliasing into moire
  c = mix(c, vec3(dot(c, vec3(0.3))) * 0.6 + base * 0.05, smoothstep(0.08, 0.5, rfoot));
  float fogD = 1.0 - exp(-t * mix(0.006, 0.03, gInside));
  return mix(c, mix(vec3(0.012, 0.010, 0.03), vec3(0.05, 0.03, 0.025), gInside), fogD);
}

// ---- membranes: the cubic cells of the three cages, as analytic translucent faces -------------
vec3 tuMembranes(vec3 ro, vec3 rd, float tMax, vec3 tint) {
  vec3 acc = vec3(0.0);
  for (int k = 0; k < 3; k++) {
    mat4 G = k == 0 ? gG0 : k == 1 ? gG1 : gG2;
    float a = gGyroA[k], w = gGyroW[k];
    vec4 A = G * vec4(ro, w), B = G * vec4(rd, 0.0);
    vec4 inv = 1.0 / (abs(B) + 1e-6) * sign(B + 1e-9);
    vec4 t1 = (-a - A) * inv, t2 = (a - A) * inv;
    vec4 tn = min(t1, t2), tf = max(t1, t2);
    float t0 = tuMax4(tn), t3 = min(min(tf.x, tf.y), min(tf.z, tf.w));
    if (t0 >= t3 || t3 <= 0.0) continue;
    for (int side = 0; side < 2; side++) {
      float t = side == 0 ? t0 : t3;
      if (t <= 0.0 || t >= tMax) continue;
      vec4 q = A + B * t;
      vec4 aq = abs(q) / a;
      // grid of the face: the other coordinates at 0 and +-1/2, and the face rim
      vec4 sq = tuSortDesc(aq);
      float foot = max(t * gPix / a, 1e-4);
      float rim = sq.y;                                 // near 1 at the face's edges
      float gridDist = 1.0;
      for (int j = 0; j < 4; j++) {
        if (aq[j] > 0.999) continue;
        float v = aq[j] * 2.0;
        gridDist = min(gridDist, abs(v - floor(v + 0.5)) * 0.5);
      }
      float lineW = 0.012;
      float grid = lineW / max(lineW, foot) * (1.0 - smoothstep(0.0, max(lineW, foot) * 1.5, gridDist));
      float edgeGlow = smoothstep(0.7, 1.0, rim);
      vec3 film = tuFilm(0.35 + sq.y * 0.6 + float(k) * 0.21 + gTime * 0.02);
      float lum = 0.008 + 0.035 * edgeGlow * edgeGlow + 0.07 * grid;
      lum *= (0.55 + 0.6 * gGyroA.w + 0.8 * gLight.y) * (1.0 + 1.5 * tuPulses(length(ro + rd * t) * 1.2));
      acc += mix(tint, film, 0.45) * lum;
    }
  }
  return acc;
}

// ---- the cages and the core: one shading function, used for hits and for edge coverage ----------
// Thin convex tubes minify their reflections enormously, so a raymarched bounce aliases into
// dashes along every beam: the cages reflect a smooth analytic chamber instead.
vec3 tuCageEnv(vec3 p, vec3 R, vec3 coreTint) {
  vec3 env = tuEnv(p, R, coreTint * gLight.x);
  vec3 hall = mix(vec3(0.020, 0.016, 0.028), vec3(0.11, 0.075, 0.05), smoothstep(-0.6, 0.8, R.y));
  hall += vec3(0.06, 0.04, 0.10) * pow(1.0 - abs(R.y), 6.0);           // the chamber's walls at the horizon
  return env + hall * gInside;
}

vec3 tuShadeCage(vec3 p, vec3 rd, float t, vec3 coreTint, float pulse) {
  float cid;
  tuCluster(p, cid);
  vec3 n = tuNormal(p, max(0.0012, t * gPix * 1.3));
  vec3 v = -rd;
  float ndv = max(dot(n, v), 0.0);
  vec3 F0 = vec3(0.04);
  float rough = 0.1;
  vec3 emit = vec3(0.0);
  float gem = fract(cid) > 0.25 ? 1.0 : 0.0;
  float k = floor(cid);
  if (k > 3.5) {
    // the core crystal
    vec3 film = tuFilm(ndv * 1.3 + tuSlice.z * 2.0);
    F0 = film * 0.6;
    rough = 0.05;
    emit = mix(coreTint * coreTint, coreTint, pow(1.0 - ndv, 2.0)) * (0.35 + 1.1 * pow(1.0 - ndv, 2.0)) * (0.6 + 0.4 * gLight.x) + film * vec3(0.5, 0.3, 0.9) * 0.18 * ndv;
    vec4 cs = tuSortDesc(abs(gC * vec4(p, 0.0)));
    float cEdge = min(cs.x - cs.y, cs.y - cs.z) / gCoreShape.w;
    float ew = max(0.06, t * gPix / gCoreShape.w * 1.5);
    emit += vec3(1.0, 0.9, 0.75) * (0.06 / ew) * (1.0 - smoothstep(ew * 0.5, ew, cEdge)) * (1.2 + 1.5 * gLight.w);
  } else if (gem > 0.5) {
    F0 = vec3(0.9);
    rough = 0.06;
    emit = mix(coreTint, vec3(0.55, 0.75, 1.0), k * 0.33) * (0.18 + 0.9 * pulse + 0.3 * gLight.y) * (0.4 + 0.6 * ndv);
  } else if (k < 1.5) {
    F0 = vec3(0.80, 0.81, 0.86); rough = 0.08;          // outer cage: chrome
  } else if (k < 2.5) {
    F0 = vec3(1.0, 0.72, 0.36) * 0.9; rough = 0.12;     // middle cage: gold
    emit = vec3(1.0, 0.6, 0.25) * 0.05 * (1.0 + 4.0 * pulse);
  } else {
    F0 = vec3(0.55, 0.35, 0.95) * 0.8; rough = 0.1;     // inner cage: violet crystal
    emit = vec3(0.35, 0.15, 0.8) * (0.15 + 0.6 * pulse + 0.5 * gLight.y);
  }
  float a2 = max(rough * rough, 0.002);
  // key light (the chamber mostly hides it; no shadow ray for the cages)
  vec3 L = TU_KEY_DIR;
  float ndl = max(dot(n, L), 0.0);
  vec3 H = normalize(L + v);
  float ndh = max(dot(n, H), 0.0);
  float D = a2 / (3.14159 * pow(ndh * ndh * (a2 - 1.0) + 1.0, 2.0));
  vec3 F = F0 + (1.0 - F0) * pow(1.0 - max(dot(H, v), 0.0), 5.0);
  vec3 col = D * F * 0.25 / max(0.05, ndl * ndv + 0.05) * vec3(0.80, 0.86, 1.0) * 1.9 * ndl * (1.0 - 0.8 * gInside) * TU_KEY;
  // core light, with the other cages' shadows
  float r = length(p);
  vec3 Lc = -p / max(r, 1e-3);
  float ndlc = max(dot(n, Lc), 0.0);
  float csh = (ndlc > 0.0 && k < 3.5) ? tuCoreShadow(p + n * 0.01) : 1.0;
  float coreI = gLight.x * 70.0 / (1.0 + r * r * 1.5) * csh;
  vec3 Hc = normalize(Lc + v);
  float ndhc = max(dot(n, Hc), 0.0);
  // the highlight is widened to at least a pixel on the tube, or it flickers between pixels
  float a2c = max(a2, min(0.25, t * gPix * 8.0));
  float Dc = a2c / (3.14159 * pow(ndhc * ndhc * (a2c - 1.0) + 1.0, 2.0));
  vec3 Fc = F0 + (1.0 - F0) * pow(1.0 - max(dot(Hc, v), 0.0), 5.0);
  col += Dc * Fc * 0.25 / max(0.05, ndlc * ndv + 0.05) * coreTint * coreI * ndlc * TU_CORE;
  vec3 Fv = F0 + (1.0 - F0) * pow(1.0 - ndv, 5.0) * (1.0 - rough);
  col += tuCageEnv(p, reflect(rd, n), coreTint) * Fv * TU_ENV;
  col += F0 * vec3(0.05, 0.05, 0.08) * 0.5;
  col += emit * TU_EMIT;
  col += vec3(1.0, 0.7, 0.4) * pulse * 0.02;
  float fogD = 1.0 - exp(-max(t - 4.0, 0.0) * mix(0.0035, 0.016, gInside));
  return mix(col, mix(vec3(0.012, 0.010, 0.03), vec3(0.018, 0.011, 0.02), gInside), fogD * 0.7);
}

// ---- default state when the director is not bound (warm-up, tools) --------------------------
mat4 tuPlane(int i, int j, float a) {
  mat4 m = mat4(1.0);
  float c = cos(a), s = sin(a);
  m[i][i] = c; m[j][j] = c; m[i][j] = s; m[j][i] = -s;
  return m;
}
void tuDefaults(float t) {
  gR = tuPlane(0, 3, 0.18 + 0.05 * t) * tuPlane(1, 3, 0.11 + 0.031 * t) * tuPlane(0, 2, 0.02 * t);
  gG0 = tuPlane(0, 3, 0.4 * t) * tuPlane(1, 2, 0.21 * t);
  gG1 = tuPlane(1, 3, -0.5 * t) * tuPlane(0, 2, 0.33 * t);
  gG2 = tuPlane(2, 3, 0.7 * t) * tuPlane(0, 1, 0.4 * t);
  gC = tuPlane(0, 3, 0.9 * t) * tuPlane(1, 2, 0.6 * t);
  gHoles = vec4(0.36, 0.35, 0.34, 0.36);
  gGyroA = vec4(0.84, 0.56, 0.34, 0.4);
  gGyroW = vec4(sin(t * 0.11), sin(t * 0.16 + 2.0), sin(t * 0.21 + 4.0), 0.0) * vec4(0.9, 0.6, 0.35, 0.0);
  gCoreShape = vec4(1.0, 0.0, 0.0, 0.17);
  gLight = vec4(1.0, 0.0, 0.3, 0.0);
  gMood = vec4(0.0, 0.5, 0.0, 0.5);
  gW0 = 0.3 * sin(t * 0.05);
  gO = tuPlane(0, 3, 0.4 + 0.02 * t) * tuPlane(1, 2, 0.3 + 0.013 * t) * tuPlane(2, 3, 0.25);
  gOuter = vec4(66.0, 8.0 * sin(t * 0.02), 0.55, 1.0);
}

void main() {
  vec2 uv = (gl_FragCoord.xy - 0.5 * resolution.xy) / resolution.y;
  bool directed = tuDir > 0.5;
  vec3 ro, fwd, right, up;
  float tanHalf;
  if (directed) {
    gR = tuR; gG0 = tuG0; gG1 = tuG1; gG2 = tuG2; gC = tuC; gO = tuO; gOuter = tuOuter;
    gHoles = tuHoles; gGyroA = tuGyroA; gGyroW = tuGyroW; gCoreShape = tuCoreShape;
    gLight = tuLight; gMood = tuMood; gW0 = tuSlice.x; gTime = tuSlice.y; gInside = tuSlice.w;
    ro = tuCamPos.xyz; tanHalf = tuCamPos.w;
    right = tuCamBasis[0]; up = tuCamBasis[1]; fwd = tuCamBasis[2];
  } else {
    gTime = presetTime;
    tuDefaults(gTime);
    float az = 3.6 + gTime * 0.03;
    ro = vec3(sin(az), 0.25, cos(az)) * 34.0;
    fwd = normalize(-ro);
    right = normalize(cross(fwd, vec3(0.0, 1.0, 0.0)));
    up = cross(right, fwd);
    tanHalf = 0.4;
    gInside = 0.0;
  }
  gRo = ro;
  gGram0 = tuGram(gG0); gGram1 = tuGram(gG1); gGram2 = tuGram(gG2); gGramO = tuGram(gO);
  gPix = 2.0 * tanHalf / resolution.y;
  gClusterR = 2.0 * gGyroA.x + 0.12;
  vec3 rd = normalize(fwd + (uv.x * right + uv.y * up) * 2.0 * tanHalf);

  float hq = quality > 0.5 ? 1.0 : 0.0;
  int maxSteps = hq > 0.5 ? 200 : 150;

  // ---- march: start at the machine's bounding sphere ----
  float bound = TU_H * 2.05;
  float b = dot(ro, rd), cc = dot(ro, ro) - bound * bound;
  float disc = b * b - cc;
  float t = 0.0, tEnd = TU_FAR;
  bool hit = false;
  int steps = 0;
  float aaR = 1e9, aaT = -1.0;            // closest approach to the cages, in pixels
  if (disc > 0.0) {
    float sq = sqrt(disc);
    t = max(0.0, -b - sq);
    tEnd = -b + sq;
    for (int i = 0; i < 200; i++) {
      if (i >= maxSteps) break;
      steps = i;
      vec3 p = ro + rd * t;
      float d = tuMap(p);
      float eps = max(0.0006, t * gPix * 0.45);
      if (gClusterD < 1e8) {
        float pr = gClusterD / max(t * gPix, 1e-5);
        if (pr < aaR) { aaR = pr; aaT = t; }
      }
      if (d < eps) { hit = true; break; }
      t += d * 0.92;
      if (t > tEnd) break;
    }
    // continuation: rays that ran out of steps close to a surface count as hits
    if (!hit && t < tEnd && steps >= maxSteps - 1) {
      for (int i = 0; i < 40; i++) {
        float d = tuMap(ro + rd * t);
        if (d < max(0.001, t * gPix * 1.2)) { hit = true; break; }
        t += d;
        if (t > tEnd) break;
      }
    }
  }

  vec3 coreTint = mix(vec3(1.0, 0.60, 0.26), vec3(1.0, 0.45, 0.42), 0.5 + 0.5 * sin(6.28318 * tuSlice.z));
  coreTint = mix(coreTint, vec3(0.75, 0.85, 1.0), gLight.w * 0.7);
  vec3 col;
  float tHit = hit ? t : TU_FAR;

  vec3 pHit = ro + rd * t;
  float cidHit = 0.0;
  bool cageHit = hit && length(pHit) < gClusterR + 0.2 && tuCluster(pHit, cidHit) < tuSponge(pHit);
  if (cageHit) {
    col = tuShadeCage(pHit, rd, t, coreTint, tuPulses(length(pHit) * 1.2));
  } else if (hit) {
    vec3 p = ro + rd * t;
    float ne = max(0.0012, t * gPix * 1.3);
    vec3 n = tuNormal(p, ne);
    vec3 v = -rd;
    float ndv = max(dot(n, v), 0.0);

    // ---- which object, which material ----
    float level, axis, edge;
    vec4 p4;
    float ds = tuSpongeInfo(p, level, axis, edge, p4);
    bool sponge = true;

    vec3 F0 = vec3(0.04);
    vec3 albedo = vec3(0.0);
    float rough = 0.3;
    vec3 emit = vec3(0.0);
    float cheb = tuMax4(abs(p4));                       // 4D Chebyshev radius: pulse shells
    float pulse = tuPulses(cheb);
    float foot = t * gPix;

    if (sponge) {
      float lw = (level < 0.5 ? 0.05 : level < 1.5 ? 0.045 : level < 2.5 ? 0.025 : 0.012);
      float wPix = max(lw, foot * 0.9);
      float seam = (lw / wPix) * (1.0 - smoothstep(wPix * 0.5, wPix * 1.5, edge));
      if (axis > 2.5) {
        // a face whose 4D normal is the hidden axis: iridescent crystal
        vec3 film = tuFilm(ndv * 0.9 + p4.w * 0.07 + level * 0.13 + tuSlice.z);
        float graze = pow(1.0 - ndv, 3.0);
        F0 = mix(vec3(0.06, 0.05, 0.10), film * 0.9, 0.25 + 0.6 * graze);
        albedo = vec3(0.004, 0.002, 0.012);
        rough = 0.05;
        emit = vec3(0.05, 0.016, 0.13) * (0.1 + 0.5 * graze) * (0.4 + 0.6 * gMood.w);
        emit += film * vec3(0.5, 0.4, 1.0) * seam * 0.45;
      } else if (level < 0.5) {
        // outer faces: dark titanium, engraved with the finest cell grid
        F0 = mix(vec3(0.11, 0.12, 0.145), vec3(0.15, 0.13, 0.11), axis * 0.5);
        albedo = vec3(0.004);
        rough = 0.24;
        vec4 g = abs(fract(p4 / (TU_H * 2.0 / 27.0)) - 0.5);
        vec4 sg = tuSortDesc(g);
        float gl = 0.5 - sg.y;                            // distance to a grid line on this face
        float gw = max(0.01, foot * 0.06);
        float groove = (0.01 / gw) * (1.0 - smoothstep(0.0, gw * 1.5, gl));
        emit += vec3(1.0, 0.72, 0.36) * groove * (0.03 + 0.5 * gLight.z * gLight.z + 0.6 * pulse) * 0.6;
      } else if (level < 1.5) {
        // the great apertures: liquid chrome
        F0 = vec3(0.78, 0.79, 0.84);
        rough = 0.10;
      } else if (level < 2.5) {
        F0 = vec3(0.16, 0.155, 0.18);
        albedo = vec3(0.004);
        rough = 0.18;
      } else {
        // the finest apertures: gold light ports, dim when quiet, lit as the pulses pass
        F0 = vec3(0.98, 0.70, 0.34) * 0.8;
        rough = 0.2;
        float port = 0.025 + 1.3 * pulse + 0.45 * gLight.y + 0.12 * gLight.z + 0.35 * gLight.w;
        emit += vec3(1.0, 0.56, 0.22) * port * 0.45;
      }
      // seams along every 4D edge: gold light, charged by builds, lit by pulses
      vec3 seamCol = mix(vec3(1.0, 0.68, 0.30), vec3(0.85, 0.55, 1.0), axis > 2.5 ? 0.7 : 0.15);
      float seamLum = 0.025 + 0.9 * gLight.y + 2.6 * pulse + 0.4 * gLight.w;
      seamLum *= level < 2.5 ? 1.0 : 0.6;
      emit += seamCol * seam * seamLum;
    }

    // ---- lighting ----
    float occ = tuAO(p, n, sponge ? 1.0 : 0.25);
    vec3 R = reflect(rd, n);
    // key light: the cold distant star of the void
    vec3 L = TU_KEY_DIR;
    float ndl = max(dot(n, L), 0.0);
    float sh = ndl > 0.0 ? tuSoftShadow(p + n * 0.01, L, 40.0, hq > 0.5 ? 40 : 26) : 0.0;
    vec3 keyCol = vec3(0.80, 0.86, 1.0) * 1.9;
    vec3 H = normalize(L + v);
    float a2 = max(rough * rough, 0.002);
    float ndh = max(dot(n, H), 0.0);
    float D = a2 / (3.14159 * pow(ndh * ndh * (a2 - 1.0) + 1.0, 2.0));
    vec3 F = F0 + (1.0 - F0) * pow(1.0 - max(dot(H, v), 0.0), 5.0);
    float vis = 0.25 / max(0.05, ndl * ndv + 0.05);
    vec3 spec = D * F * vis;
    col = (albedo + spec) * keyCol * ndl * sh * TU_KEY;
    // warm rim from the far side of the void: draws the silhouettes of walls and apertures
    vec3 Lr = TU_RIM_DIR;
    float rim = pow(1.0 - ndv, 4.0) * max(dot(n, Lr) + 0.35, 0.0);
    col += (albedo * 4.0 + F0) * vec3(1.0, 0.55, 0.25) * rim * 0.55 * (1.0 - gInside * 0.7) * TU_RIM;

    // core light
    float r = length(p);
    vec3 Lc = -p / max(r, 1e-3);
    float ndlc = max(dot(n, Lc), 0.0);
    // the core reaches the chamber and the apertures of the first level, not the depths
    vec4 cc4 = abs(p4);
    float tunnel = -tuSecond(cc4 - gHoles.x * TU_H);      // > 0 inside the first-level tunnels
    float reach = smoothstep(-3.0, 0.4, tunnel) * smoothstep(TU_H * 1.6, TU_H * 0.3, r);
    float csh = (ndlc > 0.0 && r < TU_H * 1.2) ? tuCoreShadow(p + n * 0.01) : 1.0;
    float coreI = gLight.x * 70.0 / (1.0 + r * r * 1.5) * reach * csh;
    vec3 Hc = normalize(Lc + v);
    float ndhc = max(dot(n, Hc), 0.0);
    float Dc = a2 / (3.14159 * pow(ndhc * ndhc * (a2 - 1.0) + 1.0, 2.0));
    vec3 Fc = F0 + (1.0 - F0) * pow(1.0 - max(dot(Hc, v), 0.0), 5.0);
    col += (albedo + Dc * Fc * 0.25 / max(0.05, ndlc * ndv + 0.05)) * coreTint * coreI * ndlc * TU_CORE;

    // environment reflection (rough surfaces see a dimmer, flatter environment)
    vec3 Fv = F0 + (1.0 - F0) * pow(1.0 - ndv, 5.0) * (1.0 - rough);
    vec3 env = rough < 0.15 ? tuReflection(p + n * (sponge ? 0.01 : 0.03), R, coreTint, hq > 0.5 ? 56 : 36, 1.0 / max(ndv, 0.08)) : tuEnv(p, R, coreTint * gLight.x);
    env = mix(env, vec3(dot(env, vec3(0.33))) * 0.6, clamp(rough * 2.5, 0.0, 1.0));
    col += env * Fv * (rough < 0.15 ? 1.0 : occ * (0.55 + 0.45 * smoothstep(-0.3, 0.6, R.y))) * TU_ENV * (rough < 0.15 ? 1.0 : 1.0 - 0.75 * smoothstep(TU_H * 1.2, TU_H * 0.5, length(p)));
    // ambient fill so shadowed architecture never falls to pure black
    col += (albedo + F0 * 0.05) * vec3(0.05, 0.05, 0.08) * occ;

    col += emit * mix(1.0, occ, 0.4) * TU_EMIT;
    // the hypercube shell sweeping over surfaces
    col += vec3(1.0, 0.7, 0.4) * pulse * 0.02 * occ;

    // aerial perspective: monumental depth, violet
    float fogD = 1.0 - exp(-max(t - 4.0, 0.0) * mix(0.0035, 0.016, gInside));
    vec3 fogCol = mix(vec3(0.012, 0.010, 0.03), vec3(0.018, 0.011, 0.02), gInside);
    col = mix(col, fogCol, fogD * 0.7);
  } else {
    col = tuSky(rd);
    // the colossal outer hyper-cage: a tesseract frame far around the machine
    if (gOuter.w > 0.01) {
      float to = max(t, 1.0);
      bool oh = false;
      float g;
      for (int i = 0; i < 40; i++) {
        float d = tuFrame(ro + rd * to, gO, gGramO, gOuter.y, gOuter.x, gOuter.z, g);
        if (d < to * gPix * 0.6) { oh = true; break; }
        to += d;
        if (to > 420.0) break;
      }
      if (oh) {
        vec3 q = ro + rd * to;
        vec2 k = vec2(1.0, -1.0) * max(0.02, to * gPix);
        vec3 on = normalize(k.xyy * tuFrame(q + k.xyy, gO, gGramO, gOuter.y, gOuter.x, gOuter.z, g) +
                            k.yyx * tuFrame(q + k.yyx, gO, gGramO, gOuter.y, gOuter.x, gOuter.z, g) +
                            k.yxy * tuFrame(q + k.yxy, gO, gGramO, gOuter.y, gOuter.x, gOuter.z, g) +
                            k.xxx * tuFrame(q + k.xxx, gO, gGramO, gOuter.y, gOuter.x, gOuter.z, g));
        vec3 L = TU_KEY_DIR;
        vec3 Lr = TU_RIM_DIR;
        float ndv = max(dot(on, -rd), 0.0);
        vec3 H = normalize(L - rd);
        vec3 oc = vec3(0.012, 0.012, 0.016) + vec3(0.8, 0.86, 1.0) * (0.05 * max(dot(on, L), 0.0) + 0.6 * pow(max(dot(on, H), 0.0), 40.0));
        oc += vec3(1.0, 0.55, 0.25) * 0.25 * pow(1.0 - ndv, 3.0) * max(dot(on, Lr) + 0.3, 0.0);
        oc += tuEnv(q, reflect(rd, on), vec3(0.0)) * 0.5 * (0.2 + 0.8 * pow(1.0 - ndv, 4.0));
        float rimLine = pow(1.0 - ndv, 6.0);
        oc += vec3(1.0, 0.66, 0.3) * rimLine * (0.05 + 0.9 * tuPulses(length(q) * 0.25) + 0.5 * gLight.y);
        float fogO = 1.0 - exp(-to * 0.0045);
        col = mix(oc, col, fogO * 0.85) * gOuter.w + col * (1.0 - gOuter.w);
      }
    }
  }

  // ---- cage silhouettes: a ray that passed within a pixel of a beam picks up its coverage ----
  if (aaT > 0.0 && aaT < tHit - 0.01 && aaR > 0.3 && aaR < 1.5) {
    float cover = 0.5 * (1.0 - smoothstep(0.3, 1.5, aaR));
    vec3 pe = ro + rd * aaT;
    // pull the sample onto the surface along the normal so it is shaded where the beam is
    vec3 ne = tuNormal(pe, max(0.0012, aaT * gPix * 1.3));
    float idc;
    pe -= ne * tuCluster(pe, idc);
    col = mix(col, tuShadeCage(pe, rd, aaT, coreTint, tuPulses(length(pe) * 1.2)), cover);
  }

  // ---- translucent membranes of the cages ----
  if (length(cross(rd, -ro)) < gClusterR + 0.2) {
    col += tuMembranes(ro, rd, tHit, vec3(0.35, 0.22, 0.9));
  }

  // ---- in-scattered core light (closed form for a point light along the ray) ----
  {
    float tc = -dot(ro, rd);
    vec3 pc = ro + rd * tc;
    float h = max(length(pc), 0.05);
    float tOut = min(tHit, TU_FAR);
    float I = (atan((tOut - tc) / h) - atan(-tc / h)) / h;
    col += coreTint * I * gLight.x * 0.010 * (0.5 + 0.5 * gInside + 0.8 * gLight.w);
  }

#if TU_DEBUG == 2
  col = gReflT < 0.0 ? vec3(0.0, 0.0, 0.3) : vec3(clamp(gReflT / 2.0, 0.0, 1.0), clamp(gReflT / 20.0, 0.0, 1.0), 0.0);
#endif
#if TU_DEBUG == 1
  col = hit ? vec3(float(steps) / float(maxSteps), 0.0, 0.0) : vec3(0.0, 0.0, float(steps) / float(maxSteps));
#endif

  // ---- grade ----
  float exposure = 1.0 + 0.12 * gLight.w;
  col *= exposure;
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  float lm = l * (1.0 + l / 9.0) / (1.0 + l);           // extended Reinhard on luminance
  col *= lm / max(l, 1e-4);
  col = 1.0 - exp(-col * 1.15);                          // soft per-channel shoulder
  col = pow(max(col, 0.0), vec3(0.4545));
  col = mix(col, col * col * (3.0 - 2.0 * col), 0.45);   // contrast: deeper shadows, firmer highlights
  float vig = smoothstep(1.25, 0.25, length(uv * vec2(0.85, 1.0)));
  col *= 0.78 + 0.22 * vig;
  col += (hash(gl_FragCoord.xy + fract(gTime) * 91.0) - 0.5) / 255.0;

  col *= transitionIdentityPresence();
  col += transitionTunnel(uv);
  outColor = vec4(col, 1.0);
}
`
    }]
  ];
}
