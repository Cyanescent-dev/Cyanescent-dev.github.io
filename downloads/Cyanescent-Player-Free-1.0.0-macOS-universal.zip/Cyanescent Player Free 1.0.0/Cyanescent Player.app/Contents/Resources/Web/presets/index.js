import { runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
import { editionConfig, editionAllowsPreset } from "../generated/editionConfig.js";

export const ALL_PRESET_METADATA = [
  { id: 1, name: "Fractal Temple", category: "fractal", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["fractal", "psytrance", "sacred"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 3, name: "Entangled Tunnel", category: "quantum", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["quantum", "psytrance"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 5, name: "Apollonian Foam", category: "fractal", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["fractal", "psytrance"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 6, name: "Quasicrystal Field", category: "fractal", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: ["quantum", "fractal"], goodForBuildUps: true, goodForDrops: false, goodForBreakdowns: false },
  { id: 8, name: "Quantum Strange Attractor", category: "quantum", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["quantum", "experimental", "psytrance"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 10, name: "Fractal Chrysalis", category: "fractal", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: ["fractal", "organic"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 13, name: "Quantum Circuit City", category: "quantum", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["quantum", "electronic"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 33, name: "Flower of Becoming", category: "sacred", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["sacred", "geometry", "flower"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 37, name: "Voronoi Lifeforms", category: "experimental", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["organic", "math", "lifeforms"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 59, name: "Serpent of the Infinite Sky", category: "cosmic", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["cosmic", "deity", "nebula", "psytrance"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 78, name: "Radiolarian Cathedral", category: "organic", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["organic", "video", "cathedral", "abyss"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 79, name: "Evolution of Dance", category: "electronic", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["electronic", "video", "dance", "evolution"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 80, name: "Cathedral of Attractors", category: "ancient", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["ancient", "mathematics", "attractors", "ambient"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 83, name: "Quantum Fluid Dynamics", category: "organic", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["organic", "fluid", "cosmic", "3d"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 84, name: "Kleinian Coral Cathedral", category: "fractal", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["fractal", "steady", "psychedelic", "3d"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 94, name: "Chaotic Butterfly Tunnels", category: "organic", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["tunnel", "butterfly", "lorenz", "psytrance", "organic"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 97, name: "Feather Star Ascension", category: "organic", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["organic", "ocean", "crinoid", "bioluminescent"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 98, name: "Abyssal Lace Organism", category: "organic", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["organic", "ocean", "fractal", "bioluminescent"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 102, name: "Cosmic Ray", category: "organic", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: ["organic", "ocean", "manta", "silk", "bioluminescent"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 141, name: "Quantum Foam", category: "experimental", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["quantum", "psytrance"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 142, name: "Bioluminescent Abyss", category: "experimental", energyLevel: "low", motionIntensity: "low", visualDensity: "dense", moodTags: ["organic", "ocean"], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: true },
  { id: 143, name: "Fractal Tesseract", category: "experimental", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["fractal", "math"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 144, name: "Tribal Geometry", category: "experimental", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: ["sacred", "geometry"], goodForBuildUps: true, goodForDrops: false, goodForBreakdowns: true },
  { id: 145, name: "Voxel Cave", category: "experimental", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["voxel", "cavern"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 146, name: "Tie-Dye Supernova", category: "psychedelic", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["retro", "colorful"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 147, name: "Kaleidoscopic Woodstock", category: "psychedelic", energyLevel: "medium", motionIntensity: "low", visualDensity: "dense", moodTags: ["mandala", "peace"], goodForBuildUps: true, goodForDrops: false, goodForBreakdowns: true },
  { id: 148, name: "Tesseract Unfolding", category: "experimental", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["hypercube", "4d", "sacred-geometry", "machine", "journey"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true, adaptiveMinimumPlaySeconds: 120 },
  { id: 150, name: "Penrose Tiling Crystal", category: "experimental", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["aperiodic", "crystal"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 153, name: "Twistor Space Manifold", category: "experimental", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: ["twistor", "4d", "crystalline", "network"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 154, name: "Spin Network Matrix", category: "experimental", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["spin", "network", "lattice", "crystalline", "journey"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 163, name: "Recursive Feedback Tunnel", category: "recursive", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["recursive", "tunnel"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 165, name: "Fractal Breaker", category: "recursive", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["recursive", "apollonian", "biology"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 166, name: "Audio-Reactive IFS Matrix", category: "recursive", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["recursive", "matrix"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 167, name: "Swirlie Domain Repeater", category: "recursive", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["recursive", "swirl"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 172, name: "Fractal Coral Reef", category: "recursive", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["recursive", "coral"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 174, name: "Sri Yantra Hyperspace", category: "recursive", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["recursive", "sacred", "yantra"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: false },
  { id: 176, name: "Toroidal Merkaba Field", category: "recursive", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["recursive", "sacred", "merkaba", "crystal", "temple"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 180, name: "Cymatic Mandala", category: "sacred", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: ["sacred", "geometry", "cymatic"], goodForBuildUps: true, goodForDrops: false, goodForBreakdowns: true },
  { id: 181, name: "Crystal Resonance", category: "sacred", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["crystal", "hexagonal", "chladni", "resonant"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 182, name: "Harmonic Bloom", category: "sacred", energyLevel: "low", motionIntensity: "low", visualDensity: "medium", moodTags: ["calm", "geometry", "chladni", "hypnotic", "ambient"], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: true },
  { id: 193, name: "Worldshell", category: "organic", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["cymatic", "alien", "planet", "ocean", "predictive", "flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 194, name: "Lynchwave Cathedral", category: "experimental", energyLevel: "medium", motionIntensity: "medium", visualDensity: "high", moodTags: ["cathedral", "toroidal", "braided", "recursive", "psychedelic"], goodForBuildUps: true, goodForDrops: false, goodForBreakdowns: true },
  { id: 201, name: "Colossal Spore Forest", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 210, name: "The Sentient Highway", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 215, name: "Smuggler Run Through The Ninth Dimension", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 224, name: "Ferrofluid Oracle", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 229, name: "Higher-Dimensional Jellyfish", category: "organic", energyLevel: "high", motionIntensity: "high", visualDensity: "high", moodTags: ["4d","hyperspace","jellyfish","bioluminescence","cosmic","creature"], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 245, name: "Sierpinski Pyramid", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 248, name: "Jerusalem Cube", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 252, name: "Magical Apollonian Cavern", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 259, name: "Nova Fractal Megaworld", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 262, name: "Samsara", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 265, name: "Cosmic Loom", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 267, name: "Quantum Garden", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 268, name: "Self Discovering Eye", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 273, name: "Mandelbrot Oculus", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 274, name: "Mandelbrot Newton Morph", category: "fractal", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["fractal","mandelbrot","newton","morph"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 277, name: "Event Horizon", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 285, name: "Mycorrhizal Dreamtime", category: "fractal", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["fractal","organic","apollonian","mandelbulb","psychedelic","cavern"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 289, name: "Fungal Electrophysiology", category: "organic", energyLevel: "medium", motionIntensity: "low", visualDensity: "dense", moodTags: ["organic","fungal","bioelectric","microscopy","scientific","network","bioluminescent","ambient"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 293, name: "Veiled Lady", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 294, name: "Stemonitis Sporangial Forest", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 296, name: "Nidulariaceae Rain Orchestra", category: "organic", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["organic","fungal","rain","macro","ballistic","cinematic","flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 297, name: "Psilocybe Cyanescens — Woodland Reverie", category: "organic", energyLevel: "medium", motionIntensity: "low", visualDensity: "dense", moodTags: ["botanical","woodland","macro","wavy-caps","cinematic","subtle-psychedelia"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 299, name: "Jelly Ear Sonic Resonance", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 300, name: "Bracket Fungus Recursive Forest", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 303, name: "Holly Parachute", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 313, name: "Recursive Bloom Engine", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 316, name: "Hyperbolic Carpet", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 324, name: "Six D Quasicrystal Storm", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 338, name: "Fractal Lightning Cathedral", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: ["cathedral", "electric", "organic", "branching", "journey"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 340, name: "Agarikon", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 341, name: "Myco Bee Fungal Pharmacy", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 343, name: "Spore Memory", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 344, name: "Panther Loop", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 348, name: "Chicken Of The Woods Fungal Fowl", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 355, name: "Pilobolus Spore Cannon", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 358, name: "Electric Mycena Forest", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 360, name: "Red Cage Stinkhorn", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 361, name: "Devils Fingers Apollonian", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 366, name: "Parasol Cathedral", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 369, name: "Earthstar Resonator", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 370, name: "Amethyst Deceiver Crystal Grove", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 371, name: "Wrinkled Peach Folding World", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 375, name: "Distributed Mind", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 377, name: "Living Constellation", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 379, name: "Metatron Fracture Field", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 380, name: "Topological Knot Reactor", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false },
  { id: 388, name: "Living Firepit", category: "custom", energyLevel: "medium", motionIntensity: "medium", visualDensity: "medium", moodTags: [], goodForBuildUps: false, goodForDrops: false, goodForBreakdowns: false, adaptiveMinimumPlaySeconds: 120 },
  { id: 390, name: "Apollonian Physarum Genesis", category: "organic", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["physarum","forge","hybrid","biological"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 391, name: "HD Duoverse", category: "abstract", energyLevel: "medium", motionIntensity: "medium", visualDensity: "dense", moodTags: ["duoverse","forge","hybrid","glass","metal"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 392, name: "Newton Basin Descent V1", category: "fractal", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["newton","mandelbrot","forge","basins","metadata-aware","flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 393, name: "Newtons Law", category: "fractal", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["newton","mandelbrot","forge","light","metadata-aware","flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 394, name: "Artificial Consciousness", category: "abstract", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["neural","network","forge","consciousness","metadata-aware","flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 395, name: "Helix Tunnel", category: "geometry", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["helix","tunnel","forge","propulsion","metadata-aware"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 396, name: "Clifford Phase Space: Metamorphosis", category: "experimental", energyLevel: "high", motionIntensity: "high", visualDensity: "dense", moodTags: ["clifford","strange-attractor","chaos","psychedelic","metamorphosis","flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 397, name: "Shadow Geometry: Impossible Apertures", category: "geometry", energyLevel: "high", motionIntensity: "medium", visualDensity: "medium", moodTags: ["geometry","shadow","anamorphic","sculpture","light","flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true },
  { id: 398, name: "Hypergeometry Engine: Dimensional Emergence", category: "geometry", energyLevel: "high", motionIntensity: "medium", visualDensity: "dense", moodTags: ["geometry","4d","polytope","hyperdimensional","emergence","flagship"], goodForBuildUps: true, goodForDrops: true, goodForBreakdowns: true, adaptiveMinimumPlaySeconds: 120 },
];

// Candidates retain optional-world registration; the default library contains core content only.
// Native validation completes before this module evaluates.
export const PRESET_CANDIDATE_METADATA = ALL_PRESET_METADATA.filter((preset) => editionAllowsPreset(preset.id))
  .map((preset) => ({ ...preset, optional: (editionConfig.optionalPresetIds || []).includes(preset.id),
    requiresInstalledContent: (editionConfig.optionalPresetIds || []).includes(preset.id) }));
export const PRESET_METADATA = PRESET_CANDIDATE_METADATA.filter((preset) => runtimeAllowsPreset(preset.id));

export const presetMetadataById = new Map(PRESET_METADATA.map((preset) => [preset.id, preset]));

export function adaptiveEligiblePresetIds(availablePresetIds) {
  return availablePresetIds.filter((id) => runtimeAllowsPreset(id));
}

export function pineThemeForPreset(presetId) {
  return 0;
}

export function isFiddleheadPreset(presetId) {
  return false;
}

export function isPineconePreset(presetId) {
  return false;
}

export function isKleinianCoralCathedralPreset(presetId) {
  return Number(presetId) === 84;
}

export function isQuantumFluidPreset(presetId) {
  return Number(presetId) === 83;
}

export function isBloodCellNebulaPreset(presetId) {
  return false;
}

export function isSpecialGeometryPreset(presetId) {
  return isFiddleheadPreset(presetId)
    || isPineconePreset(presetId)
    || isQuantumFluidPreset(presetId)
    || isKleinianCoralCathedralPreset(presetId)
    || isBloodCellNebulaPreset(presetId);
}
