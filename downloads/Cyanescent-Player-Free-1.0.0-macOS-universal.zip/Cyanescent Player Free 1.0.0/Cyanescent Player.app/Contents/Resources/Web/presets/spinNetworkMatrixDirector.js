// Spin Network Matrix (preset 154), The Living Quantum Lattice: the director.
//
// The lattice is the original's: unit cells, each with three orthogonal conduits and four body
// diagonals through its centre, an octahedral junction with a smaller core at the centre, and a void
// carved through it for the camera. The shader draws it; this file (pure JS, no GL, so it can be
// tested) decides how it moves, breathes and lights up:
//   travel     the camera flies along a weaving corridor through the lattice at a speed that is a
//              slewed function of the music (the original added phrasePulse to the position, so every
//              phrase boundary jumped the whole network forwards)
//   chambers   every SNM_CHAMBER_SPACING cells the corridor opens into a large void (a cycle of six
//              shapes); the camera slows, drifts off the axis and looks around, then dives back in
//   twist      the original's spiral of the lattice ahead, now on a slow accumulated phase instead of
//              sin(t + globalEnergy), which jumped with every energy change
//   breathing  a spatially continuous wave displaces the whole lattice (the original jiggled every cell
//              by its own amount, which tore the beams apart at cell boundaries); bass deepens it
//   pulses     kicks light a junction ahead and a wavefront runs outwards through the conduits; builds
//              send converging waves to the drop point; drops send one huge wave; breakdowns send
//              single signals along straight conduit lines
//   evolution  palette (sapphire, violet, emerald, amber) at phrase and section scale, conduit family
//              balance, junction opening, corner junctions and fog depth on slow envelopes
// The camera never reads instantaneous kick or bass values.
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";

export const SPIN_NETWORK_MATRIX_PRESET_ID = 154;
export const SNM_PULSE_SLOTS = 6;
export const SNM_CHAMBER_SPACING = 56;
// Chamber cycle: xyz radius scales and the base radius (cells). Mirrored in the shader (SNM_CH).
export const SNM_CHAMBERS = [
  [1.0, 1.0, 1.0, 6.0],
  [1.35, 0.7, 1.0, 7.0],
  [1.0, 1.0, 1.3, 4.5],
  [1.15, 0.95, 1.2, 9.5],
  [0.75, 1.3, 1.0, 6.5],
  [1.1, 1.0, 1.4, 5.0]
];
export const SNM_CAMERA_MARGIN = 0.16;   // void depth the camera keeps (beams are ~0.03 thick)
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth01 = (x) => { const t = clamp(x); return t * t * (3 - 2 * t); };
const smoother01 = (x) => { const t = clamp(x); return t * t * t * (t * (t * 6 - 15) + 10); };
const mix = (a, b, t) => a + (b - a) * t;

// ---- geometry shared with the shader ----------------------------------------------------------------
// Everything that varies along z repeats every SNM_Z_PERIOD cells (six chambers), so the director
// can wrap the camera's z on long sessions without any visible jump or float precision loss.
export const SNM_Z_PERIOD = 6 * SNM_CHAMBER_SPACING;
export const SNM_KZ = (2 * Math.PI) / SNM_Z_PERIOD;
// The corridor's centre line in lattice space (slopes stay under 0.21, so the corridor's distance
// bound only needs a 0.96 factor).
export function snmPath(z) {
  return [
    1.35 * Math.sin(3 * SNM_KZ * z) + 0.55 * Math.sin(8 * SNM_KZ * z + 1.7),
    1.05 * Math.sin(3 * SNM_KZ * z + 2.1) + 0.45 * Math.sin(7 * SNM_KZ * z + 0.4)
  ];
}
export const snmCorridorRadius = (z) => 0.36 + 0.08 * Math.sin(2 * SNM_KZ * z + 1.0);

function smin(a, b, k) {
  const h = clamp(0.5 + 0.5 * (b - a) / k);
  return b + (a - b) * h - k * h * (1 - h);
}

export function snmChamber(z) {
  const n = Math.floor(z / SNM_CHAMBER_SPACING + 0.5);
  const [sx, sy, sz, r] = SNM_CHAMBERS[((n % 6) + 6) % 6];
  const zc = n * SNM_CHAMBER_SPACING;
  return { n, zc, centre: [...snmPath(zc), zc], radii: [sx * r, sy * r, sz * r] };
}

// Signed distance bound to the carved void (negative inside), in lattice space.
export function snmVoid(q) {
  const [cx, cy] = snmPath(q[2]);
  const corridor = Math.hypot(q[0] - cx, q[1] - cy) * 0.96 - snmCorridorRadius(q[2]);
  const { centre, radii } = snmChamber(q[2]);
  const e = Math.hypot((q[0] - centre[0]) / radii[0], (q[1] - centre[1]) / radii[1], (q[2] - centre[2]) / radii[2]);
  const chamber = (e - 1) * Math.min(...radii);
  return smin(corridor, chamber, 0.9);
}

// How far inside a chamber z is (0 in the corridor, 1 near the chamber's middle).
export function snmChamberness(z) {
  const { zc, radii } = snmChamber(z);
  return smoother01((1 - Math.abs(z - zc) / radii[2]) / 0.65);
}

// GLSL rot(a) = mat2(c, -s, s, c) (column-major): v' = (c x + s y, -s x + c y).
function rot2(a, x, y) { const c = Math.cos(a), s = Math.sin(a); return [c * x + s * y, -s * x + c * y]; }

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const scale3 = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm3 = (a) => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
function rotateAbout(v, axis, a) {
  const c = Math.cos(a), s = Math.sin(a);
  return add(add(scale3(v, c), scale3(cross(axis, v), s)), scale3(axis, dot3(axis, v) * (1 - c)));
}

// Palettes: conduit body, channel light, junction light, accent. The first is the original's
// blue-and-magenta; the others are reached at phrase and section scale.
export const SNM_PALETTES = [
  [[0.010, 0.026, 0.080], [0.10, 0.55, 1.00], [1.00, 0.18, 0.62], [0.75, 0.90, 1.00]],   // sapphire
  [[0.026, 0.012, 0.070], [0.42, 0.24, 1.00], [0.95, 0.30, 0.95], [0.82, 0.80, 1.00]],   // violet
  [[0.006, 0.040, 0.040], [0.08, 0.95, 0.70], [1.00, 0.72, 0.22], [0.80, 1.00, 0.85]],   // emerald
  [[0.052, 0.022, 0.018], [1.00, 0.52, 0.18], [1.00, 0.30, 0.48], [1.00, 0.95, 0.88]]    // amber
];
function paletteAt(pos) {
  const n = SNM_PALETTES.length;
  const i = Math.floor(pos), f = smooth01(pos - i);
  const a = SNM_PALETTES[((i % n) + n) % n], b = SNM_PALETTES[(((i + 1) % n) + n) % n];
  return a.map((c, k) => c.map((v, j) => mix(v, b[k][j], f)));
}

// Signal directions: the three conduit axes and the four body diagonals.
const R3 = 1 / Math.sqrt(3);
const LINE_DIRS = [[1, 0, 0], [0, 1, 0], [0, 0, 1], [R3, R3, R3], [-R3, R3, R3], [R3, -R3, R3], [R3, R3, -R3]];

// ---- the director -------------------------------------------------------------------------------
export function createSpinNetworkMatrixDirector() {
  const audioModel = createNewtonAudioModel();
  const s = {};
  const pulses = [];
  const uniforms = {};
  let seed = 1;
  const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  function reset() {
    audioModel.reset();
    pulses.length = 0;
    seed = 0x5eed154;
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0, beat: 0,
      // envelopes
      energy: 0.35, energySlow: 0.35, mids: 0.35, midsSlow: 0.35, highs: 0.3, bass: 0.4, bassSlow: 0.4,
      calm: 0, drive: 0, tension: 0, shimmer: 0, flash: 0, surge: 0, hatSpark: 0, awake: 0.3,
      // phases (all accumulated: tempo or envelope changes alter rates, never positions)
      twistPhase: 0.6, warpPhase: 0, breathPhase: 0, packetPhase: 0, sparkClock: 0, formPhase: 0, cornerPhase: 1.3, film: 0,
      // structure
      nodeOpen: 0.2, diagBias: 0.5, warpAmp: 0.03, cornerSize: 0.0, fog: 0.085,
      // palette
      palPos: 0, palTarget: 0, palVel: 0, lastPalChange: 0, wasCalm: false,
      // camera
      J: 0, camZ: 20, speed: 1.2, speedV: 0, fwd: [0, 0, 1], up: [0, 1, 0], tanHalf: 0.66, lastPos: null,
      clearance: 1, minClearance: Infinity, chamberness: 0,
      // counters (tests, trial reports)
      kicks: 0, drops: 0, rolls: 0, signals: 0, lastDropAt: -1e9, nextSignalBeat: 0
    });
  }
  reset();

  const SHAPES = {
    //            speed  width wake range life  lineMix
    kick:   { speed: 6.5, width: 0.32, wake: 2.2, range: 6.5, life: 1.7, line: 0 },
    drop:   { speed: 8.0, width: 0.8, wake: 1.4, range: 22, life: 4.2, line: 0 },
    roll:   { speed: -6.0, width: 0.6, wake: 0, range: 40, life: 1.15, line: 0 },
    signal: { speed: 2.6, width: 0.35, wake: 0.3, range: 12, life: 4.0, line: 1 }
  };

  function spawn(kind, strength, src, extra = {}) {
    const shape = SHAPES[kind];
    if (pulses.length >= SNM_PULSE_SLOTS) {
      let oldest = 0;
      for (let i = 1; i < pulses.length; i++) if (pulses[i].age / pulses[i].life > pulses[oldest].age / pulses[oldest].life) oldest = i;
      pulses.splice(oldest, 1);
    }
    pulses.push({ kind, strength, src, dir: extra.dir || [0, 0, 1], start: extra.start ?? 0, age: 0, ...shape });
  }

  // A junction near the camera that exists (outside the void), offset ahead / sideways in camera space.
  function nodeNear(pos, fwd, right, up, ahead, side, rise) {
    let p = add(pos, add(scale3(fwd, ahead), add(scale3(right, side), scale3(up, rise))));
    let node = p.map(Math.round);
    for (let i = 0; i < 32 && snmVoid(node) < 0.3; i++) {
      // push outwards from the corridor / chamber centre line until the junction is real lattice
      const [cx, cy] = snmPath(p[2]);
      const out = norm3([p[0] - cx || side || 1, p[1] - cy || rise, 0]);
      p = add(p, scale3(out, 0.9));
      node = p.map(Math.round);
    }
    return node;
  }

  // time: seconds (monotonic per preset activation). input: { audio, smooth, music, tempo }.
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = clamp(time - s.lastTime, 0, 0.1);
    s.lastTime = time;
    s.time += dt;
    const { audio = {}, smooth = {}, music = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    s.beat = a.beat;

    // ---- musical envelopes (slew-limited: nothing below reaches the geometry raw) -------------------
    s.energy = follow(s.energy, Math.max(a.energyDrive * 0.9, clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.8), dt, 0.5, 1.6);
    s.energySlow = follow(s.energySlow, s.energy, dt, 4, 6);
    s.mids = follow(s.mids, clamp(smooth.mids), dt, 0.4, 0.8);
    s.midsSlow = follow(s.midsSlow, s.mids, dt, 1.4, 1.8);
    s.highs = follow(s.highs, clamp(smooth.highs), dt, 0.05, 0.25);
    s.bass = follow(s.bass, clamp(Math.max(a.sub, clamp(smooth.bass) * 0.85)), dt, 0.5, 1.1);
    s.bassSlow = follow(s.bassSlow, s.bass, dt, 0.9, 1.5);
    s.calm = follow(s.calm, clamp((a.breakdown - 0.35) / 0.45) * (1 - a.groove * 0.7) * (1 - clamp(Math.max(a.build, clamp(music.buildUp)) * 1.6)), dt, 1.4, 1.8);
    s.drive = follow(s.drive, clamp(a.groove * (0.5 + 0.5 * s.energy)), dt, 0.8, 1.6);
    const forecast = clamp(Math.max(clamp(music.upcomingDrop) * 1.2, a.build));
    s.tension = follow(s.tension, forecast * (1 - s.calm * 0.5), dt, 0.8, 1.2);

    // ---- camera frame of the previous step (pulse sources are placed relative to it) ---------------
    const pos0 = s.lastPos || [...snmPath(s.camZ), s.camZ];
    const fwd0 = s.fwd, up0 = s.up, right0 = norm3(cross(up0, fwd0));

    // ---- events -------------------------------------------------------------------------------------
    for (const w of events.waves) {
      if (w.kind === "kick") {
        // a junction ahead flares and its wave runs outwards; the bar's four kicks walk around the frame
        const b = w.beatInBar ?? (s.kicks % 4);
        const side = [1.5, -1.4, 1.1, -1.2][b % 4], rise = [0.7, 0.9, -1.1, -0.8][b % 4];
        const ahead = 2.6 + 1.2 * ((s.kicks >> 2) % 3);
        spawn("kick", w.strength * (b === 0 ? 1 : 0.7), nodeNear(pos0, fwd0, right0, up0, ahead, side, rise));
        s.kicks += 1;
      } else if (w.kind === "roll" && s.tension > 0.25) {
        // build rolls converge on the junction straight ahead, where the drop will break
        spawn("roll", 0.35 + 0.55 * w.strength, nodeNear(pos0, fwd0, right0, up0, 6.5, 0.4, 0.6), { start: 7.5 });
        s.rolls += 1;
      } else if (w.kind === "tide") {
        spawnSignal(pos0, fwd0, right0, up0, 0.8);
      }
    }
    // breakdowns: isolated signals travel along single conduit lines
    if (s.calm > 0.4 && s.beat >= s.nextSignalBeat) {
      spawnSignal(pos0, fwd0, right0, up0, 0.9 + 0.6 * s.midsSlow);
      s.nextSignalBeat = s.beat + 1.5 + Math.floor(rand() * 3) * 0.75;
    } else if (s.calm <= 0.4) s.nextSignalBeat = Math.max(s.nextSignalBeat, s.beat);
    if (events.hats) s.hatSpark = Math.max(s.hatSpark, 0.5 + 0.5 * a.highDrive);
    // the kick returning in the middle of a build (a tease) is a rebound, not the drop
    const rebound = events.drop && clamp(music.buildUp) > 0.5 && clamp(music.drop) < 0.6;
    if (rebound) { spawn("kick", 1.1, nodeNear(pos0, fwd0, right0, up0, 3.5, 0.5, 0.6)); s.flash = Math.max(s.flash, 0.3); }
    if (events.drop && !rebound && s.time - s.lastDropAt > 6) {
      s.lastDropAt = s.time; s.drops += 1;
      pulses.length = 0;
      spawn("drop", 1.6, nodeNear(pos0, fwd0, right0, up0, 2.2, 0, 0));
      s.flash = 1; s.surge = 1;
      if (s.time - s.lastPalChange > 12) { s.palTarget += 1; s.lastPalChange = s.time; }
    }
    s.flash *= Math.exp(-dt / 1.0);
    s.surge = Math.max(0, s.surge - dt / 16);
    s.hatSpark *= Math.exp(-dt / 0.12);
    s.shimmer = clamp(0.25 * s.highs + 0.55 * a.highDrive * (0.4 + 0.6 * s.energy) + 0.45 * s.hatSpark);
    for (const p of pulses) p.age += dt;
    for (let i = pulses.length - 1; i >= 0; i--) if (pulses[i].age > pulses[i].life) pulses.splice(i, 1);

    // ---- palette: phrase-scale drift, drops advance it, breakdowns turn to violet --------------------
    const calmNow = s.calm > 0.5;
    if (calmNow && !s.wasCalm && s.time - s.lastPalChange > 8) {
      const n = SNM_PALETTES.length;
      // the nearest violet, forwards or backwards
      const base = Math.round(s.palPos);
      let t = base;
      for (let k = 0; k < n; k++) {
        if ((((base + k) % n) + n) % n === 1) { t = base + k; break; }
        if ((((base - k) % n) + n) % n === 1) { t = base - k; break; }
      }
      s.palTarget = t; s.lastPalChange = s.time;
    }
    s.wasCalm = calmNow;
    if (s.time - s.lastPalChange > 128 / bps) { s.palTarget += 1; s.lastPalChange = s.time; }
    const wp = 0.22;   // critically damped: a change takes ~15 s
    s.palVel += (wp * wp * (s.palTarget - s.palPos) - 2 * wp * s.palVel) * dt;
    s.palVel = clamp(s.palVel, -0.08, 0.08);   // never faster than ~12 s per palette
    s.palPos += s.palVel * dt;

    // ---- structure ----------------------------------------------------------------------------------
    s.formPhase += dt * 0.045 * (0.7 + 0.3 * s.drive);
    s.cornerPhase += dt * 0.029;
    s.twistPhase += dt * 0.05 * (0.6 + 0.4 * s.drive + 0.3 * s.tension);
    s.warpPhase += dt * (0.55 + 0.5 * s.bassSlow + 0.25 * s.drive);
    s.breathPhase += dt * bps * TAU / 4;   // one bass wave per bar
    s.packetPhase += dt * (0.45 + 1.4 * s.mids) * (1 - 0.5 * s.calm);
    s.sparkClock += dt * (3 + 9 * s.shimmer);
    s.film += dt * (0.03 + 0.2 * s.shimmer);
    s.nodeOpen = follow(s.nodeOpen, clamp(0.15 + 0.55 * s.energySlow + 0.35 * s.surge + 0.2 * s.tension - 0.15 * s.calm), dt, 3, 4);
    s.diagBias = 0.5 + 0.5 * Math.sin(s.formPhase);
    s.warpAmp = follow(s.warpAmp, 0.018 + 0.04 * s.bassSlow + 0.02 * s.calm, dt, 2, 2.5);
    s.cornerSize = follow(s.cornerSize, clamp(Math.sin(s.cornerPhase) * 1.6 - 0.2) * 0.042 + 0.012 * s.surge, dt, 2, 2);
    s.awake = follow(s.awake, 0.22 + 0.42 * s.energy + 0.55 * s.surge + 0.15 * s.tension - 0.12 * s.calm, dt, 0.8, 2.2);

    // ---- camera -------------------------------------------------------------------------------------
    s.chamberness = snmChamberness(s.camZ);
    const ch = s.chamberness;
    const speedGoal = (1.25 + 0.45 * s.drive + 0.3 * s.tension + 0.25 * s.surge - 0.5 * s.calm) * (1 - 0.55 * ch);
    const wsp = 0.9;
    s.speedV += (wsp * wsp * (speedGoal - s.speed) - 2 * wsp * s.speedV) * dt;
    s.speed += s.speedV * dt;
    s.camZ += dt * Math.max(0.15, s.speed);
    if (s.camZ > 8 * SNM_Z_PERIOD) {
      // the lattice, path, chambers and breathing all repeat with this period
      s.camZ -= 4 * SNM_Z_PERIOD;
      for (const p of pulses) p.src = [p.src[0], p.src[1], p.src[2] - 4 * SNM_Z_PERIOD];
      s.lastPos = null;
    }
    s.J += dt * (0.8 + 0.3 * s.drive - 0.2 * s.calm);
    const J = s.J;
    const zc = s.camZ;
    const { n: chamberIndex, radii } = snmChamber(zc);
    const tau = 0.032 * Math.sin(s.twistPhase);
    // lateral drift: a few hundredths of a cell in the corridor, up to 40% of a chamber's radius
    // (the chamber's own phase only enters with its weight, so passing from one chamber's span into
    // the next never moves the camera)
    // the drift weight is a C2 ramp over the chamber's whole half-length: at most 0.32 of the
    // radius where the chamber is widest, and zero where it narrows into the corridor
    const { zc: chamberZ } = snmChamber(zc);
    const dw = smoother01(1 - Math.abs(zc - chamberZ) / radii[2]);
    const corridorDrift = 0.09 * (1 - dw);
    const chamberDrift = 0.32 * Math.min(radii[0], radii[1]) * dw;
    const off = [
      corridorDrift * Math.sin(J * 0.23) + chamberDrift * Math.sin(J * 0.11 + chamberIndex),
      corridorDrift * 0.75 * Math.sin(J * 0.17 + 1.1) + chamberDrift * 0.75 * Math.sin(J * 0.09 + 1.1 + chamberIndex * 2)
    ];
    const [px, py] = snmPath(zc);
    const pos = [px + off[0], py + off[1], zc];
    s.clearance = -snmVoid(pos);
    s.minClearance = Math.min(s.minClearance, s.clearance);

    // look along the corridor ahead, as it appears through the twist
    const look = 3.2 + 2.5 * ch;
    const za = zc + look;
    const [ax, ay] = snmPath(za);
    const [tx, ty] = rot2(-tau * look, ax - pos[0], ay - pos[1]);
    let fwdGoal = norm3([tx, ty, look]);
    // exploration: gentle sway in the corridor; in chambers, turn to take in the walls
    const worldUp = [0, 1, 0];
    const yaw = 0.1 * Math.sin(J * 0.051) + ch * 0.38 * Math.sin(J * 0.083 + chamberIndex * 1.7);
    const pitch = 0.07 * Math.sin(J * 0.037 + 0.5) + ch * 0.18 * Math.sin(J * 0.061 + chamberIndex);
    fwdGoal = rotateAbout(fwdGoal, worldUp, yaw);
    fwdGoal = rotateAbout(fwdGoal, norm3(cross(worldUp, fwdGoal)), -pitch);
    const roll = 0.12 * Math.sin(J * 0.021 + 0.4) + 0.12 * ch * Math.sin(J * 0.047) + 0.08 * s.calm * Math.sin(J * 0.031);
    const upGoal = [Math.sin(roll), Math.cos(roll), 0];
    s.fwd = norm3(s.fwd.map((v, i) => follow(v, fwdGoal[i], dt, 0.9, 0.9)));
    s.up = norm3(s.up.map((v, i) => follow(v, upGoal[i], dt, 0.8, 0.8)));
    const fwd = s.fwd;
    const right = norm3(cross(s.up, fwd));
    const up = cross(fwd, right);
    s.tanHalf = follow(s.tanHalf, 0.66 + 0.14 * ch + 0.04 * s.calm, dt, 1.5, 1.5);
    // the air clears as a chamber comes into view, so its far walls are already there on arrival
    const chAhead = Math.max(ch, 0.9 * snmChamberness(zc + 6), 0.8 * snmChamberness(zc + 12), 0.65 * snmChamberness(zc + 18));
    s.fog = follow(s.fog, 0.085 - 0.05 * chAhead - 0.015 * s.calm + 0.01 * s.tension, dt, 1.5, 1.5);
    s.lastPos = pos;

    // ---- uniforms -----------------------------------------------------------------------------------
    const breath = s.bassSlow * (0.5 + 0.5 * s.energy);
    uniforms.snmCam = [...pos, s.tanHalf];
    uniforms.snmBasis = [...right, ...up, ...fwd];
    uniforms.snmShape = [tau, s.warpAmp, s.warpPhase % 6283.185, s.breathPhase % 6283.185];
    const rO = 0.026 * (1.08 - 0.16 * s.diagBias) * (1 + 0.1 * s.energySlow);
    const rD = 0.017 * (0.7 + 0.6 * s.diagBias) * (1 + 0.1 * s.energySlow);
    uniforms.snmForm = [rO, rD, 0.11 * (0.92 + 0.22 * s.energySlow), s.nodeOpen];
    uniforms.snmForm2 = [s.cornerSize, breath, s.awake, s.calm];
    const src = new Array(4 * SNM_PULSE_SLOTS).fill(0), dir = new Array(4 * SNM_PULSE_SLOTS).fill(0), shape = new Array(4 * SNM_PULSE_SLOTS).fill(0);
    pulses.forEach((p, i) => {
      const front = p.speed >= 0 ? p.speed * p.age : Math.max(0, p.start + p.speed * p.age);
      src.splice(i * 4, 4, p.src[0], p.src[1], p.src[2], front);
      dir.splice(i * 4, 4, p.dir[0], p.dir[1], p.dir[2], p.line);
      const fadeIn = clamp(p.age / 0.05);
      const amp = p.strength * fadeIn * Math.exp(-p.age / (p.life * (0.55 + 0.25 * p.line))) * (0.55 + 0.45 * Math.max(s.energy, p.line * 0.8));
      shape.splice(i * 4, 4, amp, p.width, p.wake, p.range);
    });
    uniforms.snmPulseSrc = src; uniforms.snmPulseDir = dir; uniforms.snmPulseShape = shape;
    const pal = paletteAt(s.palPos);
    uniforms.snmColA = [...pal[0], s.fog];
    uniforms.snmColB = [...pal[1], s.packetPhase % 1000];
    uniforms.snmColC = [...pal[2], 0.35 + 0.5 * s.midsSlow];
    uniforms.snmColD = [...pal[3], s.film % 1000];
    uniforms.snmLight = [0.95 + 0.2 * s.energy + 0.12 * s.calm + 0.3 * s.flash, s.shimmer, s.flash, s.energy];
    uniforms.snmClock = [s.sparkClock % 1000, s.beat % 1024, ch, s.tension];
    s.camera = { pos, fwd, chamberness: ch, clearance: s.clearance, tau, chamber: chamberIndex };
    return s;
  }

  function spawnSignal(pos, fwd, right, up, strength) {
    const side = (rand() - 0.5) * 3.2, rise = (rand() - 0.5) * 2.6, ahead = 2 + rand() * 3;
    const d = LINE_DIRS[Math.floor(rand() * LINE_DIRS.length)];
    const sign = rand() < 0.5 ? -1 : 1;
    spawn("signal", strength, nodeNear(pos, fwd, right, up, ahead, side, rise), { dir: scale3(d, sign) });
    s.signals += 1;
  }

  return { state: s, step, uniforms: () => uniforms, pulses };
}

const cache = new WeakMap();

export function bindSpinNetworkMatrixDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime) { runtime = { director: createSpinNetworkMatrixDirector(), lastTime: -1 }; cache.set(gl, runtime); }
  const director = opts.director || runtime.director;
  // a frame drawn twice at the same time (transition, re-render) reuses the state
  if (time !== runtime.lastTime || opts.director) { director.step(time, input); runtime.lastTime = time; }
  const loc = (name) => uniformLocation(gl, program, name);
  const dirLoc = loc("snmDir");
  if (dirLoc) gl.uniform1f(dirLoc, 1);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (!l) continue;
    if (value.length === 9) gl.uniformMatrix3fv(l, false, value);
    else if (value.length === 4) gl.uniform4f(l, value[0], value[1], value[2], value[3]);
    else gl.uniform4fv(l, value);
  }
  return director;
}
