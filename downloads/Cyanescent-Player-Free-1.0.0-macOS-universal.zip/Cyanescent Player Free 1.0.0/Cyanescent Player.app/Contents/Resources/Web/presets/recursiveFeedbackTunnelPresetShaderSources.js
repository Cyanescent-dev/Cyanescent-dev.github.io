export function createRecursiveFeedbackTunnelPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const source = `${modularShaderPrelude}
${modularTransitionShaderBlock}

// -------------------------------------------------------------------------
// Preset 163: Recursive Feedback Tunnel
// Inspired by classic MilkDrop iterative warp shaders
// -------------------------------------------------------------------------

mat2 rot2(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash11(float p) {
    p = fract(p * .1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float myNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n = i.x + i.y * 57.0;
    return mix(mix(hash11(n + 0.0), hash11(n + 1.0), f.x),
               mix(hash11(n + 57.0), hash11(n + 58.0), f.x), f.y);
}

float fbm(vec2 p) {
    float f = 0.0;
    float amp = 0.5;
    for(int i = 0; i < 4; i++){
        f += amp * myNoise(p);
        p *= 2.0;
        amp *= 0.5;
    }
    return f;
}

void main() {
    vec2 uv = vUv * 2.0 - 1.0;
    uv.x *= resolution.x / max(resolution.y, 1.0);
    
    // Simulate smoothed running variables from MilkDrop
    float slowTime = time * 0.2;
    float var1 = sin(slowTime * 1.1) * 0.5 + 0.5;
    
    vec2 p = uv;
    vec3 col = vec3(0.0);
    
    // Iterative Space Folding (Simulating feedback recursion)
    for(int i = 0; i < 8; i++) {
        // Milkdrop 'zoom' and 'rot' per frame
        float z = 1.1 - bass * 0.15;
        p *= z;
        p *= rot2(time * 0.15 + var1 * 0.5);
        
        // Milkdrop 'warp' distortion
        float n = fbm(p * 2.0 + time * 0.5);
        p += vec2(sin(n * 6.28), cos(n * 6.28)) * (0.05 + mids * 0.1);
        
        // Domain repetition to create tunnel rings
        float r = length(p);
        
        // Draw shapes in folded space
        float ring = abs(fract(r * 2.0 - time * 2.0) - 0.5);
        float ringGlow = 0.015 / max(ring, 0.001);
        
        // Color cycling
        vec3 cycleCol = 0.5 + 0.5 * cos(time + float(i) * 0.4 + vec3(0, 2, 4));
        
        // Accumulate with decay
        col += cycleCol * ringGlow * exp(-float(i) * 0.5) * (1.0 + highs * 2.0);
    }
    
    // Vignette
    col *= 1.0 - length(uv) * 0.5;
    
    // Tone mapping
    outColor = vec4(col / (1.0 + col * 0.5), 1.0);
    
    // Transitions
    outColor.rgb += transitionTunnel(uv);
    outColor.rgb *= transitionIdentityPresence();
}
`;
  return [[163, { name: "Recursive Feedback Tunnel", source }]];
}
