export function createAbyssalLaceOrganismPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const fragmentSource = `${modularShaderPrelude}
${modularTransitionShaderBlock}

// Abyssal Lace Organism - Corrected
// A living deep-sea basket star fractal using curved domain-warped KIFS

float basketStarLace(vec2 p, float r, float armId) {
    float glow = 0.0;
    vec2 cp = p;
    
    // Core offset (breathing with bass)
    cp.y -= 0.05 + bass * 0.04;
    
    float scale = 1.0;
    
    // Tracking accumulated fractal distance for signal propagation
    float accumDist = r; 
    
    // Unfurling mechanics driven by mids
    float baseAngle = 0.35 + mids * 0.45;
    
    for (int i = 0; i < 7; i++) {
        float fi = float(i);
        float len = 0.28; 
        
        // Curved Domain Warping
        // Apply curvature that varies slowly over time, making arms bend naturally
        float curvature = 1.2 * sin(time * 0.35 + armId * 0.6 + fi * 0.5);
        vec2 warpedCp = cp;
        warpedCp.x += warpedCp.y * warpedCp.y * curvature;
        
        // Distance to straight line segment in warped space (creates an arc in real space)
        vec2 ba = vec2(0.0, len);
        float h = clamp(dot(warpedCp, ba)/dot(ba, ba), 0.0, 1.0);
        float distToSeg = length(warpedCp - ba * h);
        
        // Magical Signal Propagation
        // Calculate exact distance along the fractal branch
        float currentTotalDist = accumDist + (h * len) / scale;
        float kickWave = fract(currentTotalDist * 4.0 - time * 2.5);
        
        // Sharp leading edge with a glowing trail
        float kickPulse = smoothstep(0.6, 0.95, kickWave) * (1.0 - smoothstep(0.95, 1.0, kickWave)) * kick * 4.0;
        kickPulse += smoothstep(0.0, 0.6, kickWave) * kick * 0.5;
        
        // Structural geometry
        float structuralThickness = 0.006 / scale;
        float structure = smoothstep(structuralThickness, 0.0, distToSeg);
        
        // Luminous filaments on the outer lace edges (high iterations)
        float freqMod = mix(0.05, highs * 3.5, fi / 6.0);
        float filamentGlow = exp(-distToSeg * (30.0 * scale - freqMod * 15.0));
        
        // Tiny electric micro-flicker on the finest branchlets
        float shimmer = 0.0;
        if (fi > 3.0) {
            float hash = fract(sin(dot(cp, vec2(12.9898, 78.233)) + time * 5.0 + fi) * 43758.5453);
            shimmer = smoothstep(0.85, 1.0, hash) * highs * 3.0;
        }
        
        // Motion hierarchy: Mids control active network, kick sends energy pulses
        float branchActivity = 1.0 + kickPulse + mids * 0.25;
        
        glow += (structure * 0.7 + filamentGlow * 0.8 * (1.0 + shimmer)) * branchActivity / scale;
        
        // Setup coordinate system for next recursive branch
        accumDist += len / scale;
        
        // Move origin perfectly to the end of the curved arc
        cp.y -= len;
        cp.x += len * len * curvature; 
        
        // Rotate so the local Y-axis aligns perfectly with the tip's tangent
        float tipTangentAngle = atan(-2.0 * len * curvature);
        cp *= rot(tipTangentAngle);
        
        // Symmetrical fold (creates the fractal split)
        cp.x = abs(cp.x);
        
        // Add organic wiggle to the curl
        float wiggle = sin(time * 1.2 - fi * 1.5 + armId) * 0.15 * (0.5 + mids);
        cp *= rot(baseAngle + wiggle);
        
        // Scale down geometry (by scaling up coordinates)
        float s = 1.42;
        cp *= s;
        scale *= s;
    }
    
    return glow;
}

void main() {
  vec2 uv = gl_FragCoord.xy / resolution.xy;
  vec2 p = (gl_FragCoord.xy * 2.0 - resolution.xy) / min(resolution.x, resolution.y);
  
  float r = length(p);
  
  // Abyssal Background
  vec3 env = vec3(0.001, 0.003, 0.006);
  
  // Subtle deep sea drifting snow
  vec2 driftUV = p + vec2(time * 0.015, time * 0.02);
  float snowHash = fract(sin(dot(floor(driftUV * 40.0), vec2(12.9898, 78.233))) * 43758.5453);
  float snow = smoothstep(0.994, 1.0, snowHash) * (0.2 + highs * 0.6);
  env += vec3(0.1, 0.5, 0.8) * snow;
  
  // Slow rotation for the entire organism
  vec2 op = p * rot(time * -0.04);
  
  // Evaluate the continuous curved fractal lace for all 5 arms independently
  // This completely eliminates sector clipping and tearing.
  float laceGlow = 0.0;
  for (int j = 0; j < 5; j++) {
      float jf = float(j);
      float angle = jf * (PI * 2.0 / 5.0);
      vec2 armP = op * rot(angle);
      // Use max to blend arms naturally where they cross over each other
      laceGlow = max(laceGlow, basketStarLace(armP, r, jf));
  }
  
  // Enhanced Central Core
  float coreDist = r;
  float corePulse = 1.0 + bass * 0.4 + kick * 0.5;
  float coreDense = exp(-coreDist * 50.0 / corePulse);
  float coreAura = exp(-coreDist * 12.0 / corePulse) * 0.6;
  
  // Elegant Deep-Sea Color Palette
  vec3 laceColor = palette60s(0.55 + time * 0.02 - r * 0.12);
  
  vec3 color = env;
  color += laceColor * laceGlow * (1.1 + energyTrend * 0.5);
  color += vec3(0.9, 0.95, 1.0) * coreDense * (1.0 + kick * 1.5);
  color += vec3(0.1, 0.4, 0.9) * coreAura * (1.0 + bass);
  
  // Deep sea vignette
  color *= smoothstep(1.8, 0.4, r);
  
  // Standard preset lifecycle hooks
  float identityPresence = transitionIdentityPresence();
  color *= identityPresence;
  
  // Frame feedback for smooth luminous trails
  vec3 prev = samplePreviousFrame(uv, p, feedbackRetain(0.85));
  color = prev * 0.35 + color;
  
  color += transitionTunnel(p);
  color = color / (1.0 + color * 0.4);
  color = pow(color, vec3(0.9)); // Abyssal presentation
  
  outColor = vec4(color, 1.0);
}
`;

  return [[98, {
    name: "Abyssal Lace Organism",
    source: fragmentSource
  }]];
}
