export function createSerpentSkyPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const serpentSkyFragmentSource = `${modularShaderPrelude}
  ${modularTransitionShaderBlock}
  
  // ═══════════════════════════════════════════════════════
  // SERPENT OF THE INFINITE SKY — Quetzalcoatl Cosmic Serpent
  // ═══════════════════════════════════════════════════════
  
  float hash3_q(vec3 p) {
    p = fract(p * vec3(443.8975, 397.2973, 491.1871));
    p += dot(p, p.yxz + 19.19);
    return fract(p.x * p.y * p.z);
  }
  
  float noise3_q(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(mix(hash3_q(i), hash3_q(i + vec3(1, 0, 0)), f.x),
          mix(hash3_q(i + vec3(0, 1, 0)), hash3_q(i + vec3(1, 1, 0)), f.x), f.y),
      mix(mix(hash3_q(i + vec3(0, 0, 1)), hash3_q(i + vec3(1, 0, 1)), f.x),
          mix(hash3_q(i + vec3(0, 1, 1)), hash3_q(i + vec3(1, 1, 1)), f.x), f.y),
      f.z
    );
  }
  
  float smin_q(float a, float b, float k) {
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
  }
  
  vec3 serpentPalette(float t) {
    t = fract(t);
    vec3 emerald = vec3(0.0, 0.8, 0.4);
    vec3 gold = vec3(1.0, 0.72, 0.15);
    vec3 magenta = vec3(0.82, 0.04, 0.56);
    vec3 cyan = vec3(0.0, 0.82, 0.9);
    vec3 c = emerald;
    c = mix(c, gold, smoothstep(0.0, 0.25, t));
    c = mix(c, magenta, smoothstep(0.25, 0.50, t));
    c = mix(c, cyan, smoothstep(0.50, 0.75, t));
    c = mix(c, emerald, smoothstep(0.75, 1.0, t));
    return c;
  }
  
  // Serpent of the Infinite Sky SDF
  float serpentMap(vec3 p, float bassVal, float midsVal, float kickVal, float levelVal, float dropVal, out float featherTrap) {
    // Cylindrical coordinate mapping centered on Y axis
    float theta = atan(p.z, p.x);
    float r = length(p.xz);
    
    float helixRadius = 0.65 + 0.1 * sin(p.y * 1.5 + time * 0.15);
    float pitch = 1.35;
    
    // Y-axis path repeating to coil infinitely
    float spiralY = p.y - theta * (pitch / (2.0 * PI));
    spiralY = mod(spiralY + pitch * 0.5, pitch) - pitch * 0.5;
    
    // 1. Serpent Head & Flattening: Add a viper-like head once per helical turn
    float headRange = smoothstep(0.82, 0.98, sin(theta + time * 0.1));
    
    // Wave propagation along body
    float wave = sin(theta * 6.5 - beatPhase * PI * 2.0) * 0.05 * kickVal;
    float segmentRadius = mix(0.12, 0.24, bassVal) * mix(1.0, 1.85, headRange) + wave;
    
    // Flatten coordinates for the head
    vec2 q = vec2(r - helixRadius, spiralY * mix(1.0, 2.2, headRange));
    
    // Clean shingle scale pattern on the belly/sides
    float scales = cos(theta * 18.0) * cos(spiralY * 24.0) * 0.012;
    float dBody = length(q) - (segmentRadius - scales * (1.0 - headRange));
    
    // 2. Recursive Feathers coordinate folding (restricted to outer back ridge: q.x > -0.05)
    vec2 featherQ = q;
    featherQ *= rot(theta * 1.2 + time * 0.08);
    
    float scale = 1.0;
    float trap = 1e5;
    int iter = int(mix(3.0, 5.0, midsVal));
    
    for (int i = 0; i < 4; i++) {
      if (i >= iter) break;
      featherQ = abs(featherQ) - vec2(0.045 + 0.025 * midsVal);
      float s = 1.6 + midsVal * 0.4;
      featherQ *= s;
      scale *= s;
      featherQ *= rot(0.58 + midsVal * 0.38);
      trap = min(trap, length(featherQ));
    }
    
    featherTrap = trap;
    float dFeathers = (length(featherQ) - 0.007 * (1.0 + midsVal * 0.5)) / scale;
    
    // Restrict feathers to the back ridge of the serpent body (away from center)
    float featherBlend = smoothstep(-0.06, 0.06, q.x);
    float dSerpent = mix(dBody, smin_q(dBody, dFeathers, 0.015), featherBlend);
    
    // 3. Drop Event Dissolve (into thousands of birds/feathers)
    if (dropVal > 0.05) {
      float disperseNoise = noise3_q(p * 7.5 + time * 2.5) * 0.5 + noise3_q(p * 15.0 - time * 1.5) * 0.25;
      dSerpent += disperseNoise * dropVal * 0.48;
    }
    
    return dSerpent;
  }
  
  float serpentMapSDF(vec3 p, float bassVal, float midsVal, float kickVal, float levelVal, float dropVal) {
    float dummy;
    return serpentMap(p, bassVal, midsVal, kickVal, levelVal, dropVal, dummy);
  }
  
  vec3 getSerpentNormal(vec3 p, float bassVal, float midsVal, float kickVal, float levelVal, float dropVal) {
    vec2 e = vec2(0.003, 0.0);
    return normalize(vec3(
      serpentMapSDF(p + e.xyy, bassVal, midsVal, kickVal, levelVal, dropVal) - serpentMapSDF(p - e.xyy, bassVal, midsVal, kickVal, levelVal, dropVal),
      serpentMapSDF(p + e.yxy, bassVal, midsVal, kickVal, levelVal, dropVal) - serpentMapSDF(p - e.yxy, bassVal, midsVal, kickVal, levelVal, dropVal),
      serpentMapSDF(p + e.yyx, bassVal, midsVal, kickVal, levelVal, dropVal) - serpentMapSDF(p - e.yyx, bassVal, midsVal, kickVal, levelVal, dropVal)
    ));
  }
  
  // Feedback UV for Serpent of the Infinite Sky
  vec2 serpentFeedbackUv(vec2 uv, vec2 p) {
    vec2 q = p;
    q *= rot(0.001 * feedbackStep * sin(time * 0.2));
    q *= feedbackZoom(0.996 - kick * 0.0012);
    return clamp(q * 0.5 + 0.5, vec2(0.001), vec2(0.999));
  }
  
  vec3 drawFluidScaleMatrix(vec2 p, float bassVal, float midsVal, float highsVal) {
    vec2 q = p;
    q.x += sin(q.y * 5.0 - time * 2.0) * 0.05 * bassVal;
    q.y -= time * 0.4;
    float scaleSize = 10.0;
    vec2 grid1 = q * scaleSize;
    vec2 grid2 = grid1 + vec2(0.5);
    vec2 f1 = fract(grid1) * 2.0 - 1.0;
    vec2 f2 = fract(grid2) * 2.0 - 1.0;
    float d1 = length(f1);
    float d2 = length(f2);
    
    float d = min(d1, d2);
    vec2 id = (d1 < d2) ? floor(grid1) : floor(grid2);
    
    float pattern = sin(id.x * 0.3 + id.y * 0.4 + time * 0.5 + midsVal * 2.0);
    vec3 col = serpentPalette(pattern * 0.5 + 0.5);
    
    float alpha = smoothstep(1.0, 0.7, d);
    float highlight = smoothstep(0.6, 0.0, d) * highsVal * 1.5;
    
    return col * alpha * (0.2 + highlight);
  }
  
  void main() {
    vec2 uv = gl_FragCoord.xy / resolution;
    vec2 p = (gl_FragCoord.xy * 2.0 - resolution) / min(resolution.x, resolution.y);
    
    vec2 fuv = serpentFeedbackUv(uv, p);
    float transitionStrength = sin(clamp(transitionPhase, 0.0, 1.0) * PI);
    float identityPresence = transitionIdentityPresence();
    
    // Fractal memory frame loop
    float decay = mix(0.91, 0.95, level * 0.05);
    vec3 prev = samplePreviousFrame(fuv, p, feedbackRetain(mix(decay, 0.82, transitionStrength)));
    
    // ═══ CAMERA: Rising vertical orbit closer to coiling serpent to frame it immediately ═══
    float camT = time * 0.05;
    vec3 ro = vec3(
      sin(camT) * 1.6, // Camera brought closer (from 2.0 to 1.6) for immediate subject visibility
      camT * 1.6,
      cos(camT) * 1.6
    );
    vec3 ta = vec3(0.0, ro.y + 0.25, 0.0);
    
    vec3 ww = normalize(ta - ro);
    vec3 uu = normalize(cross(ww, vec3(0.0, 1.0, 0.0)));
    vec3 vv = normalize(cross(uu, ww));
    vec3 rd = normalize(p.x * uu + p.y * vv + 1.25 * ww);
    
    // Ray march serpent (Level 1: glimpses, Level 3: emerging, Level 5: full reveal)
    float t = 0.0;
    float tMax = mix(4.0, 10.0, clamp(level * 0.25, 0.0, 1.0));
    float featherTrap = 0.0;
    int steps = 0;
    bool hit = false;
    
    for (int i = 0; i < 48; i++) {
      vec3 pos = ro + rd * t;
      float d = serpentMap(pos, bass, mids, kick, level, dropState, featherTrap);
      if (d < 0.001) {
        hit = true;
        steps = i;
        break;
      }
      if (t > tMax) break;
      t += d;
    }
    
    vec3 sceneColor = vec3(0.0);
    
    // Cosmic Nebula Background (Deep space atmosphere) + Fluid Scale Matrix
    vec3 bgCol = mix(vec3(0.01, 0.005, 0.02), vec3(0.0, 0.015, 0.035), rd.y * 0.5 + 0.5);
    float nebula = noise3_q(rd * 2.8 + vec3(time * 0.02, time * 0.015, time * 0.01));
    bgCol += mix(vec3(0.04, 0.0, 0.05), vec3(0.0, 0.06, 0.08), sin(time * 0.05) * 0.5 + 0.5) * nebula * 0.65;
    
    vec3 matrixCol = drawFluidScaleMatrix(p, bass, mids, highs);
    bgCol += matrixCol;
    
    if (hit) {
      vec3 pos = ro + rd * t;
      vec3 n = getSerpentNormal(pos, bass, mids, kick, level, dropState);
      
      // Light from sun
      vec3 sunDir = normalize(vec3(0.3, 0.8, -0.4));
      float dif = clamp(dot(n, sunDir), 0.0, 1.0);
      float rim = pow(1.0 - max(dot(n, -rd), 0.0), 3.0);
      float ao = 1.0 - float(steps) / 48.0;
      
      // Base colors from palette
      vec3 baseCol = serpentPalette(featherTrap * 1.5 + pos.y * 0.1 + time * 0.03);
      
      // Emissive shine on feathers
      float specular = pow(max(dot(reflect(-sunDir, n), -rd), 0.0), 8.0) * 0.45;
      
      sceneColor = baseCol * (dif * 0.6 + 0.15) * ao;
      sceneColor += serpentPalette(featherTrap * 2.0 - time * 0.05) * rim * 0.8;
      sceneColor += vec3(0.0, 0.9, 1.0) * specular * (1.0 + kick * 1.2);
      
      // Depth fog blend
      float fog = 1.0 - exp(-t * 0.22);
      sceneColor = mix(sceneColor, bgCol, fog * 0.7);
    } else {
      sceneColor = bgCol;
    }
    
    // ═══ HIGH FREQUENCY: Spawning Glowing Birds & Particles ═══
    float sparks = 0.0;
    int numBirds = int(mix(2.0, 8.0, clamp(level * 0.25 + highs * 0.5, 0.0, 1.0)));
    for (int i = 0; i < 8; i++) {
      if (i >= numBirds) break;
      float fi = float(i);
      // Birds spiral up around Y axis
      float sPhase = time * (1.1 + fi * 0.2) + fi * 6.28;
      float sRadius = 0.8 + 0.3 * sin(sPhase * 0.5);
      vec3 sparkPos = vec3(
        sin(sPhase) * sRadius,
        ro.y - 0.5 + fract(time * 0.05 + fi * 0.125) * 3.0,
        cos(sPhase) * sRadius
      );
      
      float dist = length(ro + rd * clamp(-dot(ro - sparkPos, rd), 0.0, 7.0) - sparkPos);
      
      // Flapping wings simulation
      float flap = sin(time * 16.0 + fi * 2.0) * 0.02;
      dist += abs(flap);
      
      float sparkle = sin(time * 5.0 + fi * 1.5) * 0.5 + 0.5;
      sparks += exp(-dist * dist * mix(75.0, 30.0, highs)) * (0.2 + sparkle * 0.8) * (0.2 + highs * 0.8);
    }
    vec3 birdColor = mix(vec3(0.0, 0.85, 0.92), vec3(0.85, 0.05, 0.55), sin(time * 0.2) * 0.5 + 0.5);
    sceneColor += birdColor * sparks * 1.1;
    
    // Bloom highlights
    float lum = dot(sceneColor, vec3(0.2126, 0.7152, 0.0722));
    sceneColor += sceneColor * smoothstep(0.4, 1.1, lum) * 0.35;
    
    vec3 finalColor = prev + sceneColor * identityPresence;
    
    // Vignette
    float r = length(p);
    float vignette = 1.0 - smoothstep(1.15, 1.80, r);
    finalColor *= vignette;
    
    // Tone mapping and gamma
    finalColor = finalColor / (1.0 + finalColor * 0.36);
    finalColor = pow(finalColor, vec3(0.95));
    
    outColor = vec4(finalColor, 1.0);
  }
  `;

  return [[59, { name: "Serpent of the Infinite Sky", source: serpentSkyFragmentSource }]];
}
