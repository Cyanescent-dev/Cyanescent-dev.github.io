// Chaotic Butterfly Tunnels (preset 94), The Living Butterfly: the director.
//
// The tunnel is one enormous living butterfly: a chain of giant wing pairs (forewing and hindwing,
// left and right, hinged on the creature's spine) that the camera flies through, with the
// original's rings of small butterflies, free swarm, hero butterflies, Lorenz journey and feedback
// atmosphere around them. The shader draws it; this file (pure JS, no GL, so it can be tested)
// decides how it moves and lights up. Large things respond slowly and small things quickly:
//   wingbeat   one continuous, integrated phase (psi) for the whole creature: a shaped stroke
//              (fast opening from the roots, a suspended extension, a slower recovery): one stroke
//              per two bars in full flight, four in between, eight in a deep breakdown, phase-locked
//              to the beat grid (the opening on the grid), depth with
//              the section and the slow bass, posture with the phrase. A wave constant (kappa)
//              spreads the stroke along the tunnel: it travels away in calm, towards the viewer in
//              builds, and alternates in long drives. The shader adds root-to-tip lag (membrane
//              flexibility), a small left/right asymmetry, and a single coherent membrane ripple
//   breath     before a drop the wings fold in, the stroke slows and stills, tremors appear at the
//              tips and light gathers along the veins; the camera and the swarm slow down. With a
//              Drop Map (analysed track) it is a function of the time to the next drop; without one
//              it comes from the build that is actually happening, never a guessed drop
//   unfurling  the drop: the wings sweep open from the roots, the tips following, the movement
//              travelling down the tunnel, light racing along the veins, the swarm surging and the
//              camera accelerating, then the stroke settles back into flight. Strength follows the
//              drop (major or minor) and what led up to it; the style alternates drop by drop.
//              With a Drop Map its clock is the map's time since the drop (seek-proof)
//   light      kicks light one wing's veins with a front from the root (alternating wings), hats
//              sparkle the margin spots, builds send bands of light along the tunnel, breakdowns
//              drift the palette
//   travel     forward speed on a critically damped spring (never a jolt); the Lorenz camera,
//              swarm, heroes and streaks run on integrated journey clocks. The camera never reads
//              instantaneous kick or bass values (the original added kickPulse to its position)
// Everything advances in fixed substeps of real time, so 30 and 60 fps give the same motion, and
// offline export replays it deterministically from the preset's start (prepareChaoticButterflyOffline).
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";
import { createOfflineAnimationClock } from "../engine/offlineAnimationClock.js";

export const CHAOTIC_BUTTERFLY_PRESET_ID = 94;
const TAU = Math.PI * 2;
const SUBSTEP = 1 / 120;
const PHASE_WRAP = TAU * 256;          // phases are only used in sin/cos: wrap on whole turns
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth01 = (x) => { const t = clamp(x); return t * t * (3 - 2 * t); };
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const wrapPi = (x) => x - TAU * Math.floor((x + Math.PI) / TAU);
// Critically damped spring towards goal: unlike a first-order follower its velocity never jumps
// when the goal does (a phrase or eight-bar change), so nothing it drives changes speed abruptly.
function spring(s, key, goal, w, h) {
  const v = key + "V";
  s[v] += (w * w * (goal - s[key]) - 2 * w * s[v]) * h;
  s[key] += s[v] * h;
}

export const CBT_TIMING = Object.freeze({
  breathMajor: 8.5,      // s before a major drop that the wings start folding in
  breathMinor: 5.5,      // s before a minor one
  unfurlLife: 9,         // s after a drop that the unfurling is still settling
  liveDropCooldown: 20   // s between drops detected without a Drop Map
});

export function createChaoticButterflyDirector() {
  const audioModel = createNewtonAudioModel();
  const s = {};
  const uniforms = {};

  function reset() {
    audioModel.reset();
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0, beat: 0, beatSource: "clock",
      energy: 0.3, calm: 0, drive: 0, flight: 0, gather: 0, tension: 0, bass: 0, bassSlow: 0, mids: 0.3, midsSlow: 0.3,
      shimmer: 0, hatSpark: 0, calmSeen: 0, buildHold: 0,
      F: 0, Fgoal: 0, Flatch: 0, breathPre: 0,
      psi: 0, corr: 0, rate: 0.125, lockBars: 4, wake: 0, A: 0.4, P: 0.62, flex: 0.6, kappa: 0.55, kappaV: 0, asym: 0.16, tremor: 0, tremorPhase: 0, evolve: 0, evolveV: 0,
      unfurlTau: 99, unfurlStrength: 0, unfurlStyle: 0, unfurlGate: 1, drops: 0, minorDrops: 0,
      prevAge: null, liveDropAt: -1e9, liveDropStrength: 0, mapKnown: false, gatherPre: 0, U: 0,
      v: 0.12, vV: 0, D: 0, J: 0, bank: 0,
      swarmTravel: 0, activity: 0.3, flapPhase: 0, orbitPhase: 0, surge: 0,
      kickAge: 9, kickStrength: 0, kickSide: 0, kicks: 0,
      buildWave: 0, buildWaveAmp: 0, hue: 0, feedDecay: 0.88, feedZoom: 0.993, feedRot: 0.004
    });
  }
  reset();

  // The unfurling's shape over its own clock (shared with the shader's per-slice evaluation):
  // 0 before, sweeping open over ~1.1 s with a small overshoot, released over 2.2-6.5 s.
  function unfurlWeight(tau) {
    if (!(tau >= 0)) return 0;
    return smooth01(tau / 1.1) * (1 - smooth01((tau - 2.2) / 4.3));
  }

  function advance(dt, input = {}) {
    dt = clamp(dt, 0, 0.25);
    const { audio = {}, smooth = {}, music = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    s.beat = a.beat; s.beatSource = a.beatSource;

    // ---- section envelopes (slew-limited; nothing below reaches the wings raw) ----------------
    const energyGoal = clamp(0.58 * clamp(audio.globalEnergy ?? a.energy) + 0.42 * clamp(music.highEnergy));
    s.energy = follow(s.energy, energyGoal, dt, 0.8, 2.0);
    s.calm = follow(s.calm, clamp((a.breakdown - 0.35) / 0.45) * (1 - a.groove * 0.7) * (1 - 0.55 * clamp(Math.max(a.build, clamp(music.buildUp)) * 1.6)), dt, 1.4, 1.8);
    s.drive = follow(s.drive, clamp(a.groove * (0.5 + 0.5 * s.energy)), dt, 0.8, 1.6);
    // full flight takes a while to earn and lets go a little faster
    s.flight = follow(s.flight, clamp(s.drive * (1 - s.calm) * (0.55 + 0.45 * s.energy)), dt, 5.0, 2.2);
    const forecast = clamp(Math.max(clamp(music.upcomingDrop) * 1.2, a.build));
    s.tension = follow(s.tension, forecast * (1 - s.calm * 0.5), dt, 0.8, 1.2);
    s.bass = follow(s.bass, clamp(Math.max(a.bassDrive, a.subDrive)), dt, 0.12, 0.55);
    s.bassSlow = follow(s.bassSlow, s.bass, dt, 1.6, 2.4);
    s.mids = follow(s.mids, a.midDrive, dt, 0.25, 0.9);
    s.midsSlow = follow(s.midsSlow, s.mids, dt, 2.5, 3.0);
    s.shimmer = follow(s.shimmer, clamp(0.25 * clamp(smooth.highs) + 0.65 * a.highDrive * (0.4 + 0.6 * s.energy)), dt, 0.08, 0.35);
    s.calmSeen = Math.max(s.calm, s.calmSeen * Math.exp(-dt / 20));
    s.buildHold = s.tension > 0.6 ? s.buildHold + dt : s.buildHold * Math.exp(-dt / 8);

    // ---- the drop: Drop Map (seek-proof clock) or the live detector ---------------------------
    const known = Number(music.dropKnown) > 0.5;
    s.mapKnown = known;
    const qualify = (major) => major
      ? clamp(0.72 + 0.28 * Math.max(clamp(s.calmSeen * 2.5), clamp(s.buildHold / 8)), 0, 1)
      : clamp(0.42 + 0.16 * clamp(s.buildHold / 6), 0, 0.6);
    let tau = 99;
    if (known) {
      const age = clamp(Number(music.dropAge), 0, 64);
      const last = clamp(Number(music.dropLastStrength));
      const expected = s.prevAge === null ? age : s.prevAge + dt;
      const crossed = s.prevAge !== null && age < s.prevAge - 0.2 && age < 0.75 && last > 0;
      const seek = !crossed && Math.abs(age - expected) > 0.35;
      if (crossed) {
        s.drops += 1; if (last < 1) s.minorDrops += 1;
        s.unfurlStrength = qualify(last >= 1);
        s.unfurlStyle = s.drops % 2;
        s.Flatch = Math.max(s.Flatch, s.breathPre);
        s.calmSeen = 0; s.buildHold = 0;
      } else if ((seek || s.prevAge === null) && age < CBT_TIMING.unfurlLife && last > 0) {
        // arrived in the middle of a drop's aftermath (seek, or an export starting there): its
        // unfurling at a default strength, faded in so the wings never jump
        s.unfurlStrength = last >= 1 ? 0.85 : 0.5;
        s.unfurlGate = 0;
      }
      if (seek) s.Flatch = 0;
      s.prevAge = age;
      if (last > 0 && age < CBT_TIMING.unfurlLife) tau = age;
      // the breath: the approach of the next drop
      const next = clamp(Number(music.dropNextStrength));
      const span = next >= 1 ? CBT_TIMING.breathMajor : CBT_TIMING.breathMinor;
      const x = clamp(1 - clamp(Number(music.dropIn), 0, 64) / span);
      s.breathPre = next > 0 ? (next >= 1 ? 1 : 0.55) * Math.pow(smooth01(x), 1.3) : 0;
      // the longer approach (the lead-in) gathers energy: the Gathering
      s.gatherPre = clamp(Number(music.dropLeadIn)) * next;
    } else {
      s.prevAge = null;
      s.gatherPre = 0;
      // no lookahead: anticipation only from a build that is really happening
      s.breathPre = 0.6 * smooth01((s.tension - 0.62) / 0.3) * smooth01(s.buildHold / 2.5);
      if (events.drop && s.time - s.liveDropAt > CBT_TIMING.liveDropCooldown) {
        const earned = s.calmSeen > 0.15 || s.buildHold > 4;
        s.liveDropAt = s.time; s.drops += 1;
        s.unfurlStrength = earned ? qualify(true) : 0.42;
        s.unfurlStyle = s.drops % 2;
        s.Flatch = Math.max(s.Flatch, s.breathPre);
        s.calmSeen = 0; s.buildHold = 0;
      }
      const age = s.time - s.liveDropAt;
      if (age < CBT_TIMING.unfurlLife) tau = age;
    }
    s.unfurlTau = tau;

    // ---- events: kicks light the veins (small and quick), hats the margins --------------------
    for (const w of events.waves) {
      if (w.kind !== "kick") continue;
      s.kicks += 1;
      s.kickAge = 0;
      s.kickSide ^= 1;
      const downbeat = w.beatInBar === 0 ? 1 : 0.7;
      s.kickStrength = w.strength * downbeat * (0.45 + 0.55 * s.drive) * (1 - 0.6 * s.calm) * (1 - 0.75 * s.F);
    }
    if (events.hats) s.hatSpark = Math.max(s.hatSpark, 0.4 + 0.6 * a.highDrive);

    // ---- continuous motion in fixed substeps --------------------------------------------------
    const phrase = Math.floor(s.beat / 32);
    const block = Math.floor(s.beat / 32);   // eight bars
    const steps = Math.max(1, Math.ceil(dt / SUBSTEP - 1e-9));
    const h = dt / steps;
    for (let i = 0; i < steps; i++) {
      s.time += h;
      const tauNow = known ? tau + (i + 1) * h - dt : s.time - s.liveDropAt;
      const U = s.unfurlStrength * unfurlWeight(tauNow) * s.unfurlGate;
      s.unfurlGate = follow(s.unfurlGate, 1, h, 0.6, 0.6);

      // the breath, released through the first half second of the drop
      const Fpost = s.Flatch * (1 - smooth01(tauNow / 0.5));
      if (tauNow > 0.5) s.Flatch = 0;
      s.Fgoal = Math.max(s.breathPre, Fpost);
      s.F = follow(s.F, s.Fgoal, h, 0.25, 0.12);
      const F = s.F;
      s.gather = follow(s.gather, clamp(Math.max(s.tension, 0.8 * (s.gatherPre || 0)) * (1 - 0.4 * s.calm)), h, 1.5, 2.5);

      // wingbeat: one stroke per two bars in full flight, four in between, eight in a deep
      // breakdown (the giant wings are enormous: deliberate, never per bar). The stroke length is
      // chosen with hysteresis, the rate eases to it, and a slewed phase lock keeps the opening
      // on the grid (a two-bar stroke opens on every other downbeat).
      const lively = 0.25 * s.gather + 0.75 * s.flight;
      if (s.lockBars === 2 && lively < 0.5) s.lockBars = 4;
      else if (s.lockBars === 4 && lively > 0.62) s.lockBars = 2;
      else if (s.lockBars === 4 && lively < 0.1 && s.calm > 0.5) s.lockBars = 8;
      else if (s.lockBars === 8 && (lively > 0.2 || s.calm < 0.35)) s.lockBars = 4;
      const rateGoal = (1 / s.lockBars) * (1 - 0.72 * F);
      s.rate = follow(s.rate, rateGoal, h, 3.0, 2.0);
      const omega = TAU * (bps / 4) * s.rate;
      let correction = 0;
      if (s.beatSource === "track") {
        const lock = (1 - F) * (1 - U);
        const err = wrapPi(TAU * s.beat / (4 * s.lockBars) - s.psi);
        correction = lock * clamp(0.45 * err, -0.22, 0.22) * omega;
      }
      // the correction itself is slewed: the lock's error wraps at +-pi and its target switches,
      // which must never change the stroke's speed from one frame to the next
      s.corr = follow(s.corr, correction, h, 0.5, 0.5);
      s.psi = (s.psi + (omega + s.corr) * h) % PHASE_WRAP;

      // depth, posture, flexibility, the travelling wave
      const AGoal = (0.40 + 0.20 * s.gather + 0.32 * s.flight + 0.12 * s.bassSlow * (1 - s.calm)) * (1 - 0.86 * F);
      s.A = follow(s.A, AGoal, h, 1.6, 1.0);
      spring(s, "evolve", 0.07 * (hash(phrase * 1.37 + 4.1) - 0.5) * 2, 0.45, h);
      const PGoal = (0.62 - 0.08 * s.flight + 0.05 * s.calm + s.evolve) * (1 - 0.92 * F);
      s.P = follow(s.P, PGoal, h, 1.4, 1.1);
      s.flex = follow(s.flex, 0.45 + 0.35 * s.midsSlow + 0.2 * s.calm, h, 2, 2);
      const alternate = (((block % 2) + 2) % 2) ? -0.8 : 0.8;
      const kappaGoal = s.calm * 0.55 + s.gather * (1 - s.calm) * -0.9 + (1 - s.calm) * (1 - s.gather) * (s.flight > 0.4 ? alternate : 0.35);
      spring(s, "kappa", kappaGoal, 0.55, h);
      s.tremor = follow(s.tremor, F * (0.55 + 0.45 * s.tension), h, 0.6, 0.3);
      s.tremorPhase = (s.tremorPhase + h * TAU * (6.5 + 2 * F)) % PHASE_WRAP;

      // travel: a critically damped spring on the forward speed
      const surge = s.unfurlStrength * s.unfurlGate * (tauNow >= 0 && tauNow < 12 ? smooth01(tauNow / 0.9) * Math.exp(-Math.max(0, tauNow - 0.9) / 2.6) : 0);
      s.surge = surge;
      const vGoal = (0.12 + 0.18 * s.gather + 0.42 * s.flight) * (1 - 0.75 * F) + 0.55 * surge;
      const wv = 2.0;
      s.vV += (wv * wv * (vGoal - s.v) - 2 * wv * s.vV) * h;
      s.v += s.vV * h;
      s.D += s.v * h;
      s.J += h * (0.55 + 0.45 * s.flight + 0.2 * s.gather - 0.3 * F + 0.5 * s.v);
      s.bank = 0.12 * Math.sin(s.J * 0.23) + 0.05 * s.midsSlow * Math.sin(s.J * 0.51 + 1.3);

      // the swarm: activity, approach and wingbeats on integrated clocks (bounded speeds)
      s.activity = follow(s.activity, clamp((0.25 + 0.25 * s.gather + 0.5 * s.flight) * (1 - 0.6 * F) + 0.6 * surge, 0, 1.4), h, 1.2, 1.6);
      s.swarmTravel = (s.swarmTravel + h * (0.12 + 0.30 * s.activity + 0.5 * s.v)) % 4096;
      s.flapPhase = (s.flapPhase + h * (3.2 + 3.0 * s.activity)) % PHASE_WRAP;
      s.orbitPhase = (s.orbitPhase + h * (0.22 + 0.35 * s.activity)) % PHASE_WRAP;

      // light
      s.kickAge += h;
      s.hatSpark *= Math.exp(-h / 0.14);
      s.buildWave = (s.buildWave + h * (0.25 + 0.9 * s.gather + 0.6 * F)) % 4096;
      s.buildWaveAmp = follow(s.buildWaveAmp, clamp(s.gather * (1 - 0.5 * s.calm) * 0.9 + 0.4 * F), h, 1.0, 1.5);
      s.hue = (s.hue + h * (0.004 + 0.012 * s.calm)) % 64;

      // the feedback atmosphere: slow values only (the original zoomed on every kick)
      s.feedDecay = follow(s.feedDecay, 0.86 + 0.07 * clamp(0.5 * s.energy + 0.2 * s.bassSlow), h, 1.5, 1.5);
      s.feedZoom = 0.994 - 0.002 * clamp(s.v / 0.6) - 0.002 * surge;
      s.feedRot = 0.004 * (1 + 0.5 * s.midsSlow);
      s.U = U;
      s.wake = follow(s.wake, Math.max(U, 0.35 * F), h, 0.25, 1.8);   // dims back over ~2 s after the unfurling
    }

    // ---- uniforms -----------------------------------------------------------------------------
    const slice = Math.floor(s.D / CBT_SPACING);
    uniforms.cbtWingA = [s.psi, s.A, s.P, s.flex];
    uniforms.cbtWingB = [s.kappa, s.asym + 0.08 * Math.sin(s.J * 0.05), s.tremor, s.tremorPhase];
    uniforms.cbtUnfurl = [s.unfurlTau, s.unfurlStrength * s.unfurlGate, s.unfurlStyle, s.surge];
    uniforms.cbtTravel = [slice % 8192, s.D / CBT_SPACING - slice, s.v, s.J % 4096];
    uniforms.cbtLight = [s.kickAge, s.kickStrength, s.kickSide, Math.max(s.shimmer, s.hatSpark)];
    uniforms.cbtGlow = [s.buildWave, s.buildWaveAmp, s.F, s.hue];
    uniforms.cbtMood = [s.calm, s.gather, s.flight, s.wake];
    uniforms.cbtSwarm = [s.swarmTravel, s.activity, s.flapPhase, s.orbitPhase];
    uniforms.cbtCam = [s.J % 4096, s.bank, s.F, s.bassSlow];
    uniforms.cbtFeed = [s.feedDecay, s.feedZoom, s.feedRot, s.midsSlow];
    return s;
  }

  // Live: time is seconds since the preset started (monotonic per activation).
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = time - s.lastTime;
    s.lastTime = time;
    // a long gap (hidden window, stall) is not replayed; the envelopes catch up on their own
    return advance(Math.min(dt, 0.25), input);
  }

  function summary() {
    const r = (x, n = 2) => +Number(x).toFixed(n);
    return { t: r(s.time), calm: r(s.calm), gather: r(s.gather), flight: r(s.flight), F: r(s.F), U: r(s.U || 0),
      tau: r(s.unfurlTau), str: r(s.unfurlStrength), rate: r(s.rate), A: r(s.A), P: r(s.P), kappa: r(s.kappa),
      v: r(s.v), wake: r(s.wake), bars: s.lockBars, beat: r(s.beat, 1), src: s.beatSource, drops: s.drops, kicks: s.kicks, map: s.mapKnown ? 1 : 0 };
  }

  return { state: s, step, advance, reset, summary, uniforms: () => uniforms };
}

// The wing slices are this far apart along the tunnel (world units; the shader's CBT_SPACING).
export const CBT_SPACING = 0.7;

// ---- live and offline runtimes ------------------------------------------------------------------
const live = { director: createChaoticButterflyDirector(), lastTime: -1, loggedAt: -99 };
const offline = { director: createChaoticButterflyDirector(), active: false, clock: null };
offline.clock = createOfflineAnimationClock({
  reset: () => offline.director.reset(),
  step: (dt, inputs) => offline.director.advance(dt, inputs)
});

// Offline export / Studio preview: advance (or replay from the preset's start after a backwards
// seek) to the preset-local time, sampling the source analysis.
// The replay always runs at CBT_OFFLINE_RATE whatever the export frame rate (24, 30 and 60 fps
// frame times all fall on its steps), so exports at different frame rates are identical.
export const CBT_OFFLINE_RATE = 120;
export async function prepareChaoticButterflyOffline(time, options = {}) {
  offline.active = true;
  await offline.clock.advanceAsync(time, { ...options, fps: CBT_OFFLINE_RATE });
}
export function endChaoticButterflyOffline() { offline.active = false; offline.clock.end(); }

export function bindChaoticButterflyDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let director;
  if (opts.director) director = opts.director;
  else if (offline.active && opts.offline) director = offline.director;
  else {
    director = live.director;
    // a frame drawn twice at the same time (transition, re-render) reuses the state
    if (time !== live.lastTime) { director.step(time, input); live.lastTime = time; }
    // native preset trials only: a summary every 2 s in the trial log (beat source, stroke grid)
    if (globalThis.document?.body?.classList?.contains("preset-trial-role") && (time < live.loggedAt || time - live.loggedAt >= 2)) {
      live.loggedAt = time;
      globalThis.webkit?.messageHandlers?.nativeApp?.postMessage({ command: "logConsole", type: "info", text: `[CBT] ${JSON.stringify(director.summary())}` });
    }
  }
  const loc = (name) => uniformLocation(gl, program, name);
  const dirLoc = loc("cbtDir");
  if (dirLoc) gl.uniform1f(dirLoc, 1);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (l) gl.uniform4f(l, value[0], value[1], value[2], value[3]);
  }
  return director;
}
