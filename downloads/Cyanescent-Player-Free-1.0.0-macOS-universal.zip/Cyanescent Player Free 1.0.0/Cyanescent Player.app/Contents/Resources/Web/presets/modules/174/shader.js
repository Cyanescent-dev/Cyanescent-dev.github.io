export { createSriYantraHyperspacePresetShaderEntries as createPresetShaderEntries } from "../../sriYantraHyperspacePresetShaderSources.js";
