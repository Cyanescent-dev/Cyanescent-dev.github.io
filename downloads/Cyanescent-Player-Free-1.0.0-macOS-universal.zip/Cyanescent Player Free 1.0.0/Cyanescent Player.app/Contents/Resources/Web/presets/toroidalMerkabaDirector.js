// Toroidal Merkaba Field (preset 176), The Recursive Crystal Temple: the director.
//
// The temple is the original's: a lattice of 6-unit cells, each holding the same four-level
// reflect-scale IFS (abs fold, x2, minus a fold offset) ending in octahedral studs, every cell spun
// about its centre, with a cylinder carved along the z axis so the column of cubes the camera flies
// through becomes a run of apertures. The shader draws it; this file (pure JS, no GL, so it can be
// tested) decides how it moves, breathes and lights up:
//   travel     the camera's speed is a critically damped function of slow musical envelopes and is
//              integrated into its position (the original added globalEnergy to the position, so
//              every energy change jumped the camera); builds slow it towards stillness, drops surge
//   chambers   every ~200 units, and when a build begins, the 3x3 block of columns around the
//              axis omits its cubes for three cells (a nave) or four (a grand hall): the camera
//              slows, drifts off the axis and looks around at the ring of whole cubes. They are
//              scheduled beyond the fog, and the apertures leading into them open up (a threshold)
//   breathing  the fold offsets swell with the bass, one smooth wave per two bars running along the
//              corridor and lagging from coarse to fine levels (the original wobbled them with
//              sin(time + globalEnergy + zId), which jumped with every energy change)
//   cascades   kicks, rolls, tides and drops send fronts through the lattice; behind each front the
//              grooves between the IFS copies light up level by level, coarse to fine (descending)
//              or fine to coarse (ascending, converging), so light runs across scales
//   evolution  palette (rose quartz, amethyst, celestial turquoise, solar crystal), per-level fold
//              emphasis, cube orientation twist, stud size and aperture width on slow envelopes
// The camera never reads instantaneous kick or bass values.
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";

export const TOROIDAL_MERKABA_PRESET_ID = 176;
export const TMF_PULSE_SLOTS = 6;
export const TMF_CELL = 6;
export const TMF_HALF = 3;
// Everything that varies with the cell index repeats every TMF_PERIOD_CELLS cells, so the camera's z
// can be wrapped on long sessions without a visible jump or float precision loss.
export const TMF_PERIOD_CELLS = 240;
export const TMF_PERIOD = TMF_PERIOD_CELLS * TMF_CELL;
export const TMF_KZ = (2 * Math.PI) / TMF_PERIOD;
export const TMF_TWIST_K = (2 * Math.PI * 34) / TMF_PERIOD_CELLS;    // per-cell orientation offset
export const TMF_BREATH_K = (2 * Math.PI * 21) / TMF_PERIOD_CELLS;   // breathing lag along the corridor
export const TMF_SCHEDULE_AHEAD = 45;   // chambers are created at least this far ahead (fog ends ~36)
export const TMF_THRESHOLD = 12;        // apertures open over this distance before / after a chamber
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth01 = (x) => { const t = clamp(x); return t * t * (3 - 2 * t); };
const smoother01 = (x) => { const t = clamp(x); return t * t * t * (t * (t * 6 - 15) + 10); };
const mix = (a, b, t) => a + (b - a) * t;

// ---- geometry shared with the shader ----------------------------------------------------------------
// GLSL rot(a) = mat2(c, -s, s, c) (column-major): v' = (c x + s y, -s x + c y).
function rot2(a, x, y) { const c = Math.cos(a), s = Math.sin(a); return [c * x + s * y, -s * x + c * y]; }

// Aperture (tunnel) radius along z: a slow swell, the director's scale, and the threshold before and
// after every chamber.
export function tmfAperture(z, scale, chambers) {
  let r = (1.5 + 0.18 * Math.sin(5 * TMF_KZ * z + 0.7) + 0.1 * Math.sin(13 * TMF_KZ * z + 2.0)) * scale;
  for (const c of chambers) {
    const a = c[0] * TMF_CELL - TMF_HALF, b = c[1] * TMF_CELL + TMF_HALF;
    const open = smooth01((z - (a - TMF_THRESHOLD)) / TMF_THRESHOLD) * smooth01((b + TMF_THRESHOLD - z) / TMF_THRESHOLD);
    r += 0.45 * open * c[3];
  }
  return r;
}

// The chamber whose empty block holds cell id, or null.
export function tmfRemovedBy(id, chambers) {
  for (const c of chambers) {
    if (c[3] <= 0 || id[2] < c[0] || id[2] > c[1]) continue;
    if (Math.max(Math.abs(id[0]), Math.abs(id[1])) <= 1) return c;
  }
  return null;
}
export const tmfRemoved = (id, chambers) => tmfRemovedBy(id, chambers) !== null;

// Per-cell fold offsets: the director's per-level offsets breathing along the corridor.
export function tmfFoldOf(zId, g) {
  return g.fold.map((k, i) => k * (1 + g.breathAmp * Math.sin(g.breathPhase - zId * TMF_BREATH_K - i * 0.7)));
}

// Bounding radius of a cell's cube for fold offsets k (as large as breathing makes them) and stud
// radius r: the farthest stud centre is at (C, C, C), C = sum k_i / 2^(i+1), and a stud reaches r/16
// further along an axis.
export function tmfBound(fold, breathAmp, octR) {
  const C = fold.reduce((s, k, i) => s + k * (1 + breathAmp) / 2 ** (i + 1), 0);
  return Math.hypot(C + octR / 16, C, C) + 0.02;
}

// The cube of one cell (cell-local, oriented coordinates).
export function tmfIfs(q, k, octR) {
  let [x, y, z] = q;
  let sc = 1;
  for (let i = 0; i < 4; i++) {
    x = Math.abs(x) * 2 - k[i]; y = Math.abs(y) * 2 - k[i]; z = Math.abs(z) * 2 - k[i];
    sc *= 2;
  }
  return (Math.abs(x) + Math.abs(y) + Math.abs(z) - octR) * 0.57735027 / sc;
}

// Distance bound to the temple (positive in free space): a JS port of the shader's tmfMap.
export function tmfMap(p, g) {
  const id = p.map((v) => Math.floor((v + TMF_HALF) / TMF_CELL));
  const l = p.map((v, i) => v - id[i] * TMF_CELL);
  // the neighbouring cubes on this side of the cell, by their bounding spheres
  const sl = l.map((v) => v - (v >= 0 ? 1 : -1) * TMF_CELL);
  let bound = Infinity;
  for (let m = 1; m < 8; m++) bound = Math.min(bound, Math.hypot(m & 1 ? sl[0] : l[0], m & 2 ? sl[1] : l[1], m & 4 ? sl[2] : l[2]));
  bound -= g.Rb;
  let own = 1e3;
  const hall = tmfRemovedBy(id, g.chambers);
  if (hall) {
    // inside a chamber's empty block every cube is beyond the block's walls plus the gap
    const inside = Math.min(9 - Math.max(Math.abs(p[0]), Math.abs(p[1])), p[2] - (hall[0] * TMF_CELL - TMF_HALF), hall[1] * TMF_CELL + TMF_HALF - p[2]);
    bound = Math.max(bound, inside + TMF_HALF - g.Rb);
  } else {
    const r = Math.hypot(...l);
    if (r > g.Rb + 0.25) own = r - g.Rb;
    else {
      let [x, y] = rot2(g.spinA + g.twist * Math.sin(id[2] * TMF_TWIST_K), l[0], l[1]);
      let z = l[2];
      [y, z] = rot2(g.spinB, y, z);
      own = tmfIfs([x, y, z], tmfFoldOf(id[2], g), g.octR);
    }
  }
  const tunnel = Math.hypot(p[0], p[1]) - tmfAperture(p[2], g.aperture, g.chambers);
  return Math.max(Math.min(own, bound), -tunnel);
}

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const scale3 = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm3 = (a) => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
function rotateAbout(v, axis, a) {
  const c = Math.cos(a), s = Math.sin(a);
  return add(add(scale3(v, c), scale3(cross(axis, v), s)), scale3(axis, dot3(axis, v) * (1 - c)));
}

// Palettes: body, deep (subsurface and shadow), glow (internal light and cascades), accent (sheen,
// specular), fog. The first is the original's rose and cream.
export const TMF_PALETTES = [
  [[0.82, 0.46, 0.64], [0.48, 0.10, 0.32], [1.00, 0.62, 0.62], [1.00, 0.90, 0.80], [0.040, 0.010, 0.036]],   // rose quartz
  [[0.50, 0.36, 0.74], [0.24, 0.07, 0.44], [0.80, 0.52, 1.00], [0.86, 0.88, 1.00], [0.028, 0.012, 0.062]],   // amethyst
  [[0.36, 0.66, 0.70], [0.04, 0.26, 0.36], [0.40, 1.00, 0.88], [0.92, 0.98, 1.00], [0.008, 0.030, 0.046]],   // celestial turquoise
  [[0.84, 0.56, 0.34], [0.46, 0.17, 0.07], [1.00, 0.70, 0.30], [1.00, 0.88, 0.62], [0.046, 0.020, 0.010]]    // solar crystal
];
function paletteAt(pos) {
  const n = TMF_PALETTES.length;
  const i = Math.floor(pos), f = smooth01(pos - i);
  const a = TMF_PALETTES[((i % n) + n) % n], b = TMF_PALETTES[(((i + 1) % n) + n) % n];
  return a.map((c, k) => c.map((v, j) => mix(v, b[k][j], f)));
}

// ---- the director -------------------------------------------------------------------------------
export function createToroidalMerkabaDirector() {
  const audioModel = createNewtonAudioModel();
  const s = {};
  const pulses = [];
  const chambers = [];
  const uniforms = {};
  let seed = 1;
  const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  function reset() {
    audioModel.reset();
    pulses.length = 0;
    chambers.length = 0;
    seed = 0x5eed176;
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0, beat: 0,
      // envelopes
      energy: 0.35, energySlow: 0.35, mids: 0.35, midsSlow: 0.35, highs: 0.3, bass: 0.4, bassSlow: 0.4,
      calm: 0, drive: 0, tension: 0, anticipation: 0, buildHold: 0, shimmer: 0, gloss: 0.3, flash: 0, glare: 0, surge: 0, hatSpark: 0, awake: 0.3,
      // phases (all accumulated: tempo or envelope changes alter rates, never positions)
      spinA: 0.4, spinB: 0.2, breathPhase: 0, formPhase: 0, twistPhase: 0.8, sparkClock: 0, film: 0, levelPhase: 0,
      // structure
      fold: [1.5, 1.5, 1.5, 1.5], breathAmp: 0.03, twist: 0.18, octR: 2, aperture: 1, Rb: 2.7,
      // palette
      palPos: 0, palTarget: 0, palVel: 0, lastPalChange: 0, wasCalm: false,
      // camera
      J: 0, camZ: 1.5, speed: 2.2, speedV: 0, fwd: [0, 0, 1], up: [0, 1, 0], tanHalf: 0.62,
      clearance: 1, minClearance: Infinity, chamberness: 0, lastChamberEnd: -60, chamberCount: 0, buildChamber: false,
      // counters (tests, trial reports)
      kicks: 0, drops: 0, rolls: 0, tides: 0, lastDropAt: -1e9
    });
  }
  reset();

  const SHAPES = {
    //              speed  span  levels width range life   (span: world units per level behind the front)
    kick:     { speed: 13, span: 1.0, levels: 1, width: 0.6, range: 10, life: 1.6 },
    converge: { speed: -7.0, span: 0.8, levels: -1, width: 0.5, range: 9, life: 1.2 },
    roll:     { speed: -11, span: 0.7, levels: -1, width: 0.6, range: 30, life: 1.3 },
    tide:     { speed: 3.2, span: 1.6, levels: 1, width: 0.9, range: 16, life: 5.0 },
    drop:     { speed: 12, span: 2.6, levels: 1, width: 1.4, range: 40, life: 5.0 }
  };

  function spawn(kind, strength, src, start = 0) {
    const shape = SHAPES[kind];
    if (pulses.length >= TMF_PULSE_SLOTS) {
      let oldest = 0;
      for (let i = 1; i < pulses.length; i++) if (pulses[i].age / pulses[i].life > pulses[oldest].age / pulses[oldest].life) oldest = i;
      pulses.splice(oldest, 1);
    }
    pulses.push({ kind, strength, src, start, age: 0, ...shape });
  }

  const geometry = () => ({ fold: s.fold, breathAmp: s.breathAmp, breathPhase: s.breathPhase, octR: s.octR, Rb: s.Rb,
    spinA: s.spinA, spinB: s.spinB, twist: s.twist, aperture: s.aperture, chambers: activeChambers() });
  // [z0 cell, z1 cell, type (0 nave, 1 grand hall), presence]
  const activeChambers = () => chambers.slice(0, 2).map((c) => [c.z0, c.z1, c.type, 1]);

  // A cube centre ahead of the camera that exists: the column's next cubes, or a neighbouring column
  // (two columns out inside a chamber).
  function cubeAhead(cellsAhead, side) {
    const zId = Math.round(s.camZ / TMF_CELL) + cellsAhead;
    const cand = side === 0 ? [[0, 0], [1, 0], [-1, 0], [0, 1]] : [[side, 0], [0, side], [side, side], [-side, 0], [0, 0]];
    for (const [x, y] of cand) {
      for (let dz = 0; dz < 4; dz++) {
        for (const r of [1, 2]) {
          if (!tmfRemoved([x * r, y * r, zId + dz], activeChambers())) return [x * r * TMF_CELL, y * r * TMF_CELL, (zId + dz) * TMF_CELL];
        }
      }
    }
    return [2 * TMF_CELL, 0, zId * TMF_CELL];
  }

  // A chamber's z extent in world units and how far inside one z is (0 outside, 1 well inside).
  function chambernessAt(z) {
    let ch = 0;
    for (const c of chambers) {
      const a = c.z0 * TMF_CELL - TMF_HALF, b = c.z1 * TMF_CELL + TMF_HALF;
      ch = Math.max(ch, smoother01((z - a + 2) / 7) * smoother01((b - z + 2) / 7));
    }
    return ch;
  }

  function scheduleChamber(type, after = -Infinity) {
    const startZ = Math.max(s.camZ + TMF_SCHEDULE_AHEAD, after);
    const z0 = Math.ceil((startZ + TMF_HALF) / TMF_CELL);
    const len = type ? 4 : 3;
    chambers.push({ z0, z1: z0 + len - 1, type });
    s.chamberCount += 1;
  }

  // time: seconds (monotonic per preset activation). input: { audio, smooth, music, tempo }.
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = clamp(time - s.lastTime, 0, 0.1);
    s.lastTime = time;
    s.time += dt;
    const { audio = {}, smooth = {}, music = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const events = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    const a = audioModel.state;
    s.beat = a.beat;

    // ---- musical envelopes (slew-limited: nothing below reaches the geometry raw) -------------------
    s.energy = follow(s.energy, Math.max(a.energyDrive * 0.9, clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.8), dt, 0.5, 1.6);
    s.energySlow = follow(s.energySlow, s.energy, dt, 4, 6);
    s.mids = follow(s.mids, clamp(smooth.mids), dt, 0.4, 0.8);
    s.midsSlow = follow(s.midsSlow, s.mids, dt, 1.4, 1.8);
    s.highs = follow(s.highs, clamp(smooth.highs), dt, 0.05, 0.25);
    s.bass = follow(s.bass, clamp(Math.max(a.sub, clamp(smooth.bass) * 0.85)), dt, 0.5, 1.1);
    s.bassSlow = follow(s.bassSlow, s.bass, dt, 0.9, 1.5);
    const building = clamp(Math.max(a.build, clamp(music.buildUp)));
    s.calm = follow(s.calm, clamp((a.breakdown - 0.35) / 0.45) * (1 - a.groove * 0.7) * (1 - clamp(building * 1.6)), dt, 1.4, 1.8);
    s.drive = follow(s.drive, clamp(a.groove * (0.5 + 0.5 * s.energy)), dt, 0.8, 1.6);
    const forecast = clamp(Math.max(clamp(music.upcomingDrop) * 1.2, a.build));
    s.tension = follow(s.tension, forecast * (1 - s.calm * 0.5), dt, 0.8, 1.2);
    // the last moments of a build: the drop is imminent. The analysis forecast rarely gets near 1
    // on real tracks, so a build held at its peak also counts: the longer it holds, the nearer the drop.
    s.buildHold = s.tension > 0.9 ? s.buildHold + dt : Math.max(0, s.buildHold - dt * 3);
    const imminent = Math.max(clamp((clamp(music.upcomingDrop) - 0.7) / 0.25) * clamp(building * 1.5), 0.8 * smooth01((s.buildHold - 1.5) / 5));
    s.anticipation = follow(s.anticipation, imminent, dt, 0.7, 0.35);

    // ---- events -------------------------------------------------------------------------------------
    for (const w of events.waves) {
      if (w.kind === "kick") {
        // beats 1 and 3 send light down the scales from a cube ahead; 2 and 4 draw it back up
        const b = w.beatInBar ?? (s.kicks % 4);
        const src = cubeAhead(1 + (b >> 1), [0, 1, 0, -1][b % 4]);
        if (b % 2 === 0) spawn("kick", w.strength * (b === 0 ? 1 : 0.8), src);
        else spawn("converge", w.strength * 0.6, src, 7);
        s.kicks += 1;
      } else if (w.kind === "roll" && s.tension > 0.25) {
        // build rolls converge on the aperture ahead, where the drop will break
        spawn("roll", 0.3 + 0.5 * w.strength, [0, 0, s.camZ + 9], 15);
        s.rolls += 1;
      } else if (w.kind === "tide") {
        spawn("tide", 0.7 + 0.5 * s.midsSlow, cubeAhead(2 + Math.floor(rand() * 2), [0, 1, -1][Math.floor(rand() * 3)]));
        s.tides += 1;
      }
    }
    if (events.hats) s.hatSpark = Math.max(s.hatSpark, 0.5 + 0.5 * a.highDrive);
    // the kick returning in the middle of a build (a tease) is a rebound, not the drop. Once a build
    // has peaked, the analysis keeps calling the build through a tease (build-up ~1) but is already
    // letting go at the real drop (it lags, ~0.5-0.75 as the kick returns on TestPsy.wav)
    const bu = clamp(music.buildUp);
    const rebound = events.drop && bu > 0.5 && clamp(music.drop) < 0.6 && (s.tension < 0.85 || bu > 0.9);
    if (rebound) { spawn("kick", 1.0, cubeAhead(1, 0)); s.flash = Math.max(s.flash, 0.25); }
    if (events.drop && !rebound && s.time - s.lastDropAt > 6) {
      s.lastDropAt = s.time; s.drops += 1;
      pulses.length = 0;
      spawn("drop", 1.6, [0, 0, s.camZ + 5]);
      s.flash = 1; s.surge = 1;
      if (s.time - s.lastPalChange > 12) { s.palTarget += 1; s.lastPalChange = s.time; }
    }
    s.flash *= Math.exp(-dt / 0.9);
    // the drop's brilliance swells in over ~80 ms rather than switching on
    s.glare = follow(s.glare, s.flash, dt, 0.08, 0.05);
    // the surge rises over ~0.5 s through the speed spring and fades over ~10 s
    s.surge = Math.max(0, s.surge - dt / 10);
    s.hatSpark *= Math.exp(-dt / 0.12);
    s.shimmer = clamp(0.25 * s.highs + 0.55 * a.highDrive * (0.4 + 0.6 * s.energy) + 0.45 * s.hatSpark);
    // the polish follows the highs slowly (sparkles take the hats)
    s.gloss = follow(s.gloss, s.shimmer, dt, 0.6, 1.2);
    for (const p of pulses) p.age += dt;
    for (let i = pulses.length - 1; i >= 0; i--) if (pulses[i].age > pulses[i].life) pulses.splice(i, 1);

    // ---- palette: phrase-scale drift, drops advance it, breakdowns turn to amethyst -------------------
    const calmNow = s.calm > 0.5;
    if (calmNow && !s.wasCalm && s.time - s.lastPalChange > 8) {
      const n = TMF_PALETTES.length;
      const base = Math.round(s.palPos);
      let t = base;
      for (let k = 0; k < n; k++) {
        if ((((base + k) % n) + n) % n === 1) { t = base + k; break; }
        if ((((base - k) % n) + n) % n === 1) { t = base - k; break; }
      }
      s.palTarget = t; s.lastPalChange = s.time;
    }
    s.wasCalm = calmNow;
    if (s.time - s.lastPalChange > 128 / bps) { s.palTarget += 1; s.lastPalChange = s.time; }
    const wp = 0.22;   // critically damped: a change takes ~15 s
    s.palVel += (wp * wp * (s.palTarget - s.palPos) - 2 * wp * s.palVel) * dt;
    s.palVel = clamp(s.palVel, -0.08, 0.08);
    s.palPos += s.palVel * dt;

    // ---- structure ----------------------------------------------------------------------------------
    const spinRate = (0.06 + 0.1 * s.drive + 0.04 * s.surge) * (1 - 0.6 * s.tension) * (1 - 0.4 * s.calm);
    s.spinA += dt * spinRate;
    s.spinB += dt * spinRate * 0.6;
    s.formPhase += dt * 0.035 * (0.7 + 0.3 * s.drive);
    s.twistPhase += dt * 0.021;
    s.breathPhase += dt * bps * TAU / 8;   // one breath every two bars
    s.levelPhase += dt * (0.25 + 0.6 * s.mids);
    s.sparkClock += dt * (3 + 9 * s.shimmer);
    s.film += dt * (0.03 + 0.2 * s.shimmer);
    // which recursive level stands out: the gaps between its copies open a little
    const emph = [0, 1, 2, 3].map((i) => Math.max(0, Math.sin(s.formPhase - i * 1.6)) ** 2);
    const open = 0.04 + 0.08 * s.energySlow + 0.08 * s.surge;
    const foldGoal = emph.map((e, i) => 1.5 + open * e * (i === 0 ? 1.2 : 1) - 0.02 * s.calm);
    s.fold = s.fold.map((k, i) => follow(k, foldGoal[i], dt, 2.5, 2.5));
    s.breathAmp = follow(s.breathAmp, 0.012 + 0.055 * s.bassSlow * (0.4 + 0.6 * s.drive) + 0.008 * s.calm, dt, 1.5, 2.5);
    s.twist = follow(s.twist, 0.35 * Math.sin(s.twistPhase) ** 2 + 0.1 * s.calm, dt, 3, 3);
    // builds grow intricacy: the studs shrink apart into lacier points
    s.octR = follow(s.octR, 2.0 - 0.3 * s.tension + 0.08 * s.calm, dt, 1.5, 2.5);
    s.aperture = follow(s.aperture, 1 + 0.08 * s.calm - 0.05 * s.tension + 0.06 * s.surge, dt, 2.5, 2.5);
    s.Rb = tmfBound(s.fold, s.breathAmp, s.octR);
    // a cube never reaches its cell's faces (the field's neighbour bounds rely on it)
    while (s.Rb > 2.9 && s.breathAmp > 0) { s.breathAmp = Math.max(0, s.breathAmp - 0.004); s.Rb = tmfBound(s.fold, s.breathAmp, s.octR); }
    s.awake = follow(s.awake, 0.22 + 0.4 * s.energy + 0.5 * s.surge + 0.45 * s.tension - 0.1 * s.calm, dt, 0.8, 2.2);

    // ---- chambers -----------------------------------------------------------------------------------
    while (chambers.length && chambers[0].z1 * TMF_CELL + TMF_HALF < s.camZ - 40) chambers.shift();
    const pending = chambers.some((c) => c.z0 * TMF_CELL - TMF_HALF > s.camZ);
    if (s.tension < 0.2) s.buildChamber = false;
    // a build turns a chamber that is still out of sight into a grand hall (it only grows at the far end)
    const ahead = chambers.find((c) => c.z0 * TMF_CELL - TMF_HALF - TMF_THRESHOLD - s.camZ > 38);
    if (ahead && !ahead.type && s.tension > 0.45 && !s.buildChamber) { ahead.type = 1; ahead.z1 = ahead.z0 + 3; s.buildChamber = true; }
    // a build opens a grand hall ahead, beyond any chamber already waiting (where the drop's surge
    // carries the camera), unless one has only just ended: the analysis also calls brief builds
    // inside a drive. Otherwise a chamber every ~200 units keeps the apertures the main experience.
    for (const c of chambers) if (c.z0 * TMF_CELL - TMF_HALF <= s.camZ) s.lastChamberEnd = Math.max(s.lastChamberEnd, Math.min(s.camZ, c.z1 * TMF_CELL + TMF_HALF));
    const away = s.camZ - s.lastChamberEnd;
    if (chambers.length < 2 && s.tension > 0.45 && !s.buildChamber && away > 70 && s.time > 15) {
      const last = chambers[chambers.length - 1];
      scheduleChamber(1, last ? last.z1 * TMF_CELL + TMF_HALF + 2 * TMF_THRESHOLD + 6 : -Infinity);
      s.buildChamber = true;
    } else if (!pending && chambers.length < 2 && away > 190 + 60 * s.calm) scheduleChamber(s.chamberCount % 2);

    // ---- camera -------------------------------------------------------------------------------------
    s.chamberness = chambernessAt(s.camZ);
    const ch = s.chamberness;
    const base = 2.2 + 0.7 * s.drive - 1.1 * s.calm;
    // (a chamber slows the camera, except while a drop carries it through)
    const speedGoal = Math.max(0.3, base * (1 - 0.62 * s.tension) * (1 - 0.75 * s.anticipation) * (1 - 0.3 * ch) + 6.2 * s.surge * s.surge);
    // a faster spring while the drop surge rises, so it lands with the music
    const wsp = 1.1 + 0.9 * s.surge;
    s.speedV += (wsp * wsp * (speedGoal - s.speed) - 2 * wsp * s.speedV) * dt;
    s.speedV = clamp(s.speedV, -3.5, 5.5);
    s.speed += s.speedV * dt;
    s.camZ += dt * Math.max(0.2, s.speed);
    if (s.camZ > 8 * TMF_PERIOD) {
      // the lattice, apertures and per-cell phases all repeat with this period
      const shift = 4 * TMF_PERIOD;
      s.camZ -= shift; s.lastChamberEnd -= shift;
      for (const p of pulses) p.src = [p.src[0], p.src[1], p.src[2] - shift];
      for (const c of chambers) { c.z0 -= shift / TMF_CELL; c.z1 -= shift / TMF_CELL; }
    }
    s.J += dt * (0.8 + 0.3 * s.drive - 0.2 * s.calm);
    const J = s.J;
    const zc = s.camZ;
    // lateral drift: a little inside the apertures, a wide arc in chambers (the weight is a C2 ramp
    // over the chamber, so the camera is back on the axis before the cubes resume)
    let dw = 0, hall = 0;
    for (const c of chambers) {
      const a = c.z0 * TMF_CELL - TMF_HALF, b = c.z1 * TMF_CELL + TMF_HALF;
      const w = smoother01((zc - a) / 9) * smoother01((b - zc) / 9);
      if (w > dw) { dw = w; hall = c.type; }
    }
    const reach = hall ? 3.6 : 2.4;
    const corridorDrift = 0.28 * (1 - dw) * Math.min(1, tmfAperture(zc, s.aperture, activeChambers()) / 1.5);
    const off = [
      corridorDrift * Math.sin(J * 0.23) + reach * dw * Math.sin(J * 0.13 + 0.6),
      corridorDrift * 0.8 * Math.sin(J * 0.17 + 1.1) + reach * 0.7 * dw * Math.sin(J * 0.09 + 2.1)
    ];
    const pos = [off[0], off[1], zc];
    s.clearance = tmfMap(pos, geometry());
    s.minClearance = Math.min(s.minClearance, s.clearance);

    // look down the run of apertures; in chambers, turn to take in the architecture
    const look = 9;
    let fwdGoal = norm3([-off[0] * (1 - 0.6 * dw) / look * 0.8, -off[1] * (1 - 0.6 * dw) / look * 0.8, 1]);
    const worldUp = [0, 1, 0];
    const yaw = 0.07 * Math.sin(J * 0.051) + dw * (hall ? 0.5 : 0.36) * Math.sin(J * 0.083 + s.chamberCount * 1.7);
    const pitch = 0.05 * Math.sin(J * 0.037 + 0.5) + dw * 0.2 * Math.sin(J * 0.061 + s.chamberCount);
    fwdGoal = rotateAbout(fwdGoal, worldUp, yaw);
    fwdGoal = rotateAbout(fwdGoal, norm3(cross(worldUp, fwdGoal)), -pitch);
    // the original's slow roll of the view
    const roll = 0.16 * Math.sin(J * 0.024 + 0.4) + 0.1 * dw * Math.sin(J * 0.047) + 0.06 * s.calm * Math.sin(J * 0.031);
    const upGoal = [Math.sin(roll), Math.cos(roll), 0];
    s.fwd = norm3(s.fwd.map((v, i) => follow(v, fwdGoal[i], dt, 0.9, 0.9)));
    s.up = norm3(s.up.map((v, i) => follow(v, upGoal[i], dt, 0.8, 0.8)));
    const fwd = s.fwd;
    const right = norm3(cross(s.up, fwd));
    const up = cross(fwd, right);
    // tension narrows the view a little; the surge and the halls widen it
    s.tanHalf = follow(s.tanHalf, 0.62 + 0.1 * dw - 0.06 * s.tension + 0.07 * s.surge, dt, 1.2, 1.5);

    // ---- uniforms -----------------------------------------------------------------------------------
    const lvl = [0, 1, 2, 3].map((i) => 0.35 + 0.65 * Math.max(0, Math.cos(s.levelPhase - i * 1.3)));
    uniforms.tmfCam = [...pos, s.tanHalf];
    uniforms.tmfBasis = [...right, ...up, ...fwd];
    uniforms.tmfFold = [...s.fold];
    uniforms.tmfForm = [s.spinA % 6283.185, s.spinB % 6283.185, s.twist, s.octR];
    uniforms.tmfBreath = [s.breathAmp, s.breathPhase % 6283.185, s.aperture, s.Rb];
    const ac = activeChambers();
    uniforms.tmfChamberA = ac[0] || [0, -1, 0, 0];
    uniforms.tmfChamberB = ac[1] || [0, -1, 0, 0];
    uniforms.tmfLevels = lvl.map((v, i) => v * (0.5 + 0.5 * (i === 1 || i === 2 ? s.midsSlow : s.energy)));
    const src = new Array(4 * TMF_PULSE_SLOTS).fill(0), shape = new Array(4 * TMF_PULSE_SLOTS).fill(0), aux = new Array(4 * TMF_PULSE_SLOTS).fill(0);
    pulses.forEach((p, i) => {
      const front = p.speed >= 0 ? p.speed * p.age : Math.max(0, p.start + p.speed * p.age);
      src.splice(i * 4, 4, p.src[0], p.src[1], p.src[2], front);
      const fadeIn = clamp(p.age / 0.05);
      const amp = p.strength * fadeIn * Math.exp(-p.age / (p.life * 0.6)) * (0.55 + 0.45 * Math.max(s.energy, p.kind === "tide" ? 0.8 : 0));
      shape.splice(i * 4, 4, amp, p.span, p.levels, p.range);
      aux.splice(i * 4, 4, Math.sign(p.speed), p.width, 0, 0);
    });
    uniforms.tmfPulseSrc = src; uniforms.tmfPulseShape = shape; uniforms.tmfPulseAux = aux;
    const pal = paletteAt(s.palPos);
    const fog = 0.03 - 0.012 * ch - 0.006 * s.calm + 0.004 * s.tension;
    uniforms.tmfColA = [...pal[0], fog];
    uniforms.tmfColB = [...pal[1], s.film % 1000];
    uniforms.tmfColC = [...pal[2], s.sparkClock % 1000];
    uniforms.tmfColD = [...pal[3], 0];
    uniforms.tmfColE = [...pal[4], 0];
    // aperture light: gathers through builds, blooms on drops, softer in breakdowns
    const apLight = 0.7 + 0.4 * s.energy + 1.0 * s.tension + 0.8 * s.glare + 0.4 * s.surge - 0.25 * s.calm;
    uniforms.tmfLight = [0.95 + 0.1 * s.energy + 0.08 * s.calm + 0.14 * s.glare, s.shimmer, s.glare, s.awake];
    uniforms.tmfLight2 = [apLight, 8.5 + 3 * dw, ch, s.gloss];
    s.camera = { pos, fwd, chamberness: ch, clearance: s.clearance };
    return s;
  }

  function summary() {
    const r = (x, n = 2) => +x.toFixed(n);
    return { z: r(s.camZ, 1), speed: r(s.speed), ch: r(s.chamberness), clear: r(s.clearance), calm: r(s.calm), drive: r(s.drive),
      tension: r(s.tension), antic: r(s.anticipation), surge: r(s.surge), awake: r(s.awake), pal: r(s.palPos), fold: s.fold.map((k) => r(k, 3)),
      octR: r(s.octR), Rb: r(s.Rb), drops: s.drops, kicks: s.kicks, chambers: chambers.map((c) => `${c.type ? "hall" : "nave"}@${c.z0 * TMF_CELL}`).join(" "),
      pulses: pulses.map((p) => p.kind).join(" ") };
  }

  return { state: s, step, uniforms: () => uniforms, pulses, chambers, summary, geometry };
}

const cache = new WeakMap();

export function bindToroidalMerkabaDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime) { runtime = { director: createToroidalMerkabaDirector(), lastTime: -1 }; cache.set(gl, runtime); }
  const director = opts.director || runtime.director;
  // a frame drawn twice at the same time (transition, re-render) reuses the state
  if (time !== runtime.lastTime || opts.director) { director.step(time, input); runtime.lastTime = time; }
  const loc = (name) => uniformLocation(gl, program, name);
  const dirLoc = loc("tmfDir");
  if (dirLoc) gl.uniform1f(dirLoc, 1);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (!l) continue;
    if (value.length === 9) gl.uniformMatrix3fv(l, false, value);
    else if (value.length === 4) gl.uniform4f(l, value[0], value[1], value[2], value[3]);
    else gl.uniform4fv(l, value);
  }
  return director;
}
