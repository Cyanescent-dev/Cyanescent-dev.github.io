export { createToroidalMerkabaFieldPresetShaderEntries as createPresetShaderEntries } from "../../toroidalMerkabaFieldPresetShaderSources.js";
