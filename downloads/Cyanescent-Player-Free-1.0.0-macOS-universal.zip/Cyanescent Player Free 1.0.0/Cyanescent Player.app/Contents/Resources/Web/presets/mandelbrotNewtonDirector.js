import { computeOfflineAudioState } from "../ui/offlineAudioState.js";
import { dropMapEnabled } from "../audio/dropMap.js";
import { autonomousMnmMorph, createMnmJourney, createMnmStepper, mnmEventsFromAnalysis } from "./mandelbrotNewtonJourney.js";

export const MANDELBROT_NEWTON_PRESET_ID = 274;
const STEP = 1 / 60;
const initial = () => ({ morph: autonomousMnmMorph(0), framing: autonomousMnmMorph(0) });
const paths = new WeakMap();

// Analysis owns the immutable paths. Drop Map edits invalidate only this preset's
// cache; frame cadence, seeking and export render order never integrate the path.
export function analysedMnmJourney(analysis, sourceStart = 0) {
  sourceStart = Math.round(sourceStart * 1e6) / 1e6;
  const enabled = dropMapEnabled();
  let cache = paths.get(analysis);
  if (!cache || cache.frames !== analysis.frames || cache.sections !== analysis.sections
      || cache.drops !== analysis.drops || cache.enabled !== enabled) {
    cache = { frames: analysis.frames, sections: analysis.sections, drops: analysis.drops, enabled, entries: new Map() };
    paths.set(analysis, cache);
  }
  if (cache.entries.has(sourceStart)) return cache.entries.get(sourceStart);
  const duration = Math.max(STEP, analysis.duration - sourceStart);
  const events = mnmEventsFromAnalysis({ ...analysis, drops: enabled ? analysis.drops : [] })
    .map(event => ({ ...event, time: event.time - sourceStart })).filter(event => event.time >= 0);
  const journey = createMnmJourney({ duration, events, sampleAudio(time) {
    const music = computeOfflineAudioState({ analysisTimeline: analysis,
      time: Math.max(0, time + sourceStart), duration: analysis.duration }).musicAwareState;
    return { mainRiffState: music.mainRiff, buildUpState: music.buildUp, phraseProgress: music.phraseProgress };
  } });
  cache.entries.set(sourceStart, journey);
  if (cache.entries.size > 4) cache.entries.delete(cache.entries.keys().next().value);
  return journey;
}

// One instance per renderer, isolated from all other presets and audio envelopes.
export function createMandelbrotNewtonDirector() {
  let owner = null, epoch = null, sourceStart = 0;
  let live = null, liveTick = -1, liveEpoch = null, lastDrop = 0, lastSection = 0, lastEvent = -Infinity, lastLive = null;
  return {
    sample({ time = 0, trackTime = NaN, analysis = null, entryToken = 0, offline = false, music = {}, warmup = false } = {}) {
      if (warmup) return { ...initial(), time: 0 };
      time = Math.max(0, Number(time) || 0);
      if (analysis?.getFeatures && Number.isFinite(analysis.duration) && Number.isFinite(trackTime)) {
        if (offline) {
          const origin = trackTime - time;
          return { ...analysedMnmJourney(analysis, origin).sample(time), time };
        }
        if (owner !== analysis || epoch !== entryToken) {
          owner = analysis; epoch = entryToken; sourceStart = Math.max(0, trackTime - time);
        }
        // This local geometry clock follows playback, including pause/restart/seek.
        // Shared music, beat and export clocks are untouched.
        const localTime = Math.max(0, trackTime - sourceStart);
        return { ...analysedMnmJourney(analysis, sourceStart).sample(localTime), time: localTime };
      }
      // Live/remote input has no future analysis. Use the same damped controller,
      // fixed 60 Hz updates and edge-triggered events rather than raw drop levels.
      const tick = Math.floor(time / STEP + 1e-8);
      if (!live || liveEpoch !== entryToken || tick < liveTick || tick - liveTick > 120) {
        live = createMnmStepper(); liveEpoch = entryToken; liveTick = tick - 1;
        lastDrop = 0; lastSection = 0; lastEvent = -Infinity;
      }
      const drop = Number(music.drop) || 0, section = Number(music.sectionChange) || 0;
      if (((drop > .6 && lastDrop <= .6) || (section > .6 && lastSection <= .6)) && time - lastEvent > 8) {
        live.trigger({ time, strength: drop > .6 ? 1 : .45 }); lastEvent = time;
      }
      lastDrop = drop; lastSection = section;
      let value;
      while (liveTick < tick) {
        liveTick++;
        value = live.advance(liveTick * STEP, { mainRiffState: music.mainRiff,
          buildUpState: music.buildUp, phraseProgress: music.phraseProgress }, liveTick ? STEP : 0);
      }
      // Repeated binds during transitions must not advance the state twice.
      if (value) lastLive = value;
      return { ...(lastLive || initial()), time };
    }
  };
}
