export { createFractalCoralReefPresetShaderEntries as createPresetShaderEntries } from "../../fractalCoralReefPresetShaderSources.js";
