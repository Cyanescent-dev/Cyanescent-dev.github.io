import { CYANESCENT_PRESETS_PLAYLIST_ID } from "./presetPlaylistStore.js";

function el(tag, className = "", text = "") {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

export function createPresetManagerUI({
  root,
  nativeAppBridge,
  userPresetStore,
  playlistStore,
  validatePresetText,
  installPreset,
  deletePreset,
  getAllPresets,
  getImportedPresets,
  previewPreset,
  refreshMainUi,
  onPresetFallback,
  allowJsonPresetImports = true
} = {}) {
  let selectedPlaylistId = "";
  let activeView = "presets";
  let statusEl = null;
  let importedListEl = null;
  let playlistListEl = null;
  let editorEl = null;
  let presetsViewEl = null;
  let playlistsViewEl = null;
  let presetsNavButton = null;
  let playlistsNavButton = null;
  let countsEl = null;

  function setStatus(message, type = "info") {
    if (!statusEl) return;
    statusEl.textContent = message || "";
    statusEl.dataset.type = type;
    statusEl.hidden = !message;
  }

  function close() {
    root?.classList.add("hidden");
  }

  function confirmAction(message, confirmLabel, action) {
    const panel = root?.querySelector(".preset-manager-window");
    if (!panel) return;
    panel.querySelector(".preset-manager-confirm-overlay")?.remove();
    const overlay = el("div", "preset-manager-confirm-overlay");
    const dialog = el("section", "preset-manager-confirm");
    dialog.setAttribute("role", "alertdialog");
    dialog.setAttribute("aria-modal", "true");
    const title = el("h3", "", "Confirm deletion");
    const copy = el("p", "", message);
    const actions = el("div", "preset-manager-confirm-actions");
    const cancel = el("button", "preset-manager-button subtle", "Cancel");
    cancel.type = "button";
    const confirm = el("button", "preset-manager-button danger", confirmLabel);
    confirm.type = "button";
    cancel.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      overlay.remove();
    });
    confirm.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      overlay.remove();
      action?.();
    });
    overlay.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (event.target === overlay) overlay.remove();
    });
    actions.append(cancel, confirm);
    dialog.append(title, copy, actions);
    overlay.append(dialog);
    panel.append(overlay);
    cancel.focus();
  }

  function requestPlaylistName({ title, initialName = "", confirmLabel, onConfirm }) {
    const panel = root?.querySelector(".preset-manager-window");
    if (!panel) return;
    panel.querySelector(".preset-manager-confirm-overlay")?.remove();
    const overlay = el("div", "preset-manager-confirm-overlay");
    const dialog = el("form", "preset-manager-confirm");
    dialog.setAttribute("aria-label", title);
    const heading = el("h3", "", title);
    const field = el("label", "preset-manager-field");
    field.append(el("span", "", "Playlist name"));
    const input = document.createElement("input");
    input.type = "text";
    input.value = initialName;
    input.maxLength = 80;
    input.required = true;
    field.append(input);
    const actions = el("div", "preset-manager-confirm-actions");
    const cancel = el("button", "preset-manager-button subtle", "Cancel");
    cancel.type = "button";
    const confirm = el("button", "preset-manager-button primary", confirmLabel);
    confirm.type = "submit";
    cancel.addEventListener("click", () => overlay.remove());
    dialog.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = input.value.trim();
      if (!name) {
        input.focus();
        return;
      }
      overlay.remove();
      onConfirm(name);
    });
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) overlay.remove();
    });
    actions.append(cancel, confirm);
    dialog.append(heading, field, actions);
    overlay.append(dialog);
    panel.append(overlay);
    input.focus();
    input.select();
  }

  function open() {
    render();
    root?.classList.remove("hidden");
  }

  function updateCounts() {
    if (!countsEl) return;
    const all = getAllPresets();
    const imported = all.filter((preset) => preset.imported);
    countsEl.textContent = `${all.length - imported.length} built-in · ${imported.length} imported`;
  }

  function showView(view) {
    activeView = view === "playlists" ? "playlists" : "presets";
    presetsViewEl?.classList.toggle("hidden", activeView !== "presets");
    playlistsViewEl?.classList.toggle("hidden", activeView !== "playlists");
    presetsNavButton?.classList.toggle("active", activeView === "presets");
    playlistsNavButton?.classList.toggle("active", activeView === "playlists");
    presetsNavButton?.setAttribute("aria-pressed", String(activeView === "presets"));
    playlistsNavButton?.setAttribute("aria-pressed", String(activeView === "playlists"));
  }

  async function importPresetText(text, name = "JSON preset") {
    if (!allowJsonPresetImports) {
      setStatus("Preset imports are available in Cyanescent Player Pro.", "warning");
      return;
    }
    setStatus(`Validating ${name}...`);
    try {
      const result = validatePresetText(text);
      if (!result.ok) {
        setStatus(result.errors.join(" "), "error");
        return;
      }
      const installed = installPreset(result);
      const warningText = result.warnings.length ? ` ${result.warnings.join(" ")}` : "";
      setStatus(`Imported ${installed.name}.${warningText}`, result.warnings.length ? "warning" : "success");
      refreshMainUi?.();
      renderImportedPresets();
      renderPlaylists();
      renderPlaylistEditor();
      updateCounts();
    } catch (error) {
      setStatus(error?.message || "Preset import failed.", "error");
    }
  }

  function renderImportedPresets() {
    if (!importedListEl) return;
    importedListEl.replaceChildren();
    const presets = getImportedPresets();
    if (!presets.length) {
      importedListEl.append(el("div", "preset-manager-empty", "No imported presets yet."));
      return;
    }
    for (const preset of presets) {
      const row = el("div", "preset-manager-row");
      const copy = el("div", "preset-manager-row-copy");
      copy.append(el("strong", "preset-manager-row-title", preset.name));
      copy.append(el("span", "", `JSON shader · ${preset.author || "Unknown author"}`));

      const actions = el("div", "preset-manager-row-actions");
      const preview = el("button", "preset-manager-button subtle", "Preview");
      preview.type = "button";
      preview.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        close();
        previewPreset?.(preset.id);
      });
      const details = el("button", "preset-manager-button subtle", "Details");
      details.type = "button";
      details.addEventListener("click", () => {
        setStatus(`${preset.name} — JSON shader, preset ${preset.id}, by ${preset.author || "Unknown author"}.`);
      });
      const remove = el("button", "preset-manager-button icon danger", "×");
      remove.type = "button";
      remove.setAttribute("aria-label", `Delete ${preset.name}`);
      remove.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        confirmAction(`Delete the imported preset “${preset.name}”?`, "Delete preset", () => {
          const deleted = deletePreset(preset.id);
          if (deleted === false) {
            setStatus(`Could not delete ${preset.name}.`, "error");
            return;
          }
          refreshMainUi?.();
          renderImportedPresets();
          renderPlaylists();
          renderPlaylistEditor();
          updateCounts();
          setStatus(`Deleted ${preset.name}.`, "success");
        });
      });
      actions.append(preview, details, remove);
      row.append(copy, actions);
      importedListEl.append(row);
    }
  }

  function renderPlaylists() {
    if (!playlistListEl) return;
    playlistListEl.replaceChildren();
    const playlists = playlistStore.custom();
    if (!playlists.length) {
      const empty = el("option", "", "No custom playlists yet");
      empty.value = "";
      playlistListEl.append(empty);
      playlistListEl.disabled = true;
      return;
    }
    playlistListEl.disabled = false;
    if (!playlists.some((playlist) => playlist.id === selectedPlaylistId)) {
      selectedPlaylistId = playlists[0].id;
    }
    for (const playlist of playlists) {
      const option = el(
        "option",
        "",
        `${playlist.name} — ${playlist.presetIds.length} preset${playlist.presetIds.length === 1 ? "" : "s"}`
      );
      option.value = playlist.id;
      playlistListEl.append(option);
    }
    playlistListEl.value = selectedPlaylistId;
  }

  function renderPlaylistEditor() {
    if (!editorEl) return;
    editorEl.replaceChildren();
    const playlists = playlistStore.custom();
    const playlist = playlists.find((item) => item.id === selectedPlaylistId) || playlists[0] || null;
    selectedPlaylistId = playlist?.id || "";
    if (!playlist) {
      editorEl.append(el("div", "preset-manager-empty", "Create a playlist to begin choosing presets."));
      return;
    }

    const presets = getAllPresets();
    const presetsById = new Map(presets.map((preset) => [Number(preset.id), preset]));
    let orderedIds = playlist.presetIds
      .map(Number)
      .filter((id) => presetsById.has(id));

    const header = el("div", "preset-manager-editor-header");
    const heading = el("div", "preset-manager-editor-title");
    heading.append(el("h3", "", "Preset order"));
    const summary = el("span", "preset-manager-help");
    heading.append(summary);
    header.append(heading);

    const addArea = el("div", "preset-manager-add-row");
    const selectWrap = el("label", "preset-manager-field");
    selectWrap.append(el("span", "", "Add a preset"));
    const select = document.createElement("select");
    const placeholder = el("option", "", "Select a preset…");
    placeholder.value = "";
    select.append(placeholder);
    for (const preset of presets) {
      const option = el("option", "", `${preset.name}${preset.imported ? " (Imported)" : ""}`);
      option.value = String(preset.id);
      option.disabled = orderedIds.includes(Number(preset.id));
      select.append(option);
    }
    selectWrap.append(select);
    const add = el("button", "preset-manager-button primary", "Add");
    add.type = "button";
    add.disabled = true;
    select.addEventListener("change", () => { add.disabled = !select.value; });
    addArea.append(selectWrap, add);

    const orderList = el("div", "preset-manager-order-list");
    let draggedId = null;

    function renderOrderList() {
      orderList.replaceChildren();
      summary.textContent = `${playlist.name} · ${orderedIds.length} preset${orderedIds.length === 1 ? "" : "s"} · drag to reorder`;
      if (!orderedIds.length) {
        orderList.append(el("div", "preset-manager-empty", "This playlist is empty. Add a preset above."));
      }
      for (const id of orderedIds) {
        const preset = presetsById.get(id);
        const row = el("div", "preset-manager-order-row");
        row.draggable = true;
        row.dataset.presetId = String(id);
        const handle = el("span", "preset-manager-drag-handle", "⋮⋮");
        handle.setAttribute("aria-hidden", "true");
        const name = el("span", "preset-manager-order-name", preset?.name || `Preset ${id}`);
        if (preset?.imported) name.append(el("small", "preset-manager-badge", "Imported"));
        const remove = el("button", "preset-manager-button icon subtle", "×");
        remove.type = "button";
        remove.setAttribute("aria-label", `Remove ${preset?.name || `preset ${id}`}`);
        remove.addEventListener("click", () => {
          orderedIds = orderedIds.filter((presetId) => presetId !== id);
          renderOrderList();
          rebuildPresetOptions();
        });
        row.addEventListener("dragstart", (event) => {
          draggedId = id;
          row.classList.add("dragging");
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData("text/plain", String(id));
        });
        row.addEventListener("dragend", () => {
          draggedId = null;
          row.classList.remove("dragging");
          orderList.querySelectorAll(".drag-over").forEach((item) => item.classList.remove("drag-over"));
        });
        row.addEventListener("dragover", (event) => {
          if (draggedId === null || draggedId === id) return;
          event.preventDefault();
          row.classList.add("drag-over");
        });
        row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
        row.addEventListener("drop", (event) => {
          event.preventDefault();
          row.classList.remove("drag-over");
          if (draggedId === null || draggedId === id) return;
          const fromIndex = orderedIds.indexOf(draggedId);
          const toIndex = orderedIds.indexOf(id);
          orderedIds.splice(fromIndex, 1);
          orderedIds.splice(toIndex, 0, draggedId);
          renderOrderList();
        });
        row.append(handle, name, remove);
        orderList.append(row);
      }
    }

    function rebuildPresetOptions() {
      for (const option of select.options) {
        if (!option.value) continue;
        option.disabled = orderedIds.includes(Number(option.value));
      }
      select.value = "";
      add.disabled = true;
    }

    add.addEventListener("click", () => {
      const id = Number(select.value);
      if (!Number.isFinite(id) || orderedIds.includes(id)) return;
      orderedIds.push(id);
      renderOrderList();
      rebuildPresetOptions();
    });

    const footer = el("div", "preset-manager-editor-footer");
    const reset = el("button", "preset-manager-button subtle", "Cancel changes");
    reset.type = "button";
    reset.addEventListener("click", renderPlaylistEditor);
    const save = el("button", "preset-manager-button primary", "Save changes");
    save.type = "button";
    save.addEventListener("click", () => {
      playlistStore.update(playlist.id, { presetIds: orderedIds });
      // Do not interrupt the visual currently on screen just because it was
      // removed from this playlist. The next explicit or automatic change
      // chooses from the newly saved playlist.
      refreshMainUi?.(undefined, { preserveActivePreset: true });
      renderPlaylists();
      renderPlaylistEditor();
      setStatus(`Saved ${playlist.name}.`, "success");
    });
    footer.append(reset, save);

    renderOrderList();
    editorEl.append(header, addArea, orderList, footer);
  }

  function render() {
    if (!root) return;
    root.replaceChildren();
    const panel = el("section", "preset-manager-window");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.setAttribute("aria-labelledby", "preset-manager-title");
    panel.addEventListener("pointerdown", (event) => event.stopPropagation());
    panel.addEventListener("click", (event) => event.stopPropagation());

    const header = el("div", "preset-manager-header");
    const title = el("div", "preset-manager-title");
    const heading = el("h2", "", "Preset Manager");
    heading.id = "preset-manager-title";
    title.append(heading, el("span", "", allowJsonPresetImports ? "Import JSON presets and build playback playlists" : "Build playback playlists"));
    const closeButton = el("button", "preset-manager-button icon subtle", "×");
    closeButton.type = "button";
    closeButton.setAttribute("aria-label", "Close preset manager");
    closeButton.addEventListener("click", close);
    header.append(title, closeButton);
    statusEl = el("div", "preset-manager-status");
    statusEl.hidden = true;

    const body = el("div", "preset-manager-body");
    const navigation = el("nav", "preset-manager-nav");
    navigation.setAttribute("aria-label", "Preset Manager sections");
    presetsNavButton = el("button", "preset-manager-nav-button", "Presets");
    presetsNavButton.type = "button";
    presetsNavButton.addEventListener("click", () => showView("presets"));
    playlistsNavButton = el("button", "preset-manager-nav-button", "Visual Preset Playlists");
    playlistsNavButton.type = "button";
    playlistsNavButton.addEventListener("click", () => showView("playlists"));
    countsEl = el("span", "preset-manager-nav-counts");
    if (allowJsonPresetImports) navigation.append(presetsNavButton);
    navigation.append(playlistsNavButton, countsEl);

    const content = el("div", "preset-manager-content");
    presetsViewEl = el("section", "preset-manager-view");
    const presetToolbar = el("div", "preset-manager-toolbar");
    const presetToolbarCopy = el("div", "preset-manager-toolbar-copy");
    presetToolbarCopy.append(el("h3", "", "Imported presets"), el("span", "", "Stored locally on this Mac"));
    const importActions = el("div", "preset-manager-toolbar-actions");
    const importButton = el("button", "preset-manager-button subtle", "Import JSON");
    importButton.type = "button";
    importButton.addEventListener("click", () => {
      const nativeApp = nativeAppBridge?.();
      if (nativeApp) {
        setStatus("Opening JSON preset picker...");
        nativeApp.postMessage({ command: "openPresetJsonFile" });
      } else {
        setStatus("Preset import is available in the macOS app.", "error");
      }
    });
    importActions.append(importButton);
    presetToolbar.append(presetToolbarCopy, importActions);
    importedListEl = el("div", "preset-manager-list");
    presetsViewEl.append(presetToolbar, importedListEl);

    playlistsViewEl = el("section", "preset-manager-view");
    const playlistToolbar = el("div", "preset-manager-toolbar");
    const playlistToolbarCopy = el("div", "preset-manager-toolbar-copy");
    playlistToolbarCopy.append(el("h3", "", "Visual Preset Playlists"), el("span", "", "Choose presets and arrange their playback order"));
    const create = el("button", "preset-manager-button primary", "New visual preset playlist");
    create.type = "button";
    create.addEventListener("click", () => {
      requestPlaylistName({
        title: "New visual preset playlist",
        initialName: "New Playlist",
        confirmLabel: "Create playlist",
        onConfirm: (name) => {
          const playlist = playlistStore.create(name);
          selectedPlaylistId = playlist.id;
          refreshMainUi?.();
          renderPlaylists();
          renderPlaylistEditor();
          setStatus(`Created ${playlist.name}.`, "success");
        }
      });
    });
    playlistToolbar.append(playlistToolbarCopy, create);
    const playlistSelector = el("div", "preset-manager-playlist-selector");
    const playlistField = el("label", "preset-manager-field");
    playlistField.append(el("span", "", "Editing playlist"));
    playlistListEl = document.createElement("select");
    playlistListEl.addEventListener("change", () => {
      selectedPlaylistId = playlistListEl.value;
      renderPlaylistEditor();
    });
    playlistField.append(playlistListEl);
    const playlistActions = el("div", "preset-manager-row-actions");
    const rename = el("button", "preset-manager-button subtle", "Rename");
    rename.type = "button";
    rename.addEventListener("click", () => {
      const playlist = playlistStore.custom().find((item) => item.id === selectedPlaylistId);
      if (!playlist) return;
      requestPlaylistName({
        title: "Rename visual preset playlist",
        initialName: playlist.name,
        confirmLabel: "Rename visual preset playlist",
        onConfirm: (name) => {
          playlistStore.update(playlist.id, { name });
          refreshMainUi?.();
          renderPlaylists();
          renderPlaylistEditor();
          setStatus(`Renamed playlist to ${name}.`, "success");
        }
      });
    });
    const deleteButton = el("button", "preset-manager-button danger", "Delete");
    deleteButton.type = "button";
    deleteButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const playlist = playlistStore.custom().find((item) => item.id === selectedPlaylistId);
      if (!playlist) return;
      confirmAction(`Delete the playlist “${playlist.name}”? Presets in it will not be deleted.`, "Delete visual preset playlist", () => {
        playlistStore.remove(playlist.id);
        selectedPlaylistId = "";
        refreshMainUi?.(CYANESCENT_PRESETS_PLAYLIST_ID);
        renderPlaylists();
        renderPlaylistEditor();
        setStatus(`Deleted playlist ${playlist.name}.`, "success");
      });
    });
    playlistActions.append(rename, deleteButton);
    playlistSelector.append(playlistField, playlistActions);
    editorEl = el("div", "preset-manager-editor");
    playlistsViewEl.append(playlistToolbar, playlistSelector, editorEl);

    if (allowJsonPresetImports) content.append(presetsViewEl);
    content.append(playlistsViewEl);
    body.append(navigation, content);
    panel.append(header, statusEl, body);
    root.append(panel);

    renderImportedPresets();
    renderPlaylists();
    renderPlaylistEditor();
    updateCounts();
    showView(allowJsonPresetImports ? activeView : "playlists");
  }

  root?.addEventListener("click", (event) => {
    if (event.target === root) close();
  });

  return {
    open,
    close,
    render,
    setStatus,
    importPresetText
  };
}
