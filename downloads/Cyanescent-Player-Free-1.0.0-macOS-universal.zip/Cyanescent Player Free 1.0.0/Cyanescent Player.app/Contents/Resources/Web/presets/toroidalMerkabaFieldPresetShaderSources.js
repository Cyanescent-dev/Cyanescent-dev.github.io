// Toroidal Merkaba Field (preset 176): The Recursive Crystal Temple.
//
// The temple is the original's: a lattice of 6-unit cells, each holding a four-level reflect-scale
// IFS (abs fold, x2, minus a fold offset) that ends in octahedral studs, every cube spun about its
// centre, and a cylinder carved along z so the column the camera flies through becomes a run of
// apertures. What changed (see docs/TOROIDAL_MERKABA_FIELD.md):
//   - the camera's position was time * 2 + globalEnergy * 2 (every energy change jumped it) and the
//     cubes' spin and fold offsets read globalEnergy directly; motion now comes from accumulated
//     phases in toroidalMerkabaDirector.js (tmf* uniforms)
//   - the camera swayed 1.5 units off an aperture of radius 1.5, so it flew through the walls and a
//     "forcefield" max(d, 0.4 - t) erased everything within 0.4 of the eye whatever the ray hit;
//     the camera now stays inside the carved void and the field no longer depends on the ray
//   - each cell's distance ignored its neighbours, so rays near a cell face overshot into the next
//     cube; the field is now bounded by the distance to the cell face plus the gap beyond it, and
//     empty space far from a cube skips the IFS with a bounding sphere
//   - the IFS's extra folds (if (z.x + z.y < 0) ...) never fired after abs(); they are gone and the
//     shape is unchanged
//   - basic diffuse / Blinn shading over a z-cycling rainbow: now a mineral crystal material lit by
//     a key light and a light deep in the aperture, with translucency, grooves between the IFS
//     copies that carry light down and up the recursive levels, and a palette journey
// With no director bound (tmfDir = 0) the shader flies the column at the original's pace.

export function createToroidalMerkabaFieldPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const source = `${modularShaderPrelude}
${modularTransitionShaderBlock}

uniform float tmfDir;
uniform vec4 tmfCam;
uniform mat3 tmfBasis;
uniform vec4 tmfFold;
uniform vec4 tmfForm;
uniform vec4 tmfBreath;
uniform vec4 tmfChamberA;
uniform vec4 tmfChamberB;
uniform vec4 tmfLevels;
uniform vec4 tmfPulseSrc[6];
uniform vec4 tmfPulseShape[6];
uniform vec4 tmfPulseAux[6];
uniform vec4 tmfColA;
uniform vec4 tmfColB;
uniform vec4 tmfColC;
uniform vec4 tmfColD;
uniform vec4 tmfColE;
uniform vec4 tmfLight;
uniform vec4 tmfLight2;

#define TAU 6.28318530718
// 2 pi / 1440: everything that varies along z repeats every 240 cells
#define TMF_KZ 0.00436332313
// per-cell orientation offset and breathing lag (2 pi 34 / 240, 2 pi 21 / 240)
#define TMF_TWIST_K 0.89011791852
#define TMF_BREATH_K 0.54977871438
#define TMF_THRESHOLD 12.0

// per-frame state
vec4 g_fold;
float g_breathAmp;
float g_breathPh;
float g_spinA;
float g_spinB;
float g_twist;
float g_octR;
float g_Rb;
float g_aperture;
vec4 g_chA;
vec4 g_chB;

float tmfHash(vec3 v) {
    uvec3 u = uvec3(ivec3(floor(v)) + 65536);
    uint h = u.x * 1597334677u ^ u.y * 3812015801u ^ u.z * 2798796415u;
    h = (h ^ (h >> 15u)) * 2246822519u;
    h ^= h >> 13u;
    return float(h) * (1.0 / 4294967296.0);
}

// How open the apertures are around a chamber (1 inside it, ramping over TMF_THRESHOLD either side).
float tmfOpen(vec4 c, float z) {
    if (c.w <= 0.0) return 0.0;
    float a = c.x * 6.0 - 3.0;
    float b = c.y * 6.0 + 3.0;
    return smoothstep(a - TMF_THRESHOLD, a, z) * (1.0 - smoothstep(b, b + TMF_THRESHOLD, z));
}

float tmfAperture(float z) {
    float r = (1.5 + 0.18 * sin(5.0 * TMF_KZ * z + 0.7) + 0.1 * sin(13.0 * TMF_KZ * z + 2.0)) * g_aperture;
    return r + 0.45 * (tmfOpen(g_chA, z) + tmfOpen(g_chB, z));
}

// Chambers omit the cubes of the 3x3 block of columns around the axis (a nave, or a longer grand hall).
bool tmfRemovedIn(vec4 c, vec3 id) {
    if (c.w <= 0.0 || id.z < c.x - 0.5 || id.z > c.y + 0.5) return false;
    return max(abs(id.x), abs(id.y)) < 1.5;
}

// Inside a chamber's empty block every cube is beyond the block's walls plus the gap around a cube.
float tmfHall(vec4 c, vec3 p) {
    float inside = min(9.0 - max(abs(p.x), abs(p.y)), min(p.z - (c.x * 6.0 - 3.0), c.y * 6.0 + 3.0 - p.z));
    return inside + 3.0 - g_Rb;
}

vec3 tmfOrient(vec3 l, float zId) {
    vec3 q = l;
    q.xy = rot(g_spinA + g_twist * sin(zId * TMF_TWIST_K)) * q.xy;
    q.yz = rot(g_spinB) * q.yz;
    return q;
}

// fold offsets breathing along the corridor, lagging from coarse to fine levels
vec4 tmfFoldOf(float zId) {
    return g_fold * (1.0 + g_breathAmp * sin(g_breathPh - zId * TMF_BREATH_K - vec4(0.0, 0.7, 1.4, 2.1)));
}

// The original IFS: reflect into the positive octant, double, step back by the fold offset; four
// times, then an octahedron.
float tmfIfs(vec3 q, vec4 k) {
    for (int i = 0; i < 4; i++) q = abs(q) * 2.0 - k[i];
    q = abs(q);
    return (q.x + q.y + q.z - g_octR) * 0.57735027 * 0.0625;
}

float tmfMap(vec3 p) {
    vec3 id = floor((p + 3.0) / 6.0);
    vec3 l = p - id * 6.0;
    // the neighbouring cubes on this side of the cell, by their bounding spheres (a cube never leaves
    // its own cell, so these are exact lower bounds and let rays stride through the gaps)
    vec3 sl = l - (step(0.0, l) * 2.0 - 1.0) * 6.0;
    float nb = min(min(length(vec3(sl.x, l.y, l.z)), length(vec3(l.x, sl.y, l.z))), length(vec3(l.x, l.y, sl.z)));
    nb = min(nb, min(min(length(vec3(sl.xy, l.z)), length(vec3(sl.x, l.y, sl.z))), min(length(vec3(l.x, sl.yz)), length(sl))));
    float d = nb - g_Rb;
    if (tmfRemovedIn(g_chA, id)) d = max(d, tmfHall(g_chA, p));
    else if (tmfRemovedIn(g_chB, id)) d = max(d, tmfHall(g_chB, p));
    else {
        float r = length(l);
        if (r > g_Rb + 0.25) d = min(d, r - g_Rb);
        else d = min(d, tmfIfs(tmfOrient(l, id.z), tmfFoldOf(id.z)));
    }
    float tunnel = length(p.xy) - tmfAperture(p.z);
    return max(d, -tunnel);
}

vec3 tmfNormal(vec3 p, float e) {
    const vec2 k = vec2(1.0, -1.0);
    return normalize(k.xyy * tmfMap(p + k.xyy * e) + k.yyx * tmfMap(p + k.yyx * e) +
                     k.yxy * tmfMap(p + k.yxy * e) + k.xxx * tmfMap(p + k.xxx * e));
}

// The IFS again at a surface point, keeping what the shading needs: per level, the distance (world
// units) to that level's mirror planes, i.e. the grooves between its eight copies; the stud's own
// coordinates; and an address of the copies the point lies in (level 1 and the finest level).
vec4 tmfGrooves(vec3 q, vec4 k, out vec3 qf, out vec2 addr) {
    vec4 g;
    float sc = 1.0;
    addr = vec2(0.0);
    for (int i = 0; i < 4; i++) {
        vec3 o = step(0.0, q);
        float oct = dot(o, vec3(1.0, 2.0, 4.0));
        if (i < 2) addr.x = addr.x * 8.0 + oct;
        addr.y = addr.y * 8.0 + oct;
        q = abs(q);
        g[i] = min(q.x, min(q.y, q.z)) / sc;
        q = q * 2.0 - k[i];
        sc *= 2.0;
    }
    qf = q;
    return g;
}

// Excitation per recursive level at p (front: the bare wavefront): behind each front the levels
// light in turn, coarse to fine (descending pulses) or fine to coarse (ascending, converging pulses).
vec4 tmfCascade(vec3 p, out float front) {
    vec4 e = vec4(0.0);
    front = 0.0;
    for (int i = 0; i < 6; i++) {
        vec4 sh = tmfPulseShape[i];
        if (sh.x < 0.002) continue;
        vec4 src = tmfPulseSrc[i];
        vec4 ax = tmfPulseAux[i];
        vec3 dl = p - src.xyz;
        vec3 ad = abs(dl);
        // a cube-leaning metric, so fronts sweep along the lattice's faces
        float D = mix(length(dl), max(ad.x, max(ad.y, ad.z)), 0.4);
        float x = ax.x * (src.w - D);          // distance behind the front
        float lam = x / sh.y;                   // levels passed
        float lev = sh.z > 0.0 ? lam : 3.0 - lam;
        float env = sh.x * exp(-D / sh.w) * smoothstep(-0.6, 0.0, lam) * exp(-max(lam - 3.4, 0.0) * 1.3);
        vec4 dlev = lev - vec4(0.0, 1.0, 2.0, 3.0);
        e += env * exp(-dlev * dlev * 1.6);
        float xf = x / ax.y;
        front += 0.35 * sh.x * exp(-D / sh.w) * exp(-xf * xf);
    }
    return e;
}

vec3 tmfAces(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

// Filmic curve on luminance, so rose stays rose instead of sliding to salmon; highlights still
// roll off per channel towards white.
vec3 tmfTonemap(vec3 x) {
    float L = max(dot(x, vec3(0.2126, 0.7152, 0.0722)), 1e-5);
    vec3 hue = x * (tmfAces(vec3(L)).x / L);
    vec3 per = tmfAces(x);
    return clamp(mix(hue, per, max(0.3, smoothstep(0.55, 1.0, L))), 0.0, 1.0);
}

void main() {
    float aspect = resolution.x / max(resolution.y, 1.0);
    vec2 sp = (vUv * 2.0 - 1.0) * vec2(aspect, 1.0);

    vec3 ro;
    mat3 basis;
    float tanHalf;
    vec3 colA, colB, colC, colD, colE;
    vec4 levels;
    float fogDen, film, sparkClock, exposure, shimmer, flash, awake, apI, apDist, chamberness, gloss;
    if (tmfDir > 0.5) {
        ro = tmfCam.xyz;
        basis = tmfBasis;
        tanHalf = tmfCam.w;
        g_fold = tmfFold;
        g_spinA = tmfForm.x; g_spinB = tmfForm.y; g_twist = tmfForm.z; g_octR = tmfForm.w;
        g_breathAmp = tmfBreath.x; g_breathPh = tmfBreath.y; g_aperture = tmfBreath.z; g_Rb = tmfBreath.w;
        g_chA = tmfChamberA; g_chB = tmfChamberB;
        levels = tmfLevels;
        colA = tmfColA.rgb; colB = tmfColB.rgb; colC = tmfColC.rgb; colD = tmfColD.rgb; colE = tmfColE.rgb;
        fogDen = tmfColA.w; film = tmfColB.w; sparkClock = tmfColC.w;
        exposure = tmfLight.x; shimmer = tmfLight.y; flash = tmfLight.z; awake = tmfLight.w;
        apI = tmfLight2.x; apDist = tmfLight2.y; chamberness = tmfLight2.z; gloss = tmfLight2.w;
    } else {
        // standalone: fly the column at the original's pace
        float z = 1.5 + presetTime * 2.0;
        ro = vec3(0.25 * sin(presetTime * 0.23), 0.2 * sin(presetTime * 0.17 + 1.1), z);
        vec3 fwd = normalize(vec3(-ro.xy * 0.09, 1.0));
        float roll = 0.16 * sin(presetTime * 0.02);
        vec3 right = normalize(cross(vec3(sin(roll), cos(roll), 0.0), fwd));
        basis = mat3(right, cross(fwd, right), fwd);
        tanHalf = 0.62;
        g_fold = vec4(1.5);
        g_spinA = presetTime * 0.12; g_spinB = presetTime * 0.07; g_twist = 0.1; g_octR = 2.0;
        g_breathAmp = 0.03; g_breathPh = presetTime * 1.9; g_aperture = 1.0; g_Rb = 2.66;
        g_chA = vec4(0.0, -1.0, 0.0, 0.0); g_chB = g_chA;
        levels = vec4(0.5);
        colA = vec3(0.82, 0.46, 0.64); colB = vec3(0.48, 0.10, 0.32); colC = vec3(1.00, 0.62, 0.62);
        colD = vec3(1.00, 0.90, 0.80); colE = vec3(0.040, 0.010, 0.036);
        fogDen = 0.03; film = 0.0; sparkClock = presetTime * 5.0;
        exposure = 1.0; shimmer = 0.3; flash = 0.0; awake = 0.35; apI = 1.0; apDist = 8.5; chamberness = 0.0; gloss = 0.3;
    }
    vec3 rd = normalize(basis * vec3(sp * tanHalf, 1.0));
    float pix = 2.0 * tanHalf / max(resolution.y, 1.0);

    // ---- march ----------------------------------------------------------------------------------------
    int maxSteps = quality > 0.5 ? 128 : 96;
    float tMax = 38.0 + 8.0 * chamberness;
    float t = 0.02;
    float d = 1.0;
    bool hit = false;
    float glow = 0.0;
    int steps = 0;
    for (int i = 0; i < 128; i++) {
        if (i >= maxSteps) break;
        steps = i;
        d = tmfMap(ro + rd * t);
        glow += exp(-max(d, 0.0) * 14.0) * min(d, 0.4);
        if (d < max(0.0005, t * pix * 0.45)) { hit = true; break; }
        t += d * 0.92;
        if (t > tMax) break;
    }
    // a ray that ran out of steps right beside a surface is a hit, not a hole
    bool exhausted = !hit && t < tMax;
    if (exhausted && d < max(0.004, t * pix * 3.0)) hit = true;
    t = min(t, tMax);

    vec3 fogC = colE;
    vec3 col = fogC;
    vec3 V = -rd;
    vec3 apPos = vec3(0.0, 0.0, ro.z + apDist);
    vec3 apCol = mix(colC, colD, 0.35) * apI;
    vec3 dbg = vec3(0.0);
    if (hit) {
        vec3 p = ro + rd * t;
        float foot = t * pix;
        vec3 n = tmfNormal(p, max(0.0012, foot * 0.75));
        vec3 id = floor((p + 3.0) / 6.0);
        vec3 l = p - id * 6.0;
        vec3 q = tmfOrient(l, id.z);
        vec3 qf;
        vec2 addr;
        vec4 g = tmfGrooves(q, tmfFoldOf(id.z), qf, addr);
        float ndv = clamp(dot(n, V), 0.0, 1.0);

        // occlusion (two taps) and thickness behind the surface (thin crystal lets light through)
        float ao = clamp(0.3 + 0.7 * (0.5 * tmfMap(p + n * 0.07) / 0.07 + 0.5 * tmfMap(p + n * 0.22) / 0.22), 0.0, 1.0);
        float thin = 1.0 - clamp(-tmfMap(p - n * 0.07) / 0.07, 0.0, 1.0);
        thin *= thin;

        // mineral body: slabs of the first level vary between rose and pearl, studs a little
        float h1 = tmfHash(id * 1.7 + vec3(addr.x, 3.1, 0.7));
        float h2 = tmfHash(id * 2.3 + vec3(addr.y, 1.3, 5.9));
        vec3 albedo = mix(colA, mix(colA, colD, 0.6), 0.55 * h1) * (0.86 + 0.2 * h2);

        // lights: a soft world key from above, and the light deep in the aperture
        vec3 Lk = normalize(vec3(-0.35, 0.8, -0.3));
        vec3 keyCol = mix(colD, vec3(0.9, 0.93, 1.0), 0.65) * 1.1 / (1.0 + 0.002 * t * t);
        vec3 toAp = apPos - p;
        float apD2 = dot(toAp, toAp);
        vec3 La = toAp * inversesqrt(apD2);
        float apAtt = 1.0 / (1.0 + 0.09 * apD2);
        float wrapK = clamp((dot(n, Lk) + 0.12) / 1.12, 0.0, 1.0);
        float wrapA = clamp((dot(n, La) + 0.25) / 1.25, 0.0, 1.0);
        vec3 diff = keyCol * wrapK + apCol * wrapA * apAtt * 8.0;
        // hemisphere ambient: deep tint below, pale above
        vec3 amb = mix(colB * 0.12, mix(colE, colD, 0.12) * 1.2, n.y * 0.5 + 0.5);
        col = albedo * (diff * 0.6 + amb) * ao;
        // facets turned from the light fall into the stone's deep colour, not grey
        col += colB * 0.12 * (1.0 - wrapK) * ao * ao;
        // translucency: light from the aperture glowing through thin crystal, tinted by its depth
        float back = 0.35 + 0.65 * clamp(dot(-n, La), 0.0, 1.0);
        col += colB * mix(albedo, vec3(1.0), 0.3) * thin * back * apAtt * apI * 1.6;

        // specular: a mineral polish, not chrome (Schlick Fresnel, normalised Blinn lobes)
        float rough = mix(0.3, 0.18, gloss);
        float m = 2.0 / (rough * rough * rough * rough) - 2.0;
        float fr = 1.0 - ndv;
        float F = 0.045 + 0.955 * fr * fr * fr * fr * fr;
        vec3 Hk = normalize(Lk + V);
        vec3 Ha = normalize(La + V);
        float sk = (m + 8.0) / 25.13 * pow(max(dot(n, Hk), 0.0), m) * max(dot(n, Lk), 0.0);
        float sa = (m + 8.0) / 25.13 * pow(max(dot(n, Ha), 0.0), m) * max(dot(n, La), 0.0) * apAtt * 6.0;
        col += (keyCol * sk + apCol * sa) * F * 1.6 * ao;
        // reflection of the temple's air: dark, with the aperture's glow down the axis
        vec3 r = reflect(rd, n);
        float axisGlow = pow(max(r.z * sign(apPos.z - p.z), 0.0), 6.0);
        vec3 env = mix(colE * 1.5, colB * 0.4, r.y * 0.5 + 0.5) + apCol * axisGlow * 0.6;
        col += env * F * ao;
        // opalescence on grazing facets, and a restrained rim
        vec3 filmCol = 0.5 + 0.5 * cos(TAU * (vec3(0.0, 0.33, 0.67) + 1.6 * ndv + film * 0.1 + h2 * 0.3));
        col += filmCol * F * 0.12 * ao;
        col += colD * fr * fr * fr * fr * 0.12 * (0.5 + awake) * ao;

        // light in the grooves between the IFS copies: each level a grid of seams, thinner for finer
        // levels and faded once it is a few pixels across; cascades run through them level by level
        float front;
        vec4 casc = tmfCascade(p, front);
        casc = casc / (1.0 + 0.4 * casc);
        vec4 sizes = vec4(1.5, 0.75, 0.375, 0.1875);
        vec4 w = max(sizes * 0.07, vec4(foot * 0.8));
        vec4 lod = smoothstep(vec4(2.5), vec4(7.0), sizes / max(foot, 1e-5));
        vec4 line = exp(-g / w) + 0.3 * exp(-g / (w * 4.0));
        // a cascade also lights the faces of the copies at its level, softly
        vec4 lev = line * lod * ((0.12 + 0.5 * awake) * levels + 5.0 * casc) + 0.08 * casc * lod;
        // coarse seams burn a paler gold, fine ones the glow colour
        vec3 seam = mix(colC, colD, 0.3) * lev.x + mix(colC, colD, 0.12) * lev.y + colC * (lev.z + lev.w);
        col += seam * (0.6 + 0.4 * ao);
        // and the light of a passing cascade glows through thin crystal
        col += colC * dot(casc, vec4(0.35, 0.3, 0.25, 0.2)) * thin * 0.9;
        dbg = casc.xyz;

        // the bare front: a soft wash of light on the crystal as it passes
        col += colC * front * (0.25 + 0.5 * thin);

        // internal luminescence: light gathering inside the crystal (builds, drops)
        col += colC * awake * (0.03 + 0.15 * thin) * (0.6 + 0.4 * levels.z);

        // highs: stud tips catch sparkles
        vec3 aq = abs(qf);
        float tip = smoothstep(0.7, 0.98, max(aq.x, max(aq.y, aq.z)) / g_octR) * smoothstep(1.5, 4.0, 0.125 / max(foot, 1e-5));
        float spark = step(1.0 - 0.05 * shimmer, tmfHash(id * 3.1 + vec3(addr.y * 0.37, floor(sparkClock), addr.x)));
        col += colD * tip * spark * (1.5 + 3.0 * shimmer) * (0.4 + 0.6 * ndv);

        float fogT = exp(-t * fogDen * 2.6);
        col = mix(fogC, col, fogT);
        col = mix(col, fogC, smoothstep(tMax * 0.75, tMax, t));
    }

    // in-scattering of the aperture light along the ray (closed form for a point light in thin air)
    float s0 = dot(apPos - ro, rd);
    float hh = max(length(ro + rd * s0 - apPos), 1.3);
    float tEnd = hit ? t : tMax;
    float scat = (atan((tEnd - s0) / hh) - atan(-s0 / hh)) / hh;
    // (capped: builds gather light in the crystal, not in a fog sun)
    col += mix(colC, colD, 0.35) * min(apI, 1.3) * scat * 0.04;
    // the original's soft halo around the crystal
    col += mix(colB, colC, 0.4) * glow * 0.012 * (0.3 + awake);
    col += colC * flash * 0.025;

    col *= exposure;
    col += transitionTunnel(sp);
    col *= transitionIdentityPresence();
    col = tmfTonemap(col * 1.3);
    float vig = 1.0 - 0.22 * dot(vUv - 0.5, vUv - 0.5) * 2.0;
    outColor = vec4(col * vig, 1.0);
#ifdef TMF_DEBUG
    if (TMF_DEBUG == 1) outColor = vec4(hit ? (exhausted ? vec3(0.8, 0.8, 0.0) : vec3(0.0, 0.6, 0.0)) : (t >= tMax ? vec3(0.0, 0.0, 0.5) : vec3(1.0, 0.0, 0.0)), 1.0);
    if (TMF_DEBUG == 2) outColor = vec4(vec3(float(steps) / float(maxSteps)), 1.0);
    if (TMF_DEBUG == 3) outColor = vec4(dbg, 1.0);
#endif
}
`;

  return [[176, { name: "Toroidal Merkaba Field", source }]];
}
