export function createCymaticMandalaPresetShaderEntries({
  modularShaderPrelude,
  modularTransitionShaderBlock
}) {
  const cymaticMandalaFragmentSource = `${modularShaderPrelude}
${modularTransitionShaderBlock}

// ═══════════════════════════════════════════════════════
// CYMATIC MANDALA / CYANESCENT CYMATICS (REVERTED)
// ═══════════════════════════════════════════════════════

float samplePackedCell(int png_row, int col, vec2 uv) {
    vec2 clampedUv = clamp(uv, 0.0, 1.0);
    float grid_row = 3.0 - float(png_row);
    vec2 subUv = vec2((float(col) + clampedUv.x) * 0.25, (grid_row + clampedUv.y) * 0.25);
    return texture(presetBackground, subUv).r * 2.0 - 1.0;
}

// Reconstruct the magnified 8-bit foreground field with a small Gaussian
// footprint. All reads stay inside the original atlas cell.
float sampleForegroundCell(int png_row, int col, vec2 uv) {
    vec2 size = vec2(textureSize(presetBackground, 0));
    vec2 cellSize = size * 0.25;
    vec2 origin = vec2(float(col), 3.0 - float(png_row)) * cellSize;
    vec2 centre = origin + clamp(uv, 0.0, 1.0) * cellSize;
    vec2 lo = origin + 0.5;
    vec2 hi = origin + cellSize - 0.5;
    float weights[3] = float[3](0.3125, 0.375, 0.3125);
    float offsets[3] = float[3](-1.2, 0.0, 1.2);
    float value = 0.0;
    for (int y = 0; y < 3; ++y) {
        for (int x = 0; x < 3; ++x) {
            vec2 at = clamp(centre + vec2(offsets[x], offsets[y]), lo, hi) / size;
            value += textureLod(presetBackground, at, 0.0).r * weights[x] * weights[y];
        }
    }
    return value * 2.0 - 1.0;
}

// Foreground Circular Modes (PNG Row 0 & 1)
float sampleForegroundMode(int index, vec2 uv) {
    if (index == 0) return sampleForegroundCell(0, 0, uv);
    if (index == 1) return sampleForegroundCell(0, 1, uv);
    if (index == 2) return sampleForegroundCell(0, 2, uv);
    if (index == 3) return sampleForegroundCell(0, 3, uv);
    if (index == 4) return sampleForegroundCell(1, 0, uv);
    if (index == 5) return sampleForegroundCell(1, 1, uv);
    if (index == 6) return sampleForegroundCell(1, 2, uv);
    return sampleForegroundCell(1, 3, uv);
}

// Background Modes (PNG Row 2: Mode 1993 X-Field, Mode 1990 Detail, Mode 1985 Texture)
float sampleMode1993(vec2 uv) { return samplePackedCell(2, 0, uv); }
float sampleMode1990(vec2 uv) { return samplePackedCell(2, 1, uv); }
float sampleMode1985(vec2 uv) { return samplePackedCell(2, 2, uv); }

// A wider neighbourhood estimates contour strength without amplifying one-texel
// quantisation steps. The source fields and their morph order stay unchanged.
float sampleNodalField(int current, int nextMode, vec2 uv, float blend) {
    vec2 inset = 2.0 / vec2(textureSize(presetBackground, 0));
    vec2 cellUv = clamp(uv, inset, 1.0 - inset);
    float a = samplePackedCell(current / 4, current % 4, cellUv);
    float b = samplePackedCell(nextMode / 4, nextMode % 4, cellUv);
    return mix(a, b, blend);
}

// Controlled Emissive Palette: Electric Cyan -> Deep Blue -> Violet -> Magenta -> Hot Pink
vec3 cyanescentPalette(float pos, float energyFactor) {
    vec3 cyan = vec3(0.0, 0.88, 0.98);
    vec3 deepBlue = vec3(0.08, 0.28, 0.95);
    vec3 violet = vec3(0.60, 0.12, 0.95);
    vec3 magenta = vec3(0.98, 0.08, 0.65);
    vec3 hotPink = vec3(1.0, 0.25, 0.75);

    float p = fract(pos);
    vec3 coolTone = mix(cyan, deepBlue, smoothstep(0.25, 0.75, p));
    vec3 midTone = mix(deepBlue, violet, smoothstep(0.20, 0.70, p));
    vec3 hotTone = mix(violet, magenta, smoothstep(0.15, 0.65, p));
    hotTone = mix(hotTone, hotPink, smoothstep(0.60, 0.92, p));

    vec3 col;
    if (energyFactor < 0.45) {
        col = mix(coolTone, midTone, energyFactor / 0.45);
    } else {
        col = mix(midTone, hotTone, (energyFactor - 0.45) / 0.55);
    }
    return col;
}

void main() {
    // Normalise coordinates to center: [-1.0, 1.0] squared
    vec2 p = (vUv * 2.0 - 1.0) * vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    float r = length(p);

    // Sample previous frame feedback for smooth trails
    vec3 prev = samplePreviousFrame(vUv, p, feedbackRetain(0.85));

    // Dynamic Peak & Energy Factors (0.0 = calm cyan, 1.0 = peak magenta)
    float peakState = max(dropState, max(buildUpState * 0.8, highEnergyState));
    float energyFactor = clamp(globalEnergy * 0.55 + peakState * 0.40 + kickPulse * 0.20, 0.0, 1.0);
    float energyScale = 0.8 + globalEnergy * 0.8 + peakState * 0.4;

    // ═══════════════════════════════════════════════════════
    // THREE-LAYER RESONANT FIELD BACKGROUND (MODE 1993 DOMINANT)
    // ═══════════════════════════════════════════════════════
    
    // Clear, visible kick lighting pulse on background field lines and outer ambient space
    float kickIntensity = max(kickPulse, bass * 0.65);
    float bgRingingPulse = 1.0 + kickIntensity * 3.5;
    float bgOpacityMod = (1.0 + globalEnergy * 0.25) * bgRingingPulse;

    vec3 bgFieldColor = vec3(0.0);

    // --- Layer 1: Dominant Mode 1993 X-Field (+2.0 deg/sec clockwise) ---
    float angleL1 = presetTime * 0.0349 + kickIntensity * 0.008;
    vec2 qL1 = rot(angleL1) * p / 2.20;
    vec2 sampleUvL1 = qL1 * 0.5 + 0.5;
    
    float fieldL1 = sampleMode1993(sampleUvL1);
    float distL1 = abs(fieldL1);
    float lineL1 = smoothstep(0.010, 0.001, distL1);
    float glowL1 = exp(-distL1 * 12.0) * (0.7 + mids * 0.4);
    vec3 colL1 = cyanescentPalette(qL1.x * 0.08 + presetTime * 0.012, energyFactor * 0.65);
    bgFieldColor += colL1 * (lineL1 * 0.75 + glowL1 * 0.5) * 0.38 * bgOpacityMod;

    // --- Layer 2: Medium Detail Field - Mode 1990 (-1.0 deg/sec anticlockwise) ---
    float angleL2 = -presetTime * 0.0175 - kickIntensity * 0.004;
    vec2 qL2 = rot(angleL2) * p / 1.60;
    vec2 sampleUvL2 = qL2 * 0.5 + 0.5;
    
    float fieldL2 = sampleMode1990(sampleUvL2);
    float distL2 = abs(fieldL2);
    float lineL2 = smoothstep(0.007, 0.001, distL2);
    float glowL2 = exp(-distL2 * 16.0) * (0.5 + mids * 0.5);
    vec3 colL2 = cyanescentPalette(qL2.y * 0.12 + presetTime * 0.015 + 0.33, energyFactor * 0.55);
    bgFieldColor += colL2 * (lineL2 * 0.55 + glowL2 * 0.45) * 0.16 * bgOpacityMod;

    // --- Layer 3: Fine Texture Field - Mode 1985 (+0.4 deg/sec clockwise) ---
    float angleL3 = presetTime * 0.0070;
    vec2 qL3 = rot(angleL3) * p * 1.80;
    vec2 sampleUvL3 = qL3 * 0.5 + 0.5;
    
    float fieldL3 = sampleMode1985(sampleUvL3);
    float distL3 = abs(fieldL3);
    float texL3 = exp(-distL3 * 20.0) * (1.0 + highs * 0.5);
    vec3 colL3 = cyanescentPalette(length(qL3) * 0.1 + presetTime * 0.008 + 0.66, energyFactor * 0.4);
    bgFieldColor += colL3 * texL3 * 0.08 * bgOpacityMod;

    // Outer screen edge fade out
    float edgeAtten = smoothstep(2.6, 1.4, r);
    bgFieldColor *= edgeAtten;

    // Visible outer background kick illumination (shaped to shine around the foreground plate)
    float outerKickRing = smoothstep(0.75, 1.35, r) * exp(-abs(r - 1.25) * 1.8) * kickIntensity * 0.45;
    vec3 outerKickColor = cyanescentPalette(r * 0.15 + presetTime * 0.02, energyFactor * 0.85) * outerKickRing;

    // Ambient void background + faint radial aura + outer kick lighting
    float ambientAura = exp(-r * 1.5) * (0.018 + globalEnergy * 0.025 + peakState * 0.02);
    vec3 bgAuraColor = cyanescentPalette(r * 0.12 + presetTime * 0.015, energyFactor * 0.6) * ambientAura;
    vec3 bgWithResonantField = vec3(0.001, 0.0012, 0.0025) * (1.0 - r * 0.35) + bgAuraColor + outerKickColor + bgFieldColor;

    // ═══════════════════════════════════════════════════════
    // FOREGROUND CYMATIC MANDALA (100% OPAQUE OCCLUSION)
    // ═══════════════════════════════════════════════════════
    
    float angle = presetTime * 0.015 + sin(presetTime * 0.08) * 0.03;
    float zoom = 1.05 + 0.02 * sin(time * 0.20);
    vec2 q = rot(angle) * p * zoom;
    
    float q_r = length(q);
    float q_a = atan(q.y, q.x);
    
    // Bass-driven breathing expansion / contraction
    float breathe = 1.0 - (0.02 + bass * 0.07 + u_slowBass * 0.008) * sin(time * 1.2);
    q_r *= breathe;
    
    // Angular deformation waves
    float bassWobble = sin(q_a * 6.0 + time * 1.2) * (0.01 + bass * 0.03) * energyScale;
    float midWobble = cos(q_a * 10.0 - time * 2.5) * (mids * 0.022) * energyScale;
    float highShimmer = sin(q_a * 45.0 + time * 20.0) * (highs * 0.004) * energyScale;
    // Angular displacement must vanish at the origin; otherwise a negative
    // radius folds the centre into the fan-shaped wedges seen during morphs.
    float centreEnvelope = smoothstep(0.0, 0.18, q_r);
    q_r += (bassWobble + midWobble + highShimmer) * centreEnvelope;
    
    // Kick-driven radial shockwave
    float kickRipple = sin(q_r * 14.0 - time * 8.0) * 0.045 * kickPulse * smoothstep(0.05, 0.95, q_r) * energyScale;
    q_r += kickRipple;
    
    // Active morph progression
    float morphSpeed = 0.18 + globalEnergy * 0.12 + peakState * 0.15;
    float morphTime = presetTime * morphSpeed + u_slowBass * 0.20;
    float progress = mod(morphTime, 8.0);
    int idxCurrent = int(floor(progress));
    int idxNext = int(mod(float(idxCurrent + 1), 8.0));
    
    float blend = fract(progress);
    float blendSurge = blend + sin(blend * PI) * 0.08 * globalEnergy;
    blendSurge = clamp(smoothstep(0.0, 1.0, blendSurge), 0.0, 1.0);

    // Reconstruct deformed coordinate
    vec2 deformedQ = vec2(cos(q_a), sin(q_a)) * q_r;
    vec2 sampleUv = deformedQ * 0.5 + 0.5;
    
    // Interpolate signed scalar fields
    float valCurrent = sampleForegroundMode(idxCurrent, sampleUv);
    float valNext = sampleForegroundMode(idxNext, sampleUv);
    float mixedField = mix(valCurrent, valNext, blendSurge);
    
    float dist = abs(mixedField);
    // A near-zero scalar value is not a distance to a nodal line: the atlas
    // has almost-flat neutral areas at the centre and rim. Use screen distance
    // to keep those areas from becoming solid white cores. Keep their coloured
    // glow, but suppress white fragments where the 8-bit field has little slope.
    float fieldSlope = length(vec2(dFdx(mixedField), dFdy(mixedField)));
    float nodeDistancePx = dist / max(fieldSlope, 0.000001);
    vec2 slopeStep = vec2(0.012, 0.0);
    vec4 neighbours = vec4(
        sampleNodalField(idxCurrent, idxNext, sampleUv + slopeStep.xy, blendSurge),
        sampleNodalField(idxCurrent, idxNext, sampleUv - slopeStep.xy, blendSurge),
        sampleNodalField(idxCurrent, idxNext, sampleUv + slopeStep.yx, blendSurge),
        sampleNodalField(idxCurrent, idxNext, sampleUv - slopeStep.yx, blendSurge));
    float localRange = max(max(neighbours.x, neighbours.y), max(neighbours.z, neighbours.w))
                     - min(min(neighbours.x, neighbours.y), min(neighbours.z, neighbours.w));
    float nodeSupport = smoothstep(0.015, 0.045, localRange);
    float geometryMask = smoothstep(0.98, 0.95, q_r);
    
    // --- Foreground Layer 1: Luminous Membrane Body ---
    float signedPhase = mixedField * 0.5 + 0.5;
    float fieldBands = 0.5 + 0.5 * sin(mixedField * (10.0 + mids * 6.0) - time * (1.5 + bass * 2.5));
    float fieldIntensity = pow(clamp(abs(mixedField), 0.0, 1.0), 1.2) * (0.6 + 0.4 * fieldBands);
    
    float membraneOpacity = (0.04 + bass * 0.12 + globalEnergy * 0.18 + dropState * 0.22) * (1.0 - smoothstep(0.85, 1.0, q_r)) * geometryMask;
    vec3 membraneTone = cyanescentPalette(signedPhase * 0.4 + q_r * 0.15 + presetTime * 0.02, energyFactor * 0.85);
    vec3 membraneColor = membraneTone * fieldIntensity * membraneOpacity;
    
    // --- Foreground Layer 2: Layered Emissive Lines ---
    float kickTighten = 1.0 - kickPulse * 0.35;
    float coreWidthPx = (0.9 + mids * 0.5) * kickTighten;
    float coreLine = (1.0 - smoothstep(max(coreWidthPx - 0.4, 0.1), coreWidthPx + 0.5, nodeDistancePx)) * geometryMask * nodeSupport;
    vec3 coreColor = mix(mix(vec3(0.92, 0.98, 1.0), vec3(1.0, 0.92, 0.98), energyFactor), vec3(1.0, 1.0, 1.0), kickPulse * 0.6);
    
    float edgeSparkle = smoothstep(0.55, 1.0, sin(q_a * 55.0 + time * 30.0 + dist * 35.0)) * (highs * 0.45) * coreLine;
    vec3 sparkleColor = vec3(0.88, 0.96, 1.0) * edgeSparkle;
    
    float haloFalloff = 32.0 - mids * 10.0;
    float coreGlow = exp(-dist * haloFalloff) * (0.60 + kickPulse * 0.9) * geometryMask;
    float softHalo = exp(-dist * 15.0) * (0.25 + globalEnergy * 0.20 + peakState * 0.20) * geometryMask;
    vec3 haloColor = cyanescentPalette(q_r * 0.15 + presetTime * 0.025, energyFactor);
    
    float auraGlow = exp(-dist * 6.5) * (0.16 + globalEnergy * 0.18 + peakState * 0.15) * geometryMask;
    vec3 auraColor = cyanescentPalette(q_r * 0.1 + presetTime * 0.012 + 0.38, energyFactor * 0.75) * 0.5;
    
    vec3 nodeColor = (coreColor * coreLine + sparkleColor) * (1.0 + kickPulse * 0.25);
    nodeColor += haloColor * (coreGlow * 0.65 + softHalo * 0.35) * (0.85 + globalEnergy * 0.55 + peakState * 0.4);
    nodeColor += auraColor * auraGlow;
    
    // --- Foreground Layer 3: Harmonic Iso-Contour Overtones ---
    float offset1 = 0.14 - mids * 0.03;
    float offset2 = 0.28 - mids * 0.05;
    float ghostDist1 = abs(dist - offset1);
    float ghostDist2 = abs(dist - offset2);
    
    float ghostVisibility = (0.03 + mids * 0.40 + globalEnergy * 0.30 + peakState * 0.25) * geometryMask;
    float ghostLine1 = smoothstep(0.0035, 0.0018, ghostDist1) * ghostVisibility;
    float ghostHalo1 = exp(-ghostDist1 * 36.0) * 0.30 * ghostVisibility;
    
    float ghostLine2 = smoothstep(0.0030, 0.0015, ghostDist2) * ghostVisibility * 0.65;
    float ghostHalo2 = exp(-ghostDist2 * 40.0) * 0.20 * ghostVisibility * 0.65;
    
    vec3 ghostCol1 = cyanescentPalette(q_r * 0.2 + 0.35 + presetTime * 0.02, energyFactor * 0.7);
    vec3 ghostCol2 = cyanescentPalette(q_r * 0.2 + 0.65 + presetTime * 0.02, energyFactor * 0.85);
    
    vec3 harmonicContours = ghostCol1 * (ghostLine1 * 0.7 + ghostHalo1 * 0.4) + ghostCol2 * (ghostLine2 * 0.7 + ghostHalo2 * 0.4);
    
    // --- Foreground Layer 4: Resonant Outer Boundary / Rim ---
    float rimLine = smoothstep(0.005, 0.001, abs(q_r - 1.0));
    float rimHalo = exp(-abs(q_r - 1.0) * 18.0) * (0.40 + bass * 0.5 + peakState * 0.3);
    float rimKickPulse = exp(-abs(q_r - (1.0 + kickPulse * 0.035)) * 34.0) * kickPulse * 0.65;
    vec3 rimColor = cyanescentPalette(0.0 + presetTime * 0.03, energyFactor * 0.9);
    vec3 boundaryCol = rimColor * (rimLine * 0.90 + rimHalo * 0.42 + rimKickPulse * 0.65);
    
    // ═══════════════════════════════════════════════════════
    // 100% OPAQUE FOREGROUND COMPOSITING & OCCLUSION
    // ═══════════════════════════════════════════════════════
    
    // Solid deep void interior base for foreground membrane (prevents background bleed)
    vec3 fgInteriorBase = vec3(0.001, 0.0012, 0.0025);
    vec3 foregroundPlate = fgInteriorBase + nodeColor + harmonicContours + membraneColor + boundaryCol;
    
    // Mask to strictly occlude the background field beneath the foreground plate
    float mask = smoothstep(1.0, 0.985, q_r);
    vec3 finalColor = mix(bgWithResonantField, foregroundPlate, mask);
    
    // Composite with chromatic feedback trails
    vec3 color = mix(prev * 0.85, finalColor, 0.25 + globalEnergy * 0.05);
    
    // Transition overlay and identity presence
    color += transitionTunnel(p);
    color *= transitionIdentityPresence();
    
    // Emissive tone mapping
    outColor = vec4(color / (1.0 + color * 0.28), 1.0);
}
`;

  return [
    [180, { name: "Cymatic Mandala", source: cymaticMandalaFragmentSource }]
  ];
}
