// Living Firepit: the director — the stateful half of preset 388 (pure JS + one bind function).
//
// The shader (livingFirepitPresetShaderSources.js) is stateless; this module keeps the state that
// gives the scene development over time and binds it as uniforms plus one small float texture:
//
//   music model     Player's analysis through the shared newtonBasinAudio model (beat grid, groove,
//                   build, breakdown, drop events that work on loud masters), reduced to a few
//                   timescales: energy (seconds), awakening and the living circle (sustained
//                   energy over phrases), build tension, post-drop surge, breakdown.
//   network         the woven network's light follows its threads; a pattern per phrase, more
//                   active threads as energy is sustained, a sweep through the whole web at a drop.
//   fire            wind (leans the flames, sways the trees), ember rate, the ember column at a drop.
//   hero events     a state machine schedules the constellation animals from the music (a
//                   breakdown calls the deer or the salmon, a build the eagle, a drop the horse, a
//                   major drop gathers several; sustained energy the bison), with cooldowns, minimum
//                   lifetimes and a deterministic fallback when analysis is missing.
//   camera          the original slow orbit, with framing that supports the music and the events.
//   constellations  each frame the active animals are posed (livingFirepitAnimals.js), placed in
//                   the world, projected with the camera and packed as screen-space segments.
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";
import { ANIMALS, clamp, deerBound, deerBoundTravel, eagleStroke, fract, mix, smooth, TAU } from "./livingFirepitAnimals.js";

export const LIVING_FIREPIT_PRESET_ID = 388;
export const LFP_TEX_WIDTH = 256;
export const LFP_TEX_HEIGHT = 32;
export const LFP_CHUNK = 8;                         // segments per chunk
export const LFP_CHUNK_TEXELS = 2 + LFP_CHUNK * 2;  // bbox, header, 8 x (endpoints, style)
export const LFP_MAX_CHUNKS = Math.floor((LFP_TEX_WIDTH * LFP_TEX_HEIGHT) / LFP_CHUNK_TEXELS);
export const LFP_MAX_ANIMALS = 5;
export const LFP_SLOTS = 6;                         // five animals + the fire's particles
const ANIMAL_KINDS = ["eagle", "horse", "bison", "salmon", "deer"];

// ---------- terrain (ported from the shader so the deer stands on the ground) ----------
const fr = (x) => x - Math.floor(x);
function hash12(x, y) {
  let a = fr(x * 0.1031), b = fr(y * 0.1031), c = fr(x * 0.1031);
  const d = a * (b + 33.33) + b * (c + 33.33) + c * (a + 33.33);
  a += d; b += d; c += d;
  return fr((a + b) * c);
}
function noise2(x, y) {
  const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
  const a = hash12(ix, iy), b = hash12(ix + 1, iy), c = hash12(ix, iy + 1), d = hash12(ix + 1, iy + 1);
  return mix(mix(a, b, ux), mix(c, d, ux), uy);
}
export function riverCentre(x) { return -7.4 + 0.9 * Math.sin(x * 0.21 + 0.6) + 0.35 * Math.sin(x * 0.53 + 2.0); }
export function groundHeight(x, z) {
  const r = Math.hypot(x, z);
  let h = noise2(x * 0.16 + 3.1, z * 0.16 + 7.7) * 0.9 * smooth(2.5, 10.0, r);
  h += (noise2(x * 0.7 + 1.3, z * 0.7 + 5.2) - 0.5) * 0.08;
  h += 0.018 * Math.max(r - 7.0, 0.0);
  h -= 0.13 * (1.0 - smooth(0.45, 1.1, r));
  h += 0.035 * Math.exp(-(r - 1.25) * (r - 1.25) * 18.0);
  const rv = Math.abs(z - riverCentre(x));
  const carve = 1.0 - smooth(1.4, 2.9, rv);
  return mix(h, -0.72 + 0.28 * smooth(0.0, 1.5, rv), carve);
}
export const WATER_Y = -0.3;

// The conifers' tips, from the shader's tree placement (jittered 3.2 grid, same hashes), so sky
// animals can be kept clear of the treeline from wherever the camera is.
function hash22(x, y) {
  let a = fr(x * 0.1031), b = fr(y * 0.1030), c = fr(x * 0.0973);
  const d = a * (b + 33.33) + b * (c + 33.33) + c * (a + 33.33);
  a += d; b += d; c += d;
  return [fr((a + b) * c), fr((a + c) * b)];
}
let treeTips = null;
export function coniferTreeTips() {
  if (treeTips) return treeTips;
  treeTips = [];
  const C = 3.2;
  for (let i = -10; i <= 9; i += 1) for (let j = -10; j <= 9; j += 1) {
    const hv = hash22(i + 17, j + 41);
    const x = (i + 0.5) * C + (hv[0] - 0.5) * 0.4, z = (j + 0.5) * C + (hv[1] - 0.5) * 0.4;
    const rr = Math.hypot(x, z);
    const h3 = hash12(i * 1.7 + 3.1, j * 1.7 + 8.3);
    if (rr < 6.6 || rr > 27 || Math.abs(z - riverCentre(x)) < 3.1 || h3 < 0.1) continue;
    const gy = noise2(x * 0.16 + 3.1, z * 0.16 + 7.7) * 0.9 * smooth(2.5, 10, rr) + 0.018 * Math.max(rr - 7, 0);
    treeTips.push([x, gy + 3.8 + 3.0 * h3, z]);
  }
  return treeTips;
}
// Highest elevation angle of the treeline seen from ro within [az0, az1] (world azimuth from ro).
export function treelineElevation(ro, az0, az1) {
  let best = 0.05;
  for (const [x, y, z] of coniferTreeTips()) {
    const dx = x - ro[0], dz = z - ro[2];
    const az = Math.atan2(dz, dx);
    const da = Math.atan2(Math.sin(az - (az0 + az1) / 2), Math.cos(az - (az0 + az1) / 2));
    if (Math.abs(da) > Math.abs(az1 - az0) / 2 + 0.08) continue;
    best = Math.max(best, Math.atan2(y - ro[1], Math.hypot(dx, dz)));
  }
  return best;
}

// ---------- small vector helpers ----------
const v = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
  axes: (o, x, y, z) => [o[0] + x[0] + y[0] + z[0], o[1] + x[1] + y[1] + z[1], o[2] + x[2] + y[2] + z[2]]
};
const rotAxis = (p, axis, a) => {
  const c = Math.cos(a), s = Math.sin(a), d = v.dot(axis, p), cr = v.cross(axis, p);
  return [p[0] * c + cr[0] * s + axis[0] * d * (1 - c), p[1] * c + cr[1] * s + axis[1] * d * (1 - c), p[2] * c + cr[2] * s + axis[2] * d * (1 - c)];
};

// critically damped spring toward a goal (time constant tc seconds)
function spring(state, key, goal, dt, tc) {
  const vk = `${key}V`;
  const w = 2 / Math.max(tc, 1e-3);
  const x = state[key] - goal;
  const vel = state[vk] || 0;
  const temp = (vel + w * x) * dt;
  const e = Math.exp(-w * dt);
  state[vk] = (vel - w * temp) * e;
  state[key] = goal + (x + temp) * e;
}

// deterministic random stream for event choices
function rng(seed) { let s = seed >>> 0 || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }

// ---------- event parameters ----------
const LIFE = { eagle: 21, horse: 15, bison: 17, salmon: 12.2, deer: 24 };   // seconds before dissolving
const FORM = { eagle: 4.5, horse: 4.0, bison: 4.0, salmon: 3.5, deer: 5.0 };
const DISSOLVE = { eagle: 4.5, horse: 4.0, bison: 4.5, salmon: 4.0, deer: 6.5 };
const COOLDOWN = 48;            // per animal (s)
const MIN_GAP = 14;             // between event starts (s)
const FALLBACK_GAP = 68;        // without musical triggers an animal still appears this often

export function createLivingFirepitDirector() {
  const audioModel = createNewtonAudioModel();
  const s = {};
  let events = [];
  let pinned = null;
  let random = rng(388);
  const sparks = [];
  let sparkSerial = 0, sparkDebt = 0, columnDebt = 0;

  function reset() {
    audioModel.reset();
    events = [];
    random = rng(388);
    sparks.length = 0; sparkSerial = 0; sparkDebt = 0; columnDebt = 0;
    Object.assign(s, {
      t: 0, started: false, frame: 0,
      energy: 0.3, energySus: 0.25, levelPeak: 0.3, awaken: 0, circle: 0, build: 0, breakdown: 0, groove: 0,
      surgeAt: -100, surge: 0, surgeMajor: 0, lastSweepAt: -100, sweepStrength: 0,
      phrase: -1, phraseCount: 0, phraseClock: 0, circleSince: null,
      pattern: 0, patternPrev: 0, patternMix: 1, patternAt: -100, travel: 0, activity: 0.2, sector: 0,
      windX: 0.06, windZ: 0.0, gust: 0, treeSway: 0.2, emberRate: 0.25, richness: 0,
      breakdownSince: null, breakdownUsed: false, buildSince: null, buildUsed: false,
      lastEventAt: -100, lastGatherAt: -300, lastBy: {}, eventCount: 0, heroLevel: 0,
      orbit: 1.4, orbitSpeed: 0.12, camR: 4.3, camY: 1.75, tx: 0, ty: 0.95, tz: 0, zoom: 1.75,
      framingPhase: 0, lastKind: "", log: []
    });
  }
  reset();

  // ---------------------------------------------------------------------------------------
  function musicStep(dt, input) {
    const { audio = {}, smooth: bands = {}, music = {} } = input;
    const ev = audioModel.step(dt, { audio, smooth: bands, music }, { beatsPerSecond: 145 / 60 });
    const a = audioModel.state;
    s.beat = a.beat;
    // energy relative to the track's own peak (loud masters saturate absolute levels)
    const raw = clamp(Number(audio.globalEnergy) || Number(music.adaptiveIntensity) || Number(input.slowLevel) || 0);
    s.levelPeak = Math.max(raw, s.levelPeak - dt * s.levelPeak / 100);
    const rel = clamp((raw / Math.max(s.levelPeak, 0.05) - 0.5) / 0.5);
    s.groove = a.groove; s.breakdown = a.breakdown; s.build = a.build;
    const goal = clamp(0.1 + 0.42 * a.groove * (1 - 0.7 * a.breakdown) + 0.22 * rel + 0.3 * s.surge + 0.08 * clamp(Number(music.highEnergy) || 0));
    s.energy = follow(s.energy, goal, dt, 0.8, 2.2);
    // sustained energy: rises over phrases, falls faster
    s.energySus = follow(s.energySus, s.energy, dt, 9, 4);
    s.awaken = smooth(0.3, 0.55, s.energy);
    s.circle = smooth(0.5, 0.68, s.energySus) * (1 - 0.8 * s.breakdown);
    // drops: the groove returning after a break, or the analysis' drop detection with a groove
    let drop = ev.drop > 0;
    if (!drop && (Number(audio.dropDetected) || 0) > 0.5 && a.groove > 0.5 && s.t - s.surgeAt > 20) drop = true;
    if (drop && s.t - s.surgeAt > 8) {
      const major = (s.buildSince !== null && s.t - s.buildSince > 3) || (s.breakdownSince !== null && s.t - s.breakdownSince > 12) || s.buildPeakAt > s.t - 12;
      // the gathering is kept for the biggest release: a drop after a long breakdown
      const epic = (s.breakdownSince !== null && s.t - s.breakdownSince > 14) || (s.t - (s.lastBreakEnd ?? -100) < 8 && (s.lastBreakLen || 0) > 14);
      s.surgeAt = s.t; s.surge = 1; s.surgeMajor = major ? 1 : 0.55;
      s.lastSweepAt = s.t; s.sweepStrength = major ? 1 : 0.7;
      s.log.push(`${s.t.toFixed(1)} drop${major ? " (major)" : ""}`);
      return { drop: true, major, epic, events: ev };
    }
    return { drop: false, major: false, events: ev };
  }

  // ---------------------------------------------------------------------------------------
  function phraseStep(dt, music) {
    const beat = Number(music.absoluteBeat);
    let phrase;
    if (Number.isFinite(beat) && beat > 0) phrase = Math.floor(beat / 32);
    else { s.phraseClock += dt * (145 / 60); phrase = Math.floor(s.phraseClock / 32); }
    const changed = phrase !== s.phrase;
    if (changed) { s.phrase = phrase; s.phraseCount += 1; }
    // beat-locked travel of light along the threads: one thread round every two beats
    const bps = 145 / 60;
    s.travel += dt * bps * (0.25 + 0.35 * s.awaken + 0.4 * s.circle);
    return changed;
  }

  function networkStep(dt, phraseChanged) {
    // patterns: 1 inward, 2 outward, 3 around the rounds, 4 along the spiral, 5 sector call/response
    const cycleHigh = [1, 3, 2, 4, 5, 3, 1, 4];
    const cycleMid = [1, 3, 1, 4];
    if (phraseChanged && s.awaken > 0.35) {
      const list = s.circle > 0.5 ? cycleHigh : cycleMid;
      const next = list[s.phraseCount % list.length];
      if (next !== s.pattern) { s.patternPrev = s.pattern; s.pattern = next; s.patternMix = 0; s.patternAt = s.t; }
    }
    if (s.awaken < 0.15 && s.pattern !== 0 && s.t - s.patternAt > 6) { s.patternPrev = s.pattern; s.pattern = 0; s.patternMix = 0; s.patternAt = s.t; }
    s.patternMix = clamp(s.patternMix + dt / 3.5);
    // active fraction of threads: grows over sustained energy, more in builds; never all of them
    const sustain = s.circleSince === null ? 0 : clamp((s.t - s.circleSince) / 60);
    const goal = clamp(0.12 + 0.3 * s.awaken + 0.2 * s.circle + 0.18 * sustain + 0.2 * s.build, 0.08, 0.82);
    s.activity = follow(s.activity, goal, dt, 2.5, 4);
    s.sector += dt * (0.05 + 0.1 * s.circle);
    s.sweepStrength *= Math.exp(-dt / 5);
  }

  function fireStep(dt) {
    s.surge *= Math.exp(-dt / 7);
    // wind: slow wandering, stronger through builds and the living circle; never kick-driven
    const t = s.t;
    const base = 0.05 + 0.05 * s.awaken + 0.12 * s.build + 0.06 * s.circle;
    const dir = 0.3 + 0.9 * Math.sin(t * 0.021) + 0.4 * Math.sin(t * 0.0071 + 1.0);
    spring(s, "windX", Math.cos(dir) * base, dt, 4);
    spring(s, "windZ", Math.sin(dir) * base * 0.6, dt, 4);
    s.gust = follow(s.gust, 0.5 + 0.5 * Math.sin(t * 0.37) * Math.sin(t * 0.13 + 2), dt, 1.5, 1.5);
    s.treeSway = follow(s.treeSway, 0.15 + 0.35 * s.awaken + 0.5 * s.build + 0.3 * s.circle, dt, 6, 8);
    s.emberRate = follow(s.emberRate, clamp(0.18 + 0.28 * s.awaken + 0.3 * s.circle + 0.22 * s.build + 0.25 * s.surge + 0.15 * s.heroLevel), dt, 1.2, 3);
    s.richness = follow(s.richness, clamp(0.6 * s.circle + 0.3 * s.awaken + 0.3 * s.surge), dt, 3, 5);
  }

  // ---------------------------------------------------------------------------------------
  // hero events
  function viewAz() { return Math.atan2(-Math.sin(s.orbit), -Math.cos(s.orbit)); }
  function startEvent(kind, opt = {}) {
    if (kind === "salmon" && opt.delay === undefined) opt = { ...opt, delay: 3.5 };
    // sky animals form a moment after they are chosen, so the camera is already tilting up
    if ((kind === "horse" || kind === "eagle") && opt.delay === undefined) opt = { ...opt, delay: 1.5 };
    const side = opt.side ?? (random() < 0.5 ? -1 : 1);
    const ev = { kind, at: s.t + (opt.delay || 0), life: (opt.life || LIFE[kind]), side, seed: random(), slot: opt.slot || "solo", az: viewAz() + (opt.azOff ?? 0), elev: opt.elev, radius: opt.radius, phase: 0, path: null };
    events.push(ev);
    planSkyPlacement(ev);
    s.lastBy[kind] = s.t;
    s.lastKind = kind;
    s.eventCount += 1;
    s.log.push(`${s.t.toFixed(1)} ${kind}${opt.slot && opt.slot !== "solo" ? ` (${opt.slot})` : ""}`);
    return ev;
  }
  const active = (kind) => events.find((e) => e.kind === kind && s.t < e.at + e.life + DISSOLVE[kind]);
  const cooled = (kind) => s.t - (s.lastBy[kind] ?? -1e3) > COOLDOWN && !active(kind);
  const busy = () => events.filter((e) => s.t < e.at + e.life).length;
  const leastRecent = (kinds) => kinds.filter(cooled).sort((a, b) => (s.lastBy[a] ?? -1e3) - (s.lastBy[b] ?? -1e3))[0];

  // A sky animal arriving while another is in the sky starts on the other half of the view; a
  // traveller then covers only half the width, and an eagle already there drifts outward on its
  // own side, so their paths do not cross. (The gathering has its own layout.)
  function planSkyPlacement(ev) {
    if (!SKY_KINDS.has(ev.kind) || ev.slot === "gather") return;
    const others = events.filter((o) => o !== ev && SKY_KINDS.has(o.kind) && s.t < o.at + o.life + DISSOLVE[o.kind] * 0.5);
    if (!others.length) return;
    const cam = camera();
    const screenX = (dAz) => {
      const az = viewAz() + dAz, p = [Math.cos(az) * 26, 1.6 + 26 * 0.36, Math.sin(az) * 26];
      const d = v.sub(p, cam.ro);
      return v.dot(d, cam.cu) / Math.max(v.dot(d, cam.cw), 0.1);
    };
    const centre = (o) => (o.box ? (o.box[0] + o.box[2]) / 2 : o.world ? (() => { const d = v.sub(o.world, cam.ro); return v.dot(d, cam.cu) / Math.max(v.dot(d, cam.cw), 0.1); })() : 0);
    const cx = others.reduce((sum, o) => sum + centre(o), 0) / others.length;
    const awaySign = (cx >= 0 ? -1 : 1);                       // the half of the screen to use
    const plus = Math.sign(screenX(0.42)) || 1;                 // screen side of a +azimuth offset
    if (ev.kind === "eagle") ev.azBias = 0.45 * awaySign * plus;
    else { ev.side = awaySign * plus; ev.travel = 0.5; }
    // an eagle already circling moves outward on its own side, out of the newcomer's way
    for (const o of others) if (o.kind === "eagle" && ev.kind !== "eagle") o.azBias = 0.45 * Math.sign(centre(o) || -awaySign) * plus;
    for (const o of others) if (o.kind !== "eagle" && ev.kind !== "eagle") o.travel = Math.min(o.travel ?? 1, 0.5);
  }

  // A gathering: eagle high and central, horse mid-height and the bison low on the horizon (both
  // travelling the same way, the bison behind), the deer at the treeline on the other side.
  function gatherAll(sd) {
    const eagle = active("eagle");
    if (!eagle) { const ev = startEvent("eagle", { slot: "gather", side: -sd, life: 24, delay: 1.5, azOff: 0, elev: 0.42, radius: 3.2 }); ev.azBias = -0.45 * sd; }
    else { eagle.elevGoal = 0.42; eagle.radius = 3.2; eagle.azBias = -0.45 * sd; eagle.life = Math.max(eagle.life, s.t - eagle.at + 22); }
    if (!active("horse")) startEvent("horse", { slot: "gather", side: sd, life: 20, delay: 2.6, azOff: 0.08 * sd, elev: 0.3 });
    if (!active("bison")) startEvent("bison", { slot: "gather", side: sd, life: 22, delay: 2.8 });
    if (!active("deer")) startEvent("deer", { slot: "gather", side: -sd, life: 20, delay: 4.5, azOff: -0.5 * sd });
  }

  function eventsStep(dt, music, drop) {
    // continuous conditions
    if (s.breakdown > 0.6) { if (s.breakdownSince === null) s.breakdownSince = s.t; } else if (s.breakdown < 0.35) { if (s.breakdownSince !== null) { s.lastBreakLen = s.t - s.breakdownSince; s.lastBreakEnd = s.t; } s.breakdownSince = null; s.breakdownUsed = false; }
    if (s.build > 0.5) { if (s.buildSince === null) s.buildSince = s.t; } else if (s.build < 0.25) { if (s.buildSince !== null && s.t - s.buildSince > 2.5) s.buildPeakAt = s.t; s.buildSince = null; s.buildUsed = false; }
    if (s.circle > 0.6) { if (s.circleSince === null) s.circleSince = s.t; } else if (s.circle < 0.35) s.circleSince = null;
    const sinceLast = s.t - s.lastEventAt;
    const can = sinceLast > MIN_GAP && busy() < 2;
    let started = null;
    if (drop.drop) {
      if (drop.epic && s.t - s.lastGatherAt > 150 && s.t > 30) {
        s.lastGatherAt = s.t;
        gatherAll(random() < 0.5 ? 1 : -1);
        started = "gather";
      } else if (cooled("horse") && (busy() < 2) && sinceLast > 6) {
        started = startEvent("horse", { slot: active("eagle") ? "pair" : "solo" }).kind;
      }
    } else if (can && s.t > 12 && s.breakdownSince !== null && !s.breakdownUsed && s.t - s.breakdownSince > 3) {
      s.breakdownUsed = true;
      // the two calm animals take turns (the salmon first): the deer at the treeline, the salmon
      // swimming across the sky
      const kind = active("deer") || active("salmon") ? null : leastRecent(["salmon", "deer"]);
      if (kind) started = startEvent(kind).kind;
    } else if (can && s.buildSince !== null && !s.buildUsed && s.t - s.buildSince > 2.5) {
      s.buildUsed = true;
      const kind = cooled("eagle") ? "eagle" : leastRecent(["salmon", "bison", "horse"]);
      if (kind) started = startEvent(kind, { life: kind === "eagle" ? 26 : undefined }).kind;
    } else if (can && s.circleSince !== null && s.t - s.circleSince > 28 && sinceLast > 34) {
      const kind = leastRecent(["salmon", "bison", "horse", "eagle"]);
      if (kind) started = startEvent(kind).kind;
    } else if (sinceLast > FALLBACK_GAP && s.t > 26 && busy() === 0) {
      // deterministic fallback: rotation by energy so every animal appears in ordinary playback
      const calm = s.energy < 0.45;
      const order = calm ? ["deer", "salmon", "eagle", "bison", "horse"] : ["eagle", "horse", "bison", "deer", "salmon"];
      // least recently shown first (energy order breaks ties), so every animal comes round
      const ranked = order.filter((k) => cooled(k) && k !== s.lastKind).sort((a, b) => (s.lastBy[a] ?? -1e3) - (s.lastBy[b] ?? -1e3));
      const kind = ranked[0];
      if (kind) started = startEvent(kind).kind;
    }
    if (started) s.lastEventAt = s.t;
    events = events.filter((e) => s.t < e.at + e.life + DISSOLVE[e.kind] + 0.5);
  }

  // forced events (tests, trial tool)
  function force(kind) {
    if (kind === "gather") {
      s.lastGatherAt = s.t;
      gatherAll(1);
    } else if (ANIMAL_KINDS.includes(kind) && !active(kind)) startEvent(kind);
    s.lastEventAt = s.t;
  }

  // ---------------------------------------------------------------------------------------
  // camera
  function cameraStep(dt) {
    const t = s.t;
    const SKY_LEAD = { salmon: 3.5, horse: 1.5, eagle: 1.5 };
    const live = events.filter((e) => s.t >= e.at - (SKY_LEAD[e.kind] ?? 1) && s.t < e.at + e.life + DISSOLVE[e.kind] * (SKY_LEAD[e.kind] ? 1.0 : 0.5));
    for (const e of live) if (SKY_LEAD[e.kind] && e.topEst === undefined) e.topEst = e.kind === "eagle" ? 0.8 : 0.72;
    const sky = live.some((e) => e.kind === "eagle" || e.kind === "horse" || e.kind === "salmon");
    const bison = live.find((e) => e.kind === "bison");
    const deer = live.find((e) => e.kind === "deer");
    const gather = live.some((e) => e.slot === "gather");
    // in the living circle the framing alternates every two phrases: wide and high / close and low
    const wide = s.circle * (0.5 + 0.5 * Math.cos(Math.PI * Math.floor(s.phraseCount / 2)));
    const surge = clamp((1 - (t - s.surgeAt) / 9)) * s.surgeMajor;
    let speed = 0.11 + 0.02 * s.awaken + 0.03 * s.circle - 0.03 * s.breakdown + 0.02 * s.build;
    let R = 4.3 + 0.3 * Math.sin(t * 0.067) + 0.9 * wide - 0.35 * s.build * (1 - wide) + 0.35 * surge - 0.2 * s.circle * (1 - wide);
    let Y = 1.75 + 0.25 * Math.sin(t * 0.051 + 1.3) + 0.55 * wide - 0.35 * s.build + 0.3 * surge - 0.15 * s.breakdown;
    let ty = 0.95 + 0.06 * Math.sin(t * 0.09) + 0.12 * s.build + 0.55 * surge;
    let tx = 0, tz = 0, zoom = 1.75;
    if (sky) { speed *= 0.35; ty += gather ? 1.25 : 1.1; Y -= 0.15; R += 0.25; }
    if (gather) { R += 0.5; zoom = bison ? 1.25 : 1.6; }
    // horse, eagle and salmon fly above the treeline: tilt just enough to keep their highest point in frame
    const skyTop = Math.max(...live.filter((e) => e.kind === "horse" || e.kind === "eagle" || e.kind === "salmon").map((e) => Math.max(e.topElev ?? -9, e.topEst ?? -9)), -9);
    // and correct by what is actually on screen: tilt further while any sky animal's top is near
    // the frame edge (perspective lifts animals near the sides), relax when there is room
    const boxTop = Math.max(...live.filter((e) => SKY_LEAD[e.kind] && e.box).map((e) => e.box[3]), -9);
    // a bison on the ground below shares the frame: its feet keep the tilt from going too far
    const groundBottom = Math.min(...live.filter((e) => e.kind === "bison" && e.box).map((e) => e.box[1]), 9);
    const upNeed = boxTop > 0.85 ? (boxTop - 0.85) * 3.0 : boxTop < 0.7 ? -0.08 : 0;
    const downNeed = groundBottom < -0.88 ? (groundBottom + 0.88) * 3.0 : 0;
    s.tiltBias = clamp((s.tiltBias || 0) + (downNeed < 0 ? Math.min(downNeed, 0) + Math.max(upNeed, 0) * 0.5 : upNeed) * dt, -0.3, 0.25);
    if (skyTop > -9) {
      zoom = Math.min(zoom, gather && bison ? 1.25 : 1.6);
      const pitch = Math.min(skyTop + 0.06 - Math.atan(1 / zoom) + s.tiltBias, 0.45);
      ty = Math.max(ty, Y + R * Math.tan(pitch));
    } else s.tiltBias = 0;
    s.skyFocus = skyTop > -9;
    if (bison && !deer) speed = 0;
    if (deer && !sky) {
      speed *= 0.1;
      const dp = deer.world || [0, 0, 0];
      void dp; ty = 1.0 + 0.25 * clamp((t - deer.at - deer.life + 2) / 4); zoom = 1.95;
    }
    if (pinned) {
      [s.camX, s.camY, s.camZ, s.tx, s.ty, s.tz] = pinned; s.zoom = pinned[6] || 1.75;
      return;
    }
    spring(s, "orbitSpeed", speed, dt, 3.5);
    s.orbit += s.orbitSpeed * dt;
    spring(s, "camR", R, dt, 3.0);
    spring(s, "camY", Y, dt, 3.0);
    spring(s, "ty", ty, dt, s.skyFocus ? 1.4 : 2.6);
    spring(s, "tx", tx, dt, 3.2);
    spring(s, "tz", tz, dt, 3.2);
    spring(s, "zoom", zoom, dt, 3.0);
    s.camX = Math.cos(s.orbit) * s.camR;
    s.camZ = Math.sin(s.orbit) * s.camR;
  }

  function camera() {
    const ro = [s.camX, s.camY, s.camZ];
    const ta = [s.tx, s.ty, s.tz];
    const cw = v.norm(v.sub(ta, ro));
    const cu = v.norm(v.cross(cw, [0, 1, 0]));
    const cv = v.cross(cu, cw);
    return { ro, ta, cw, cu, cv, zoom: s.zoom };
  }

  // ---------------------------------------------------------------------------------------
  // constellation geometry for one event: returns { lines, stars } in world space + alpha
  function lifecycle(e) {
    const age = s.t - e.at;
    const form = clamp(age / FORM[e.kind]);
    const diss = clamp((age - e.life) / DISSOLVE[e.kind]);
    return { age, form, diss };
  }

  // ---------------------------------------------------------------------------------------
  // Sky animals keep clear of each other on screen. Each frame's tight screen box (line and star
  // positions, no glow) is compared pairwise; on an overlap one animal gives way smoothly: the
  // eagle moves its circle aside, a later traveller (horse, bison, salmon) rises to pass above, or
  // moves aside when there is no room above. Offsets ease back only once well clear.
  const SKY_KINDS = new Set(["eagle", "horse", "salmon"]);
  function withSep(e, cam, a) {
    if (!e.sepX && !e.sepY) return a;
    const z = Math.max(v.dot(v.sub(a, cam.ro), cam.cw), 1);
    return v.add(a, v.add(v.mul(cam.cu, (e.sepX || 0) * z / cam.zoom), v.mul(cam.cv, (e.sepY || 0) * z / cam.zoom)));
  }
  function separate(dt) {
    const M = 0.05;
    const sky = events.filter((e) => SKY_KINDS.has(e.kind) && e.box && s.t >= e.at && s.t < e.at + e.life + DISSOLVE[e.kind] * 0.6);
    for (const e of sky) { e.sepTX ??= 0; e.sepTY ??= 0; e.sepX ??= 0; e.sepY ??= 0; e.clash = false; }
    for (let i = 0; i < sky.length; i += 1) for (let j = i + 1; j < sky.length; j += 1) {
      const a = sky[i], b = sky[j];
      const ox = Math.min(a.box[2], b.box[2]) - Math.max(a.box[0], b.box[0]) + M;
      const oy = Math.min(a.box[3], b.box[3]) - Math.max(a.box[1], b.box[1]) + M;
      if (ox <= 0 || oy <= 0) continue;
      // the eagle rises above travellers; between two travellers the later one rises
      let mover, other;
      if ((a.kind === "eagle") !== (b.kind === "eagle")) { mover = a.kind === "eagle" ? a : b; other = mover === a ? b : a; }
      else { mover = a.at > b.at ? a : b; other = mover === a ? b : a; }
      mover.clash = true;
      const up = mover.box[3] + oy < 0.95;
      if (up) mover.sepTY = Math.min(mover.sepY + oy, 0.9);
      else {
        const dir = Math.sign((mover.box[0] + mover.box[2]) - (other.box[0] + other.box[2])) || mover.side || 1;
        mover.sepTX = clamp(mover.sepX + dir * ox, -1.3, 1.3);
      }
    }
    // sharing the sky, the eagle circles more tightly
    for (const e of sky) if (e.kind === "eagle") e.share = sky.length > 1;
    for (const e of sky) {
      if (!e.clash) { e.sepTX *= Math.exp(-dt / 25); e.sepTY *= Math.exp(-dt / 25); }
      spring(e, "sepX", e.sepTX, dt, 1.1);
      spring(e, "sepY", e.sepTY, dt, 1.1);
    }
  }

  function placeEvent(e, cam, lc) {
    const kind = e.kind;
    const A = ANIMALS[kind];
    const { age, form, diss } = lc;
    const amp = smooth(0.45, 1.0, form) * (1 - 0.5 * smooth(0.3, 1, diss));
    const right = cam.cu, up = [0, 1, 0];
    const toward = v.norm([cam.ro[0] - 0, 0, cam.ro[2] - 0]);
    let geo, toWorld, depth;
    if (kind === "horse" || kind === "eagle" || kind === "salmon") {
      const dAz = Math.atan2(Math.sin(viewAz() - e.az), Math.cos(viewAz() - e.az));
      e.az += dAz * (1 - Math.exp(-s.dt / 5));
    }
    if (kind === "horse") {
      // a slightly distant apparition galloping across the sky, always clear of the treeline: its
      // height follows the tallest tree tips under its path as seen from the camera right now
      const D = 27;
      const size = 5.0;
      const travel = e.travel ?? (e.slot === "gather" ? 0.5 : 1);
      const az = e.az + e.side * 0.32 - e.side * age * 0.042 * travel;
      const base = [Math.cos(az) * D, 0, Math.sin(az) * D];
      const dx = base[0] - cam.ro[0], dz = base[2] - cam.ro[2], dist = Math.hypot(dx, dz);
      const azc = Math.atan2(dz, dx), half = size / dist + 0.05;
      const tree = treelineElevation(cam.ro, azc - half, azc + half);
      // hooves sit 0.65 sizes below the anchor; keep them above the tips, allowing for the drift
      const need = cam.ro[1] + dist * Math.tan(tree + 0.05) + 0.65 * size + 1.0;
      const goal = Math.max(1.6 + D * Math.tan(e.elev ?? 0.33), need);
      if (e.yCur === undefined) e.yCur = goal;
      else e.yCur += (goal - e.yCur) * (1 - Math.exp(-s.dt / (goal > e.yCur ? 1.0 : 4.0)));
      const anchor = withSep(e, cam, [base[0], e.yCur + 1.0 * Math.sin(age * 0.35), base[2]]);
      e.world = anchor;
      e.topEst = Math.atan2(e.yCur + 1.0 + 0.95 * size - cam.ro[1], dist);
      const dir = -e.side;
      e.phase += 1.2 * (0.35 + 0.65 * amp) * s.dt;
      geo = A.pose(fract(e.phase), { amp, time: age });
      const R = v.norm(v.cross(v.norm(v.sub(anchor, cam.ro)), up));
      toWorld = (p) => v.axes(anchor, v.mul(R, -dir * p[0] * size), v.mul(up, (p[1] - 0.6) * size), v.mul(v.norm(v.sub(cam.ro, anchor)), p[2] * size));
      depth = D;
    } else if (kind === "bison") {
      // on the ground between the dreamcatcher's feathers (r < 5.5) and the first trees (r > 6.6),
      // beside the fire on screen. It walks slowly along the ring away from the fire, stops to
      // graze, walks on. Its size gives 83% of its former apparent height in the sky.
      const r = 6.0;
      const screenAt = (p3, y = 0.7) => { const d = v.sub([p3[0], y, p3[2]], cam.ro); return v.dot(d, cam.cu) / Math.max(v.dot(d, cam.cw), 0.1) * cam.zoom; };
      const onRing = (a) => [Math.cos(a) * r, 0, Math.sin(a) * r];
      if (!e.path) {
        let az = viewAz() + e.side * 0.14;
        for (let k = 0.1; k <= 0.9; k += 0.04) { const c = viewAz() + e.side * k; if (Math.abs(screenAt(onRing(c))) >= 0.5) { az = c; break; } }
        const p0 = onRing(az);
        const dist = Math.hypot(p0[0] - cam.ro[0], p0[2] - cam.ro[2]);
        e.path = { az, targetX: Math.sign(screenAt(p0)) * 0.5, phase: 0, arc: 0, size: clamp(0.266 * dist / (1.08 * cam.zoom), 1.0, 2.2) };
      }
      const P = e.path;
      const size = P.size;
      // walking 3.5-8.5 s and from 12 s on; grazing in between (head down)
      const walk = smooth(3.5, 4.5, age) * (1 - smooth(8.0, 8.8, age)) + smooth(11.8, 12.6, age);
      const graze = smooth(8.4, 9.4, age) * (1 - smooth(11.2, 12.2, age));
      if (age < 3.5) {
        // match the target apparent height (box measured last frame), then hold it
        if (e.box && lc.form > 0.6) P.size *= Math.pow(0.266 / Math.max(e.box[3] - e.box[1], 0.05), Math.min(1, s.dt * 2));
        // keep its place on screen while the camera settles
        for (let it = 0; it < 2; it += 1) {
          const f0 = screenAt(onRing(P.az)) - P.targetX, f1 = screenAt(onRing(P.az + 0.01)) - P.targetX;
          const der = (f1 - f0) / 0.01;
          if (Math.abs(der) > 1e-3) P.az -= clamp(f0 / der, -0.02, 0.02);
        }
        P.dir = Math.sign(screenAt(onRing(P.az + 0.05)) - screenAt(onRing(P.az))) === Math.sign(P.targetX) ? 1 : -1;
      }
      // walks outward until about 1.05 from the screen centre, no further
      const room = Math.abs(screenAt(onRing(P.az + P.dir * P.arc / r))) < 1.05;
      const rate = 0.45 * walk * (0.35 + 0.65 * amp) * (room ? 1 : 0);
      P.phase += rate * s.dt;
      P.arc += rate * 0.42 * size * s.dt;            // matches the stance feet: no sliding
      const az = P.az + P.dir * P.arc / r;
      const pos = onRing(az);
      const tangent = [-Math.sin(az) * P.dir, 0, Math.cos(az) * P.dir];
      const anchor = [pos[0], groundHeight(pos[0], pos[2]), pos[2]];
      e.world = anchor;
      geo = A.pose(fract(P.phase), { amp: rate > 0 ? walk : 0, time: age, neck: -0.42 * graze, head: -0.25 * graze });
      const dirSign = v.dot(tangent, cam.cu) > 0 ? 1 : -1;
      const toCam = v.norm(v.sub(cam.ro, anchor));
      const R = v.norm(v.cross(toCam, up));
      toWorld = (p) => v.axes(anchor, v.mul(R, -dirSign * p[0] * size), v.mul(up, (p[1] + 0.02) * size), v.mul(toCam, p[2] * size));
      depth = Math.hypot(anchor[0] - cam.ro[0], anchor[1] - cam.ro[1], anchor[2] - cam.ro[2]);
    } else if (kind === "eagle") {
      const D = 24;
      if (e.biasCur === undefined) e.biasCur = e.azBias || 0;
      e.biasCur += ((e.azBias || 0) - e.biasCur) * (1 - Math.exp(-s.dt / 2.5));
      const az0 = e.az + e.biasCur;
      if (e.elevCur === undefined) e.elevCur = e.elev ?? 0.27;
      if (e.elevGoal !== undefined) e.elevCur += (e.elevGoal - e.elevCur) * (1 - Math.exp(-s.dt / 1.4));
      // the circle's centre is kept high enough that the body's path clears the tree tips under
      // it (only a wingtip may brush them when the wings stand vertical on screen)
      const base = [Math.cos(az0) * D, 0, Math.sin(az0) * D];
      const edx = base[0] - cam.ro[0], edz = base[2] - cam.ro[2], edist = Math.hypot(edx, edz);
      const eaz = Math.atan2(edz, edx), ehalf = 9 / edist;
      const etree = treelineElevation(cam.ro, eaz - ehalf, eaz + ehalf);
      const eneed = cam.ro[1] + edist * Math.tan(etree + 0.02) + 2.6 * 0.93 + 0.5 * 1.15 * 4.8;
      const egoal = Math.max(1.6 + D * Math.tan(e.elevCur), eneed);
      if (e.yCur === undefined) e.yCur = egoal;
      else e.yCur += (egoal - e.yCur) * (1 - Math.exp(-s.dt / (egoal > e.yCur ? 1.0 : 4.0)));
      const anchor = withSep(e, cam, [base[0], e.yCur, base[2]]);
      e.world = anchor;
      // expected top of the whole circle (path above the centre plus a raised wing), for the camera
      e.topEst = Math.atan2(anchor[1] - cam.ro[1], edist) + (3.6 * 0.93 + 0.5 * 1.15 * 4.8) / edist;
      // flight path: a glide in, one wide thermal circle (banked inward), a glide out, in a plane
      // seen from well below (tau), so the planform rotates like a bird circling overhead
      if (!e.path) e.path = { x: -e.side * 4.4, y: 3.0, h: e.side > 0 ? -0.22 : Math.PI + 0.22, bank: 0 };   // glides in toward the middle, descending slightly
      const P = e.path;
      const speed = 1.75 * (0.45 + 0.55 * amp);
      e.radCur = (e.radCur ?? Math.min(e.radius ?? 3.2, 3.2)) + ((e.share ? 2.3 : Math.min(e.radius ?? 3.2, 3.2)) - (e.radCur ?? 3.2)) * (1 - Math.exp(-s.dt / 3));
      const radius = e.radCur;
      // one full thermal circle: the turn eases out as the heading comes back round to the entry
      P.turned = P.turned || 0;
      const circling = smooth(2.5, 5.0, age) * clamp((TAU - P.turned) / 0.9);
      const kappa = circling / radius * -e.side;
      P.h += kappa * speed * s.dt;
      P.turned += Math.abs(kappa * speed * s.dt);
      P.x += Math.cos(P.h) * speed * s.dt;
      P.y += Math.sin(P.h) * speed * s.dt;
      const bankGoal = clamp(Math.atan(kappa * speed * speed * 0.55), -0.6, 0.6);
      P.bank += (bankGoal - P.bank) * (1 - Math.exp(-s.dt / 1.4));
      // Mostly gliding. A short bout of three powered wingbeats when it climbs without circling
      // (a climb in a thermal needs none), and otherwise now and then, never more than one bout
      // every few seconds.
      const climbing = Math.sin(P.h) > 0.3 && circling < 0.5;
      const sinceBout = age - (P.boutAt ?? -100);
      if (P.boutAt === undefined || sinceBout > 2.2) {
        const due = (climbing && sinceBout > 4.5) || sinceBout > 9.5;
        if (due && age > FORM.eagle && age < e.life - 1.5) P.boutAt = age;
      }
      let flapAmp = 0, flapPh = 0;
      const ub = (age - (P.boutAt ?? -100)) / 2.2;
      if (ub > 0 && ub < 1) { flapAmp = Math.sin(Math.PI * ub) ** 0.5; flapPh = (age - P.boutAt) * TAU * 1.36; }
      flapAmp *= amp;
      // soaring: each wing trims on its own, the dihedral breathes, the tail adjusts
      const trim = (k) => 0.07 * (0.5 + 0.5 * Math.sin(age * (0.55 + 0.1 * k) + e.seed * 9 + k * 2.1));
      const tau = 1.2;
      const N = v.norm(v.sub(cam.ro, anchor));
      const Rr = v.norm(v.cross(up, N)), U = v.cross(N, Rr);
      const upB0 = v.add(v.mul(U, Math.cos(tau)), v.mul(N, -Math.sin(tau)));
      const Dp = v.add(v.mul(U, Math.sin(tau)), v.mul(N, Math.cos(tau)));
      let fwd = v.add(v.mul(Rr, Math.cos(P.h)), v.mul(Dp, Math.sin(P.h)));
      let upB = upB0;
      upB = rotAxis(upB, fwd, -P.bank);
      const rightB = v.cross(fwd, upB);
      const size = 4.8;
      // the body answers each stroke: it lifts through the downstroke and settles in the recovery
      const theta = eagleStroke(flapPh);
      const heave = -0.035 * flapAmp * Math.cos(theta - 0.5) * size;
      const pos = v.axes(anchor, v.mul(Rr, P.x), v.mul(Dp, P.y), v.mul(upB, heave));
      geo = A.pose({ time: age, flap: flapPh, amp: flapAmp, spread: 0.35 + 0.5 * Math.abs(P.bank) + 0.15 * flapAmp, twist: -P.bank * 0.5 + 0.06 * Math.sin(age * 0.5 + e.seed * 7),
        bend: 0.7 + 0.1 * Math.sin(age * 0.37), flexL: Math.max(0, -kappa) * 0.6 + trim(0), flexR: Math.max(0, kappa) * 0.6 + trim(1), dihedral: 0.1 + 0.03 * Math.sin(age * 0.45 + e.seed * 5) });
      toWorld = (p) => v.axes(pos, v.mul(fwd, p[0] * size), v.mul(upB, p[1] * size), v.mul(rightB, p[2] * size));
      depth = D;
    } else if (kind === "deer") {
      // at the forest edge, clearly beside the fire on screen; it bounds along the treeline away
      // from the fire toward the side of the view
      const r = 6.9, ZOOM = 1.95;
      const B0 = 7.2, CROUCH = 0.5, BT = 1.05, NB = 2, STRIDE = 1.9;
      const screenAt = (p3) => { const d = v.sub([p3[0], 0.8, p3[2]], cam.ro); return v.dot(d, cam.cu) / Math.max(v.dot(d, cam.cw), 0.1) * ZOOM; };
      const onEdge = (a) => [Math.cos(a) * r, 0, Math.sin(a) * r];
      if (!e.path) {
        let az = viewAz() + e.side * 0.14;
        for (let k = 0.1; k <= 0.9; k += 0.04) { const c = viewAz() + e.side * k; if (Math.abs(screenAt(onEdge(c))) >= 0.5) { az = c; break; } }
        e.path = { az, r, walk: 0, dir: 1, strideScale: 1, targetX: Math.sign(screenAt(onEdge(az))) * 0.55 };
      }
      const P = e.path;
      // until the bounds begin, it keeps its place on screen while the camera settles
      if (age < B0) {
        for (let it = 0; it < 2; it += 1) {
          const f0 = screenAt(onEdge(P.az)) - P.targetX, f1 = screenAt(onEdge(P.az + 0.01)) - P.targetX;
          const der = (f1 - f0) / 0.01;
          if (Math.abs(der) > 1e-3) P.az -= clamp(f0 / der, -0.02, 0.02);
        }
        P.start = null;
      }
      if (!P.start) {
        P.start = onEdge(P.az);
        // direction away from the fire; stride shortened if the bounds would leave the view
        const t0 = [-Math.sin(P.az), 0, Math.cos(P.az)];
        const away = Math.sign(screenAt(v.add(P.start, t0)) - screenAt(P.start)) === Math.sign(P.targetX) ? 1 : -1;
        P.dir = away;
        const travel = NB * STRIDE + 0.35;
        const endAt = (k) => Math.abs(screenAt(v.add(P.start, v.mul(t0, away * travel * k))));
        P.strideScale = 1;
        while (P.strideScale > 0.5 && endAt(P.strideScale) > 1.1) P.strideScale -= 0.05;
      }
      // behaviour: emerges at the treeline (still, head low), pauses and raises its head, makes two
      // bounds along the treeline, slows to a few steps and settles, looks around (ears turning,
      // tail flicking), brightens, then its points rise into the sky.
      // bounding: a crouch into the first bound, NB continuous bounds, a settle out of the last
      const B1 = B0 + CROUCH;                                   // first push-off begins
      const ub = clamp((age - B1) / BT, 0, NB - 0.12);          // ends as the hinds come under
      const bEnd = B1 + (NB - 0.12) * BT;
      const bAmount = smooth(B0, B1, age) * (1 - smooth(bEnd, bEnd + 0.6, age));
      const bounding = bAmount > 0.001;
      const boundDisp = STRIDE * P.strideScale * deerBoundTravel(ub);
      const walkOn = smooth(bEnd + 0.3, bEnd + 0.7, age) * (1 - smooth(bEnd + 1.8, bEnd + 2.8, age));
      P.walk += 0.5 * walkOn * s.dt;
      P.walkDisp = (P.walkDisp || 0) + 0.2 * walkOn * s.dt;
      const tangent = [-Math.sin(P.az) * P.dir, 0, Math.cos(P.az) * P.dir];
      P.pos = v.add(P.start, v.mul(tangent, boundDisp + P.walkDisp));
      const gy = groundHeight(P.pos[0], P.pos[2]);
      const anchor = [P.pos[0], gy, P.pos[2]];
      e.world = anchor;
      const alert = smooth(5.0, 6.6, age);
      const head = -0.25 * (1 - smooth(3, 4.5, age)) * (1 - alert);   // head low while emerging
      const look0 = bEnd + 2.6;
      const ears = 0.25 * Math.sin(Math.max(0, age - look0) * 1.7) * smooth(look0, look0 + 1, age) * (1 - smooth(look0 + 4, look0 + 5, age)) + 0.12 * smooth(5.6, 6.4, age) * (1 - smooth(6.8, 7.2, age));
      const earTurn = smooth(look0 + 0.5, look0 + 1.5, age) * (1 - smooth(look0 + 3.5, look0 + 4.5, age));
      // the white tail lifts as a flag through the bounds, then a flick while it looks around
      const flag = smooth(B0 - 0.2, B0 + 0.3, age) * (1 - smooth(bEnd + 0.3, bEnd + 1.5, age));
      const tail = Math.max(flag, 0.5 * smooth(look0 + 2, look0 + 2.5, age) * (1 - smooth(look0 + 3.5, look0 + 4.5, age)));
      if (bounding) {
        const bd = deerBound(ub, bAmount, 0.42, STRIDE * P.strideScale / 1.75);
        geo = A.pose(0, { amp: 1, legs: bd.legs, lift: bd.lift, pitch: bd.pitch, flex: bd.flex, neck: 0.12 * alert + bd.neck, head: -0.1 * alert + bd.head, ears: -0.15, earTurn: 0, tail, time: age });
      } else {
        geo = A.pose(fract(P.walk), { amp: walkOn > 0.01 ? walkOn : 0.0, time: age, neck: 0.12 * alert + head, head: -0.1 * alert + 0.15 * earTurn, ears, earTurn, tail });
      }
      const size = 1.75;
      const dirSign = v.dot(tangent, cam.cu) > 0 ? 1 : -1;
      const toCam = v.norm(v.sub(cam.ro, anchor));
      const R = v.norm(v.cross(toCam, up));
      toWorld = (p) => v.axes(anchor, v.mul(R, -dirSign * p[0] * size), v.mul(up, (p[1] + 0.02) * size), v.mul(toCam, p[2] * size));
      depth = Math.hypot(anchor[0] - cam.ro[0], anchor[1] - cam.ro[1], anchor[2] - cam.ro[2]);
    } else {
      // salmon: a constellation in the sky above the treeline. It swims across the whole time:
      // head steady, the beat travelling to the tail (one tail beat every two beats of the music),
      // seen three-quarter from above so the body wave reads as a gentle S.
      const D = 26, size = 8.0;
      if (!e.path) e.path = { u: 0 };
      const P = e.path;
      const vx = 1.4 * (0.4 + 0.6 * smooth(1.5, 4.0, age));
      P.u += vx * s.dt * (e.travel ?? 1);
      const az = e.az + e.side * 0.28 - e.side * P.u / D;
      const base = [Math.cos(az) * D, 0, Math.sin(az) * D];
      const dx = base[0] - cam.ro[0], dz = base[2] - cam.ro[2], dist = Math.hypot(dx, dz);
      const azc = Math.atan2(dz, dx), half = size * 0.6 / dist + 0.05;
      const tree = treelineElevation(cam.ro, azc - half, azc + half);
      const need = cam.ro[1] + dist * Math.tan(tree + 0.03) + 0.17 * size;
      const goal = Math.max(1.6 + D * Math.tan(0.34), need);
      if (e.yCur === undefined) e.yCur = goal;
      else e.yCur += (goal - e.yCur) * (1 - Math.exp(-s.dt / (goal > e.yCur ? 1.0 : 4.0)));
      // a slow, gentle rise and fall
      const bob = 0.35 * Math.sin(age * 0.8);
      const anchor = withSep(e, cam, [base[0], e.yCur + bob, base[2]]);
      e.world = anchor;
      e.topEst = Math.atan2(e.yCur + 0.35 + 0.3 * size - cam.ro[1], dist);
      const pitch = Math.atan2(0.28 * Math.cos(age * 0.8), vx);
      geo = A.pose({ phase: (s.beat || 0) * 0.5 * TAU, amp });
      // frame: right-handed, the fish's back up and tilted a little toward the camera
      const toCam = v.norm(v.sub(cam.ro, anchor));
      const R = v.norm(v.cross(up, toCam));                 // screen right at the anchor
      const dirv = v.mul(R, -e.side);                      // travel direction on screen
      const fwd = v.add(v.mul(dirv, Math.cos(pitch)), v.mul(up, Math.sin(pitch)));
      const back0 = v.sub(v.mul(up, Math.cos(pitch)), v.mul(dirv, Math.sin(pitch)));
      const view = 0.6;
      const dorsal = v.norm(v.add(v.mul(back0, Math.cos(view)), v.mul(toCam, Math.sin(view))));
      const lateral = v.cross(fwd, dorsal);
      toWorld = (p) => v.axes(anchor, v.mul(fwd, p[0] * size), v.mul(dorsal, p[1] * size), v.mul(lateral, p[2] * size));
      depth = D;
    }
    return { geo, toWorld, depth };
  }

  // ---------------------------------------------------------------------------------------
  // projection + packing
  const data = new Float32Array(LFP_TEX_WIDTH * LFP_TEX_HEIGHT * 4);
  const animUniform = new Float32Array(LFP_SLOTS * 4);
  const animBox = new Float32Array(LFP_SLOTS * 4);

  function pack(cam, width, height, quality) {
    data.fill(0);
    animUniform.fill(0);
    animBox.fill(0);
    const aspect = width / Math.max(height, 1);
    const px = 2 / Math.max(height, 1);
    let chunk = 0;
    let slot = 0;
    let heroLevel = 0;
    const segBuf = [];
    const live = events.filter((e) => s.t >= e.at).sort((a, b) => ANIMAL_KINDS.indexOf(a.kind) - ANIMAL_KINDS.indexOf(b.kind));
    for (const e of live) {
      if (slot >= LFP_MAX_ANIMALS) break;
      const lc = lifecycle(e);
      if (lc.diss >= 1) continue;
      const { geo, toWorld, depth } = placeEvent(e, cam, lc);
      const sky = e.kind === "horse" || e.kind === "eagle" || e.kind === "salmon";
      let topElev = -9;
      let presence = smooth(0, 0.3, lc.form) * (1 - smooth(0.6, 1.0, lc.diss));
      if (e.kind === "deer") presence *= 0.4 + 0.6 * smooth(10, 16, lc.age);
      heroLevel = Math.max(heroLevel, presence);
      const project = (w) => {
        const d = v.sub(w, cam.ro);
        const z = v.dot(d, cam.cw);
        if (z < 0.2) return null;
        return [v.dot(d, cam.cu) / z * cam.zoom, v.dot(d, cam.cv) / z * cam.zoom];
      };
      segBuf.length = 0;
      let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
      // world-space units per pixel at this depth, so the line width follows the animal's size
      const scalePx = Math.max(0.75, Math.min(1.5, 36 / Math.max(depth, 4)));
      const rise = e.kind === "deer" ? lc.diss : lc.diss * 0.35;
      for (const l of geo.lines) {
        // formation: lines grow along their length in rank order; dissolution fades detail first
        const grow = clamp((lc.form * 1.55 - 0.25 - l.rank * 0.7) / 0.55);
        const fade = 1 - smooth(0.0 + (1 - l.rank) * 0.25, 0.45 + (1 - l.rank) * 0.25, lc.diss);
        const alpha = fade * l.i;
        if (grow <= 0 || alpha <= 0.01) continue;
        const pts = l.pts;
        const n = pts.length;
        const lastIdx = Math.max(1, Math.ceil((n - 1) * grow));
        let prev = null, prevI = 0;
        for (let k = 0; k <= lastIdx && k < n; k += 1) {
          let wp = toWorld(pts[k]);
          if (sky) topElev = Math.max(topElev, Math.atan2(wp[1] - cam.ro[1], Math.hypot(wp[0] - cam.ro[0], wp[2] - cam.ro[2])));
          if (rise > 0) wp = v.add(wp, [0, rise * rise * (e.kind === "deer" ? 3.5 : 1.0), 0]);
          const q = project(wp);
          if (!q) { prev = null; continue; }
          // last point of a growing line: interpolate the partial segment
          let qq = q;
          if (k === lastIdx && grow < 1 && prev) {
            const f = (n - 1) * grow - (lastIdx - 1);
            qq = [mix(prev[0], q[0], f), mix(prev[1], q[1], f)];
          }
          const ii = alpha * (0.85 + 0.15 * Math.sin(s.t * 1.7 + k * 0.9 + e.seed * 20));
          if (prev) {
            const dx = qq[0] - prev[0], dy = qq[1] - prev[1];
            // decimate: skip points closer than ~1.6 px unless it is the last one
            if (dx * dx + dy * dy < (1.6 * px) ** 2 && k < Math.min(lastIdx, n - 1)) continue;
            segBuf.push([prev[0], prev[1], qq[0], qq[1], prevI, ii, l.w * px * scalePx, l.tint]);
          }
          prev = qq; prevI = ii;
        }
      }
      for (const st of geo.stars) {
        const appear = smooth(st.rank * 0.5, st.rank * 0.5 + 0.22, lc.form);
        const linger = 1 - smooth(0.55, 1.0, lc.diss - st.rank * 0.15);
        let a = appear * linger * st.i;
        if (a <= 0.01) continue;
        let wp = toWorld(st.p);
        // in the dissolution the stars drift (the deer's rise into the night sky)
        if (lc.diss > 0) {
          const h = fract(Math.sin((st.p[0] * 12.9898 + st.p[1] * 78.233 + st.p[2] * 37.719)) * 43758.5453);
          wp = v.add(wp, [Math.sin(h * 40) * lc.diss * 0.6, (e.kind === "deer" ? 3.5 + 2.5 * h : 0.6 + 0.8 * h) * lc.diss ** 1.5, Math.cos(h * 40) * lc.diss * 0.6]);
        }
        const q = project(wp);
        if (!q) continue;
        // twinkle-in: a brief flare as each star first appears
        a *= 1 + 0.8 * Math.exp(-((lc.form - st.rank * 0.5 - 0.12) ** 2) / 0.004);
        segBuf.push([q[0], q[1], q[0], q[1], a * 1.25, a * 1.25, -st.s * px * 2.1 * scalePx, st.tint]);
      }
      if (sky && topElev > -9) e.topElev = topElev;
      if (!segBuf.length) continue;
      if (SKY_KINDS.has(e.kind) || e.kind === "bison") {
        let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        for (const sg of segBuf) { x0 = Math.min(x0, sg[0], sg[2]); y0 = Math.min(y0, sg[1], sg[3]); x1 = Math.max(x1, sg[0], sg[2]); y1 = Math.max(y1, sg[1], sg[3]); }
        e.box = [x0, y0, x1, y1];
      }
      const first = chunk;
      for (let k = 0; k < segBuf.length && chunk < LFP_MAX_CHUNKS; k += LFP_CHUNK) {
        const base = chunk * LFP_CHUNK_TEXELS * 4;
        let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
        for (let j = 0; j < LFP_CHUNK; j += 1) {
          const sg = segBuf[k + j];
          const o = base + (2 + j * 2) * 4;
          if (!sg) { data[o + 6] = 0; continue; }
          data[o] = sg[0]; data[o + 1] = sg[1]; data[o + 2] = sg[2]; data[o + 3] = sg[3];
          data[o + 4] = sg[4]; data[o + 5] = sg[5]; data[o + 6] = sg[6]; data[o + 7] = sg[7];
          // reach of the item's glow: lines ~4.5 widths, stars ~9 radii (gaussian tails)
          const r = sg[6] < 0 ? -sg[6] * 9 : sg[6] * 4.5;
          bx0 = Math.min(bx0, sg[0] - r, sg[2] - r); by0 = Math.min(by0, sg[1] - r, sg[3] - r);
          bx1 = Math.max(bx1, sg[0] + r, sg[2] + r); by1 = Math.max(by1, sg[1] + r, sg[3] + r);
        }
        data[base] = bx0; data[base + 1] = by0; data[base + 2] = bx1; data[base + 3] = by1;
        data[base + 4] = depth; data[base + 5] = presence; data[base + 6] = 0;
        minX = Math.min(minX, bx0); minY = Math.min(minY, by0); maxX = Math.max(maxX, bx1); maxY = Math.max(maxY, by1);
        chunk += 1;
      }
      // cull animals entirely off screen
      if (maxX < -aspect || minX > aspect || maxY < -1 || minY > 1) { chunk = first; continue; }
      animUniform.set([first, chunk - first, depth, ANIMAL_KINDS.indexOf(e.kind)], slot * 4);
      animBox.set([minX, minY, maxX, maxY], slot * 4);
      slot += 1;
    }
    chunk = packParticles(cam, chunk, px, aspect);
    s.heroLevel = heroLevel;
    s.chunks = chunk;
    s.animals = slot;
  }


  // ---------------------------------------------------------------------------------------
  // fire particles: sparks (continuous, rate from the music) and the ember column at a drop.
  // World-space simulation; packed as streaks with their own depth (chunk type 1).
  const prand = (n, k) => fract(Math.sin(n * 127.1 + k * 311.7) * 43758.5453);
  function particlesStep(dt, quality) {
    const cap = quality > 0.5 ? 90 : 64;
    // continuous sparks
    sparkDebt += dt * (2 + 12 * s.emberRate);
    while (sparkDebt >= 1) {
      sparkDebt -= 1;
      if (sparks.length >= cap) break;
      const n = sparkSerial++;
      const a = prand(n, 1) * TAU, r = 0.33 * Math.sqrt(prand(n, 2));
      sparks.push({ n, kind: 0, age: 0, life: 1.8 + 2.4 * prand(n, 3),
        p: [Math.cos(a) * r, 0.45 + 0.55 * prand(n, 4), Math.sin(a) * r],
        u: [Math.cos(a) * (0.1 + 0.18 * prand(n, 5)), 0.85 + 1.15 * prand(n, 6) + 0.6 * s.surge, Math.sin(a) * (0.1 + 0.18 * prand(n, 5))],
        heat: 0.7 + 0.3 * prand(n, 7) });
    }
    // the ember column: a surge of the flames sends a controlled column up; it opens into arcs
    const age = s.t - s.surgeAt;
    if (age < 1.6) {
      columnDebt += dt * (quality > 0.5 ? 46 : 32) * s.surgeMajor;
      while (columnDebt >= 1) {
        columnDebt -= 1;
        const n = sparkSerial++;
        const a = prand(n, 1) * TAU, r = 0.18 * Math.sqrt(prand(n, 2));
        // most embers open away from the camera's side, toward the sky the animals use
        const arcA = viewAz() + (prand(n, 8) - 0.5) * 2.6;
        sparks.push({ n, kind: 1, age: 0, life: 4.5 + 3.0 * prand(n, 3),
          p: [Math.cos(a) * r, 1.0 + 0.6 * prand(n, 4), Math.sin(a) * r],
          u: [0, 4.6 + 2.6 * prand(n, 6), 0], arc: [Math.cos(arcA), Math.sin(arcA)], spread: 0.8 + 1.4 * prand(n, 9), heat: 1.0 });
      }
    } else columnDebt = 0;
    const T = s.t;
    for (const q of sparks) {
      q.age += dt;
      if (q.kind === 0) {
        // buoyant rise, slowing; curling eddies; drift with the wind
        q.u[1] -= q.u[1] * 0.12 * dt;
        const e1 = Math.sin(q.age * 1.9 + q.n * 2.1), e2 = Math.cos(q.age * 1.5 + q.n * 1.7);
        q.p[0] += (q.u[0] + e1 * 0.12 + s.windX * q.age * 2) * dt;
        q.p[2] += (q.u[2] + e2 * 0.12 + s.windZ * q.age * 2) * dt;
        q.p[1] += q.u[1] * dt;
      } else {
        // decelerating column that bends into a wide arc as it slows
        q.u[1] -= q.u[1] * 0.55 * dt;
        const open = smooth(0.5, 2.2, q.age) * q.spread;
        q.p[0] += (q.arc[0] * open + s.windX * 3) * dt;
        q.p[2] += (q.arc[1] * open + s.windZ * 3) * dt;
        q.p[1] += (q.u[1] - 0.12 * smooth(2.5, 6, q.age)) * dt;
      }
      q.heat -= dt / q.life * 0.8;
    }
    for (let k = sparks.length - 1; k >= 0; k -= 1) if (sparks[k].age > sparks[k].life) sparks.splice(k, 1);
  }

  function packParticles(cam, chunk, px, aspect) {
    const segs = [];
    for (const q of sparks) {
      const ph = q.age / q.life;
      const fade = smooth(0.02, 0.14, ph) * (1 - ph) ** 1.4;
      if (fade < 0.004) continue;
      const tail = q.kind === 0 ? 0.07 : 0.03;
      const vel = q.kind === 0 ? [q.u[0], q.u[1], q.u[2]] : [q.arc[0] * q.spread * smooth(0.5, 2.2, q.age), q.u[1], q.arc[1] * q.spread * smooth(0.5, 2.2, q.age)];
      const b = [q.p[0] - vel[0] * tail, q.p[1] - vel[1] * tail, q.p[2] - vel[2] * tail];
      const d = v.sub(q.p, cam.ro), db = v.sub(b, cam.ro);
      const z = v.dot(d, cam.cw), zb = v.dot(db, cam.cw);
      if (z < 0.15 || zb < 0.15) continue;
      const x0 = v.dot(d, cam.cu) / z * cam.zoom, y0 = v.dot(d, cam.cv) / z * cam.zoom;
      const x1 = v.dot(db, cam.cu) / zb * cam.zoom, y1 = v.dot(db, cam.cv) / zb * cam.zoom;
      if (Math.max(x0, x1) < -aspect - 0.05 || Math.min(x0, x1) > aspect + 0.05 || Math.max(y0, y1) < -1.05 || Math.min(y0, y1) > 1.05) continue;
      const twk = 0.65 + 0.35 * Math.sin(q.age * 23 + q.n * 40);
      const inten = fade * twk * (q.kind === 0 ? 1.2 + 1.2 * prand(q.n, 10) : 1.6);
      const dist = Math.hypot(d[0], d[1], d[2]);
      const w = (0.0022 * dist + 0.003) / dist * cam.zoom;   // the original's world-space width
      segs.push([x0, y0, x1, y1, inten, Math.max(w, px * 0.6), dist, clamp(q.heat * (1 - 0.6 * ph))]);
    }
    if (!segs.length || chunk >= LFP_MAX_CHUNKS) { animUniform.set([0, 0, 0, -1], 5 * 4); return chunk; }
    segs.sort((a, b) => a[0] - b[0]);
    const first = chunk;
    let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
    for (let k = 0; k < segs.length && chunk < LFP_MAX_CHUNKS; k += LFP_CHUNK) {
      const base = chunk * LFP_CHUNK_TEXELS * 4;
      let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9, wmax = 0;
      for (let j = 0; j < LFP_CHUNK; j += 1) {
        const sg = segs[k + j];
        const o = base + (2 + j * 2) * 4;
        if (!sg) { data[o + 5] = 0; continue; }
        data[o] = sg[0]; data[o + 1] = sg[1]; data[o + 2] = sg[2]; data[o + 3] = sg[3];
        data[o + 4] = sg[4]; data[o + 5] = sg[5]; data[o + 6] = sg[6]; data[o + 7] = sg[7];
        bx0 = Math.min(bx0, sg[0], sg[2]); by0 = Math.min(by0, sg[1], sg[3]);
        bx1 = Math.max(bx1, sg[0], sg[2]); by1 = Math.max(by1, sg[1], sg[3]);
        wmax = Math.max(wmax, sg[5]);
      }
      const m = wmax * 12;
      data[base] = bx0 - m; data[base + 1] = by0 - m; data[base + 2] = bx1 + m; data[base + 3] = by1 + m;
      data[base + 4] = 0; data[base + 5] = 1; data[base + 6] = 1;
      minX = Math.min(minX, bx0 - m); minY = Math.min(minY, by0 - m); maxX = Math.max(maxX, bx1 + m); maxY = Math.max(maxY, by1 + m);
      chunk += 1;
    }
    animUniform.set([first, chunk - first, 0, -1], 5 * 4);
    animBox.set([minX, minY, maxX, maxY], 5 * 4);
    return chunk;
  }

  // ---------------------------------------------------------------------------------------
  function step(time, input = {}, size = {}) {
    if (!s.started || time < s.t - 0.25) { reset(); s.started = true; s.t = time; }
    const dt = clamp(time - s.t, 0, 0.1);
    s.dt = dt;
    s.t = time;
    s.frame += 1;
    const music = input.music || {};
    const drop = musicStep(dt, input);
    const phraseChanged = phraseStep(dt, music);
    networkStep(dt, phraseChanged);
    fireStep(dt);
    eventsStep(dt, music, drop);
    cameraStep(dt);
    separate(dt);
    particlesStep(dt, size.quality || 0);
    if (size.width) pack(camera(), size.width, size.height, size.quality || 0);
    return s;
  }

  function uniforms() {
    const cam = camera();
    const patternPrev = s.patternMix >= 1 ? s.pattern : s.patternPrev;
    return {
      lfpDir: 1,
      lfpCam0: [cam.ro[0], cam.ro[1], cam.ro[2], cam.zoom],
      lfpCam1: [cam.ta[0], cam.ta[1], cam.ta[2], 0],
      lfpMus0: [s.energy, s.awaken, s.circle, s.build],
      lfpMus1: [s.breakdown, Math.min(s.t - s.surgeAt, 60), s.surgeMajor, s.heroLevel],
      lfpNet0: [patternPrev, s.pattern, s.patternMix, s.travel],
      lfpNet1: [s.activity, Math.min(s.t - s.lastSweepAt, 60), s.sweepStrength, s.sector],
      lfpWind: [s.windX, s.windZ, s.gust, s.treeSway],
      lfpFire: [s.emberRate, s.richness, s.surge, 0]
    };
  }

  return {
    state: s,
    step,
    force,
    reset,
    uniforms,
    camera,
    data,
    animUniform,
    animBox,
    events: () => events,
    pinCamera(values) { pinned = values; },
    summary: () => ({ t: s.t, energy: +s.energy.toFixed(3), circle: +s.circle.toFixed(3), pattern: s.pattern, events: s.eventCount, chunks: s.chunks, animals: s.animals, log: s.log.slice(-40) })
  };
}

// ---------------------------------------------------------------------------------------
// Production binding (called from visualFrameRenderer for preset 388, and by the trial tool).
const cache = new WeakMap();
const TEXTURE_UNIT = 11;

export function bindLivingFirepitDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime || !gl.isTexture(runtime.texture)) {
    const texture = gl.createTexture();
    const activeUnit = gl.getParameter(gl.ACTIVE_TEXTURE);
    gl.activeTexture(gl.TEXTURE0 + TEXTURE_UNIT);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texStorage2D(gl.TEXTURE_2D, 1, gl.RGBA32F, LFP_TEX_WIDTH, LFP_TEX_HEIGHT);
    gl.activeTexture(activeUnit);
    runtime = { texture, director: null, lastTime: -1 };
    cache.set(gl, runtime);
  }
  const director = opts.director || runtime.director || (runtime.director = createLivingFirepitDirector());
  const width = opts.width || gl.drawingBufferWidth, height = opts.height || gl.drawingBufferHeight;
  // a frame drawn twice at the same time (transition, re-render) reuses the packed data
  if (time !== runtime.lastTime || opts.director) {
    director.step(time, input, { width, height, quality: opts.quality || 0 });
    runtime.lastTime = time;
    const activeUnit = gl.getParameter(gl.ACTIVE_TEXTURE);
    gl.activeTexture(gl.TEXTURE0 + TEXTURE_UNIT);
    gl.bindTexture(gl.TEXTURE_2D, runtime.texture);
    const flipY = gl.getParameter(gl.UNPACK_FLIP_Y_WEBGL);
    const premultiply = gl.getParameter(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    // only the rows that hold chunks
    const rows = Math.max(1, Math.ceil(((director.state.chunks || 0) * LFP_CHUNK_TEXELS) / LFP_TEX_WIDTH));
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, LFP_TEX_WIDTH, rows, gl.RGBA, gl.FLOAT, director.data.subarray(0, rows * LFP_TEX_WIDTH * 4));
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, flipY);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, premultiply);
    gl.activeTexture(activeUnit);
  }
  const activeUnit = gl.getParameter(gl.ACTIVE_TEXTURE);
  gl.activeTexture(gl.TEXTURE0 + TEXTURE_UNIT);
  gl.bindTexture(gl.TEXTURE_2D, runtime.texture);
  gl.activeTexture(activeUnit);
  const loc = (name) => uniformLocation(gl, program, name);
  gl.uniform1i(loc("lfpAnimals"), TEXTURE_UNIT);
  const u = director.uniforms();
  gl.uniform1f(loc("lfpDir"), 1);
  for (const [name, value] of Object.entries(u)) if (Array.isArray(value)) gl.uniform4f(loc(name), value[0], value[1], value[2], value[3]);
  gl.uniform4fv(loc("lfpAnim[0]"), director.animUniform);
  gl.uniform4fv(loc("lfpAnimBox[0]"), director.animBox);
  return director;
}
