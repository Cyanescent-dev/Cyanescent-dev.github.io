export { createApollonianFoamPresetShaderEntries as createPresetShaderEntries } from "../../apollonianFoamPresetShaderSources.js";
