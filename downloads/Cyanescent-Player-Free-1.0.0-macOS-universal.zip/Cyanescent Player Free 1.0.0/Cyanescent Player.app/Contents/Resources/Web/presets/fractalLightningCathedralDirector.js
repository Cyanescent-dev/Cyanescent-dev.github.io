// Fractal Lightning Cathedral (preset 338), The Living Conductor: the director.
//
// The cathedral is the original's: rooted piers branching into great vaults, side chambers, lower
// vaults and interlaced daughter arches, mirrored across the nave and repeated in 16-unit bays.
// flcMap returns, beside the distance, a propagation coordinate (network distance from the pier's
// root), the branch hierarchy (1 piers and great vault, ~1.3-2.1 side and lower vaults, ~3 lace) and
// junction proximity. The original lit it with a cosine pulse train locked to the beat, the same in
// every bay forever. The shader still draws the cathedral; this file (pure JS, no GL, so it can be
// tested) decides what the network conducts:
//   events     a few analytic wavefronts on the propagation coordinate (FLC_EVENT_SLOTS at most):
//              each has a centre on the network, a radius growing (outgoing) or shrinking
//              (converging), a hierarchy window, a delay per hierarchy level (daughters light after
//              their parents) and a spatial origin: one pier of one bay, both piers of a bay, or a
//              wave running down the nave. Kicks vary through the bar, breakdowns send sparse
//              solitary impulses, build rolls converge on the great junctions, drops discharge
//   charge     the piers glow from inside with the bass, one slow wave per bar climbing them
//   reach      mids (and builds) let light spread into finer branches
//   shimmer    highs: fine filaments and occasional sparks at junctions
//   travel     the camera's speed is a critically damped function of slow envelopes, integrated
//              into its position: steady through drives, slow in breakdowns, slowing through
//              builds, held before the drop, surging with the discharge
//   colour     slow drift between the original's cyan/turquoise/violet palette, violet-indigo
//              in breakdowns, magenta and pale gold accents in builds, cyan-white discharges
// The camera never reads instantaneous kick or bass values.
import { createNewtonAudioModel, follow } from "../engine/newtonBasinAudio.js";
import { createCathedralStorm } from "./fractalLightningStorm.js";

export const FRACTAL_LIGHTNING_CATHEDRAL_PRESET_ID = 338;
export const FLC_EVENT_SLOTS = 6;
export const FLC_BAY = 16;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const smooth01 = (x) => { const t = clamp(x); return t * t * (3 - 2 * t); };
const mix = (a, b, t) => a + (b - a) * t;

// ---- the network's propagation coordinates (mirrors flcMap) --------------------------------------
const smoothstep = (a, b, x) => smooth01((x - a) / (b - a));
export const flcPropagation = (h) => mix(1, 0.52, smoothstep(1, 3, h));
const dist = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
const travel = (a, b, h) => dist(a, b) * flcPropagation(h);
export const FLC_NODES = {
  root: [8.2, -5.35, 0], knee: [7.85, 0.9, 0], fork: [6.8, 5.2, 0], archA: [4.8, 8.8, 2.5], archB: [2.3, 11.0, 5.4],
  crown: [0, 11.8, 8], outerA: [10, 7.3, 3.4], innerA: [6.35, 4.6, 2.7]
};
// Nodes a storm strike can hit (folded coordinates): the side chamber, the upper storey, the vault
// springer and the pier's fork, each with its propagation coordinate and limb radius.
const FLC_HIGH_A = [9.0, 12.2, 5.4];
export const FLC_PATH = (() => {
  const n = FLC_NODES;
  const knee = travel(n.root, n.knee, 1);
  const fork = knee + travel(n.knee, n.fork, 1);
  const archA = fork + travel(n.fork, n.archA, 1);
  const archB = archA + travel(n.archA, n.archB, 1);
  const crown = archB + travel(n.archB, n.crown, 1);
  return { knee, fork, archA, archB, crown, outerA: fork + travel(n.fork, n.outerA, 1.3), innerA: knee + travel(n.knee, n.innerA, 1.95),
    roof: crown + 8 * flcPropagation(1.65) };
})();
export const FLC_STRIKE_NODES = [
  { name: "highA", p: FLC_HIGH_A, path: FLC_PATH.outerA + travel(FLC_NODES.outerA, FLC_HIGH_A, 1.85), r: 0.46 },
  { name: "outerA", p: FLC_NODES.outerA, path: FLC_PATH.outerA, r: 0.59 },
  { name: "archA", p: FLC_NODES.archA, path: FLC_PATH.archA, r: 0.76 },
  { name: "fork", p: FLC_NODES.fork, path: FLC_PATH.fork, r: 1.06 }
];

// The shader's sway of the architecture (flcSwayed): world -> swayed space.
export function flcSway(w, time, pressure, activity) {
  const rooted = Math.sin((w[1] + 5.5) * 0.12);
  let sway = (0.24 + 0.15 * pressure) * Math.sin(w[2] * 0.105 + time * 0.13) * rooted;
  sway += (0.045 + 0.13 * activity) * Math.sin(w[2] * 0.19 - time * 0.21) * Math.sin((w[1] + 5.5) * 0.19);
  return [w[0] - sway, w[1] - (0.14 + 0.075 * pressure) * Math.sin(w[2] * 0.13 + time * 0.12) * smoothstep(-5.5, 10, w[1]), w[2]];
}

// Event shapes. v: path units per second (negative converges), w: leading-edge width, tail: soft
// trailing length, glow/glowLen: afterglow along the conduits behind the front, lo/hi: hierarchy
// window, delay: path units added per hierarchy level (daughter branches light later), life seconds,
// hold: the fraction of the life before the front starts to fade.
// span: the network distance a front travels before it starts to fade (it completes its journey:
// up the pier, over the vault to the roof spine at ~31), then it fades over FLC_FADE seconds.
// Primary currents are broad and bright; branches are finer.
const FLC_FADE = 0.7;
const SHAPES = {
  impulse:  { v: 20, w: 0.48, tail: 1.3, glow: 0.32, glowLen: 4, lo: 1, hi: 1.35, delay: 0, span: 32 },
  branch:   { v: 13, w: 0.38, tail: 1.1, glow: 0.35, glowLen: 4, lo: 1.3, hi: 2.3, delay: 1.5, span: 22 },
  crown:    { v: 24, w: 0.50, tail: 1.4, glow: 0.32, glowLen: 5, lo: 1, hi: 1.7, delay: 0, span: 32 },
  cascade:  { v: 18, w: 0.46, tail: 1.4, glow: 0.40, glowLen: 6, lo: 1, hi: 3.1, delay: 2.5, span: 37 },
  current:  { v: 22, w: 0.48, tail: 1.4, glow: 0.30, glowLen: 5, lo: 1, hi: 1.6, delay: 1.0, span: 49 },
  solitary: { v: 7, w: 0.52, tail: 2.4, glow: 0.55, glowLen: 7, lo: 1, hi: 3.1, delay: 3.0, span: 38 },
  converge: { v: -12, w: 0.42, tail: 1.6, glow: 0.25, glowLen: 3, lo: 1, hi: 2.0, delay: 0, life: 1.6, hold: 0.75 },
  strike:   { v: 22, w: 0.6, tail: 2.0, glow: 1.0, glowLen: 20, lo: 1, hi: 3.2, delay: 2.0, life: 3.0 },
  discharge:{ v: 26, w: 0.85, tail: 2.6, glow: 1.0, glowLen: 60, lo: 1, hi: 1.45, delay: 0, life: 5.5 }
};

// Palettes: [cyan-ish primary, turquoise primary, violet fine, magenta fine, front accent].
const PAL = {
  normal: [[0.025, 0.88, 1.30], [0.015, 0.95, 0.61], [0.43, 0.085, 1.16], [1.08, 0.035, 0.53], [1.75, 0.50, 0.065]],
  calm:   [[0.20, 0.32, 1.25], [0.10, 0.55, 0.95], [0.48, 0.07, 1.20], [0.62, 0.05, 0.95], [0.80, 0.42, 1.30]],
  build:  [[0.10, 0.80, 1.30], [0.06, 0.92, 0.70], [0.80, 0.10, 1.05], [1.25, 0.08, 0.62], [1.70, 0.95, 0.42]],
  drop:   [[0.16, 0.98, 1.38], [0.10, 1.02, 0.86], [0.52, 0.16, 1.22], [1.10, 0.22, 0.66], [1.55, 1.05, 0.55]]
};

// options.storm: false keeps the closed cathedral without the storm beyond it.
export function createFractalLightningCathedralDirector(options = {}) {
  const audioModel = createNewtonAudioModel();
  const storm = options.storm === false ? null : createCathedralStorm();
  const s = {};
  const events = [];
  const delayed = [];
  const uniforms = {};
  let seed = 1;
  const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  function reset() {
    audioModel.reset();
    storm?.reset();
    for (const key of Object.keys(uniforms)) delete uniforms[key];
    events.length = 0;
    delayed.length = 0;
    seed = 0x338c4a7;
    Object.assign(s, {
      initialised: true, time: 0, lastTime: 0, beat: 0,
      energy: 0.35, energySlow: 0.35, mids: 0.35, midsSlow: 0.35, highs: 0.3, bass: 0.4, bassSlow: 0.4,
      calm: 0, drive: 0, tension: 0, anticipation: 0, buildHold: 0, tensionMemory: 0, calmMemory: 0, calmHeld: 0, lastConverge: -1e9,
      shimmer: 0, hatSpark: 0, charge: 0.3, reach: 0.3, focus: 0, discharge: 0, whiteness: 0, surge: 0,
      breathPhase: 0, sparkClock: 0, nextSolitary: 4, side: 1,
      pal: PAL.normal.map((c) => c.slice()),
      J: 0, camZ: 0, speed: 4, speedV: 0, lookAnticipation: 0,
      kicks: 0, bars: 0, drops: 0, strikes: 0, grooveStrikes: 0, lastStrike: null, lastPhrase: undefined, releasedAt: -1e9, camera: null, prevDropIn: undefined, presetTime: 0, pressure: 0.5, level: 0.5, majors: 0, minors: 0, teases: 0, solitaries: 0, converges: 0, lastDropAt: -1e9, lastMajorAt: -1e9,
      spawned: {}
    });
  }
  reset();

  // origin: { z (world z of a bay's piers, or the nave wave's start), side (+-1 one pier, 0 both),
  // lambda (path units per world unit away from the origin), falloff (1 / radius, 0 none), local
  // (1: distance to the origin bay's mirror image, 0: plain distance along the nave) }
  function spawn(kind, strength, origin, opts = {}) {
    const shape = { ...SHAPES[kind], ...opts };
    if (shape.span) {
      // hold until the front has travelled its span, then fade
      const travelTime = shape.span / Math.abs(shape.v);
      shape.life = travelTime + FLC_FADE;
      shape.hold = travelTime / shape.life;
    }
    if (events.length >= FLC_EVENT_SLOTS) {
      let weakest = 0;
      for (let i = 1; i < events.length; i++) if (events[i].age / events[i].life > events[weakest].age / events[weakest].life) weakest = i;
      events.splice(weakest, 1);
    }
    events.push({ kind, strength, age: 0, centre: 0, r0: 0, hold: 0.55, lambda: 1.6, falloff: 0.08, local: 1, side: 0, z: 0, ...shape, ...origin });
    s.spawned[kind] = (s.spawned[kind] || 0) + 1;
  }

  // The bays whose piers stand ahead of the camera: n = 1 is the next pier at least 6 units ahead,
  // the nearest that is fully in view, filling the sides of the frame.
  const bayAhead = (n) => (Math.ceil((s.camZ + 6) / FLC_BAY) + n - 1) * FLC_BAY;
  const pier = (n, side, extra = {}) => ({ z: bayAhead(n), side, ...extra });

  function onKick(beatInBar, strength) {
    const b = beatInBar;
    if (b === 0) s.bars += 1;
    s.kicks += 1;
    // the bar's shape: a pier, a branching, the vault, then something different every bar
    const scale = (1 - 0.55 * s.calm) * (1 - 0.35 * s.tension) * (1 - 0.85 * s.anticipation);
    if (scale < 0.15) return;
    // in a drive every kick carries a clearly visible current (the analysis' kick strength can be low)
    const amp = Math.max(strength, 0.55 + 0.35 * s.drive) * scale;
    if (b === 0) {
      s.side = -s.side;
      if (s.drive > 0.55 && s.bars % 3 !== 2) {
        // driving sections: a current runs down the nave, pier after pier
        spawn("current", 0.9 * amp, { z: s.camZ - 2, side: 0, lambda: 0.42, falloff: 0, local: 0, hi: 1.45 + 0.6 * s.reach });
      } else spawn("impulse", 1.0 * amp, pier(1, s.bars % 3 === 1 ? s.side : 0, { falloff: 0.05 }));
    } else if (b === 1) {
      if (s.reach > 0.35 || rand() < 0.5) spawn("branch", 0.8 * amp, pier(1, -s.side, { lambda: 1.2 }), { centre: FLC_PATH.fork, hi: 1.9 + 1.1 * s.reach });
      else spawn("impulse", 0.6 * amp, pier(2, -s.side));
    } else if (b === 2) {
      spawn("crown", 0.95 * amp, pier(1 + Math.floor(rand() * 2), 0, { falloff: 0.035 }));
    } else {
      const variant = s.bars % 4;
      if (variant === 3) spawn("cascade", 1.0 * amp, pier(1, 0, { falloff: 0.045 }), { hi: 2.2 + 0.9 * s.reach });
      else if (variant === 1) spawn("branch", 0.75 * amp, pier(2, s.side, { lambda: 1.2 }), { centre: FLC_PATH.archA, hi: 1.8 + 1.2 * s.reach });
      else if (rand() < 0.5) spawn("impulse", 0.75 * amp, pier(1, s.side, { falloff: 0.11 }), { hi: 1.3 + 0.8 * s.reach, delay: 1.2 });
      // otherwise the beat rests: the cathedral breathes between impulses
    }
  }

  // Breakdowns: a solitary impulse in a distant pier, branching slowly into the vaults
  function solitary() {
    const side = rand() < 0.5 ? -1 : 1;
    const centre = rand() < 0.3 ? FLC_PATH.archA : 0;
    spawn("solitary", 1.2 + 0.4 * s.midsSlow, pier(1 + Math.floor(rand() * 2), side, { falloff: 0.1 }), { centre, hi: 1.6 + 1.5 * s.reach });
    s.solitaries += 1;
    s.nextSolitary = s.time + 3.5 + 5 * rand();
  }

  // Builds: currents from the foundations and from the roof converge on a great junction
  function converge(strength) {
    const centre = s.tension > 0.6 && s.converges % 2 ? FLC_PATH.archA : FLC_PATH.fork;
    const r0 = Math.max(centre, FLC_PATH.crown - centre) + 1;
    spawn("converge", strength, pier(1, s.converges % 3 === 2 ? 0 : (s.converges % 2 ? 1 : -1), { falloff: 0.06 }),
      { centre, r0, v: -(r0 / 0.9), life: 1.15, hi: 1.4 + 1.4 * s.tension });
    s.converges += 1;
    s.lastConverge = s.time;
  }

  // The great discharge: piers ignite, the vaults follow, then the finer network; a wave that runs
  // away from the camera down the nave
  // A node of the cathedral for a storm strike: in a bay ahead (in view through the openings), on
  // the given side, its world position following the sway.
  function strikeTarget(side, great) {
    const k = Math.ceil((s.camZ + 20) / FLC_BAY);
    const names = great ? ["archA", "archA", "outerA"] : ["archA", "outerA", "fork"];
    const node = FLC_STRIKE_NODES.find((n) => n.name === names[s.strikes % names.length]);
    const sz = node.p[2] === 0 ? 1 : (s.strikes % 2 ? 1 : -1);
    const z = k * FLC_BAY + sz * node.p[2];
    let w = [side * node.p[0], node.p[1], z];
    for (let i = 0; i < 3; i++) {
      const q = flcSway(w, s.presetTime, s.pressure, s.level);
      w = [w[0] + (side * node.p[0] - q[0]), w[1] + (node.p[1] - q[1]), z];
    }
    return { node, world: w, bayZ: k * FLC_BAY, side };
  }

  // Lightning from the storm hits a node; when the channel arrives, electricity runs out through
  // the network from that node's propagation coordinate.
  function stormStrike(kind) {
    const side = s.strikes % 2 ? 1 : -1;
    const target = strikeTarget(side, kind === "great");
    s.strikes += 1;
    const impact = storm.strike(target.world, side, kind, s.camera?.pos ?? [0, 0, s.camZ]);
    delayed.push({ at: s.time + impact, kind: "strike", strength: kind === "great" ? 2.0 : 1.4,
      origin: { z: target.bayZ, side, falloff: kind === "great" ? 0.02 : 0.045 }, opts: { centre: target.node.path } });
    s.lastStrike = { ...target, kind, at: s.time + impact };
    return { impact, target };
  }

  function discharge() {
    events.length = 0;
    delayed.length = 0;
    // with the storm, the great strike opens the discharge: the waves run down the nave both ways
    // from the bay it hits, as the channel arrives
    let z = s.camZ - 6, wait = 0;
    if (storm) { const k = stormStrike("great"); z = k.target.bayZ; wait = k.impact; }
    const nave = { z, side: 0, lambda: 0.55, falloff: 0, local: 0 };
    if (wait > 0) delayed.push({ at: s.time + wait, kind: "discharge", strength: 2.4, origin: nave, opts: {} });
    else spawn("discharge", 2.4, nave);
    delayed.push({ at: s.time + wait + 0.22, kind: "discharge", strength: 1.8, origin: nave, opts: { lo: 1.3, hi: 2.4, delay: 4, w: 0.7, glow: 1.15 } });
    delayed.push({ at: s.time + wait + 0.5, kind: "discharge", strength: 1.4, origin: nave, opts: { lo: 2.3, hi: 3.3, delay: 6, w: 0.55, glow: 1.5 } });
    s.discharge = 1; s.surge = 1;
    // the drop has come: whatever the analysis still says (it lags), the waiting is over
    s.anticipation = 0; s.buildHold = 0; s.lookAnticipation = 0; s.releasedAt = s.time;
    s.majors += 1; s.lastMajorAt = s.time;
  }

  // time: seconds (monotonic per preset activation). input: { audio, smooth, music, tempo }.
  function step(time, input = {}) {
    if (!s.initialised || time < s.lastTime - 1e-3) { reset(); s.lastTime = time; }
    const dt = clamp(time - s.lastTime, 0, 0.1);
    s.lastTime = time;
    s.time += dt;
    const { audio = {}, smooth = {}, music = {}, tempo = {} } = input;
    const bps = clamp((Number(tempo?.bpm) || Number(music.bpm) || 145) / 60, 1, 4);
    const ev = audioModel.step(dt, { audio, smooth, music }, { beatsPerSecond: bps });
    // the architecture's sway, as the shader computes it (strike targets follow it)
    s.presetTime = time;
    s.pressure = clamp(input.slowBass ?? smooth.bass);
    s.level = clamp(input.slowLevel ?? smooth.level);
    let minorAccent = false;
    const a = audioModel.state;
    s.beat = a.beat;

    // ---- musical envelopes ------------------------------------------------------------------------
    s.energy = follow(s.energy, Math.max(a.energyDrive * 0.9, clamp(music.adaptiveIntensity ?? a.energyDrive) * 0.8), dt, 0.5, 1.6);
    s.energySlow = follow(s.energySlow, s.energy, dt, 4, 6);
    s.mids = follow(s.mids, clamp(smooth.mids), dt, 0.4, 0.8);
    s.midsSlow = follow(s.midsSlow, s.mids, dt, 1.4, 1.8);
    s.highs = follow(s.highs, clamp(smooth.highs), dt, 0.05, 0.25);
    s.bass = follow(s.bass, clamp(Math.max(a.sub, clamp(smooth.bass) * 0.85)), dt, 0.5, 1.1);
    s.bassSlow = follow(s.bassSlow, s.bass, dt, 0.9, 1.5);
    const building = clamp(Math.max(a.build, clamp(music.buildUp)));
    // (the analysis reports a weak build, ~0.3, through much of a long breakdown: only a real build
    // wakes the cathedral)
    s.calm = follow(s.calm, clamp((a.breakdown - 0.35) / 0.45) * (1 - a.groove * 0.7) * (1 - clamp((building - 0.35) * 2.2)), dt, 1.4, 1.8);
    s.drive = follow(s.drive, clamp(a.groove * (0.5 + 0.5 * s.energy)), dt, 0.8, 1.6);
    const forecast = clamp(Math.max(clamp(music.upcomingDrop) * 1.2, a.build));
    s.tension = follow(s.tension, forecast * (1 - s.calm * 0.5), dt, 0.8, 1.2);
    // the drop is imminent: a confident forecast, or a build held at its peak (real analysis rarely
    // forecasts near 1, so the longer a build holds, the nearer the drop)
    s.buildHold = s.tension > 0.9 ? s.buildHold + dt : Math.max(0, s.buildHold - dt * 3);
    // With the track's drop map (music.dropKnown) the drop is known exactly: the last 16 beats
    // before a major drop are imminent. Without it (live input), a confident forecast or a build
    // held at its peak (the longer it holds, the nearer the drop).
    const mapped = Number(music.dropKnown) > 0;
    const imminent = mapped
      ? (Number(music.dropNextStrength) >= 1 ? smooth01((16 - Number(music.dropBeatsIn)) / 12) : 0)
      : Math.max(clamp((clamp(music.upcomingDrop) - 0.7) / 0.25) * clamp(building * 1.5), 0.8 * smooth01((s.buildHold - 1.5) / 5));
    // for a few seconds after a drop nothing is imminent (real analysis keeps calling the build)
    const released = smooth01((s.time - s.releasedAt - 6) / 4);
    s.anticipation = follow(s.anticipation, imminent * released, dt, 0.7, 0.35);
    s.tensionMemory = Math.max(s.tension, s.tensionMemory - dt / 25);
    // a breakdown is context for a major drop once it has lasted (a brief lull inside a section is not)
    s.calmHeld = s.calm > 0.5 && s.time > 8 ? s.calmHeld + dt : Math.max(0, s.calmHeld - dt * 3);
    s.calmMemory = Math.max(smooth01((s.calmHeld - 12) / 6), s.calmMemory - dt / 30);

    // ---- events -----------------------------------------------------------------------------------
    for (const w of ev.waves) {
      if (w.kind === "kick") onKick(w.beatInBar ?? (s.kicks % 4), w.strength);
      // rolls subdivide towards the drop; the currents quicken with them, at most two per beat
      else if (w.kind === "roll" && s.tension > 0.4 && s.anticipation < 0.6 && s.time - s.lastConverge > (s.tension > 0.75 ? 0.5 : 1) / bps) converge(0.45 + 0.6 * w.strength + 0.3 * s.tension);
      else if (w.kind === "tide" && s.calm > 0.3 && s.time >= s.nextSolitary - 1.5 && rand() < 0.7) solitary();
    }
    if (s.calm > 0.5 && s.time >= s.nextSolitary) solitary();
    if (ev.hats) s.hatSpark = Math.max(s.hatSpark, 0.5 + 0.5 * a.highDrive);
    // the kick returning inside a build (a tease) is a rebound, not the drop
    const bu = clamp(music.buildUp);
    if (mapped) {
      // A mapped drop fires when playback passes it: approaching it last frame, just past it now.
      // A seek past a drop does not fire it; a seek to just before one does.
      const dropIn = Number(music.dropIn), dropAge = Number(music.dropAge);
      if (s.prevDropIn !== undefined && s.prevDropIn < 1.5 && dropAge < 1.5) {
        s.drops += 1;
        if (Number(music.dropLastStrength) >= 1 && s.time - s.lastMajorAt > 8) discharge();
        else { s.minors += 1; minorAccent = true; spawn("cascade", 1.2, pier(1, 0, { falloff: 0.04 }), { hi: 3.1 }); }
        s.lastDropAt = s.time;
      }
      s.prevDropIn = dropIn;
    }
    const rebound = !mapped && ev.drop && bu > 0.5 && clamp(music.drop) < 0.6 && (s.tension < 0.85 || bu > 0.9);
    if (rebound) { s.teases += 1; minorAccent = true; spawn("cascade", 1.0, pier(1, 0, { falloff: 0.045 })); }
    if (!mapped && ev.drop && !rebound) {
      s.drops += 1;
      // a major drop follows a build or a breakdown; the kick entering after an intro does not count
      const context = s.tensionMemory > 0.55 || s.calmMemory > 0.5;
      if (context && s.time > 20 && s.time - s.lastMajorAt > 30) discharge();
      else { s.minors += 1; minorAccent = true; spawn("cascade", 1.2, pier(1, 0, { falloff: 0.04 }), { hi: 3.1 }); }
      s.lastDropAt = s.time;
    }
    for (let i = delayed.length - 1; i >= 0; i--) {
      const d = delayed[i];
      if (s.time >= d.at) { spawn(d.kind, d.strength, d.origin, d.opts); delayed.splice(i, 1); }
    }
    for (const e of events) e.age += dt;
    for (let i = events.length - 1; i >= 0; i--) if (events[i].age > events[i].life) events.splice(i, 1);

    // ---- continuous electrical state ----------------------------------------------------------------
    s.hatSpark *= Math.exp(-dt / 0.12);
    s.shimmer = clamp(0.25 * s.highs + 0.5 * a.highDrive * (0.4 + 0.6 * s.energy) + 0.4 * s.hatSpark) * (1 - 0.5 * s.anticipation);
    // the discharge's afterglow fades over seconds, the surge over ~10 s
    s.discharge = Math.max(0, s.discharge - dt / 6);
    s.surge = Math.max(0, s.surge - dt / 10);
    s.whiteness = follow(s.whiteness, s.discharge > 0.5 ? 1 : 0, dt, 0.08, 1.2);
    // charge: the piers' inner glow (bass), rising through builds, held hard before the drop
    s.charge = follow(s.charge, clamp(0.12 + 0.55 * s.bassSlow * (0.45 + 0.55 * s.drive) + 0.45 * s.tension + 0.25 * s.anticipation - 0.12 * s.calm, 0, 1.2), dt, 0.9, 1.6);
    // reach: how far into the finer branches light spreads (mids, builds, drops)
    s.reach = follow(s.reach, clamp(0.15 + 0.55 * s.midsSlow * (0.5 + 0.5 * s.energy) + 0.45 * s.tension + 0.4 * s.surge - 0.15 * s.calm - 0.5 * s.anticipation), dt, 1.2, 1.8);
    // focus: before the drop light gathers into the piers and vault
    s.focus = follow(s.focus, s.anticipation, dt, 0.6, 0.5);
    s.breathPhase += dt * bps * Math.PI * 2 / 4;   // one breath per bar
    s.sparkClock += dt * (2 + 10 * s.shimmer);

    // ---- colour: slow and never cycling --------------------------------------------------------------
    const wCalm = smooth01(s.calm * 1.3), wBuild = smooth01(s.tension) * (1 - wCalm), wDrop = s.discharge * s.discharge;
    for (let k = 0; k < 5; k++) for (let j = 0; j < 3; j++) {
      let goal = PAL.normal[k][j];
      goal = mix(goal, PAL.calm[k][j], wCalm * 0.8);
      goal = mix(goal, PAL.build[k][j], wBuild * 0.7);
      goal = mix(goal, PAL.drop[k][j], wDrop * 0.85);
      s.pal[k][j] = follow(s.pal[k][j], goal, dt, wDrop > 0.3 ? 0.25 : 2.5, 3.5);
    }

    // ---- camera: accumulated travel down the nave ---------------------------------------------------
    // Section speeds (units/s; a bay is 16): breakdown ~0.6 drifting, melodic ~2.7 floating,
    // drive ~5.5-6, sustained high energy ~7 cruising; builds slow progressively, an imminent drop
    // holds nearly still, the drop surges to ~12 and eases back over ~10 s. All from slow envelopes
    // through a critically damped spring: no kick ever reaches the camera.
    const high = smooth01((s.energySlow - 0.7) / 0.25);
    const cruise = mix(2.7, 6.0, s.drive) + 1.2 * high * s.drive;
    const base = mix(cruise, 0.6, s.calm);
    // the analysis' lookahead: energy rising ahead while a build holds is the drop approaching
    const look = input.lookahead;
    const rising = look?.ready ? smooth01(((look.medium?.maxEnergy ?? 0) - (look.current?.energy ?? 0) - 0.15) / 0.25) : 0;
    s.lookAnticipation = follow(s.lookAnticipation, rising * smooth01((s.tension - 0.5) / 0.3) * released, dt, 1.0, 0.6);
    const approach = Math.max(s.anticipation, 0.8 * s.lookAnticipation);
    const speedGoal = Math.max(0.18, base * (1 - 0.6 * s.tension * released) * (1 - 0.85 * approach) + 8.5 * s.surge * Math.sqrt(s.surge));
    const wsp = 0.9 + 1.1 * s.surge;
    s.speedV += (wsp * wsp * (speedGoal - s.speed) - 2 * wsp * s.speedV) * dt;
    s.speedV = clamp(s.speedV, -4, 8);
    s.speed += s.speedV * dt;
    s.camZ += dt * Math.max(0.15, s.speed);
    // the original's sway phases, advanced a little slower in breakdowns
    s.J += dt * (1 - 0.25 * s.calm - 0.15 * s.anticipation);
    const J = s.J;
    const pos = [1.25 * Math.sin(J * 0.057), -0.10 + 0.36 * Math.sin(J * 0.073), s.camZ];
    const fwd = [0.055 * Math.sin(J * 0.041), 0.235 + 0.025 * Math.sin(J * 0.061) + 0.03 * s.tension, 1];

    // ---- uniforms ----------------------------------------------------------------------------------
    uniforms.flcCam = [...pos, 1.30 - 0.06 * s.surge];
    uniforms.flcFwd = [...fwd, 1];
    uniforms.flcLevel = [s.charge, s.reach, s.shimmer, s.focus];
    uniforms.flcState = [s.breathPhase % 6283.185, s.sparkClock % 1000, s.discharge, s.calm];
    // (w: col0 energy, col1 the build's gathering at the junctions, col4 the discharge whiteness)
    const gather = clamp(s.tension * (1 - s.calm) * (1 - 0.5 * s.discharge));
    s.pal.forEach((c, k) => { uniforms[`flcCol${k}`] = [...c, k === 4 ? s.whiteness : k === 0 ? s.energy : k === 1 ? gather : 0]; });
    // the shader evaluates every slot (a loop without early exits): unused ones have zero amplitude
    // and harmless widths
    const A = [], B = [], C = [], D = [];
    for (let i = 0; i < FLC_EVENT_SLOTS; i++) { A.push(0, 0, 1, 1); B.push(0, 0, 1, 0); C.push(0, 0, 0, 0); D.push(1, 1, 1, 1); }
    events.forEach((e, i) => {
      const radius = e.v >= 0 ? e.r0 + e.v * e.age : Math.max(0, e.r0 + e.v * e.age);
      const fadeIn = clamp(e.age / 0.05);
      const fadeOut = 1 - smooth01((e.age - e.hold * e.life) / ((1 - e.hold) * e.life));
      const front = e.strength * fadeIn * fadeOut;
      const glow = e.strength * e.glow * smooth01(e.age / 0.25) * Math.exp(-e.age / (e.kind === "discharge" ? 3.0 : 0.5 * e.life));
      A.splice(i * 4, 4, e.centre, radius, e.w, e.tail);
      B.splice(i * 4, 4, front, glow, e.glowLen, e.delay);
      C.splice(i * 4, 4, e.z, e.side, e.lambda, e.falloff);
      D.splice(i * 4, 4, e.lo, e.hi, e.local, e.v >= 0 ? 1 : -1);
    });
    uniforms.flcEvA = A; uniforms.flcEvB = B; uniforms.flcEvC = C; uniforms.flcEvD = D;
    uniforms.flcEvCount = events.length;
    s.camera = { pos, speed: s.speed };

    // ---- the storm beyond the open cathedral ---------------------------------------------------
    if (storm) {
      storm.step(dt, { camPos: pos, beat: s.beat, music: { calm: s.calm, drive: s.drive, energy: s.energySlow, tension: s.tension,
        anticipation: s.anticipation, discharge: s.discharge, minor: minorAccent } });
      // a long drive earns a strike, at a phrase boundary (every eight bars)
      const phrase = Math.floor(s.beat / 32);
      if (storm.state.wantsStrike && s.lastPhrase !== undefined && phrase !== s.lastPhrase) { stormStrike("groove"); s.grooveStrikes += 1; }
      s.lastPhrase = phrase;
      Object.assign(uniforms, storm.uniforms());
      // the direction of the brightest near bolt (it lights the architecture from that side)
      let best = null;
      for (const b of storm.bolts) if (!best || (b.layer < best.layer)) best = b;
      if (best) {
        const th = best.top + best.side * 0.5 * best.height / best.R;
        const zc = best.z + 0.5 * best.height * best.tilt / Math.hypot(1, best.tilt);
        const c = [Math.sin(th) * best.R - pos[0], 4 + Math.cos(th) * best.R - pos[1], zc - pos[2]];
        const l = Math.hypot(...c) || 1;
        uniforms.flcFlashDir = [c[0] / l, c[1] / l, c[2] / l, 0];
      } else uniforms.flcFlashDir = [0, 1, 0, 0];
    } else uniforms.flcStorm = [0, 0, 0, 0];
    return s;
  }

  function summary() {
    const r = (x, n = 2) => +x.toFixed(n);
    return { z: r(s.camZ, 1), speed: r(s.speed), calm: r(s.calm), drive: r(s.drive), tension: r(s.tension), antic: r(s.anticipation),
      charge: r(s.charge), reach: r(s.reach), shimmer: r(s.shimmer), discharge: r(s.discharge), surge: r(s.surge),
      kicks: s.kicks, drops: s.drops, majors: s.majors, minors: s.minors, teases: s.teases, solitaries: s.solitaries, converges: s.converges,
      events: events.map((e) => e.kind).join(" ") };
  }

  return { state: s, step, uniforms: () => uniforms, events, summary, storm };
}

const cache = new WeakMap();

export function bindFractalLightningCathedralDirector(gl, program, time, input, uniformLocation, opts = {}) {
  let runtime = cache.get(gl);
  if (!runtime) {
    // the storm can be switched off for comparison: localStorage "cyanescent.flcStorm" = "0"
    let stormOn = true;
    try { stormOn = globalThis.localStorage?.getItem("cyanescent.flcStorm") !== "0"; } catch { /* storage unavailable */ }
    runtime = { director: createFractalLightningCathedralDirector({ storm: stormOn }), lastTime: -1 };
    cache.set(gl, runtime);
  }
  const director = opts.director || runtime.director;
  // a frame drawn twice at the same time (transition, re-render) reuses the state
  if (time !== runtime.lastTime || opts.director) { director.step(time, input); runtime.lastTime = time; }
  const loc = (name) => uniformLocation(gl, program, name);
  for (const [name, value] of Object.entries(director.uniforms())) {
    const l = loc(name);
    if (!l) continue;
    if (typeof value === "number") gl.uniform1f(l, value);
    else if (value.length === 4) gl.uniform4f(l, value[0], value[1], value[2], value[3]);
    else gl.uniform4fv(l, value);
  }
  return director;
}
