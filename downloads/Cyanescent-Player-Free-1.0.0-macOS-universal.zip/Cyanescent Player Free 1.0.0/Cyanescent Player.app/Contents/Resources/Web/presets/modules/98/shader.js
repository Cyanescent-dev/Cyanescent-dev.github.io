export { createAbyssalLaceOrganismPresetShaderEntries as createPresetShaderEntries } from "../../abyssalLaceOrganismPresetShaderSources.js";
