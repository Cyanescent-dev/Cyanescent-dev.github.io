import { fullVisualizerSharedPrelude } from "./sharedPrelude.js";

export const vertexSource = "#version 300 es\nin vec2 position;\nout vec2 vUv;\nvoid main() {\n  vUv = position * 0.5 + 0.5;\n  gl_Position = vec4(position, 0.0, 1.0);\n}";

const fullVisualizerFallbackBody = `
void main() {
  vec2 p = (vUv - 0.5) * vec2(resolution.x / max(resolution.y, 1.0), 1.0) * 2.0;
  float r = length(p);
  float a = atan(p.y, p.x);
  vec2 feedbackUv = vUv + normalize(p + 0.0001) * (0.003 * sin(time * 0.7 + r * 12.0));
  vec3 prev = texture(previousFrame, feedbackUv).rgb * 0.88;
  float shell = smoothstep(0.78, 1.0, abs(sin(18.0 * log(r + 0.08) - time * (0.8 + level))));
  shell *= exp(-r * 1.3);
  float dust = smoothstep(0.988 - highs * 0.012, 1.0, hash(floor((p + 1.5 + vec2(time * 0.015, -time * 0.011)) * 92.0)));
  vec3 color = prev;
  color += palette60s(0.45 + a / (PI * 2.0) + time * 0.01) * shell * (0.10 + bass * 0.08 + kick * 0.06);
  color += vec3(0.72, 0.96, 1.0) * dust * highs * 0.20;
  color += palette60s(0.18 + time * 0.006) * exp(-r * 2.8) * (0.04 + globalEnergy * 0.10);
  color = blendPresetBackground(color, vUv, 0.72);
  color *= 0.98 - r * 0.02;
  color = color / (1.0 + color * 0.50);
  outColor = vec4(pow(max(color, vec3(0.0)), vec3(0.90)), 1.0);
}
`;

export const fullVisualizerFragmentSource = `${fullVisualizerSharedPrelude}${fullVisualizerFallbackBody}`;
