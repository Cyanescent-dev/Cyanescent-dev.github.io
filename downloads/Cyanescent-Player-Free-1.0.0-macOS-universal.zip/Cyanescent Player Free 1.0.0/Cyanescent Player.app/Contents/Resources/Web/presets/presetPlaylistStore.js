export const ALL_PRESETS_PLAYLIST_ID = "all";
export const CYANESCENT_PRESETS_PLAYLIST_ID = "cyanescent";
export const IMPORTED_PRESETS_PLAYLIST_ID = "imported";

const STOCK_PLAYLIST_IDS = new Set([
  CYANESCENT_PRESETS_PLAYLIST_ID,
  IMPORTED_PRESETS_PLAYLIST_ID,
  ALL_PRESETS_PLAYLIST_ID
]);

const PLAYLIST_STORAGE_KEY = "cyanescent.presetPlaylists.v1";

function safeLocalStorage() {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function readPlaylists(key) {
  const storage = safeLocalStorage();
  if (!storage) return [];
  try {
    const parsed = JSON.parse(storage.getItem(key) || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writePlaylists(key, playlists) {
  const storage = safeLocalStorage();
  if (!storage) return false;
  storage.setItem(key, JSON.stringify(playlists));
  return true;
}

function playlistId() {
  return `playlist-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function normalizePresetIds(presetIds, availablePresetIds = []) {
  const available = new Set(availablePresetIds.map(Number).filter(Number.isFinite));
  const seen = new Set();
  const ids = [];
  for (const id of presetIds || []) {
    const numeric = Number(id);
    if (!Number.isFinite(numeric) || seen.has(numeric)) continue;
    if (available.size && !available.has(numeric)) continue;
    seen.add(numeric);
    ids.push(numeric);
  }
  return ids;
}

export function createPresetPlaylistStore({
  storageKey = PLAYLIST_STORAGE_KEY,
  getAvailablePresetIds = () => [],
  loadPersisted = true
} = {}) {
  let playlists = (loadPersisted ? readPlaylists(storageKey) : [])
    .filter((playlist) => playlist && !STOCK_PLAYLIST_IDS.has(playlist.id))
    .map((playlist) => ({
      id: String(playlist.id || playlistId()),
      name: String(playlist.name || "Untitled Playlist").slice(0, 80),
      // Native-backed presets arrive asynchronously after page startup. Preserve
      // unknown IDs until every preset provider has populated the catalog.
      presetIds: normalizePresetIds(playlist.presetIds)
    }));

  function save() {
    writePlaylists(storageKey, playlists);
  }

  function all() {
    return [
      { id: CYANESCENT_PRESETS_PLAYLIST_ID, name: "Cyanescent Presets", presetIds: null, locked: true, filter: "built-in" },
      { id: IMPORTED_PRESETS_PLAYLIST_ID, name: "Imported Presets", presetIds: null, locked: true, filter: "imported" },
      { id: ALL_PRESETS_PLAYLIST_ID, name: "All Presets", presetIds: null, locked: true },
      ...playlists.map((playlist) => ({ ...playlist, presetIds: [...playlist.presetIds] }))
    ];
  }

  function custom() {
    return playlists.map((playlist) => ({ ...playlist, presetIds: [...playlist.presetIds] }));
  }

  function create(name = "New Playlist") {
    const playlist = {
      id: playlistId(),
      name: String(name || "New Playlist").trim().slice(0, 80) || "New Playlist",
      presetIds: []
    };
    playlists.push(playlist);
    save();
    return { ...playlist, presetIds: [] };
  }

  function update(id, updates = {}) {
    const playlist = playlists.find((item) => item.id === id);
    if (!playlist) return null;
    if (updates.name !== undefined) {
      playlist.name = String(updates.name || playlist.name).trim().slice(0, 80) || playlist.name;
    }
    if (updates.presetIds !== undefined) {
      playlist.presetIds = normalizePresetIds(updates.presetIds, getAvailablePresetIds());
    }
    save();
    return { ...playlist, presetIds: [...playlist.presetIds] };
  }

  function remove(id) {
    const before = playlists.length;
    playlists = playlists.filter((playlist) => playlist.id !== id);
    if (playlists.length !== before) save();
    return playlists.length !== before;
  }

  function removePresetFromAll(presetId) {
    const numeric = Number(presetId);
    let changed = false;
    playlists = playlists.map((playlist) => {
      const nextIds = playlist.presetIds.filter((id) => id !== numeric);
      if (nextIds.length !== playlist.presetIds.length) changed = true;
      return { ...playlist, presetIds: nextIds };
    });
    if (changed) save();
  }

  function cleanMissingPresets() {
    const available = getAvailablePresetIds();
    let changed = false;
    playlists = playlists.map((playlist) => {
      const presetIds = normalizePresetIds(playlist.presetIds, available);
      if (presetIds.length !== playlist.presetIds.length) changed = true;
      return { ...playlist, presetIds };
    });
    if (changed) save();
  }

  return {
    all,
    custom,
    create,
    update,
    remove,
    removePresetFromAll,
    cleanMissingPresets
  };
}
