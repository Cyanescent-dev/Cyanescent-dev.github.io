export function createBioluminescentAbyssPresetShaderEntries({ modularShaderPrelude, modularTransitionShaderBlock }) {
  return [[142, {
    name: "Bioluminescent Abyss",
    source: `${modularShaderPrelude}
${modularTransitionShaderBlock}

float smin1003(float a, float b, float k) {
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
}

float map1003(vec3 p) {
    p.xy *= rot(p.z * 0.1 + presetTime * 0.05);
    vec2 id = floor(p.xy / 3.0);
    p.xy = mod(p.xy, 3.0) - 1.5;
    
    float bRel = max(bassRel, 0.0);
    float mRel = max(midRel, 0.0);
    
    p.x += sin(p.z * 1.5 + presetTime * 2.0 + id.x) * 0.4 * (1.0 + bRel);
    p.y += cos(p.z * 1.2 + presetTime * 1.5 + id.y) * 0.4 * (1.0 + mRel);
    
    float tendrils = length(p.xy) - 0.15 - 0.05 * sin(p.z * 10.0 - presetTime * 5.0) * kickPulse;
    
    vec3 q = p;
    q.z = mod(q.z, 2.0) - 1.0;
    float pods = length(q) - 0.2 - 0.1 * mRel;
    
    float d = smin1003(tendrils, pods, 0.2);
    
    vec3 fp = p + vec3(presetTime * 0.5, presetTime * 0.2, 0.0);
    fp = mod(fp, 1.0) - 0.5;
    float particles = length(fp) - 0.02 - 0.01 * trebleRel;
    
    return min(d, particles) * 0.8;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * resolution.xy) / resolution.y;
    vec3 ro = vec3(0.0, 0.0, presetTime * 2.0);
    vec3 rd = normalize(vec3(uv, 1.0));
    rd.xy *= rot(sin(presetTime * 0.2) * 0.5);
    
    float t = 0.0;
    vec3 p;
    float d;
    float glowBlue = 0.0;
    float glowGreen = 0.0;
    
    for(int i = 0; i < 60; i++) {
        p = ro + rd * t;
        d = map1003(p);
        if(d < 0.005 || t > 20.0) break;
        
        glowBlue += 0.01 / (0.01 + abs(d)) * (1.0 + midRel);
        
        float gz = mod(p.z, 2.0) - 1.0;
        glowGreen += 0.005 / (0.005 + abs(gz)) * (1.0 + kickPulse);
        
        t += d;
    }
    
    vec3 col = vec3(0.0);
    if(t < 20.0) {
        vec2 e = vec2(0.01, 0.0);
        vec3 n = normalize(vec3(
            map1003(p + e.xyy) - map1003(p - e.xyy),
            map1003(p + e.yxy) - map1003(p - e.yxy),
            map1003(p + e.yyx) - map1003(p - e.yyx)
        ));
        
        vec3 light = normalize(vec3(1.0, 1.0, -1.0));
        float diff = max(dot(n, light), 0.0);
        
        col = vec3(0.0, 0.1, 0.2) * (diff + 0.1);
    }
    
    col += vec3(0.0, 0.3, 1.0) * glowBlue * 0.05;
    col += vec3(0.0, 1.0, 0.5) * glowGreen * 0.1;
    
    col = mix(col, vec3(0.0, 0.02, 0.05), smoothstep(10.0, 20.0, t));
    col = col / (1.0 + col);
    
    outColor = vec4(col, 1.0);
    
}
`
  }]];
}
