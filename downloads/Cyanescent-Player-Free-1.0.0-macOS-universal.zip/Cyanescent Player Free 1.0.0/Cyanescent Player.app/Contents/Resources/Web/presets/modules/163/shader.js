export { createRecursiveFeedbackTunnelPresetShaderEntries as createPresetShaderEntries } from "../../recursiveFeedbackTunnelPresetShaderSources.js";
