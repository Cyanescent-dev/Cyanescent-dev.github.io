export { createTieDyeSupernovaPresetShaderEntries as createPresetShaderEntries } from "../../tieDyeSupernovaPresetShaderSources.js";
