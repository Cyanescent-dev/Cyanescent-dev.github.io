export { createQuantumFoamPresetShaderEntries as createPresetShaderEntries } from "../../quantumFoamPresetShaderSources.js";
