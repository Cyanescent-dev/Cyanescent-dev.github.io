// Fractal Lightning Cathedral (preset 338): the Storm Beyond.
//
// The shader opens the cathedral's enclosure (side walls and ceiling; the floor becomes a slab that
// ends beyond the outer chambers) and draws, for rays that leave the architecture, three layers of
// storm cloud on cylinders around the nave axis (radii FLC_STORM_RADII), with world z as one
// coordinate, so they keep their place and parallax as the camera travels and never repeat with
// the 16-unit bays. Bolts are analytic branching channels on one of those cylinders; a strike is
// one more channel, in 3D, from the near clouds down to a node of the cathedral.
//
// This file is the storm's own state, on longer timescales than the cathedral's pulses:
//   activity   how often lightning comes and how near: sparse and distant in breakdowns, steady in
//              drives, quickening and closing in through builds; before a drop the distance falls
//              silent and only the nearest flashes keep lighting the vaults
//   mood       turbulence (cloud drift and swirl), ambient light, violet breakdown tint, embers
//   bolts      up to FLC_BOLTS cloud bolts, spawned on beat boundaries when the music has a beat,
//              aimed at directions the camera sees through the openings (seeded: video export is
//              deterministic)
//   strikes    the director calls strike() at a qualified drop (great) or, rarely, at a phrase
//              boundary in a long drive (groove); it picks the node and sends the cascade
export const FLC_BOLTS = 3;
export const FLC_STORM_RADII = [70, 150, 320];
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const follow = (x, target, dt, rise, fall) => x + (target - x) * (1 - Math.exp(-dt / (target > x ? rise : fall)));
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a) => { const l = Math.hypot(...a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

export function createCathedralStorm() {
  const s = {};
  const bolts = [];
  const uniforms = {};
  let seed = 1;
  const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  function reset() {
    bolts.length = 0;
    seed = 0x570a3;
    Object.assign(s, {
      time: 0, clock: 0, count: 0, flash: 0, glow: 0, lastBeat: null,
      nextDistant: 2, nextMid: 6, nextNear: 12,
      activity: 0.4, turbulence: 0.4, ambient: 0.8, violet: 0, embers: 0.3, hush: 0,
      strike: null, strikes: 0, greatStrikes: 0, lastStrikeAt: -1e9, wantsStrike: false,
      spawned: { distant: 0, mid: 0, near: 0 }
    });
  }
  reset();

  // Where a direction from the camera meets the cylinder of radius R: [world point, angle from zenith].
  function onCylinder(cam, azimuth, elevation, R) {
    const d = [Math.sin(azimuth) * Math.cos(elevation), Math.sin(elevation), Math.cos(azimuth) * Math.cos(elevation)];
    const o = [cam[0], cam[1] - 4];
    const a = d[0] * d[0] + d[1] * d[1], b = o[0] * d[0] + o[1] * d[1], c = o[0] * o[0] + o[1] * o[1] - R * R;
    const t = (-b + Math.sqrt(Math.max(b * b - a * c, 0))) / Math.max(a, 1e-5);
    const p = [cam[0] + d[0] * t, cam[1] + d[1] * t, cam[2] + d[2] * t];
    return { p, th: Math.atan2(p[0], p[1] - 4) };
  }

  // layer 0 near, 1 middle, 2 far. A bolt is aimed at the part of the sky the camera sees through
  // the side openings and over the vaults: from a top (azimuth from the nave's axis, elevation) down
  // to the horizon or below it, then laid on its cylinder.
  function spawn(kind, cam, strength = 1, forcedSide = 0) {
    const layer = kind === "near" ? 0 : kind === "mid" ? 1 : 2;
    const R = FLC_STORM_RADII[layer];
    const side = forcedSide || (rand() < 0.5 ? -1 : 1);
    const az = side * (kind === "near" ? 0.3 + 0.45 * rand() : 0.45 + 0.6 * rand());
    const elTop = kind === "near" ? 0.55 + 0.2 * rand() : 0.2 + 0.25 * rand();
    const elBottom = kind === "near" ? -0.25 - 0.1 * rand() : -0.05 + 0.12 * rand();
    const top = onCylinder(cam, az, elTop, R);
    const bottom = onCylinder(cam, az + side * (rand() - 0.3) * 0.25, elBottom, R);
    const dir = bottom.th >= top.th ? 1 : -1;
    const arc = (bottom.th - top.th) * R * dir;
    const dz = bottom.p[2] - top.p[2];
    const life = kind === "near" ? 1.6 : 0.9;
    const strokes = kind === "near" ? [[0.05, 1], [0.22, 0.7], [0.4, 0.9], [0.75, 0.45]] : [[0.04, 1], [0.2, 0.55 * rand() + 0.3]];
    const base = kind === "near" ? 1.4 : kind === "mid" ? 0.9 : 0.6 + 0.3 * rand();
    bolts.push({ kind, layer, R, top: top.th, z: top.p[2], height: Math.hypot(arc, dz), tilt: dz / Math.max(Math.abs(arc), 1e-3), side: dir,
      seed: Math.floor(rand() * 997), age: 0, life, strokes, strength: base * strength });
    if (bolts.length > FLC_BOLTS) bolts.shift();
    s.count += 1;
    s.spawned[kind] += 1;
  }

  // The flash of a bolt: a leader grows, then return strokes flicker.
  function envelope(b) {
    let e = 0;
    for (const [t0, k] of b.strokes) if (b.age >= t0) e = Math.max(e, k * Math.exp(-(b.age - t0) / 0.07));
    return e;
  }

  // A strike from the near clouds to target (world point on a node of the cathedral), from the
  // side of the sky it faces. kind: "great" (a qualified drop) or "groove". Returns the delay
  // until impact (the leader's travel), so the cascade starts when the channel arrives.
  function strike(target, side, kind, cam) {
    const great = kind === "great";
    // from overhead and a little outside, so the channel comes down through the gaps between the
    // vaults (the sky the camera sees above the nave)
    const from = [target[0] + side * (8 + 6 * rand()), target[1] + 26 + 8 * rand(), target[2] + 4 + 8 * rand()];
    s.strike = { kind, from, to: target.slice(), seed: Math.floor(rand() * 997), age: 0, life: great ? 2.6 : 1.6,
      strokes: great ? [[0.1, 1], [0.3, 0.8], [0.5, 1], [0.8, 0.6], [1.15, 0.45]] : [[0.08, 1], [0.3, 0.6], [0.55, 0.5]],
      strength: great ? 1.8 : 1.15 };
    s.strikes += 1;
    if (great) s.greatStrikes += 1;
    s.lastStrikeAt = s.time;
    s.wantsStrike = false;
    // the sky answers a great strike with a near bolt beside it
    if (great) spawn("near", cam, 0.8, side);
    return s.strike.strokes[0][0];
  }

  // dt: seconds; ctx: { camPos, beat, music: { calm, drive, energy, tension, anticipation, discharge, minor } }
  function step(dt, ctx) {
    const m = ctx.music || {};
    s.time += dt;
    // ---- mood ---------------------------------------------------------------------------------
    // activity: what the storm is doing over phrases (never per beat)
    const goal = clamp(0.18 + 0.45 * (m.drive ?? 0) * (0.5 + 0.5 * (m.energy ?? 0.5)) + 0.75 * (m.tension ?? 0) - 0.2 * (m.calm ?? 0));
    s.activity = follow(s.activity, goal, dt, 3, 5);
    // the hush before the drop: the sky holds its breath
    s.hush = follow(s.hush, clamp(m.anticipation ?? 0), dt, 0.8, 0.4);
    s.turbulence = follow(s.turbulence, clamp(0.2 + 0.5 * s.activity + 0.5 * (m.tension ?? 0) + 0.4 * (m.discharge ?? 0) - 0.15 * (m.calm ?? 0)), dt, 4, 8);
    s.ambient = follow(s.ambient, 0.65 + 0.35 * s.activity - 0.25 * s.hush + 0.3 * (m.discharge ?? 0), dt, 2, 4);
    s.violet = follow(s.violet, clamp((m.calm ?? 0) * 1.2), dt, 4, 6);
    s.embers = follow(s.embers, clamp(0.2 + 0.6 * (m.tension ?? 0) + 0.15 * (m.calm ?? 0)), dt, 3, 5);
    // the clouds' clock runs with the turbulence (accumulated: rate changes never jump the clouds)
    s.clock += dt * (0.5 + 1.6 * s.turbulence);

    for (const b of bolts) b.age += dt;
    for (let i = bolts.length - 1; i >= 0; i--) if (bolts[i].age > bolts[i].life) bolts.splice(i, 1);
    if (s.strike) { s.strike.age += dt; if (s.strike.age > s.strike.life) s.strike = null; }

    // ---- lightning, on beat boundaries when there is a groove ---------------------------------------
    const beatIndex = Number.isFinite(ctx.beat) ? Math.floor(ctx.beat) : null;
    const onBeat = beatIndex === null || s.lastBeat === null || beatIndex !== s.lastBeat || (m.drive ?? 0) < 0.3;
    s.lastBeat = beatIndex;
    const A = s.activity * (1 - 0.9 * s.hush);
    const cam = ctx.camPos;
    if (onBeat) {
      // the hush before a drop silences the distance; the storm's nearest flashes keep lighting the vaults
      if (s.time >= s.nextDistant && s.hush < 0.5) {
        spawn("distant", cam, 0.7 + 0.5 * A - 0.2 * (m.calm ?? 0));
        s.nextDistant = s.time + (7 - 5.6 * A) * (0.6 + 0.8 * rand());
      }
      if (s.time >= s.nextMid && A > 0.3 && s.hush < 0.5) {
        spawn("mid", cam, 0.8 + 0.4 * A);
        s.nextMid = s.time + (16 - 11 * A) * (0.6 + 0.8 * rand());
      }
      // near bolts come with builds (the storm closing in) and now and then in a strong drive
      const closing = clamp(((m.tension ?? 0) - 0.45) / 0.4);
      if (s.time >= s.nextNear && (closing > 0 || A > 0.55) && (m.calm ?? 0) < 0.4) {
        spawn("near", cam, 0.75 + 0.35 * closing);
        s.nextNear = s.time + (closing > 0 ? 9 - 4.5 * closing : 24) * (0.7 + 0.6 * rand());
      }
    }
    // minor drops and teases: a near flash, no contact
    if (m.minor) { spawn("near", cam, 0.7); s.nextNear = Math.max(s.nextNear, s.time + 6); }
    // a long drive earns a strike now and then (the director places it at a phrase boundary)
    s.wantsStrike = (m.drive ?? 0) > 0.7 && (m.calm ?? 0) < 0.2 && (m.tension ?? 0) < 0.3 && s.time - s.lastStrikeAt > 55 && s.time > 30 && !s.strike;

    // ---- uniforms -----------------------------------------------------------------------------
    let flash = 0, glow = 0;
    const UA = [], UB = [], UC = [];
    for (let i = 0; i < FLC_BOLTS; i++) {
      const b = bolts[i];
      if (!b) { UA.push(0, 0, -1e4, 1); UB.push(0, 0, 0, 1); UC.push(0, 0, 0, 0); continue; }
      const env = envelope(b);
      const grow = clamp(b.age / (b.kind === "near" ? 0.12 : 0.07));
      const after = Math.exp(-b.age / 0.5) * (b.age > 0.05 ? 1 : 0);
      // in breakdowns even distant lightning lights the vaults (the conductors are quiet)
      const near = b.layer === 0 ? 1 : b.layer === 1 ? 0.35 + 0.3 * s.violet : 0.12 + 0.3 * s.violet;
      flash = Math.max(flash, env * b.strength * near);
      glow = Math.max(glow, after * b.strength * near);
      UA.push(b.R, b.top, b.z, b.height);
      UB.push(b.seed, grow, env * b.strength, after * b.strength);
      UC.push(b.tilt, b.side, b.layer, 0);
    }
    uniforms.flcBoltA = UA; uniforms.flcBoltB = UB; uniforms.flcBoltC = UC;

    // the strike: a channel drawn in the plane through it that faces the camera
    const k = s.strike;
    if (k) {
      let env = 0;
      for (const [t0, w] of k.strokes) if (k.age >= t0) env = Math.max(env, w * Math.exp(-(k.age - t0) / 0.09));
      const impact = k.strokes[0][0];
      const grow = clamp(k.age / impact);
      const after = (k.age > impact ? 1 : 0) * Math.exp(-(k.age - impact) / (k.kind === "great" ? 1.4 : 0.8));
      const axis = sub(k.to, k.from), L = Math.hypot(...axis), u = norm(axis);
      const mid = [(k.from[0] + k.to[0]) / 2, (k.from[1] + k.to[1]) / 2, (k.from[2] + k.to[2]) / 2];
      const view = norm(sub(mid, cam));
      const n = norm(cross(cross(u, view), u));
      const v = norm(cross(n, u));
      uniforms.flcStrikeO = [...k.from, L];
      uniforms.flcStrikeU = [...u, k.seed];
      uniforms.flcStrikeV = [...v, grow];
      uniforms.flcStrikeN = [...n, env * k.strength];
      uniforms.flcStrikeT = [...k.to, after * k.strength];
      flash = Math.max(flash, env * k.strength * 0.8);
      glow = Math.max(glow, after * k.strength * 0.7);
    } else {
      uniforms.flcStrikeO = [0, -1e4, 0, 1]; uniforms.flcStrikeU = [0, 1, 0, 0]; uniforms.flcStrikeV = [1, 0, 0, 0];
      uniforms.flcStrikeN = [0, 0, 1, 0]; uniforms.flcStrikeT = [0, -1e4, 0, 0];
    }
    s.flash = flash;
    // the clouds keep a faint afterglow for a few seconds after a great flash
    s.glow = Math.max(glow, s.glow * Math.exp(-dt / 2.5));
    // on, storm clock, flash on the architecture, lingering cloud glow
    uniforms.flcStorm = [1, s.clock % 10000, flash, s.glow];
    uniforms.flcStormMood = [s.turbulence, s.ambient * (1 - 0.3 * s.hush), s.violet, s.embers];
    return s;
  }

  function summary() {
    const r = (x) => +x.toFixed(2);
    return { activity: r(s.activity), turbulence: r(s.turbulence), hush: r(s.hush), bolts: bolts.map((b) => b.kind).join(" "),
      strike: s.strike ? s.strike.kind : "", strikes: s.strikes, great: s.greatStrikes, spawned: { ...s.spawned } };
  }

  return { state: s, step, strike, uniforms: () => uniforms, bolts, reset, summary };
}
