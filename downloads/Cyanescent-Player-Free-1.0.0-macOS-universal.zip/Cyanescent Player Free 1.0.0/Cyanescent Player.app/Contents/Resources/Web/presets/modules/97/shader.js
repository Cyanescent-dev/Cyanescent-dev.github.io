export { createFeatherStarAscensionPresetShaderEntries as createPresetShaderEntries } from "../../featherStarAscensionPresetShaderSources.js";
