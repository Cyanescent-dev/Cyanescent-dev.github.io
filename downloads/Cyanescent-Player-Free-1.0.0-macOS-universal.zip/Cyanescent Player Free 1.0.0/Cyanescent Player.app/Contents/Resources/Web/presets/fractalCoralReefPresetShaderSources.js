export function createFractalCoralReefPresetShaderEntries({
    modularShaderPrelude,
    modularTransitionShaderBlock
  }) {
    const source = `${modularShaderPrelude}
  ${modularTransitionShaderBlock}
mat2 r2d(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, s, -s, c);
}

vec2 map(vec3 p, float tDist) {
    vec3 q = p;
    
    // Swaying coral branches (tied to globalEnergy for smooth motion)
    q.x += sin(q.y * 1.2 + (time * 0.5 + globalEnergy * 0.5) * 0.4) * 0.15;
    q.z += cos(q.y * 1.1 + (time * 0.5 + globalEnergy * 0.5) * 0.3) * 0.15;
    
    // Domain repetition for infinite reef
    q.xz = mod(q.xz + 6.0, 12.0) - 6.0;
    
    float scale = 1.0;
    float orb = 1000.0;
    
    for (int i = 0; i < 7; i++) {
        q = 2.0 * clamp(q, -1.0, 1.0) - q; // box fold
        
        float r2 = dot(q, q);
        orb = min(orb, r2);
        
        float k = clamp(1.4 / r2, 0.7, 2.3); // non-uniform recursive spherical inversion
        q *= k;
        scale *= k;
        
        // biological rotation
        q.xy *= r2d(0.5 + sin((time * 0.5 + globalEnergy * 0.5) * 0.03) * 0.1);
        q.yz *= r2d(0.4 + cos((time * 0.5 + globalEnergy * 0.5) * 0.04) * 0.1);
        
        q += vec3(0.6, 0.3, 0.9);
    }
    
    // Branched structure using length of xy
    float d = (length(q.xy) - 0.2) / scale;
    d = max(d, 0.3 - tDist); // CAMERA FORCEFIELD
    
    return vec2(d, orb);
}

void main() {
    vec2 uv = (vUv - 0.5) * 2.0;
    uv.x *= resolution.x / resolution.y;
    
    float camTime = time * 0.5 + globalEnergy * 0.2;
    // Keep Y height relatively constant, fly along Z and sway in X (which are domain repeated)
    vec3 ro = vec3(sin(camTime * 0.5) * 2.0, 1.0 + sin(camTime * 0.2) * 0.5, -camTime * 2.0);
    vec3 rd = normalize(vec3(uv, 0.8)); // slightly wide angle
    
    // Gentle camera rotation
    rd.xy *= r2d(sin(camTime * 0.3) * 0.15);
    rd.xz *= r2d(cos(camTime * 0.2) * 0.15);
    
    float tDist = 0.0;
    float glow = 0.0;
    vec2 res = vec2(0.0);
    
    for (int i = 0; i < 90; i++) {
        vec3 p = ro + rd * tDist;
        res = map(p, tDist);
        if (res.x < 0.002 || tDist > 40.0) break;
        tDist += res.x * 0.7; // Step multiplier for fractals
        glow += 0.02 / (0.01 + abs(res.x) * 15.0); // Accumulate glow safely
    }
    
    vec3 col = vec3(0.0);
    
    if (tDist < 40.0) {
        vec3 p = ro + rd * tDist;
        float curT = tDist;
        vec2 e = vec2(0.005, 0.0);
        vec3 n = normalize(vec3(
            map(p + e.xyy, curT).x - map(p - e.xyy, curT).x,
            map(p + e.yxy, curT).x - map(p - e.yxy, curT).x,
            map(p + e.yyx, curT).x - map(p - e.yyx, curT).x
        ));
        
        vec3 light1 = normalize(vec3(1.0, 2.0, -1.0));
        vec3 light2 = normalize(vec3(-2.0, -1.0, 2.0));
        
        float diff1 = max(dot(n, light1), 0.0);
        float diff2 = max(dot(n, light2), 0.0);
        float amb = 0.4 + 0.6 * clamp(0.5 + 0.5 * n.y, 0.0, 1.0);
        
        // Alien coral base color driven by orbit trap
        vec3 colorA = vec3(0.05, 0.5, 0.4); // teal
        vec3 colorB = vec3(0.9, 0.2, 0.5);  // magenta/pink
        vec3 baseColor = mix(colorA, colorB, clamp(res.y * 1.8, 0.0, 1.0));
        
        // Texturing / details
        baseColor += vec3(0.3, 0.9, 0.4) * smoothstep(0.7, 1.0, sin(res.y * 15.0 - (time * 0.5 + globalEnergy * 0.5) * 3.0));
        
        col = baseColor * (diff1 * 1.0 + diff2 * 0.5 + amb * 0.3);
        
        // Depth fog (water-like)
        vec3 fogColor = vec3(0.01, 0.04, 0.1);
        col = mix(col, fogColor, 1.0 - exp(-0.015 * tDist * tDist));
    } else {
        col = vec3(0.01, 0.04, 0.1);
    }
    
    // PREVENT GRAZING STROBES: Clamp total glow accumulation
    vec3 glowColor = mix(vec3(0.1, 0.7, 0.9), vec3(0.8, 0.1, 0.4), sin((time * 0.5 + globalEnergy * 0.5) * 0.25) * 0.5 + 0.5);
    col += glowColor * min(glow, 2.5) * 0.7;
    
    // Vignette and tone mapping
    col *= 1.0 - 0.4 * dot(uv, uv);
    col = col / (1.0 + col);
    col = pow(col, vec3(0.4545));
    
    outColor = vec4(col, 1.0);
}
`;
    return [[172, { name: "Fractal Coral Reef", source }]];
}
