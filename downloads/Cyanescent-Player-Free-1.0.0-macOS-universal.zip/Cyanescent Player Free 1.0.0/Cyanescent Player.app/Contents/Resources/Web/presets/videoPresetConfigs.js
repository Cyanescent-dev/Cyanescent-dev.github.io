import { capabilityEnabled, runtimeAllowsPreset } from "../config/runtimeCapabilities.js";
import { editionAllowsPreset } from "../generated/editionConfig.js";
import { presetMetadataById } from "./index.js";

import { STINKHORN_ID, STINKHORN_ASSET } from "../engine/stinkhornField.js";
import { APOLLONIAN_PHYSARUM_GENESIS_ID, APOLLONIAN_PHYSARUM_GENESIS } from "../engine/forgeHybridAsset.js";
import { NEWTON_BASIN_DESCENT_ID, NEWTON_BASIN_DESCENT } from "../engine/newtonBasinAsset.js";
import { NEWTONS_LAW_ID, NEWTONS_LAW } from "../engine/newtonLawAsset.js";
import { ARTIFICIAL_CONSCIOUSNESS_ID, ARTIFICIAL_CONSCIOUSNESS } from "../engine/artificialConsciousnessAsset.js";

// Authored source lengths, not music-responsive runtime cycle lengths. Helix
// Tunnel deliberately remains standard; HD Duoverse is retired from V1.
const FORGE_ADAPTIVE_MINIMUM_SECONDS = new Map([
  [STINKHORN_ID, STINKHORN_ASSET.durationSeconds],
  [APOLLONIAN_PHYSARUM_GENESIS_ID, APOLLONIAN_PHYSARUM_GENESIS.frameCount / APOLLONIAN_PHYSARUM_GENESIS.fps],
  [NEWTON_BASIN_DESCENT_ID, NEWTON_BASIN_DESCENT.durationSeconds],
  [NEWTONS_LAW_ID, NEWTONS_LAW.durationSeconds],
  [ARTIFICIAL_CONSCIOUSNESS_ID, ARTIFICIAL_CONSCIOUSNESS.durationSeconds]
]);

export const RADIOLARIAN_CATHEDRAL_PRESET_ID = 78;
export const EVOLUTION_OF_DANCE_PRESET_ID = 79;

const DEFAULT_VIDEO_CLIP_DURATION_SECONDS = 10;
const DEFAULT_VIDEO_CROSSFADE_SECONDS = 2.2;

const RADIOLARIAN_PLAYLIST = [
  { path: "assets/bg/bg1.mp4" },
  { path: "assets/bg/bg2.mp4" },
  { path: "assets/bg/bg3.mp4" },
  { path: "assets/bg/bg4.mp4" },
  { path: "assets/bg/bg5.mp4" },
  { path: "assets/bg/bg6.mp4" }
];

const EVOLUTION_PLAYLIST = [
  { path: "assets/bg/primordial_earth_volcanic_large.mp4", stage: 0.0 },
  { path: "assets/bg/primordial_earth_volcanic_small.mp4", stage: 0.0 },
  { path: "assets/bg/rockpool_chemical_elements.mp4", stage: 0.0 },
  { path: "assets/bg/amoeboid_organisms_ocean.mp4", stage: 1.0, duration: 8 },
  { path: "assets/bg/bg3.mp4", stage: 1.0 },
  { path: "assets/bg/bg6.mp4", stage: 1.0 },
  { path: "assets/bg/Trilobite_swimming_in_Cambrian.mp4", stage: 2.0 },
  { path: "assets/bg/giant_predatory_fish.mp4", stage: 2.0 },
  { path: "assets/bg/fish_emerging_ocean.mp4", stage: 3.0 },
  { path: "assets/bg/prehistoric_wetland_creatures.mp4", stage: 3.0 },
  { path: "assets/bg/forested_wetland_amphibians.mp4", stage: 3.0 },
  { path: "assets/bg/primeval_jungle_sunlight.mp4", stage: 4.0 },
  { path: "assets/bg/primates_dancing_jungle.mp4", stage: 4.0 },
  { path: "assets/bg/cave_people_bonfire.mp4", stage: 4.0 },
  { path: "assets/bg/psychedelic_gathering_canopies_2.mp4", stage: 5.0 },
  { path: "assets/bg/psychedelic_gathering_canopies.mp4", stage: 5.0 },
  { path: "assets/bg/gathering_canopies_trans.mp4", stage: 5.0 },
  { path: "assets/bg/flower_of_life_cosmic_realm.mp4", stage: 6.0 },
  { path: "assets/bg/giant_flower_of_life_cosmic.mp4", stage: 6.0 }
];

const VIDEO_PRESET_CONFIGS = new Map([
  [RADIOLARIAN_CATHEDRAL_PRESET_ID, { playlist: RADIOLARIAN_PLAYLIST }],
  [EVOLUTION_OF_DANCE_PRESET_ID, {
    playlist: EVOLUTION_PLAYLIST,
    playFullInAdaptiveMode: true
  }]
]);

export function createVideoPresetBackgroundConfigs() {
  return new Map([...VIDEO_PRESET_CONFIGS].filter(([presetId]) => capabilityEnabled("videoPresets") && runtimeAllowsPreset(presetId)));
}

export function videoPresetBackgroundConfig(presetId) {
  const id = Number(presetId);
  return capabilityEnabled("videoPresets") && runtimeAllowsPreset(id) ? VIDEO_PRESET_CONFIGS.get(id) || null : null;
}

export function isVideoBackgroundPreset(presetId) {
  return VIDEO_PRESET_CONFIGS.has(Number(presetId));
}

function clipDurationForItem(item) {
  const duration = Number(item?.duration || item?.durationSeconds || 0);
  return Number.isFinite(duration) && duration > 0 ? duration : DEFAULT_VIDEO_CLIP_DURATION_SECONDS;
}

export function videoPresetTotalDurationSeconds(presetId) {
  const playlist = videoPresetBackgroundConfig(presetId)?.playlist || [];
  return playlist.reduce((sum, item) => sum + clipDurationForItem(item), 0);
}

export function adaptivePresetMinimumPlaySeconds(presetId) {
  const config = videoPresetBackgroundConfig(presetId);
  const configuredMinimum = Number(presetMetadataById.get(Number(presetId))?.adaptiveMinimumPlaySeconds) || 0;
  const videoMinimum = config?.playFullInAdaptiveMode ? videoPresetTotalDurationSeconds(presetId) : 0;
  const forgeMinimum = editionAllowsPreset(presetId) ? FORGE_ADAPTIVE_MINIMUM_SECONDS.get(Number(presetId)) || 0 : 0;
  return Math.max(configuredMinimum, videoMinimum, forgeMinimum);
}

// The adaptive manager aims its landing at the exact-play seconds below and
// starts the transition transitionDurationSeconds() (2.6s) before it, while
// videoBackgroundManager fires onPlaylistEndApproaching min(3, clip * 0.25)
// before the final clip ends -- 2.5s for a 10s clip. Reporting the true total
// therefore puts the two within 0.1s of each other, and whichever wins the
// race picks the next preset. Both outcomes are safe (the loser is declined
// because a transition is already active), but the winner would vary run to
// run, changing preset selection and landing time unpredictably.
//
// The playlist-end trigger is the authority here: it watches the real clip,
// not an arithmetic estimate. Hold the adaptive landing far enough past the
// true end that it can never preempt that trigger. This margin only has to
// exceed transitionDurationSeconds() minus the trigger's lead (2.6 - 2.5).
const ADAPTIVE_PLAYLIST_END_GUARD_SECONDS = 1.5;

export function adaptivePresetExactPlaySeconds(presetId) {
  const config = videoPresetBackgroundConfig(presetId);
  if (!config?.playFullInAdaptiveMode) return 0;
  return videoPresetTotalDurationSeconds(presetId) + ADAPTIVE_PLAYLIST_END_GUARD_SECONDS;
}

export function videoBackgroundStateAt(presetId, presetTimeSeconds = 0) {
  const config = videoPresetBackgroundConfig(presetId);
  const playlist = config?.playlist || [];
  if (!playlist.length) {
    return {
      active: false,
      stage: 0,
      localTime: 0,
      duration: DEFAULT_VIDEO_CLIP_DURATION_SECONDS
    };
  }

  const totalDuration = playlist.reduce((sum, item) => sum + clipDurationForItem(item), 0) || DEFAULT_VIDEO_CLIP_DURATION_SECONDS;
  let loopTime = ((Number(presetTimeSeconds) || 0) % totalDuration + totalDuration) % totalDuration;
  let index = 0;
  let elapsedBeforeClip = 0;
  for (let i = 0; i < playlist.length; i += 1) {
    const duration = clipDurationForItem(playlist[i]);
    if (loopTime < duration || i === playlist.length - 1) {
      index = i;
      break;
    }
    loopTime -= duration;
    elapsedBeforeClip += duration;
  }

  const current = playlist[index];
  const duration = clipDurationForItem(current);
  const nextIndex = (index + 1) % playlist.length;
  const next = playlist[nextIndex];
  const fadeSeconds = Math.min(DEFAULT_VIDEO_CROSSFADE_SECONDS, duration * 0.45);
  const fadeProgress = fadeSeconds > 0
    ? Math.max(0, Math.min(1, (loopTime - (duration - fadeSeconds)) / fadeSeconds))
    : 0;

  return {
    active: true,
    presetId: Number(presetId),
    stage: Number(current?.stage || 0),
    localTime: loopTime,
    duration,
    clipIndex: index,
    primary: {
      path: current.path || current.src || "",
      time: loopTime,
      alpha: 1 - fadeProgress
    },
    secondary: fadeProgress > 0.001 ? {
      path: next.path || next.src || "",
      time: Math.max(0, loopTime - duration + fadeSeconds),
      alpha: fadeProgress,
      stage: Number(next?.stage || 0)
    } : null,
    elapsed: elapsedBeforeClip + loopTime
  };
}
