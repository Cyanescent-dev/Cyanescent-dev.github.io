import { SYSTEM_AUDIO_VALUE, systemAudioSupported, createSystemAudioInputController } from "./audio/systemAudio.js";
import { createMusicPlaylistRPC, createMusicPlaylistPersistence } from "./audio/musicPlaylistPersistence.js";
import { requestMusicPlaylistAction } from "./ui/musicPlaylistDialog.js";
import { hdWorldStatus } from './config/hdWorldAvailability.js';
import { capabilityEnabled, requireRuntimePreset } from "./config/runtimeCapabilities.js";
import { presetAnimationStartedAt } from "./engine/presetAnimationClock.js";
import { setPresetCalibrationState, selectPresetCalibration, onPresetCalibrationChanged, tunedPresetCalibrations, applyPresetCalibration } from "./ui/presetCalibration.js";
import { STINKHORN_ID } from './engine/stinkhornField.js';
import { installNativeConsoleLogging } from "./utils/nativeLogging.js";
import { VISUAL_AUDIO_SENSITIVITY } from "./config/visualSettings.js";
import { nativeAppBridge } from "./utils/nativeBridge.js";
import { clamp01, fractJs, mixJs } from "./utils/math.js";
import {
  createPlayerElementEventHandlers,
  createPlayerRuntime
} from "./audio/playerRuntime.js";
import {
  CHOOSE_EXTERNAL_AUDIO_VALUE,
  ENABLE_EXTERNAL_AUDIO_VALUE,
  createAudioInputDeviceController,
  primeExternalAudioContext,
  startExternalAudioMonitoring
} from "./audio/devices.js";
import { isAudioFileName } from "./audio/fileTypes.js";
import {
  createAudioAnalysisRuntime,
  createEmptyLookaheadState,
  createMusicAwareState
} from "./audio/analysisRuntime.js";
import {
  createAudioBands,
  createAudioFeatureState,
  readLiveAudioBands,
  smoothAudioBands,
  updateAudioFeatureState,
  updateSlowAudioBands
} from "./audio/liveAudioState.js";
import {
  createScionBiofeedbackState,
  updateScionBiofeedback,
  resetScionBiofeedbackState,
  applyScionBiofeedbackSnapshot,
  scionBiofeedbackSnapshot,
  applyScionBeatPulse,
  scionAccentIsNew,
  SCION_VISUAL_BPM
} from "./audio/scionBiofeedback.js";
import { createLiveTempoTrackerState } from "./audio/liveTempoTracker.js";
import { createLiveStructureTrackerState } from "./audio/liveStructureTracker.js";
import { createPlayerController } from "./audio/playerController.js";
import { createPlayerQueueController } from "./audio/playerQueueController.js";
import { saveDropMarkers, toggleDropMarker } from "./audio/dropMarkerStore.js";
import {
  clampTrackTime,
  registerPlayerControlHandlers,
  updateTrackTimeDisplay as updateTrackTimeDisplayView
} from "./ui/playlist.js";
import { createPlayerControlActions } from "./ui/playerControlActions.js";
import { createOptionsController } from "./ui/optionsController.js";
import { persistAppOptions } from "./ui/options.js";
import { createExportRangeModel } from "./ui/exportRange.js";
import {
  computeOfflineAudioState,
  createOfflineFrameCapture,
  buildOfflinePresetTimeline as buildOfflinePresetTimelinePlan,
  registerNativeOfflineExportCallbacks,
  renderOfflineFrame as renderOfflineFrameView
} from "./ui/musicVideoExport.js";
import { createMusicVideoExportActions } from "./ui/musicVideoExportActions.js";
import { createExportStudio } from "./ui/exportStudio.js";
import { createExportJourneyEditor } from "./ui/exportJourneyEditor.js";
import { installNativeUiPreviewBridge } from "./ui/nativeUiPreview.js";
import { createPresetTrialRuntime, isForgeArrangementTrialFixture } from "./ui/presetTrialHarness.js";
import { createPresetTrialVideoCapture } from "./engine/presetTrialVideoCapture.js";
import { createPresetCurator } from "./ui/presetCurator.js";
import { APOLLONIAN_PHYSARUM_GENESIS_ID } from "./engine/forgeHybridAsset.js";
import { DUOVERSE_HD_ID } from "./engine/duoverseAsset.js";
import { NEWTON_BASIN_DESCENT_ID } from "./engine/newtonBasinAsset.js";
import { NEWTONS_LAW_ID } from "./engine/newtonLawAsset.js";
import { HELIX_TUNNEL_ID } from "./engine/helixTunnelAsset.js";
import { ARTIFICIAL_CONSCIOUSNESS_ID } from "./engine/artificialConsciousnessAsset.js";
import { createOfflineExportController } from "./ui/offlineExportController.js";
import { createOfflineVideoTransitionCompositor } from "./ui/offlineVideoTransitionCompositor.js";
import { timelineRangeBoundaryWarnings } from "./ui/offlineTimeline.js";
import {
  createWaveformController,
  registerWaveformInteractionHandlers,
  renderWaveformTimeline
} from "./ui/waveform.js";
import {
  createPerformanceController
} from "./ui/performance.js";
import { createAppDom } from "./ui/dom.js";
import {
  registerStartAudioHandler,
  updateAudioStatusPanel
} from "./ui/audioStatus.js";
import {
  createVisualOutputController,
  isVisualOutputDocument
} from "./ui/visualOutputController.js";
import {
  registerAudioFileDropHandler,
  registerResizeHandler,
  registerUserInteractionTracker
} from "./ui/windowEvents.js";
import {
  adaptiveEligiblePresetIds as registryAdaptiveEligiblePresetIds,
  isBloodCellNebulaPreset,
  isFiddleheadPreset,
  isKleinianCoralCathedralPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isSpecialGeometryPreset,
  pineThemeForPreset,
  PRESET_CANDIDATE_METADATA,
  PRESET_METADATA,
  presetMetadataById
} from "./presets/index.js";
import {
  createPresetSelectionController
} from "./presets/selection.js";
import {
  createUserPresetStore
} from "./presets/userPresetStore.js";
import {
  createPresetPlaylistStore,
  ALL_PRESETS_PLAYLIST_ID,
  CYANESCENT_PRESETS_PLAYLIST_ID,
  IMPORTED_PRESETS_PLAYLIST_ID
} from "./presets/presetPlaylistStore.js";
import {
  createPresetCatalog,
  PresetRenderer
} from "./presets/presetCatalog.js";
import {
  createUserPresetValidator,
  CYANESCENT_PLAYER_VERSION
} from "./presets/userPresetValidator.js";
import {
  createPresetManagerUI
} from "./presets/PresetManagerUI.js";
import {
  createVideoPresetBackgroundConfigs,
  adaptivePresetExactPlaySeconds,
  adaptivePresetMinimumPlaySeconds,
  isVideoBackgroundPreset,
  videoBackgroundStateAt
} from "./presets/videoPresetConfigs.js";
import { fullVisualizerFragmentSource, vertexSource } from "./presets/shaders/fullVisualizerSource.js";
import {
  createApplicationPresetShaderRegistry,
} from "./presets/shaderRegistry.js";
import {
  createInactivePresetTransition,
  parseEnergyLevel,
  RenderMode,
  VisualTransitionMode
} from "./engine/transitions.js";
import { createVisualTransitionRuntime } from "./engine/visualTransitionRuntime.js";
import { adaptiveTransitionTimingRange, adaptiveTransitionProtectionShift } from "./engine/adaptiveTransitionManager.js";
import { createLiveVisualRuntime } from "./engine/liveVisualRuntime.js";
import { createVisualRendererSetup } from "./engine/visualRendererSetup.js";
import { fallbackFragmentSource } from "./engine/fallbackShaderSource.js";
import {
  blitSource
} from "./engine/utilityShaderSources.js";
import { createFullShaderLifecycle } from "./engine/fullShaderLifecycle.js";
import { createPresetShaderRuntime } from "./engine/presetShaderRuntime.js";
import { createVisualTextureAssetProvider } from "./engine/visualAssets.js";
import { createVideoAssetManager } from "./engine/videoAssets.js";
import { createVideoBackgroundManager } from "./engine/videoBackgroundManager.js";
import { createPresetVideoOverlay } from "./engine/presetVideoOverlay.js";
import { createAlienVisitDirector } from "./engine/alienVisits.js";
import { alienVisitSources } from "./engine/alienVisitAssets.js";
import { createVideoTransitionManager, snapshotVideoTransitionOptions } from "./engine/videoTransitionManager.js";
import { createRenderSurfaceController } from "./engine/renderSurface.js";
import { createVisualFrameRenderer } from "./engine/visualFrameRenderer.js";
import { createVisualRuntimeState } from "./engine/visualRuntimeState.js";
import { WORLDSHELL_PRESET_ID } from "./engine/worldshellResonanceRuntime.js";
import {
  createWorldshellBenchmark,
  worldshellBenchmarkConfig,
  worldshellBenchmarkLogLine
} from "./engine/worldshellBenchmark.js";
import { createStartupOrchestrator } from "./engine/startupOrchestrator.js";
import {
  createWebGlContextController
} from "./engine/webglContext.js";
import {
  createQuantumFluidRenderer,
  createSpecialGeometryRenderer
} from "./generated/editionGeometryModules.js";
import { editionConfig } from "./generated/editionConfig.js";
import { availablePresetOrFallback, filterAvailablePresetIds } from "./presets/editionAvailability.js";

installNativeConsoleLogging();

const uiPreviewParams = new URLSearchParams(window.location.search);
const uiPreviewId = uiPreviewParams.get("uiPreview") || "";
const uiPreviewFixtureId = uiPreviewParams.get("fixture") || "standard-project";
const uiPreviewActive = Boolean(uiPreviewId);
const presetTrialActive = uiPreviewParams.get("presetTrial") === "1";
const presetTrialPresetId = uiPreviewParams.get("preset") || "";
const presetTrialFixtureId = uiPreviewParams.get("fixture") || "psytrance-test";
const presetTrialTrackActive = presetTrialActive && (presetTrialFixtureId === "track-test" || presetTrialFixtureId.startsWith("stinkhorn-track") || presetTrialFixtureId.startsWith("stinkhorn-export"));
// "vt" fixtures of runtime presets (ia-vt, cm-vt-high, ...): start on preset 5, preflight the trial
// preset as an auto-transition candidate would, then video-transition into it (startup and
// end-of-transition continuity checks).
const presetTrialVideoTransitionIn = presetTrialActive && /^(ia|cm|hg)-(.*-)?vt(-|$)/.test(presetTrialFixtureId);
const presetTrialVideoEnabled = uiPreviewParams.get("video") === "1";
const presetTrialDuration = Math.max(1, Math.min(3600, Number(uiPreviewParams.get("duration")) || 30));
const presetTrialTargetFps = Math.max(15, Math.min(120, Number(uiPreviewParams.get("targetFps")) || 30));
const visualOutputRole = isVisualOutputDocument();
document.body.classList.add(visualOutputRole || presetTrialActive ? "visual-output-role" : "controller-role");
if (presetTrialActive) document.body.classList.add("preset-trial-role");

const worldshellBenchmarkConfigValue = worldshellBenchmarkConfig();
const primaryWorldshellBenchmark = worldshellBenchmarkConfigValue.enabled
  && worldshellBenchmarkConfigValue.target === "primary";
const runsLocalVisualRenderer = visualOutputRole || primaryWorldshellBenchmark || presetTrialActive;
if (primaryWorldshellBenchmark) document.body.classList.add("worldshell-benchmark-primary");
const worldshellBenchmark = createWorldshellBenchmark({
  config: worldshellBenchmarkConfigValue,
  onComplete: (result) => {
    const line = worldshellBenchmarkLogLine(result);
    if (visualOutputRole) {
      visualOutputController?.sendToMain({ action: "worldshell-benchmark-result", result });
    } else {
      nativeAppBridge()?.postMessage({ command: "appendPerfLog", line });
      console.warn(line);
      ui?.audioStatus && (ui.audioStatus.textContent = "Worldshell benchmark complete");
      ui?.audioDiagnostic && (ui.audioDiagnostic.textContent = `${result.averageFps} FPS · ${result.renderSize || "unknown render size"}`);
    }
  }
});
let worldshellBenchmarkLaunchStarted = false;
let worldshellBenchmarkFrameObserved = false;

function traceWorldshellBenchmark(event, details = {}) {
  if (!worldshellBenchmarkConfigValue.enabled) return;
  nativeAppBridge()?.postMessage({
    command: "appendPerfLog",
    line: `worldshell_benchmark_trace\t${JSON.stringify({
      event,
      role: visualOutputRole ? "secondary" : "primary",
      ...details
    })}`
  });
}

const transitionDiagnosticsQueryEnabled = new URLSearchParams(window.location.search).get("transitionDiagnostics") === "1";
const transitionDiagnosticRunEnabled = transitionDiagnosticsQueryEnabled
  && new URLSearchParams(window.location.search).get("transitionDiagnosticRun") === "1";
function transitionDiagnosticsEnabled() {
  return transitionDiagnosticsQueryEnabled
    || worldshellBenchmarkConfigValue.enabled
    || Boolean(window.__cyanescentTransitionDiagnostics);
}

const remoteTrackTimeHistory = [];

let smoothedRemoteTrackTimeBase = Number.NaN;
let smoothedRemoteTrackTimeReceivedAt = 0;
let smoothedRemoteTrackTimeRate = 0;

let smoothedRemoteAbsoluteBeatBase = 0;
let smoothedRemoteAbsoluteBeatReceivedAt = 0;
let smoothedRemoteAbsoluteBeatRate = 0;
let previousRemoteAbsoluteBeatSample = null;

const { canvas, ui } = createAppDom();
document.title = editionConfig.displayName;
document.body.dataset.edition = editionConfig.id;
for (const title of document.querySelectorAll(".engine-splash-title, .logo-title")) {
  title.textContent = editionConfig.displayName;
}
const webGlContext = createWebGlContextController({ canvas, ui, vertexSource });
const ensureWebGl = webGlContext.ensureWebGl;
const ensureFullscreenQuad = webGlContext.ensureFullscreenQuad;
const programFrom = webGlContext.programFrom;
const program = webGlContext.program;
const warmupDrawCall = webGlContext.warmupDrawCall;
const getGl = () => webGlContext.getGl();

const presetShaderRegistry = createApplicationPresetShaderRegistry();
const builtInPresetOptions = PRESET_METADATA.map((preset) => ({
  id: Number(preset.id),
  name: preset.name || `Preset ${preset.id}`,
  builtIn: true,
  imported: false
}));
const builtInPresetIds = builtInPresetOptions.map((preset) => preset.id);
const userPresetStore = createUserPresetStore({ builtInPresetIds, loadPersisted: !uiPreviewActive });
const presetCatalog = createPresetCatalog({
  builtInPresets: builtInPresetOptions,
  getUserShaderPresets: () => editionConfig.allowJsonPresetImports ? userPresetStore.all() : [],
  hasUserShader: (presetId) => presetShaderRegistry.has(Number(presetId))
});
let currentPresetPlaylistId = CYANESCENT_PRESETS_PLAYLIST_ID;

function userPresetMetadata(preset) {
  const tags = Array.isArray(preset.tags) ? preset.tags : [];
  const energyTags = Array.isArray(preset.energyTags) ? preset.energyTags : [];
  return {
    id: Number(preset.id),
    name: preset.name,
    category: preset.category || "user",
    energyLevel: energyTags.includes("high") ? "high" : energyTags.includes("low") ? "low" : "medium",
    motionIntensity: energyTags.includes("calm") ? "low" : energyTags.includes("intense") ? "high" : "medium",
    visualDensity: energyTags.includes("sparse") ? "sparse" : "medium",
    moodTags: [...tags, "imported", "user"],
    goodForBuildUps: true,
    goodForDrops: energyTags.includes("drop") || energyTags.includes("high"),
    goodForBreakdowns: energyTags.includes("calm") || energyTags.includes("breakdown"),
    imported: true,
    author: preset.author || "Unknown",
    description: preset.description || ""
  };
}

function allPresetRecords() {
  return presetCatalog.playable();
}

function registerUserPreset(preset) {
  if (!editionConfig.allowJsonPresetImports) return false;
  const id = Number(preset.id);
  if (!Number.isFinite(id) || !preset.fragmentShaderSource) return false;
  if (id < 10000 || builtInPresetIds.includes(id)) return false;
  presetShaderRegistry.modules.set(id, {
    name: `${preset.name} (Imported)`,
    source: preset.fragmentShaderSource,
    imported: true
  });
  const metadata = userPresetMetadata(preset);
  const existingIndex = PRESET_METADATA.findIndex((item) => Number(item.id) === id);
  if (existingIndex >= 0) PRESET_METADATA.splice(existingIndex, 1, metadata);
  else PRESET_METADATA.push(metadata);
  presetMetadataById.set(id, metadata);
  return true;
}

function unregisterUserPreset(presetId) {
  const id = Number(presetId);
  presetShaderRegistry.modules.delete(id);
  presetMetadataById.delete(id);
  const index = PRESET_METADATA.findIndex((item) => Number(item.id) === id);
  if (index >= 0) PRESET_METADATA.splice(index, 1);
}

for (const preset of userPresetStore.all()) {
  try {
    registerUserPreset(preset);
  } catch (error) {
    console.warn("Skipping stored user preset:", error);
  }
}

const presetPlaylistStore = createPresetPlaylistStore({
  getAvailablePresetIds: () => allPresetRecords().map((preset) => preset.id),
  loadPersisted: !uiPreviewActive
});
// Availability is an execution-time view of the authored playlists.
// Keep unavailable edition/content references in stored playlists; filter only for playback.

function playlistPresetIds(playlistId = currentPresetPlaylistId) {
  const playlist = presetPlaylistStore.all().find((item) => item.id === playlistId);
  const records = allPresetRecords();
  if (!playlist || playlist.id === ALL_PRESETS_PLAYLIST_ID) {
    return records.map((preset) => preset.id);
  }
  if (playlist.id === CYANESCENT_PRESETS_PLAYLIST_ID) {
    return records
      .filter((preset) => preset.renderer === PresetRenderer.CYANESCENT)
      .map((preset) => preset.id);
  }
  if (playlist.id === IMPORTED_PRESETS_PLAYLIST_ID) {
    return records.filter((preset) => preset.imported).map((preset) => preset.id);
  }
  if (!Array.isArray(playlist.presetIds)) {
    return allPresetRecords().map((preset) => preset.id);
  }
  return filterAvailablePresetIds(playlist.presetIds, records.map((preset) => preset.id));
}

function renderPresetDropdown(
  preferredPreset = Number(ui.presetSelect?.value) || builtInPresetOptions[0]?.id || 0,
  { preserveActivePreset = false } = {}
) {
  if (!ui.presetSelect) return;
  const ids = playlistPresetIds();
  const recordsById = new Map(allPresetRecords().map((preset) => [preset.id, preset]));
  const records = ids.map((id) => recordsById.get(Number(id))).filter(Boolean);
  ui.presetSelect.replaceChildren();
  if (!records.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = currentPresetPlaylistId === IMPORTED_PRESETS_PLAYLIST_ID
      ? "No imported presets"
      : "No presets available";
    option.disabled = true;
    option.selected = true;
    ui.presetSelect.append(option);
    ui.presetSelect.disabled = true;
    return Number(preferredPreset);
  }
  ui.presetSelect.disabled = false;
  const activeRecord = recordsById.get(Number(preferredPreset));
  const activeIsOutsidePlaylist = preserveActivePreset
    && activeRecord
    && !records.some((preset) => preset.id === Number(preferredPreset));
  if (activeIsOutsidePlaylist) {
    const option = document.createElement("option");
    option.value = String(activeRecord.id);
    option.textContent = `Current visual: ${activeRecord.name} (changes next)`;
    option.dataset.playlistAvailable = "false";
    ui.presetSelect.append(option);
  }
  for (const preset of records) {
    const option = document.createElement("option");
    option.value = String(preset.id);
    option.textContent = preset.imported ? `${preset.name} (Imported)` : preset.name;
    option.dataset.imported = preset.imported ? "true" : "false";
    option.dataset.renderer = preset.renderer;
    ui.presetSelect.append(option);
  }
  // Show missing/invalid expansions without adding them to executable playlists or Adaptive inputs.
  for (const preset of PRESET_CANDIDATE_METADATA.filter(p => p.optional && !recordsById.has(p.id))) {
    const status = hdWorldStatus(preset.id);
    const option = document.createElement("option");
    option.value = String(preset.id);
    option.disabled = true;
    option.dataset.playlistAvailable = "false";
    option.textContent = `${preset.name} — ${status.state === 'missing' ? 'HD World — Not Installed' : status.message}`;
    option.title = status.message;
    ui.presetSelect.append(option);
  }
  const selected = activeIsOutsidePlaylist
    ? Number(preferredPreset)
    : availablePresetOrFallback(preferredPreset, records.map((preset) => preset.id));
  const fallback = selected ?? records[0]?.id ?? builtInPresetOptions[0]?.id ?? 0;
  if (Number.isFinite(Number(preferredPreset)) && !records.some((preset) => preset.id === Number(preferredPreset))) {
    console.warn(`[${editionConfig.displayName}] Preset ${preferredPreset} is unavailable; using ${fallback} without changing saved playlist data.`);
  }
  ui.presetSelect.value = String(fallback);
  return fallback;
}

function renderPresetPlaylistDropdown(preferredPlaylist = currentPresetPlaylistId) {
  if (!ui.presetPlaylistSelect) return;
  const playlists = presetPlaylistStore.all()
    .filter((playlist) => playlist.id !== ALL_PRESETS_PLAYLIST_ID);
  ui.presetPlaylistSelect.replaceChildren();
  for (const playlist of playlists) {
    const option = document.createElement("option");
    option.value = playlist.id;
    option.textContent = playlist.name;
    ui.presetPlaylistSelect.append(option);
  }
  currentPresetPlaylistId = playlists.some((playlist) => playlist.id === preferredPlaylist)
    ? preferredPlaylist
    : CYANESCENT_PRESETS_PLAYLIST_ID;
  ui.presetPlaylistSelect.value = currentPresetPlaylistId;
}

function refreshPresetSelectionUi(
  preferredPlaylist = currentPresetPlaylistId,
  preferredPreset = Number(ui.presetSelect?.value) || builtInPresetOptions[0]?.id || 0,
  options = {}
) {
  renderPresetPlaylistDropdown(preferredPlaylist);
  return renderPresetDropdown(preferredPreset, options);
}

refreshPresetSelectionUi();

function playerIsActivelyPlaying() {
  return Boolean(playerAudio && !playerAudio.paused && !playerAudio.ended);
}

const presetShaderRuntime = createPresetShaderRuntime({
  registry: presetShaderRegistry,
  compileProgram: program,
  warmupDrawCall,
  isPlaybackActive: playerIsActivelyPlaying,
  isLiveRenderLoopRunning: () => liveVisualRuntime.isRenderLoopRunning(),
  renderMode: () => renderMode,
  offlineRenderMode: RenderMode.OFFLINE_EXPORT,
  getLastUserInteractionAt: () => lastUserInteractionAt,
  shellProgram: () => shellRenderProgram,
  fullProgram: () => fullRenderProgram,
  fullShaderReady: () => visualFullShaderReady,
  setShellActive: (shellActive) => {
    visualShellActive = shellActive;
  },
  setErrorText: (message) => {
    visualErrorText = message;
  },
  setStatus: (message) => {
    ui.audioStatus.textContent = message;
  },
  setDiagnostic: (message) => {
    ui.audioDiagnostic.textContent = message;
  },
  getDiagnosticText: () => ui.audioDiagnostic.textContent
});

function presetShaderModuleId(presetValue) {
  return presetShaderRuntime.moduleIdForPreset(presetValue);
}

function queuePresetShaderModulePrime(presetValue, delay = 1200, qualityValue = quality) {
  presetShaderRuntime.queuePrime(presetValue, delay, qualityValue);
}

function ensurePresetShaderModule(presetValue, options = {}, qualityValue = quality) {
  return presetShaderRuntime.ensure(presetValue, options, qualityValue);
}

function renderProgramForPreset(presetValue, qualityValue = quality) {
  return presetShaderRuntime.renderProgramForPreset(presetValue, qualityValue);
}

function primePresetShaderModule(presetValue, delay = 0, qualityValue = quality) {
  presetShaderRuntime.prime(presetValue, delay, qualityValue);
}


let renderProgram = null;
let shellRenderProgram = null;
let fullRenderProgram = null;
let blitProgram = null;
const textureAssets = createVisualTextureAssetProvider({ getGl: ensureWebGl });
const videoAssetManager = createVideoAssetManager();
const videoBackgroundManager = createVideoBackgroundManager({
  container: ui.videoBackgroundContainer,
  videoA: ui.bgVideoA,
  videoB: ui.bgVideoB,
  assetManager: videoAssetManager,
  presetConfigs: createVideoPresetBackgroundConfigs(),
  shouldHoldPlaylistEnd: (presetId) => {
    return visualTransitions?.getTransitionMode?.() === VisualTransitionMode.ADAPTIVE
      && adaptivePresetExactPlaySeconds(presetId) > 0;
  },
  onPlaylistEndApproaching: ({ presetId }) => {
    // Only the visual output document runs the render loop, so only it ever
    // sees the playlist reach its end (videoBackgroundManager.update() is
    // driven from that loop). But that document does not own the preset
    // engine -- see the Cmd+Right relay further down, which states the same
    // rule. Starting a transition here begins one the primary document never
    // learns about: its own `transition` stays the inactive placeholder, so
    // its adaptive manager sees an idle engine plus a newly active preset,
    // immediately begins a second transition, and pushes it over via
    // setTransition -- clobbering this one mid-swap. That is the glitch
    // leaving Evolution of Dance: the incoming preset appears, then is torn
    // away for a third one. Relay instead, and let the primary document run
    // beginPlaylistEndTransition() exactly as it would for any other source.
    if (visualOutputRole) {
      visualOutputController?.sendToMain({ action: "playlist-end", presetId });
      return true;
    }
    return beginPlaylistEndTransition(presetId);
  }
});

// Shared by the local (primary-document) path above and the relayed request
// from the visual output window, so both take exactly the same route.
function beginPlaylistEndTransition(presetId) {
  if (!visualTransitions) return false;
  if (visualTransitions.getTransitionMode?.() !== VisualTransitionMode.ADAPTIVE) return false;
  if (adaptivePresetExactPlaySeconds(presetId) <= 0) return false;
  if (visualTransitions.getTransition()?.active) return true;
  const nextPreset = visualTransitions.chooseNextPreset();
  if (Number(nextPreset) === Number(presetId)) return false;
  // Deliberately NOT "adaptive": notePresetStartedForAdaptive() skips
  // markPresetStarted() for that source, assuming the adaptive manager began
  // the transition itself and already recorded the landing. This trigger
  // bypasses that flow, so under "adaptive" the manager is never told a new
  // preset began and treats the incoming one as instantly overdue.
  return visualTransitions.begin(nextPreset, "playlist-end", { style: 0 });
}

// Phase Space Reef (preset 54)'s clam: a single foreground video overlay,
// distinct from videoBackgroundManager above (which crossfades full-bleed
// clips behind the canvas). See web/engine/presetVideoOverlay.js.
//
// "-transitions" is the join-repaired cut: the source stitch had six
// visible clam-geometry joins plus a mismatched loop seam, each now masked
// by a composited underwater energy-bloom overlay timed to the exact join
// frame. The original un-repaired file stays on disk at
// assets/bg/phase-space-reef-clam.mp4 (untouched, unreferenced) — revert by
// pointing `source` back at it.
const PHASE_SPACE_REEF_PRESET_ID = 54;
const phaseSpaceReefClamOverlay = createPresetVideoOverlay({
  video: ui.phaseSpaceReefClamOverlay,
  source: "assets/bg/phase-space-reef-clam-transitions.mp4"
});
// Alien Visits: scheduled semi-transparent video intrusions over the running
// preset. The session clock is tied to playerIsActivelyPlaying() so a paused
// set does not burn encounters, and it reuses the existing music-aware state
// rather than analysing anything itself. See web/engine/alienVisits.js.
const alienVisitDirector = createAlienVisitDirector({
  video: ui.alienVisitOverlay,
  sources: alienVisitSources(),
  isEnabled: () => capabilityEnabled("alienVisits") && optionsController.options?.alienVisits !== false,
  isSessionActive: () => (visualOutputRole ? remotePlaying : playerIsActivelyPlaying())
    && !presetTrialActive,
  isSceneSafe: alienVisitSceneIsSafe,
  isTransitionActive: () => Boolean(visualTransitions?.getTransition?.()?.active)
    || Boolean(videoTransitionManager?.isCoveringOutput?.(0.001)),
  getMusicAwareState: () => musicAwareState,
  getAudioFeatures: () => audioFeatures
});

// An encounter is only allowed to land well inside a rendered preset. Compositing
// one over a preset transition reads as a broken crossfade rather than an
// intrusion, and compositing one over a video-backed preset stacks video on
// video, which just looks like a muddle.
const ALIEN_PRESET_SETTLE_MS = 12000;      // how far into a preset before one may start
const ALIEN_TRANSITION_CLEARANCE_MS = 6000; // and how far clear of the next one
function alienVisitSceneIsSafe() {
  // Mid-transition, in either direction.
  const transition = visualTransitions?.getTransition?.();
  if (transition?.active) return false;
  // A transition video is still on screen even after the preset swap lands.
  if (videoTransitionManager?.isCoveringOutput?.(0.001)) return false;
  // Video-backed presets (Radiolarian Cathedral, Evolution of Dance) are
  // already showing full-bleed footage; a second video over them is a mess.
  if (isVideoBackgroundPreset(activePreset)) return false;
  if (videoBackgroundManager?.activePreset?.() != null) return false;
  const now = performance.now();
  // Part way through, not on either edge.
  if (now - activePresetStartedAt < ALIEN_PRESET_SETTLE_MS) return false;
  // The shuffle deadline is only meaningful in shuffle mode. In static and
  // adaptive mode nothing advances it, so it sits permanently in the past --
  // reading it unconditionally would mark every scene unsafe forever and
  // silently disable the whole feature in the default mode.
  if (visualTransitions?.getTransitionMode?.() === VisualTransitionMode.SHUFFLE) {
    const nextShuffle = Number(visualTransitions?.nextShuffleAt?.());
    if (Number.isFinite(nextShuffle) && nextShuffle - now < ALIEN_TRANSITION_CLEARANCE_MS) return false;
  }
  return true;
}
let videoTransitionManager = null;

let visualsReady = false;
let visualFallbackActive = false;
let visualErrorText = "";
let lastUserInteractionAt = performance.now();
let visualShellActive = false;
let visualFullShaderReady = false;
const FULL_SHADER_IDLE_GRACE_MS = 15000;
let visualEngineWarmupPromise = null;
let visualEngineBootComplete = false;
let offlineVideoBackgroundState = null;
let musicVideoPreview = null;
let presetDemoPreview = null;
const presetDemoTimeData = new Uint8Array(512);
let presetTrialRuntime = null;
const presetTrialCaptureRequests = [];
let presetTrialMetadata = null;
let presetTrialFirstRenderLogged = false;
let presetTrialFrameProbeCount = 0;
let presetTrialLastCanvasProbe = { valid: false };

function presetTrialLog(scope, event, details = {}) {
  if (!presetTrialActive) return;
  const text = `[PRESET_TRIAL][${scope}][${event}] ${JSON.stringify(details)}`;
  nativeAppBridge()?.postMessage({ command: "logConsole", type: "info", text });
}

// Atomic GPU-backed Forge playback owns both the beauty and augmentation in
// the production canvas. Capture its immutable presented source, never the
// independently advancing HTMLVideoElement used for decoding.
function captureForgeGpuTrialFrame({ canvas: productionCanvas, sourceCanvas, captureSource, alignment = {}, effects = {},
  controls = {}, fixture, fixtureTime, mediaClockTime, compare = true }) {
  const frame = { ...alignment, fieldFrames: alignment.fieldFrames ? [...alignment.fieldFrames] : null };
  const composite = productionCanvas.toDataURL("image/png");
  if (!compare) return { composite, comparison: null };
  const presentedSource = captureSource();
  if (!presentedSource || !presentedSource.width || !presentedSource.height) {
    throw new Error("Forge GPU source is not ready for a coherent frame capture");
  }
  if (sourceCanvas.width !== productionCanvas.width || sourceCanvas.height !== productionCanvas.height) {
    sourceCanvas.width = productionCanvas.width;
    sourceCanvas.height = productionCanvas.height;
  }
  const context = sourceCanvas.getContext("2d");
  context.globalAlpha = 1;
  context.fillStyle = "#03040a";
  context.fillRect(0, 0, sourceCanvas.width, sourceCanvas.height);
  const aspect = presentedSource.width / presentedSource.height;
  const width = Math.min(sourceCanvas.width, sourceCanvas.height * aspect), height = width / aspect;
  context.drawImage(presentedSource, (sourceCanvas.width - width) * 0.5, (sourceCanvas.height - height) * 0.5, width, height);
  const source = sourceCanvas.toDataURL("image/png");
  return { composite, comparison: {
    source, overlay: composite, composite,
    diagnostics: {
      fixture, fixtureTime,
      capturedVideoTime: frame.videoTime ?? null,
      mediaClockTime,
      renderVideoTime: frame.videoTime ?? null,
      fieldVideoTime: frame.videoTime ?? null,
      fieldFrames: frame.fieldFrames,
      fieldMix: frame.fieldMix ?? null,
      videoPresentation: frame.videoPresentation ?? "gpu",
      presentedVideoFrame: frame.presentedVideoFrame ?? null,
      sourceVideoFrame: frame.presentedVideoFrame ?? null,
      frameCoherent: frame.frameCoherent ?? false,
      sourceCapture: "presented-gpu-video",
      sourceCaptureMode: "shared-gl-video-texture",
      overlayIncludesBackground: true,
      debug: controls.debug ?? null,
      braids: { ...effects.braids }, effects: { ...effects.effects }, cues: { ...effects.cues }, controls: { ...controls },
      width: sourceCanvas.width, height: sourceCanvas.height,
      sourceWidth: presentedSource.width, sourceHeight: presentedSource.height
    }
  } };
}

function presetTrialCanvasProbe(stage, record = true) {
  if (!presetTrialActive) return { valid: false };
  const context = getGl();
  const rect = canvas.getBoundingClientRect();
  const base = {
    stage,
    cssWidth: Math.round(rect.width), cssHeight: Math.round(rect.height),
    backingWidth: canvas.width, backingHeight: canvas.height,
    devicePixelRatio: window.devicePixelRatio || 1
  };
  if (!context || canvas.width < 2 || canvas.height < 2) {
    if (record) presetTrialLog("WEB", "CANVAS_SIZE", base);
    return { valid: false };
  }
  const sampleWidth = Math.min(16, canvas.width);
  const sampleHeight = Math.min(16, canvas.height);
  const pixels = new Uint8Array(sampleWidth * sampleHeight * 4);
  context.bindFramebuffer(context.FRAMEBUFFER, null);
  context.readPixels(
    Math.max(0, Math.floor((canvas.width - sampleWidth) / 2)),
    Math.max(0, Math.floor((canvas.height - sampleHeight) / 2)),
    sampleWidth, sampleHeight, context.RGBA, context.UNSIGNED_BYTE, pixels
  );
  let luminance = 0;
  let nonBlack = 0;
  for (let index = 0; index < pixels.length; index += 4) {
    const value = (pixels[index] * 0.2126 + pixels[index + 1] * 0.7152 + pixels[index + 2] * 0.0722) / 255;
    luminance += value;
    if (value > 0.012) nonBlack += 1;
  }
  const glError = context.getError();
  const result = { ...base, averageLuminance: luminance / (sampleWidth * sampleHeight), nonBlackPixels: nonBlack, glError, viewport: Array.from(context.getParameter(context.VIEWPORT) || []), framebufferStatus: context.checkFramebufferStatus(context.FRAMEBUFFER), currentProgram: Boolean(context.getParameter(context.CURRENT_PROGRAM)), blend: context.isEnabled(context.BLEND), scissor: context.isEnabled(context.SCISSOR_TEST), colorMask: Array.from(context.getParameter(context.COLOR_WRITEMASK) || []) };
  if (record) presetTrialLog("WEBGL", stage === "first-frame" ? "FIRST_CANVAS_SAMPLE" : "CANVAS_SAMPLE", result);
  return { valid: result.averageLuminance > 0.003 || result.nonBlackPixels > 2, result };
}

const specialGeometryRenderer = createSpecialGeometryRenderer({
  getGl: ensureWebGl,
  getCanvas: () => canvas,
  getQuad: ensureFullscreenQuad,
  program,
  programFrom,
  pineThemeForPreset,
  getSmooth: () => smooth,
  getMusicAwareState: () => musicAwareState,
  getAudioFeatures: () => audioFeatures,
  getActivePresetStartedAt: () => activePresetStartedAt,
  getQuality: () => quality,
  getTimeData: visualAudioTimeData,
  textureAssets
});

const {
  ensurePineResources,
  ensureFernGeometryResources,
  ensureKleinianCoralCathedralResources,
  ensureBloodCellNebulaResources,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula
} = specialGeometryRenderer;

const quantumFluidRenderer = createQuantumFluidRenderer({
  getGl: ensureWebGl,
  getCanvas: () => canvas,
  getQuad: ensureFullscreenQuad,
  program,
  programFrom,
  getSmooth: () => smooth,
  getMusicAwareState: () => musicAwareState,
  getAudioFeatures: () => audioFeatures,
  getActivePresetStartedAt: () => activePresetStartedAt,
  getQuality: () => quality,
  getAnalysisTimeline: () => analysisTimeline,
  textureAssets
});

const {
  ensureResources: ensureQuantumFluidResources,
  renderQuantumFluid3D
} = quantumFluidRenderer;

let renderSurface = null;
let quality = 0;
let playerRuntime = null;
let audioAnalysisRuntime = null;
let visualOutputController = null;
let stream;
let externalInputSource = null;
let playerAudio;
let playerMode = false;
let uiPreviewFixtureTrackName = "";
let uiPreviewFixtureDuration = 0;
let monitoringInput = false;
let externalAudioNotice = null;
let scionActive = false;
let scionPaused = false;
// Whether Scion is genuinely live *this frame* - the same guarded condition
// updateAudio() has always used before touching scionBiofeedback, now also
// gating the synthetic visual beat clock and the energy/kick-pulse blending
// in liveAudioState.js. See updateAudio().
let scionLive = false;
let scionAdaptiveNextAt = 0;
let scionAdaptivePresetStartedAt = null;
let scionVolume = uiPreviewActive
  ? 0.25
  : Math.max(0, Math.min(1, Number(localStorage.getItem("cyanescentScionVolume")) || 0.25));
let analysisTimeline = null;
let analysisGeneration = 0;
let analysisPending = false;
let lookaheadState = createEmptyLookaheadState();
let musicAwareState = createMusicAwareState();
let bands = createAudioBands();
let meterBands = createAudioBands();
let smooth = createAudioBands();
let slowLevel = 0.0;
let slowBass = 0.0;
// Pocket SCÍON biofeedback, kept separate from the music bands so presets can
// treat a living organism's signal as its own input. See audio/scionBiofeedback.js.
const scionBiofeedback = createScionBiofeedbackState();
let remoteTrackTime = Number.NaN;
let remoteTrackProgress = 0;
let remoteTimeData = new Uint8Array(512);
let remoteStateReceived = false;
// The detached visual output has no player audio of its own, so it cannot ask
// playerIsActivelyPlaying(). The controller sends its playback state instead;
// Alien Visits uses it as the session clock in that window.
let remotePlaying = false;
let remoteTransitionId = "";
let completedRemoteTransitionId = "";
let lastReportedOutputPreset = null;
let visualTransitions = null;
const audioFeatures = createAudioFeatureState();
// Online BPM/phase tracker used only while there is no pre-analyzed
// timeline to fall back on (external input, or the Scion synth monitor).
// See audio/liveTempoTracker.js.
const liveTempoTracker = createLiveTempoTrackerState();
// Structural novelty + phrase-alignment + build/drop/breakdown classifiers
// for that same live-input case. See audio/liveStructureTracker.js.
const liveStructureTracker = createLiveStructureTrackerState();
// One source of truth for every export surface. It starts empty, resets when a
// new audio source is loaded, and is clamped again when media metadata arrives.
const exportRangeModel = createExportRangeModel();
ui.__exportRangeModel = exportRangeModel;
playerRuntime = createPlayerRuntime({
  volumeControl: ui.playerVolume,
  getPlayerAudio: () => playerAudio,
  setPlayerAudio: (audio) => { playerAudio = audio; },
  getAnalysisTimeline: () => analysisTimeline,
  stopInputStream,
  setPlayerMode: (value) => { playerMode = value; },
  activateVisuals,
  playerElementEvents: createPlayerElementEventHandlers({
    ui,
    handleTrackEnded,
    updateTrackTimeDisplay,
    updateWaveformProgress,
    pendingAutoplay: () => playerController.pendingAutoplay(),
    autoplayLoadedTrack: () => playerController.autoplayLoadedTrackFromFinder(),
    handleSeek: (time) => visualTransitions.handleSeek(time),
    onDurationAvailable: () => {
      exportRangeModel.setTrackDuration(playerRuntime?.playerDuration?.() || 0, { preserveSelection: true });
    },
    onPlaybackStateChanged: (state) => playerQueueController.setPlaybackState(state),
    handlePlayerError: audio => playerController?.handleMediaError(audio),
    onVisualPlaybackStarted: () => {
      activateVisuals(0);
    }
  })
});
const visualRuntimeState = createVisualRuntimeState({
  getAudioFeatures: () => audioFeatures,
  getMusicAwareState: () => musicAwareState,
  getSlowLevel: () => slowLevel
});

let activePreset = Number(ui.presetSelect.value);
let activePresetStartedAt = performance.now();
const presetSelection = createPresetSelectionController({
  select: ui.presetSelect,
  shuffleSecondsControl: ui.shuffleSeconds,
  adaptiveEligiblePresetIds: (presetIds) => registryAdaptiveEligiblePresetIds(presetIds),
  getActivePreset: () => activePreset
});
let exportResolutionOverride = null;
const exportState = {
  active: false,
  previousQuality: 0,
  previousTime: 0,
  wasPlaying: false,
  outputPath: "",
  savedPath: "",
  blobUrl: "",
  nativeSaveResolver: null,
  nativeSaveRejecter: null,
  offlineBeginResolver: null,
  offlineBeginRejecter: null,
  offlineFrameResolver: null,
  offlineFrameRejecter: null,
  offlineFinishResolver: null,
  offlineFinishRejecter: null,
  cancelRequested: false,
  startedAt: 0,
  lastFrameIndex: -1
};
let renderMode = RenderMode.LIVE;
let offlineRenderClock = null;
const offlineVisualTimeData = new Uint8Array(512);

function visualAudioTimeData() {
  if (presetDemoPreview || (presetTrialRuntime && !presetTrialTrackActive)) return presetDemoTimeData;
  if (renderMode !== RenderMode.OFFLINE_EXPORT || !offlineRenderClock) {
    if (visualOutputRole && remoteStateReceived) return remoteTimeData;
    return playerRuntime?.timeData || null;
  }
  const time = Number(offlineRenderClock.videoTimeSeconds) || 0;
  const amplitude = Math.max(0.04, Math.min(0.92, Number(smooth.level) * 0.72 + Number(smooth.bass) * 0.28));
  for (let index = 0; index < offlineVisualTimeData.length; index += 1) {
    const sampleTime = time + index / 44100;
    const bassWave = Math.sin(sampleTime * Math.PI * 2 * 92) * (0.58 + Number(smooth.bass) * 0.35);
    const midWave = Math.sin(sampleTime * Math.PI * 2 * 440) * Number(smooth.mids) * 0.28;
    const kickWave = Math.sin(sampleTime * Math.PI * 2 * 55) * Number(smooth.kick) * 0.42;
    const sample = Math.max(-1, Math.min(1, (bassWave + midWave + kickWave) * amplitude));
    offlineVisualTimeData[index] = Math.round(128 + sample * 127);
  }
  return offlineVisualTimeData;
}
let performanceController = null;

const fullShaderLifecycle = createFullShaderLifecycle({
  ui,
  ensureWebGl,
  vertexSource,
  fragmentSource: fullVisualizerFragmentSource,
  compileFullscreenProgram: program,
  warmupDrawCall,
  renderMode: () => renderMode,
  offlineRenderMode: RenderMode.OFFLINE_EXPORT,
  isPlaying: playerIsActivelyPlaying,
  getLastUserInteractionAt: () => lastUserInteractionAt,
  idleGraceMs: FULL_SHADER_IDLE_GRACE_MS,
  getReady: () => visualFullShaderReady,
  getProgram: () => fullRenderProgram,
  setProgram: (compiledProgram) => {
    fullRenderProgram = compiledProgram;
  },
  setRenderProgram: (compiledProgram) => {
    renderProgram = compiledProgram;
  },
  setShellActive: (shellActive) => {
    visualShellActive = shellActive;
  },
  setReady: (ready) => {
    visualFullShaderReady = ready;
  },
  setErrorText: (message) => {
    visualErrorText = message;
  },
  clearFeedbackBuffers,
  hasFeedbackBuffers: () => renderSurface?.hasBuffers(),
  visualsReady: () => visualsReady,
  visualFallbackActive: () => visualFallbackActive
});

function compileFullShaderSynchronouslyForStartup() {
  fullShaderLifecycle.markSynchronousReady();
  visualFallbackActive = false;
  visualErrorText = "";
  if (renderSurface.hasBuffers()) clearFeedbackBuffers();
}

function waitForFullShaderReady(timeoutMs = 90000) {
  return fullShaderLifecycle.waitUntilReady(timeoutMs, () => visualErrorText);
}

function fullShaderCompiler() {
  return fullShaderLifecycle.getCompiler();
}

function startFullShaderCompile() {
  fullShaderLifecycle.start();
}

function scheduleFullShaderCompile(delay = 1200) {
  fullShaderLifecycle.schedule(delay);
}

const startupOrchestrator = createStartupOrchestrator({
  ui,
  setBootComplete: (value) => {
    visualEngineBootComplete = value;
  },
  loadPlayerFiles,
  releaseObjectUrls,
  setPlayerQueue,
  appendNativeTracks: (tracks, autoplay, options = {}) => {
    if (options.source === 'default-startup' && musicPlaylistPersistence && !musicPlaylistPersistence.shouldLoadDefaultFolder()) return Promise.resolve();
    return playerController.appendPlayerTracks(tracks, autoplay);
  },
  enterFullscreen: () => {
    visualOutputController?.toggleFullscreen();
  },
  initializeDefaultFolderOptions: visualOutputRole || uiPreviewActive ? () => {} : initializeDefaultFolderOptions,
  reportPlayerError: (prefix, error) => {
    ui.audioStatus.textContent = "player error";
    ui.audioDiagnostic.textContent = `${prefix}: ${error.message || "unknown error"}`;
    console.error(error);
  },
  ensureFernGeometryResources,
  ensurePineResources,
  ensureAdditionalGeometryResources: () => {
    ensureKleinianCoralCathedralResources();
    ensureQuantumFluidResources();
    ensureBloodCellNebulaResources();
  },
  warmPresetModules: async (onProgress = null) => {
    if (!presetTrialActive || !presetTrialMetadata) return await presetShaderRuntime.manager().warm({ force: true }, onProgress);
    presetTrialLog("REGISTRY", "READY", { presetId: presetTrialMetadata.id, preset: presetTrialMetadata.name });
    onProgress?.(0, `Compiling: ${presetTrialMetadata.name}`);
    if (presetTrialFixtureId === 'helix-transition' || presetTrialFixtureId.startsWith('stinkhorn-switch') || presetTrialVideoTransitionIn) ensurePresetShaderModule(5, { force: true });
    const compiled = ensurePresetShaderModule(presetTrialMetadata.id, { force: true });
    const state = presetShaderRuntime.diagnosticState(presetTrialMetadata.id, quality);
    const nonModular = state?.state === "not-modular";
    presetTrialLog("WEBGL", compiled ? "PROGRAM_LINKED" : (nonModular ? "PROGRAM_NOT_MODULAR" : "PROGRAM_FAILED"), { presetId: presetTrialMetadata.id, state });
    // Geometry presets use the same production renderer but intentionally do
    // not have a modular shader module. Their readiness is established by the
    // renderer's first valid frame, not by a modular-program compile result.
    if ((!compiled && !nonModular) || state?.state === "error") throw new Error(state?.error || `Could not compile ${presetTrialMetadata.name}`);
    onProgress?.(1, `${presetTrialMetadata.name} ready`);
  },
  // Trial mode exercises the selected production preset program directly.
  // Do not wait for the unrelated monolithic full-visual shader warmup: on a
  // hidden/dev WKWebView it can be idle-throttled before the first frame,
  // preventing the selected renderer from ever being activated.
  isFullShaderReady: () => presetTrialActive || (visualFullShaderReady && fullRenderProgram),
  startFullShaderCompile,
  fullShaderStatus: () => fullShaderCompiler().status(),
  compileFullShaderSynchronously: compileFullShaderSynchronouslyForStartup,
  waitForFullShaderReady,
  createRenderer: () => initializeVisualEngine({ reveal: false, compileFull: false }),
  allocateFrameBuffers: async () => {
    renderProgram = fullRenderProgram || renderProgram;
    visualShellActive = !visualFullShaderReady;
    resize();
    clearFeedbackBuffers();
    await warmLiveRenderPathDuringSplash();
  },
  finalizeReady: () => {
    if (!visualFallbackActive) {
      ui.audioStatus.textContent = "player ready";
      ui.audioDiagnostic.textContent = "Visual engine ready";
    }
  },
  finalizeError: (error) => {
    const message = error?.message || "Visual engine warmup failed";
    visualErrorText = message;
    visualFallbackActive = Boolean(visualsReady && shellRenderProgram);
    ui.audioStatus.textContent = visualFallbackActive ? "visual fallback" : "shader error";
    ui.audioDiagnostic.textContent = `Visual engine warmup failed: ${message}`;
    return visualFallbackActive;
  },
  onSplashProgress: (progress, status) => {
    if (visualOutputRole) visualOutputController?.reportWarmupProgress(progress, status);
  }
});

const setLocalSplashProgress = startupOrchestrator.setSplashProgress;
function setSplashProgress(progress, status) {
  setLocalSplashProgress(progress, status);
}
const setAppReady = startupOrchestrator.setAppReady;
const processPendingInitialBootActions = startupOrchestrator.processPendingInitialBootActions;

function warmVisualEngineAtStartup(options = {}) {
  visualEngineWarmupPromise = startupOrchestrator.runVisualEngineStartup(options);
  videoAssetManager.loadTransitionManifests().catch((error) => {
    console.warn("Video transition manifests are not available yet:", error);
  });
  return visualEngineWarmupPromise;
}

let musicPlaylistPersistence = null;
let musicPersistenceMessage = '', musicFeedbackMessage = '', musicCanReload = false;
function renderMusicNotice() {
  const message = [musicPersistenceMessage, musicFeedbackMessage].filter(Boolean).join(' ');
  ui.musicPlaylistNotice.hidden = !message;
  ui.musicPlaylistNoticeText.textContent = message;
  ui.reloadMusicPlaylists.hidden = !musicCanReload;
}
function reportMusicFeedback(message = '') { musicFeedbackMessage = message; renderMusicNotice(); }
window.__musicImportStatus = ({message = ''} = {}) => reportMusicFeedback(message);
const playerQueueController = createPlayerQueueController({
  ui,
  updateTrackTimeDisplay,
  hasPlayerSource: () => Boolean(playerAudio?.src),
  locateTrack: id => musicPlaylistPersistence?.locate(id),
  reportFeedback: reportMusicFeedback,
  loadTrackAt
});

const waveformController = createWaveformController({
  ui,
  getTimeline: () => analysisTimeline,
  getPlayerTime: () => playerAudio?.currentTime || 0,
  getPlayerDuration: () => playerDuration(),
  getDuration: () => waveformDuration(),
  getExportRange: () => exportRangeModel.get(),
  clampTime: clampTrackTime
});
exportRangeModel.subscribe(() => {
  waveformController.draw();
}, { immediate: false });

audioAnalysisRuntime = createAudioAnalysisRuntime({
  getPlayerMode: () => playerMode,
  getPlayerAudio: () => playerAudio,
  getAnalysisTimeline: () => analysisTimeline,
  setAnalysisTimeline: (timeline) => { analysisTimeline = timeline; },
  getAnalysisGeneration: () => analysisGeneration,
  setAnalysisPending: (pending) => { analysisPending = pending; },
  getLookaheadState: () => lookaheadState,
  setLookaheadState: (state) => { lookaheadState = state; },
  getMusicAwareState: () => musicAwareState,
  setMusicAwareState: (state) => { musicAwareState = state; },
  getAudioFeatures: () => audioFeatures,
  getBands: () => bands,
  getLiveTempoTracker: () => liveTempoTracker,
  getLiveStructureTracker: () => liveStructureTracker,
  getMonitoringInput: () => monitoringInput,
  getScionVisualBpm: () => (scionLive ? SCION_VISUAL_BPM : 0),
  waveformController,
  updateWaveformProgress,
  ensureAudioContext,
  setDiagnostic: (message) => { ui.audioDiagnostic.textContent = message; }
});

renderSurface = createRenderSurfaceController({
  canvas,
  getGl: ensureWebGl,
  getQuality: () => quality,
  getActivePreset: () => activePreset,
  getExportResolutionOverride: () => exportResolutionOverride,
  isOfflineExport: () => renderMode === RenderMode.OFFLINE_EXPORT,
  isVisualsReady: () => visualsReady,
  drawWaveform
});

window.__cyanescentVisualOutputLiveResize = (active) => {
  if (!visualOutputRole) return;
  renderSurface.setLiveResizeSuspended(Boolean(active));
  if (!active) resize();
};

visualOutputController = createVisualOutputController({
  nativeApp: nativeAppBridge,
  outputRole: visualOutputRole,
  createStateSnapshot: createVisualStateSnapshot,
  applyStateSnapshot: applyVisualStateSnapshot,
  onWarmupProgress: ({ progress, status }) => setLocalSplashProgress(progress, status),
  onOutputReady: () => {
    if (visualOutputRole) return;
    visualOutputController.sendToOutput({
      action: "preset-calibration-export", exporting: renderMode === RenderMode.OFFLINE_EXPORT
    });
    for (const calibration of tunedPresetCalibrations()) {
      visualOutputController.sendToOutput({ action: "preset-calibration", calibration });
    }
    traceWorldshellBenchmark("output_ready");
    setAppReady(true);
    processPendingInitialBootActions();
    startWorldshellBenchmark().catch((error) => {
      console.error("Worldshell benchmark setup failed:", error);
    });
  },
  onTransitionState: applyOutputTransitionState,
  onSignalReceived: (detail) => {
    if (detail?.action === "preset-calibration-export") {
      setPresetCalibrationState({ exporting: Boolean(detail.exporting) });
      return;
    }
    if (detail?.action === "preset-calibration") {
      applyPresetCalibration(detail.calibration);
      return;
    }
    if (detail?.action === "next-preset") {
      triggerManualNextPreset();
      return;
    }
    if (detail?.action === "playlist-end") {
      beginPlaylistEndTransition(detail.presetId);
      return;
    }
    if (detail?.action !== "worldshell-benchmark-result") return;
    const line = worldshellBenchmarkLogLine(detail.result || {});
    nativeAppBridge()?.postMessage({ command: "appendPerfLog", line });
    ui.audioStatus.textContent = "Worldshell benchmark complete";
    ui.audioDiagnostic.textContent = `${detail.result?.averageFps || "?"} FPS · ${detail.result?.renderSize || "unknown render size"}`;
    console.warn(line);
  },
  onStartRequested: () => {
    if (visualOutputRole) activateVisuals(0);
  },
  onBenchmarkStart: () => {
    if (!visualOutputRole || !worldshellBenchmarkConfigValue.enabled) return;
    document.body.classList.add("worldshell-benchmark-output");
    worldshellBenchmark.start(benchmarkContext());
    traceWorldshellBenchmark("output_sampler_started", benchmarkContext());
    activateVisuals(0);
  },
  onStateChanged: ({ open, fullscreen }) => {
    if (!ui.fullscreen) return;
    ui.fullscreen.textContent = fullscreen ? "Exit Visualiser Fullscreen" : "Visualiser Fullscreen";
    ui.fullscreen.title = open
      ? "Toggle fullscreen on the display containing the visualiser window"
      : "Open the visualiser window in fullscreen";
  }
});

onPresetCalibrationChanged((calibration) => {
  const message = { action: "preset-calibration", calibration };
  if (visualOutputRole) visualOutputController.sendToMain(message);
  else visualOutputController.sendToOutput(message);
});

const visualFrameRenderer = createVisualFrameRenderer({
  getAnalysisTimeline: () => (presetDemoPreview || (presetTrialRuntime && !presetTrialTrackActive) || visualOutputRole) ? null : analysisTimeline,
  getGl: ensureWebGl,
  getCanvas: () => canvas,
  program,
  programFrom,
  setAttribs,
  renderSurface,
  resize,
  clearFeedbackBuffers,
  renderProgramForPreset,
  textureAssets,
  getTransition: () => visualTransitions.getTransition(),
  getActivePreset: () => activePreset,
  getActivePresetStartedAt: () => activePresetStartedAt,
  getSensitivity: () => VISUAL_AUDIO_SENSITIVITY,
  getQuality: () => quality,
  getSmooth: () => smooth,
  getSlowLevel: () => slowLevel,
  getSlowBass: () => slowBass,
  getScionBiofeedback: () => scionBiofeedback,
  getWavePhaseAccum: visualRuntimeState.getWavePhaseAccum,
  getVideoBackgroundState: () => offlineVideoBackgroundState || videoBackgroundManager.playlistState(),
  getMusicAwareState: () => {
    if (visualOutputRole && remoteStateReceived) {
      const elapsedMs = Math.min(100, performance.now() - smoothedRemoteAbsoluteBeatReceivedAt);
      const beatDelta = smoothedRemoteAbsoluteBeatRate * elapsedMs;
      const beatPhase = (Number(musicAwareState.beatPhase) || 0) + beatDelta;
      const barPhase = (Number(musicAwareState.barPhase) || 0) + (beatDelta / 4.0);
      const phraseProgress = (Number(musicAwareState.phraseProgress) || 0) + (beatDelta / 32.0);
      return {
        ...musicAwareState,
        absoluteBeat: smoothedRemoteAbsoluteBeatBase + beatDelta,
        beatPhase: beatPhase % 1.0,
        barPhase: barPhase % 1.0,
        phraseProgress: phraseProgress % 1.0
      };
    }
    return musicAwareState;
  },
  getLookaheadState: () => lookaheadState,
  getAudioFeatures: () => audioFeatures,
  getForgeTempo: () => {
    if (presetTrialActive && Number(musicAwareState.bpm) > 0) {
      return { bpm: Number(musicAwareState.bpm), confidence: 1 };
    }
    if (visualOutputRole && remoteStateReceived) {
      return { bpm: Number(musicAwareState.bpm) || 0,
        confidence: Number(musicAwareState.bpmConfidence) || 0 };
    }
    if (analysisTimeline?.tempo) return analysisTimeline.tempo;
    if (liveTempoTracker.locked) return liveTempoTracker;
    return null;
  },
  getOfflineClock: () => offlineRenderClock,
  getForgeShouldPlay: () => {
    if (renderMode === RenderMode.OFFLINE_EXPORT) return true;
    if (presetTrialActive) return true;
    if (visualOutputRole && remoteStateReceived) {
      return remotePlaying || !Number.isFinite(remoteTrackTime);
    }
    return !(playerMode && playerAudio?.src && playerAudio.paused);
  },
  getKnotOrbitPhase: visualRuntimeState.getKnotOrbitPhase,
  getFeedbackStep: visualRuntimeState.getFeedbackStep,
  getTimeData: visualAudioTimeData,
  // The analyser's byte spectrum for presets that map frequency to structure (Artificial Consciousness);
  // null when there is no real analyser (fixtures, offline export, remote output), which they synthesise from the bands.
  getFrequencyData: () => {
    if (presetDemoPreview || (presetTrialRuntime && !presetTrialTrackActive)) return null;
    if (renderMode === RenderMode.OFFLINE_EXPORT || (visualOutputRole && remoteStateReceived)) return null;
    return playerRuntime?.freq || null;
  },
  getTrackTime: () => {
    if (renderMode === RenderMode.OFFLINE_EXPORT && offlineRenderClock) {
      return Number(offlineRenderClock.sourceTimeSeconds ?? offlineRenderClock.videoTimeSeconds) || 0;
    }
    if (presetDemoPreview) {
      return Math.max(0, (performance.now() - presetDemoPreview.startedAt) * 0.001);
    }
    if (presetTrialRuntime && !presetTrialTrackActive) return presetTrialRuntime.elapsed();
    if (visualOutputRole && remoteStateReceived) {
       if (!Number.isFinite(smoothedRemoteTrackTimeBase)) return Number.NaN;
       const elapsedMs = Math.min(100, performance.now() - smoothedRemoteTrackTimeReceivedAt);
       return smoothedRemoteTrackTimeBase + (smoothedRemoteTrackTimeRate * elapsedMs);
    }
    const currentTime = playerMode ? Number(playerAudio?.currentTime) : Number.NaN;
    return Number.isFinite(currentTime) ? currentTime : Number.NaN;
  },
  getTrackProgress: () => visualOutputRole && remoteStateReceived
    ? remoteTrackProgress
    : (waveformController.progress() || 0),
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  isSpecialGeometryPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  specialGeometryRenderer,
  isPresetProgramReady: (presetId, qualityValue = quality) => {
    const state = presetShaderRuntime.diagnosticState(presetId, qualityValue)?.state;
    return state === "ready" || state === "not-modular";
  },
  canCoverVideoPreparation: () => videoTransitionManager?.canCoverPresetPreparation?.() || false,
  isVideoCoveringOutput: (minimumOpacity) => (
    videoTransitionManager?.isCoveringOutput?.(minimumOpacity) || false
  ),
  diagnosticsEnabled: transitionDiagnosticsEnabled,
  setRenderProgram: (programToUse) => {
    renderProgram = programToUse;
  }
});

function reportAudioInputDiagnostic(event, details = {}) {
  nativeAppBridge?.()?.postMessage({
    command: "audioImportDiagnostic",
    text: `audio-input event=${event} details=${JSON.stringify(details)}`
  });
}

const systemAudioInput = createSystemAudioInputController({
  bridge: nativeAppBridge,
  isSelected: () => ui.deviceSelect?.value === SYSTEM_AUDIO_VALUE,
  onStatus: (status, diagnostic) => {
    externalAudioNotice = { status, diagnostic };
    ui.audioStatus.textContent = status;
    ui.audioDiagnostic.textContent = diagnostic;
  }
});

const audioInputDeviceController = createAudioInputDeviceController({
  systemAudioAvailable: systemAudioSupported,
  select: ui.deviceSelect,
  setStatus: (message) => {
    externalAudioNotice = { ...(externalAudioNotice || {}), status: message };
    ui.audioStatus.textContent = message;
  },
  setDiagnostic: (message) => {
    externalAudioNotice = { ...(externalAudioNotice || {}), diagnostic: message };
    ui.audioDiagnostic.textContent = message;
  },
  getStream: () => stream,
  setStream: (value) => { stream = value; },
  getInputSource: () => externalInputSource,
  setInputSource: (value) => { externalInputSource = value; },
  onSelectedDeviceRemoved: () => {
    nativeAppBridge?.()?.postMessage("stopNativeAudio");
    monitoringInput = false;
    playerMode = true;
  },
  reportDiagnostic: reportAudioInputDiagnostic
});

const scionModeNames = [
  "Ethereal Drone", "Rhythmic Pulses", "Crystal Chimes", "Deep Sea Swells",
  "Breathing Brass", "Singing Wind", "Ghost Strings", "Neural Sync",
  "Chaotic Feedback Ring", "The Conductor", "The Orchestral Mash-Up"
];

// Maps the old single-mode index (from before modes could be combined and
// before "Granular Time-Shatter"/"Spectral Re-Harmonizer" were removed) onto
// the current index space, so a saved preference from an older build still
// lands on a sensible mode instead of silently breaking.
const legacyScionModeMigration = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 9: 8, 10: 9, 12: 10 };

function selectedScionModes() {
  const checkboxes = ui.scionModeGrid?.querySelectorAll("input[data-scion-mode-index]");
  if (checkboxes && checkboxes.length) {
    // The grid is the source of truth once rendered: an all-unchecked grid
    // means the user deliberately silenced every mode, not "no preference".
    return Array.from(checkboxes)
      .filter((checkbox) => checkbox.checked)
      .map((checkbox) => Number(checkbox.dataset.scionModeIndex));
  }
  const raw = localStorage.getItem("cyanescentScionModes");
  if (raw != null) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        const valid = parsed
          .map((value) => Number(value))
          .filter((value) => Number.isInteger(value) && value >= 0 && value < scionModeNames.length);
        return Array.from(new Set(valid));
      }
    } catch {
      // fall through to legacy migration below
    }
  }
  const legacyRaw = localStorage.getItem("cyanescentScionMode");
  if (legacyRaw != null) {
    const migrated = legacyScionModeMigration[Number(legacyRaw)];
    return migrated != null ? [migrated] : [0];
  }
  return [0];
}

function persistScionModes(modes) {
  localStorage.setItem("cyanescentScionModes", JSON.stringify(modes));
  localStorage.removeItem("cyanescentScionMode");
}

function updateScionTransport() {
  const disabled = scionActive;
  ui.scionModeControl?.classList.toggle("hidden", ui.deviceSelect?.value !== "scion");
  [ui.prevTrack, ui.nextTrack, ui.playerShuffle, ui.repeatMode, ui.exportMusicVideo].forEach((control) => {
    if (control) control.disabled = disabled;
  });
  if (ui.playPause) ui.playPause.textContent = disabled ? (scionPaused ? "Play Scion" : "Pause Scion") : "Play";
}

function postScion(command) {
  nativeAppBridge?.()?.postMessage({ command, modes: selectedScionModes() });
}

function applyScionVolume() {
  scionVolume = Math.max(0, Math.min(1, Number(ui.playerVolume?.value) || 0));
  localStorage.setItem("cyanescentScionVolume", String(scionVolume));
  nativeAppBridge?.()?.postMessage({
    command: "setScionGain",
    gain: scionVolume
  });
}

function scheduleScionAdaptiveTransition(now = performance.now()) {
  const range = adaptiveTransitionTimingRange(optionsController?.adaptiveTransitionTime?.());
  const selectedSeconds = range.min + Math.random() * (range.max - range.min);
  const minimum = adaptivePresetMinimumPlaySeconds(activePreset);
  scionAdaptivePresetStartedAt = activePresetStartedAt;
  if (minimum > 0 && adaptivePresetExactPlaySeconds(activePreset) <= 0) {
    // Scion has no analysed track events. Retain its random timer selection,
    // with the same protected landing window and 2.6s crossfade lead.
    const shift = adaptiveTransitionProtectionShift(minimum);
    scionAdaptiveNextAt = Math.max(now + 350,
      activePresetStartedAt + (selectedSeconds + shift - 2.6) * 1000);
  } else {
    scionAdaptiveNextAt = now + selectedSeconds * 1000;
  }
}

function updateScionAdaptiveTransitions(now) {
  if (!scionActive || scionPaused || visualTransitions.getTransitionMode?.() !== VisualTransitionMode.ADAPTIVE) {
    scionAdaptiveNextAt = 0;
    return;
  }
  if (visualTransitions.getTransition()?.active) return;
  // Never cut into an Alien Visit that is already on screen.
  if (alienVisitDirector.isHoldingTransitions()) return;
  if (!scionAdaptiveNextAt || scionAdaptivePresetStartedAt !== activePresetStartedAt) {
    scheduleScionAdaptiveTransition(now);
    return;
  }
  if (now < scionAdaptiveNextAt) return;
  if (visualTransitions.begin(visualTransitions.chooseNextPreset(), "adaptive", { style: Math.floor(Math.random() * 4) })) {
    scionAdaptiveNextAt = 0;
  } else {
    scheduleScionAdaptiveTransition(now);
  }
}

async function selectScionAudioSource({ resume = true } = {}) {
  activateVisuals(0);
  stopInputStream();
  if (playerAudio && !playerAudio.paused) playerAudio.pause();
  playerMode = false;
  monitoringInput = true;
  analysisGeneration += 1;
  analysisPending = false;
  analysisTimeline = null;
  resetLookaheadState();
  window.__scionAudio = window.__nativeAudio = { source: "scion", active: false, status: resume ? "Connecting to Pocket Scion" : "Scion paused", timestamp: Date.now() / 1000 };
  scionActive = true;
  scionPaused = !resume;
  if (ui.playerVolume) ui.playerVolume.value = String(scionVolume);
  applyScionVolume();
  scionAdaptiveNextAt = 0;
  updateScionTransport();
  if (resume) postScion("startScionAudio");
  else postScion("stopScionAudio");
  if (resume) visualOutputController?.openAutomatically();
  ui.audioStatus.textContent = resume ? "Scion starting" : "Scion paused";
  ui.audioDiagnostic.textContent = resume ? "Waiting for device connection and MIDI data" : "Pocket SCÍON synthesis paused";
}

function leaveScionAudioSource() {
  if (!scionActive) return;
  postScion("stopScionAudio");
  scionActive = false;
  scionPaused = false;
  scionAdaptiveNextAt = 0;
  updateScionTransport();
}

function setScionModes() {
  persistScionModes(selectedScionModes());
  postScion("setScionMode");
}

const optionsController = createOptionsController({
  ui,
  defaultTransitionMode: VisualTransitionMode.ADAPTIVE,
  ignorePersisted: uiPreviewActive,
  playlistStore: playerQueueController.store,
  onDebugModeApplied: (enabled) => {
    waveformController.resetZoomIfHidden(enabled);
    document.body.classList.toggle("debug-off", !enabled);
    setPresetCalibrationState({ debugEnabled: enabled });
    drawWaveform();
  },
  onInputMeterChanged: updateMeters,
  onAlienVisitsChanged: (active) => alienVisitDirector.setEnabled(active),
  refreshDevices: () => audioInputDeviceController.refreshDevicesOnDemand(),
  onAudioSourceSelected: (value) => {
    if (value !== SYSTEM_AUDIO_VALUE) systemAudioInput.stop();
    if (value === ENABLE_EXTERNAL_AUDIO_VALUE) {
      selectExternalAudioIntent().catch((error) => {
        handleExternalCaptureFailure(error, "intent-resolution-error");
      });
      return;
    }
    if (value === CHOOSE_EXTERNAL_AUDIO_VALUE) {
      return;
    }
    externalAudioNotice = null;
    if (value === "scion-mode") {
      setScionModes();
      return;
    }
    if (value === "scion") {
      audioInputDeviceController.rememberSelection(value);
      selectScionAudioSource().catch(console.error);
      return;
    }
    leaveScionAudioSource();
    if (value === "player") {
      audioInputDeviceController.rememberSelection(value);
      selectPlayerAudioSource().catch(console.error);
    } else {
      startSelectedExternalAudio().catch(console.error);
    }
  },
  onPresetSelected: (value) => {
    visualTransitions.begin(value);
    visualTransitions.markAdaptivePresetStarted?.(playerAudio?.currentTime || 0);
  },
  onTransitionModeChanged: (value) => {
    visualTransitions.setTransitionMode(value);
  },
  onShuffleSecondsChanged: () => {
    visualTransitions.resetShuffleTimer();
  },
  onAdaptiveTransitionTimeChanged: (value) => {
    visualTransitions.setAdaptiveTimingPreset?.(value);
    if (scionActive) scheduleScionAdaptiveTransition();
  },
  onStandardQuality: () => {
    quality = 0;
    ui.standardMode.classList.add("active");
    ui.highMode.classList.remove("active");
    resize();
  },
  onHighQuality: () => {
    quality = 1;
    ui.highMode.classList.add("active");
    ui.standardMode.classList.remove("active");
    resize();
  }
});

videoTransitionManager = createVideoTransitionManager({
  video: ui.transitionVideo,
  assetManager: videoAssetManager,
  classifyEnergy: classifyVideoTransitionEnergy,
  getOptions: () => optionsController.options
});

const offlineVideoTransitionCompositor = createOfflineVideoTransitionCompositor({
  assetManager: videoAssetManager,
  classifyEnergy: classifyVideoTransitionEnergy,
  getOptions: currentVideoTransitionOptions
});

function initializeDefaultFolderOptions() {
  // Playlists restore through native playlist persistence; never load the legacy folder.
  if (musicPlaylistPersistence) {
    void musicPlaylistPersistence.ready.then(() => optionsController.refreshDefaultPlaylists());
  } else optionsController.refreshDefaultPlaylists();
}

optionsController.applyOptionsToUi();
if (ui.scionModeGrid) {
  const selected = new Set(selectedScionModes());
  ui.scionModeGrid.innerHTML = scionModeNames.map((name, index) => `
    <label class="scion-mode-option">
      <input type="checkbox" data-scion-mode-index="${index}"${selected.has(index) ? " checked" : ""}>
      <span>${name}</span>
    </label>
  `).join("");
  ui.scionModeGrid.querySelectorAll("input[data-scion-mode-index]").forEach((checkbox) => {
    checkbox.addEventListener("change", () => setScionModes());
  });
}

function debugModeEnabled() {
  return optionsController.debugModeEnabled();
}

window.__nativeAudio = {
  level: 0,
  kick: 0,
  bass: 0,
  mids: 0,
  highs: 0,
  brightness: 0,
  active: false,
  status: "native waiting",
  timestamp: 0
};

function resize() {
  const before = renderSurface.renderSize();
  renderSurface.resize();
  const after = renderSurface.renderSize();
  if (before.width === after.width && before.height === after.height) return;
  if (renderMode !== RenderMode.LIVE) return;
  window.clearTimeout(resize.transitionWarmTimer || 0);
  const warmWhenIdle = () => {
    if (renderMode !== RenderMode.LIVE || visualTransitions?.getTransition?.()?.active) {
      resize.transitionWarmTimer = window.setTimeout(warmWhenIdle, 700);
      return;
    }
    visualFrameRenderer?.prepareTransitionInfrastructure?.();
  };
  resize.transitionWarmTimer = window.setTimeout(warmWhenIdle, 700);
}

function ensureAudioContext() {
  return playerRuntime.ensureAudioContext();
}

function makeAnalyser() {
  return playerRuntime.makeAnalyser();
}

function applyPlayerVolume() {
  if (scionActive) {
    applyScionVolume();
    return;
  }
  playerRuntime.applyPlayerVolume();
}

async function playPlayerAudioWithFade(options = {}) {
  return playerRuntime.playPlayerAudioWithFade(options);
}

function playerDuration() {
  return playerRuntime.playerDuration();
}

function waveformDuration() {
  return playerRuntime.waveformDuration();
}

function drawWaveform() {
  waveformController.draw();
  redrawExportStudio();
}

// The Export Studio draws its own waveform canvases from the same analysis;
// only redraw them while the studio is open.
function redrawExportStudio() {
  if (ui.exportOverlay?.classList.contains("hidden")) return;
  exportStudio?.redrawCanvases?.();
}

function formatExportRangeClock(seconds) {
  const safe = Math.max(0, Number(seconds) || 0);
  const minutes = Math.floor(safe / 60).toString().padStart(2, "0");
  const whole = Math.floor(safe % 60).toString().padStart(2, "0");
  const milliseconds = Math.floor((safe % 1) * 1000).toString().padStart(3, "0");
  return `${minutes}:${whole}.${milliseconds}`;
}

function addWaveformTransitionMarker(marker) {
  waveformController.addTransitionMarker(marker);
}

function updateWaveformProgress(force = false) {
  waveformController.updateProgress(force);
  redrawExportStudio();
}

function updateAudio() {
  if (presetTrialRuntime && !presetTrialTrackActive) {
    const fixture = presetTrialRuntime.sample();
    lookaheadState = fixture.lookahead || createEmptyLookaheadState();
    bands = createAudioBands({
      kick: fixture.kick, bass: fixture.bass, mids: fixture.mids, highs: fixture.highs,
      brightness: fixture.mids * 0.45 + fixture.highs * 0.55, level: fixture.level
    });
    meterBands = { ...bands };
    updateAudioFeatureState({ state: audioFeatures, bands, now: performance.now() });
    smooth = smoothAudioBands({ smooth, bands, noAnalyser: false });
    ({ slowLevel, slowBass } = updateSlowAudioBands({ slowLevel, slowBass, bands }));
    const absoluteBeat = presetTrialRuntime.elapsed() * fixture.bpm / 60;
    musicAwareState = {
      ...musicAwareState, bpm: fixture.bpm, beatPhase: fixture.beatPhase, absoluteBeat,
      barPhase: (absoluteBeat / 4) % 1, phraseProgress: (absoluteBeat / 32) % 1,
      futureEnergy: fixture.futureEnergy ?? fixture.level,
      futureBrightness: fixture.futureBrightness ?? fixture.highs,
      futureDensity: fixture.futureDensity ?? fixture.intensity,
      energyTrend: fixture.energyTrend ?? fixture.intensity,
      upcomingDrop: fixture.upcomingDrop || 0, upcomingBuild: fixture.upcomingBuild || 0,
      upcomingBreakdown: fixture.upcomingBreakdown || 0,
      nextPhraseSeconds: fixture.nextPhraseSeconds ?? (8 - absoluteBeat % 8) * 60 / fixture.bpm,
      mainRiff: fixture.mainRiff || 0, highEnergy: fixture.intensity, adaptiveIntensity: fixture.intensity,
      sectionChange: fixture.sectionChange ?? (fixture.drop || fixture.build || 0), drop: fixture.drop || 0, buildUp: fixture.build || 0,
      breakdown: fixture.breakdown || 0, calm: fixture.calm || 0
    };
    for (let index = 0; index < presetDemoTimeData.length; index += 1) {
      const sampleTime = presetTrialRuntime.elapsed() + index / 44100;
      const sample = Math.sin(sampleTime * Math.PI * 2 * 58) * bands.bass * 0.58 + Math.sin(sampleTime * Math.PI * 2 * 330) * bands.mids * 0.22 + Math.sin(sampleTime * Math.PI * 2 * 93) * bands.kick * 0.32;
      presetDemoTimeData[index] = Math.round(128 + Math.max(-1, Math.min(1, sample)) * 127);
    }
    return;
  }
  if (presetDemoPreview) {
    const elapsed = Math.max(0, (performance.now() - presetDemoPreview.startedAt) * 0.001);
    const beat = elapsed * 2.0;
    const beatPhase = beat - Math.floor(beat);
    const kick = Math.exp(-beatPhase * 11.0);
    const barPhase = (beat / 8) - Math.floor(beat / 8);
    const bass = Math.min(1, 0.38 + kick * 0.42 + Math.sin(elapsed * Math.PI) * 0.08);
    const mids = Math.min(1, 0.34 + 0.18 * (0.5 + 0.5 * Math.sin(elapsed * 3.1 + 0.8)));
    const highs = Math.min(1, 0.24 + kick * 0.18 + 0.16 * (0.5 + 0.5 * Math.sin(elapsed * 7.7)));
    bands = createAudioBands({
      kick,
      bass,
      mids,
      highs,
      brightness: mids * 0.48 + highs * 0.52,
      level: Math.min(1, 0.42 + kick * 0.26 + bass * 0.24)
    });
    meterBands = { ...bands };
    smooth = smoothAudioBands({ smooth, bands, noAnalyser: false });
    ({ slowLevel, slowBass } = updateSlowAudioBands({ slowLevel, slowBass, bands }));
    Object.assign(audioFeatures, {
      bassRel: 0.9 + bass * 1.15,
      midRel: 0.85 + mids * 1.05,
      trebleRel: 0.82 + highs * 1.15,
      kickPulse: kick,
      globalEnergy: bands.level,
      dropDetected: barPhase < 0.08 ? kick : 0
    });
    musicAwareState = {
      ...musicAwareState,
      futureEnergy: 0.62,
      futureBrightness: 0.55,
      futureDensity: 0.58,
      sectionChange: barPhase < 0.08 ? 0.7 : 0,
      energyTrend: 0.56,
      mainRiff: 0.64,
      drop: barPhase < 0.08 ? kick : 0,
      buildUp: Math.max(0, (barPhase - 0.55) * 2.0),
      calm: 0.08,
      highEnergy: 0.66,
      adaptiveIntensity: 0.7,
      phrasePulse: Math.exp(-((beat / 4) % 1) * 7),
      phraseProgress: (beat / 8) % 1,
      beatPhase,
      absoluteBeat: beat
    };
    for (let index = 0; index < presetDemoTimeData.length; index += 1) {
      const sampleTime = elapsed + index / 44100;
      const sample = Math.sin(sampleTime * Math.PI * 2 * 82) * bass * 0.58
        + Math.sin(sampleTime * Math.PI * 2 * 330) * mids * 0.22
        + Math.sin(sampleTime * Math.PI * 2 * 57) * kick * 0.34;
      presetDemoTimeData[index] = Math.round(128 + Math.max(-1, Math.min(1, sample)) * 127);
    }
    return;
  }
  const nativeAudio = (scionActive ? window.__scionAudio : window.__nativeAudio) || {};
  const audioRuntimeState = playerRuntime.analyserState();
  const liveAudio = readLiveAudioBands({
    analyser: audioRuntimeState.analyser,
    freq: audioRuntimeState.freq,
    timeData: audioRuntimeState.timeData,
    sampleRate: audioRuntimeState.audioContext?.sampleRate,
    previousKick: smooth.kick,
    nativeAudio,
    monitoringInput,
    playerMode,
    nativeOnlySource: ui.deviceSelect?.value === SYSTEM_AUDIO_VALUE ? SYSTEM_AUDIO_VALUE : null
  });
  bands = liveAudio.bands || createAudioBands();
  meterBands = { ...bands };
  updateLookaheadState();
  blendTimelineIntoBands();
  const now = performance.now();
  const scionFresh = Boolean(nativeAudio.timestamp)
    && Date.now() / 1000 - Number(nativeAudio.timestamp) < 1.2;
  scionLive = scionActive && !scionPaused && nativeAudio.source === "scion"
    && nativeAudio.active === true && scionFresh;
  // Ahead of updateAudioFeatureState so this frame's activity/beatStrength
  // are ready in time to shape it, rather than lagging a frame behind.
  updateScionBiofeedback(scionBiofeedback, { live: scionLive, bands: nativeAudio, now });
  updateAudioFeatureState({ state: audioFeatures, bands, now, scion: scionLive ? scionBiofeedback : null });
  updateLiveTempo();
  updateMusicAwareState();
  if (scionLive) {
    // The synthetic clock (see liveTempoTracker's syntheticBpm, engaged via
    // updateLiveTempo -> getScionVisualBpm above) already advanced
    // musicAwareState.beatPhase/absoluteBeat exactly as a real lock would.
    // This is the one place that turns "a new beat/accent happened" into an
    // actual kickPulse, so every preset's existing beat-reactive motion
    // picks it up with no preset-specific changes.
    if (scionAccentIsNew(scionBiofeedback, scionBiofeedback.lastAccentAppliedAt)) {
      console.debug(`[Scion] accent (strength ${scionBiofeedback.accentStrength.toFixed(2)}, activity ${scionBiofeedback.activity.toFixed(2)})`);
    }
    applyScionBeatPulse({ audioFeatures, state: scionBiofeedback, absoluteBeat: musicAwareState.absoluteBeat });
  }
  smooth = smoothAudioBands({ smooth, bands, noAnalyser: liveAudio.noAnalyser });
  ({ slowLevel, slowBass } = updateSlowAudioBands({ slowLevel, slowBass, bands }));
  updateMeters();
}

function createVisualStateSnapshot() {
  if (visualOutputRole || !visualTransitions) return null;
  updateAudio();
  const now = performance.now();
  updateScionAdaptiveTransitions(now);
  visualTransitions.updateVisual(now);
  const transition = visualTransitions.getTransition() || createInactivePresetTransition(activePreset);
  const transitionId = visualTransitionIdentity(transition);
  const timeData = playerRuntime?.timeData;
  const trackTime = playerMode ? Number(playerAudio?.currentTime) : Number.NaN;
  return {
    version: 1,
    bands: { ...bands },
    smooth: { ...smooth },
    slowLevel,
    slowBass,
    scionBiofeedback: scionBiofeedbackSnapshot(scionBiofeedback),
    audioFeatures: { ...audioFeatures },
    musicAwareState: {
      ...musicAwareState,
      bpm: analysisTimeline?.tempo?.bpm || (liveTempoTracker.locked ? liveTempoTracker.bpm : 0),
      bpmConfidence: analysisTimeline?.tempo?.confidence || (liveTempoTracker.locked ? liveTempoTracker.confidence : 0)
    },
    lookaheadState: { ...lookaheadState },
    activePreset,
    activePresetAgeMs: Math.max(0, now - activePresetStartedAt),
    transition: { ...transition },
    transitionId,
    transitionElapsedMs: transition.active ? Math.max(0, now - Number(transition.start || now)) : 0,
    transitionMode: visualTransitions.getTransitionMode(),
    videoTransitionOptions: snapshotVideoTransitionOptions(optionsController.options),
    quality,
    debugEnabled: debugModeEnabled(),
    // The detached output uses this producer clock to interpolate beat state.
    // It must not infer tempo from when a cross-window message happens to arrive.
    sourceTimeMs: now,
    playing: playerIsActivelyPlaying(),
    trackTime: Number.isFinite(trackTime) ? trackTime : null,
    trackProgress: waveformController.progress() || 0,
    timeData: timeData ? Array.from(timeData) : []
  };
}

function visualTransitionIdentity(transition) {
  if (!transition?.active) return "";
  return [
    Number(transition.from),
    Number(transition.to),
    Math.round(Number(transition.start) || 0),
    Math.round((Number(transition.seed) || 0) * 100000)
  ].join(":");
}

function applyOutputTransitionState(detail = {}) {
  if (visualOutputRole || !visualTransitions) return;
  const preset = visualTransitions.normalizePresetId(detail.activePreset);
  if (Number.isFinite(Number(preset)) && Number(preset) !== Number(activePreset)) {
    activePreset = preset;
    activePresetStartedAt = performance.now();
    if (ui.presetSelect) ui.presetSelect.value = String(activePreset);
    visualTransitions.notePresetActivated?.(activePreset);
  }
  if (detail.complete) {
    const current = visualTransitions.getTransition();
    if (!detail.transitionId || detail.transitionId === visualTransitionIdentity(current)) {
      visualTransitions.setTransition(createInactivePresetTransition(activePreset));
      visualTransitions.markAdaptivePresetStarted?.(playerAudio?.currentTime || 0);
      visualTransitions.resetShuffleTimer?.();
    }
  }
}

function applyVisualStateSnapshot(state) {
  if (!visualOutputRole || !state || !visualTransitions) return;
  const debugEnabled = state.debugEnabled !== false;
  if (ui.debugMode) ui.debugMode.checked = debugEnabled;
  document.body.classList.toggle("debug-off", !debugEnabled);
  setPresetCalibrationState({ debugEnabled });
  const now = performance.now();
  bands = createAudioBands(state.bands);
  meterBands = { ...bands };
  smooth = createAudioBands(state.smooth);
  slowLevel = Number(state.slowLevel) || 0;
  slowBass = Number(state.slowBass) || 0;
  applyScionBiofeedbackSnapshot(scionBiofeedback, state.scionBiofeedback || {});
  Object.assign(audioFeatures, state.audioFeatures || {});
  musicAwareState = { ...createMusicAwareState(), ...(state.musicAwareState || {}) };
  lookaheadState = { ...createEmptyLookaheadState(), ...(state.lookaheadState || {}) };
  // Smoothing for remoteTrackTime
  const newTrackTime = state.trackTime === null ? Number.NaN : Number(state.trackTime);
  if (Number.isFinite(newTrackTime)) {
    remoteTrackTimeHistory.push({ time: now, val: newTrackTime });
    while (remoteTrackTimeHistory.length > 1 && now - remoteTrackTimeHistory[0].time > 1000) {
      remoteTrackTimeHistory.shift();
    }
    const first = remoteTrackTimeHistory[0];
    const last = remoteTrackTimeHistory[remoteTrackTimeHistory.length - 1];
    if (last.time - first.time > 100) {
       smoothedRemoteTrackTimeRate = (last.val - first.val) / (last.time - first.time);
    } else {
       smoothedRemoteTrackTimeRate = 0;
    }
    // Seek detection
    if (remoteTrackTimeHistory.length > 1 && Math.abs(newTrackTime - remoteTrackTimeHistory[remoteTrackTimeHistory.length - 2].val) > 1.0) {
       remoteTrackTimeHistory.length = 0;
       smoothedRemoteTrackTimeRate = 0;
    }
  } else {
    smoothedRemoteTrackTimeRate = 0;
    remoteTrackTimeHistory.length = 0;
  }
  smoothedRemoteTrackTimeBase = newTrackTime;
  smoothedRemoteTrackTimeReceivedAt = now;
  remoteTrackTime = newTrackTime;

  // Smooth beats against the producer's clock rather than local message arrival.
  // A resized or fullscreen output window can receive queued IPC messages in a
  // burst; using those arrival intervals falsely turns one musical beat into a
  // much faster rotation for presets such as Tesseract Unfolding.
  const newAbsoluteBeat = Number(state.musicAwareState?.absoluteBeat) || 0;
  const sourceTimeMs = Number(state.sourceTimeMs);
  const previousBeatSample = previousRemoteAbsoluteBeatSample;
  if (Number.isFinite(sourceTimeMs)) {
    const sourceElapsedMs = sourceTimeMs - Number(previousBeatSample?.sourceTimeMs);
    const beatElapsed = newAbsoluteBeat - Number(previousBeatSample?.absoluteBeat);
    smoothedRemoteAbsoluteBeatRate = previousBeatSample
      && sourceElapsedMs > 0
      && beatElapsed >= 0
      ? beatElapsed / sourceElapsedMs
      : 0;
    previousRemoteAbsoluteBeatSample = {
      sourceTimeMs,
      absoluteBeat: newAbsoluteBeat
    };
  } else {
    smoothedRemoteAbsoluteBeatRate = 0;
    previousRemoteAbsoluteBeatSample = null;
  }
  smoothedRemoteAbsoluteBeatBase = newAbsoluteBeat;
  smoothedRemoteAbsoluteBeatReceivedAt = now;
  remoteTrackProgress = clamp01(Number(state.trackProgress) || 0);
  if (Array.isArray(state.timeData) && state.timeData.length) {
    remoteTimeData = Uint8Array.from(state.timeData);
  }
  remoteStateReceived = true;
  remotePlaying = Boolean(state.playing);

  const nextQuality = Number(state.quality) > 0.5 ? 1 : 0;
  if (nextQuality !== quality) {
    quality = nextQuality;
    ui.highMode?.classList.toggle("active", quality > 0.5);
    ui.standardMode?.classList.toggle("active", quality <= 0.5);
    resize();
  }
  // The output has its own options object; localStorage writes do not update it.
  // Apply runtime settings before accepting a new transition, without persisting
  // remote state or changing the resources of an already active transition.
  if (state.videoTransitionOptions) {
    Object.assign(optionsController.options, snapshotVideoTransitionOptions(state.videoTransitionOptions));
  }
  const transitionMode = state.transitionMode || VisualTransitionMode.STATIC;
  if (visualTransitions.getTransitionMode() !== transitionMode) {
    visualTransitions.setTransitionMode(transitionMode);
  }
  const transition = { ...(state.transition || createInactivePresetTransition(activePreset)) };
  transition.from = visualTransitions.normalizePresetId(transition.from);
  transition.to = visualTransitions.normalizePresetId(transition.to);
  const incomingTransitionId = String(state.transitionId || visualTransitionIdentity(transition));
  const localTransition = visualTransitions.getTransition();
  const renderedCancellation = !transition.active && transition.cancelled
    && localTransition?.active && transition.diagnosticId === localTransition.diagnosticId;
  if (renderedCancellation || (transition.active
      && incomingTransitionId
      && incomingTransitionId !== remoteTransitionId
      && incomingTransitionId !== completedRemoteTransitionId)) {
    remoteTransitionId = renderedCancellation ? "" : incomingTransitionId;
    // The output owns the animation already on screen. The producer may have
    // discarded its completed transition and retained only the later swap
    // timestamp; rebasing that as a new outgoing epoch would rewind this world.
    const retainedOutgoingStartedAt = !transition.suppressShaderTransition
      && Number(activePreset) === Number(transition.from)
      ? presetAnimationStartedAt(activePreset, localTransition, activePreset, activePresetStartedAt)
      : null;
    const retainedOutgoingActivatedAt = activePresetStartedAt;
    if (transitionDiagnosticsEnabled()) console.info("[TransitionInitiation]", JSON.stringify({
      event: "accept", id: transition.diagnosticId, source: transition.source, now,
      from: transition.from, to: transition.to, retainedOutgoingStartedAt,
      producerOutgoingStartedAt: Number.isFinite(transition.fromPresetStartedAt) && Number.isFinite(sourceTimeMs)
        ? now + transition.fromPresetStartedAt - sourceTimeMs : null
    }));
    activePreset = visualTransitions.normalizePresetId(renderedCancellation ? state.activePreset :
      transition.swapped && !transition.suppressShaderTransition ? transition.to : transition.from);
    activePresetStartedAt = retainedOutgoingStartedAt !== null && Number(activePreset) === Number(transition.from)
      ? retainedOutgoingActivatedAt : now - Math.max(0, Number(state.activePresetAgeMs) || 0);
    if (ui.presetSelect) ui.presetSelect.value = String(activePreset);
    syncVideoBackgroundForPreset(activePreset);
    visualTransitions.setTransition({
      ...transition,
      start: now - Math.max(0, Number(state.transitionElapsedMs) || 0),
      ...Object.fromEntries(["fromPresetStartedAt", "toPresetStartedAt", "fromActivatedAt", "toActivatedAt"]
        .filter(key => Number.isFinite(transition[key]) && Number.isFinite(sourceTimeMs))
        .map(key => [key, key === (transition.swapped ? "toActivatedAt" : "fromActivatedAt")
          ? activePresetStartedAt : now + transition[key] - sourceTimeMs])),
      ...(retainedOutgoingStartedAt !== null ? {
        fromPresetStartedAt: retainedOutgoingStartedAt,
        fromActivatedAt: retainedOutgoingActivatedAt
      } : {})
    });
  } else if (!transition.active && !visualTransitions.getTransition()?.active) {
    remoteTransitionId = "";
    completedRemoteTransitionId = "";
    const nextPreset = visualTransitions.normalizePresetId(state.activePreset);
    if (Number(nextPreset) !== Number(activePreset)) {
      activePreset = nextPreset;
      activePresetStartedAt = now - Math.max(0, Number(state.activePresetAgeMs) || 0);
      if (ui.presetSelect) ui.presetSelect.value = String(activePreset);
      syncVideoBackgroundForPreset(activePreset);
    }
  }
}

function updateMeters() {
  updateAudioStatusPanel({
    ui,
    updateWaveformProgress,
    updateTrackTimeDisplay,
    visualFallbackActive,
    visualErrorText,
    meterBands,
    playerMode,
    playerAudio,
    analysisPending,
    analysisTimeline,
    lookaheadState,
    musicAwareState,
    monitoringInput,
    liveTempoTracker,
    liveStructureTracker,
    webStreamActive: Boolean(stream),
    nativeAudio: (scionActive ? window.__scionAudio : window.__nativeAudio) || {},
    inputNotice: externalAudioNotice,
    liveAdaptive: visualTransitions?.getLiveAdaptiveStatus?.(),
    scionLive,
    scionBiofeedback,
    globalEnergy: audioFeatures.globalEnergy
  });
}

function syncVideoBackgroundForPreset(preset) {
  if (videoBackgroundManager.hasPreset(preset)) {
    videoBackgroundManager.syncToPreset(preset).catch((error) => {
      console.warn("Video background failed to start:", error);
      videoBackgroundManager.stop();
    });
  } else if (!visualTransitions?.getTransition()?.active) {
    // Same swap-point hazard as the clam overlay below, but on the way out.
    // stop() is not a fade: it pulls src off both background elements and
    // calls load(), so the footage is gone on the very next frame while only
    // the empty container behind it eases out over 900ms. For a video-backed
    // preset that footage IS the visual (it is full-bleed CSS behind the
    // canvas, z-index 0 vs 1), so tearing it down at the swap point blanks
    // the outgoing half of an in-progress crossfade in a single frame.
    //
    // Deferring costs nothing: the incoming preset's own output grows opaque
    // over the crossfade and has covered the background by the time it ends,
    // and onActivePresetChanged fires again on completion (with active
    // already false) to run the teardown then.
    videoBackgroundManager.stop();
  }
  if (Number(preset) === PHASE_SPACE_REEF_PRESET_ID) {
    // This function is called from onActivePresetChanged, which fires
    // *during* a preset transition (at the crossfade's swap point) as well
    // as again once it fully completes. The clam overlay sits above the
    // canvas (z-index 2 vs 1), so starting its fade-in mid-crossfade means
    // it visually swallows the second half of the transition. Only start it
    // once nothing is transitioning; onActivePresetChanged's second,
    // post-transition call (still targeting this same preset) picks it up.
    // Leaving Phase Space Reef isn't gated the same way — the overlay's own
    // fade-out uncovering whatever's beneath is far less visually
    // disruptive than a fade-in stacking on top of an in-progress crossfade.
    if (!visualTransitions?.getTransition()?.active) {
      phaseSpaceReefClamOverlay.start();
    }
  } else {
    phaseSpaceReefClamOverlay.stop();
  }
}

function classifyVideoTransitionEnergy(transition) {
  const fromMeta = presetMetadataById.get(Number(transition?.from));
  const toMeta = presetMetadataById.get(Number(transition?.to));
  if (!fromMeta || !toMeta) return "high-high";
  const rank = { low: 1, medium: 2, high: 3 };
  const fromLevel = fromMeta.energyLevel || "medium";
  const toLevel = toMeta.energyLevel || "medium";
  if (fromLevel === "low" && toLevel === "low") return "low-low";
  if (fromLevel === "high" && toLevel === "high") return "high-high";
  const diff = (rank[toLevel] || 2) - (rank[fromLevel] || 2);
  if (diff > 0) return "rising";
  if (diff < 0) return "falling";
  return toLevel === "high" ? "high-high" : "low-low";
}

function transitionTimingForCurrentOptions() {
  const options = optionsController.options || {};
  if (!capabilityEnabled("videoTransitions") || !options.useVideoTransitions) return { useVideoTransitions: false };
  return {
    useVideoTransitions: true,
    duration: 10000,
    swapAt: 0.5,
    suppressShaderTransition: true
  };
}

function currentVideoTransitionOptions() {
  const options = optionsController.options || {};
  return {
    ...options,
    useVideoTransitions: capabilityEnabled("videoTransitions") && Boolean(options.useVideoTransitions)
  };
}

visualTransitions = createVisualTransitionRuntime({
  presetSelection,
  shouldDeferAutoTransition: () => alienVisitDirector.isHoldingTransitions(),
  initialPreset: activePreset,
  initialMode: ui.transitionMode?.value || VisualTransitionMode.STATIC,
  initialShuffleSeconds: ui.shuffleSeconds?.value,
  getActivePreset: () => activePreset,
  setActivePreset: (value) => { activePreset = requireRuntimePreset(value); },
  getActivePresetStartedAt: () => activePresetStartedAt,
  setActivePresetStartedAt: (value) => { activePresetStartedAt = value; },
  getPlayerMode: () => playerMode,
  getPlayerAudio: () => playerAudio,
  getAnalysisTimeline: () => analysisTimeline,
  getMusicAwareState: () => musicAwareState,
  getLookaheadState: () => lookaheadState,
  getLiveInputState: () => ({
    active: monitoringInput && !playerMode && !scionActive && !visualOutputRole
      && renderMode !== RenderMode.OFFLINE_EXPORT,
    source: `${ui.deviceSelect?.value || "external"}:${analysisGeneration}`,
    bands,
    features: audioFeatures,
    music: musicAwareState,
    tempo: liveTempoTracker,
    structure: liveStructureTracker
  }),
  getAdaptiveTimingPreset: () => optionsController.adaptiveTransitionTime(),
  getAdaptivePresetExactPlaySeconds: adaptivePresetExactPlaySeconds,
  getAdaptivePresetMinimumPlaySeconds: adaptivePresetMinimumPlaySeconds,
  presetMetadata: PRESET_METADATA,
  presetMetadataById,
  onPresetCandidate: (presetId) => visualFrameRenderer.queuePresetPreflight(presetId),
  getTransitionTiming: transitionTimingForCurrentOptions,
  onActivePresetChanged: (preset) => {
    ui.presetSelect.value = String(preset);
    syncVideoBackgroundForPreset(preset);
    if (![APOLLONIAN_PHYSARUM_GENESIS_ID, DUOVERSE_HD_ID, NEWTON_BASIN_DESCENT_ID, NEWTONS_LAW_ID, ARTIFICIAL_CONSCIOUSNESS_ID, HELIX_TUNNEL_ID].includes(Number(preset)) && !visualTransitions.getTransition()?.active) {
      visualFrameRenderer.stopForgeHybrid(preset);
    }
  }
});

const presetCurator = createPresetCurator({
  // PRESET_METADATA is the same edition-filtered catalog used by the Player's
  // dropdown, shuffle, and preset playlist controller.
  getPresets: () => PRESET_METADATA.map((preset) => ({
    id: Number(preset.id),
    name: String(preset.name || `Preset ${preset.id}`),
    category: String(preset.category || "Uncategorised"),
    edition: editionConfig.id,
    removable: presetShaderRegistry.has(Number(preset.id))
  })),
  previewPreset: (presetId) => {
    const id = Number(presetId);
    visualTransitions.setPresetImmediate(id);
    // Presets are rendered in the Player's separate visual-output window.
    // Ensure it is visible so the new active preset reaches a running renderer,
    // even when the output was previously closed by the user.
    visualOutputController?.show();
  },
  removePresets: (ids) => nativeAppBridge()?.postMessage({ command: "removeCuratorPresets", ids }),
  onRemoved: (ids) => {
    const removed = new Set(ids.map(Number));
    const previousActive = Number(activePreset);
    for (const id of removed) {
      presetShaderRegistry.modules.delete(id);
      presetMetadataById.delete(id);
      const metadataIndex = PRESET_METADATA.findIndex((preset) => Number(preset.id) === id);
      if (metadataIndex >= 0) PRESET_METADATA.splice(metadataIndex, 1);
      const optionIndex = builtInPresetOptions.findIndex((preset) => Number(preset.id) === id);
      if (optionIndex >= 0) builtInPresetOptions.splice(optionIndex, 1);
      const idIndex = builtInPresetIds.indexOf(id);
      if (idIndex >= 0) builtInPresetIds.splice(idIndex, 1);
    }
    // Keep unavailable edition/content references in stored playlists; filter only for playback.
    const fallback = builtInPresetOptions[0]?.id || 0;
    refreshPresetSelectionUi(currentPresetPlaylistId, removed.has(previousActive) ? fallback : previousActive);
    if (removed.has(previousActive) && fallback) visualTransitions.setPresetImmediate(fallback);
  }
});
window.__openPresetCurator = () => presetCurator.open();

// Manual "skip to next preset" — triggered by Cmd+Right while the visualiser
// is fullscreen (see the keydown listener near the bottom of this file).
// Reuses the same preset-choice and transition-timing logic as shuffle/
// adaptive mode ("manual" is just another transition source), so the
// incoming preset picks up the normal shuffle/adaptive playback-duration
// budget from this moment rather than expiring early. `visualTransitions`
// only truly drives the preset engine in the primary (non-output) document —
// see the keydown listener below for how a request from the fullscreen
// visual output window gets relayed here.
function triggerManualNextPreset() {
  if (!visualTransitions) return false;
  const requestedAt = performance.now();
  const begun = visualTransitions.begin(visualTransitions.chooseNextPreset(), "manual");
  if (transitionDiagnosticsEnabled()) {
    const transition = visualTransitions.getTransition();
    console.info("[ManualTransition]", JSON.stringify({ event: "request", requestedAt,
      synchronousMs: performance.now() - requestedAt, begun, id: transition?.diagnosticId,
      from: transition?.from, to: transition?.to, start: transition?.start }));
  }
  return begun;
}

function isVisualiserFullscreen() {
  return document.body.classList.contains("fullscreen-ui");
}

// The visualiser always renders fullscreen in its own native window (the
// "visual output" window), which is a separate WKWebView/document from the
// controls window — so this listener has to run in both documents (this
// script is loaded into each). Whichever one currently has key focus is the
// one that's actually fullscreen, and `isVisualiserFullscreen()` reflects
// that per-document via the "fullscreen-ui" body class each side maintains
// independently. The output document doesn't own `visualTransitions`, so it
// relays the request to the primary document instead of acting locally.
// Drop markers: D at the playhead (Shift-D: a minor drop), or Option-click on the waveform, marks
// a drop there or removes the one that is there. Saved per track (dropMarkerStore.js).
function toggleDropMarkerAt(time, { minor = false } = {}) {
  const timeline = analysisTimeline;
  if (!timeline?.setDropMarkers) {
    ui.audioDiagnostic.textContent = "Drop markers need the track's analysis: wait until the waveform is ready.";
    return;
  }
  const { markers, message } = toggleDropMarker({
    drops: timeline.drops, markers: timeline.dropMarkers, autoDrops: timeline.autoDrops, time, minor
  });
  timeline.setDropMarkers(markers);
  saveDropMarkers(timeline.fingerprint, markers, playerQueueController.currentTrack()?.name || "");
  ui.audioDiagnostic.textContent = message;
  updateWaveformProgress(true);
}

document.addEventListener("keydown", (event) => {
  if (visualOutputRole || event.metaKey || event.ctrlKey || event.altKey || event.repeat) return;
  if (event.key !== "d" && event.key !== "D") return;
  const target = event.target;
  if (target?.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target?.tagName || "")) return;
  if (!playerAudio || !analysisTimeline) return;
  event.preventDefault();
  toggleDropMarkerAt(playerAudio.currentTime || 0, { minor: event.shiftKey });
});

document.addEventListener("keydown", (event) => {
  if (!event.metaKey || event.altKey || event.shiftKey || event.ctrlKey) return;
  if (event.key !== "ArrowRight") return;
  if (!isVisualiserFullscreen()) return;
  event.preventDefault();
  if (event.repeat) return;
  if (transitionDiagnosticsEnabled()) console.info("[ManualTransition]", JSON.stringify({
    event: "shortcut", eventAt: event.timeStamp, receivedAt: performance.now(), output: visualOutputRole
  }));
  if (visualOutputRole) {
    visualOutputController?.sendToMain({ action: "next-preset" });
  } else {
    triggerManualNextPreset();
  }
});

function validateUserPresetText(text) {
  return createUserPresetValidator({
    gl: ensureWebGl(),
    vertexSource,
    existingPresetIds: allPresetRecords().map((preset) => preset.id),
    playerVersion: CYANESCENT_PLAYER_VERSION
  }).validate(text);
}

function installUserPreset(validationResult) {
  const installed = userPresetStore.install(validationResult, allPresetRecords().map((preset) => preset.id));
  registerUserPreset(installed);
  refreshPresetSelectionUi(currentPresetPlaylistId, activePreset);
  queuePresetShaderModulePrime(installed.id, 120);
  return installed;
}

function deleteUserPreset(presetId) {
  const id = Number(presetId);
  const removed = userPresetStore.remove(id);
  if (!removed) return false;
  unregisterUserPreset(id);
  presetPlaylistStore.removePresetFromAll(id);
  if (Number(activePreset) === id) {
    const fallback = builtInPresetOptions[0]?.id ?? allPresetRecords()[0]?.id ?? 0;
    visualTransitions.begin(fallback);
    visualTransitions.markAdaptivePresetStarted?.(playerAudio?.currentTime || 0);
  }
  refreshPresetSelectionUi(currentPresetPlaylistId, activePreset);
  return true;
}

function deleteImportedPreset(presetId) {
  return deleteUserPreset(presetId);
}

function handlePresetPlaylistChanged(playlistId) {
  currentPresetPlaylistId = playlistId || CYANESCENT_PRESETS_PLAYLIST_ID;
  const selected = refreshPresetSelectionUi(currentPresetPlaylistId, activePreset);
  if (Number(selected) !== Number(activePreset)) {
    visualTransitions.begin(selected);
    visualTransitions.markAdaptivePresetStarted?.(playerAudio?.currentTime || 0);
  }
}

ui.presetPlaylistSelect?.addEventListener("change", () => {
  handlePresetPlaylistChanged(ui.presetPlaylistSelect.value);
});

const presetManagerUi = createPresetManagerUI({
  root: ui.presetManagerOverlay,
  nativeAppBridge,
  userPresetStore,
  playlistStore: presetPlaylistStore,
  validatePresetText: validateUserPresetText,
  installPreset: installUserPreset,
  deletePreset: deleteImportedPreset,
  getAllPresets: allPresetRecords,
  getImportedPresets: () => presetCatalog.imported(),
  previewPreset: previewPresetDemo,
  refreshMainUi: (playlistId = currentPresetPlaylistId, options = {}) => (
    refreshPresetSelectionUi(playlistId, activePreset, options)
  ),
  onPresetFallback: (deletedPresetId) => {
    if (Number(activePreset) === Number(deletedPresetId)) {
      const fallback = builtInPresetOptions[0]?.id ?? allPresetRecords()[0]?.id ?? 0;
      visualTransitions.begin(fallback);
    }
  },
  allowJsonPresetImports: editionConfig.allowJsonPresetImports
});

ui.presetManagerButton?.addEventListener("click", () => presetManagerUi.open());

window.__presetJsonFileChosen = (payload = {}) => {
  presetManagerUi.open();
  presetManagerUi.importPresetText(String(payload.text || ""), payload.name || "JSON preset");
};

window.__presetJsonFileFailed = (payload = {}) => {
  presetManagerUi.open();
  presetManagerUi.setStatus(payload.error || "Preset file could not be opened.", "error");
};

function updatePerformanceMeter(now, renderMs) {
  performanceController?.updateMeter(now, renderMs);
}

function benchmarkContext() {
  const renderSize = renderSurface?.renderSize?.() || {};
  return {
    role: visualOutputRole ? "secondary" : "primary",
    quality: quality > 0.5 ? "high" : "standard",
    fullscreen: document.body.classList.contains("fullscreen-ui"),
    windowSize: `${window.innerWidth}x${window.innerHeight}`,
    canvasSize: `${canvas.width}x${canvas.height}`,
    renderSize: `${renderSize.width || 0}x${renderSize.height || 0}`
  };
}

function setAttribs(p) {
  webGlContext.useProgramAndBindFullscreenQuad(p);
}

function clearFeedbackBuffers() {
  renderSurface.clearFeedbackBuffers();
}

function renderShaderOrSpecialTransitionFrame(now, t, transitionPhase) {
  return visualFrameRenderer.renderShaderOrSpecialTransitionFrame(now, t, transitionPhase, blitProgram);
}

async function warmLiveRenderPathDuringSplash() {
  const context = getGl();
  if (!context || !visualFrameRenderer || !renderSurface?.hasBuffers?.()) return;
  try {
    // Trial mode must warm only its selected production preset, just as its
    // module compilation does. Warming the entire library here can consume
    // the native trial's readiness deadline before its first frame.
    const presetIds = presetTrialActive && presetTrialMetadata
      ? [presetTrialMetadata.id]
      : visualTransitions.presetIds();
    for (const presetId of presetIds) {
      ensurePresetShaderModule(presetId, { force: true });
    }
    await visualFrameRenderer.warmPresetPipelines(presetIds, {
      qualities: [0, 1],
      fullResolutionPresetIds: [WORLDSHELL_PRESET_ID],
      onProgress: (ratio) => {
        setSplashProgress(0.985 + ratio * 0.01, "Optimizing transition pipelines");
      }
    });
    visualFrameRenderer.prepareTransitionInfrastructure();
  } catch (error) {
    console.warn("Splash render warmup skipped:", error);
  } finally {
    clearFeedbackBuffers();
  }
}

const visualRendererSetup = createVisualRendererSetup({
  ensureWebGl,
  compileProgram: program,
  fallbackFragmentSource,
  blitSource,
  textureAssets,
  ensureFullscreenQuad,
  resize,
  clearFeedbackBuffers,
  getActivePreset: () => activePreset,
  queuePresetShaderModulePrime,
  presetShaderModuleId,
  scheduleFullShaderCompile,
  getVisualFullShaderReady: () => visualFullShaderReady,
  getFullRenderProgram: () => fullRenderProgram,
  setRenderProgram: (compiledProgram) => {
    renderProgram = compiledProgram;
  },
  getShellRenderProgram: () => shellRenderProgram,
  setShellRenderProgram: (compiledProgram) => {
    shellRenderProgram = compiledProgram;
  },
  getBlitProgram: () => blitProgram,
  setBlitProgram: (compiledProgram) => {
    blitProgram = compiledProgram;
  },
  setShellActive: (shellActive) => {
    visualShellActive = shellActive;
  },
  setVisualsReady: (ready) => {
    visualsReady = ready;
  },
  setFallbackActive: (fallbackActive) => {
    visualFallbackActive = fallbackActive;
  },
  setErrorText: (message) => {
    visualErrorText = message;
  },
  revealRenderLoop: () => {
    revealLiveVisuals();
    startVisualRenderLoop();
  }
});

const liveVisualRuntime = createLiveVisualRuntime({
  isVisualsReady: () => visualsReady,
  skipVisuals: () => !runsLocalVisualRenderer && visualOutputController?.isOpen(),
  isPlaybackStarting: () => Boolean(playerAudio && !playerAudio.paused && playerAudio.currentTime < 4.25),
  initializeRenderer: visualRendererSetup.initializePrimary,
  initializeFallbackRenderer: visualRendererSetup.initializeFallback,
  finishBoot: visualRendererSetup.finishBoot,
  revealVisuals: revealLiveVisuals,
  setStatus: (message) => {
    ui.audioStatus.textContent = message;
  },
  setDiagnostic: (message) => {
    ui.audioDiagnostic.textContent = message;
  },
  setErrorText: (message) => {
    visualErrorText = message || "";
  },
  isOfflineExport: () => renderMode === RenderMode.OFFLINE_EXPORT,
  resize,
  updateAudio: visualOutputRole && !presetTrialActive ? () => {} : updateAudio,
  updateKnotOrbitPhase: visualRuntimeState.updateKnotOrbitPhase,
  updateVisualTransitions: (now) => {
    if (visualOutputRole) {
      videoBackgroundManager.update();
      phaseSpaceReefClamOverlay.update();
      alienVisitDirector.update(now);
      return;
    }
    updateScionAdaptiveTransitions(now);
    visualTransitions.updateVisual(now);
    videoBackgroundManager.update();
    phaseSpaceReefClamOverlay.update();
    alienVisitDirector.update(now);
  },
  updatePresetTransition: (now) => {
    const transition = visualTransitions.getTransition();
    const transitionWasActive = Boolean(transition?.active);
    const transitionId = remoteTransitionId || visualTransitionIdentity(transition);
    videoTransitionManager?.update(transition, now);
    const phase = visualTransitions.updatePreset(now);
    selectPresetCalibration(Number(activePreset));
    if (visualOutputRole && Number(activePreset) !== Number(lastReportedOutputPreset)) {
      lastReportedOutputPreset = activePreset;
      visualOutputController?.reportTransitionState({
        transitionId,
        activePreset,
        complete: false
      });
    }
    if (visualOutputRole && transitionWasActive && !visualTransitions.getTransition()?.active) {
      completedRemoteTransitionId = transitionId;
      remoteTransitionId = "";
      visualOutputController?.reportTransitionState({
        transitionId,
        activePreset,
        complete: true
      });
    }
    return phase;
  },
  updateLiveFeedbackStep: visualRuntimeState.updateLiveFeedbackStep,
  getActivePreset: () => activePreset,
  getTransition: () => visualTransitions.getTransition(),
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  renderShaderOrSpecialTransitionFrame,
  diagnosticsEnabled: transitionDiagnosticsEnabled,
  onFrameMetrics: (metrics) => {
    if (presetTrialRuntime) {
      const state = presetShaderRuntime.diagnosticState(activePreset, quality)?.state || "unknown";
      presetTrialFrameProbeCount += 1;
      const firstFrame = !presetTrialFirstRenderLogged;
      const sampleCanvas = firstFrame || !presetTrialRuntime.ready() || presetTrialFrameProbeCount % 60 === 0;
      if (sampleCanvas) {
        presetTrialLastCanvasProbe = presetTrialCanvasProbe(firstFrame ? "first-frame" : "frame-sample",
          firstFrame || presetTrialFrameProbeCount % 60 === 0);
      }
      const probe = presetTrialLastCanvasProbe;
      if (!presetTrialFirstRenderLogged) {
        presetTrialFirstRenderLogged = true;
        presetTrialLog("RENDER", "FIRST_FRAME", { activePreset, state, renderDiagnostics: metrics?.renderDiagnostics?.branch || "none" });
      }
      const audioReady = !presetTrialTrackActive || (!playerAudio?.paused
        && playerRuntime?.audioContext?.state === "running" && bands.level > 0.01);
      const forgeVideo = Number(activePreset) === APOLLONIAN_PHYSARUM_GENESIS_ID ? window.__forgeHybridVideo
        : Number(activePreset) === DUOVERSE_HD_ID ? window.__duoverseVideo
        : Number(activePreset) === NEWTON_BASIN_DESCENT_ID ? window.__newtonBasinVideo
        : Number(activePreset) === NEWTONS_LAW_ID ? window.__newtonsLawVideo
        : Number(activePreset) === ARTIFICIAL_CONSCIOUSNESS_ID ? window.__artificialConsciousnessVideo
      : Number(activePreset) === HELIX_TUNNEL_ID ? window.__helixTunnelVideo : null;
      const forgeGpuSource = Number(activePreset) === APOLLONIAN_PHYSARUM_GENESIS_ID
        && typeof window.__forgeHybridCaptureSource === "function";
      const gpuAlignment = window.__forgeHybridFrameAlignment || {};
      const forgeReady = forgeGpuSource
        ? Number.isFinite(gpuAlignment.presentedVideoFrame) && gpuAlignment.presentedVideoFrame >= 0
          && (presetTrialRuntime.ready() || gpuAlignment.frameCoherent === true)
        : (Number(activePreset) === STINKHORN_ID ? window.__stinkhornDiagnostics?.videoReady === true : Boolean(forgeVideo?.readyState >= 2 && forgeVideo.currentTime > 0));
      const frameCount = presetTrialRuntime.frame({ presetId: activePreset, presetDisplayName: presetMetadataById.get(Number(activePreset))?.name || "", shaderState: state, canvasValid: (forgeGpuSource ? forgeReady : (probe.valid || forgeReady)) && audioReady });
      if (presetTrialFixtureId.startsWith('stinkhorn-switch') && presetTrialRuntime.ready()) {
        const cycle = Math.floor(presetTrialRuntime.elapsed()/6);
        if (cycle>0 && window.__stinkhornSwitchCycle !== cycle) {
          window.__stinkhornSwitchCycle=cycle;visualTransitions.setPresetImmediate(5);
          window.setTimeout(()=>visualTransitions.setPresetImmediate(STINKHORN_ID),600);
          presetTrialLog('STINKHORN','DESELECT_RESELECT',{cycle});
        }
      }
      if (presetTrialFixtureId.startsWith('stinkhorn-export') && presetTrialRuntime.ready()
          && presetTrialRuntime.elapsed() > 3 && analysisTimeline && !analysisPending && !window.__stinkhornExportTrialStarted) {
        window.__stinkhornExportTrialStarted = true;
        const directory = new URLSearchParams(window.location.search).get('trialOutputDirectory');
        if (directory) musicVideoExportActions.startDiagnostic({
          outputPath: directory + '/offline-augmented.mp4', sourceStart: 26, sourceEnd: 28,
          options: {width:1280,height:720,fps:30,bitrateMbps:12,includeAudio:false,
            destinationId:'custom',autoClipBehaviour:'match-full-video'}
        }).then(result => presetTrialLog('STINKHORN','OFFLINE_EXPORT_RESULT',{...result,error:result?.error?.message || ''}))
          .catch(e => console.error('[Stinkhorn] Offline export: ' + e.message));
      }
      if (presetTrialFixtureId === 'helix-transition' && presetTrialRuntime.ready()
        && presetTrialRuntime.elapsed() > .6 && !window.__helixTrialTransitionStarted) {
        window.__helixTrialTransitionStarted = true;
        visualTransitions.setPresetImmediate(5);
        const began = visualTransitions.begin(HELIX_TUNNEL_ID, 'diagnostic', {
          forceVideoTransition: true, videoTransitionId: 'cosmic_om', timing: { duration: 3000, swapAt: .45 }
        });
        presetTrialLog('HELIX', 'VIDEO_TRANSITION_BEGIN', { began });
      }
      if (presetTrialFixtureId === 'helix-transition' && frameCount % 30 === 0) {
        presetTrialLog('HELIX', 'VIDEO_TRANSITION_STATE', {
          transition: visualTransitions.getTransition(), video: videoTransitionManager?.diagnosticState?.()
        });
      }
      if (presetTrialTrackActive && frameCount % 60 === 0) {
        presetTrialLog("AUDIO", "LIVE_TRACK", { trackTime: playerAudio?.currentTime,
          paused: playerAudio?.paused, context: playerRuntime?.audioContext?.state,
          bands: { ...bands }, beat: musicAwareState.absoluteBeat,
          highEnergy: musicAwareState.highEnergy, analysisReady: Boolean(analysisTimeline) });
      }
      if (window.__presetTrialCaptureRequested) {
        const requests = presetTrialCaptureRequests.splice(0);
        window.__presetTrialCaptureRequested = false;
        try {
          // Capture while this production render frame still owns the accelerated
          // default framebuffer; later canvas reads can see a discarded buffer.
          if (forgeGpuSource) {
            const capture = window.__forgeTrialCaptureCanvas || document.createElement("canvas");
            window.__forgeTrialCaptureCanvas = capture;
            const alignment = window.__forgeHybridFrameAlignment || {};
            const fixtureTime = presetTrialRuntime.elapsed();
            const mediaClockTime = Number(forgeVideo?.currentTime) || 0;
            const effects = window.__forgeHybridEffectSnapshot?.() || window.__forgeHybridDiagnostics || {};
            const result = captureForgeGpuTrialFrame({ canvas, sourceCanvas: capture,
              captureSource: window.__forgeHybridCaptureSource,
              alignment, effects, controls: window.__forgeHybridControls || {},
              fixture: presetTrialFixtureId, fixtureTime, mediaClockTime,
              compare: isForgeArrangementTrialFixture(presetTrialFixtureId) });
            window.__presetTrialLastCanvasPng = result.composite;
            if (result.comparison) window.__forgeTrialLastComparison = result.comparison;
          } else if (forgeVideo && forgeVideo.style.display !== "none") {
            const capture = window.__forgeTrialCaptureCanvas || document.createElement("canvas");
            window.__forgeTrialCaptureCanvas = capture;
            if (capture.width !== canvas.width || capture.height !== canvas.height) {
              capture.width = canvas.width;
              capture.height = canvas.height;
            }
            const context = capture.getContext("2d");
            const forgeComparison = Number(activePreset) === APOLLONIAN_PHYSARUM_GENESIS_ID
              && isForgeArrangementTrialFixture(presetTrialFixtureId);
            context.globalAlpha = 1;
            context.fillStyle = "#03040a";
            context.fillRect(0, 0, capture.width, capture.height);
            let capturedVideoTime = null;
            let capturedFixtureTime = null;
            if (forgeVideo.readyState >= 2) {
              const aspect = forgeVideo.videoWidth / forgeVideo.videoHeight;
              const width = Math.min(capture.width, capture.height * aspect);
              const height = width / aspect;
              // Snapshot both clocks before drawing/encoding. PNG encoding can
              // take long enough for the media clock to advance another frame.
              capturedVideoTime = forgeVideo.currentTime;
              capturedFixtureTime = presetTrialRuntime.elapsed();
              context.drawImage(forgeVideo, (capture.width - width) * 0.5, (capture.height - height) * 0.5, width, height);
            }
            const sourcePng = forgeComparison ? capture.toDataURL("image/png") : null;
            const overlayPng = forgeComparison ? canvas.toDataURL("image/png") : null;
            context.drawImage(canvas, 0, 0);
            window.__presetTrialLastCanvasPng = capture.toDataURL("image/png");
            if (forgeComparison) {
              const alignment = window.__forgeHybridFrameAlignment || {};
              const effects = window.__forgeHybridEffectSnapshot?.() || window.__forgeHybridDiagnostics || {};
              window.__forgeTrialLastComparison = {
                source: sourcePng, overlay: overlayPng, composite: window.__presetTrialLastCanvasPng,
                diagnostics: {
                  fixture: presetTrialFixtureId, fixtureTime: capturedFixtureTime,
                  capturedVideoTime,
                  renderVideoTime: alignment.videoTime ?? null,
                  fieldVideoTime: alignment.videoTime ?? null,
                  fieldFrames: alignment.fieldFrames ? [...alignment.fieldFrames] : null,
                  fieldMix: alignment.fieldMix ?? null,
                  debug: window.__forgeHybridControls?.debug ?? null,
                  braids: { ...effects.braids },
                  effects: { ...effects.effects },
                  cues: { ...effects.cues },
                  controls: { ...window.__forgeHybridControls },
                  width: capture.width, height: capture.height
                }
              };
            }
          } else {
            window.__presetTrialLastCanvasPng = canvas.toDataURL("image/png");
          }
          const result = Number(activePreset) === APOLLONIAN_PHYSARUM_GENESIS_ID
            && isForgeArrangementTrialFixture(presetTrialFixtureId)
            ? window.__forgeTrialLastComparison : window.__presetTrialLastCanvasPng;
          for (const request of requests) {
            clearTimeout(request.timer);
            request.resolve(result);
          }
        } catch (error) {
          for (const request of requests) {
            clearTimeout(request.timer);
            request.reject(error);
          }
        }
      }
      if (frameCount % 60 === 0) presetTrialRuntime.report();
    }
    if (worldshellBenchmarkConfigValue.enabled && !worldshellBenchmarkFrameObserved) {
      worldshellBenchmarkFrameObserved = true;
      traceWorldshellBenchmark("first_render_frame", benchmarkContext());
    }
    const result = worldshellBenchmark.onFrame({
      ...metrics,
      context: benchmarkContext()
    });
    if (result && visualOutputRole) {
      document.body.classList.remove("worldshell-benchmark-output");
    }
  },
  getTransitionDiagnosticContext: () => {
    const transition = visualTransitions.getTransition();
    return {
      quality: quality > 0.5 ? "high" : "standard",
      fullscreen: document.body.classList.contains("fullscreen-ui"),
      shaderFrom: presetShaderRuntime.diagnosticState(transition?.from),
      shaderTo: presetShaderRuntime.diagnosticState(transition?.to),
      video: videoTransitionManager?.diagnosticState?.() || null
    };
  },
  getPresetName: (presetId) => presetMetadataById.get(Number(presetId))?.name || "",
  updatePerformanceMeter
});

function startVisualRenderLoop() {
  if (!runsLocalVisualRenderer) return;
  liveVisualRuntime.startVisualRenderLoop();
}

function revealLiveVisuals() {
  if (!runsLocalVisualRenderer) return;
  document.body.classList.add("visuals-live");
  document.body.classList.remove("visuals-idle");
}

function initializeVisualEngine(options = {}) {
  liveVisualRuntime.initialize(options);
}

function activateVisuals(delay = 0) {
  if (runsLocalVisualRenderer) liveVisualRuntime.activate(delay);
  else visualOutputController?.openAutomatically();
}

function selectWorldshellBenchmarkPreset() {
  quality = 0;
  ui.standardMode?.classList.add("active");
  ui.highMode?.classList.remove("active");
  visualTransitions.setStaticTransitionMode();
  if (ui.transitionMode) ui.transitionMode.value = VisualTransitionMode.STATIC;
  visualTransitions.setPresetImmediate(WORLDSHELL_PRESET_ID);
  if (ui.presetSelect) ui.presetSelect.value = String(WORLDSHELL_PRESET_ID);
}

async function startWorldshellBenchmark() {
  if (!worldshellBenchmarkConfigValue.enabled || worldshellBenchmarkLaunchStarted) return;
  if (visualOutputRole) return;
  worldshellBenchmarkLaunchStarted = true;
  traceWorldshellBenchmark("controller_launch_started", { target: worldshellBenchmarkConfigValue.target });
  selectWorldshellBenchmarkPreset();
  await setPlayerQueue([{
    id: "worldshell-benchmark-track",
    name: "Joyride.wav",
    url: `/perf-test-track?worldshell=${Date.now()}`
  }], 0, true);

  if (primaryWorldshellBenchmark) {
    document.body.classList.add("fullscreen-ui");
    activateVisuals(0);
    window.setTimeout(() => {
      nativeAppBridge()?.postMessage("toggleFullscreen");
    }, 250);
    window.setTimeout(() => {
      worldshellBenchmark.start(benchmarkContext());
      traceWorldshellBenchmark("primary_sampler_started", benchmarkContext());
    }, 1500);
    return;
  }

  visualOutputController?.show();
  visualOutputController?.toggleFullscreen();
  traceWorldshellBenchmark("secondary_fullscreen_requested");
  window.setTimeout(() => {
    traceWorldshellBenchmark("secondary_sampler_requested");
    visualOutputController?.sendToOutput({
      action: "worldshell-benchmark-start",
      config: worldshellBenchmarkConfigValue
    });
  }, 1500);
}

async function refreshDevices() {
  return audioInputDeviceController.refreshDevices();
}

function refreshDevicesOnDemand() {
  audioInputDeviceController.refreshDevicesOnDemand();
}

function stopInputStream() {
  audioInputDeviceController.stopInputStream();
}

const offlineFrameCapture = createOfflineFrameCapture({ getGl: ensureWebGl, canvas });

// Offline export deliberately avoids captureStream/MediaRecorder. Each frame is rendered
// from an absolute audio timestamp, then passed to the native constant-frame-rate encoder.
const exportTrackName = () => uiPreviewFixtureTrackName || playerQueueController.currentTrack()?.name || "";
const exportTrackDuration = () => uiPreviewFixtureDuration || playerDuration();
function exportPresetOptions() {
  return Array.from(ui.presetSelect?.options || [])
    .map((option) => ({ id: Number(option.value), name: option.textContent }))
    .filter((option) => Number.isFinite(option.id));
}
function seekExportPlayback(time) {
  if (!playerAudio) return;
  playerAudio.currentTime = time;
  updateLookaheadState();
  visualTransitions.handleSeek(playerAudio.currentTime || 0);
  updateWaveformProgress(true);
}

const exportStudio = createExportStudio({
  ui,
  exportState,
  exportRangeModel,
  getTrackName: exportTrackName,
  getTrackDuration: exportTrackDuration,
  getAnalysisTimeline: () => analysisTimeline,
  getPlaybackAudio: () => playerAudio,
  playAudio: () => playPlayerAudioWithFade(),
  pauseAudio: () => playerAudio?.pause(),
  seekAudio: seekExportPlayback,
  previewSelection: (options) => previewExportSelection(options),
  stopSelectionPreview: () => stopExportRangePreview(),
  // Preview frames come from the offline export renderer in this window, so the
  // preview never opens or depends on the visualiser window.
  preview: { begin: (options) => musicVideoExportActions.beginPreview(options) },
  getPresetOptions: exportPresetOptions,
  getActivePreset: () => activePreset,
  selectPreset: (id) => {
    // Apply at once: exports start from the active preset, and this window does not
    // render, so a blended change would only complete if the visualiser were showing.
    const preset = visualTransitions.normalizePresetId(Number(id));
    if (!Number.isFinite(Number(preset))) return;
    visualTransitions.setPresetImmediate(preset);
    if (ui.presetSelect) ui.presetSelect.value = String(preset);
    musicVideoExportActions.notePresetSelected(preset);
  },
  nativeAppBridge,
  loadPreferences: () => optionsController.options.exportStudio,
  savePreferences: (preferences) => {
    optionsController.options.exportStudio = { ...(optionsController.options.exportStudio || {}), ...preferences };
    persistAppOptions(optionsController.options);
  },
  startExport: async () => musicVideoExportActions.start(),
  cancelExport: () => musicVideoExportActions.cancel(),
  holdVisualiserHidden: (hold) => visualOutputController?.holdHidden?.(hold),
  revealExportedVideo: (path) => {
    if (path) nativeAppBridge()?.postMessage({ command: "revealExportedVideo", path });
  }
});
// The export runtime and diagnostics use this contract.
const exportDialog = exportStudio;

function stopPresetDemoPreview({ reopenManager = true } = {}) {
  if (!presetDemoPreview) return;
  const preview = presetDemoPreview;
  presetDemoPreview = null;
  window.clearTimeout(preview.timeout);
  window.clearInterval(preview.interval);
  document.body.classList.remove("timeline-previewing", "preset-demo-previewing");
  ui.timelinePreviewWindow?.classList.add("hidden");
  visualTransitions.setTransitionMode(preview.previousTransitionMode || VisualTransitionMode.STATIC);
  visualTransitions.setTransition(preview.previousTransition || createInactivePresetTransition(preview.previousPreset));
  activePreset = preview.previousPreset;
  activePresetStartedAt = performance.now();
  ui.presetSelect.value = String(activePreset);
  syncVideoBackgroundForPreset(activePreset);
  quality = preview.previousQuality;
  ui.highMode.classList.toggle("active", quality > 0.5);
  ui.standardMode.classList.toggle("active", quality <= 0.5);
  resize();
  if (preview.audio && preview.wasPlaying) {
    playPlayerAudioWithFade().catch(console.error);
  }
  if (reopenManager) presetManagerUi?.open();
}

function previewPresetDemo(presetId) {
  stopMusicVideoTimelinePreview({ restore: true });
  stopPresetDemoPreview({ reopenManager: false });
  const previewPreset = Number(presetId);
  const preset = presetCatalog.byId(previewPreset);
  if (!Number.isFinite(previewPreset) || !preset) return;
  const audio = playerAudio;
  const wasPlaying = Boolean(audio && !audio.paused);
  if (wasPlaying) audio.pause();
  const previousPreset = activePreset;
  const previousTransition = { ...visualTransitions.getTransition() };
  const previousTransitionMode = visualTransitions.getTransitionMode();
  const previousQuality = quality;
  const startedAt = performance.now();

  visualTransitions.setTransitionMode(VisualTransitionMode.STATIC);
  visualTransitions.setPresetImmediate(previewPreset);
  visualTransitions.setTransition(createInactivePresetTransition(previewPreset));
  activePresetStartedAt = startedAt;
  quality = 0;
  ui.highMode.classList.remove("active");
  ui.standardMode.classList.add("active");
  document.body.classList.add("timeline-previewing", "preset-demo-previewing");
  ui.timelinePreviewWindow?.classList.remove("hidden");
  activateVisuals(0);
  resize();

  const title = ui.timelinePreviewWindow?.querySelector(".timeline-preview-titlebar span");
  const updateTitle = () => {
    if (!presetDemoPreview || !title) return;
    const remaining = Math.max(0, Math.ceil(30 - (performance.now() - startedAt) / 1000));
    title.textContent = `${preset?.name || "Preset"} · Silent demo · ${remaining}s`;
  };
  const timeout = window.setTimeout(() => stopPresetDemoPreview({ reopenManager: true }), 30000);
  const interval = window.setInterval(updateTitle, 250);
  presetDemoPreview = {
    audio,
    wasPlaying,
    previousPreset,
    previousTransition,
    previousTransitionMode,
    previousQuality,
    startedAt,
    timeout,
    interval
  };
  updateTitle();
}

function stopMusicVideoTimelinePreview({ restore = true } = {}) {
  if (!musicVideoPreview) return;
  const preview = musicVideoPreview;
  musicVideoPreview = null;
  document.body.classList.remove("timeline-previewing");
  ui.timelinePreviewWindow?.classList.add("hidden");
  window.clearInterval(preview.interval);
  window.clearTimeout(preview.transitionTimer);
  const audio = preview.audio;
  if (restore && audio) {
    audio.pause();
    if (Number.isFinite(preview.previousTime)) {
      audio.currentTime = Math.min(preview.previousTime, playerDuration() || preview.previousTime);
    }
  }
  visualTransitions.setTransitionMode(preview.previousTransitionMode || VisualTransitionMode.STATIC);
  visualTransitions.setTransition(preview.previousTransition || createInactivePresetTransition(preview.previousPreset));
  activePreset = preview.previousPreset;
  activePresetStartedAt = performance.now();
  ui.presetSelect.value = String(activePreset);
  syncVideoBackgroundForPreset(activePreset);
  quality = preview.previousQuality;
  ui.highMode.classList.toggle("active", quality > 0.5);
  ui.standardMode.classList.toggle("active", quality <= 0.5);
  resize();
  if (restore && audio && preview.wasPlaying) {
    playPlayerAudioWithFade().catch(console.error);
  }
  ui.audioDiagnostic.textContent = restore ? "Timeline preview complete" : "Timeline preview stopped";
}

async function previewMusicVideoTimelineSection(plan = {}) {
  const audio = ensurePlayer();
  if (!audio?.src) return;
  stopMusicVideoTimelinePreview({ restore: true });
  const trackDuration = playerDuration() || audio.duration || 0;
  const startTime = Math.max(0, Math.min(trackDuration, Number(plan.startTime) || 0));
  const endTime = Math.max(startTime + 1, Math.min(trackDuration, Number(plan.endTime) || startTime + 12));
  const previewPreset = visualTransitions.normalizePresetId(plan.presetId ?? activePreset);
  const previousTransition = { ...visualTransitions.getTransition() };
  const previousPreset = activePreset;
  const previousTime = Number(audio.currentTime) || 0;
  const wasPlaying = !audio.paused;
  const previousQuality = quality;
  const previousTransitionMode = visualTransitions.getTransitionMode();

  visualTransitions.setTransitionMode(VisualTransitionMode.STATIC);
  visualTransitions.setPresetImmediate(previewPreset);
  visualTransitions.setTransition(createInactivePresetTransition(previewPreset));
  document.body.classList.add("timeline-previewing");
  ui.timelinePreviewWindow?.classList.remove("hidden");
  const previewTitle = ui.timelinePreviewWindow?.querySelector(".timeline-preview-titlebar span");
  if (previewTitle) previewTitle.textContent = "Timeline Preview";
  quality = 0;
  ui.standardMode.classList.add("active");
  ui.highMode.classList.remove("active");
  resize();
  activateVisuals(0);

  audio.currentTime = startTime;
  ui.audioDiagnostic.textContent = "Previewing timeline section...";
  try {
    await playPlayerAudioWithFade();
  } catch (error) {
    document.body.classList.remove("timeline-previewing");
    ui.timelinePreviewWindow?.classList.add("hidden");
    visualTransitions.setTransitionMode(previousTransitionMode || VisualTransitionMode.STATIC);
    visualTransitions.setTransition(previousTransition || createInactivePresetTransition(previousPreset));
    activePreset = previousPreset;
    quality = previousQuality;
    ui.highMode.classList.toggle("active", quality > 0.5);
    ui.standardMode.classList.toggle("active", quality <= 0.5);
    resize();
    throw error;
  }

  const transition = plan.transition;
  let transitionTimer = 0;
  if (transition?.toPreset && transition.toPreset !== transition.fromPreset) {
    const triggerDelayMs = Math.max(0, ((Number(transition.triggerTime) || startTime) - startTime) * 1000);
    transitionTimer = window.setTimeout(() => {
      visualTransitions.begin(transition.toPreset, "preview", {
        style: transition.style || 0,
        timing: {
          duration: Math.max(1, Number(transition.durationSeconds) || 2.6) * 1000,
          swapAt: Number.isFinite(transition.swapAt) ? transition.swapAt : 0.5
        },
        videoTransitionId: transition.videoTransitionId || "",
        forceVideoTransition: Boolean(transition.forceVideoTransition),
        suppressVideoTransition: Boolean(transition.suppressVideoTransition),
        suppressShaderTransition: Boolean(transition.suppressShaderTransition)
      });
    }, triggerDelayMs);
  }

  const interval = window.setInterval(() => {
    if (!musicVideoPreview || audio.paused || audio.currentTime >= endTime) {
      stopMusicVideoTimelinePreview({ restore: true });
    }
  }, 90);

  musicVideoPreview = {
    audio,
    interval,
    transitionTimer,
    previousPreset,
    previousTime,
    wasPlaying,
    previousQuality,
    previousTransition,
    previousTransitionMode
  };
}

// Custom Timeline: the automatic starting sequence comes from the same offline
// generator Automatic exports use, seeded so a sequence is reproducible.
function buildAutomaticExportSequence({ seed = 0 } = {}) {
  const ids = visualTransitions.adaptiveEligiblePresetIds?.() || exportPresetOptions().map((option) => option.id);
  if (!ids.length || !analysisTimeline) return null;
  const pick = Math.floor(fractJs(Math.sin((seed + 1) * 12.9898 + ids.length * 78.233) * 43758.5453) * ids.length);
  const startPreset = visualTransitions.normalizePresetId(ids[Math.max(0, Math.min(ids.length - 1, pick))]);
  const mode = ui.transitionMode?.value === VisualTransitionMode.SHUFFLE ? VisualTransitionMode.SHUFFLE : VisualTransitionMode.ADAPTIVE;
  const timeline = buildOfflinePresetTimelinePlan({
    analysisTimeline,
    duration: playerDuration() || analysisTimeline.duration || 0,
    mode,
    shuffleSeconds: ui.shuffleSeconds?.value,
    activePreset: startPreset,
    normalizePresetId: (value) => visualTransitions.normalizePresetId(value),
    adaptiveEligiblePresetIds: () => ids,
    presetMetadataById,
    addWaveformTransitionMarker: null,
    videoTransitionOptions: currentVideoTransitionOptions(),
    renderedTransitionDuration: exportStudio.exportOptions().renderedTransitionDuration
  });
  return { startPreset, timeline };
}

const exportJourneyEditor = createExportJourneyEditor({
  studio: exportStudio,
  ui,
  exportRangeModel,
  getAnalysisTimeline: () => analysisTimeline,
  getDuration: exportTrackDuration,
  getTrackKey: () => `${exportTrackName()}|${Math.round(exportTrackDuration() * 10)}|${analysisTimeline ? "a" : "-"}`,
  getPlaybackAudio: () => playerAudio,
  playAudio: () => playPlayerAudioWithFade(),
  pauseAudio: () => playerAudio?.pause(),
  seekAudio: seekExportPlayback,
  getPresetOptions: exportPresetOptions,
  normalizePresetId: (value) => visualTransitions.normalizePresetId(value),
  buildAutomaticSequence: buildAutomaticExportSequence,
  getVideoTransitionOptions: currentVideoTransitionOptions,
  addWaveformTransitionMarker
});
exportStudio.attachJourney(exportJourneyEditor);

const offlineExportController = createOfflineExportController({
  buildOfflinePresetTimelinePlan,
  computeOfflineAudioState,
  renderOfflineFrameView,
  prepareOfflinePresetFrame: async ({state,clock,timeline,startPreset,time,sampleInputsAt}) => {
    const resources = await visualFrameRenderer.prepareOfflineFrame(state, clock, sampleInputsAt);
    const involved = Number(state.preset) === STINKHORN_ID ||
      Number(state.transition?.from) === STINKHORN_ID || Number(state.transition?.to) === STINKHORN_ID;
    if (!involved) { visualFrameRenderer.endStinkhornOffline(); return resources; }
    await visualFrameRenderer.prepareStinkhornOffline(clock.presetTimes[STINKHORN_ID] || 0);
    return resources;
  },
  getAnalysisTimeline: () => analysisTimeline,
  getAnalysisPending: () => analysisPending,
  getVisualsReady: () => visualsReady,
  getVisualEngineWarmupPromise: () => visualEngineWarmupPromise,
  getVisualEngineBootComplete: () => visualEngineBootComplete,
  warmVisualEngineAtStartup,
  getSlowLevel: () => slowLevel,
  getSlowBass: () => slowBass,
  resetScionBiofeedback: () => resetScionBiofeedbackState(scionBiofeedback),
  setLookaheadState: (value) => { lookaheadState = value; },
  setBands: (value) => { bands = value; },
  assignAudioFeatures: (value) => { Object.assign(audioFeatures, value); },
  setSmooth: (value) => { smooth = value; },
  setSlowAudio: (nextSlowLevel, nextSlowBass) => {
    slowLevel = nextSlowLevel;
    slowBass = nextSlowBass;
  },
  setWaveformProgress: (value) => { waveformController.setProgress(value); },
  setMusicAwareState: (value) => { musicAwareState = value; },
  setVisualRuntimeOfflineState: visualRuntimeState.setOfflineState,
  setOfflineVideoBackgroundState: (value) => { offlineVideoBackgroundState = value; },
  videoBackgroundStateAt,
  getTransitionMode: () => ui.transitionMode?.value || VisualTransitionMode.STATIC,
  getShuffleSeconds: () => ui.shuffleSeconds?.value,
  getVideoTransitionOptions: currentVideoTransitionOptions,
  getRenderedTransitionDuration: () => exportStudio.exportOptions().renderedTransitionDuration,
  getManualExportTimeline: (options) => exportJourneyEditor.manualTimeline(options),
  getActivePreset: () => activePreset,
  normalizePresetId: (value) => visualTransitions.normalizePresetId(value),
  adaptiveEligiblePresetIds: () => visualTransitions.adaptiveEligiblePresetIds(),
  presetMetadataById,
  addWaveformTransitionMarker,
  resize,
  setExportResolutionOverride: (value) => { exportResolutionOverride = value; },
  setActivePreset: (value) => { activePreset = requireRuntimePreset(value); },
  setActivePresetStartedAt: (value) => { activePresetStartedAt = value; },
  setPresetSelectValue: (value) => { ui.presetSelect.value = value; },
  setOfflineRenderClock: (value) => { offlineRenderClock = value; if (!value) { visualFrameRenderer.endOfflineFrame(); } },
  getTransition: () => visualTransitions.getTransition(),
  setTransition: (value) => visualTransitions.setTransition(value),
  isFiddleheadPreset,
  isPineconePreset,
  isQuantumFluidPreset,
  isKleinianCoralCathedralPreset,
  isBloodCellNebulaPreset,
  renderFiddleheadGeometry,
  renderPinecone3D,
  renderQuantumFluid3D,
  renderKleinianCoralCathedral,
  renderBloodCellNebula,
  renderShaderOrSpecialTransitionFrame,
  getPreviousFrameWasPine3D: specialGeometryRenderer.getPreviousFrameWasPine3D,
  setPreviousFrameWasPine3D: specialGeometryRenderer.setPreviousFrameWasPine3D,
  clearFeedbackBuffers
});

registerNativeOfflineExportCallbacks({
  state: exportState,
  setProgress: exportDialog.setProgress,
  currentProgressValue: () => ui.exportProgress.value
});

const musicVideoExportActions = createMusicVideoExportActions({
  ui,
  exportState,
  exportDialog,
  offlineExportController,
  playerDuration,
  currentTrack: () => playerQueueController.currentTrack(),
  ensurePlayer,
  nativeAppBridge,
  normalizePresetId: (value) => visualTransitions.normalizePresetId(value),
  getActivePreset: () => activePreset,
  setActivePreset: (value) => { activePreset = requireRuntimePreset(value); },
  getTransition: () => visualTransitions.getTransition(),
  setTransition: (value) => visualTransitions.setTransition(value),
  getRenderMode: () => renderMode,
  setRenderMode: (value) => {
    renderMode = value;
    const exporting = value === RenderMode.OFFLINE_EXPORT;
    setPresetCalibrationState({ exporting });
    visualOutputController.sendToOutput({ action: "preset-calibration-export", exporting });
  },
  getWaveformProgress: () => waveformController.progress(),
  setWaveformProgress: (value) => { waveformController.setProgress(value); },
  getReadIndex: () => renderSurface.readIndex(),
  setReadIndex: (value) => { renderSurface.setReadIndex(value); },
  getQuality: () => quality,
  setQuality: (value) => { quality = value; },
  setOfflineRenderClock: (value) => { offlineRenderClock = value; if (!value) { visualFrameRenderer.endOfflineFrame(); } },
  setFeedbackStep: (value) => { visualRuntimeState.setOfflineState({ feedbackStep: value }); },
  resetOfflineVideoBackgroundState: () => { offlineVideoBackgroundState = null; },
  resetFeedbackStepTiming: visualRuntimeState.resetFeedbackStepTiming,
  setExportResolutionOverride: (value) => { exportResolutionOverride = value; },
  getGl: ensureWebGl,
  getActualRenderSize: () => ({
    canvasWidth: canvas.width,
    canvasHeight: canvas.height,
    renderWidth: renderSurface.renderWidth(),
    renderHeight: renderSurface.renderHeight()
  }),
  resize,
  clearFeedbackBuffers,
  resetLookaheadState,
  drawWaveform,
  offlineFrameCapture,
  offlineVideoTransitionCompositor,
  getVideoTransitionOptions: currentVideoTransitionOptions,
  getAnalysisTimeline: () => analysisTimeline,
  isTimelineMode: () => exportStudio.isCustom(),
  getCanvas: () => canvas,
  // After preview frames: this window keeps nothing running unless it renders live.
  stopPresetRuntimes: (keepPreset) => visualFrameRenderer.stopForgeHybrid(runsLocalVisualRenderer ? keepPreset : null),
  playPlayerAudioWithFade,
  renderModeOfflineExport: RenderMode.OFFLINE_EXPORT,
  builtInPresets: builtInPresetOptions
});

ui.presetTestBatchSection?.classList.remove("hidden");
window.__presetTestBatchSetupFailed = (payload = {}) => {
  exportDialog.setProgress(0, payload.error || "Preset test batch setup failed.");
  if (ui.exportPresetTestBatch) ui.exportPresetTestBatch.disabled = false;
};
window.__presetTestBatchSetupReady = async (payload = {}) => {
  const track = payload.track;
  if (!track?.url || !payload.outputDirectory) {
    window.__presetTestBatchSetupFailed({ error: "Preset test audio or output folder was unavailable." });
    return;
  }
  window.__loadNativeTrack?.(track, { autoplay: false, source: "preset-test-batch" });
  exportDialog.setProgress(0, "Loading and analysing preset-test audio...");
  const deadline = performance.now() + 90000;
  while (performance.now() < deadline) {
    const current = playerQueueController.currentTrack();
    if (String(current?.nativeId || current?.id) === String(track.nativeId || track.id)
        && playerDuration() >= 15) break;
    await new Promise((resolve) => window.setTimeout(resolve, 100));
  }
  const current = playerQueueController.currentTrack();
  if (String(current?.nativeId || current?.id) !== String(track.nativeId || track.id) || playerDuration() < 15) {
    window.__presetTestBatchSetupFailed({ error: "The preset-test audio did not become ready." });
    return;
  }
  try {
    await musicVideoExportActions.startPresetTestBatch({ outputDirectory: payload.outputDirectory });
  } catch (error) {
    exportDialog.setProgress(0, `Preset test batch failed: ${error.message || "unknown error"}`);
    if (ui.exportPresetTestBatch) ui.exportPresetTestBatch.disabled = false;
  }
};

ui.exportPresetTestBatch?.addEventListener("click", () => {
  ui.exportPresetTestBatch.disabled = true;
  exportDialog.setProgress(0, "Choose where to save the preset-test batch...");
  nativeAppBridge()?.postMessage({ command: "preparePresetTestBatch" });
});

window.__presetImportPreviewSetupFailed = (payload = {}) => {
  nativeAppBridge()?.postMessage({ command: "presetImportPreviewFailed", error: payload.error || "Preview setup failed." });
};
window.__presetImportPreviewSetup = async (payload = {}) => {
  const { track, presetId, outputPath } = payload;
  if (!track?.url || !presetId || !outputPath) {
    window.__presetImportPreviewSetupFailed({ error: "Missing track, presetId, or outputPath in setup payload." });
    return;
  }
  window.__loadNativeTrack?.(track, { autoplay: false, source: "preset-import-preview" });
  const deadline = performance.now() + 90000;
  while (performance.now() < deadline) {
    const current = playerQueueController.currentTrack();
    if (String(current?.nativeId || current?.id) === String(track.nativeId || track.id)
        && playerDuration() >= 15) break;
    await new Promise((resolve) => window.setTimeout(resolve, 100));
  }
  const current = playerQueueController.currentTrack();
  if (String(current?.nativeId || current?.id) !== String(track.nativeId || track.id) || playerDuration() < 15) {
    window.__presetImportPreviewSetupFailed({ error: "The preset-import audio did not become ready within 90 seconds." });
    return;
  }
  try {
    const result = await musicVideoExportActions.startPresetImportPreview({ outputPath, presetId, durationSeconds: 30 });
    if (result?.success) {
      nativeAppBridge()?.postMessage({ command: "presetImportPreviewComplete", path: result.path || outputPath });
    } else if (result?.cancelled) {
      window.__presetImportPreviewSetupFailed({ error: "Preview export was cancelled." });
    } else {
      window.__presetImportPreviewSetupFailed({ error: result?.error || "Preview export returned failure." });
    }
  } catch (error) {
    window.__presetImportPreviewSetupFailed({ error: error.message || "Preview export threw an unexpected error." });
  }
};

function releaseObjectUrls() {
  playerController?.releaseObjectUrls?.();
  videoAssetManager.releaseObjectUrls();
}

async function loadPlayerFiles(files, autoplay = false) {
  leaveScionAudioSource();
  return playerController?.loadPlayerFiles?.(files, autoplay);
}

async function setPlayerQueue(tracks, startIndex = 0, autoplay = false) {
  return playerController?.setPlayerQueue?.(tracks, startIndex, autoplay);
}

async function loadTrackAt(index, autoplay = false, playlistId) {
  return playerController?.loadTrackAt?.(index, autoplay, playlistId);
}

async function handleTrackEnded() {
  return playerController?.handleTrackEnded?.();
}

async function togglePlayer() {
  return playerController?.togglePlayer?.();
}

async function selectPlayerAudioSource() {
  return playerController?.selectPlayerAudioSource?.();
}

function ensurePlayer() {
  return playerRuntime.ensurePlayer();
}

function resetLookaheadState() {
  audioAnalysisRuntime.resetLookaheadState();
}

async function analyzeLoadedTrack(src, generation, decodedBuffer) {
  await audioAnalysisRuntime.analyzeLoadedTrack(src, generation, decodedBuffer);
}

function updateLookaheadState() {
  audioAnalysisRuntime.updateLookaheadState();
}

function blendTimelineIntoBands() {
  audioAnalysisRuntime.blendTimelineIntoBands();
}

function updateLiveTempo() {
  audioAnalysisRuntime.updateLiveTempo();
}

function updateMusicAwareState() {
  audioAnalysisRuntime.updateMusicAwareState();
}

async function setupPlayerAnalyser(options = {}) {
  return playerRuntime.setupPlayerAnalyser(options);
}

let playerController = null;

playerController = createPlayerController({
  ui,
  playerQueueController,
  isAudioFileName,
  ensurePlayer,
  ensureAudioContext,
  setupPlayerAnalyser,
  playPlayerAudioWithFade,
  applyPlayerVolume,
  currentPlayerVolume: () => playerRuntime.currentPlayerVolume(),
  analyzeLoadedTrack,
  resetLookaheadState,
  visualTransitions,
  waveformController,
  onTrackSourceReset: () => exportRangeModel.setTrackDuration(0),
  updateWaveformProgress,
  updateTrackTimeDisplay,
  nativeAppBridge,
  stopInputStream,
  setMonitoringInput: (value) => { monitoringInput = value; },
  setPlayerMode: (value) => { playerMode = value; },
  clearAnalyserBuffers: () => {
    playerRuntime.clearAnalyserBuffers();
  },
  incrementAnalysisGeneration: () => {
    analysisGeneration += 1;
    return analysisGeneration;
  },
  setAnalysisTimeline: (value) => { analysisTimeline = value; },
  setAnalysisPending: (value) => { analysisPending = value; },
  currentAnalysisGeneration: () => analysisGeneration,
  setStatus: (message) => { ui.audioStatus.textContent = message; },
  setDiagnostic: (message) => { ui.audioDiagnostic.textContent = message; },
  isReady: () => window.__cyanescentFullAppReady,
  reportFeedback: reportMusicFeedback,
  resolveTrack: id => musicPlaylistPersistence?.resolveEntry(id),
  acceptNativeTracks: options => options.source !== 'default-startup' || !musicPlaylistPersistence || musicPlaylistPersistence.shouldLoadDefaultFolder()
});

if (!visualOutputRole && !uiPreviewActive && !presetTrialActive && nativeAppBridge()) {
  musicPlaylistPersistence = createMusicPlaylistPersistence({
    store: playerQueueController.store, queue: playerQueueController, player: playerController,
    request: createMusicPlaylistRPC(nativeAppBridge()),
    getDefaultPlaylistId: () => optionsController.options.defaultPlaylistId,
    notify: (message, canReload) => {
      musicPersistenceMessage = message || ''; musicCanReload = Boolean(canReload);
      renderMusicNotice();
    }
  });
  ui.reloadMusicPlaylists.addEventListener('click', async () => {
    if (await requestMusicPlaylistAction({title: 'Reload saved music playlists', confirmLabel: 'Reload',
      message: 'Replace this window’s playlists with the shared saved collection? Unsaved conflict copies remain in Application Support.'})) {
      await musicPlaylistPersistence.reload();
    }
  });
}



async function startAudio() {
  activateVisuals(0);
  if (ui.deviceSelect.value !== SYSTEM_AUDIO_VALUE) systemAudioInput.stop();
  if (ui.deviceSelect.value === ENABLE_EXTERNAL_AUDIO_VALUE) {
    return selectExternalAudioIntent();
  }
  if (ui.deviceSelect.value === "scion") {
    externalAudioNotice = null;
    audioInputDeviceController.rememberSelection("scion");
    await selectScionAudioSource();
    return;
  }
  leaveScionAudioSource();
  if (ui.deviceSelect.value === "player") {
    externalAudioNotice = null;
    audioInputDeviceController.rememberSelection("player");
    await selectPlayerAudioSource();
    return;
  }
  externalAudioNotice = null;
  if (ui.deviceSelect.value === SYSTEM_AUDIO_VALUE) {
    audioInputDeviceController.stopInputStream("system-audio-start");
    playerAudio?.pause();
    analysisGeneration += 1;
    analysisPending = false;
    analysisTimeline = null;
    resetLookaheadState();
    playerMode = false;
    monitoringInput = true;
    window.__nativeAudio = {};
    audioInputDeviceController.rememberSelection(SYSTEM_AUDIO_VALUE);
    if (await systemAudioInput.start()) visualOutputController?.openAutomatically();
    return;
  }
  await startExternalAudioMonitoring({
    ui,
    nativeAppBridge,
    getPlayerAudio: () => playerAudio,
    setPlayerMode: (value) => { playerMode = value; },
    setMonitoringInput: (value) => { monitoringInput = value; },
    incrementAnalysisGeneration: () => { analysisGeneration += 1; },
    setAnalysisPending: (value) => { analysisPending = value; },
    setAnalysisTimeline: (value) => { analysisTimeline = value; },
    resetLookaheadState,
    stopInputStream,
    acquireInputStream: (deviceId) => audioInputDeviceController.acquireSelectedStream(deviceId),
    ensureAudioContext,
    makeAnalyser,
    setInputSource: (value) => { externalInputSource = value; },
    reportDiagnostic: reportAudioInputDiagnostic
  });
  visualOutputController?.openAutomatically();
}

function handleExternalCaptureFailure(error, reason = "external-start-failed") {
  audioInputDeviceController.stopInputStream(reason);
  audioInputDeviceController.rememberSelection("player");
  audioInputDeviceController.fallBackFromExternalIntent(reason, error);
  nativeAppBridge?.()?.postMessage("stopNativeAudio");
  monitoringInput = false;
  playerMode = true;
  console.error(error);
}

async function startSelectedExternalAudio() {
  try {
    await startAudio();
  } catch (error) {
    handleExternalCaptureFailure(error);
  }
}

async function selectExternalAudioIntent() {
  externalAudioNotice = null;
  const audioContextActivation = primeExternalAudioContext({
    ensureAudioContext,
    reportDiagnostic: reportAudioInputDiagnostic
  });
  const resolution = await audioInputDeviceController.resolveExternalIntent();
  if (!resolution?.selection) return resolution;
  await audioContextActivation.activationPromise;
  await startSelectedExternalAudio();
  return resolution;
}

registerStartAudioHandler({
  button: ui.startAudio,
  startAudio,
  setStatus: (message) => {
    ui.audioStatus.textContent = message;
  },
  setDiagnostic: (message) => {
    ui.audioDiagnostic.textContent = message;
  }
});

registerPlayerControlHandlers({
  ui,
  isReady: () => window.__cyanescentFullAppReady,
  ...createPlayerControlActions({
    ui,
    nativeAppBridge,
    loadPlayerFiles,
    togglePlayer: async () => {
      if (!scionActive) return togglePlayer();
      await selectScionAudioSource({ resume: scionPaused });
    },
    playerQueueController,
    getPlayerTime: () => playerAudio?.currentTime || 0,
    loadTrackAt,
    applyPlayerVolume,
    setStatus: (message) => {
      ui.audioStatus.textContent = message;
    },
    setDiagnostic: (message) => {
      ui.audioDiagnostic.textContent = message;
    }
  })
});

let exportRangePreviewCleanup = null;

function stopExportRangePreview() {
  exportRangePreviewCleanup?.();
  exportRangePreviewCleanup = null;
  exportStudio?.syncPlayButtons?.();
}

// Plays the selected export range (looping when asked) with the real player audio.
async function previewExportSelection({ loop = false } = {}) {
  const audio = ensurePlayer();
  let range = exportRangeModel.get();
  if (!range.valid) {
    exportDialog.setProgress(0, range.error || "Choose a valid export range first.");
    return;
  }
  stopExportRangePreview();
  const finish = () => {
    audio.pause();
    stopExportRangePreview();
    redrawExportStudio();
  };
  const checkBoundary = () => {
    // Read the selection every time: its handles can move while the clip plays.
    const current = exportRangeModel.get();
    if (current.valid) range = current;
    if (audio.currentTime < range.end - 0.008 && !audio.ended) {
      redrawExportStudio();
      return;
    }
    if (loop) {
      audio.currentTime = range.start;
      audio.play().catch(console.error);
      return;
    }
    finish();
  };
  exportRangePreviewCleanup = () => {
    audio.removeEventListener("timeupdate", checkBoundary);
    audio.removeEventListener("ended", checkBoundary);
  };
  audio.addEventListener("timeupdate", checkBoundary);
  audio.addEventListener("ended", checkBoundary);
  if (audio.currentTime < range.start || audio.currentTime >= range.end) audio.currentTime = range.start;
  try {
    await playPlayerAudioWithFade();
    exportStudio?.syncPlayButtons?.();
  } catch (error) {
    stopExportRangePreview();
    throw error;
  }
}

function openExportStudio() {
  if (playerAudio && !playerAudio.paused) playerAudio.pause();
  exportStudio.openDialog();
}

function closeExportStudio() {
  if (exportState.active) {
    nativeAppBridge()?.postMessage({ command: "closeExportStudio" });
    return;
  }
  stopMusicVideoTimelinePreview({ restore: true });
  stopExportRangePreview();
  playerAudio?.pause();
  exportStudio.closeDialog();
}

// Called only through native AppKit menu/delegate actions; no keyboard interception.
let lifecycleCancellation = null;
window.__nativeLifecycle = {
  exportActive: () => Boolean(exportState.active || exportState.nativeCancellationPending),
  closeNeedsConfirmation(studioOnly = false) {
    if (!studioOnly && ui.optionsOverlay && !ui.optionsOverlay.classList.contains("hidden")) return false;
    return !ui.exportOverlay?.classList.contains("hidden") && this.exportActive();
  },
  async cancelExport() {
    if (!exportState.active && !exportState.nativeCancellationPending) return;
    if (!lifecycleCancellation) {
      lifecycleCancellation = (async () => {
        await musicVideoExportActions.cancel();
        // Native acknowledgement releases pending frame/mux promises. Wait for
        // the JS renderer's finally block to restore its preview/audio state.
        while (exportState.active) await new Promise(resolve => setTimeout(resolve, 20));
      })().finally(() => { lifecycleCancellation = null; });
    }
    await lifecycleCancellation;
  },
  async closeCurrent(studioOnly = false) {
    if (!studioOnly && ui.optionsOverlay && !ui.optionsOverlay.classList.contains("hidden")) {
      ui.optionsOverlay.classList.add("hidden");
      return true;
    }
    if (ui.exportOverlay && !ui.exportOverlay.classList.contains("hidden")) {
      await this.cancelExport();
      closeExportStudio();
      return true;
    }
    return false;
  },
  async prepareQuit() {
    await this.cancelExport();
    stopMusicVideoTimelinePreview({ restore: true });
    stopExportRangePreview();
    exportStudio.closeDialog();
    playerAudio?.pause();
  }
};

async function applyNativeUiPreviewFixture({ previewId, fixtureId }) {
  if (fixtureId === "audio-track") {
    // Development harness: a real, analysed track drives the Export Studio.
    const diagnostics = await import("./ui/exportStudioDiagnostics.js");
    const ctx = {
      params: uiPreviewParams,
      setPlayerQueue,
      analysis: () => ({ timeline: analysisTimeline, pending: analysisPending, duration: playerDuration() }),
      openStudio: () => openExportStudio(),
      studio: exportStudio,
      journey: exportJourneyEditor,
      exportState,
      exportOptions: () => exportStudio.exportOptions(),
      automaticPlan: () => offlineExportController.buildOfflinePresetTimeline(playerDuration(), {allowManual:false}),
      range: () => exportRangeModel.get(),
      seek: seekExportPlayback,
      playhead: () => playerAudio?.currentTime || 0,
      audio: () => playerAudio,
      activePreset: () => activePreset,
      presets: () => builtInPresetOptions,
      exportPreset: (config) => musicVideoExportActions.startDiagnostic(config),
      showVisualiser: () => visualOutputController?.show(),
      visualiserOpen: () => Boolean(visualOutputController?.isOpen?.())
    };
    await diagnostics.loadFixtureTrack(ctx);
    if (previewId === "export-run") await diagnostics.runExportPlan(ctx, uiPreviewParams.get("exportPlan"));
    else if (previewId.startsWith("export-")) await diagnostics.applyStudioState(ctx, previewId);
    window.CyanescentDiagnostics?.reportStage("export-opened", { previewId });
    return;
  }
  if (fixtureId !== "standard-project") {
    throw new Error(`Unsupported native UI preview fixture: ${fixtureId}`);
  }
  const fixture = {
    trackName: "Neon Cartography — Synthetic Mix",
    artist: "Cyanescent Test Ensemble",
    duration: 184.5,
    rangeStart: 18.25,
    rangeEnd: 142.75,
    presetId: 5,
    outputFileName: "neon-cartography-synthetic-mix.mp4",
    outputPath: "Fixture destination (not written)",
    destinationId: "youtube-hd-60"
  };
  uiPreviewFixtureTrackName = fixture.trackName;
  uiPreviewFixtureDuration = fixture.duration;
  ui.trackName.textContent = fixture.trackName;
  ui.trackTime.textContent = `0:00 / ${Math.floor(fixture.duration / 60)}:${String(Math.floor(fixture.duration % 60)).padStart(2, "0")}`;
  ui.audioStatus.textContent = "fixture ready";
  ui.audioDiagnostic.textContent = `${fixture.artist} · deterministic standard-project fixture`;
  ui.queueSummary.textContent = "1 synthetic track in queue";
  ui.queueList.replaceChildren(Object.assign(document.createElement("div"), {
    className: "queue-item active",
    textContent: fixture.trackName
  }));
  if (ui.presetSelect) ui.presetSelect.value = String(fixture.presetId);
  activePreset = fixture.presetId;
  visualTransitions?.setPresetImmediate?.(fixture.presetId);
  exportRangeModel.setTrackDuration(fixture.duration);
  exportRangeModel.setRange(fixture.rangeStart, fixture.rangeEnd, { reason: "ui-preview-fixture" });

  if (previewId.startsWith("export-")) {
    openExportStudio();
    if (previewId === "export-timeline") ui.exportModeCustom?.click();
    else ui.exportModeAutomatic?.click();
    window.CyanescentDiagnostics?.reportStage("export-opened", { mode: previewId === "export-timeline" ? "timeline" : "auto" });
    if (ui.exportFileName) ui.exportFileName.value = fixture.outputFileName.replace(/\.mp4$/, "");
    exportStudio.render();
  } else {
    exportDialog.closeDialog();
  }
}

if (uiPreviewActive) {
  installNativeUiPreviewBridge({
    previewId: uiPreviewId,
    fixtureId: uiPreviewFixtureId,
    applyFixture: applyNativeUiPreviewFixture,
    nativeApp: nativeAppBridge
  });
}

ui.exportMusicVideo?.addEventListener("click", () => openExportStudio());
ui.closeExportDialog?.addEventListener("click", () => closeExportStudio());
ui.exportOverlay?.addEventListener("click", (event) => {
  if (event.target === ui.exportOverlay) closeExportStudio();
});
ui.launchExportedVideo?.addEventListener("click", () => {
  if (exportState.savedPath) nativeAppBridge()?.postMessage({ command: "openExportedVideo", path: exportState.savedPath });
});

ui.closeTimelinePreview?.addEventListener("click", () => {
  if (presetDemoPreview) stopPresetDemoPreview({ reopenManager: true });
  else stopMusicVideoTimelinePreview({ restore: true });
});


optionsController.registerOptionHandlers();

registerWaveformInteractionHandlers({
  canvas: ui.waveformCanvas,
  zoomControl: ui.waveformZoom,
  resetControl: ui.waveformZoomReset,
  debugEnabled: debugModeEnabled,
  canSeek: () => Boolean(playerAudio && waveformDuration()),
  getView: () => waveformController.viewRange(),
  getDuration: waveformDuration,
  getCurrentTime: () => waveformController.playerTimeToWaveformTime(playerAudio?.currentTime || 0),
  xToTime: (x, width, view) => waveformController.xToTime(x, width, view),
  onSeek: (time) => {
    waveformController.setZoomCenterFromTime(time);
    playerAudio.currentTime = waveformController.waveformTimeToPlayerTime(time);
    updateLookaheadState();
    visualTransitions.handleSeek(playerAudio.currentTime || 0);
    updateWaveformProgress(true);
  },
  onMarkDrop: (time, options) => toggleDropMarkerAt(waveformController.waveformTimeToPlayerTime(time), options),
  onZoom: (value, anchorTime, options = {}) => {
    waveformController.setZoom(options.absolute ? value : waveformController.zoom() * value, anchorTime);
  },
  getExportRange: () => exportRangeModel.get(),
  onExportRangeChange: (edge, time) => {
    if (edge === "start") exportRangeModel.setStart(time);
    else exportRangeModel.setEnd(time);
  }
});

optionsController.registerVisualSettings();

if (!visualOutputRole) {
  audioInputDeviceController.initialize().then(({ restoreDeviceId }) => {
    if (!restoreDeviceId) return;
    ui.deviceSelect.value = restoreDeviceId;
    window.setTimeout(() => {
      startAudio().catch((error) => {
        ui.deviceSelect.value = "player";
        audioInputDeviceController.rememberSelection("player");
        audioInputDeviceController.presentError(error);
      });
    }, 250);
  }).catch((error) => {
    audioInputDeviceController.presentError(error);
  });
}

if (!visualOutputRole) {
  ui.fullscreen?.addEventListener("click", () => {
    activateVisuals(0);
    visualOutputController?.toggleFullscreen();
  });
}

registerResizeHandler({ resize });
if (!visualOutputRole) {
  registerAudioFileDropHandler({
    isAudioFileName,
    loadFiles: loadPlayerFiles,
    setStatus: (message) => {
      ui.audioStatus.textContent = message;
    },
    setDiagnostic: (message) => {
      ui.audioDiagnostic.textContent = message;
    }
  });
}

playerQueueController.updateRepeatButton();
playerQueueController.renderQueue();
drawWaveform();
resize();
registerUserInteractionTracker({
  onInteraction: () => {
    lastUserInteractionAt = performance.now();
    liveVisualRuntime.markUserInteraction();
  }
});
setAppReady(false);
if (uiPreviewActive) {
  document.body.classList.remove("engine-booting");
  document.body.classList.add("engine-ready");
  ui.engineSplash?.classList.add("hidden");
  window.CyanescentDiagnostics?.reportStage("ui-controllers-ready");
  window.dispatchEvent(new CustomEvent("cyanescent-ui-ready"));
}
performanceController = createPerformanceController({
  ui,
  nativeApp: nativeAppBridge,
  metadata: PRESET_METADATA,
  presetIds: () => visualTransitions.presetIds(),
  getRenderSize: () => renderSurface.renderSize(),
  setStaticTransitionMode: () => {
    visualTransitions.setStaticTransitionMode();
    if (ui.transitionMode) ui.transitionMode.value = VisualTransitionMode.STATIC;
  },
  setRepeatOne: () => {
    playerQueueController.setRepeatMode("one");
    playerQueueController.updateRepeatButton();
  },
  setPlayerQueue,
  activateVisuals,
  visualsReady: () => visualsReady,
  setPreset: (presetId) => {
    visualTransitions.setPresetImmediate(presetId);
  },
  clearFeedbackBuffers: () => {
    if (visualsReady && renderSurface.hasBuffers()) clearFeedbackBuffers();
  },
  primePreset: primePresetShaderModule
});

function diagnosticDelay(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

async function runTransitionDiagnosticSuite() {
  if (!transitionDiagnosticRunEnabled) return;
  const candidates = [5, 146, 176, 97, 165, 147]
    .map((preset) => visualTransitions.normalizePresetId(preset))
    .filter((preset, index, values) => values.indexOf(preset) === index);
  if (candidates.length < 4) {
    console.warn(`[TransitionDiag] event=suite_error reason=insufficient_presets count=${candidates.length}`);
    return;
  }

  const waitForTransition = async (timeoutMs) => {
    const deadline = performance.now() + timeoutMs;
    while (visualTransitions.getTransition()?.active && performance.now() < deadline) {
      await diagnosticDelay(100);
    }
    await diagnosticDelay(750);
  };
  const runPhase = async (kind, targets) => {
    optionsController.options.useVideoTransitions = kind === "video";
    if (ui.useVideoTransitions) ui.useVideoTransitions.checked = kind === "video";
    console.warn(`[TransitionDiag] event=suite_phase kind=${kind} targets=${targets.join(",")}`);
    for (const target of targets) {
      const started = visualTransitions.begin(target, "diagnostic");
      console.warn(`[TransitionDiag] event=suite_transition kind=${kind} target=${target} started=${started}`);
      if (started) await waitForTransition(kind === "video" ? 14000 : 7000);
    }
  };

  console.warn(`[TransitionDiag] event=suite_begin presets=${candidates.join(",")}`);
  quality = 1;
  ui.highMode?.classList.add("active");
  ui.standardMode?.classList.remove("active");
  ui.fullscreen?.click();
  resize();
  visualTransitions.setStaticTransitionMode();
  visualTransitions.setPresetImmediate(candidates[0]);
  await diagnosticDelay(2000);
  await runPhase("rendered", candidates.slice(1, 4));
  await runPhase("video", candidates.slice(4).concat(candidates[0]));
  optionsController.options.useVideoTransitions = false;
  if (ui.useVideoTransitions) ui.useVideoTransitions.checked = false;
  console.warn("[TransitionDiag] event=suite_end");
}

if (runsLocalVisualRenderer) {
  const startup = presetTrialActive ? Promise.resolve().then(preparePresetTrial).then(() => warmVisualEngineAtStartup()) : warmVisualEngineAtStartup();
  startup.then(async () => {
    if (visualOutputRole) visualOutputController?.markReady();
    if (primaryWorldshellBenchmark) {
      startWorldshellBenchmark().catch((error) => {
        console.error("Worldshell benchmark setup failed:", error);
      });
    }
    if (performanceController.enabled()) {
      window.setTimeout(() => {
        performanceController.start();
      }, 350);
    }
    if (presetTrialTrackActive) {
      await setPlayerQueue([{ id: "native-trial-wav", name: "TestPsy.wav",
        url: new URL("assets/TestPsy.wav", window.location.href).href }], 0, false);
      await playPlayerAudioWithFade();
      presetTrialLog("AUDIO", "TRACK_STARTED", { source: playerAudio?.currentSrc,
        context: playerRuntime?.audioContext?.state });
    }
    if (presetTrialActive && presetTrialMetadata) activateVisuals(0);
  });
} else {
  videoAssetManager.loadTransitionManifests().catch((error) => {
    console.warn("Video transition manifests are not available yet:", error);
  });
  setLocalSplashProgress(0.02, "Preparing visual output renderer");
  visualOutputController?.prewarm();
  runTransitionDiagnosticSuite().catch((error) => {
    console.warn(`[TransitionDiag] event=suite_error reason=${String(error?.message || error)}`);
  });
}

function preparePresetTrial() {
  const requested = String(presetTrialPresetId).trim().toLowerCase();
  const slug = (name) => name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  const metadata = PRESET_METADATA.find((item) => String(item.id) === requested || slug(item.name) === requested);
  if (!metadata) {
    nativeAppBridge()?.postMessage({ command: "presetTrialReady", error: PRESET_CANDIDATE_METADATA.some(p => p.optional && (String(p.id) === requested || slug(p.name) === requested))
      ? `HD World unavailable: ${hdWorldStatus(Number(presetTrialPresetId)).message}. Quit Player, install the matching pack, then restart.` : `Unknown production preset '${presetTrialPresetId}'` });
    return;
  }
  presetTrialMetadata = metadata;
  if ((presetTrialFixtureId.startsWith("helix-high") || presetTrialFixtureId.startsWith("stinkhorn-high")) || /^(ia|hg)-(.*-)?high(-|$)/.test(presetTrialFixtureId)) {
    quality = 1;
    ui.highMode?.classList.add("active"); ui.standardMode?.classList.remove("active");
    resize();
  }
  let trialAudioDestination = null;
  const videoCapture = createPresetTrialVideoCapture({
    canvas,
    nativeApp: nativeAppBridge,
    // The renderer can be measured at 60 FPS while a 30 FPS diagnostic composite
    // avoids forcing full-resolution video readback on every animation frame.
    targetFps: Math.min(30, presetTrialTargetFps),
    stopAtSeconds: presetTrialDuration,
    enabled: presetTrialVideoEnabled,
    getBackgroundVideo: () => Number(activePreset) === APOLLONIAN_PHYSARUM_GENESIS_ID ? window.__forgeHybridVideo
      : Number(activePreset) === DUOVERSE_HD_ID ? window.__duoverseVideo
      : Number(activePreset) === NEWTON_BASIN_DESCENT_ID ? window.__newtonBasinVideo
      : Number(activePreset) === NEWTONS_LAW_ID ? window.__newtonsLawVideo
      : Number(activePreset) === ARTIFICIAL_CONSCIOUSNESS_ID ? window.__artificialConsciousnessVideo
      : Number(activePreset) === HELIX_TUNNEL_ID ? window.__helixTunnelVideo : null,
    getAudioStream: () => {
      if (!presetTrialTrackActive || !playerRuntime?.analyser) return null;
      trialAudioDestination = playerRuntime.audioContext.createMediaStreamDestination();
      playerRuntime.analyser.connect(trialAudioDestination);
      return trialAudioDestination.stream;
    }
  });
  presetTrialRuntime = createPresetTrialRuntime({
    fixtureId: presetTrialFixtureId,
    nativeApp: nativeAppBridge,
    targetFps: presetTrialTargetFps,
    startVideoCapture: videoCapture.start,
    stopVideoCapture: async () => {
      const result = await videoCapture.stop();
      if (presetTrialTrackActive) playerAudio?.pause();
      if (trialAudioDestination) {
        playerRuntime?.analyser?.disconnect(trialAudioDestination);
        trialAudioDestination.stream.getTracks().forEach(track => track.stop());
      }
      return result;
    },
    noteVideoFrame: videoCapture.noteFrame
  });
  window.CyanescentPresetTrial = presetTrialRuntime;
  if (presetTrialVideoTransitionIn) {
    // Leave the trial preset for preset 5 once the trial is ready, preflight it as an
    // auto-transition candidate would, then video-transition back into it.
    const target = Number(metadata.id);
    let stage = 0, readyAt = null;
    const timer = window.setInterval(() => {
      if (!presetTrialRuntime.ready()) return;
      const elapsed = presetTrialRuntime.elapsed();
      if (readyAt === null) readyAt = elapsed;
      if (stage === 0) { stage = 1; visualTransitions.setPresetImmediate(5); presetTrialLog("TRANSITION", "LEFT_TARGET", { elapsed }); }
      if (stage === 1 && elapsed - readyAt > 2.5) { stage = 2; visualFrameRenderer.queuePresetPreflight(target); presetTrialLog("TRANSITION", "PREFLIGHT_QUEUED", { elapsed }); }
      if (stage === 2 && elapsed - readyAt > 3.5) {
        stage = 3;
        const began = visualTransitions.begin(target, "diagnostic", {
          forceVideoTransition: true, videoTransitionId: "cosmic_om", timing: { duration: 3000, swapAt: .45 }
        });
        presetTrialLog("TRANSITION", "VIDEO_TRANSITION_BEGIN", { began, target, elapsed });
      }
      if (stage === 3 && !visualTransitions.getTransition()?.active) {
        stage = 4; window.clearInterval(timer);
        presetTrialLog("TRANSITION", "VIDEO_TRANSITION_END", { elapsed, activePreset });
      }
    }, 100);
  }
  presetTrialLog("WEB", "DOCUMENT_LOADED", { fixture: presetTrialFixtureId });
  presetTrialLog("WEB", "CANVAS_FOUND", { found: Boolean(canvas) });
  presetTrialCanvasProbe("startup");
  visualTransitions.setStaticTransitionMode();
  visualTransitions.setPresetImmediate(metadata.id);
  activePreset = metadata.id;
  activePresetStartedAt = performance.now();
  if (ui.presetSelect) ui.presetSelect.value = String(metadata.id);
  presetTrialLog("REGISTRY", "PRESET_RESOLVED", { presetId: metadata.id, preset: metadata.name });
  window.__presetTrialCanvasPng = () => window.__presetTrialLastCanvasPng || "";
  window.__presetTrialCaptureRequested = false;
  window.__requestPresetTrialCapture = () => new Promise((resolve, reject) => {
    const request = { resolve, reject, timer: null };
    request.timer = setTimeout(() => {
      const index = presetTrialCaptureRequests.indexOf(request);
      if (index >= 0) presetTrialCaptureRequests.splice(index, 1);
      window.__presetTrialCaptureRequested = presetTrialCaptureRequests.length > 0;
      reject(new Error("The renderer did not produce a requested screenshot within 8 seconds."));
    }, 8000);
    presetTrialCaptureRequests.push(request);
    window.__presetTrialCaptureRequested = true;
  });
  // All three images were captured together during a real render frame. Reading
  // the WebGL canvas here later could return its discarded default framebuffer.
  window.__captureForgeBraidComparison = () => window.__forgeTrialLastComparison || null;
  const trialCanvas = document.getElementById("visualizer");
  trialCanvas?.addEventListener("webglcontextlost", (event) => {
    event.preventDefault();
    console.error(`[PresetTrial] WebGL context lost for ${metadata.name}`);
    presetTrialRuntime?.frame({ presetId: metadata.id, presetDisplayName: metadata.name, shaderState: "error", contextLost: true });
  }, { once: true });
}


function updateTrackTimeDisplay() {
  updateTrackTimeDisplayView({
    element: ui.trackTime,
    audio: playerAudio,
    timeline: analysisTimeline
  });
}
